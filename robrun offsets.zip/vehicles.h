#pragma once
#include <cstdint>

namespace Offsets::Vehicles {

    namespace AccessVehicleRules { // "AccessVehicleRules (Battle.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t HasVehicleAccess = 0x90C020; // "public static bool HasVehicleAccess(long publicId, VehicleOwnerModel vehicleOwnerModel, PartyModel partyModel, ICharacterSlotsModel characterSlotsModel, IClanBattleCharacterTeamModel clanBattleCharacterTeamModel)"
            inline constexpr std::uintptr_t IsOwnerVehicle = 0x90C230; // "public static bool IsOwnerVehicle(long publicId, VehicleOwnerModel vehicleOwnerModel)"
        }
    } // namespace AccessVehicleRules

    namespace AlarmCarUpgradeReadAdapter { // "Models.Utils.Adapters.CarUpgradeAdapter.AlarmCarUpgradeReadAdapter (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t TryFromItem = 0x3C78040; // "public bool TryFromItem(InventoryItemDescription item, out AlarmCarUpgradeDescription value)"
            inline constexpr std::uintptr_t TryGetUpgradeSlot = 0x3C78080; // "public bool TryGetUpgradeSlot(CarUpgradesSlotsModel carUpgradesSlotsModel, int slotIndex, CarDescription carDescription, out IPrimitiveModel<AlarmCarUpgradeDescription> slotModel)"
            inline constexpr std::uintptr_t CheckUnsetUpgrade = 0x7D5050; // "public bool CheckUnsetUpgrade(int entityId, IPrimitiveModel<AlarmCarUpgradeDescription> slotModel)"
            inline constexpr std::uintptr_t CheckSwap = 0x7D5050; // "public bool CheckSwap(int entityId, IPrimitiveModel<AlarmCarUpgradeDescription> slotModel, AlarmCarUpgradeDescription upgradeDescription)"
        }
    } // namespace AlarmCarUpgradeReadAdapter

    namespace BattleCharacterCarInputModel { // "Models.Models.BattleCharacterCarInput.BattleCharacterCarInputModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ZInput = 0x10; // "float"
            inline constexpr std::uintptr_t XInput = 0x14; // "float"
            inline constexpr std::uintptr_t HandBrakeInput = 0x18; // "bool"
            inline constexpr std::uintptr_t BurnoutInput = 0x19; // "bool"
            inline constexpr std::uintptr_t HornInput = 0x1A; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetZInput = 0x834220; // "public void SetZInput(float value)"
            inline constexpr std::uintptr_t SetXInput = 0x834230; // "public void SetXInput(float value)"
            inline constexpr std::uintptr_t SetHandBrakeInput = 0x36581D0; // "public void SetHandBrakeInput()"
            inline constexpr std::uintptr_t SetBurnoutInput = 0x49D6820; // "public void SetBurnoutInput()"
            inline constexpr std::uintptr_t SetHornInput = 0x49D6830; // "public void SetHornInput()"
            inline constexpr std::uintptr_t Clear = 0x49D6810; // "public void Clear()"
        }
    } // namespace BattleCharacterCarInputModel

    namespace BattleCharacterHelicopterInputModel { // "Models.Models.BattleCharacterHelicopterInput.BattleCharacterHelicopterInputModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ContainsThrustInput = 0x10; // "bool"
            inline constexpr std::uintptr_t Thrust = 0x14; // "float"
            inline constexpr std::uintptr_t ContainsRotationInput = 0x18; // "bool"
            inline constexpr std::uintptr_t Rotation = 0x1C; // "float"
            inline constexpr std::uintptr_t ContainsTiltInput = 0x20; // "bool"
            inline constexpr std::uintptr_t TiltX = 0x24; // "float"
            inline constexpr std::uintptr_t TiltZ = 0x28; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetThrustInput = 0x28EE980; // "public void SetThrustInput(float thrust)"
            inline constexpr std::uintptr_t SetRotationInput = 0x49778F0; // "public void SetRotationInput(float rotation)"
            inline constexpr std::uintptr_t SetTiltInput = 0x49D6960; // "public void SetTiltInput(float tiltX, float tiltZ)"
            inline constexpr std::uintptr_t Clear = 0x49D6950; // "public void Clear()"
        }
    } // namespace BattleCharacterHelicopterInputModel

    namespace BattleCharacterLocationVehicleModel { // "Models.Models.BattleCharacterLocationVehicle.BattleCharacterLocationVehicleModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t vehicleType = 0x10; // "IPrimitiveData<VehicleTypeDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_HasVehicle = 0x49D6AC0; // "public bool get_HasVehicle()"
            inline constexpr std::uintptr_t get_VehicleType = 0x49D6B10; // "public VehicleTypeDescription get_VehicleType()"
            inline constexpr std::uintptr_t Set = 0x49D6A10; // "public void Set(VehicleTypeDescription vehicleType)"
            inline constexpr std::uintptr_t Unset = 0x49D6A70; // "public void Unset()"
        }
    } // namespace BattleCharacterLocationVehicleModel

    namespace BattleCharacterPoliceCarBreachStateModel { // "Models.Models.BattleCharacterPoliceCarBreachState.BattleCharacterPoliceCarBreachStateModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t BreachEndTs = 0x10; // "long"
            inline constexpr std::uintptr_t CopPresetDescription = 0x18; // "CopPresetDescription"
        }
    } // namespace BattleCharacterPoliceCarBreachStateModel

    namespace BattleSkinCenterRequestingVehicleTabModelUpdater { // "Game.Battle.SkinCenter.BattleSkinCenterRequestingVehicleTabModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dialogModel = 0x10; // "SkinCenterDialogModel"
            inline constexpr std::uintptr_t skinCenterSceneModel = 0x18; // "SkinCenterSceneModel"
            inline constexpr std::uintptr_t regionUserSettlementModel = 0x20; // "RegionUserSettlementModel"
            inline constexpr std::uintptr_t modalDialogModel = 0x28; // "ModalDialogModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x30; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t battleCharacterModel = 0x38; // "BattleCharacterModel"
            inline constexpr std::uintptr_t skinCenterLocalization = 0x40; // "SkinCenterLocalization"
            inline constexpr std::uintptr_t globalLocalizationKeys = 0x48; // "GlobalLocalizationKeys"
            inline constexpr std::uintptr_t publicId = 0x50; // "long"
            inline constexpr std::uintptr_t vehicleOwnersModel = 0x58; // "VehicleOwnersModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xD9FAB0; // "public void Update()"
            inline constexpr std::uintptr_t IsCurrentCarOutsideBase = 0xD9F4D0; // "private bool IsCurrentCarOutsideBase(PlotModel plotModel)"
            inline constexpr std::uintptr_t HasCarOutsideBase = 0xD9E7C0; // "private bool HasCarOutsideBase(CarSlotDescription slot, PlotModel plotModel)"
            inline constexpr std::uintptr_t IsCurrentHelicopterOutsideBase = 0xD9F5E0; // "private bool IsCurrentHelicopterOutsideBase(PlotModel plotModel)"
            inline constexpr std::uintptr_t HasHelicopterOutsideBase = 0xD9EFF0; // "private bool HasHelicopterOutsideBase(HelicopterSlotDescription slot, PlotModel plotModel)"
            inline constexpr std::uintptr_t OnModalOk = 0xD9FA60; // "private void OnModalOk()"
            inline constexpr std::uintptr_t OnModalCancel = 0xD9F6F0; // "private void OnModalCancel()"
        }
    } // namespace BattleSkinCenterRequestingVehicleTabModelUpdater

    namespace BuyCarMessage { // "Models.Messages.BuyCarMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t car = 0x20; // "IPrimitiveData<CarDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Car = 0x49E6F60; // "public CarDescription get_Car()"
            inline constexpr std::uintptr_t get_Type = 0x49E6FB0; // "public override string get_Type()"
        }
    } // namespace BuyCarMessage

    namespace BuyHelicopterMessage { // "Models.Messages.BuyHelicopterMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t helicopter = 0x20; // "IPrimitiveData<HelicopterDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Helicopter = 0x49E86E0; // "public HelicopterDescription get_Helicopter()"
            inline constexpr std::uintptr_t get_Type = 0x49E8730; // "public override string get_Type()"
        }
    } // namespace BuyHelicopterMessage

    namespace CarAnyPredictionSavePhysicsAndTickDataSystem { // "ClientCore.Systems.CarAnyPredictionSavePhysicsAndTickDataSystem (Client.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsSceneModel = 0x38; // "PhysicsSceneModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0xE512E0; // "protected override void Tick(ITick tick)"
            inline constexpr std::uintptr_t BuildWheelTimelineTickData = 0xE51250; // "private static CarWheelTimelineTickData BuildWheelTimelineTickData(ValueTuple<VehicleWheelSuspensionTickDataModel, VehicleWheelGroundTickDataModel, CarWheelFrictionTickDataModel> wheelTickData)"
        }
    } // namespace CarAnyPredictionSavePhysicsAndTickDataSystem

    namespace CarAnyPredictionUpdatePhysicsAndTickDataSystem { // "ClientCore.Systems.CarAnyPredictionUpdatePhysicsAndTickDataSystem (Client.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsSceneModel = 0x38; // "PhysicsSceneModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0xE51B90; // "protected override void Tick(ITick tick)"
            inline constexpr std::uintptr_t UpdatePhysicsScene = 0xE52070; // "private void UpdatePhysicsScene(in CarTimelineTickData timelineTickData, in CarTimelineSubTickData timelineSubTickData, PhysicsBodyId bodyId)"
            inline constexpr std::uintptr_t UpdateWheel = 0xE524A0; // "private static void UpdateWheel(in CarWheelTimelineTickData timelineTickData, ValueTuple<VehicleWheelSuspensionTickDataModel, VehicleWheelGroundTickDataModel, CarWheelFrictionTickDataModel> wheelTickData)"
        }
    } // namespace CarAnyPredictionUpdatePhysicsAndTickDataSystem

    namespace CarAxleClientModel { // "Game.Battle.EntityModel.Car.Wheel.CarAxleClientModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t LeftLinkPosition = 0x28; // "Vector3"
            inline constexpr std::uintptr_t RightLinkPosition = 0x34; // "Vector3"
            inline constexpr std::uintptr_t LeftWheelPosition = 0x40; // "Vector3"
            inline constexpr std::uintptr_t RightWheelPosition = 0x4C; // "Vector3"
            inline constexpr std::uintptr_t BaseOrientation = 0x58; // "Quaternion"
            inline constexpr std::uintptr_t SteeringOrientation = 0x68; // "Quaternion"
            inline constexpr std::uintptr_t RollOrientation = 0x78; // "Quaternion"
            inline constexpr std::uintptr_t LeftCamberOrientation = 0x88; // "Quaternion"
            inline constexpr std::uintptr_t RightCamberOrientation = 0x98; // "Quaternion"
            inline constexpr std::uintptr_t WorldWheelForward = 0xA8; // "Vector3"
            inline constexpr std::uintptr_t Blocked = 0xB4; // "bool"
            inline constexpr std::uintptr_t Slipping = 0xB5; // "bool"
            inline constexpr std::uintptr_t InAir = 0xB6; // "bool"
            inline constexpr std::uintptr_t SlipTs = 0xB8; // "long"
            inline constexpr std::uintptr_t Rpm = 0xC0; // "float"
            inline constexpr std::uintptr_t WheelLastAngularVelocity = 0xC4; // "float"
            inline constexpr std::uintptr_t WheelRollAccumulator = 0xC8; // "float"
        }
    } // namespace CarAxleClientModel

    namespace CarBenchDialogUpdater { // "Game.Battle.EntityModel.VehicleBench.CarBenchDialogUpdater (Battle.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x817AF30; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace Fields {
            inline constexpr std::uintptr_t updaters = 0x20; // "List<IUpdater>"
            inline constexpr std::uintptr_t isDragSuitableCarItem = 0x28; // "Func<bool>"
            inline constexpr std::uintptr_t inventoryModels = 0x30; // "InventoryModels"
            inline constexpr std::uintptr_t disposableContent = 0x38; // "IDisposable"
            inline constexpr std::uintptr_t globalModel = 0x40; // "GlobalModel"
        }
        namespace StaticFields {
            inline constexpr std::uintptr_t isValidItem = 0x0; // "Func<IInventoryItemModel, bool>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xC1CF70; // "public CarBenchDialogUpdater Init(CurrentInventoryModel.CarBench currentInventoryModel, GlobalModel globalModel, BattleModel battleModel, GlobalScreenContent globalScreenContent, BattleScreenContent battleScreenContent, UpdaterPool updaterPool, Transform canvasParent, DeviceModel deviceModel, InputActions inputActions, List<IUpdater> mainInputUpdaters, InteractRaycastModel interactRaycastModel, IRegisterDisposable registerDisposable)"
            inline constexpr std::uintptr_t Dispose = 0xC1CE90; // "protected override void Dispose()"
            inline constexpr std::uintptr_t IsDragSuitableCarItem = 0xC1DE50; // "private bool IsDragSuitableCarItem()"
            inline constexpr std::uintptr_t IsValidItem = 0xC1DF40; // "private static bool IsValidItem(IInventoryItemModel itemModel)"
            inline constexpr std::uintptr_t OnUpdate = 0x94CF50; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace CarBenchDialogUpdater

    namespace CarBenchDropAreaInputUpdater { // "Game.Battle.EntityModel.VehicleBench.CarBenchDropAreaInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t items = 0x20; // "List<ValueTuple<VehicleBenchItemView, IItemMoveContext>>"
            inline constexpr std::uintptr_t dragAndDropModel = 0x28; // "InventoryDragAndDropModel"
            inline constexpr std::uintptr_t itemMoveModel = 0x30; // "ItemMoveModel"
            inline constexpr std::uintptr_t blockedSlotsModel = 0x38; // "BlockedSlotsModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xC1E110; // "public CarBenchDropAreaInputUpdater Init(InventoryModels inventoryModels, List<ValueTuple<VehicleBenchItemView, IItemMoveContext>> items, BlockedSlotsModel blockedSlotsModel)"
            inline constexpr std::uintptr_t Dispose = 0x9F4BF0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xC1E190; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t UpdateSlot = 0xC1E430; // "private void UpdateSlot(VehicleBenchItemView view, IItemMoveContext to)"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace CarBenchDropAreaInputUpdater

    namespace CarBenchItemMoveContext { // "Game.Battle.EntityModel.VehicleBench.CarBenchItemMoveContext (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t SlotModel = 0x10; // "CarBenchSlotModel"
            inline constexpr std::uintptr_t ItemModel = 0x18; // "IInventoryItemModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_EntityId = 0xC01B80; // "public int get_EntityId()"
            inline constexpr std::uintptr_t get_SlotDescription = 0xC01C30; // "public PlotCarSlotDescription get_SlotDescription()"
            inline constexpr std::uintptr_t get_RevealContainerModel = 0xC01BA0; // "public IRevealContainerModel get_RevealContainerModel()"
            inline constexpr std::uintptr_t get_Revealed = 0x7D5050; // "public bool get_Revealed()"
            inline constexpr std::uintptr_t get_Count = 0xC01B20; // "public int get_Count()"
            inline constexpr std::uintptr_t get_Ammo = 0x7E3AB0; // "public int get_Ammo()"
            inline constexpr std::uintptr_t get_Durability = 0x7E3AB0; // "public int get_Durability()"
            inline constexpr std::uintptr_t get_CumulativePoints = 0x7E3AB0; // "public int get_CumulativePoints()"
        }
    } // namespace CarBenchItemMoveContext

    namespace CarBenchSlotModel { // "Game.Battle.EntityModel.VehicleBench.CarBenchSlotModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t EntityId = 0x10; // "int"
            inline constexpr std::uintptr_t PlotCarModel = 0x18; // "IPlotCarModel"
            inline constexpr std::uintptr_t InventoryItemModel = 0x20; // "IInventoryItemModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_PlotVehicleModel = 0x7E7130; // "public IPlotVehicleModel get_PlotVehicleModel()"
            inline constexpr std::uintptr_t get_InventoryItemDescription = 0xC1E6C0; // "public InventoryItemDescription get_InventoryItemDescription()"
            inline constexpr std::uintptr_t get_IsEmpty = 0xC1E730; // "public bool get_IsEmpty()"
            inline constexpr std::uintptr_t CreateMoveContext = 0xC1E5D0; // "public IItemMoveContext CreateMoveContext()"
        }
    } // namespace CarBenchSlotModel

    namespace CarBenchSlotsModel { // "Game.Battle.EntityModel.VehicleBench.CarBenchSlotsModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t EntityId = 0x10; // "int"
            inline constexpr std::uintptr_t Slots = 0x18; // "IVehicleBenchSlotModel[]"
        }
    } // namespace CarBenchSlotsModel

    namespace CarBenchTargetActions { // "Game.Battle.EntityModel.VehicleBench.CarBenchTargetActions (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t entityId = 0x10; // "int"
            inline constexpr std::uintptr_t globalModel = 0x18; // "GlobalModel"
            inline constexpr std::uintptr_t battleModel = 0x20; // "BattleModel"
            inline constexpr std::uintptr_t plotModel = 0x28; // "PlotModel"
            inline constexpr std::uintptr_t globalLocalizationKeys = 0x30; // "GlobalLocalizationKeys"
            inline constexpr std::uintptr_t personalNotificationModel = 0x38; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t uiSoundModel = 0x40; // "GlobalUISoundModel"
            inline constexpr std::uintptr_t notificationKeys = 0x48; // "NotificationKeys"
            inline constexpr std::uintptr_t dialogModel = 0x50; // "InventoryDialogModel"
            inline constexpr std::uintptr_t interactEntityModel = 0x58; // "IInteractEntityModel"
            inline constexpr std::uintptr_t inputActions = 0x60; // "InputActions"
            inline constexpr std::uintptr_t clientCodexModel = 0x68; // "ClientCodexModel"
            inline constexpr std::uintptr_t battleRoomConnection = 0x70; // "IRoomConnection"
            inline constexpr std::uintptr_t isSendingMessage = 0x78; // "bool"
            inline constexpr std::uintptr_t UseAction = 0x80; // "TargetAction"
            inline constexpr std::uintptr_t RentAction = 0x88; // "TargetAction"
            inline constexpr std::uintptr_t CallAction = 0x90; // "TargetAction"
        }
        namespace Methods {
            inline constexpr std::uintptr_t OnRent = 0xC01F20; // "private void OnRent()"
            inline constexpr std::uintptr_t TryShowRentCodex = 0xC02570; // "private void TryShowRentCodex()"
            inline constexpr std::uintptr_t SendRentMessage = 0xC02410; // "private void SendRentMessage()"
            inline constexpr std::uintptr_t OnCall = 0xC01D10; // "private void OnCall()"
            inline constexpr std::uintptr_t SendSpawnMessage = 0xC024C0; // "private void SendSpawnMessage()"
            inline constexpr std::uintptr_t Unavailable = 0xAE9B20; // "private void Unavailable(LocalizedString invalidNotification, PersonalNotificationActionIds id)"
            inline constexpr std::uintptr_t OpenBench = 0xC022B0; // "private void OpenBench()"
        }
    } // namespace CarBenchTargetActions

    namespace CarBenchTargetProvider { // "Game.Battle.EntityModel.VehicleBench.CarBenchTargetProvider (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t settlementHelperModel = 0x20; // "ISettlementHelperModel"
            inline constexpr std::uintptr_t worldEntitiesModel = 0x28; // "WorldEntitiesModel"
            inline constexpr std::uintptr_t targetActions = 0x30; // "CarBenchTargetActions"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x38; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t battleModel = 0x40; // "BattleModel"
            inline constexpr std::uintptr_t entityId = 0x48; // "int"
            inline constexpr std::uintptr_t localizationKeys = 0x50; // "LocalizationKeys"
            inline constexpr std::uintptr_t carSlots = 0x58; // "ReadOnly.List<IPlotCarModel>"
            inline constexpr std::uintptr_t summonVisibleDistanceSqr = 0x60; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t FillTargetActions = 0xC02CD0; // "protected internal override void FillTargetActions(List<ITargetAction> actions)"
            inline constexpr std::uintptr_t HasAnyVehicle = 0xC03410; // "private bool HasAnyVehicle()"
            inline constexpr std::uintptr_t CanSummonAny = 0xC02BF0; // "private bool CanSummonAny(long publicId)"
        }
    } // namespace CarBenchTargetProvider

    namespace CarBenchView { // "Game.Battle.EntityModel.VehicleBench.CarBenchView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t MarkerRoot = 0x20; // "Transform"
            inline constexpr std::uintptr_t Collider = 0x28; // "Collider"
            inline constexpr std::uintptr_t TargetObjectView = 0x30; // "TargetObjectView"
        }
    } // namespace CarBenchView

    namespace CarBonnetToTrunkCollisionDescription { // "Models.References.Car.CarBonnetToTrunkCollisionDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t CanTurnAnotherCarWheels = 0x20; // "bool"
            inline constexpr std::uintptr_t WheelsCanBeTurned = 0x21; // "bool"
        }
    } // namespace CarBonnetToTrunkCollisionDescription

    namespace CarBurnoutDescription { // "Models.References.Car.CarBurnoutDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t BurnoutStartMaxLinearVelocity = 0x20; // "float"
            inline constexpr std::uintptr_t BurnoutStartMaxAngularVelocity = 0x24; // "float"
            inline constexpr std::uintptr_t BurnoutMaxLinearVelocity = 0x28; // "float"
            inline constexpr std::uintptr_t BurnoutMaxAngularVelocity = 0x2C; // "float"
            inline constexpr std::uintptr_t BurnoutStartMaxLinearVelocitySqr = 0x30; // "float"
            inline constexpr std::uintptr_t BurnoutStartMaxAngularVelocitySqr = 0x34; // "float"
            inline constexpr std::uintptr_t BurnoutMaxLinearVelocitySqr = 0x38; // "float"
            inline constexpr std::uintptr_t BurnoutMaxAngularVelocitySqr = 0x3C; // "float"
            inline constexpr std::uintptr_t TorqueAcceleration = 0x40; // "float"
            inline constexpr std::uintptr_t RotationAxisPairFrictionStiffness = 0x44; // "float"
            inline constexpr std::uintptr_t OuterFrictionStiffness = 0x48; // "float"
        }
    } // namespace CarBurnoutDescription

    namespace CarBurnoutExtensions { // "Models.Utils.Extensions.Vehicles.Car.CarBurnoutExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t GetRotationAxisWheelIndex = 0x39521F0; // "public static int GetRotationAxisWheelIndex(float steeringAngle, CarDescription description)"
            inline constexpr std::uintptr_t GetRotationAxisPairWheelIndex = 0x39521E0; // "public static int GetRotationAxisPairWheelIndex(int rotationAxisWheelIndex)"
            inline constexpr std::uintptr_t IsRotationAxisOnForwardWheels = 0x3952250; // "public static bool IsRotationAxisOnForwardWheels(int rotationAxisWheelIndex)"
        }
    } // namespace CarBurnoutExtensions

    namespace CarBurnoutInputModel { // "Models.Models.CarBurnoutInput.CarBurnoutInputModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Value = 0x10; // "bool"
        }
    } // namespace CarBurnoutInputModel

    namespace CarBurnoutInputUpdater { // "Game.Battle.Inputs.CarBurnoutInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t carBurnoutInputModel = 0x10; // "InputModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x18; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t battleInputModel = 0x20; // "BattleInputModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA73230; // "public void Update()"
        }
    } // namespace CarBurnoutInputUpdater

    namespace CarBurnoutSettingsModel { // "Models.Models.CarBurnoutSettings.CarBurnoutSettingsModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t burnoutDescription = 0x10; // "CarBurnoutDescription"
            inline constexpr std::uintptr_t overrideModel = 0x18; // "CarBurnoutSettingsOverrideModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_BurnoutStartMaxLinearVelocity = 0x498B900; // "public float get_BurnoutStartMaxLinearVelocity()"
            inline constexpr std::uintptr_t get_BurnoutStartMaxAngularVelocity = 0x498B700; // "public float get_BurnoutStartMaxAngularVelocity()"
            inline constexpr std::uintptr_t get_BurnoutMaxLinearVelocity = 0x498B500; // "public float get_BurnoutMaxLinearVelocity()"
            inline constexpr std::uintptr_t get_BurnoutMaxAngularVelocity = 0x498B300; // "public float get_BurnoutMaxAngularVelocity()"
            inline constexpr std::uintptr_t get_BurnoutStartMaxLinearVelocitySqr = 0x498B7D0; // "public float get_BurnoutStartMaxLinearVelocitySqr()"
            inline constexpr std::uintptr_t get_BurnoutStartMaxAngularVelocitySqr = 0x498B5D0; // "public float get_BurnoutStartMaxAngularVelocitySqr()"
            inline constexpr std::uintptr_t get_BurnoutMaxLinearVelocitySqr = 0x498B3D0; // "public float get_BurnoutMaxLinearVelocitySqr()"
            inline constexpr std::uintptr_t get_BurnoutMaxAngularVelocitySqr = 0x498B1D0; // "public float get_BurnoutMaxAngularVelocitySqr()"
            inline constexpr std::uintptr_t get_TorqueAcceleration = 0x498BB70; // "public float get_TorqueAcceleration()"
            inline constexpr std::uintptr_t get_RotationAxisPairFrictionStiffness = 0x498BAA0; // "public float get_RotationAxisPairFrictionStiffness()"
            inline constexpr std::uintptr_t get_OuterFrictionStiffness = 0x498B9D0; // "public float get_OuterFrictionStiffness()"
        }
    } // namespace CarBurnoutSettingsModel

    namespace CarBurnoutSettingsOverrideData { // "Models.Data.SettingsOverride.Cars.CarBurnoutSettingsOverrideData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t OverrideEnabled = 0x20; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t BurnoutStartMaxLinearVelocity = 0x28; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t BurnoutStartMaxAngularVelocity = 0x30; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t BurnoutMaxLinearVelocity = 0x38; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t BurnoutMaxAngularVelocity = 0x40; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t TorqueAcceleration = 0x48; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t RotationAxisPairFrictionStiffness = 0x50; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t OuterFrictionStiffness = 0x58; // "IPrimitiveData<float>"
        }
    } // namespace CarBurnoutSettingsOverrideData

    namespace CarBurnoutSettingsOverrideModel { // "Models.Models.CarBurnoutSettingsOverride.CarBurnoutSettingsOverrideModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "CarBurnoutSettingsOverrideData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_OverrideEnabled = 0x498C280; // "public bool get_OverrideEnabled()"
            inline constexpr std::uintptr_t get_BurnoutStartMaxLinearVelocity = 0x498C1E0; // "public float get_BurnoutStartMaxLinearVelocity()"
            inline constexpr std::uintptr_t get_BurnoutStartMaxAngularVelocity = 0x498C0F0; // "public float get_BurnoutStartMaxAngularVelocity()"
            inline constexpr std::uintptr_t get_BurnoutMaxLinearVelocity = 0x498C000; // "public float get_BurnoutMaxLinearVelocity()"
            inline constexpr std::uintptr_t get_BurnoutMaxAngularVelocity = 0x498BF10; // "public float get_BurnoutMaxAngularVelocity()"
            inline constexpr std::uintptr_t get_BurnoutStartMaxLinearVelocitySqr = 0x498C140; // "public float get_BurnoutStartMaxLinearVelocitySqr()"
            inline constexpr std::uintptr_t get_BurnoutStartMaxAngularVelocitySqr = 0x498C050; // "public float get_BurnoutStartMaxAngularVelocitySqr()"
            inline constexpr std::uintptr_t get_BurnoutMaxLinearVelocitySqr = 0x498BF60; // "public float get_BurnoutMaxLinearVelocitySqr()"
            inline constexpr std::uintptr_t get_BurnoutMaxAngularVelocitySqr = 0x498BE70; // "public float get_BurnoutMaxAngularVelocitySqr()"
            inline constexpr std::uintptr_t get_TorqueAcceleration = 0x498C320; // "public float get_TorqueAcceleration()"
            inline constexpr std::uintptr_t get_RotationAxisPairFrictionStiffness = 0x498C2D0; // "public float get_RotationAxisPairFrictionStiffness()"
            inline constexpr std::uintptr_t get_OuterFrictionStiffness = 0x498C230; // "public float get_OuterFrictionStiffness()"
            inline constexpr std::uintptr_t SetOverrideData = 0x498BC40; // "public void SetOverrideData(float burnoutStartMaxLinearVelocity, float burnoutStartMaxAngularVelocity, float burnoutMaxLinearVelocity, float burnoutMaxAngularVelocity, float torqueAcceleration, float rotationAxisPairFrictionStiffness, float outerFrictionStiffness)"
        }
    } // namespace CarBurnoutSettingsOverrideModel

    namespace CarBurnoutTickDataModel { // "Models.Models.TickDataModels.Car.CarBurnoutTickDataModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsBurnout = 0x10; // "bool"
            inline constexpr std::uintptr_t RotationAxisWheelIndex = 0x14; // "int"
            inline constexpr std::uintptr_t RotationAxisPairWheelIndex = 0x18; // "int"
        }
    } // namespace CarBurnoutTickDataModel

    namespace CarBurnoutTouchInputUpdater { // "Game.Battle.Inputs.CarBurnoutTouchInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t carControlView = 0x10; // "CarControlView"
            inline constexpr std::uintptr_t carBurnoutInputModel = 0x18; // "InputModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA733D0; // "public void Update()"
        }
    } // namespace CarBurnoutTouchInputUpdater

    namespace CarCameraAccelerationEffectUpdater { // "Game.Battle.Entities.Car.CarCameraAccelerationEffectUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t cameraFollow = 0x10; // "Cinemachine3rdPersonFollow"
            inline constexpr std::uintptr_t carCamera = 0x18; // "CinemachineVirtualCamera"
            inline constexpr std::uintptr_t stateModel = 0x20; // "IBattleCharacterStateModel"
            inline constexpr std::uintptr_t inVehicleModel = 0x28; // "InVehicleModel"
            inline constexpr std::uintptr_t vehiclesModel = 0x30; // "VehiclesClientModel"
            inline constexpr std::uintptr_t carViewDescriptions = 0x38; // "CarViewDescriptions"
            inline constexpr std::uintptr_t playerEntityModel = 0x40; // "PlayerEntityModel"
            inline constexpr std::uintptr_t startDistance = 0x48; // "float"
            inline constexpr std::uintptr_t minFov = 0x4C; // "float"
            inline constexpr std::uintptr_t minHand = 0x50; // "float"
            inline constexpr std::uintptr_t cameraOutOfCarDistanceDecreaseSpeed = 0x54; // "float"
            inline constexpr std::uintptr_t cameraOutOfCarFovDecreaseSpeed = 0x58; // "float"
            inline constexpr std::uintptr_t cameraOutOfCarHandDecreaseSpeed = 0x5C; // "float"
            inline constexpr std::uintptr_t carCameraView = 0x60; // "CarCameraView"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB74D10; // "public void Update()"
        }
    } // namespace CarCameraAccelerationEffectUpdater

    namespace CarCameraAccelerationWeightSpeedUpdater { // "Game.Battle.Entities.Car.CarCameraAccelerationWeightSpeedUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t cameraFollow = 0x10; // "Cinemachine3rdPersonFollow"
            inline constexpr std::uintptr_t stateModel = 0x18; // "IBattleCharacterStateModel"
            inline constexpr std::uintptr_t inVehicleModel = 0x20; // "InVehicleModel"
            inline constexpr std::uintptr_t vehiclesModel = 0x28; // "VehiclesClientModel"
            inline constexpr std::uintptr_t carViewDescriptions = 0x30; // "CarViewDescriptions"
            inline constexpr std::uintptr_t playerClientModel = 0x38; // "PlayerClientModel"
            inline constexpr std::uintptr_t carCameraView = 0x40; // "CarCameraView"
            inline constexpr std::uintptr_t speed = 0x48; // "float"
            inline constexpr std::uintptr_t weight = 0x4C; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB752F0; // "public void Update()"
        }
    } // namespace CarCameraAccelerationWeightSpeedUpdater

    namespace CarCameraNoiseEffectUpdater { // "Game.Battle.Entities.Car.CarCameraNoiseEffectUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t cameraMultiChannelPerlin = 0x10; // "CinemachineBasicMultiChannelPerlin"
            inline constexpr std::uintptr_t stateModel = 0x18; // "IBattleCharacterStateModel"
            inline constexpr std::uintptr_t inVehicleModel = 0x20; // "InVehicleModel"
            inline constexpr std::uintptr_t vehiclesModel = 0x28; // "VehiclesClientModel"
            inline constexpr std::uintptr_t carViewDescriptions = 0x30; // "CarViewDescriptions"
            inline constexpr std::uintptr_t playerCameraTypeModel = 0x38; // "PlayerCameraTypeModel"
            inline constexpr std::uintptr_t grenadeViewDescriptions = 0x40; // "GrenadeViewDescriptions"
            inline constexpr std::uintptr_t playerCameraViewDescriptions = 0x48; // "PlayerCameraViewDescriptions"
            inline constexpr std::uintptr_t grenadeCameraShakingModel = 0x50; // "GrenadeCameraShakingModel"
            inline constexpr std::uintptr_t carLandingCameraShakeModel = 0x58; // "CarLandingCameraShakeModel"
            inline constexpr std::uintptr_t playerClientModel = 0x60; // "PlayerClientModel"
            inline constexpr std::uintptr_t cameraOutOfNoiseAmplitudeGain = 0x68; // "float"
            inline constexpr std::uintptr_t cameraOutOfNoiseFrequencyGain = 0x6C; // "float"
            inline constexpr std::uintptr_t minNoiseAmplitudeGain = 0x70; // "float"
            inline constexpr std::uintptr_t minNoiseFrequencyGain = 0x74; // "float"
            inline constexpr std::uintptr_t speed = 0x78; // "float"
            inline constexpr std::uintptr_t defaultNoise = 0x80; // "NoiseSettings"
            inline constexpr std::uintptr_t explosionNoise = 0x88; // "NoiseSettings"
            inline constexpr std::uintptr_t landingNoise = 0x90; // "NoiseSettings"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB75B60; // "public void Update()"
            inline constexpr std::uintptr_t TakeCameraPerlin = 0xB75760; // "private void TakeCameraPerlin(out float amplitudeGain, out float frequencyGain, out NoiseSettings noiseSettings)"
        }
    } // namespace CarCameraNoiseEffectUpdater

    namespace CarCameraSettings { // "Game.Battle.Car.CarCameraSettings (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t HasShake = 0x10; // "bool"
            inline constexpr std::uintptr_t HasSpring = 0x11; // "bool"
            inline constexpr std::uintptr_t StiffnessCurve = 0x18; // "AnimationCurve"
            inline constexpr std::uintptr_t SpringFading = 0x20; // "float"
            inline constexpr std::uintptr_t SpringsStartImpulseMultiply = 0x24; // "float"
            inline constexpr std::uintptr_t SpringVerticalMultiplier = 0x28; // "float"
        }
    } // namespace CarCameraSettings

    namespace CarCameraSpringUpdater { // "Game.Battle.Entities.Car.CarSpring.CarCameraSpringUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleEntitiesModel = 0x10; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t vehiclesCollisionsModel = 0x18; // "IVehiclesCollisionsModel"
            inline constexpr std::uintptr_t carLandingCameraShakeModel = 0x20; // "CarLandingCameraShakeModel"
            inline constexpr std::uintptr_t playerEntityModel = 0x28; // "PlayerEntityModel"
            inline constexpr std::uintptr_t carViewDescriptions = 0x30; // "CarViewDescriptions"
            inline constexpr std::uintptr_t springTarget = 0x38; // "Transform"
            inline constexpr std::uintptr_t target = 0x40; // "Transform"
            inline constexpr std::uintptr_t inertia = 0x48; // "Vector3"
            inline constexpr std::uintptr_t cameraSettings = 0x58; // "CarCameraSettings"
            inline constexpr std::uintptr_t lastVelocity = 0x60; // "Nullable<Vector3>"
            inline constexpr std::uintptr_t isCarOnGround = 0x70; // "bool"
            inline constexpr std::uintptr_t lastSpeed = 0x74; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xBAA230; // "public void Update()"
            inline constexpr std::uintptr_t UpdateInertia = 0xBA9A00; // "private void UpdateInertia()"
            inline constexpr std::uintptr_t TryGetCollisionNormal = 0xBA96C0; // "private bool TryGetCollisionNormal(CarEntityModel carEntityModel, out Vector3 collisionNormal)"
            inline constexpr std::uintptr_t GetDeltaInertia = 0xBA9510; // "private Vector3 GetDeltaInertia()"
        }
    } // namespace CarCameraSpringUpdater

    namespace CarCameraView { // "Game.Battle.Cars.CarCameraView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Camera = 0x20; // "CinemachineVirtualCamera"
            inline constexpr std::uintptr_t Base = 0x28; // "CameraSettingsView"
            inline constexpr std::uintptr_t Noise = 0x30; // "CameraSettingsView"
            inline constexpr std::uintptr_t DebugEnableCameraAccelerationEffectUpdater = 0x38; // "bool"
            inline constexpr std::uintptr_t DebugEnableCameraAccelerationWeightSpeedUpdater = 0x39; // "bool"
        }
    } // namespace CarCameraView

    namespace CarCargoInventoryModel { // "Models.Models.CargoInventory.CarCargoInventoryModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t startSlotsCount = 0x18; // "int"
            inline constexpr std::uintptr_t additionalSlotsCount = 0x20; // "IPrimitiveModel<int>"
            inline constexpr std::uintptr_t MaxSlotsCount = 0x28; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_SlotsCount = 0x4966D70; // "public override int get_SlotsCount()"
        }
    } // namespace CarCargoInventoryModel

    namespace CarClientData { // "Game.Battle.Entities.Car.Models.CarClientData (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t wheels = 0x10; // "CarWheelClientData[]"
            inline constexpr std::uintptr_t PhysicsData = 0x18; // "VehiclePhysicsDataModel"
            inline constexpr std::uintptr_t DriveInput = 0x20; // "CarDriveInputModel"
            inline constexpr std::uintptr_t HandBrakeInput = 0x28; // "CarHandBrakeInputModel"
            inline constexpr std::uintptr_t BurnoutInput = 0x30; // "CarBurnoutInputModel"
            inline constexpr std::uintptr_t SteeringAngle = 0x38; // "float"
            inline constexpr std::uintptr_t FlWheel = 0x40; // "CarWheelClientData"
            inline constexpr std::uintptr_t FrWheel = 0x48; // "CarWheelClientData"
            inline constexpr std::uintptr_t BlWheel = 0x50; // "CarWheelClientData"
            inline constexpr std::uintptr_t BrWheel = 0x58; // "CarWheelClientData"
            inline constexpr std::uintptr_t IsBurnout = 0x60; // "bool"
            inline constexpr std::uintptr_t IsWarped = 0x61; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t GetWheel = 0xBAA730; // "public CarWheelClientData GetWheel(int index)"
        }
    } // namespace CarClientData

    namespace CarClientDataUpdater { // "Game.Battle.Entities.Car.CarClientDataUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t serverModel = 0x10; // "CarModel"
            inline constexpr std::uintptr_t clientData = 0x18; // "CarClientData"
            inline constexpr std::uintptr_t deadReckoningModel = 0x20; // "EntityDeadReckoningModel"
            inline constexpr std::uintptr_t timeOffsetModel = 0x28; // "TimelineTimeOffsetModel"
            inline constexpr std::uintptr_t time = 0x30; // "TimeModel"
            inline constexpr std::uintptr_t dataModel = 0x38; // "IDataModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB76840; // "public void Update()"
            inline constexpr std::uintptr_t UpdatePhysicsDataFromDeadReckoning = 0xB68D00; // "private void UpdatePhysicsDataFromDeadReckoning(VehiclePhysicsDataModel physicsDataModel, VehicleTransformModel serverTransformModel, EntityDeadReckoningModel deadReckoningModel)"
            inline constexpr std::uintptr_t UpdatePhysicsDataFromTimeline = 0xB68F60; // "private void UpdatePhysicsDataFromTimeline(VehiclePhysicsDataModel physicsDataModel, VehicleTransformModel serverTransformModel, in CarTimelineSubTickData timelineSubTickData)"
            inline constexpr std::uintptr_t UpdatePhysicsDataFromServer = 0xB68E00; // "private void UpdatePhysicsDataFromServer(VehiclePhysicsDataModel physicsDataModel, VehicleTransformModel serverTransformModel, VelocityModel serverLinearVelocity, VelocityModel serverAngularVelocity)"
            inline constexpr std::uintptr_t UpdatePhysicsData = 0xB69040; // "private void UpdatePhysicsData(VehiclePhysicsDataModel physicsDataModel, VehicleTransformModel serverTransformModel, in Vector3 centerOfMassPosition, in Quaternion centerOfMassOrientation, in Vector3 linearVelocity, in Vector3 angularVelocity)"
            inline constexpr std::uintptr_t UpdateInputDataFromServer = 0xB75F20; // "private void UpdateInputDataFromServer(CarDescription description, CarDriveInputModel driveInput, CarHandBrakeInputModel handBrakeInput, CarBurnoutInputModel burnoutInput, VehiclePhysicsDataModel physicsDataModel, IPrimitiveModel<CarMoveInputDescription> serverMoveInput, IPrimitiveModel<bool> serverHandBrake)"
            inline constexpr std::uintptr_t UpdateSteeringFromTimeline = 0xB76100; // "private void UpdateSteeringFromTimeline(CarClientData clientData, in CarTimelineTickData timelineTickData)"
            inline constexpr std::uintptr_t UpdateSteeringFromServer = 0xB760D0; // "private void UpdateSteeringFromServer(CarClientData clientData, CarSteeringModel steering)"
            inline constexpr std::uintptr_t UpdateBurnoutFromTimeline = 0xB75EE0; // "private void UpdateBurnoutFromTimeline(CarClientData clientData, in CarTimelineTickData timelineTickData)"
            inline constexpr std::uintptr_t UpdateBurnoutFromServer = 0xB75E80; // "private void UpdateBurnoutFromServer(CarClientData clientData, IPrimitiveModel<bool> burnout)"
            inline constexpr std::uintptr_t UpdateBurnout = 0xB75F00; // "private void UpdateBurnout(CarClientData clientData, bool isBurnout)"
            inline constexpr std::uintptr_t UpdateWheelsStateFromTimeline = 0xB765F0; // "private void UpdateWheelsStateFromTimeline(CarClientData clientData, in CarTimelineTickData timelineTickData, ICarWheelsModel serverWheels)"
            inline constexpr std::uintptr_t UpdateWheelsStateFromServer = 0xB764E0; // "private void UpdateWheelsStateFromServer(CarClientData clientData, ICarWheelsModel serverWheels)"
            inline constexpr std::uintptr_t UpdateWheelStateFromTimeline = 0xB76470; // "private void UpdateWheelStateFromTimeline(CarWheelClientData clientData, in CarWheelTimelineTickData timelineTickData, VehicleWheelDescription wheelDescription)"
            inline constexpr std::uintptr_t UpdateWheelStateFromServer = 0xB761C0; // "private void UpdateWheelStateFromServer(CarWheelClientData clientData, ICarWheelModel serverWheel)"
            inline constexpr std::uintptr_t UpdateWarpedStateFromTimeline = 0xB76180; // "private void UpdateWarpedStateFromTimeline(CarClientData clientData, in CarTimelineTickData timelineTickData)"
            inline constexpr std::uintptr_t UpdateWarpedStateFromServer = 0xB76120; // "private void UpdateWarpedStateFromServer(CarClientData clientData, IPrimitiveModel<bool> isWarped)"
            inline constexpr std::uintptr_t UpdateWarpedState = 0xB761A0; // "private void UpdateWarpedState(CarClientData clientData, bool isWarped)"
        }
    } // namespace CarClientDataUpdater

    namespace CarClientModel { // "Game.Battle.EntityModel.Car.CarClientModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t serverModel = 0x48; // "CarModel"
            inline constexpr std::uintptr_t ClientData = 0x50; // "CarClientData"
            inline constexpr std::uintptr_t IsPlayerInsideCar = 0x58; // "bool"
            inline constexpr std::uintptr_t ForwardAxle = 0x60; // "CarAxleClientModel"
            inline constexpr std::uintptr_t BackwardAxle = 0x68; // "CarAxleClientModel"
            inline constexpr std::uintptr_t CarEngineModel = 0x70; // "CarEngineModel"
            inline constexpr std::uintptr_t Speed = 0x78; // "float"
            inline constexpr std::uintptr_t PreviousPosition = 0x7C; // "Vector3"
            inline constexpr std::uintptr_t PreviousPositionTs = 0x88; // "long"
            inline constexpr std::uintptr_t Velocity = 0x90; // "Vector3"
            inline constexpr std::uintptr_t WheelsModel = 0xA0; // "CarWheelsModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t IsCarOnGroundByServerData = 0xC9A140; // "public bool IsCarOnGroundByServerData()"
            inline constexpr std::uintptr_t IsCarOnGroundByClientData = 0xC9A090; // "public bool IsCarOnGroundByClientData()"
            inline constexpr std::uintptr_t get_Id = 0xC9A3E0; // "public int get_Id()"
            inline constexpr std::uintptr_t get_Description = 0xC9A3C0; // "public CarDescription get_Description()"
            inline constexpr std::uintptr_t get_IsSirenModelEnabled = 0xC9A400; // "public bool get_IsSirenModelEnabled()"
        }
    } // namespace CarClientModel

    namespace CarConfig { // "Models.References.Car.Settings.CarConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t SuspensionLimitAllowedPenetration = 0x10; // "float"
            inline constexpr std::uintptr_t SuspensionLimitErrorCorrection = 0x14; // "float"
            inline constexpr std::uintptr_t SuspensionLimitRestitution = 0x18; // "float"
            inline constexpr std::uintptr_t MaxAngleFromWheelsToGroundSurfaceInDegree = 0x1C; // "float"
            inline constexpr std::uintptr_t LargeSlopeGroundSurfaceAngleInDegree = 0x20; // "float"
            inline constexpr std::uintptr_t MaxAngleFromWheelsToGroundSurfaceCos = 0x24; // "float"
            inline constexpr std::uintptr_t LargeSlopeGroundSurfaceAngleCos = 0x28; // "float"
            inline constexpr std::uintptr_t TakeLargeSlopeAsGround = 0x2C; // "bool"
            inline constexpr std::uintptr_t DisableSirenDelay = 0x30; // "long"
            inline constexpr std::uintptr_t EnvironmentCollisionVerticalFrictionVerticalDotLimit = 0x38; // "float"
            inline constexpr std::uintptr_t EnvironmentCollisionEdgesFrictionVerticalDotSoftLimit = 0x3C; // "float"
            inline constexpr std::uintptr_t EnvironmentCollisionEdgesFrictionVerticalDotHardLimit = 0x40; // "float"
            inline constexpr std::uintptr_t EnvironmentCollisionEdgesFrictionHorizontalDotSoftLimit = 0x44; // "float"
            inline constexpr std::uintptr_t EnvironmentCollisionEdgesFrictionHorizontalDotHardLimit = 0x48; // "float"
            inline constexpr std::uintptr_t EnvironmentCollisionFlipFrictionVerticalDotLimit = 0x4C; // "float"
            inline constexpr std::uintptr_t WheelsFrictionStiffnessModifiersBySurfaceType = 0x50; // "IReadOnlyDictionary<byte, float>"
            inline constexpr std::uintptr_t DeathFromWaterOffsetY = 0x58; // "float"
        }
    } // namespace CarConfig

    namespace CarControllerApplyCarInputByDriverSystem { // "Models.Systems.CarControllerApplyCarInputByDriverSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsSceneModel = 0x38; // "PhysicsSceneModel"
            inline constexpr std::uintptr_t battleCharacters = 0x40; // "ReadOnly.Dictionary<int, BattleCharacterModel>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x3F7C0D0; // "protected override void Tick(ITick tick)"
            inline constexpr std::uintptr_t ResolveDriverAtLookRearviewMirror = 0x3F7BF40; // "private static void ResolveDriverAtLookRearviewMirror(VelocityModel linearVelocity, VehicleTransformModel transform, CarMoveInputDescription moveInput, CarDriveInputModel driveInput, long now)"
        }
    } // namespace CarControllerApplyCarInputByDriverSystem

    namespace CarControllerApplyCarInputByEmptySystem { // "Models.Systems.CarControllerApplyCarInputByEmptySystem (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x3F7C7E0; // "protected override void Tick(ITick tick)"
        }
    } // namespace CarControllerApplyCarInputByEmptySystem

    namespace CarControllerApplyCarInputByParkingSystem { // "Models.Systems.CarControllerApplyCarInputByParkingSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsSceneModel = 0x38; // "PhysicsSceneModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x3F7CA80; // "protected override void Tick(ITick tick)"
        }
    } // namespace CarControllerApplyCarInputByParkingSystem

    namespace CarControllerApplyCarInputByPartialPredictionSystem { // "Models.Systems.CarControllerApplyCarInputByPartialPredictionSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsSceneModel = 0x38; // "PhysicsSceneModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x3F7CFD0; // "protected override void Tick(ITick tick)"
            inline constexpr std::uintptr_t ApplyParkingInput = 0x3F7CF80; // "private void ApplyParkingInput(CarDriveInputModel driveInput, float linearVelocityAlongZ)"
            inline constexpr std::uintptr_t ApplyDriverLastInput = 0x3F7CEC0; // "private void ApplyDriverLastInput(CarDescription carDescription, CarDriveInputModel driveInput, IPrimitiveModel<CarMoveInputDescription> carMoveInput, CarHandBrakeInputModel handBrakeInput, IPrimitiveModel<bool> handBrake, CarBurnoutInputModel burnoutInput, float linearVelocityAlongZ)"
        }
    } // namespace CarControllerApplyCarInputByPartialPredictionSystem

    namespace CarControllerApplyCarInputExtensions { // "Models.Utils.Extensions.Vehicles.Car.CarControllerApplyCarInputExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t ConvertDriverInputToCarMoveInput = 0x39522C0; // "public static CarMoveInputDescription ConvertDriverInputToCarMoveInput(float zDriverInput, bool burnoutDriverInput, bool isEngineSpeedEnoughForHandling)"
            inline constexpr std::uintptr_t ConvertDriverInputToCarSteeringInput = 0x3952460; // "public static ValueTuple<bool, bool> ConvertDriverInputToCarSteeringInput(float xDriverInput, bool isForceSteering, bool isForceSteeringToLeft)"
            inline constexpr std::uintptr_t ConvertParkingInputToCarMoveInput = 0x39524F0; // "public static CarMoveInputDescription ConvertParkingInputToCarMoveInput(bool isBrakeForward, bool isBrakeBackward)"
            inline constexpr std::uintptr_t SetCarInputByDriverInputFromData = 0x3952650; // "public static void SetCarInputByDriverInputFromData(CarMoveInputDescription carMoveInputValue, bool handBrakeDriverInput, CarDescription carDescription, float linearVelocityAlongZ, CarDriveInputModel driveInput, CarHandBrakeInputModel handBrakeInput, CarBurnoutInputModel burnoutInput)"
            inline constexpr std::uintptr_t ClearCarMoveInput = 0x3952260; // "public static void ClearCarMoveInput(CarDriveInputModel driveInput, CarHandBrakeInputModel handBrakeInput, CarBurnoutInputModel burnoutInput)"
            inline constexpr std::uintptr_t ClearCarSteeringInput = 0x39522A0; // "public static void ClearCarSteeringInput(CarSteeringInputModel steeringInput)"
        }
    } // namespace CarControllerApplyCarInputExtensions

    namespace CarControllerApplyFrictionSystem { // "Models.Systems.CarControllerApplyFrictionSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsSceneModel = 0x38; // "PhysicsSceneModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x3F7D4B0; // "protected override void Tick(ITick tick)"
        }
    } // namespace CarControllerApplyFrictionSystem

    namespace CarControllerBlockedFrictionSystem { // "Models.Systems.CarControllerBlockedFrictionSystem (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x3F7D7C0; // "protected override void Tick(ITick tick)"
        }
    } // namespace CarControllerBlockedFrictionSystem

    namespace CarControllerBurnoutFrictionSystem { // "Models.Systems.CarControllerBurnoutFrictionSystem (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x3F7DBA0; // "protected override void Tick(ITick tick)"
        }
    } // namespace CarControllerBurnoutFrictionSystem

    namespace CarControllerBurnoutSystem { // "Models.Systems.CarControllerBurnoutSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsSceneModel = 0x38; // "PhysicsSceneModel"
            inline constexpr std::uintptr_t wheelsGroundTickData = 0x40; // "VehicleWheelGroundTickDataModel[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x3F7E890; // "protected override void Tick(ITick tick)"
            inline constexpr std::uintptr_t EnableBurnoutState = 0x3F7E220; // "private void EnableBurnoutState(IPrimitiveModel<bool> burnout, CarBurnoutTickDataModel burnoutTickData, bool isPartialPrediction, int rotationAxisWheelIndex, int rotationAxisPairWheelIndex)"
            inline constexpr std::uintptr_t DisableBurnoutState = 0x3F7E1A0; // "private void DisableBurnoutState(IPrimitiveModel<bool> burnout, CarBurnoutTickDataModel burnoutTickData, bool isPartialPrediction)"
            inline constexpr std::uintptr_t SetBurnoutState = 0x3F7E800; // "private void SetBurnoutState(IPrimitiveModel<bool> burnout, CarBurnoutTickDataModel burnoutTickData, bool isPartialPrediction, bool value, int rotationAxisWheelIndex, int rotationAxisPairWheelIndex)"
            inline constexpr std::uintptr_t GetWheelsGroundTickData = 0x3F7E470; // "private ReadOnlySpan<VehicleWheelGroundTickDataModel> GetWheelsGroundTickData(ValueTuple<VehicleWheelGroundTickDataModel, CarWheelBurnoutStateTickDataModel, VehicleWheelLinkTickDataModel>[] wheels)"
            inline constexpr std::uintptr_t IsCarAvailableToBurnout = 0x3F7E600; // "private bool IsCarAvailableToBurnout(ref RigidBodyData body, CarBurnoutSettingsModel burnoutSettings, CarBurnoutTickDataModel burnoutTickData, ReadOnlySpan<VehicleWheelGroundTickDataModel> wheelsGroundTickData)"
            inline constexpr std::uintptr_t IsCarVelocitiesAvailableToBurnout = 0x3F7E710; // "private bool IsCarVelocitiesAvailableToBurnout(ref RigidBodyData body, CarBurnoutSettingsModel burnoutSettings, CarBurnoutTickDataModel burnoutTickData)"
            inline constexpr std::uintptr_t GetCollisionMod = 0x3F7E2A0; // "private float GetCollisionMod(PhysicsBodyId bodyId, Span<float> bodyTransformMatrix, float steeringAngle, int rotationAxisWheelIndex)"
        }
    } // namespace CarControllerBurnoutSystem

    namespace CarControllerCalculateSlipParamsSystem { // "Models.Systems.CarControllerCalculateSlipParamsSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsDebugEnabledModel = 0x38; // "PhysicsDebugEnabledModel"
            inline constexpr std::uintptr_t physicsDebugModel = 0x40; // "IPhysicsDebugModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x3F7F360; // "protected override void Tick(ITick tick)"
            inline constexpr std::uintptr_t CalculateDefaultSlipRatio = 0x3F7F160; // "private void CalculateDefaultSlipRatio(int wheelIndex, CarWheelFrictionTickDataModel wheelFrictionTickData, CarTireFrictionSettingsModel tireFrictionSettings, PhysicsDebugCarWheelTickData physicsDebugWheel, CarBurnoutTickDataModel burnoutTickData, out float slipRatio, out int slipRatioSign)"
            inline constexpr std::uintptr_t CalculateDefaultSlipAngle = 0x3F7F100; // "private void CalculateDefaultSlipAngle(CarWheelFrictionTickDataModel wheelFrictionTickData, out float slipAngle, out int slipAngleSign)"
            inline constexpr std::uintptr_t CalculateSleepingSlipRatio = 0x3F7F280; // "private void CalculateSleepingSlipRatio(int wheelIndex, CarTireFrictionSettingsModel tireFrictionSettings, PhysicsDebugCarWheelTickData physicsDebugWheel, CarBurnoutTickDataModel burnoutTickData, out float slipRatio, out int slipRatioSign)"
            inline constexpr std::uintptr_t CalculateSleepingSlipAngle = 0x3F7F0C0; // "private void CalculateSleepingSlipAngle(out float slipAngle, out int slipAngleSign)"
            inline constexpr std::uintptr_t CalculateAirSlipRatio = 0x3F7F0D0; // "private void CalculateAirSlipRatio(PhysicsDebugCarWheelTickData physicsDebugWheel, out float slipRatio, out int slipRatioSign)"
            inline constexpr std::uintptr_t CalculateAirSlipAngle = 0x3F7F0C0; // "private void CalculateAirSlipAngle(out float slipAngle, out int slipAngleSign)"
        }
    } // namespace CarControllerCalculateSlipParamsSystem

    namespace CarControllerClearInputSystem { // "Models.Systems.CarControllerClearInputSystem (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x3F7F930; // "protected override void Tick(ITick tick)"
        }
    } // namespace CarControllerClearInputSystem

    namespace CarControllerCombinedFrictionSystem { // "Models.Systems.CarControllerCombinedFrictionSystem (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x3F7FC20; // "protected override void Tick(ITick tick)"
            inline constexpr std::uintptr_t CalculateLongitudinalFrictionForce = 0x3F7FAF0; // "private ValueTuple<float, float> CalculateLongitudinalFrictionForce(VehicleWheelGroundTickDataModel wheelGroundTickData, VehicleWheelLoadTickDataModel wheelLoadTickData, CarWheelFrictionTickDataModel wheelFrictionTickData)"
            inline constexpr std::uintptr_t CalculateLateralFrictionForce = 0x3F7F9F0; // "private ValueTuple<float, float> CalculateLateralFrictionForce(VehicleWheelGroundTickDataModel wheelGroundTickData, VehicleWheelLoadTickDataModel wheelLoadTickData, CarWheelFrictionTickDataModel wheelFrictionTickData)"
            inline constexpr std::uintptr_t ClampForce = 0x3F7FBF0; // "private float ClampForce(float force, float maxForce)"
        }
    } // namespace CarControllerCombinedFrictionSystem

    namespace CarControllerControlOwnerSystem { // "Models.Systems.CarControllerControlOwnerSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleCharacters = 0x38; // "ReadOnly.Dictionary<int, BattleCharacterModel>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x3F80040; // "protected override void Tick(ITick tick)"
        }
    } // namespace CarControllerControlOwnerSystem

    namespace CarControllerDirtLevelSystem { // "Models.Systems.CarControllerDirtLevelSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dirtyingLevelSettings = 0x38; // "DirtyingLevelSettings"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x3F801D0; // "protected override void Tick(ITick tick)"
        }
    } // namespace CarControllerDirtLevelSystem

    namespace CarControllerDownForceSystem { // "Models.Systems.CarControllerDownForceSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsSceneModel = 0x38; // "PhysicsSceneModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x3F805E0; // "protected override void Tick(ITick tick)"
        }
    } // namespace CarControllerDownForceSystem

    namespace CarControllerDragSystem { // "Models.Systems.CarControllerDragSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsSceneModel = 0x38; // "PhysicsSceneModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x3F80950; // "protected override void Tick(ITick tick)"
        }
    } // namespace CarControllerDragSystem

    namespace CarControllerFlipSystem { // "Models.Systems.CarControllerFlipSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsSceneModel = 0x38; // "PhysicsSceneModel"
            inline constexpr std::uintptr_t tickDeltaTime = 0x40; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x3F80E90; // "protected override void Tick(ITick tick)"
            inline constexpr std::uintptr_t IsCarAvailableForFlip = 0x3F80C80; // "private bool IsCarAvailableForFlip(ref RigidBodyData body, VehicleWheelGroundTickDataModel[] wheels, CarDescription carDescription)"
            inline constexpr std::uintptr_t IsCarVelocitiesAvailableForFlip = 0x3F80DB0; // "private bool IsCarVelocitiesAvailableForFlip(ref RigidBodyData body, CarDescription carDescription)"
        }
    } // namespace CarControllerFlipSystem

    namespace CarControllerGroundedStateExtensions { // "Models.Utils.Extensions.Vehicles.Car.CarControllerGroundedStateExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t IsCarGroundedWithNormalSlope = 0x3952A00; // "public static bool IsCarGroundedWithNormalSlope(ReadOnlySpan<VehicleWheelGroundTickDataModel> wheels)"
            inline constexpr std::uintptr_t IsAtLeastOneWheelTouchGroundWithNormalSlope = 0x3952980; // "public static bool IsAtLeastOneWheelTouchGroundWithNormalSlope(ReadOnlySpan<VehicleWheelGroundTickDataModel> wheels)"
        }
    } // namespace CarControllerGroundedStateExtensions

    namespace CarControllerMovementStateSystem { // "Models.Systems.CarControllerMovementStateSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsSceneModel = 0x38; // "PhysicsSceneModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x3F81CC0; // "protected override void Tick(ITick tick)"
            inline constexpr std::uintptr_t BuildLogForNotFiniteLinearVelocityAlongZ = 0x3F814A0; // "private static string BuildLogForNotFiniteLinearVelocityAlongZ(CarDescription carDescription, Span<float> transformMatrix, in RigidBodyData body, float linearVelocityAlongZ)"
            inline constexpr std::uintptr_t GetSignedMaxLinearVelocityAlongZ = 0x3F81C70; // "private float GetSignedMaxLinearVelocityAlongZ(CarDriveInputModel driveInput, float linearVelocityAlongZ, float forwardMaxVelocity, float backwardMaxVelocity)"
            inline constexpr std::uintptr_t GetMaxLinearVelocityAlongZ = 0x3F81C60; // "private float GetMaxLinearVelocityAlongZ(float linearVelocityAlongZ, float forwardMaxVelocity, float backwardMaxVelocity)"
        }
    } // namespace CarControllerMovementStateSystem

    namespace CarControllerPreparePhysicsForSubTickSystem { // "Models.Systems.CarControllerPreparePhysicsForSubTickSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsSceneModel = 0x38; // "PhysicsSceneModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x3F82550; // "protected override void Tick(ITick tick)"
            inline constexpr std::uintptr_t CalculateLinksDirection = 0x3F82350; // "private void CalculateLinksDirection(Span<float> transformMatrix, VehicleLinksTickDataModel linksTickData)"
            inline constexpr std::uintptr_t CalculateWheelLink = 0x3F823C0; // "private void CalculateWheelLink(VehicleWheelDescription wheelDescription, Span<float> transformMatrix, VehicleWheelLinkTickDataModel wheelLinkTickData)"
        }
    } // namespace CarControllerPreparePhysicsForSubTickSystem

    namespace CarControllerPreparePhysicsForTickSystem { // "Models.Systems.CarControllerPreparePhysicsForTickSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsSceneModel = 0x38; // "PhysicsSceneModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x3F830C0; // "protected override void Tick(ITick tick)"
            inline constexpr std::uintptr_t CalculateGroundSearchCastLength = 0x3F82A30; // "private float CalculateGroundSearchCastLength(VehicleSuspensionSettingsModel suspensionSettings)"
            inline constexpr std::uintptr_t CalculateLinksDirection = 0x3F82350; // "private void CalculateLinksDirection(Span<float> transformMatrix, VehicleLinksTickDataModel linksTickData)"
            inline constexpr std::uintptr_t SetWheelParams = 0x3F82E60; // "private void SetWheelParams(VehicleWheelDescription wheelDescription, CarDescription description, CarTireFrictionSettingsModel tireFrictionSettings, CarUpgradesSettingsModel upgradesSettings, CarUpgradesSlotsModel upgradesSlots, VehicleWheelLoadTickDataModel wheelLoadTickData, VehicleWheelSuspensionLimitTickDataModel wheelSuspensionLimitTickData, VehicleWheelGroundTickDataModel wheelGroundTickData, CarWheelFrictionTickDataModel wheelFrictionTickData)"
            inline constexpr std::uintptr_t CalculateWheelLink = 0x3F823C0; // "private void CalculateWheelLink(VehicleWheelDescription wheelDescription, Span<float> transformMatrix, VehicleWheelLinkTickDataModel wheelLinkTickData)"
            inline constexpr std::uintptr_t CalculateWheelsBoundingBoxAABB = 0x3F82AB0; // "private void CalculateWheelsBoundingBoxAABB(VehicleLinksTickDataModel vehicleLinksTickData, Span<float> transformMatrix, CarDescription description, float groundSearchCastLength)"
        }
    } // namespace CarControllerPreparePhysicsForTickSystem

    namespace CarControllerStuckSurfaceSystem { // "Models.Systems.CarControllerStuckSurfaceSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsSceneModel = 0x38; // "PhysicsSceneModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x3F83F20; // "protected override void Tick(ITick tick)"
            inline constexpr std::uintptr_t StuckInSurfaceStateHandle = 0x3F83CF0; // "private void StuckInSurfaceStateHandle(ref RigidBodyData body, IPrimitiveModel<bool> isStuckInSurfaceModel, CarStateTickDataModel carStateTickData, VehicleWheelGroundTickDataModel[] wheels, bool isPartialPrediction)"
            inline constexpr std::uintptr_t NotStuckInSurfaceStateHandle = 0x3F83A70; // "private void NotStuckInSurfaceStateHandle(ref RigidBodyData body, IPrimitiveModel<bool> isStuckInSurfaceModel, CarStateTickDataModel carStateTickData, VehicleWheelGroundTickDataModel[] wheels, bool isPartialPrediction)"
            inline constexpr std::uintptr_t IsAtLeastOneWheelTouchGroundWithStuckSurfaceType = 0x3F837F0; // "private bool IsAtLeastOneWheelTouchGroundWithStuckSurfaceType(VehicleWheelGroundTickDataModel[] wheels)"
            inline constexpr std::uintptr_t SlowDownByStuckSurface = 0x3F83B80; // "private void SlowDownByStuckSurface(ref RigidBodyData body)"
            inline constexpr std::uintptr_t LimitVelocityByStuckSurface = 0x3F838C0; // "private void LimitVelocityByStuckSurface(ref RigidBodyData body)"
            inline constexpr std::uintptr_t ChangeStuckInSurfaceState = 0x3F83760; // "private void ChangeStuckInSurfaceState(IPrimitiveModel<bool> isStuckInSurfaceModel, CarStateTickDataModel carStateTickData, bool isPartialPrediction, bool value)"
        }
    } // namespace CarControllerStuckSurfaceSystem

    namespace CarControllerTransmissionSystem { // "Models.Systems.CarControllerTransmissionSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsSceneModel = 0x38; // "PhysicsSceneModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x3F84450; // "protected override void Tick(ITick tick)"
            inline constexpr std::uintptr_t GetTransmissionCommand = 0x3F84080; // "private CarControllerTransmissionSystem.TransmissionCommand GetTransmissionCommand(long now, PhysicsBodyId bodyId, CarDriveInputModel driveInput, CarHandling handling, CarTransmissionModel transmission, CarTransmissionSettingsModel transmissionSettings, CarUpgradesSettingsModel upgradesSettings, CarUpgradesSlotsModel upgradesSlots)"
            inline constexpr std::uintptr_t StartShiftGearProcess = 0x3F84420; // "private void StartShiftGearProcess(long now, CarTransmissionModel transmission)"
            inline constexpr std::uintptr_t ShiftGearProcess = 0x3F84380; // "private void ShiftGearProcess(long now, PhysicsBodyId bodyId, CarDriveInputModel driveInput, CarHandling handling, CarTransmissionModel transmission, CarTransmissionSettingsModel transmissionSettings)"
            inline constexpr std::uintptr_t ShiftGearAction = 0x3F84240; // "private void ShiftGearAction(PhysicsBodyId bodyId, CarDriveInputModel driveInput, CarHandling handling, CarTransmissionModel transmission, CarTransmissionSettingsModel transmissionSettings)"
        }
    } // namespace CarControllerTransmissionSystem

    namespace CarControllerWheelApplyInputSystem { // "Models.Systems.CarControllerWheelApplyInputSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsSceneModel = 0x38; // "PhysicsSceneModel"
            inline constexpr std::uintptr_t tickDeltaTime = 0x40; // "float"
            inline constexpr std::uintptr_t physicsDebugEnabledModel = 0x48; // "PhysicsDebugEnabledModel"
            inline constexpr std::uintptr_t physicsDebugModel = 0x50; // "IPhysicsDebugModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x3F84B00; // "protected override void Tick(ITick tick)"
            inline constexpr std::uintptr_t CalculateSignedAcceleration = 0x3F84940; // "private float CalculateSignedAcceleration(CarStateTickDataModel carStateTickData, CarDriveInputModel driveInput, CarTransmissionSettingsModel transmissionSettings, CarTransmissionModel transmission, CarUpgradesSettingsModel upgradesSettings, CarUpgradesSlotsModel upgradesSlotsModel)"
            inline constexpr std::uintptr_t CalculateSignedBrake = 0x3F84AA0; // "private float CalculateSignedBrake(CarDriveInputModel driveInput, CarTransmissionSettingsModel transmissionSettings)"
            inline constexpr std::uintptr_t CalculateAirResistanceAcceleration = 0x3F84790; // "private float CalculateAirResistanceAcceleration(PhysicsBodyId bodyId, CarDriveInputModel driveInput, CarStateTickDataModel carStateTickData, CarHandling handling, CarTransmissionModel transmission)"
            inline constexpr std::uintptr_t AddAcceleration = 0x3F846B0; // "private float AddAcceleration(float oldFakeAngularLinearVelocity, float signedAcceleration)"
            inline constexpr std::uintptr_t AddBrake = 0x3F846C0; // "private float AddBrake(float oldFakeAngularLinearVelocity, float signedBrake)"
        }
    } // namespace CarControllerWheelApplyInputSystem

    namespace CarControllerWheelFrictionMaxPossibleForcesSystem { // "Models.Systems.CarControllerWheelFrictionMaxPossibleForcesSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsDebugEnabledModel = 0x38; // "PhysicsDebugEnabledModel"
            inline constexpr std::uintptr_t physicsDebugModel = 0x40; // "IPhysicsDebugModel"
            inline constexpr std::uintptr_t invDt = 0x48; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x3F853A0; // "protected override void Tick(ITick tick)"
        }
    } // namespace CarControllerWheelFrictionMaxPossibleForcesSystem

    namespace CarControllerWheelFrictionSlipVelocitiesSystem { // "Models.Systems.CarControllerWheelFrictionSlipVelocitiesSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsDebugEnabledModel = 0x38; // "PhysicsDebugEnabledModel"
            inline constexpr std::uintptr_t physicsDebugModel = 0x40; // "IPhysicsDebugModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x3F85670; // "protected override void Tick(ITick tick)"
        }
    } // namespace CarControllerWheelFrictionSlipVelocitiesSystem

    namespace CarControllerWheelGroundCheckSystem { // "Models.Systems.CarControllerWheelGroundCheckSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsDebugModel = 0x70; // "IPhysicsDebugModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t DebugLogGroundFound = 0x3F85900; // "protected override void DebugLogGroundFound(int entityId, int wheelIndex, VehicleWheelGroundTickDataModel wheelGroundTickData)"
            inline constexpr std::uintptr_t DebugLogGroundNotFound = 0x3F859C0; // "protected override void DebugLogGroundNotFound(int entityId, int wheelIndex)"
        }
    } // namespace CarControllerWheelGroundCheckSystem

    namespace CarControllerWheelMovementDataSystem { // "Models.Systems.CarControllerWheelMovementDataSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsSceneModel = 0x38; // "PhysicsSceneModel"
            inline constexpr std::uintptr_t physicsDebugEnabledModel = 0x40; // "PhysicsDebugEnabledModel"
            inline constexpr std::uintptr_t physicsDebugModel = 0x48; // "IPhysicsDebugModel"
            inline constexpr std::uintptr_t floatData = 0x50; // "float[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x3F85BE0; // "protected override void Tick(ITick tick)"
            inline constexpr std::uintptr_t CalculateWheelSteeringAngleForWheel = 0x3F85A90; // "private float CalculateWheelSteeringAngleForWheel(float carSteeringAngle, bool isForwardWheel, bool isLeftWheel, CarDescription carDescription)"
        }
    } // namespace CarControllerWheelMovementDataSystem

    namespace CarControllerWheelSuspensionSystem { // "Models.Systems.CarControllerWheelSuspensionSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsDebugModel = 0x60; // "IPhysicsDebugModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t DebugLogSuspension = 0x3F867E0; // "protected override void DebugLogSuspension(int entityId, int wheelIndex, float springContactDepth, float springContactSpeed, float contactDepth, float contactSpeed, float stiffness, float damper, float linkVelocityAlongSuspensionDirection, float idleForce, float stiffnessForce, float damperForce, float suspensionTotalForce)"
            inline constexpr std::uintptr_t DebugLogSpringLength = 0x3F86730; // "protected override void DebugLogSpringLength(int entityId, int wheelIndex, float springLengthFromData, float springLengthCalculated)"
        }
    } // namespace CarControllerWheelSuspensionSystem

    namespace CarControlOwnerDescription { // "Models.References.Car.CarControlOwnerDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x817DBD0; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t Empty = 0x0; // "CarControlOwnerDescription"
            inline constexpr std::uintptr_t Driver = 0x8; // "CarControlOwnerDescription"
            inline constexpr std::uintptr_t Parking = 0x10; // "CarControlOwnerDescription"
        }
    } // namespace CarControlOwnerDescription

    namespace CarControlOwnerModel { // "Models.Models.CarControlOwner.CarControlOwnerModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t OwnerType = 0x10; // "CarControlOwnerDescription"
            inline constexpr std::uintptr_t Driver = 0x18; // "BattleCharacterModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetEmpty = 0x498C420; // "public void SetEmpty()"
            inline constexpr std::uintptr_t SetDriver = 0x498C370; // "public void SetDriver(BattleCharacterModel driver)"
            inline constexpr std::uintptr_t SetParkingSystem = 0x498C4D0; // "public void SetParkingSystem()"
        }
    } // namespace CarControlOwnerModel

    namespace CarData { // "Models.Data.Car.CarData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Description = 0x20; // "CarDescription"
            inline constexpr std::uintptr_t ParkingOverTs = 0x28; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t Position = 0x30; // "IPrimitiveData<Vector3>"
            inline constexpr std::uintptr_t Orientation = 0x38; // "IPrimitiveData<Vector4>"
            inline constexpr std::uintptr_t LinearVelocity = 0x40; // "IPrimitiveData<Vector3>"
            inline constexpr std::uintptr_t AngularVelocity = 0x48; // "IPrimitiveData<Vector3>"
            inline constexpr std::uintptr_t FlWheel = 0x50; // "CarWheelData"
            inline constexpr std::uintptr_t FrWheel = 0x58; // "CarWheelData"
            inline constexpr std::uintptr_t BlWheel = 0x60; // "CarWheelData"
            inline constexpr std::uintptr_t BrWheel = 0x68; // "CarWheelData"
            inline constexpr std::uintptr_t Seats = 0x70; // "ReferenceMapData<VehicleSeatSlotDescription, VehicleSeatData>"
            inline constexpr std::uintptr_t Steering = 0x78; // "CarSteeringData"
            inline constexpr std::uintptr_t HandBrake = 0x80; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t Burnout = 0x88; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t MoveInput = 0x90; // "IPrimitiveData<CarMoveInputDescription>"
            inline constexpr std::uintptr_t Transmission = 0x98; // "CarTransmissionData"
            inline constexpr std::uintptr_t IsTrunkOpened = 0xA0; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t IsHoodOpened = 0xA8; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t IsWarped = 0xB0; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t IsSirenEnabled = 0xB8; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t IsStuckInSurface = 0xC0; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t HasFreeCargoSlot = 0xC8; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t IsHornEnabled = 0xD0; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t HasCargo = 0xD8; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t IsAvailableToFlip = 0xE0; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t EngineStateChangeOverTs = 0xE8; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t EngineActive = 0xF0; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t IsDrowned = 0xF8; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t WaterState = 0x100; // "IPrimitiveData<VehicleWaterStateDescription>"
            inline constexpr std::uintptr_t IsUnowned = 0x108; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t OwnerPublicId = 0x110; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t OwnerRole = 0x118; // "IPrimitiveData<PlayerRoleDescription>"
            inline constexpr std::uintptr_t RadioStation = 0x120; // "IPrimitiveData<RadioStationDescription>"
            inline constexpr std::uintptr_t DirtLevel = 0x128; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t ClanBattleTeamOwner = 0x130; // "IPrimitiveData<ClanBattleTeamDescription>"
            inline constexpr std::uintptr_t SleepCounter = 0x138; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t TrunkBreachData = 0x140; // "BreachEntityData"
            inline constexpr std::uintptr_t UpgradesSlots = 0x148; // "CarUpgradesSlotsData"
            inline constexpr std::uintptr_t IsRented = 0x150; // "IPrimitiveData<bool>"
        }
    } // namespace CarData

    namespace CarDescription { // "Models.References.Car.CarDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t SeatsFunc = 0x20; // "Func<VehicleSeatsDescription>"
            inline constexpr std::uintptr_t CollidersDescriptionFunc = 0x28; // "Func<VehicleCollidersDescription>"
            inline constexpr std::uintptr_t SteeringFunc = 0x30; // "Func<CarSteeringDescription>"
            inline constexpr std::uintptr_t TireFrictionFunc = 0x38; // "Func<CarTireFrictionDescription>"
            inline constexpr std::uintptr_t SuspensionFunc = 0x40; // "Func<VehicleSuspensionDescription>"
            inline constexpr std::uintptr_t TransmissionFunc = 0x48; // "Func<CarTransmissionDescription>"
            inline constexpr std::uintptr_t InteractFunc = 0x50; // "Func<VehicleInteractDescription>"
            inline constexpr std::uintptr_t CarSlotFunc = 0x58; // "Func<CarSlotDescription>"
            inline constexpr std::uintptr_t PhysicsDragFunc = 0x60; // "Func<CarPhysicsDragDescription>"
            inline constexpr std::uintptr_t PhysicsDescriptionFunc = 0x68; // "Func<CarPhysicsDescription>"
            inline constexpr std::uintptr_t BonnetToTrunkCollisionDescriptionFunc = 0x70; // "Func<CarBonnetToTrunkCollisionDescription>"
            inline constexpr std::uintptr_t WheelsBaseDescriptionFunc = 0x78; // "Func<CarWheelsBaseDescription>"
            inline constexpr std::uintptr_t HandlingDescriptionFunc = 0x80; // "Func<CarHandlingDescription>"
            inline constexpr std::uintptr_t InteractionPointsDescriptionFunc = 0x88; // "Func<CarInteractionPointsDescription>"
            inline constexpr std::uintptr_t BurnoutFunc = 0x90; // "Func<CarBurnoutDescription>"
            inline constexpr std::uintptr_t UpgradesFunc = 0x98; // "Func<CarUpgradesDescription>"
            inline constexpr std::uintptr_t DrownPointsFunc = 0xA0; // "Func<VehicleDrownPointsDescription>"
            inline constexpr std::uintptr_t EngineFunc = 0xA8; // "Func<VehicleEngineDescription>"
            inline constexpr std::uintptr_t PoliceCarTrunkFunc = 0xB0; // "Func<PoliceCarTrunkDescription>"
            inline constexpr std::uintptr_t AvailableOnStart = 0xB8; // "bool"
            inline constexpr std::uintptr_t CryptoCoinsPrice = 0xBC; // "int"
            inline constexpr std::uintptr_t CompensationCryptoCoins = 0xC0; // "int"
            inline constexpr std::uintptr_t ImprisonmentYearsRequired = 0xC4; // "int"
            inline constexpr std::uintptr_t GroupType = 0xC8; // "VehicleGroupType"
            inline constexpr std::uintptr_t IsHidden = 0xC9; // "bool"
            inline constexpr std::uintptr_t physics = 0xD0; // "CarPhysics"
            inline constexpr std::uintptr_t handling = 0xD8; // "CarHandling"
            inline constexpr std::uintptr_t wheels = 0xE0; // "CarWheels"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_InteractionPointsDescription = 0x43E8A80; // "public CarInteractionPointsDescription get_InteractionPointsDescription()"
            inline constexpr std::uintptr_t get_CarSlot = 0x4048FB0; // "public CarSlotDescription get_CarSlot()"
            inline constexpr std::uintptr_t get_PoliceCarTrunk = 0x4067270; // "public PoliceCarTrunkDescription get_PoliceCarTrunk()"
            inline constexpr std::uintptr_t get_BonnetToTrunkCollisionDescription = 0x4048F80; // "public CarBonnetToTrunkCollisionDescription get_BonnetToTrunkCollisionDescription()"
            inline constexpr std::uintptr_t get_HasSkinPrice = 0x447BBA0; // "public bool get_HasSkinPrice()"
            inline constexpr std::uintptr_t get_BuyParams = 0x447BA10; // "public ValueTuple<int, int> get_BuyParams()"
            inline constexpr std::uintptr_t get_HasTrunk = 0x447BBB0; // "public bool get_HasTrunk()"
            inline constexpr std::uintptr_t get_HasUpgradesSlots = 0x447BC40; // "public bool get_HasUpgradesSlots()"
            inline constexpr std::uintptr_t get_HasSiren = 0x447BA70; // "public bool get_HasSiren()"
            inline constexpr std::uintptr_t get_CanRefillCopAmmo = 0x447BA70; // "public bool get_CanRefillCopAmmo()"
            inline constexpr std::uintptr_t get_CanTurnAnotherCarWheelsInBonnetToTrunkCollision = 0x447BA80; // "public bool get_CanTurnAnotherCarWheelsInBonnetToTrunkCollision()"
            inline constexpr std::uintptr_t get_WheelsCanBeTurnedInBonnetToTrunkCollision = 0x447BFE0; // "public bool get_WheelsCanBeTurnedInBonnetToTrunkCollision()"
            inline constexpr std::uintptr_t get_Suspension = 0x4048E60; // "public VehicleSuspensionDescription get_Suspension()"
            inline constexpr std::uintptr_t get_TireFriction = 0x2AA0B60; // "public CarTireFrictionDescription get_TireFriction()"
            inline constexpr std::uintptr_t get_Steering = 0x9AA5D0; // "public CarSteeringDescription get_Steering()"
            inline constexpr std::uintptr_t get_Transmission = 0x4048E90; // "public CarTransmissionDescription get_Transmission()"
            inline constexpr std::uintptr_t get_PhysicsDrag = 0x4048EC0; // "public CarPhysicsDragDescription get_PhysicsDrag()"
            inline constexpr std::uintptr_t get_Burnout = 0x440E2B0; // "public CarBurnoutDescription get_Burnout()"
            inline constexpr std::uintptr_t get_Upgrades = 0x4067080; // "public CarUpgradesDescription get_Upgrades()"
            inline constexpr std::uintptr_t get_Engine = 0x4067190; // "public VehicleEngineDescription get_Engine()"
            inline constexpr std::uintptr_t get_DrownPoints = 0x40671C0; // "public VehicleDrownPointsDescription get_DrownPoints()"
            inline constexpr std::uintptr_t get_SeatsType = 0x447BE50; // "public VehicleSeatTypeDescription get_SeatsType()"
            inline constexpr std::uintptr_t get_Seats = 0x447BE80; // "public ReadOnly.Dictionary<VehicleSeatSlotDescription, VehicleSeatDescription> get_Seats()"
            inline constexpr std::uintptr_t get_DriverSlot = 0x447BAB0; // "public VehicleSeatSlotDescription get_DriverSlot()"
            inline constexpr std::uintptr_t get_Interact = 0x1CE7810; // "public VehicleInteractDescription get_Interact()"
            inline constexpr std::uintptr_t get_InteractDescription = 0x447BD00; // "public InteractDescription get_InteractDescription()"
            inline constexpr std::uintptr_t get_TrunkLocalPosition = 0x447BF00; // "public Vector3 get_TrunkLocalPosition()"
            inline constexpr std::uintptr_t get_TrunkInteractDescription = 0x447BEC0; // "public InteractDescription get_TrunkInteractDescription()"
            inline constexpr std::uintptr_t get_HoodLocalPosition = 0x447BCB0; // "public Vector3 get_HoodLocalPosition()"
            inline constexpr std::uintptr_t get_HoodInteractDescription = 0x447BC70; // "public InteractDescription get_HoodInteractDescription()"
            inline constexpr std::uintptr_t get_UndercarriageLocalPosition = 0x447BF90; // "public Vector3 get_UndercarriageLocalPosition()"
            inline constexpr std::uintptr_t get_UndercarriageInteractDescription = 0x447BF50; // "public InteractDescription get_UndercarriageInteractDescription()"
            inline constexpr std::uintptr_t get_Physics = 0x447BD50; // "public CarPhysics get_Physics()"
            inline constexpr std::uintptr_t get_Handling = 0x447BAF0; // "public CarHandling get_Handling()"
            inline constexpr std::uintptr_t get_Wheels = 0x447C010; // "public CarWheels get_Wheels()"
        }
    } // namespace CarDescription

    namespace CarDestroyModel { // "Models.Models.CarDestroy.CarDestroyModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "CarModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Destroy = 0x498C580; // "public void Destroy(PhysicsSceneModel physicsSceneModel, WorldEntitiesModel worldEntitiesModel, PhysicsBodiesModel physicsBodiesModel)"
        }
    } // namespace CarDestroyModel

    namespace CarDriveInputModel { // "Models.Models.CarDriveInput.CarDriveInputModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsAccelerationForward = 0x10; // "bool"
            inline constexpr std::uintptr_t IsAccelerationBackward = 0x11; // "bool"
            inline constexpr std::uintptr_t IsAcceleration = 0x12; // "bool"
            inline constexpr std::uintptr_t IsBrakeForward = 0x13; // "bool"
            inline constexpr std::uintptr_t IsBrakeBackward = 0x14; // "bool"
            inline constexpr std::uintptr_t IsBrake = 0x15; // "bool"
            inline constexpr std::uintptr_t IsNoInputZ = 0x16; // "bool"
            inline constexpr std::uintptr_t CarDriverLookAtRearviewMirror = 0x17; // "bool"
            inline constexpr std::uintptr_t CarDriverLookCurrentStateEndTs = 0x18; // "long"
        }
    } // namespace CarDriveInputModel

    namespace CarDriverLookAtRearviewMirrorModelUpdater { // "Game.Battle.Entities.Car.CarDriverLookAtRearviewMirrorModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t driveInputModel = 0x18; // "CarDriveInputModel"
            inline constexpr std::uintptr_t carTransformModel = 0x20; // "VehicleTransformModel"
            inline constexpr std::uintptr_t velocityModel = 0x28; // "VelocityModel"
            inline constexpr std::uintptr_t carInput = 0x30; // "IPrimitiveModel<CarMoveInputDescription>"
            inline constexpr std::uintptr_t now = 0x38; // "INow"
        }
        namespace Methods {
            inline constexpr std::uintptr_t InnerUpdate = 0xB8BDB0; // "protected override void InnerUpdate()"
            inline constexpr std::uintptr_t InnerStart = 0x7B3360; // "protected override void InnerStart()"
            inline constexpr std::uintptr_t InnerStop = 0x7B3360; // "protected override void InnerStop()"
        }
    } // namespace CarDriverLookAtRearviewMirrorModelUpdater

    namespace CarDriverSexUpdater { // "Game.Battle.Entities.Car.Updaters.CarDriverSexUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t view = 0x10; // "CarEntityView"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x18; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t carSeatsModel = 0x20; // "VehicleSeatsModel"
            inline constexpr std::uintptr_t isMale = 0x28; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xBAAD40; // "public void Update()"
            inline constexpr std::uintptr_t IsDriverMaleOrEmpty = 0xBAAAF0; // "private bool IsDriverMaleOrEmpty()"
        }
    } // namespace CarDriverSexUpdater

    namespace CarEngineConfigViewDescription { // "Game.Battle.Car.CarEngineConfigViewDescription (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t SlippingRpmCurve = 0x10; // "AnimationCurve"
            inline constexpr std::uintptr_t AdditiveRpmForMaxVelocityCurve = 0x18; // "AnimationCurve"
            inline constexpr std::uintptr_t CutoffAdditiveRpmCurve = 0x20; // "AnimationCurve"
            inline constexpr std::uintptr_t CutoffThreshold = 0x28; // "int"
            inline constexpr std::uintptr_t RpmByGearConvertCurve = 0x30; // "AnimationCurve[]"
            inline constexpr std::uintptr_t fakeGearShiftsByRpm = 0x38; // "List<float>[]"
            inline constexpr std::uintptr_t fakeGearShiftsByMaxVelocity = 0x40; // "List<float>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t FillListWithFakeGearShiftsByCurve = 0xABDE20; // "private static void FillListWithFakeGearShiftsByCurve(List<float> list, AnimationCurve curve)"
            inline constexpr std::uintptr_t HasFakeGearShift = 0xABE030; // "public bool HasFakeGearShift(int gear, float fromRpm, float toRpm)"
            inline constexpr std::uintptr_t HasFakeGearShift_2 = 0xABE1B0; // "public bool HasFakeGearShift(float fromTimePastFromMaxSpeed, float toTimePastFromMaxSpeed)"
        }
    } // namespace CarEngineConfigViewDescription

    namespace CarEngineConfigWithECOViewDescription { // "Game.Battle.Car.CarEngineConfigWithECOViewDescription (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Identified = 0x48; // "IdentifiedProperty<EcuCarUpgradeDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Id = 0xABE530; // "public string get_Id()"
        }
    } // namespace CarEngineConfigWithECOViewDescription

    namespace CarEngineModel { // "Game.Battle.EntityModel.Car.CarEngineModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsOn = 0x10; // "bool"
            inline constexpr std::uintptr_t StartEngineTs = 0x18; // "long"
            inline constexpr std::uintptr_t FinishStartingEngineTs = 0x20; // "long"
            inline constexpr std::uintptr_t CurrentGear = 0x28; // "int"
            inline constexpr std::uintptr_t GearShift = 0x2C; // "bool"
            inline constexpr std::uintptr_t RPM = 0x30; // "int"
            inline constexpr std::uintptr_t RoundSpeed = 0x34; // "int"
            inline constexpr std::uintptr_t Speed = 0x38; // "float"
            inline constexpr std::uintptr_t Power = 0x3C; // "float"
            inline constexpr std::uintptr_t HandBreak = 0x40; // "int"
            inline constexpr std::uintptr_t TimePastFromMaxSpeed = 0x44; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsHandBreak = 0xC9BC40; // "public bool get_IsHandBreak()"
            inline constexpr std::uintptr_t get_IsForward = 0xC9BC20; // "public bool get_IsForward()"
            inline constexpr std::uintptr_t get_IsBackward = 0xC9BC00; // "public bool get_IsBackward()"
        }
    } // namespace CarEngineModel

    namespace CarEngineModelUpdater { // "Game.Battle.EntityModel.Car.CarEngineModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t car = 0x10; // "CarModel"
            inline constexpr std::uintptr_t viewDescriptions = 0x18; // "CarViewDescriptions"
            inline constexpr std::uintptr_t carViewDescription = 0x20; // "CarViewDescription"
            inline constexpr std::uintptr_t carClientModel = 0x28; // "CarClientModel"
            inline constexpr std::uintptr_t now = 0x30; // "INow"
            inline constexpr std::uintptr_t carSeatsModel = 0x38; // "VehicleSeatsModel"
            inline constexpr std::uintptr_t gearIndex = 0x40; // "int"
            inline constexpr std::uintptr_t isHandBreakUsed = 0x44; // "bool"
            inline constexpr std::uintptr_t ts = 0x48; // "long"
            inline constexpr std::uintptr_t cutoffTs = 0x50; // "long"
            inline constexpr std::uintptr_t isGearShiftInProcess = 0x58; // "bool"
            inline constexpr std::uintptr_t currentGear = 0x5C; // "int"
            inline constexpr std::uintptr_t hasDriver = 0x60; // "bool"
            inline constexpr std::uintptr_t turnOffStartTs = 0x68; // "long"
            inline constexpr std::uintptr_t turnOffEndTs = 0x70; // "long"
            inline constexpr std::uintptr_t turnOffRpm = 0x78; // "int"
            inline constexpr std::uintptr_t lastTimePastFromMaxSpeed = 0x7C; // "float"
            inline constexpr std::uintptr_t lastWheelRpm = 0x80; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC9AC30; // "public void Update()"
            inline constexpr std::uintptr_t IsTurnOffInProcess = 0xC9A820; // "private bool IsTurnOffInProcess()"
            inline constexpr std::uintptr_t StopTurnOff = 0xC9A930; // "private void StopTurnOff()"
            inline constexpr std::uintptr_t StartTurnOff = 0xC9A830; // "private void StartTurnOff()"
            inline constexpr std::uintptr_t TurnOffFakeRpm = 0xC9A940; // "private int TurnOffFakeRpm()"
            inline constexpr std::uintptr_t GetAdditiveRpmForMaxVelocity = 0xC9A4B0; // "private int GetAdditiveRpmForMaxVelocity(float timePastFromMaxSpeed, int rpm)"
            inline constexpr std::uintptr_t GetRpmWithCutoff = 0xC9A590; // "private int GetRpmWithCutoff(int rpm)"
            inline constexpr std::uintptr_t UpdateTimePastFromMaxSpeed = 0xC9AA20; // "private void UpdateTimePastFromMaxSpeed(float speed)"
        }
    } // namespace CarEngineModelUpdater

    namespace CarEngineRulesModel { // "Models.Models.VehicleEngineRules.CarEngineRulesModel (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t IsEngineShouldBeActiveBySpecialRules = 0x7D5050; // "protected override bool IsEngineShouldBeActiveBySpecialRules()"
        }
    } // namespace CarEngineRulesModel

    namespace CarEngineViewDescription { // "Game.Battle.Car.CarEngineViewDescription (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t default_id = 0x28; // "CarEngineConfigViewDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t GetEngineConfig = 0xABE6D0; // "public CarEngineConfigViewDescription GetEngineConfig(EcuCarUpgradeDescription ecu)"
            inline constexpr std::uintptr_t AfterDeserialize = 0xABE570; // "protected override void AfterDeserialize()"
        }
    } // namespace CarEngineViewDescription

    namespace CarEntityDataBuilder { // "Models.Replication.EntityDataBuilder.CarEntityDataBuilder (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t paramsModel = 0x10; // "EntitiesParamsModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Build = 0x44B4D10; // "public IData Build(int id)"
        }
    } // namespace CarEntityDataBuilder

    namespace CarEntityModel { // "Game.Battle.EntityModel.Car.CarEntityModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ServerModel = 0x18; // "CarModel"
            inline constexpr std::uintptr_t ClientModel = 0x20; // "CarClientModel"
        }
    } // namespace CarEntityModel

    namespace CarEntityModelUpdater { // "Game.Battle.EntityModel.Car.CarEntityModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t updater = 0x10; // "IUpdater"
            inline constexpr std::uintptr_t carSlidingSpeedUpdater = 0x18; // "IUpdater"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC9BC50; // "public void Update()"
        }
    } // namespace CarEntityModelUpdater

    namespace CarEntitySkinViewUpdater { // "Game.Battle.Entities.Car.CarEntitySkinViewUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t entityModel = 0x10; // "CarEntityModel"
            inline constexpr std::uintptr_t globalModel = 0x18; // "GlobalModel"
            inline constexpr std::uintptr_t battleModel = 0x20; // "BattleModel"
            inline constexpr std::uintptr_t globalScreenContent = 0x28; // "GlobalScreenContent"
            inline constexpr std::uintptr_t battleScreenContent = 0x30; // "BattleScreenContent"
            inline constexpr std::uintptr_t locationScreenViewModel = 0x38; // "LocationScreenViewModel"
            inline constexpr std::uintptr_t targetSubsystem = 0x40; // "ITargetSubsystem"
            inline constexpr std::uintptr_t carEntityViews = 0x48; // "Dictionary<int, CarEntityView>"
            inline constexpr std::uintptr_t vehicleCollidersViews = 0x50; // "Dictionary<int, VehicleEntityView>"
            inline constexpr std::uintptr_t carViewDescription = 0x58; // "CarViewDescription"
            inline constexpr std::uintptr_t registerDisposable = 0x60; // "IRegisterDisposable"
            inline constexpr std::uintptr_t vehiclesLoadingModel = 0x68; // "ScopesLoadingModel"
            inline constexpr std::uintptr_t viewUpdater = 0x70; // "IUpdater"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB8C570; // "public void Update()"
            inline constexpr std::uintptr_t CreateCar = 0xB8C130; // "private void CreateCar()"
        }
    } // namespace CarEntitySkinViewUpdater

    namespace CarEntityStreamReader { // "Models.Replication.EntityStreamReader.CarEntityStreamReader (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t paramsModel = 0x20; // "EntitiesParamsModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t TryReadParams = 0x44B4E10; // "protected override bool TryReadParams(int entityId, IBinaryReadStream stream)"
        }
    } // namespace CarEntityStreamReader

    namespace CarEntityTrunkEntityDataBuilder { // "Models.Replication.EntityDataBuilder.CarEntityTrunkEntityDataBuilder (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t paramsModel = 0x10; // "EntitiesParamsModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Build = 0x44B4F10; // "public IData Build(int id)"
        }
    } // namespace CarEntityTrunkEntityDataBuilder

    namespace CarEntityView { // "Game.Battle.Entities.Car.CarEntityView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t VehicleEntity = 0x20; // "VehicleEntityView"
            inline constexpr std::uintptr_t transform = 0x28; // "Transform"
            inline constexpr std::uintptr_t flWheel = 0x30; // "Transform"
            inline constexpr std::uintptr_t frWheel = 0x38; // "Transform"
            inline constexpr std::uintptr_t blWheel = 0x40; // "Transform"
            inline constexpr std::uintptr_t brWheel = 0x48; // "Transform"
            inline constexpr std::uintptr_t flWheelBrakeSupport = 0x50; // "Transform"
            inline constexpr std::uintptr_t frWheelBrakeSupport = 0x58; // "Transform"
            inline constexpr std::uintptr_t blWheelBrakeSupport = 0x60; // "Transform"
            inline constexpr std::uintptr_t brWheelBrakeSupport = 0x68; // "Transform"
            inline constexpr std::uintptr_t BlSkidSoundEmitter = 0x70; // "GameObject"
            inline constexpr std::uintptr_t BrSkidSoundEmitter = 0x78; // "GameObject"
            inline constexpr std::uintptr_t CarAnimationView = 0x80; // "VehicleAnimationView"
            inline constexpr std::uintptr_t SpoilerAnimation = 0x88; // "TweenAnimation"
            inline constexpr std::uintptr_t FlWheelVfxSpawnPoint = 0x90; // "Transform"
            inline constexpr std::uintptr_t FrWheelVfxSpawnPoint = 0x98; // "Transform"
            inline constexpr std::uintptr_t BlWheelVfxSpawnPoint = 0xA0; // "Transform"
            inline constexpr std::uintptr_t BrWheelVfxSpawnPoint = 0xA8; // "Transform"
            inline constexpr std::uintptr_t ExhaustSmokeVfxSpawnPoint = 0xB0; // "Transform"
            inline constexpr std::uintptr_t CarMaterialView = 0xB8; // "CarMaterialView"
            inline constexpr std::uintptr_t CarHeadlightsView = 0xC0; // "CarHeadlightsView"
            inline constexpr std::uintptr_t CarSoakingView = 0xC8; // "CarSoakingView"
            inline constexpr std::uintptr_t PresentationCamera = 0xD0; // "CinemachineVirtualCamera"
            inline constexpr std::uintptr_t SuspensionConstraints = 0xD8; // "ConstraintIslandComponent"
            inline constexpr std::uintptr_t LightProbeReceiver = 0xE0; // "LightProbeReceiver"
            inline constexpr std::uintptr_t steeringWheelAdjustmentAnims = 0xE8; // "TweenAnimation[]"
            inline constexpr std::uintptr_t isMaleDriver = 0xF0; // "bool"
            inline constexpr std::uintptr_t flWheelStartLocalPosition = 0xF4; // "Vector3"
            inline constexpr std::uintptr_t frWheelStartLocalPosition = 0x100; // "Vector3"
            inline constexpr std::uintptr_t blWheelStartLocalPosition = 0x10C; // "Vector3"
            inline constexpr std::uintptr_t brWheelStartLocalPosition = 0x118; // "Vector3"
            inline constexpr std::uintptr_t flWheelStartLocalRotation = 0x124; // "Quaternion"
            inline constexpr std::uintptr_t frWheelStartLocalRotation = 0x134; // "Quaternion"
            inline constexpr std::uintptr_t blWheelStartLocalRotation = 0x144; // "Quaternion"
            inline constexpr std::uintptr_t brWheelStartLocalRotation = 0x154; // "Quaternion"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_HasRearBrakes = 0xB90740; // "public bool get_HasRearBrakes()"
            inline constexpr std::uintptr_t Awake = 0xB8FF00; // "private void Awake()"
            inline constexpr std::uintptr_t SetPositionAndOrientation = 0xB906E0; // "public void SetPositionAndOrientation(in Vector3 position, in Quaternion orientation)"
            inline constexpr std::uintptr_t SetFLWheelTransform = 0xB90580; // "public void SetFLWheelTransform(in Vector3 position, in Quaternion orientation)"
            inline constexpr std::uintptr_t SetFRWheelTransform = 0xB90690; // "public void SetFRWheelTransform(in Vector3 position, in Quaternion orientation)"
            inline constexpr std::uintptr_t SetBLWheelTransform = 0xB902C0; // "public void SetBLWheelTransform(in Vector3 position, in Quaternion orientation)"
            inline constexpr std::uintptr_t SetBRWheelTransform = 0xB903D0; // "public void SetBRWheelTransform(in Vector3 position, in Quaternion orientation)"
            inline constexpr std::uintptr_t SetFLBrakeSupport = 0xB904C0; // "public void SetFLBrakeSupport(in Vector3 position, in Quaternion orientation)"
            inline constexpr std::uintptr_t SetFRBrakeSupport = 0xB905D0; // "public void SetFRBrakeSupport(in Vector3 position, in Quaternion orientation)"
            inline constexpr std::uintptr_t SetBLBrakeSupport = 0xB90200; // "public void SetBLBrakeSupport(in Vector3 position, in Quaternion orientation)"
            inline constexpr std::uintptr_t SetBRBrakeSupport = 0xB90310; // "public void SetBRBrakeSupport(in Vector3 position, in Quaternion orientation)"
            inline constexpr std::uintptr_t SetDriverIsMale = 0xB90420; // "public void SetDriverIsMale(bool isMale)"
            inline constexpr std::uintptr_t Content_ContentWrappers_IComponentContent_ResetOnDisposeContent = 0xB90060; // "private void Content.ContentWrappers.IComponentContent.ResetOnDisposeContent()"
        }
    } // namespace CarEntityView

    namespace CarEntityViewUpdater { // "Game.Battle.Entities.Car.CarEntityViewUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t updater = 0x10; // "IUpdater"
            inline constexpr std::uintptr_t marker = 0x18; // "ProfilerMarker"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB8C810; // "public void Update()"
        }
    } // namespace CarEntityViewUpdater

    namespace CarHandBrakeInputModel { // "Models.Models.CarHandBrakeInput.CarHandBrakeInputModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Value = 0x10; // "bool"
        }
    } // namespace CarHandBrakeInputModel

    namespace CarHandBrakeInputUpdater { // "Game.Battle.Inputs.CarHandBrakeInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t carHandBrakeInputModel = 0x10; // "InputModel"
            inline constexpr std::uintptr_t battleInputModel = 0x18; // "BattleInputModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA73410; // "public void Update()"
        }
    } // namespace CarHandBrakeInputUpdater

    namespace CarHandling { // "Models.References.Car.CarTypes.CarHandling (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ForwardMaxVelocity = 0x10; // "float"
            inline constexpr std::uintptr_t BackwardMaxVelocity = 0x14; // "float"
            inline constexpr std::uintptr_t ParkingVelocity = 0x18; // "float"
            inline constexpr std::uintptr_t ParkingVelocitySqr = 0x1C; // "float"
            inline constexpr std::uintptr_t ParkingStopVelocity = 0x20; // "float"
            inline constexpr std::uintptr_t ParkingStopSqrVelocity = 0x24; // "float"
            inline constexpr std::uintptr_t ParkingMaxDuration = 0x28; // "int"
            inline constexpr std::uintptr_t FlipMaxLinearVelocity = 0x2C; // "float"
            inline constexpr std::uintptr_t FlipMaxAngularVelocity = 0x30; // "float"
            inline constexpr std::uintptr_t AccelerationWindowMaxVelocity = 0x34; // "float"
            inline constexpr std::uintptr_t DriveAxleBias = 0x38; // "float"
            inline constexpr std::uintptr_t BrakeAxleBias = 0x3C; // "float"
            inline constexpr std::uintptr_t HandBreakAcceleration = 0x40; // "float"
            inline constexpr std::uintptr_t DriftingLateralLinearVelocityRatioOnBackAxis = 0x44; // "float"
            inline constexpr std::uintptr_t FlipMaxLinearVelocitySqr = 0x48; // "float"
            inline constexpr std::uintptr_t FlipMaxAngularVelocitySqr = 0x4C; // "float"
        }
    } // namespace CarHandling

    namespace CarHandlingDescription { // "Models.References.Car.CarHandlingDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t DriveAxleBias = 0x20; // "float"
            inline constexpr std::uintptr_t BrakeAxleBias = 0x24; // "float"
            inline constexpr std::uintptr_t HandBreakAcceleration = 0x28; // "float"
            inline constexpr std::uintptr_t ForwardMaxVelocity = 0x2C; // "float"
            inline constexpr std::uintptr_t BackwardMaxVelocity = 0x30; // "float"
            inline constexpr std::uintptr_t AccelerationWindowMaxVelocity = 0x34; // "float"
            inline constexpr std::uintptr_t ParkingVelocity = 0x38; // "float"
            inline constexpr std::uintptr_t ParkingStopVelocity = 0x3C; // "float"
            inline constexpr std::uintptr_t ParkingMaxDuration = 0x40; // "int"
            inline constexpr std::uintptr_t FlipMaxLinearVelocity = 0x44; // "float"
            inline constexpr std::uintptr_t FlipMaxAngularVelocity = 0x48; // "float"
            inline constexpr std::uintptr_t DriftingLateralLinearVelocityRatioOnBackAxis = 0x4C; // "float"
        }
    } // namespace CarHandlingDescription

    namespace CarHoodTargetActions { // "Game.Battle.Entities.Car.CarHoodTargetActions (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t vehicleId = 0x10; // "int"
            inline constexpr std::uintptr_t carUpgradesHolderOpenModel = 0x18; // "CarUpgradesHolderOpenModel"
            inline constexpr std::uintptr_t worldEntitiesModel = 0x20; // "WorldEntitiesModel"
            inline constexpr std::uintptr_t settlementHelperModel = 0x28; // "ISettlementHelperModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x30; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t clientCodexModel = 0x38; // "ClientCodexModel"
            inline constexpr std::uintptr_t personalNotificationModel = 0x40; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t uiSoundModel = 0x48; // "GlobalUISoundModel"
            inline constexpr std::uintptr_t Open = 0x50; // "TargetAction"
        }
        namespace Methods {
            inline constexpr std::uintptr_t OpenHood = 0xB90C60; // "private void OpenHood()"
            inline constexpr std::uintptr_t Unavailable = 0xB90E70; // "private void Unavailable(LocalizedString invalidNotification, PersonalNotificationActionIds id)"
            inline constexpr std::uintptr_t HasAccess = 0xB90AA0; // "public bool HasAccess()"
        }
    } // namespace CarHoodTargetActions

    namespace CarHornInputUpdater { // "Game.Battle.Player.CarHornInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t carHornInputModel = 0x10; // "InputModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x18; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t battleInputModel = 0x20; // "BattleInputModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x9611D0; // "public void Update()"
        }
    } // namespace CarHornInputUpdater

    namespace CarInitializeModel { // "Models.Models.CarInitialize.CarInitializeModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "CarModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Initialize = 0x498D010; // "public void Initialize(PhysicsSceneModel physicsSceneModel, WorldEntitiesModel worldEntitiesModel, PhysicsBodiesModel physicsBodiesModel, in Vector3 pivotPosition, in Quaternion pivotOrientation)"
            inline constexpr std::uintptr_t InitializePhysicsBody = 0x498CEE0; // "private PhysicsBodyId InitializePhysicsBody(PhysicsSceneModel physicsSceneModel, in Vector3 centerOfMassPosition, in Quaternion centerOfMassOrientation, CarDescription description)"
            inline constexpr std::uintptr_t BuildVehicle = 0x498C6A0; // "private VehicleModel BuildVehicle()"
        }
    } // namespace CarInitializeModel

    namespace CarInteractionPointsDescription { // "Models.References.Car.CarInteractionPointsDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t LocalInteractPoint = 0x20; // "Vector3"
            inline constexpr std::uintptr_t InteractDescription = 0x30; // "InteractDescription"
            inline constexpr std::uintptr_t TrunkLocalInteractPoint = 0x38; // "Vector3"
            inline constexpr std::uintptr_t TrunkInteractDescription = 0x48; // "InteractDescription"
            inline constexpr std::uintptr_t HoodLocalInteractPoint = 0x50; // "Vector3"
            inline constexpr std::uintptr_t HoodInteractDescription = 0x60; // "InteractDescription"
            inline constexpr std::uintptr_t UndercarriageLocalInteractPoint = 0x68; // "Vector3"
            inline constexpr std::uintptr_t UndercarriageInteractDescription = 0x78; // "InteractDescription"
        }
    } // namespace CarInteractionPointsDescription

    namespace CarInventoryExtension { // "Game.Battle.Entities.Car.Models.CarInventoryExtension (Battle.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t ToCarInventoryModel = 0xBAB060; // "public static CarInventoryModel ToCarInventoryModel(CarModel carModel)"
            inline constexpr std::uintptr_t ToCarInventoryModel_2 = 0xBAAED0; // "public static CarInventoryModel ToCarInventoryModel(IPlotCarModel carModel)"
        }
    } // namespace CarInventoryExtension

    namespace CarInventoryModel { // "Game.Battle.Entities.Car.Models.CarInventoryModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t hasCargo = 0x10; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t hasFreeCargoSlot = 0x18; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t Id = 0x20; // "int"
            inline constexpr std::uintptr_t Description = 0x28; // "CarDescription"
            inline constexpr std::uintptr_t IsRented = 0x30; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_HasCargo = 0xBAB1F0; // "public bool get_HasCargo()"
            inline constexpr std::uintptr_t get_HasFreeCargoSlot = 0xBAB240; // "public bool get_HasFreeCargoSlot()"
        }
    } // namespace CarInventoryModel

    namespace CarItemTypeViewDescription { // "Game.Battle.ItemType.CarItemTypeViewDescription (Global.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x3554320; // "public override InventoryItemType get_Type()"
        }
    } // namespace CarItemTypeViewDescription

    namespace CarLandingCameraShakeModel { // "Game.Battle.Entities.Player.LandingCameraShake.CarLandingCameraShakeModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsShaking = 0x10; // "bool"
        }
    } // namespace CarLandingCameraShakeModel

    namespace CarLandingCameraShakeUpdater { // "Game.Battle.Entities.Player.LandingCameraShake.CarLandingCameraShakeUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t carLandingCameraShakeModel = 0x10; // "CarLandingCameraShakeModel"
            inline constexpr std::uintptr_t playerCameraViewDescriptions = 0x18; // "PlayerCameraViewDescriptions"
            inline constexpr std::uintptr_t perlin = 0x20; // "CinemachineBasicMultiChannelPerlin"
            inline constexpr std::uintptr_t carCamera = 0x28; // "CinemachineVirtualCamera"
            inline constexpr std::uintptr_t carCameraFollow = 0x30; // "Cinemachine3rdPersonFollow"
            inline constexpr std::uintptr_t fieldOfView = 0x38; // "float"
            inline constexpr std::uintptr_t cameraDistance = 0x3C; // "float"
            inline constexpr std::uintptr_t verticalArmLength = 0x40; // "float"
            inline constexpr std::uintptr_t isCameraShaking = 0x44; // "bool"
            inline constexpr std::uintptr_t endTs = 0x48; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB1B640; // "public void Update()"
            inline constexpr std::uintptr_t UpdateCamera = 0xB1B600; // "private void UpdateCamera()"
        }
    } // namespace CarLandingCameraShakeUpdater

    namespace CarModel { // "Models.Models.Car.CarModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Id = 0x10; // "int"
            inline constexpr std::uintptr_t BodyId = 0x14; // "PhysicsBodyId"
            inline constexpr std::uintptr_t Initialize = 0x20; // "CarInitializeModel"
            inline constexpr std::uintptr_t Destroy = 0x28; // "CarDestroyModel"
            inline constexpr std::uintptr_t CharacterOwner = 0x30; // "VehicleOwnerModel"
            inline constexpr std::uintptr_t PartyOwner = 0x38; // "PartyVehicleOwnerModel"
            inline constexpr std::uintptr_t ClanBattleVehicleTeamOwnerModel = 0x40; // "ClanBattleVehicleTeamOwnerModel"
            inline constexpr std::uintptr_t OwnerRole = 0x48; // "IPrimitiveModel<PlayerRoleDescription>"
            inline constexpr std::uintptr_t ControlOwner = 0x50; // "CarControlOwnerModel"
            inline constexpr std::uintptr_t DriveInput = 0x58; // "CarDriveInputModel"
            inline constexpr std::uintptr_t SteeringInput = 0x60; // "CarSteeringInputModel"
            inline constexpr std::uintptr_t HandBrakeInput = 0x68; // "CarHandBrakeInputModel"
            inline constexpr std::uintptr_t BurnoutInput = 0x70; // "CarBurnoutInputModel"
            inline constexpr std::uintptr_t Description = 0x78; // "CarDescription"
            inline constexpr std::uintptr_t SuspensionSettings = 0x80; // "VehicleSuspensionSettingsModel"
            inline constexpr std::uintptr_t TireFrictionSettings = 0x88; // "CarTireFrictionSettingsModel"
            inline constexpr std::uintptr_t SteeringSettings = 0x90; // "CarSteeringSettingsModel"
            inline constexpr std::uintptr_t TransmissionSettings = 0x98; // "CarTransmissionSettingsModel"
            inline constexpr std::uintptr_t PhysicsDragSettings = 0xA0; // "CarPhysicsDragSettingsModel"
            inline constexpr std::uintptr_t BurnoutSettings = 0xA8; // "CarBurnoutSettingsModel"
            inline constexpr std::uintptr_t EngineSettings = 0xB0; // "VehicleEngineSettingsModel"
            inline constexpr std::uintptr_t UpgradesSettings = 0xB8; // "CarUpgradesSettingsModel"
            inline constexpr std::uintptr_t Transform = 0xC0; // "VehicleTransformModel"
            inline constexpr std::uintptr_t LinearVelocity = 0xC8; // "VelocityModel"
            inline constexpr std::uintptr_t AngularVelocity = 0xD0; // "VelocityModel"
            inline constexpr std::uintptr_t Wheels = 0xD8; // "ICarWheelsModel"
            inline constexpr std::uintptr_t Seats = 0xE0; // "VehicleSeatsModel"
            inline constexpr std::uintptr_t Steering = 0xE8; // "CarSteeringModel"
            inline constexpr std::uintptr_t Transmission = 0xF0; // "CarTransmissionModel"
            inline constexpr std::uintptr_t Engine = 0xF8; // "VehicleEngineModel"
            inline constexpr std::uintptr_t EngineRules = 0x100; // "VehicleEngineRulesModel"
            inline constexpr std::uintptr_t Sleep = 0x108; // "VehicleSleepModel"
            inline constexpr std::uintptr_t PhysicsAwakeObserver = 0x110; // "PhysicsAwakeObserverModel"
            inline constexpr std::uintptr_t Parking = 0x118; // "CarParkingModel"
            inline constexpr std::uintptr_t ParkingEvent = 0x120; // "IEventModel"
            inline constexpr std::uintptr_t HandBrake = 0x128; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t Burnout = 0x130; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t HitBoxAccess = 0x138; // "IHitBoxAccessModel"
            inline constexpr std::uintptr_t HitBoxId = 0x140; // "HitBoxIdModel"
            inline constexpr std::uintptr_t Events = 0x148; // "EventsModel"
            inline constexpr std::uintptr_t TimelineTickData = 0x150; // "ITimelineDataModel<CarTimelineTickData>"
            inline constexpr std::uintptr_t TickSnapshots = 0x158; // "TimelineSnapshotsData<CarTimelineTickData>"
            inline constexpr std::uintptr_t TickExtrapolations = 0x160; // "TimelineExtrapolationsData<CarTimelineTickData>"
            inline constexpr std::uintptr_t TimelineSubTickData = 0x168; // "ITimelineDataModel<CarTimelineSubTickData>"
            inline constexpr std::uintptr_t SubTickSnapshots = 0x170; // "TimelineSnapshotsData<CarTimelineSubTickData>"
            inline constexpr std::uintptr_t SubTickExtrapolations = 0x178; // "TimelineExtrapolationsData<CarTimelineSubTickData>"
            inline constexpr std::uintptr_t SubStepSnapshots = 0x180; // "PhysicsEntitySubStepSnapshotsModel"
            inline constexpr std::uintptr_t WarpedEvent = 0x188; // "IEventModel"
            inline constexpr std::uintptr_t MoveInput = 0x190; // "IPrimitiveModel<CarMoveInputDescription>"
            inline constexpr std::uintptr_t TeleportRequest = 0x198; // "RequestModel<ValueTuple<Vector3, Quaternion, Vector3, Vector3>>"
            inline constexpr std::uintptr_t TrunkPosition = 0x1A0; // "VehicleTrunkPositionModel"
            inline constexpr std::uintptr_t TrunkOpenedModel = 0x1A8; // "InteractableObjectOpenedModel"
            inline constexpr std::uintptr_t HoodPosition = 0x1B0; // "InteractPositionModel"
            inline constexpr std::uintptr_t UndercarriagePosition = 0x1B8; // "InteractPositionModel"
            inline constexpr std::uintptr_t Exit = 0x1C0; // "VehicleExitModel"
            inline constexpr std::uintptr_t IsWarped = 0x1C8; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t SirenModel = 0x1D0; // "CarSirenModel"
            inline constexpr std::uintptr_t IsStuckInSurface = 0x1D8; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t IsHornEnabled = 0x1E0; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t IsAvailableToFlip = 0x1E8; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t Water = 0x1F0; // "VehicleWaterModel"
            inline constexpr std::uintptr_t HasFreeCargoSlot = 0x1F8; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t HasCargo = 0x200; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t IsUnowned = 0x208; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t TickData = 0x210; // "CarTickDataModel"
            inline constexpr std::uintptr_t RadioStation = 0x218; // "RadioStationModel"
            inline constexpr std::uintptr_t DirtLevel = 0x220; // "VehicleDirtLevelModel"
            inline constexpr std::uintptr_t TrunkBreachModel = 0x228; // "BreachStateEntityModel"
            inline constexpr std::uintptr_t IsHoodOpened = 0x230; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t UpgradesSlots = 0x238; // "CarUpgradesSlotsModel"
            inline constexpr std::uintptr_t IsRented = 0x240; // "IPrimitiveModel<bool>"
        }
    } // namespace CarModel

    namespace CarMoveInputDescription { // "Models.References.Car.CarMoveInputDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x8184028; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t enum_id = 0x0; // "Enum<CarMoveInputDescription>"
            inline constexpr std::uintptr_t Forward = 0x8; // "CarMoveInputDescription"
            inline constexpr std::uintptr_t Backward = 0x10; // "CarMoveInputDescription"
            inline constexpr std::uintptr_t Neutral = 0x18; // "CarMoveInputDescription"
            inline constexpr std::uintptr_t Burnout = 0x20; // "CarMoveInputDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Enum = 0x447D370; // "public static ReadOnlyEnum<CarMoveInputDescription> get_Enum()"
        }
    } // namespace CarMoveInputDescription

    namespace CarParkingExtensions { // "Models.Utils.Extensions.Vehicles.Car.CarParkingExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t InProcess = 0x3952B00; // "public static bool InProcess(long parkingOverTs)"
            inline constexpr std::uintptr_t IsOver = 0x3952B60; // "public static bool IsOver(long now, long parkingOverTs)"
            inline constexpr std::uintptr_t CalculateOverTsOnStart = 0x3952A80; // "public static long CalculateOverTsOnStart(CarDescription description, long now)"
            inline constexpr std::uintptr_t CalculateOverTsOnStop = 0x3952AB0; // "public static long CalculateOverTsOnStop()"
        }
    } // namespace CarParkingExtensions

    namespace CarParkingModel { // "Models.Models.CarParking.CarParkingModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t parkingOverTs = 0x10; // "IPrimitiveData<long>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_ParkingOverTs = 0x498EB20; // "public long get_ParkingOverTs()"
            inline constexpr std::uintptr_t set_ParkingOverTs = 0x498EB70; // "public void set_ParkingOverTs(long value)"
        }
    } // namespace CarParkingModel

    namespace CarParkingSystem { // "Models.Systems.CarParkingSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsSceneModel = 0x38; // "PhysicsSceneModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x3F86960; // "protected override void Tick(ITick tick)"
        }
    } // namespace CarParkingSystem

    namespace CarPhysics { // "Models.References.Car.CarTypes.CarPhysics (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t WheelBaseLength = 0x10; // "float"
            inline constexpr std::uintptr_t WheelBaseWidth = 0x14; // "float"
            inline constexpr std::uintptr_t WheelBaseOffsetZ = 0x18; // "float"
            inline constexpr std::uintptr_t InertiaBoxShapeSize = 0x1C; // "Vector3"
            inline constexpr std::uintptr_t Mass = 0x28; // "float"
            inline constexpr std::uintptr_t Load = 0x2C; // "float"
            inline constexpr std::uintptr_t GravityForce = 0x30; // "Vector3"
            inline constexpr std::uintptr_t CenterOfMassBiasAlongZ = 0x3C; // "float"
            inline constexpr std::uintptr_t CenterOfMassHeightOffset = 0x40; // "float"
            inline constexpr std::uintptr_t DownForceCoefficient = 0x44; // "float"
            inline constexpr std::uintptr_t InvMass = 0x48; // "float"
            inline constexpr std::uintptr_t LocalInvInertiaTensorCol0 = 0x4C; // "Vector3"
            inline constexpr std::uintptr_t LocalInvInertiaTensorCol1 = 0x58; // "Vector3"
            inline constexpr std::uintptr_t LocalInvInertiaTensorCol2 = 0x64; // "Vector3"
            inline constexpr std::uintptr_t CenterOfMassToPivotOffsetInLocalSpace = 0x70; // "Vector3"
            inline constexpr std::uintptr_t PivotToCenterOfMassOffsetInLocalSpace = 0x7C; // "Vector3"
            inline constexpr std::uintptr_t ColliderShapeRelativeToCenterOfMass = 0x88; // "CompoundShape"
            inline constexpr std::uintptr_t ColliderShapeRelativeToPivot = 0x90; // "CompoundShape"
            inline constexpr std::uintptr_t BoundingBoxLocalPositionRelativeToCenterOfMass = 0x98; // "Vector3"
            inline constexpr std::uintptr_t BoundingBoxLocalPositionRelativeToPivot = 0xA4; // "Vector3"
            inline constexpr std::uintptr_t BoundingBoxSize = 0xB0; // "Vector3"
            inline constexpr std::uintptr_t BoundingSphereRadius = 0xBC; // "float"
            inline constexpr std::uintptr_t HitBox = 0xC0; // "TransformHitBoxDescription"
            inline constexpr std::uintptr_t GarageSlotColliders = 0xC8; // "CollidersDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t CalculateCenterOfMassToPivotOffsetInLocalSpace = 0x4496DE0; // "private Vector3 CalculateCenterOfMassToPivotOffsetInLocalSpace()"
        }
    } // namespace CarPhysics

    namespace CarPhysicsDescription { // "Models.References.Car.CarPhysicsDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t InertiaBoxShapeSize = 0x20; // "Vector3"
            inline constexpr std::uintptr_t Mass = 0x2C; // "float"
            inline constexpr std::uintptr_t Gravity = 0x30; // "float"
            inline constexpr std::uintptr_t CenterOfMassBiasAlongZ = 0x34; // "float"
            inline constexpr std::uintptr_t CenterOfMassHeightOffset = 0x38; // "float"
            inline constexpr std::uintptr_t DownForceCoefficient = 0x3C; // "float"
            inline constexpr std::uintptr_t InvMass = 0x40; // "float"
            inline constexpr std::uintptr_t Load = 0x44; // "float"
            inline constexpr std::uintptr_t GravityForce = 0x48; // "Vector3"
            inline constexpr std::uintptr_t LocalInvInertiaTensorCol0 = 0x54; // "Vector3"
            inline constexpr std::uintptr_t LocalInvInertiaTensorCol1 = 0x60; // "Vector3"
            inline constexpr std::uintptr_t LocalInvInertiaTensorCol2 = 0x6C; // "Vector3"
        }
    } // namespace CarPhysicsDescription

    namespace CarPhysicsDragDescription { // "Models.References.Car.CarPhysicsDragDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t NotFullGroundedAngularDrag = 0x20; // "float"
            inline constexpr std::uintptr_t FullGroundedAngularDragZ = 0x24; // "float"
        }
    } // namespace CarPhysicsDragDescription

    namespace CarPhysicsDragSettingsModel { // "Models.Models.CarPhysicsDragSettings.CarPhysicsDragSettingsModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsDragDescription = 0x10; // "CarPhysicsDragDescription"
            inline constexpr std::uintptr_t overrideModel = 0x18; // "CarPhysicsDragSettingsOverrideModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_NotFullGroundedAngularDrag = 0x498EC90; // "public float get_NotFullGroundedAngularDrag()"
            inline constexpr std::uintptr_t get_FullGroundedAngularDragZ = 0x498EBC0; // "public float get_FullGroundedAngularDragZ()"
        }
    } // namespace CarPhysicsDragSettingsModel

    namespace CarPhysicsDragSettingsOverrideData { // "Models.Data.SettingsOverride.Cars.CarPhysicsDragSettingsOverrideData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t OverrideEnabled = 0x20; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t NotFullGroundedAngularDrag = 0x28; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t FullGroundedAngularDragZ = 0x30; // "IPrimitiveData<float>"
        }
    } // namespace CarPhysicsDragSettingsOverrideData

    namespace CarPhysicsDragSettingsOverrideModel { // "Models.Models.CarPhysicsDragSettingsOverride.CarPhysicsDragSettingsOverrideModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "CarPhysicsDragSettingsOverrideData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_OverrideEnabled = 0x498EF20; // "public bool get_OverrideEnabled()"
            inline constexpr std::uintptr_t get_NotFullGroundedAngularDrag = 0x498EED0; // "public float get_NotFullGroundedAngularDrag()"
            inline constexpr std::uintptr_t get_FullGroundedAngularDragZ = 0x498EE80; // "public float get_FullGroundedAngularDragZ()"
            inline constexpr std::uintptr_t SetOverrideData = 0x498ED60; // "public void SetOverrideData(float notFullGroundedAngularDrag, float fullGroundedAngularDragZ)"
        }
    } // namespace CarPhysicsDragSettingsOverrideModel

    namespace CarPlayerIsInsideSwitchUpdater { // "Game.Battle.Entities.Car.CarPlayerIsInsideSwitchUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t carModel = 0x10; // "CarClientModel"
            inline constexpr std::uintptr_t carViewDescriptions = 0x18; // "CarViewDescriptions"
            inline constexpr std::uintptr_t soundEmitter = 0x20; // "GameObject"
            inline constexpr std::uintptr_t isPlayerInsideCar = 0x28; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB91530; // "public void Update()"
            inline constexpr std::uintptr_t UpdateSwitch = 0xB914E0; // "private void UpdateSwitch()"
        }
    } // namespace CarPlayerIsInsideSwitchUpdater

    namespace CarPlayerIsInsideUpdater { // "Game.Battle.Entities.Car.CarPlayerIsInsideUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t carEntityModel = 0x10; // "CarEntityModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x18; // "IBattleEntitiesModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB91640; // "public void Update()"
        }
    } // namespace CarPlayerIsInsideUpdater

    namespace CarPositionViewUpdater { // "Game.Battle.EntityModel.Car.CarPositionViewUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "CarClientModel"
            inline constexpr std::uintptr_t view = 0x18; // "CarEntityView"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xCBE1C0; // "public void Update()"
        }
    } // namespace CarPositionViewUpdater

    namespace CarRentConfig { // "Models.References.Car.CarRentConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t CarSlotForRentFunc = 0x10; // "Func<CarSlotDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_CarSlotForRent = 0x1765CB0; // "public CarSlotDescription get_CarSlotForRent()"
        }
    } // namespace CarRentConfig

    namespace CarRentExtensions { // "Models.Utils.Extensions.Vehicles.Car.CarRentExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t GetCarForRent = 0x3952BE0; // "public static CarDescription GetCarForRent(BattleCharacterModel battleCharacterModel)"
        }
    } // namespace CarRentExtensions

    namespace CarSettingsOverrideData { // "Models.Data.SettingsOverride.Cars.CarSettingsOverrideData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Suspension = 0x20; // "VehicleSuspensionSettingsOverrideData"
            inline constexpr std::uintptr_t TireFriction = 0x28; // "CarTireFrictionSettingsOverrideData"
            inline constexpr std::uintptr_t Steering = 0x30; // "CarSteeringSettingsOverrideData"
            inline constexpr std::uintptr_t Transmission = 0x38; // "CarTransmissionSettingsOverrideData"
            inline constexpr std::uintptr_t PhysicsDrag = 0x40; // "CarPhysicsDragSettingsOverrideData"
            inline constexpr std::uintptr_t Burnout = 0x48; // "CarBurnoutSettingsOverrideData"
            inline constexpr std::uintptr_t Engine = 0x50; // "VehicleEngineSettingsOverrideData"
            inline constexpr std::uintptr_t Upgrades = 0x58; // "CarUpgradesSettingsOverrideData"
        }
    } // namespace CarSettingsOverrideData

    namespace CarSettingsOverrideModel { // "Models.Models.CarSettingsOverride.CarSettingsOverrideModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Suspension = 0x10; // "VehicleSuspensionSettingsOverrideModel"
            inline constexpr std::uintptr_t TireFriction = 0x18; // "CarTireFrictionSettingsOverrideModel"
            inline constexpr std::uintptr_t Steering = 0x20; // "CarSteeringSettingsOverrideModel"
            inline constexpr std::uintptr_t Transmission = 0x28; // "CarTransmissionSettingsOverrideModel"
            inline constexpr std::uintptr_t PhysicsDrag = 0x30; // "CarPhysicsDragSettingsOverrideModel"
            inline constexpr std::uintptr_t Burnout = 0x38; // "CarBurnoutSettingsOverrideModel"
            inline constexpr std::uintptr_t Engine = 0x40; // "VehicleEngineSettingsOverrideModel"
            inline constexpr std::uintptr_t Upgrades = 0x48; // "CarUpgradesSettingsOverrideModel"
        }
    } // namespace CarSettingsOverrideModel

    namespace CarSirenModel { // "Models.Models.CarSiren.CarSirenModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t isEnabled = 0x10; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t DisableTs = 0x18; // "long"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsEnabled = 0x498F280; // "public bool get_IsEnabled()"
            inline constexpr std::uintptr_t set_IsEnabled = 0x498F2D0; // "public void set_IsEnabled(bool value)"
        }
    } // namespace CarSirenModel

    namespace CarSirenUpdater { // "Game.Battle.Player.CarSirenUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t carSirenInputModel = 0x10; // "InputModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x18; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t roomConnection = 0x20; // "IRoomConnection"
            inline constexpr std::uintptr_t isRequest = 0x28; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x9614A0; // "public void Update()"
            inline constexpr std::uintptr_t SendMessage = 0x9613D0; // "private void SendMessage(CarEntityModel carEntityModel)"
        }
    } // namespace CarSirenUpdater

    namespace CarSkinViewDescription { // "Game.Global.SkinCenter.ViewDescriptions.CarSkinViewDescription (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Identified = 0x10; // "IdentifiedProperty<CarDescription>"
            inline constexpr std::uintptr_t decorativeVehicleView = 0x18; // "AssetReferenceT<GameObject>"
            inline constexpr std::uintptr_t icon = 0x20; // "AssetReferenceSprite"
            inline constexpr std::uintptr_t Rare = 0x28; // "RarityItem"
            inline constexpr std::uintptr_t CarName = 0x30; // "LocalizedString"
            inline constexpr std::uintptr_t Name = 0x38; // "LocalizedString"
            inline constexpr std::uintptr_t Description = 0x40; // "LocalizedString"
            inline constexpr std::uintptr_t CameraType = 0x48; // "SkinCenterVehicleCameraType"
            inline constexpr std::uintptr_t KeysSprite = 0x50; // "Sprite"
            inline constexpr std::uintptr_t DecorativeVehicleView = 0x58; // "LoadedComponentContent<SkinCenterDecorativeCarView>"
            inline constexpr std::uintptr_t Sprite = 0x60; // "NotInstantiateLoadedContent<Sprite>"
            inline constexpr std::uintptr_t Content = 0x68; // "ILoadedContent[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Id = 0x366D520; // "public string get_Id()"
            inline constexpr std::uintptr_t get_Empty = 0x7EC9F0; // "public bool get_Empty()"
            inline constexpr std::uintptr_t GetIconBySexData = 0x8E1B30; // "public LoadedContent<Sprite> GetIconBySexData(CharacterSexDescription sexData)"
            inline constexpr std::uintptr_t CanInteractWithSkin = 0x366D240; // "public bool CanInteractWithSkin()"
        }
    } // namespace CarSkinViewDescription

    namespace CarSkinViewDescriptions { // "Game.Global.SkinCenter.ViewDescriptions.CarSkinViewDescriptions (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t DefaultCarName = 0x28; // "LocalizedString"
        }
    } // namespace CarSkinViewDescriptions

    namespace CarSlidingSpeedUpdater { // "Game.Battle.Entities.Car.CarSlidingSpeedUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t car = 0x10; // "CarClientModel"
            inline constexpr std::uintptr_t physicsDataModel = 0x18; // "VehiclePhysicsDataModel"
            inline constexpr std::uintptr_t slidingSpeed = 0x20; // "float[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB92BE0; // "public void Update()"
            inline constexpr std::uintptr_t ShiftSpeed = 0xB92B10; // "private float ShiftSpeed()"
            inline constexpr std::uintptr_t FillSpeed = 0xB92AB0; // "private float FillSpeed()"
        }
    } // namespace CarSlidingSpeedUpdater

    namespace CarSlipParamsExtensions { // "Models.Utils.Extensions.Vehicles.Car.CarSlipParamsExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t CalculateSlipRatio = 0x3952E60; // "public static ValueTuple<CarSlipRatioType, float, int> CalculateSlipRatio(float wheelLinearVelocityZ, float wheelAngularLinearVelocityZ, float maxSlipRatio, bool isBlocked, bool isBurnoutInner, bool isBurnoutOuter)"
            inline constexpr std::uintptr_t CalculateSlipAngle = 0x3952D00; // "public static ValueTuple<float, int> CalculateSlipAngle(float wheelLinearVelocityZ, float wheelLinearVelocityX)"
        }
    } // namespace CarSlipParamsExtensions

    namespace CarSlotDescription { // "Models.References.Car.CarSlotDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t DefaultCarFunc = 0x20; // "Func<CarDescription>"
            inline constexpr std::uintptr_t InventoryItemFunc = 0x28; // "Func<InventoryItemDescription>"
            inline constexpr std::uintptr_t TrunkFunc = 0x30; // "Func<CarTrunkDescription>"
            inline constexpr std::uintptr_t HasUpgradeSlots = 0x38; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_DefaultCar = 0x9D6230; // "public CarDescription get_DefaultCar()"
            inline constexpr std::uintptr_t get_InventoryItem = 0x993E50; // "public InventoryItemDescription get_InventoryItem()"
            inline constexpr std::uintptr_t get_Trunk = 0x9AA5D0; // "public CarTrunkDescription get_Trunk()"
            inline constexpr std::uintptr_t get_HasTrunk = 0x40A2280; // "public bool get_HasTrunk()"
        }
    } // namespace CarSlotDescription

    namespace CarStateTickDataModel { // "Models.Models.TickDataModels.Car.CarStateTickDataModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsStuckInSurface = 0x10; // "bool"
            inline constexpr std::uintptr_t IsAvailableToFlip = 0x11; // "bool"
            inline constexpr std::uintptr_t ParkingOverTs = 0x18; // "long"
            inline constexpr std::uintptr_t LinearVelocityAlongZRatioWithUpgrades = 0x20; // "float"
            inline constexpr std::uintptr_t LinearVelocityAlongZRatioWithoutUpgrades = 0x24; // "float"
            inline constexpr std::uintptr_t SignedLinearVelocityAlongZRatioWithUpgrades = 0x28; // "float"
            inline constexpr std::uintptr_t SignedLinearVelocityAlongZRatioWithoutUpgrades = 0x2C; // "float"
            inline constexpr std::uintptr_t LinearVelocityAtBackwardAxleMagnitude = 0x30; // "float"
            inline constexpr std::uintptr_t LinearVelocityAtBackwardAxleAlongBasisX = 0x34; // "float"
            inline constexpr std::uintptr_t IsDriftingToLeft = 0x38; // "bool"
            inline constexpr std::uintptr_t IsDriftingToRight = 0x39; // "bool"
        }
    } // namespace CarStateTickDataModel

    namespace CarSteeringData { // "Models.Data.Car.CarSteeringData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Angle = 0x20; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t ForceSteeringToLeft = 0x28; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t ForceSteeringEndTs = 0x30; // "IPrimitiveData<long>"
        }
    } // namespace CarSteeringData

    namespace CarSteeringDescription { // "Models.References.Car.CarSteeringDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t MaxSteeringAngle = 0x20; // "float"
            inline constexpr std::uintptr_t MaxSteeringAngleBySignedLinearVelocityAlongZRatioCurve = 0x28; // "Curve"
            inline constexpr std::uintptr_t SteeringAngleChangeSpeed = 0x30; // "float"
            inline constexpr std::uintptr_t SteeringAngleChangeSpeedBySignedLinearVelocityAlongZRatioCurve = 0x38; // "Curve"
        }
    } // namespace CarSteeringDescription

    namespace CarSteeringInputModel { // "Models.Models.CarSteeringInput.CarSteeringInputModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsSteering = 0x10; // "bool"
            inline constexpr std::uintptr_t SteerLeft = 0x11; // "bool"
            inline constexpr std::uintptr_t SteerRight = 0x12; // "bool"
        }
    } // namespace CarSteeringInputModel

    namespace CarSteeringModel { // "Models.Models.CarSteering.CarSteeringModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t angle = 0x10; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t forceSteeringToLeft = 0x18; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t forceSteeringEndTs = 0x20; // "IPrimitiveData<long>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Angle = 0x498F530; // "public float get_Angle()"
            inline constexpr std::uintptr_t set_Angle = 0x498F710; // "public void set_Angle(float value)"
            inline constexpr std::uintptr_t get_IsForceSteering = 0x498F690; // "public bool get_IsForceSteering()"
            inline constexpr std::uintptr_t get_IsForceSteeringToLeft = 0x498F5D0; // "public bool get_IsForceSteeringToLeft()"
            inline constexpr std::uintptr_t get_IsForceSteeringToRight = 0x498F630; // "public bool get_IsForceSteeringToRight()"
            inline constexpr std::uintptr_t get_ForceSteeringEndTs = 0x498F580; // "public long get_ForceSteeringEndTs()"
            inline constexpr std::uintptr_t SetForceSteering = 0x498F490; // "public void SetForceSteering(long endTs, bool isLeft)"
            inline constexpr std::uintptr_t ClearForceSteering = 0x498F330; // "public void ClearForceSteering()"
            inline constexpr std::uintptr_t SetForceSteeringToLeft = 0x498F410; // "private void SetForceSteeringToLeft(bool value)"
            inline constexpr std::uintptr_t SetForceSteeringEndTs = 0x498F390; // "private void SetForceSteeringEndTs(long value)"
        }
    } // namespace CarSteeringModel

    namespace CarSteeringSettingsModel { // "Models.Models.CarSteeringSettings.CarSteeringSettingsModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t steeringDescription = 0x10; // "CarSteeringDescription"
            inline constexpr std::uintptr_t overrideModel = 0x18; // "CarSteeringSettingsOverrideModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_MaxSteeringAngleBySignedLinearVelocityAlongZRatioCurve = 0x498F770; // "public Curve get_MaxSteeringAngleBySignedLinearVelocityAlongZRatioCurve()"
            inline constexpr std::uintptr_t get_MaxSteeringAngle = 0x498F810; // "public float get_MaxSteeringAngle()"
            inline constexpr std::uintptr_t get_SteeringAngleChangeSpeedBySignedLinearVelocityAlongZRatioCurve = 0x498F8E0; // "public Curve get_SteeringAngleChangeSpeedBySignedLinearVelocityAlongZRatioCurve()"
            inline constexpr std::uintptr_t get_SteeringAngleChangeSpeed = 0x498F980; // "public float get_SteeringAngleChangeSpeed()"
        }
    } // namespace CarSteeringSettingsModel

    namespace CarSteeringSettingsOverrideData { // "Models.Data.SettingsOverride.Cars.CarSteeringSettingsOverrideData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t DataVersion = 0x20; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t MaxSteeringAngleBySignedLinearVelocityAlongZRatioCurve = 0x28; // "IPrimitiveData<byte[]>"
            inline constexpr std::uintptr_t MaxSteeringAngle = 0x30; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t SteeringAngleChangeSpeedBySignedLinearVelocityAlongZRatioCurve = 0x38; // "IPrimitiveData<byte[]>"
            inline constexpr std::uintptr_t SteeringAngleChangeSpeed = 0x40; // "IPrimitiveData<float>"
        }
    } // namespace CarSteeringSettingsOverrideData

    namespace CarSteeringSettingsOverrideModel { // "Models.Models.CarSteeringSettingsOverride.CarSteeringSettingsOverrideModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "CarSteeringSettingsOverrideData"
            inline constexpr std::uintptr_t dataVersion = 0x18; // "int"
            inline constexpr std::uintptr_t maxSteeringAngleBySignedLinearVelocityAlongZRatioCurve = 0x20; // "Curve"
            inline constexpr std::uintptr_t steeringAngleChangeSpeedBySignedLinearVelocityAlongZRatioCurve = 0x28; // "Curve"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_OverrideEnabled = 0x498FE80; // "public bool get_OverrideEnabled()"
            inline constexpr std::uintptr_t get_MaxSteeringAngleBySignedLinearVelocityAlongZRatioCurve = 0x498FE10; // "public Curve get_MaxSteeringAngleBySignedLinearVelocityAlongZRatioCurve()"
            inline constexpr std::uintptr_t get_MaxSteeringAngle = 0x498FE30; // "public float get_MaxSteeringAngle()"
            inline constexpr std::uintptr_t get_SteeringAngleChangeSpeedBySignedLinearVelocityAlongZRatioCurve = 0x498FEE0; // "public Curve get_SteeringAngleChangeSpeedBySignedLinearVelocityAlongZRatioCurve()"
            inline constexpr std::uintptr_t get_SteeringAngleChangeSpeed = 0x498FF00; // "public float get_SteeringAngleChangeSpeed()"
            inline constexpr std::uintptr_t SetOverrideData = 0x498FBB0; // "public void SetOverrideData(byte[] maxSteeringAngleBySignedLinearVelocityAlongZRatioCurve, float maxSteeringAngle, byte[] steeringAngleChangeSpeedBySignedLinearVelocityAlongZRatioCurve, float steeringAngleChangeSpeed)"
            inline constexpr std::uintptr_t AlignLocalVersionWithDataVersion = 0x498FA50; // "private void AlignLocalVersionWithDataVersion()"
        }
    } // namespace CarSteeringSettingsOverrideModel

    namespace CarSteeringSystem { // "Models.Systems.CarSteeringSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t tickDeltaTime = 0x38; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x3F87050; // "protected override void Tick(ITick tick)"
            inline constexpr std::uintptr_t GetTargetSteeringAngle = 0x3F86F60; // "private float GetTargetSteeringAngle(CarSteeringInputModel steeringInput, CarSteeringModel steering, CarSteeringSettingsModel steeringSettings, CarStateTickDataModel stateTickData, CarBurnoutTickDataModel burnoutTickData)"
            inline constexpr std::uintptr_t GetSteeringSpeed = 0x3F86ED0; // "private float GetSteeringSpeed(CarSteeringSettingsModel steeringSettings, CarStateTickDataModel stateTickData, CarBurnoutTickDataModel burnoutTickData)"
        }
    } // namespace CarSteeringSystem

    namespace CarSteeringWheelViewUpdater { // "Game.Battle.Entities.Car.Updaters.CarSteeringWheelViewUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t carSteering = 0x18; // "CarSteeringModel"
            inline constexpr std::uintptr_t vehicleAnimationView = 0x20; // "VehicleAnimationView"
            inline constexpr std::uintptr_t steeringSettings = 0x28; // "CarSteeringSettingsModel"
            inline constexpr std::uintptr_t t = 0x30; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t InnerUpdate = 0xBAB460; // "protected override void InnerUpdate()"
            inline constexpr std::uintptr_t InnerStart = 0x7B3360; // "protected override void InnerStart()"
            inline constexpr std::uintptr_t InnerStop = 0xBAB430; // "protected override void InnerStop()"
        }
    } // namespace CarSteeringWheelViewUpdater

    namespace CarStuckSurfaceConfig { // "Models.References.Car.CarStuckSurfaceConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t LinearVelocityDamping = 0x10; // "float"
            inline constexpr std::uintptr_t AngularVelocityDamping = 0x14; // "float"
            inline constexpr std::uintptr_t StuckLinearVelocity = 0x18; // "float"
            inline constexpr std::uintptr_t SqrStuckLinearVelocity = 0x1C; // "float"
            inline constexpr std::uintptr_t StuckSurfaceType = 0x20; // "byte"
        }
        namespace Methods {
            inline constexpr std::uintptr_t IsStuckSurfaceType = 0x447EEF0; // "public bool IsStuckSurfaceType(byte surfaceType)"
        }
    } // namespace CarStuckSurfaceConfig

    namespace CarSuspensionShakingModelUpdater { // "Game.Battle.Entities.Car.CarSuspensionShakingModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t carModel = 0x18; // "CarEntityModel"
            inline constexpr std::uintptr_t surfaceTypeViewDescriptions = 0x20; // "SurfaceTypeViewDescriptions"
            inline constexpr std::uintptr_t cars = 0x28; // "CarViewDescriptions"
            inline constexpr std::uintptr_t dataModels = 0x30; // "IBattleEntityDataModels"
            inline constexpr std::uintptr_t noiseYCoord = 0x38; // "float"
            inline constexpr std::uintptr_t clientModel = 0x40; // "CarClientModel"
            inline constexpr std::uintptr_t wheelsCount = 0x48; // "int"
            inline constexpr std::uintptr_t wheelDescriptions = 0x50; // "VehicleWheelDescription[]"
            inline constexpr std::uintptr_t wheelClientData = 0x58; // "CarWheelClientData[]"
            inline constexpr std::uintptr_t wheelClientModel = 0x60; // "CarWheelModel[]"
            inline constexpr std::uintptr_t axles = 0x68; // "CarAxleClientModel[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t InnerUpdate = 0xB95B60; // "protected override void InnerUpdate()"
            inline constexpr std::uintptr_t InnerStart = 0x7B3360; // "protected override void InnerStart()"
            inline constexpr std::uintptr_t InnerStop = 0x7B3360; // "protected override void InnerStop()"
            inline constexpr std::uintptr_t UpdateWheel = 0xB95C10; // "private void UpdateWheel(VehicleWheelDescription wheelDescription, CarWheelClientData carWheelClientData, CarWheelModel clientWheelModel, CarAxleClientModel axle)"
        }
    } // namespace CarSuspensionShakingModelUpdater

    namespace CarTargetActions { // "Game.Battle.EntityModel.Car.CarTargetActions (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleInputModel = 0x10; // "BattleInputModel"
            inline constexpr std::uintptr_t carEntityModel = 0x18; // "CarEntityModel"
            inline constexpr std::uintptr_t inventoryDialogModel = 0x20; // "InventoryDialogModel"
            inline constexpr std::uintptr_t carSoundEmitter = 0x28; // "GameObject"
            inline constexpr std::uintptr_t personalNotificationModel = 0x30; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t attemptToOpenClosedDoor = 0x38; // "Event"
            inline constexpr std::uintptr_t cooldownTs = 0x40; // "float"
            inline constexpr std::uintptr_t Enter = 0x48; // "TargetAction"
            inline constexpr std::uintptr_t EnterPoliceCarUnavailable = 0x50; // "ITargetAction"
            inline constexpr std::uintptr_t UnavailableInteraction = 0x58; // "UnavailableTargetAction"
        }
        namespace Methods {
            inline constexpr std::uintptr_t EnterCar = 0xC9D0D0; // "private void EnterCar()"
            inline constexpr std::uintptr_t Unavailable = 0xC9D1C0; // "private void Unavailable(LocalizedString invalidNotification, PersonalNotificationActionIds id)"
        }
    } // namespace CarTargetActions

    namespace CarTickDataModel { // "Models.Models.TickDataModels.Car.CarTickDataModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t TransformTickData = 0x10; // "VehicleTransformTickDataModel"
            inline constexpr std::uintptr_t LinksTickData = 0x18; // "VehicleLinksTickDataModel"
            inline constexpr std::uintptr_t StateTickData = 0x20; // "CarStateTickDataModel"
            inline constexpr std::uintptr_t SleepTickData = 0x28; // "VehicleSleepTickDataModel"
            inline constexpr std::uintptr_t BurnoutTickData = 0x30; // "CarBurnoutTickDataModel"
            inline constexpr std::uintptr_t WaterTickData = 0x38; // "VehicleWaterTickDataModel"
            inline constexpr std::uintptr_t EngineTickData = 0x40; // "VehicleEngineTickDataModel"
        }
    } // namespace CarTickDataModel

    namespace CarTimelineDataExtensions { // "Models.Utils.Timeline.Data.CarTimelineDataExtensions (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x81894A0; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t TickInterpolationFunc = 0x0; // "TimelineDelegates.Interpolation<CarTimelineTickData>"
            inline constexpr std::uintptr_t ErrorCorrectionTickInterpolationFunc = 0x8; // "TimelineDelegates.ErrorCorrectionInterpolation<CarTimelineTickData>"
            inline constexpr std::uintptr_t SubTickInterpolationFunc = 0x10; // "TimelineDelegates.Interpolation<CarTimelineSubTickData>"
            inline constexpr std::uintptr_t ErrorCorrectionSubTickInterpolationFunc = 0x18; // "TimelineDelegates.ErrorCorrectionInterpolation<CarTimelineSubTickData>"
            inline constexpr std::uintptr_t CastToPhysicsBodyDataFunc = 0x20; // "TimelineDelegates.CastToPhysicsBodyData<CarTimelineSubTickData>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t TickInterpolation = 0x3936600; // "private static void TickInterpolation(in CarTimelineTickData from, in CarTimelineTickData to, float t, out CarTimelineTickData result)"
            inline constexpr std::uintptr_t WheelTickInterpolation = 0x3936910; // "private static void WheelTickInterpolation(in CarWheelTimelineTickData from, in CarWheelTimelineTickData to, float t, out CarWheelTimelineTickData result)"
            inline constexpr std::uintptr_t SubTickInterpolation = 0x39364F0; // "private static void SubTickInterpolation(in CarTimelineSubTickData from, in CarTimelineSubTickData to, float t, out CarTimelineSubTickData result)"
            inline constexpr std::uintptr_t ErrorCorrectionTickInterpolation = 0x3936230; // "private static void ErrorCorrectionTickInterpolation(in CarTimelineTickData errorData, in CarTimelineTickData correctData, float t, out CarTimelineTickData result)"
            inline constexpr std::uintptr_t WheelErrorCorrectionTickInterpolation = 0x39368C0; // "private static void WheelErrorCorrectionTickInterpolation(in CarWheelTimelineTickData errorData, in CarWheelTimelineTickData correctData, float t, out CarWheelTimelineTickData result)"
            inline constexpr std::uintptr_t ErrorCorrectionSubTickInterpolation = 0x39360A0; // "private static void ErrorCorrectionSubTickInterpolation(in CarTimelineSubTickData errorData, in CarTimelineSubTickData correctData, float t, out CarTimelineSubTickData result)"
            inline constexpr std::uintptr_t CastToPhysicsBodyData = 0x3936050; // "private static PhysicsBodyTimelineData CastToPhysicsBodyData(in CarTimelineSubTickData data)"
        }
    } // namespace CarTimelineDataExtensions

    namespace CarTimelineSubTickData { // "Models.Timeline.Data.Entity.CarTimelineSubTickData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t BodyTouchAnyBeforeSubTick = 0x0; // "bool"
            inline constexpr std::uintptr_t CenterOfMassPosition = 0x4; // "Vector3"
            inline constexpr std::uintptr_t CenterOfMassOrientation = 0x10; // "Quaternion"
            inline constexpr std::uintptr_t LinearVelocity = 0x20; // "Vector3"
            inline constexpr std::uintptr_t AngularVelocity = 0x2C; // "Vector3"
        }
    } // namespace CarTimelineSubTickData

    namespace CarTimelineSubTickDataModel { // "Models.Models.TimelineDataModel.CarTimelineSubTickDataModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t transform = 0x10; // "VehicleTransformModel"
            inline constexpr std::uintptr_t linearVelocity = 0x18; // "VelocityModel"
            inline constexpr std::uintptr_t angularVelocity = 0x20; // "VelocityModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Build = 0x48B6780; // "public CarTimelineSubTickData Build()"
        }
    } // namespace CarTimelineSubTickDataModel

    namespace CarTimelineTickData { // "Models.Timeline.Data.Entity.CarTimelineTickData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsWarped = 0x0; // "bool"
            inline constexpr std::uintptr_t SteeringAngle = 0x4; // "float"
            inline constexpr std::uintptr_t FlWheel = 0x8; // "CarWheelTimelineTickData"
            inline constexpr std::uintptr_t FrWheel = 0x20; // "CarWheelTimelineTickData"
            inline constexpr std::uintptr_t BlWheel = 0x38; // "CarWheelTimelineTickData"
            inline constexpr std::uintptr_t BrWheel = 0x50; // "CarWheelTimelineTickData"
            inline constexpr std::uintptr_t EngineActive = 0x68; // "bool"
            inline constexpr std::uintptr_t EngineStateChangeOverTs = 0x70; // "long"
            inline constexpr std::uintptr_t ParkingOverTs = 0x78; // "long"
            inline constexpr std::uintptr_t IsStuckInSurface = 0x80; // "bool"
            inline constexpr std::uintptr_t IsAvailableToFlip = 0x81; // "bool"
            inline constexpr std::uintptr_t IsBurnout = 0x82; // "bool"
            inline constexpr std::uintptr_t WaterState = 0x88; // "VehicleWaterStateDescription"
            inline constexpr std::uintptr_t SleepCounter = 0x90; // "int"
        }
    } // namespace CarTimelineTickData

    namespace CarTimelineTickDataModel { // "Models.Models.TimelineDataModel.CarTimelineTickDataModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t wheels = 0x10; // "ICarWheelsModel"
            inline constexpr std::uintptr_t isStuckInSurface = 0x18; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t isAvailableToFlip = 0x20; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t burnout = 0x28; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t sleep = 0x30; // "VehicleSleepModel"
            inline constexpr std::uintptr_t parking = 0x38; // "CarParkingModel"
            inline constexpr std::uintptr_t steering = 0x40; // "CarSteeringModel"
            inline constexpr std::uintptr_t isWarped = 0x48; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t water = 0x50; // "VehicleWaterModel"
            inline constexpr std::uintptr_t engine = 0x58; // "VehicleEngineModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Build = 0x48B6AE0; // "public CarTimelineTickData Build()"
            inline constexpr std::uintptr_t BuildWheel = 0x48B6850; // "private static CarWheelTimelineTickData BuildWheel(ICarWheelModel wheel)"
        }
    } // namespace CarTimelineTickDataModel

    namespace CarTireFrictionDescription { // "Models.References.Car.CarTireFrictionDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t FwLongFrictionCurve = 0x20; // "Curve"
            inline constexpr std::uintptr_t FwLatFrictionCurve = 0x28; // "Curve"
            inline constexpr std::uintptr_t FwFrictionStiffness = 0x30; // "float"
            inline constexpr std::uintptr_t FwBlockFrictionStiffness = 0x34; // "float"
            inline constexpr std::uintptr_t BwLongFrictionCurve = 0x38; // "Curve"
            inline constexpr std::uintptr_t BwLatFrictionCurve = 0x40; // "Curve"
            inline constexpr std::uintptr_t BwFrictionStiffness = 0x48; // "float"
            inline constexpr std::uintptr_t BwBlockFrictionStiffness = 0x4C; // "float"
            inline constexpr std::uintptr_t MaxSlipRatio = 0x50; // "float"
            inline constexpr std::uintptr_t SlipRatioSlippingThreshold = 0x54; // "float"
            inline constexpr std::uintptr_t FrictionForceApplyOffsetYAlongLinkDirection = 0x58; // "float"
        }
    } // namespace CarTireFrictionDescription

    namespace CarTireFrictionSettingsModel { // "Models.Models.CarTireFrictionSettings.CarTireFrictionSettingsModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t tireFrictionDescription = 0x10; // "CarTireFrictionDescription"
            inline constexpr std::uintptr_t overrideModel = 0x18; // "CarTireFrictionSettingsOverrideModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_FWLongFrictionCurve = 0x4990180; // "public Curve get_FWLongFrictionCurve()"
            inline constexpr std::uintptr_t get_FWLatFrictionCurve = 0x4990130; // "public Curve get_FWLatFrictionCurve()"
            inline constexpr std::uintptr_t get_FWFrictionStiffness = 0x49900E0; // "public float get_FWFrictionStiffness()"
            inline constexpr std::uintptr_t get_FWBlockFrictionStiffness = 0x4990090; // "public float get_FWBlockFrictionStiffness()"
            inline constexpr std::uintptr_t get_BWLongFrictionCurve = 0x4990040; // "public Curve get_BWLongFrictionCurve()"
            inline constexpr std::uintptr_t get_BWLatFrictionCurve = 0x498FFF0; // "public Curve get_BWLatFrictionCurve()"
            inline constexpr std::uintptr_t get_BWFrictionStiffness = 0x498FFA0; // "public float get_BWFrictionStiffness()"
            inline constexpr std::uintptr_t get_BWBlockFrictionStiffness = 0x498FF50; // "public float get_BWBlockFrictionStiffness()"
            inline constexpr std::uintptr_t get_MaxSlipRatio = 0x4990220; // "public float get_MaxSlipRatio()"
            inline constexpr std::uintptr_t get_SlipRatioSlippingThreshold = 0x4990240; // "public float get_SlipRatioSlippingThreshold()"
            inline constexpr std::uintptr_t get_FrictionForceApplyOffsetYAlongLinkDirection = 0x49901D0; // "public float get_FrictionForceApplyOffsetYAlongLinkDirection()"
        }
    } // namespace CarTireFrictionSettingsModel

    namespace CarTireFrictionSettingsOverrideData { // "Models.Data.SettingsOverride.Cars.CarTireFrictionSettingsOverrideData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t DataVersion = 0x20; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t FWLongFrictionCurve = 0x28; // "IPrimitiveData<byte[]>"
            inline constexpr std::uintptr_t FWLatFrictionCurve = 0x30; // "IPrimitiveData<byte[]>"
            inline constexpr std::uintptr_t FWFrictionStiffness = 0x38; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t FWBlockFrictionStiffness = 0x40; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t BWLongFrictionCurve = 0x48; // "IPrimitiveData<byte[]>"
            inline constexpr std::uintptr_t BWLatFrictionCurve = 0x50; // "IPrimitiveData<byte[]>"
            inline constexpr std::uintptr_t BWFrictionStiffness = 0x58; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t BWBlockFrictionStiffness = 0x60; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t FrictionForceApplyOffsetYAlongLinkDirection = 0x68; // "IPrimitiveData<float>"
        }
    } // namespace CarTireFrictionSettingsOverrideData

    namespace CarTireFrictionSettingsOverrideModel { // "Models.Models.CarTireFrictionSettingsOverride.CarTireFrictionSettingsOverrideModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "CarTireFrictionSettingsOverrideData"
            inline constexpr std::uintptr_t dataVersion = 0x18; // "int"
            inline constexpr std::uintptr_t fwLongFrictionCurve = 0x20; // "Curve"
            inline constexpr std::uintptr_t fwLatFrictionCurve = 0x28; // "Curve"
            inline constexpr std::uintptr_t bwLongFrictionCurve = 0x30; // "Curve"
            inline constexpr std::uintptr_t bwLatFrictionCurve = 0x38; // "Curve"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_OverrideEnabled = 0x4967590; // "public bool get_OverrideEnabled()"
            inline constexpr std::uintptr_t get_FWLongFrictionCurve = 0x4967520; // "public Curve get_FWLongFrictionCurve()"
            inline constexpr std::uintptr_t get_FWLatFrictionCurve = 0x4967500; // "public Curve get_FWLatFrictionCurve()"
            inline constexpr std::uintptr_t get_FWFrictionStiffness = 0x49674B0; // "public float get_FWFrictionStiffness()"
            inline constexpr std::uintptr_t get_FWBlockFrictionStiffness = 0x4967460; // "public float get_FWBlockFrictionStiffness()"
            inline constexpr std::uintptr_t get_BWLongFrictionCurve = 0x4967440; // "public Curve get_BWLongFrictionCurve()"
            inline constexpr std::uintptr_t get_BWLatFrictionCurve = 0x4967420; // "public Curve get_BWLatFrictionCurve()"
            inline constexpr std::uintptr_t get_BWFrictionStiffness = 0x49673D0; // "public float get_BWFrictionStiffness()"
            inline constexpr std::uintptr_t get_BWBlockFrictionStiffness = 0x4967380; // "public float get_BWBlockFrictionStiffness()"
            inline constexpr std::uintptr_t get_FrictionForceApplyOffsetYAlongLinkDirection = 0x4967540; // "public float get_FrictionForceApplyOffsetYAlongLinkDirection()"
            inline constexpr std::uintptr_t SetOverrideData = 0x4966FC0; // "public void SetOverrideData(byte[] fwLongFrictionCurve, byte[] fwLatFrictionCurve, float fwFrictionStiffness, float fwBlockFrictionStiffness, byte[] bwLongFrictionCurve, byte[] bwLatFrictionCurve, float bwFrictionStiffness, float bwBlockFrictionStiffness, float frictionForceApplyOffsetYAlongLinkDirection)"
            inline constexpr std::uintptr_t AlignLocalVersionWithDataVersion = 0x4966DD0; // "private void AlignLocalVersionWithDataVersion()"
        }
    } // namespace CarTireFrictionSettingsOverrideModel

    namespace CarTooltipContext { // "Game.Battle.CarTooltipContext (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Description = 0x10; // "CarDescription"
            inline constexpr std::uintptr_t Options = 0x18; // "VehicleTooltipOptions"
        }
    } // namespace CarTooltipContext

    namespace CarTransmissionConfig { // "Models.References.Car.Transmission.CarTransmissionConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t MaxForwardGearsCount = 0x10; // "int"
            inline constexpr std::uintptr_t MaxGearsCount = 0x14; // "int"
            inline constexpr std::uintptr_t ReverseGear = 0x18; // "int"
            inline constexpr std::uintptr_t FirstGear = 0x1C; // "int"
            inline constexpr std::uintptr_t ReverseGearStartVelocity = 0x20; // "float"
            inline constexpr std::uintptr_t AirResistanceMinAcceleration = 0x24; // "float"
            inline constexpr std::uintptr_t AirResistanceMaxAcceleration = 0x28; // "float"
        }
    } // namespace CarTransmissionConfig

    namespace CarTransmissionData { // "Models.Data.Car.CarTransmissionData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Gear = 0x20; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t GearShiftInProcess = 0x28; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t GearShiftOverTs = 0x30; // "IPrimitiveData<long>"
        }
    } // namespace CarTransmissionData

    namespace CarTransmissionDescription { // "Models.References.Car.Transmission.CarTransmissionDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ForwardGears = 0x20; // "IReadOnlyList<CarTransmissionGearDescription>"
            inline constexpr std::uintptr_t DriveForceAcceleration = 0x28; // "float"
            inline constexpr std::uintptr_t ReverseDriveForceAcceleration = 0x2C; // "float"
            inline constexpr std::uintptr_t BrakeForceAcceleration = 0x30; // "float"
            inline constexpr std::uintptr_t GearShiftDuration = 0x38; // "long"
            inline constexpr std::uintptr_t GearShiftCooldown = 0x40; // "long"
        }
    } // namespace CarTransmissionDescription

    namespace CarTransmissionGearDescription { // "Models.References.Car.Transmission.CarTransmissionGearDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ShiftDownVelocityNormalized = 0x10; // "float"
            inline constexpr std::uintptr_t ShiftUpVelocityNormalized = 0x14; // "float"
            inline constexpr std::uintptr_t AccelerationNormalized = 0x18; // "float"
        }
    } // namespace CarTransmissionGearDescription

    namespace CarTransmissionModel { // "Models.Models.CarTransmission.CarTransmissionModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "CarTransmissionData"
            inline constexpr std::uintptr_t settings = 0x18; // "CarTransmissionSettingsModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Gear = 0x49679B0; // "public int get_Gear()"
            inline constexpr std::uintptr_t set_Gear = 0x4967AF0; // "public void set_Gear(int value)"
            inline constexpr std::uintptr_t IsGearShiftOnCooldown = 0x49675F0; // "public bool IsGearShiftOnCooldown(long now)"
            inline constexpr std::uintptr_t get_IsGearShiftInProcess = 0x4967A00; // "public bool get_IsGearShiftInProcess()"
            inline constexpr std::uintptr_t get_GearShiftOverTs = 0x4967960; // "public long get_GearShiftOverTs()"
            inline constexpr std::uintptr_t StartGearShiftProcess = 0x4967790; // "public void StartGearShiftProcess(long now)"
            inline constexpr std::uintptr_t StopGearShiftProcess = 0x4967900; // "public void StopGearShiftProcess()"
            inline constexpr std::uintptr_t get_IsReverseGear = 0x4967A50; // "public bool get_IsReverseGear()"
            inline constexpr std::uintptr_t get_IsNeutralGear = 0x4967A00; // "public bool get_IsNeutralGear()"
        }
    } // namespace CarTransmissionModel

    namespace CarTransmissionSettingsModel { // "Models.Models.CarTransmissionSettings.CarTransmissionSettingsModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t transmissionDescription = 0x10; // "CarTransmissionDescription"
            inline constexpr std::uintptr_t overrideModel = 0x18; // "CarTransmissionSettingsOverrideModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_ForwardGears = 0x4968140; // "public IReadOnlyList<CarTransmissionGearDescription> get_ForwardGears()"
            inline constexpr std::uintptr_t get_LastGear = 0x4968480; // "public int get_LastGear()"
            inline constexpr std::uintptr_t get_DriveForceAcceleration = 0x4968070; // "public float get_DriveForceAcceleration()"
            inline constexpr std::uintptr_t get_ReverseDriveForceAcceleration = 0x4968520; // "public float get_ReverseDriveForceAcceleration()"
            inline constexpr std::uintptr_t get_BrakeForceAcceleration = 0x4967FA0; // "public float get_BrakeForceAcceleration()"
            inline constexpr std::uintptr_t get_GearShiftDuration = 0x49683B0; // "public long get_GearShiftDuration()"
            inline constexpr std::uintptr_t get_GearShiftCooldown = 0x49682E0; // "public long get_GearShiftCooldown()"
            inline constexpr std::uintptr_t GetShiftUpVelocityInGear = 0x4967C80; // "public float GetShiftUpVelocityInGear(int gear, CarHandling handling, CarUpgradesSettingsModel upgradesSettings, CarUpgradesSlotsModel upgradesSlots)"
            inline constexpr std::uintptr_t GetShiftDownVelocityInGear = 0x4967B80; // "public float GetShiftDownVelocityInGear(int gear, CarHandling handling)"
            inline constexpr std::uintptr_t TryGetForwardGearDescription = 0x4967E10; // "public bool TryGetForwardGearDescription(int gear, out CarTransmissionGearDescription gearDescription)"
        }
    } // namespace CarTransmissionSettingsModel

    namespace CarTransmissionSettingsOverrideData { // "Models.Data.SettingsOverride.Cars.CarTransmissionSettingsOverrideData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t DataVersion = 0x20; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t ForwardGears = 0x28; // "IPrimitiveData<byte[]>"
            inline constexpr std::uintptr_t DriveForceAcceleration = 0x30; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t ReverseDriveForceAcceleration = 0x38; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t BrakeForceAcceleration = 0x40; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t GearShiftDuration = 0x48; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t GearShiftCooldown = 0x50; // "IPrimitiveData<long>"
        }
    } // namespace CarTransmissionSettingsOverrideData

    namespace CarTransmissionSettingsOverrideModel { // "Models.Models.CarTransmissionSettingsOverride.CarTransmissionSettingsOverrideModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "CarTransmissionSettingsOverrideData"
            inline constexpr std::uintptr_t dataVersion = 0x18; // "int"
            inline constexpr std::uintptr_t forwardGears = 0x20; // "List<CarTransmissionGearDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_OverrideEnabled = 0x4968B50; // "public bool get_OverrideEnabled()"
            inline constexpr std::uintptr_t get_ForwardGears = 0x4968990; // "public IReadOnlyList<CarTransmissionGearDescription> get_ForwardGears()"
            inline constexpr std::uintptr_t get_DriveForceAcceleration = 0x4968940; // "public float get_DriveForceAcceleration()"
            inline constexpr std::uintptr_t get_ReverseDriveForceAcceleration = 0x4968BB0; // "public float get_ReverseDriveForceAcceleration()"
            inline constexpr std::uintptr_t get_BrakeForceAcceleration = 0x49688F0; // "public float get_BrakeForceAcceleration()"
            inline constexpr std::uintptr_t get_GearShiftDuration = 0x4968B00; // "public long get_GearShiftDuration()"
            inline constexpr std::uintptr_t get_GearShiftCooldown = 0x4968AB0; // "public long get_GearShiftCooldown()"
            inline constexpr std::uintptr_t SetOverrideData = 0x4968710; // "public void SetOverrideData(byte[] forwardGears, float driveForceAcceleration, float reverseDriveForceAcceleration, float brakeForceAcceleration, long gearShiftDuration, long gearShiftCooldown)"
            inline constexpr std::uintptr_t AlignLocalVersionWithDataVersion = 0x49685F0; // "private void AlignLocalVersionWithDataVersion()"
        }
    } // namespace CarTransmissionSettingsOverrideModel

    namespace CarTrunkDistanceOpenModel { // "Game.Battle.Entities.Car.Models.CarTrunkDistanceOpenModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t NeedOpenTrunk = 0x10; // "bool"
        }
    } // namespace CarTrunkDistanceOpenModel

    namespace CarTrunkEntityStreamReader { // "Models.Replication.EntityStreamReader.CarTrunkEntityStreamReader (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t paramsModel = 0x20; // "EntitiesParamsModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t TryReadParams = 0x44B4FB0; // "protected override bool TryReadParams(int entityId, IBinaryReadStream stream)"
        }
    } // namespace CarTrunkEntityStreamReader

    namespace CarTrunkTargetActions { // "Game.Battle.Entities.Car.CarTrunkTargetActions (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleModel = 0x10; // "BattleModel"
            inline constexpr std::uintptr_t breachStateEntityModel = 0x18; // "BreachStateEntityModel"
            inline constexpr std::uintptr_t carInventoryModel = 0x20; // "CarInventoryModel"
            inline constexpr std::uintptr_t carViewDescriptions = 0x28; // "CarViewDescriptions"
            inline constexpr std::uintptr_t personalNotificationModel = 0x30; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t uiSoundModel = 0x38; // "GlobalUISoundModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x40; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t observerRequestModel = 0x48; // "ObserverRequestModel"
            inline constexpr std::uintptr_t battleInputModel = 0x50; // "BattleInputModel"
            inline constexpr std::uintptr_t partyMemberAccessModel = 0x58; // "IPartyMemberAccessModel"
            inline constexpr std::uintptr_t trunkSoundEmitter = 0x60; // "GameObject"
            inline constexpr std::uintptr_t carTrunkDistanceOpenModel = 0x68; // "CarTrunkDistanceOpenModel"
            inline constexpr std::uintptr_t partyModel = 0x70; // "PartyModel"
            inline constexpr std::uintptr_t clanModel = 0x78; // "ClanModel"
            inline constexpr std::uintptr_t now = 0x80; // "INow"
            inline constexpr std::uintptr_t clientCodexModel = 0x88; // "ClientCodexModel"
            inline constexpr std::uintptr_t becomeRobberNotificationModel = 0x90; // "BecomeRobberNotificationModel"
            inline constexpr std::uintptr_t unavailableKeys = 0x98; // "UnavailableTargetActionsKeys"
            inline constexpr std::uintptr_t settlementHelperModel = 0xA0; // "ISettlementHelperModel"
            inline constexpr std::uintptr_t breachEntity = 0xA8; // "BreachEntityModel"
            inline constexpr std::uintptr_t worldEntitiesModel = 0xB0; // "WorldEntitiesModel"
            inline constexpr std::uintptr_t battleMode = 0xB8; // "BattleModeDescription"
            inline constexpr std::uintptr_t characterSlotsModel = 0xC0; // "ICharacterSlotsModel"
            inline constexpr std::uintptr_t clanBattleCharacterTeamModel = 0xC8; // "IClanBattleCharacterTeamModel"
            inline constexpr std::uintptr_t deferredOpenModel = 0xD0; // "DeferredOpenModel"
            inline constexpr std::uintptr_t localizationKeys = 0xD8; // "LocalizationKeys"
            inline constexpr std::uintptr_t carUpgradesHolderOpenModel = 0xE0; // "CarUpgradesHolderOpenModel"
            inline constexpr std::uintptr_t Interact = 0xE8; // "ITargetAction"
            inline constexpr std::uintptr_t RepairInteract = 0xF0; // "ITargetAction"
            inline constexpr std::uintptr_t CopRepair = 0xF8; // "TargetAction"
            inline constexpr std::uintptr_t BurglarInteract = 0x100; // "ITargetAction"
            inline constexpr std::uintptr_t Refill = 0x108; // "TargetAction"
            inline constexpr std::uintptr_t PutCargo = 0x110; // "TargetAction"
            inline constexpr std::uintptr_t Open = 0x118; // "TargetAction"
            inline constexpr std::uintptr_t Breach = 0x120; // "TargetAction"
            inline constexpr std::uintptr_t UnavailableBreach = 0x128; // "UnavailableTargetAction"
            inline constexpr std::uintptr_t UnavailableBreachCitizen = 0x130; // "UnavailableTargetAction"
            inline constexpr std::uintptr_t UnavailableInteraction = 0x138; // "UnavailableTargetAction"
        }
        namespace Methods {
            inline constexpr std::uintptr_t CanOpenUpgrades = 0xB966E0; // "private bool CanOpenUpgrades(VehicleTrunkInventorySettingsDescription trunkInventorySettingsDescription, CarInventoryModel carInventoryModel)"
            inline constexpr std::uintptr_t OpenUpgrades = 0xB970C0; // "private void OpenUpgrades()"
            inline constexpr std::uintptr_t UnavailableToManage = 0xB97FB0; // "private void UnavailableToManage()"
            inline constexpr std::uintptr_t CanManage = 0xB96500; // "private bool CanManage()"
            inline constexpr std::uintptr_t TryGetInvalidOpenInventoryNotification = 0xB975E0; // "private bool TryGetInvalidOpenInventoryNotification(out LocalizedString invalidNotification)"
            inline constexpr std::uintptr_t UnavailableRepairTrunk = 0xB97AB0; // "private void UnavailableRepairTrunk()"
            inline constexpr std::uintptr_t CanRepairTrunk = 0xB96740; // "private bool CanRepairTrunk()"
            inline constexpr std::uintptr_t CanTakeCargo = 0xB96890; // "private bool CanTakeCargo()"
            inline constexpr std::uintptr_t CanOpenTrunk = 0xB96550; // "private bool CanOpenTrunk()"
            inline constexpr std::uintptr_t UnavailableOpenTrunk = 0xB97900; // "private void UnavailableOpenTrunk()"
            inline constexpr std::uintptr_t UnavailableTakeCargoTrunk = 0xB97CC0; // "private void UnavailableTakeCargoTrunk()"
            inline constexpr std::uintptr_t OpenTrunk = 0xB96F70; // "private void OpenTrunk()"
            inline constexpr std::uintptr_t Unavailable = 0xA74080; // "private void Unavailable(LocalizedString invalidNotification, PersonalNotificationActionIds id)"
            inline constexpr std::uintptr_t RefillAmmoWithCopCarTrunk = 0xB972F0; // "private void RefillAmmoWithCopCarTrunk()"
            inline constexpr std::uintptr_t PutCargoInTrunk = 0xB97160; // "private void PutCargoInTrunk()"
            inline constexpr std::uintptr_t TakeCargo = 0xB97500; // "private void TakeCargo()"
            inline constexpr std::uintptr_t RepairTrunk = 0xB97420; // "private void RepairTrunk()"
            inline constexpr std::uintptr_t BreachTrunk = 0xB963C0; // "private void BreachTrunk()"
            inline constexpr std::uintptr_t UnavailableBreachTrunk = 0xB97800; // "private void UnavailableBreachTrunk()"
            inline constexpr std::uintptr_t UnavailableBreachTrunkCitizen = 0xB97780; // "private void UnavailableBreachTrunkCitizen()"
            inline constexpr std::uintptr_t UnavailableInteractionTrunk = 0xB97880; // "private void UnavailableInteractionTrunk()"
            inline constexpr std::uintptr_t HasAccessToTrunk = 0xB96A40; // "public bool HasAccessToTrunk()"
            inline constexpr std::uintptr_t IsOwnerTrunk = 0xB96D80; // "public bool IsOwnerTrunk()"
        }
    } // namespace CarTrunkTargetActions

    namespace CarTrunkTargetProvider { // "Game.Battle.Entities.Car.CarTrunkTargetProvider (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleModel = 0x20; // "BattleModel"
            inline constexpr std::uintptr_t targetActions = 0x28; // "CarTrunkTargetActions"
            inline constexpr std::uintptr_t breachStateEntityModel = 0x30; // "BreachStateEntityModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x38; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t carInventoryModel = 0x40; // "CarInventoryModel"
            inline constexpr std::uintptr_t carServerModel = 0x48; // "CarModel"
            inline constexpr std::uintptr_t unavailableKeys = 0x50; // "UnavailableTargetActionsKeys"
            inline constexpr std::uintptr_t vehicleTrunkBreachItems = 0x58; // "IEnumerable<InventoryItemDescription>"
            inline constexpr std::uintptr_t breachUnavailableByItem = 0x60; // "LocalizedString"
            inline constexpr std::uintptr_t worldEntitiesModel = 0x68; // "WorldEntitiesModel"
            inline constexpr std::uintptr_t battleMode = 0x70; // "BattleModeDescription"
            inline constexpr std::uintptr_t clanModel = 0x78; // "ClanModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t GetTargetAction = 0xB99320; // "protected override ITargetAction GetTargetAction()"
            inline constexpr std::uintptr_t UpdateBreachTrunk = 0xB99AE0; // "private void UpdateBreachTrunk(bool isKnocked)"
        }
    } // namespace CarTrunkTargetProvider

    namespace CarTrunkUpdater { // "Game.Battle.Entities.Car.CarTrunkUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t updaters = 0x10; // "IUpdater"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB99F00; // "public void Update()"
        }
    } // namespace CarTrunkUpdater

    namespace CarUndercarriageTargetActions { // "Game.Battle.Entities.Car.CarUndercarriageTargetActions (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t vehicleId = 0x10; // "int"
            inline constexpr std::uintptr_t carUpgradesHolderOpenModel = 0x18; // "CarUpgradesHolderOpenModel"
            inline constexpr std::uintptr_t worldEntitiesModel = 0x20; // "WorldEntitiesModel"
            inline constexpr std::uintptr_t settlementHelperModel = 0x28; // "ISettlementHelperModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x30; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t personalNotificationModel = 0x38; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t uiSoundModel = 0x40; // "GlobalUISoundModel"
            inline constexpr std::uintptr_t Open = 0x48; // "TargetAction"
        }
        namespace Methods {
            inline constexpr std::uintptr_t OpenUnderCarriage = 0xB9A880; // "private void OpenUnderCarriage()"
            inline constexpr std::uintptr_t Unavailable = 0xAE9B20; // "private void Unavailable(LocalizedString invalidNotification, PersonalNotificationActionIds id)"
            inline constexpr std::uintptr_t HasAccess = 0xB9A6C0; // "public bool HasAccess()"
        }
    } // namespace CarUndercarriageTargetActions

    namespace CarUpgradeConfig { // "Models.References.Car.Settings.CarUpgradeConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t MaxAdditionalTrunkCargoSlots = 0x10; // "int"
            inline constexpr std::uintptr_t MaxAdditionalTrunkInventoryLines = 0x14; // "int"
        }
    } // namespace CarUpgradeConfig

    namespace CarUpgradeDescription { // "Models.References.Car.Upgrades.CarUpgradeDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t HolderType = 0x20; // "CarUpgradesHolderTypeDescription"
            inline constexpr std::uintptr_t ItemFunc = 0x28; // "Func<InventoryItemDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Item = 0x993E50; // "public InventoryItemDescription get_Item()"
        }
    } // namespace CarUpgradeDescription

    namespace CarUpgradeDialogSlotView { // "Game.Battle.CarUpgrades.CarUpgradeDialogSlotView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t UpgradeType = 0x20; // "CarUpgradeType"
            inline constexpr std::uintptr_t SlotIndex = 0x24; // "int"
            inline constexpr std::uintptr_t icon = 0x28; // "Image"
            inline constexpr std::uintptr_t emptyIcon = 0x30; // "Image"
            inline constexpr std::uintptr_t glow = 0x38; // "Image"
            inline constexpr std::uintptr_t rareView = 0x40; // "LineAndBackgroundRareView"
            inline constexpr std::uintptr_t DraggableItemView = 0x48; // "DraggableItemView"
            inline constexpr std::uintptr_t PointerButtonView = 0x50; // "PointerButtonView"
            inline constexpr std::uintptr_t DropAreaView = 0x58; // "DropAreaView"
            inline constexpr std::uintptr_t InventorySlotGlowView = 0x60; // "InventorySlotGlowView"
            inline constexpr std::uintptr_t SlotBlockedView = 0x68; // "SlotBlockedView"
            inline constexpr std::uintptr_t SlotLockedView = 0x70; // "SlotLockedView"
            inline constexpr std::uintptr_t glowEnabled = 0x78; // "bool"
            inline constexpr std::uintptr_t itemSprite = 0x80; // "Sprite"
            inline constexpr std::uintptr_t itemRarity = 0x88; // "RarityItem"
            inline constexpr std::uintptr_t isShow = 0x8C; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetGlowEnable = 0xD385A0; // "public void SetGlowEnable(bool enable)"
            inline constexpr std::uintptr_t Show = 0xD385E0; // "public void Show(Sprite sprite, RarityItem rarity)"
            inline constexpr std::uintptr_t Hide = 0xD384E0; // "public void Hide()"
        }
    } // namespace CarUpgradeDialogSlotView

    namespace CarUpgradeEffectDescription { // "Models.References.Car.Upgrades.CarUpgradeEffectDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ForwardMaxVelocity = 0x10; // "float"
            inline constexpr std::uintptr_t DriveForceAcceleration = 0x14; // "float"
            inline constexpr std::uintptr_t FwLongFrictionStiffness = 0x18; // "float"
            inline constexpr std::uintptr_t FwLatFrictionStiffness = 0x1C; // "float"
            inline constexpr std::uintptr_t BwLongFrictionStiffness = 0x20; // "float"
            inline constexpr std::uintptr_t BwLatFrictionStiffness = 0x24; // "float"
            inline constexpr std::uintptr_t FwBlockFrictionStiffness = 0x28; // "float"
            inline constexpr std::uintptr_t BwBlockFrictionStiffness = 0x2C; // "float"
        }
    } // namespace CarUpgradeEffectDescription

    namespace CarUpgradeHoldersInteractPositionModelUpdater { // "Game.Battle.Entities.Car.CarUpgradeHoldersInteractPositionModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t positionHoodModel = 0x10; // "InteractPositionModel"
            inline constexpr std::uintptr_t positionUndercarriageModel = 0x18; // "InteractPositionModel"
            inline constexpr std::uintptr_t serverModel = 0x20; // "CarModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB9AB50; // "public void Update()"
        }
    } // namespace CarUpgradeHoldersInteractPositionModelUpdater

    namespace CarUpgradeItemsViewDescription { // "Game.Battle.CarUpgrades.CarUpgradeItemsViewDescription (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ecuCarUpgradeViewDescription = 0x18; // "EcuCarUpgradeViewDescription"
            inline constexpr std::uintptr_t engineCoolingCarUpgradeViewDescription = 0x20; // "EngineCoolingCarUpgradeViewDescription"
            inline constexpr std::uintptr_t policeRadioCarUpgradeViewDescription = 0x28; // "PoliceRadioCarUpgradeViewDescription"
            inline constexpr std::uintptr_t steeringRackCarUpgradeViewDescription = 0x30; // "SteeringRackCarUpgradeViewDescription"
            inline constexpr std::uintptr_t suspensionCarUpgradeViewDescription = 0x38; // "SuspensionCarUpgradeViewDescription"
            inline constexpr std::uintptr_t turbochargerCarUpgradeViewDescription = 0x40; // "TurbochargerCarUpgradeViewDescription"
            inline constexpr std::uintptr_t dictionary = 0x48; // "Dictionary<InventoryItemDescription, ValueTuple<CarUpgradeViewRarity, CarUpgradeViewProperty>>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t TryGetValue = 0xD38720; // "public bool TryGetValue(InventoryItemDescription description, out CarUpgradeViewRarity rarity, out CarUpgradeViewProperty upgradeStat)"
            inline constexpr std::uintptr_t TryInit = 0xD387C0; // "private void TryInit()"
        }
    } // namespace CarUpgradeItemsViewDescription

    namespace CarUpgradeItemTypeViewDescription { // "Game.Battle.ItemType.CarUpgradeItemTypeViewDescription (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t RarityDescriptions = 0x38; // "List<LocalizedString>"
            inline constexpr std::uintptr_t StatsStrength = 0x40; // "List<LocalizedString>"
            inline constexpr std::uintptr_t StatNames = 0x48; // "List<LocalizedString>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x3554A10; // "public override InventoryItemType get_Type()"
        }
    } // namespace CarUpgradeItemTypeViewDescription

    namespace CarUpgradesDescription { // "Models.References.Car.Upgrades.CarUpgradesDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t EcuCollection = 0x20; // "Lazy<IReadOnlyDictionary<EcuCarUpgradeDescription, CarUpgradeEffectDescription>>"
            inline constexpr std::uintptr_t EngineCoolingCollection = 0x28; // "Lazy<IReadOnlyDictionary<EngineCoolingCarUpgradeDescription, CarUpgradeEffectDescription>>"
            inline constexpr std::uintptr_t SteeringRackCollection = 0x30; // "Lazy<IReadOnlyDictionary<SteeringRackCarUpgradeDescription, CarUpgradeEffectDescription>>"
            inline constexpr std::uintptr_t SuspensionCollection = 0x38; // "Lazy<IReadOnlyDictionary<SuspensionCarUpgradeDescription, CarUpgradeEffectDescription>>"
            inline constexpr std::uintptr_t TurbochargerCollection = 0x40; // "Lazy<IReadOnlyDictionary<TurbochargerCarUpgradeDescription, CarUpgradeEffectDescription>>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Ecu = 0x4481640; // "public IReadOnlyDictionary<EcuCarUpgradeDescription, CarUpgradeEffectDescription> get_Ecu()"
            inline constexpr std::uintptr_t get_EngineCooling = 0x4481690; // "public IReadOnlyDictionary<EngineCoolingCarUpgradeDescription, CarUpgradeEffectDescription> get_EngineCooling()"
            inline constexpr std::uintptr_t get_SteeringRack = 0x44816E0; // "public IReadOnlyDictionary<SteeringRackCarUpgradeDescription, CarUpgradeEffectDescription> get_SteeringRack()"
            inline constexpr std::uintptr_t get_Suspension = 0x4481730; // "public IReadOnlyDictionary<SuspensionCarUpgradeDescription, CarUpgradeEffectDescription> get_Suspension()"
            inline constexpr std::uintptr_t get_Turbocharger = 0x4481780; // "public IReadOnlyDictionary<TurbochargerCarUpgradeDescription, CarUpgradeEffectDescription> get_Turbocharger()"
        }
    } // namespace CarUpgradesDescription

    namespace CarUpgradesExtension { // "Models.Utils.Extensions.Vehicles.Car.CarUpgradesExtension (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t GetForwardMaxVelocityWithUpgrades = 0x3954830; // "public static float GetForwardMaxVelocityWithUpgrades(CarHandling handling, CarUpgradesSettingsModel upgradesSettings, CarUpgradesSlotsModel upgradesSlots)"
            inline constexpr std::uintptr_t GetForwardMaxVelocityWithoutUpgrades = 0x3954870; // "public static float GetForwardMaxVelocityWithoutUpgrades(CarHandling handling)"
            inline constexpr std::uintptr_t GetForwardDriveForceAcceleration = 0x39547D0; // "public static float GetForwardDriveForceAcceleration(CarTransmissionSettingsModel transmissionSettings, CarUpgradesSettingsModel upgradesSettings, CarUpgradesSlotsModel upgradesSlots)"
            inline constexpr std::uintptr_t GetFWLongFrictionStiffness = 0x3954770; // "public static float GetFWLongFrictionStiffness(CarTireFrictionSettingsModel tireFrictionSettings, CarUpgradesSettingsModel upgradesSettings, CarUpgradesSlotsModel upgradesSlots)"
            inline constexpr std::uintptr_t GetFWLatFrictionStiffness = 0x3954710; // "public static float GetFWLatFrictionStiffness(CarTireFrictionSettingsModel tireFrictionSettings, CarUpgradesSettingsModel upgradesSettings, CarUpgradesSlotsModel upgradesSlots)"
            inline constexpr std::uintptr_t GetBWLongFrictionStiffness = 0x3953F90; // "public static float GetBWLongFrictionStiffness(CarTireFrictionSettingsModel tireFrictionSettings, CarUpgradesSettingsModel upgradesSettings, CarUpgradesSlotsModel upgradesSlots)"
            inline constexpr std::uintptr_t GetBWLatFrictionStiffness = 0x3953F30; // "public static float GetBWLatFrictionStiffness(CarTireFrictionSettingsModel tireFrictionSettings, CarUpgradesSettingsModel upgradesSettings, CarUpgradesSlotsModel upgradesSlots)"
            inline constexpr std::uintptr_t GetFWBlockFrictionStiffness = 0x39546B0; // "public static float GetFWBlockFrictionStiffness(CarTireFrictionSettingsModel tireFrictionSettings, CarUpgradesSettingsModel upgradesSettings, CarUpgradesSlotsModel upgradesSlots)"
            inline constexpr std::uintptr_t GetBWBlockFrictionStiffness = 0x3953ED0; // "public static float GetBWBlockFrictionStiffness(CarTireFrictionSettingsModel tireFrictionSettings, CarUpgradesSettingsModel upgradesSettings, CarUpgradesSlotsModel upgradesSlots)"
            inline constexpr std::uintptr_t CollectItemsAndUnsetUpgradeSlots = 0x3953700; // "public static void CollectItemsAndUnsetUpgradeSlots(CarUpgradesSlotsModel upgradesSlotsModel, List<InventoryItem> items)"
            inline constexpr std::uintptr_t CollectCarUpgradeSlotItemAndUnsetSlot_TSlot_TUpgrade_inst_1 = 0x156DB60; // "CarUpgradesExtension.CollectCarUpgradeSlotItemAndUnsetSlot<object, object>"
            inline constexpr std::uintptr_t CollectCarUpgradeSlotItemAndUnsetSlot_TSlot_TUpgrade_inst_2 = 0x156D6A0; // "CarUpgradesExtension.CollectCarUpgradeSlotItemAndUnsetSlot<__Il2CppFullySharedGenericType, __Il2CppFullySharedGenericType>"
            inline constexpr std::uintptr_t CollectCarUpgradeSlotItemAndUnsetSlot_T_inst_1 = 0x156DD40; // "CarUpgradesExtension.CollectCarUpgradeSlotItemAndUnsetSlot<object>"
            inline constexpr std::uintptr_t CollectCarUpgradeSlotItemAndUnsetSlot_T_inst_2 = 0x156D8B0; // "CarUpgradesExtension.CollectCarUpgradeSlotItemAndUnsetSlot<__Il2CppFullySharedGenericType>"
            inline constexpr std::uintptr_t TryGetCarUpgradeType = 0x3954F60; // "public static bool TryGetCarUpgradeType(InventoryItemDescription item, out CarUpgradeType carUpgradeType)"
            inline constexpr std::uintptr_t TryGetCarUpgradeDescription = 0x3954D60; // "public static bool TryGetCarUpgradeDescription(InventoryItemDescription item, out CarUpgradeDescription carUpgradeDescription)"
            inline constexpr std::uintptr_t GetAssetsValue = 0x3953CE0; // "public static int GetAssetsValue(CarUpgradesSlotsModel upgradesSlotsModel)"
            inline constexpr std::uintptr_t GetCarUpgradeSlotAssetValue_TSlot_TUpgrade_inst_1 = 0x156DEF0; // "CarUpgradesExtension.GetCarUpgradeSlotAssetValue<object, object>"
            // "CarUpgradesExtension.GetCarUpgradeSlotAssetValue<__Il2CppFullySharedGenericType, object>"
            inline constexpr std::uintptr_t GetCarUpgradeSlotAssetValue_T_inst_1 = 0x156E170; // "CarUpgradesExtension.GetCarUpgradeSlotAssetValue<object>"
            inline constexpr std::uintptr_t GetAdditionalInventoryLines = 0x3953AC0; // "public static int GetAdditionalInventoryLines(CarUpgradesSlotsModel upgradesSlotsModel)"
            inline constexpr std::uintptr_t GetAdditionalCargoInventorySlots = 0x39538A0; // "public static int GetAdditionalCargoInventorySlots(CarUpgradesSlotsModel upgradesSlotsModel)"
            inline constexpr std::uintptr_t UpdateAdditionalInventorySlotsAndLines = 0x39554E0; // "public static void UpdateAdditionalInventorySlotsAndLines(CarUpgradesSlotsModel upgradesSlotsModel, IPrimitiveModel<int> inventoryAdditionalLines, IPrimitiveModel<int> cargoInventoryAdditionalSlots)"
            inline constexpr std::uintptr_t Clear = 0x39535C0; // "public static void Clear(CarUpgradesSlotsModel upgradesSlotsModel, IPlotCarModel plotCarModel, WorldEntitiesModel worldEntitiesModel)"
            inline constexpr std::uintptr_t ClearUnavailable = 0x3953470; // "public static bool ClearUnavailable(CarUpgradesSlotsModel upgradesSlotsModel, CarDescription carDescription)"
            inline constexpr std::uintptr_t ClearUnavailable_2 = 0x39531C0; // "public static void ClearUnavailable(CarUpgradesSlotsModel upgradesSlotsModel, IPlotCarModel plotCarModel, WorldEntitiesModel worldEntitiesModel)"
            inline constexpr std::uintptr_t ClearSlotsFrom_TCarUpgradeSlotDescription_TCarUpgradeDescription_inst_1 = 0x156D4B0; // "CarUpgradesExtension.ClearSlotsFrom<object, object>"
            inline constexpr std::uintptr_t CanCarUseUpgradesHolder = 0x39530E0; // "public static bool CanCarUseUpgradesHolder(ICarUpgradeDescription carUpgradeDescription, PlayerBattleModel playerBattleModel, int carEntityId)"
            inline constexpr std::uintptr_t TryGetCarUpgradesData = 0x39551D0; // "public static bool TryGetCarUpgradesData(WorldEntitiesModel worldEntitiesModel, int entityId, out CarUpgradesSlotsModel upgradesSlotsModel, out UpgradesSlotsSource upgradesSlotsSource, out CarDescription carDescription)"
            inline constexpr std::uintptr_t TryGetUpgradeSlots = 0x3955330; // "private static bool TryGetUpgradeSlots(WorldEntitiesModel worldEntitiesModel, int entityId, out CarUpgradesSlotsModel upgradesSlotsModel, out UpgradesSlotsSource upgradesSlotsSource)"
            inline constexpr std::uintptr_t TryGetCarDescription = 0x3954C30; // "private static bool TryGetCarDescription(WorldEntitiesModel worldEntitiesModel, int entityId, out CarDescription carDescription)"
            inline constexpr std::uintptr_t SetCarUpgradesData = 0x3954890; // "public static void SetCarUpgradesData(CarUpgradesSlotsData data, CarUpgradesInfo info)"
            inline constexpr std::uintptr_t GetCarUpgradesInfoFromData = 0x3953FF0; // "public static CarUpgradesInfo GetCarUpgradesInfoFromData(CarUpgradesSlotsData data)"
            inline constexpr std::uintptr_t GetDefaultCarUpgradesInfo = 0x3954640; // "public static CarUpgradesInfo GetDefaultCarUpgradesInfo()"
            inline constexpr std::uintptr_t SetUpgrades = 0x3954A60; // "public static void SetUpgrades(CarUpgradesSlotsModel slotsModel, CarUpgradesInfo info)"
        }
    } // namespace CarUpgradesExtension

    namespace CarUpgradesHolderDialogDragAndDropUpdater { // "Game.Battle.CarUpgrades.CarUpgradesHolderDialogDragAndDropUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dragAndDropModel = 0x20; // "InventoryDragAndDropModel"
            inline constexpr std::uintptr_t itemMoveModel = 0x28; // "ItemMoveModel"
            inline constexpr std::uintptr_t playerClientModel = 0x30; // "PlayerClientModel"
            inline constexpr std::uintptr_t notificationError = 0x38; // "NotificationError"
            inline constexpr std::uintptr_t personalNotificationModel = 0x40; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t itemMoveContexts = 0x48; // "Dictionary<CarUpgradeDialogSlotView, CarUpgradeMoveContext>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xD39CE0; // "public CarUpgradesHolderDialogDragAndDropUpdater Init(InventoryModels inventoryModels, PlayerClientModel playerClientModel, NotificationError notificationError, PersonalNotificationModel personalNotificationModel, Dictionary<CarUpgradeDialogSlotView, CarUpgradeMoveContext> itemMoveContexts)"
            inline constexpr std::uintptr_t Dispose = 0xA0E680; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xD39D90; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t UpdateSlot = 0xD3A3C0; // "private void UpdateSlot(CarUpgradeDialogSlotView slot, CarUpgradeMoveContext moveContext)"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace CarUpgradesHolderDialogDragAndDropUpdater

    namespace CarUpgradesHolderDialogUpdater { // "Game.Battle.CarUpgrades.CarUpgradesHolderDialogUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t updaters = 0x20; // "List<IUpdater>"
            inline constexpr std::uintptr_t carUpgradesHolderOpenModel = 0x28; // "CarUpgradesHolderOpenModel"
            inline constexpr std::uintptr_t inventoryDialogModel = 0x30; // "InventoryDialogModel"
            inline constexpr std::uintptr_t playerBattleModel = 0x38; // "PlayerBattleModel"
            inline constexpr std::uintptr_t holderType = 0x40; // "CarUpgradesHolderTypeDescription"
            inline constexpr std::uintptr_t hoodUIDisposableContent = 0x48; // "IDisposable"
            inline constexpr std::uintptr_t isHolderOpened = 0x50; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xD3A8A0; // "public CarUpgradesHolderDialogUpdater Init(GlobalModel globalModel, BattleModel battleModel, GlobalScreenContent globalScreenContent, BattleScreenContent battleScreenContent, IBattleEntitiesModel battleEntitiesModel, UpdaterPool updaterPool, int vehicleId, CarSkinViewDescriptions carSkinViewDescriptions, InventoryDialogModel inventoryDialogModel, List<IUpdater> mainInputUpdaters, Transform canvasParent, CarUpgradesHolderTypeDescription holderType, IRegisterDisposable registerDisposable)"
            inline constexpr std::uintptr_t Dispose = 0xD3A7C0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xD3B870; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace CarUpgradesHolderDialogUpdater

    namespace CarUpgradesHolderExtensions { // "Models.Utils.Extensions.Vehicles.Car.CarUpgradesHolderExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t GetCarHoodWorldPosition = 0x3955680; // "public static Vector3 GetCarHoodWorldPosition(CarModel carModel)"
            inline constexpr std::uintptr_t GetPlotCarHoodWorldPosition = 0x3955CF0; // "public static Vector3 GetPlotCarHoodWorldPosition(IPlotCarModel plotCarModel)"
            inline constexpr std::uintptr_t GetCarUndercarriageWorldPosition = 0x39558E0; // "public static Vector3 GetCarUndercarriageWorldPosition(CarModel carModel)"
            inline constexpr std::uintptr_t GetPlotCarUndercarriageWorldPosition = 0x3955E90; // "public static Vector3 GetPlotCarUndercarriageWorldPosition(IPlotCarModel plotCarModel)"
            inline constexpr std::uintptr_t GetCarTrunkWorldPosition = 0x39557B0; // "public static Vector3 GetCarTrunkWorldPosition(CarModel carModel)"
            inline constexpr std::uintptr_t GetPlotCarTrunkWorldPosition = 0x3955DC0; // "public static Vector3 GetPlotCarTrunkWorldPosition(IPlotCarModel plotCarModel)"
            inline constexpr std::uintptr_t GetCarHolderWorldPosition = 0x3955580; // "private static Vector3 GetCarHolderWorldPosition(in Vector3 holderLocalPosition, VehicleTransformModel transformModel)"
            inline constexpr std::uintptr_t GetPlotCarHolderWorldPosition = 0x3955AD0; // "private static Vector3 GetPlotCarHolderWorldPosition(in Vector3 holderLocalPosition, IPlotVehicleTransformModel plotCarModel)"
            inline constexpr std::uintptr_t GetHolderWorldPosition = 0x3955A10; // "private static Vector3 GetHolderWorldPosition(in Vector3 holderLocalPosition, in Vector3 carPivotPosition, in Quaternion carPivotOrientation)"
        }
    } // namespace CarUpgradesHolderExtensions

    namespace CarUpgradesHolderMessage { // "Models.Messages.Vehicle.Car.CarUpgradesHolderMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t entityId = 0x20; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t holderType = 0x28; // "IPrimitiveData<CarUpgradesHolderTypeDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_EntityId = 0x49F00A0; // "public int get_EntityId()"
            inline constexpr std::uintptr_t get_HolderType = 0x49F00F0; // "public CarUpgradesHolderTypeDescription get_HolderType()"
        }
    } // namespace CarUpgradesHolderMessage

    namespace CarUpgradesHolderOpenModel { // "Game.Battle.Entities.Car.Models.CarUpgradesHolderOpenModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t EntityId = 0x10; // "int"
            inline constexpr std::uintptr_t NeedOpenHolder = 0x18; // "CarUpgradesHolderTypeDescription"
            inline constexpr std::uintptr_t NeedCloseHolder = 0x20; // "CarUpgradesHolderTypeDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Clear = 0xBAB5E0; // "public void Clear()"
        }
    } // namespace CarUpgradesHolderOpenModel

    namespace CarUpgradesHolderRestrictedCellsUpdater { // "Game.Battle.CarUpgrades.CarUpgradesHolderRestrictedCellsUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t hoodSlotsModel = 0x30; // "CarUpgradesSlotModel"
            inline constexpr std::uintptr_t holderType = 0x38; // "CarUpgradesHolderTypeDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xD3BBB0; // "public CarUpgradesHolderRestrictedCellsUpdater Init(BattleCharacterModel battleCharacterModel, CarUpgradesSlotModel hoodSlotsModel, RestrictedCellsModel restrictedCellsModel, CarUpgradesHolderTypeDescription holderType)"
            inline constexpr std::uintptr_t Dispose = 0xD3BA20; // "protected override void Dispose()"
            inline constexpr std::uintptr_t GetIsActive = 0xD3BA60; // "protected override bool GetIsActive(IInventoryItemModel itemModel)"
        }
    } // namespace CarUpgradesHolderRestrictedCellsUpdater

    namespace CarUpgradesHolderSlotItemsUpdater { // "Game.Battle.CarUpgrades.CarUpgradesHolderSlotItemsUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t contexts = 0x20; // "Dictionary<CarUpgradeDialogSlotView, CarUpgradeMoveContext>"
            inline constexpr std::uintptr_t descriptions = 0x28; // "Dictionary<CarUpgradeDialogSlotView, CarUpgradeDescription>"
            inline constexpr std::uintptr_t inventoryModels = 0x30; // "InventoryModels"
            inline constexpr std::uintptr_t tooltipMiniModel = 0x38; // "TooltipMiniModel"
            inline constexpr std::uintptr_t tooltipModel = 0x40; // "TooltipModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xD3BDF0; // "public CarUpgradesHolderSlotItemsUpdater Init(VehicleUpgradesDialogView uiView, Dictionary<CarUpgradeDialogSlotView, CarUpgradeMoveContext> itemMoveContexts, InventoryModels inventoryModels, TooltipMiniModel tooltipMiniModel, TooltipModel tooltipModel, CarUpgradesHolderTypeDescription holderType)"
            inline constexpr std::uintptr_t Dispose = 0xD3BC00; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xD3C010; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t UpdateState = 0xD3C330; // "private void UpdateState(CarUpgradeDialogSlotView slotView)"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace CarUpgradesHolderSlotItemsUpdater

    namespace CarUpgradesHolderTargetHintUpdater { // "Game.Battle.Entities.Car.CarUpgradesHolderTargetHintUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t targetHintModel = 0x10; // "TargetHintObjectsModel"
            inline constexpr std::uintptr_t inventoryDialogModel = 0x18; // "InventoryDialogModel"
            inline constexpr std::uintptr_t vehicleOwnersModel = 0x20; // "VehicleOwnersModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x28; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t settlementModel = 0x30; // "SettlementModel"
            inline constexpr std::uintptr_t entityId = 0x38; // "int"
            inline constexpr std::uintptr_t targetObject = 0x40; // "ITargetObject"
            inline constexpr std::uintptr_t isVisible = 0x48; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB9B060; // "public void Update()"
            inline constexpr std::uintptr_t IsPlayerVehicle = 0xB9AE90; // "private bool IsPlayerVehicle()"
        }
    } // namespace CarUpgradesHolderTargetHintUpdater

    namespace CarUpgradesHolderTargetProvider { // "Game.Battle.Entities.Car.CarUpgradesHolderTargetProvider (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleEntitiesModel = 0x20; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t carServerModel = 0x28; // "CarModel"
            inline constexpr std::uintptr_t targetActions = 0x30; // "ICarUpgradesHolderTargetActions"
            inline constexpr std::uintptr_t unavailableKeys = 0x38; // "UnavailableTargetActionsKeys"
            inline constexpr std::uintptr_t isPlotCar = 0x40; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t GetTargetAction = 0xB9B2B0; // "protected override ITargetAction GetTargetAction()"
        }
    } // namespace CarUpgradesHolderTargetProvider

    namespace CarUpgradesHolderTypeDescription { // "Models.Models.CarUpgradesHolderModel.CarUpgradesHolderTypeDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x818DC50; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t enum_id = 0x0; // "Enum<CarUpgradesHolderTypeDescription>"
            inline constexpr std::uintptr_t Hood = 0x8; // "CarUpgradesHolderTypeDescription"
            inline constexpr std::uintptr_t Undercarriage = 0x10; // "CarUpgradesHolderTypeDescription"
            inline constexpr std::uintptr_t Trunk = 0x18; // "CarUpgradesHolderTypeDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Enum = 0x4968E60; // "public static ReadOnlyEnum<CarUpgradesHolderTypeDescription> get_Enum()"
        }
    } // namespace CarUpgradesHolderTypeDescription

    namespace CarUpgradesHolderViewUpdater { // "Game.Battle.CarUpgrades.CarUpgradesHolderViewUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t upgradeSlots = 0x20; // "CarUpgradesSlotsModel"
            inline constexpr std::uintptr_t inventoryItemViewDescriptions = 0x28; // "InventoryItemViewDescriptions"
            inline constexpr std::uintptr_t uiSlots = 0x30; // "CarUpgradeDialogSlotView[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xD3C660; // "public CarUpgradesHolderViewUpdater Init(IBattleEntitiesModel battleEntitiesModel, VehicleUpgradesDialogView uiView, int vehicleId, CarSkinViewDescriptions carSkinViewDescriptions, CarUpgradesSlotsModel upgradeSlots, InventoryItemViewDescriptions inventoryItemViewDescriptions, CarUpgradesHolderTypeDescription holderType)"
            inline constexpr std::uintptr_t Dispose = 0x9F6DA0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xD3C7C0; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t GetCarDescription = 0xD3C470; // "private static CarDescription GetCarDescription(IBattleEntitiesModel battleEntitiesModel, int vehicleId)"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace CarUpgradesHolderViewUpdater

    namespace CarUpgradesInfo { // "Models.Models.CarSpawnUpgradesInfo.CarUpgradesInfo (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Alarm = 0x10; // "AlarmCarUpgradeDescription"
            inline constexpr std::uintptr_t PoliceRadio = 0x18; // "PoliceRadioCarUpgradeDescription"
            inline constexpr std::uintptr_t Horn = 0x20; // "HornCarUpgradeDescription"
            inline constexpr std::uintptr_t ECU = 0x28; // "EcuCarUpgradeDescription"
            inline constexpr std::uintptr_t Turbocharger = 0x30; // "TurbochargerCarUpgradeDescription"
            inline constexpr std::uintptr_t EngineCooling = 0x38; // "EngineCoolingCarUpgradeDescription"
            inline constexpr std::uintptr_t Nitro = 0x40; // "NitroCarUpgradeDescription"
            inline constexpr std::uintptr_t Suspension = 0x48; // "SuspensionCarUpgradeDescription"
            inline constexpr std::uintptr_t SteeringRack = 0x50; // "SteeringRackCarUpgradeDescription"
        }
    } // namespace CarUpgradesInfo

    namespace CarUpgradeSlotsViewDescription { // "Game.Battle.CarUpgrades.CarUpgradeSlotsViewDescription (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t list = 0x18; // "List<CarUpgradeSlotViewDescription>"
            inline constexpr std::uintptr_t dictionary = 0x20; // "Dictionary<CarUpgradeType, CarUpgradeSlotViewDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t AfterDeserialize = 0x7B3360; // "protected virtual void AfterDeserialize()"
            inline constexpr std::uintptr_t get_Item = 0xD39C90; // "public CarUpgradeSlotViewDescription get_Item(CarUpgradeType type)"
        }
    } // namespace CarUpgradeSlotsViewDescription

    namespace CarUpgradeSlotViewDescription { // "Game.Battle.CarUpgrades.CarUpgradeSlotViewDescription (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Type = 0x10; // "CarUpgradeType"
            inline constexpr std::uintptr_t MiniTooltipTitle = 0x18; // "LocalizedString"
        }
    } // namespace CarUpgradeSlotViewDescription

    namespace CarUpgradesRequestModelUpdater { // "Game.Battle.Entities.Car.CarUpgradesRequestModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t carUpgradesHolderOpenModel = 0x10; // "CarUpgradesHolderOpenModel"
            inline constexpr std::uintptr_t inventoryDialogModel = 0x18; // "InventoryDialogModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x20; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t roomConnectionsBattle = 0x28; // "IRoomConnection"
            inline constexpr std::uintptr_t prolongedActionProcessModel = 0x30; // "ProlongedActionProcessModel"
            inline constexpr std::uintptr_t carUpgradesHolderIdToClose = 0x38; // "int"
            inline constexpr std::uintptr_t isCarUpgradesHoldersPlotCar = 0x3C; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB9C9A0; // "public void Update()"
            inline constexpr std::uintptr_t TryCloseHood = 0xB9BF50; // "private void TryCloseHood()"
            inline constexpr std::uintptr_t TryOpenHood = 0xB9C3D0; // "private void TryOpenHood(bool isPlot)"
            inline constexpr std::uintptr_t SendOpenHoodFlag = 0xB9BAD0; // "private void SendOpenHoodFlag(int entityId)"
            inline constexpr std::uintptr_t SendOpenPlotHoodFlag = 0xB9BB90; // "private void SendOpenPlotHoodFlag(int entityId)"
            inline constexpr std::uintptr_t SendCloseHoodFlag = 0xB9B5F0; // "private void SendCloseHoodFlag(int entityId)"
            inline constexpr std::uintptr_t SendClosePlotHoodFlag = 0xB9B6C0; // "private void SendClosePlotHoodFlag(int entityId)"
            inline constexpr std::uintptr_t TryCloseUndercarriage = 0xB9C250; // "private void TryCloseUndercarriage()"
            inline constexpr std::uintptr_t TryOpenUndercarriage = 0xB9C7B0; // "private void TryOpenUndercarriage(bool isPlot)"
            inline constexpr std::uintptr_t SendOpenUndercarriageFlag = 0xB9BE90; // "private void SendOpenUndercarriageFlag(int entityId)"
            inline constexpr std::uintptr_t SendOpenPlotUndercarriageFlag = 0xB9BD10; // "private void SendOpenPlotUndercarriageFlag(int entityId)"
            inline constexpr std::uintptr_t SendCloseUndercarriageFlag = 0xB9BA00; // "private void SendCloseUndercarriageFlag(int entityId)"
            inline constexpr std::uintptr_t SendClosePlotUndercarriageFlag = 0xB9B860; // "private void SendClosePlotUndercarriageFlag(int entityId)"
            inline constexpr std::uintptr_t TryCloseTrunk = 0xB9C0D0; // "private void TryCloseTrunk()"
            inline constexpr std::uintptr_t TryOpenTrunk = 0xB9C5C0; // "private void TryOpenTrunk(bool isPlot)"
            inline constexpr std::uintptr_t SendOpenPlotTrunkFlag = 0xB9BC50; // "private void SendOpenPlotTrunkFlag(int vehicleId)"
            inline constexpr std::uintptr_t SendOpenTrunkFlag = 0xB9BDD0; // "private void SendOpenTrunkFlag(int vehicleId)"
            inline constexpr std::uintptr_t SendCloseTrunkFlag = 0xB9B930; // "private void SendCloseTrunkFlag(int entityId)"
            inline constexpr std::uintptr_t SendClosePlotTrunkFlag = 0xB9B790; // "private void SendClosePlotTrunkFlag(int entityId)"
        }
    } // namespace CarUpgradesRequestModelUpdater

    namespace CarUpgradesSettingsModel { // "Models.Models.CarUpgradesSettings.CarUpgradesSettingsModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t upgradesDescription = 0x10; // "CarUpgradesDescription"
            inline constexpr std::uintptr_t overrideModel = 0x18; // "CarUpgradesSettingsOverrideModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Ecu = 0x4969BC0; // "public IReadOnlyDictionary<EcuCarUpgradeDescription, CarUpgradeEffectDescription> get_Ecu()"
            inline constexpr std::uintptr_t get_EngineCooling = 0x4969C60; // "public IReadOnlyDictionary<EngineCoolingCarUpgradeDescription, CarUpgradeEffectDescription> get_EngineCooling()"
            inline constexpr std::uintptr_t get_SteeringRack = 0x4969D00; // "public IReadOnlyDictionary<SteeringRackCarUpgradeDescription, CarUpgradeEffectDescription> get_SteeringRack()"
            inline constexpr std::uintptr_t get_Suspension = 0x4969DA0; // "public IReadOnlyDictionary<SuspensionCarUpgradeDescription, CarUpgradeEffectDescription> get_Suspension()"
            inline constexpr std::uintptr_t get_Turbocharger = 0x4969E40; // "public IReadOnlyDictionary<TurbochargerCarUpgradeDescription, CarUpgradeEffectDescription> get_Turbocharger()"
            inline constexpr std::uintptr_t CalculateUpgradeForForwardMaxVelocity = 0x4969690; // "public float CalculateUpgradeForForwardMaxVelocity(CarUpgradesSlotsModel upgradesSlots)"
            inline constexpr std::uintptr_t CalculateUpgradeForDriveForceAcceleration = 0x4969210; // "public float CalculateUpgradeForDriveForceAcceleration(CarUpgradesSlotsModel upgradesSlots)"
            inline constexpr std::uintptr_t CalculateUpgradeForFWLongFrictionStiffness = 0x4969570; // "public float CalculateUpgradeForFWLongFrictionStiffness(CarUpgradesSlotsModel upgradesSlots)"
            inline constexpr std::uintptr_t CalculateUpgradeForFWLatFrictionStiffness = 0x4969450; // "public float CalculateUpgradeForFWLatFrictionStiffness(CarUpgradesSlotsModel upgradesSlots)"
            inline constexpr std::uintptr_t CalculateUpgradeForBWLongFrictionStiffness = 0x49690F0; // "public float CalculateUpgradeForBWLongFrictionStiffness(CarUpgradesSlotsModel upgradesSlots)"
            inline constexpr std::uintptr_t CalculateUpgradeForBWLatFrictionStiffness = 0x4968FD0; // "public float CalculateUpgradeForBWLatFrictionStiffness(CarUpgradesSlotsModel upgradesSlots)"
            inline constexpr std::uintptr_t CalculateUpgradeForFWBlockFrictionStiffness = 0x4969330; // "public float CalculateUpgradeForFWBlockFrictionStiffness(CarUpgradesSlotsModel upgradesSlots)"
            inline constexpr std::uintptr_t CalculateUpgradeForBWBlockFrictionStiffness = 0x4968EB0; // "public float CalculateUpgradeForBWBlockFrictionStiffness(CarUpgradesSlotsModel upgradesSlots)"
            inline constexpr std::uintptr_t GetUpgradesValue = 0x49697B0; // "private float GetUpgradesValue(CarUpgradesSlotsModel upgradesSlots, Func<CarUpgradeEffectDescription, float> upgradeValueFunc)"
            inline constexpr std::uintptr_t GetUpgradeValue_T_inst_1 = 0x156E450; // "CarUpgradesSettingsModel.GetUpgradeValue<object>"
            inline constexpr std::uintptr_t GetUpgradeValue_T_inst_2 = 0x156E210; // "CarUpgradesSettingsModel.GetUpgradeValue<__Il2CppFullySharedGenericType>"
        }
    } // namespace CarUpgradesSettingsModel

    namespace CarUpgradesSettingsOverrideData { // "Models.Data.SettingsOverride.Cars.CarUpgradesSettingsOverrideData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t DataVersion = 0x20; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t Ecu = 0x28; // "IPrimitiveData<byte[]>"
            inline constexpr std::uintptr_t EngineCooling = 0x30; // "IPrimitiveData<byte[]>"
            inline constexpr std::uintptr_t SteeringRack = 0x38; // "IPrimitiveData<byte[]>"
            inline constexpr std::uintptr_t Suspension = 0x40; // "IPrimitiveData<byte[]>"
            inline constexpr std::uintptr_t Turbocharger = 0x48; // "IPrimitiveData<byte[]>"
        }
    } // namespace CarUpgradesSettingsOverrideData

    namespace CarUpgradesSettingsOverrideModel { // "Models.Models.CarUpgradesSettingsOverride.CarUpgradesSettingsOverrideModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "CarUpgradesSettingsOverrideData"
            inline constexpr std::uintptr_t dataVersion = 0x18; // "int"
            inline constexpr std::uintptr_t ecu = 0x20; // "Dictionary<EcuCarUpgradeDescription, CarUpgradeEffectDescription>"
            inline constexpr std::uintptr_t engineCooling = 0x28; // "Dictionary<EngineCoolingCarUpgradeDescription, CarUpgradeEffectDescription>"
            inline constexpr std::uintptr_t steeringRack = 0x30; // "Dictionary<SteeringRackCarUpgradeDescription, CarUpgradeEffectDescription>"
            inline constexpr std::uintptr_t suspension = 0x38; // "Dictionary<SuspensionCarUpgradeDescription, CarUpgradeEffectDescription>"
            inline constexpr std::uintptr_t turbocharger = 0x40; // "Dictionary<TurbochargerCarUpgradeDescription, CarUpgradeEffectDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_OverrideEnabled = 0x496A720; // "public bool get_OverrideEnabled()"
            inline constexpr std::uintptr_t get_Ecu = 0x496A6E0; // "public IReadOnlyDictionary<EcuCarUpgradeDescription, CarUpgradeEffectDescription> get_Ecu()"
            inline constexpr std::uintptr_t get_EngineCooling = 0x496A700; // "public IReadOnlyDictionary<EngineCoolingCarUpgradeDescription, CarUpgradeEffectDescription> get_EngineCooling()"
            inline constexpr std::uintptr_t get_SteeringRack = 0x496A780; // "public IReadOnlyDictionary<SteeringRackCarUpgradeDescription, CarUpgradeEffectDescription> get_SteeringRack()"
            inline constexpr std::uintptr_t get_Suspension = 0x496A7A0; // "public IReadOnlyDictionary<SuspensionCarUpgradeDescription, CarUpgradeEffectDescription> get_Suspension()"
            inline constexpr std::uintptr_t get_Turbocharger = 0x496A7C0; // "public IReadOnlyDictionary<TurbochargerCarUpgradeDescription, CarUpgradeEffectDescription> get_Turbocharger()"
            inline constexpr std::uintptr_t SetOverrideData = 0x496A550; // "public void SetOverrideData(byte[] ecu, byte[] engineCooling, byte[] steeringRack, byte[] suspension, byte[] turbocharger)"
            inline constexpr std::uintptr_t AlignLocalVersionWithDataVersion = 0x4969EE0; // "private void AlignLocalVersionWithDataVersion()"
        }
    } // namespace CarUpgradesSettingsOverrideModel

    namespace CarUpgradesSlotModel { // "Game.Battle.CarUpgrades.CarUpgradesSlotModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsPlotCar = 0x10; // "bool"
            inline constexpr std::uintptr_t CarModel = 0x18; // "CarModel"
            inline constexpr std::uintptr_t PlotCarModel = 0x20; // "IPlotCarModel"
            inline constexpr std::uintptr_t InventoryModel = 0x28; // "IInventoryModel"
            inline constexpr std::uintptr_t CargoInventoryModel = 0x30; // "CargoInventoryModel"
            inline constexpr std::uintptr_t UpgradeSlotsModel = 0x38; // "CarUpgradesSlotsModel"
            inline constexpr std::uintptr_t VehicleEntityId = 0x40; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_InventorySettingsDescription = 0xD3C930; // "public VehicleTrunkInventorySettingsDescription get_InventorySettingsDescription()"
        }
    } // namespace CarUpgradesSlotModel

    namespace CarUpgradesSlotsData { // "Models.Data.Car.CarUpgradesSlotsData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Alarm = 0x20; // "IPrimitiveData<AlarmCarUpgradeDescription>"
            inline constexpr std::uintptr_t PoliceRadio = 0x28; // "IPrimitiveData<PoliceRadioCarUpgradeDescription>"
            inline constexpr std::uintptr_t Horn = 0x30; // "IPrimitiveData<HornCarUpgradeDescription>"
            inline constexpr std::uintptr_t ECU = 0x38; // "IPrimitiveData<EcuCarUpgradeDescription>"
            inline constexpr std::uintptr_t Turbocharger = 0x40; // "IPrimitiveData<TurbochargerCarUpgradeDescription>"
            inline constexpr std::uintptr_t EngineCooling = 0x48; // "IPrimitiveData<EngineCoolingCarUpgradeDescription>"
            inline constexpr std::uintptr_t Nitro = 0x50; // "IPrimitiveData<NitroCarUpgradeDescription>"
            inline constexpr std::uintptr_t Suspension = 0x58; // "IPrimitiveData<SuspensionCarUpgradeDescription>"
            inline constexpr std::uintptr_t SteeringRack = 0x60; // "IPrimitiveData<SteeringRackCarUpgradeDescription>"
            inline constexpr std::uintptr_t TrunkInventorySlots = 0x68; // "ReferenceMapData<TrunkInventoryCarUpgradeSlotDescription, IPrimitiveData<TrunkInventoryCarUpgradeDescription>>"
            inline constexpr std::uintptr_t TrunkCargoInventorySlots = 0x70; // "ReferenceMapData<TrunkCargoInventoryCarUpgradeSlotDescription, IPrimitiveData<TrunkCargoInventoryCarUpgradeDescription>>"
        }
    } // namespace CarUpgradesSlotsData

    namespace CarUpgradesSlotsModel { // "Models.Models.CarUpgradesSlots.CarUpgradesSlotsModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Data = 0x10; // "IData"
            inline constexpr std::uintptr_t Alarm = 0x18; // "IPrimitiveModel<AlarmCarUpgradeDescription>"
            inline constexpr std::uintptr_t PoliceRadio = 0x20; // "IPrimitiveModel<PoliceRadioCarUpgradeDescription>"
            inline constexpr std::uintptr_t Horn = 0x28; // "IPrimitiveModel<HornCarUpgradeDescription>"
            inline constexpr std::uintptr_t ECU = 0x30; // "IPrimitiveModel<EcuCarUpgradeDescription>"
            inline constexpr std::uintptr_t Turbocharger = 0x38; // "IPrimitiveModel<TurbochargerCarUpgradeDescription>"
            inline constexpr std::uintptr_t EngineCooling = 0x40; // "IPrimitiveModel<EngineCoolingCarUpgradeDescription>"
            inline constexpr std::uintptr_t Nitro = 0x48; // "IPrimitiveModel<NitroCarUpgradeDescription>"
            inline constexpr std::uintptr_t Suspension = 0x50; // "IPrimitiveModel<SuspensionCarUpgradeDescription>"
            inline constexpr std::uintptr_t SteeringRack = 0x58; // "IPrimitiveModel<SteeringRackCarUpgradeDescription>"
            inline constexpr std::uintptr_t TrunkInventorySlots = 0x60; // "ICarTrunkInventoryUpgradeSlotsModel<TrunkInventoryCarUpgradeSlotDescription, TrunkInventoryCarUpgradeDescription>"
            inline constexpr std::uintptr_t TrunkCargoInventorySlots = 0x68; // "ICarTrunkInventoryUpgradeSlotsModel<TrunkCargoInventoryCarUpgradeSlotDescription, TrunkCargoInventoryCarUpgradeDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Clear = 0x496A7E0; // "public void Clear()"
            inline constexpr std::uintptr_t Set = 0x496AD60; // "public void Set(CarUpgradesSlotsModel model)"
            inline constexpr std::uintptr_t Swap = 0x496B5E0; // "public void Swap(CarUpgradesSlotsModel model)"
            inline constexpr std::uintptr_t GetDescriptionByType = 0x496A890; // "public CarUpgradeDescription GetDescriptionByType(CarUpgradeType upgradeType, int slotIndex)"
            inline constexpr std::uintptr_t get_IsEmpty = 0x496BB60; // "public bool get_IsEmpty()"
            inline constexpr std::uintptr_t Set_2 = 0x496B000; // "private void Set(AlarmCarUpgradeDescription alarm, PoliceRadioCarUpgradeDescription policeRadio, HornCarUpgradeDescription horn, EcuCarUpgradeDescription ecu, TurbochargerCarUpgradeDescription turbocharger, EngineCoolingCarUpgradeDescription engineCooling, NitroCarUpgradeDescription nitro, SuspensionCarUpgradeDescription suspension, SteeringRackCarUpgradeDescription steeringRack)"
        }
    } // namespace CarUpgradesSlotsModel

    namespace CarUtils { // "Game.Battle.Entities.Car.CarUtils (Battle.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x818EAA8; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t carBoundsIncrease = 0x0; // "Vector3"
        }
        namespace Methods {
            inline constexpr std::uintptr_t TryGetCarBoundedTopThreshold = 0xB78150; // "public static bool TryGetCarBoundedTopThreshold(IBattleEntitiesModel battleEntitiesModel, Cinemachine3rdPersonFollow cameraFollow, float nextCameraPitch, float nextCameraYaw, out float boundedTopThreshold)"
        }
    } // namespace CarUtils

    namespace CarVelocityUpdater { // "Game.Battle.EntityModel.Car.CarVelocityUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t clientModel = 0x10; // "CarClientModel"
            inline constexpr std::uintptr_t tickPeriod = 0x18; // "int"
            inline constexpr std::uintptr_t position = 0x20; // "SetMovementModel"
            inline constexpr std::uintptr_t timeOffset = 0x28; // "TimelineTimeOffsetModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xCBED60; // "public void Update()"
        }
    } // namespace CarVelocityUpdater

    namespace CarViewDescription { // "Game.Battle.Car.CarViewDescription (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Identified = 0x10; // "IdentifiedProperty<CarDescription>"
            inline constexpr std::uintptr_t prefab = 0x18; // "AssetReference"
            inline constexpr std::uintptr_t exhaustSmokeVfx = 0x20; // "AssetReference"
            inline constexpr std::uintptr_t EntityView = 0x28; // "LoadedComponentContent<CarEntityView>"
            inline constexpr std::uintptr_t ExhaustSmoke = 0x30; // "PooledLoadedComponentContent<ExhaustSmokeVfx>"
            inline constexpr std::uintptr_t InteractDistance = 0x38; // "float"
            inline constexpr std::uintptr_t CameraMinDistance = 0x3C; // "float"
            inline constexpr std::uintptr_t WheelMaxRollPerFrame = 0x40; // "float"
            inline constexpr std::uintptr_t WheelRollSlippingAngularAcceleration = 0x44; // "float"
            inline constexpr std::uintptr_t WheelRollSlowDownAngularAcceleration = 0x48; // "float"
            inline constexpr std::uintptr_t ForwardAxleWheelsSuspensionVerticalOffset = 0x4C; // "float"
            inline constexpr std::uintptr_t BackwardAxleWheelsSuspensionVerticalOffset = 0x50; // "float"
            inline constexpr std::uintptr_t WheelsDefaultCamberAngleDegree = 0x54; // "float"
            inline constexpr std::uintptr_t WheelsDefaultCamberAngleRad = 0x58; // "float"
            inline constexpr std::uintptr_t Engine = 0x60; // "CarEngineViewDescription"
            inline constexpr std::uintptr_t CarType = 0x68; // "Switch"
            inline constexpr std::uintptr_t noDoorsSeats = 0x70; // "IdentifiedProperty<VehicleSeatSlotDescription>[]"
            inline constexpr std::uintptr_t CharacteristicSpeed = 0x78; // "float"
            inline constexpr std::uintptr_t CharacteristicAcceleration = 0x7C; // "float"
            inline constexpr std::uintptr_t CharacteristicHandling = 0x80; // "float"
            inline constexpr std::uintptr_t WheelDrive = 0x84; // "WheelDrive"
            inline constexpr std::uintptr_t SkidVelocityThreshold = 0x88; // "float"
            inline constexpr std::uintptr_t SlipAngleThreshold = 0x8C; // "float"
            inline constexpr std::uintptr_t SkidTrailLifetime = 0x90; // "float"
            inline constexpr std::uintptr_t DampingBySpeed = 0x98; // "AnimationCurve"
            inline constexpr std::uintptr_t CamberRadius = 0xA0; // "float"
            inline constexpr std::uintptr_t NoiseAmplitudeGainCurve = 0xA8; // "AnimationCurve"
            inline constexpr std::uintptr_t NoiseFrequencyGainCurve = 0xB0; // "AnimationCurve"
            inline constexpr std::uintptr_t noDoorsSeatsIds = 0xB8; // "HashSet<string>"
            inline constexpr std::uintptr_t SuspensionLimitCollisionThreshold = 0xC0; // "float"
            inline constexpr std::uintptr_t FarLODDistance = 0xC4; // "float"
            inline constexpr std::uintptr_t MidLODDistance = 0xC8; // "float"
            inline constexpr std::uintptr_t CloseLODDistance = 0xCC; // "float"
            inline constexpr std::uintptr_t Content = 0xD0; // "ILoadedContent[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Id = 0xAC0670; // "public string get_Id()"
            inline constexpr std::uintptr_t NeedCharacterDoorAnim = 0xAC01B0; // "public bool NeedCharacterDoorAnim(VehicleSeatSlotDescription seat)"
        }
    } // namespace CarViewDescription

    namespace CarViewDescriptions { // "Game.Battle.Car.CarViewDescriptions (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t UpLookPitchThreshold = 0x28; // "float"
            inline constexpr std::uintptr_t DownLookPitchThreshold = 0x2C; // "float"
            inline constexpr std::uintptr_t RPM = 0x30; // "RTPC"
            inline constexpr std::uintptr_t Power = 0x38; // "RTPC"
            inline constexpr std::uintptr_t Speed = 0x40; // "RTPC"
            inline constexpr std::uintptr_t Skidding = 0x48; // "RTPC"
            inline constexpr std::uintptr_t DopplerEffect = 0x50; // "RTPC"
            inline constexpr std::uintptr_t EngineEvent = 0x58; // "Event"
            inline constexpr std::uintptr_t GearEvent = 0x60; // "Event"
            inline constexpr std::uintptr_t CutoffEvent = 0x68; // "Event"
            inline constexpr std::uintptr_t CarTrunkEvent = 0x70; // "Event"
            inline constexpr std::uintptr_t CarHoodEvent = 0x78; // "Event"
            inline constexpr std::uintptr_t SkidRight = 0x80; // "Event"
            inline constexpr std::uintptr_t SkidLeft = 0x88; // "Event"
            inline constexpr std::uintptr_t SkidCenter = 0x90; // "Event"
            inline constexpr std::uintptr_t DoorSound = 0x98; // "Event"
            inline constexpr std::uintptr_t FlashlightSound = 0xA0; // "Event"
            inline constexpr std::uintptr_t HonkingTheCarHornSound = 0xA8; // "Event"
            inline constexpr std::uintptr_t AttemptToOpenClosedCarDoor = 0xB0; // "Event"
            inline constexpr std::uintptr_t RefillEquipEvent = 0xB8; // "Event"
            inline constexpr std::uintptr_t SpawnEvent = 0xC0; // "Event"
            inline constexpr std::uintptr_t IsCarOnGroundSwitch = 0xC8; // "Switch"
            inline constexpr std::uintptr_t IsCarInAirSwitch = 0xD0; // "Switch"
            inline constexpr std::uintptr_t IsCarTrunkOpenSwitch = 0xD8; // "Switch"
            inline constexpr std::uintptr_t IsCarTrunkClosedSwitch = 0xE0; // "Switch"
            inline constexpr std::uintptr_t IsCarHoodOpenSwitch = 0xE8; // "Switch"
            inline constexpr std::uintptr_t IsCarHoodClosedSwitch = 0xF0; // "Switch"
            inline constexpr std::uintptr_t PlayerIsInsideCarSwitch = 0xF8; // "Switch"
            inline constexpr std::uintptr_t PlayerIsNotInsideCarSwitch = 0x100; // "Switch"
            inline constexpr std::uintptr_t DropCargoToTrunk = 0x108; // "Event"
            inline constexpr std::uintptr_t CarEngineStart = 0x110; // "Event"
            inline constexpr std::uintptr_t CarEngineStop = 0x118; // "Event"
            inline constexpr std::uintptr_t CarEngineHeatedStop = 0x120; // "Event"
            inline constexpr std::uintptr_t TimeForHeat = 0x128; // "int"
            inline constexpr std::uintptr_t LeftWheel = 0x130; // "Event"
            inline constexpr std::uintptr_t RightWheel = 0x138; // "Event"
            inline constexpr std::uintptr_t BothWheels = 0x140; // "Event"
            inline constexpr std::uintptr_t VehicleSuspension = 0x148; // "Event"
            inline constexpr std::uintptr_t OpenCarSpoilerByMoreSpeed = 0x150; // "float"
            inline constexpr std::uintptr_t CloseCarSpoilerByLowSpeed = 0x154; // "float"
            inline constexpr std::uintptr_t CharacteristicMaxTrunk = 0x158; // "float"
            inline constexpr std::uintptr_t BreakLightSpeed = 0x15C; // "float"
            inline constexpr std::uintptr_t MaxTrunkCargoCapacity = 0x160; // "int"
            inline constexpr std::uintptr_t AccelerationEffectDistanceIncrease = 0x164; // "float"
            inline constexpr std::uintptr_t AccelerationEffectFovIncrease = 0x168; // "float"
            inline constexpr std::uintptr_t AccelerationEffectCameraHandIncrease = 0x16C; // "float"
            inline constexpr std::uintptr_t AccelerationEffectCameraNoiseAmplitudeGainIncrease = 0x170; // "float"
            inline constexpr std::uintptr_t AccelerationEffectCameraNoiseFrequencyGainIncrease = 0x174; // "float"
            inline constexpr std::uintptr_t NoiseAmplitudeChangeSpeed = 0x178; // "float"
            inline constexpr std::uintptr_t NoiseFrequencyBySpeed = 0x180; // "AnimationCurve"
            inline constexpr std::uintptr_t RPMFade = 0x188; // "AnimationCurve"
            inline constexpr std::uintptr_t MinZoom = 0x190; // "float"
            inline constexpr std::uintptr_t MaxZoom = 0x194; // "float"
            inline constexpr std::uintptr_t UpLookPitchThresholdLaptopView = 0x198; // "float"
            inline constexpr std::uintptr_t DownLookPitchThresholdLaptopView = 0x19C; // "float"
            inline constexpr std::uintptr_t vehicleParking = 0x1A0; // "AssetReference"
            inline constexpr std::uintptr_t GarageParking = 0x1A8; // "PooledLoadedComponentContent<GarageVehicleParkingView>"
            inline constexpr std::uintptr_t GarageParkingVisibleDistance = 0x1B0; // "float"
            inline constexpr std::uintptr_t garageSlotTarget = 0x1B8; // "AssetReference"
            inline constexpr std::uintptr_t GarageSlotTarget = 0x1C0; // "PooledLoadedComponentContent<GarageVehicleSlotTargetView>"
            inline constexpr std::uintptr_t BurnoutDelayedTs = 0x1C8; // "float"
            inline constexpr std::uintptr_t CollisionCarCameraSettings = 0x1D0; // "CarCameraSettings"
            inline constexpr std::uintptr_t LandingCarCameraSettings = 0x1D8; // "CarCameraSettings"
            inline constexpr std::uintptr_t LandingThreshold = 0x1E0; // "float"
            inline constexpr std::uintptr_t CoefExtraSpringLength = 0x1E4; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t AfterDeserialize = 0xAC0740; // "protected override void AfterDeserialize()"
        }
    } // namespace CarViewDescriptions

    namespace CarViewExtensions { // "Game.Battle.Entities.Car.CarViewExtensions (Battle.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t SetWheelTransformDataToView = 0xB9D140; // "public static void SetWheelTransformDataToView(CarEntityView view, bool isForward, bool isLeft, in Vector3 position, in Quaternion orientation)"
            inline constexpr std::uintptr_t SetWheelBrakeSupportTransformDataToView = 0xB9D020; // "public static void SetWheelBrakeSupportTransformDataToView(CarEntityView view, bool isForward, bool isLeft, in Vector3 position, in Quaternion orientation)"
        }
    } // namespace CarViewExtensions

    namespace CarVsCarBonnetToTrunkCollisionConfig { // "Models.References.Car.Collision.CarVsCarBonnetToTrunkCollisionConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t DirectionLimit = 0x10; // "float"
            inline constexpr std::uintptr_t TurnWheelsMinSpeedSum = 0x14; // "float"
            inline constexpr std::uintptr_t TurnWheelsMinContactSpeed = 0x18; // "float"
            inline constexpr std::uintptr_t TurnWheelsDuration = 0x20; // "long"
        }
    } // namespace CarVsCarBonnetToTrunkCollisionConfig

    namespace CarVsCarCollisionClientSystem { // "ClientCore.Systems.CarVsCarCollisionClientSystem (Client.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t predictedCars = 0x30; // "ReadOnly.Dictionary<int, CarModel>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t IsCanApplyTurnWheelsBonnetToTrunkCollisionEffect = 0xE52580; // "protected override bool IsCanApplyTurnWheelsBonnetToTrunkCollisionEffect(CarModel carWithTrunk)"
        }
    } // namespace CarVsCarCollisionClientSystem

    namespace CarVsCarCollisionServerSystem { // "Models.Systems.CarVsCarCollisionServerSystem (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t IsCanApplyTurnWheelsBonnetToTrunkCollisionEffect = 0x7D5050; // "protected override bool IsCanApplyTurnWheelsBonnetToTrunkCollisionEffect(CarModel carWithTrunk)"
        }
    } // namespace CarVsCarCollisionServerSystem

    namespace CarVsCarCollisionSystem { // "Models.Systems.CarVsCarCollisionSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t characters = 0x10; // "ReadOnly.Dictionary<int, BattleCharacterModel>"
            inline constexpr std::uintptr_t physicsSceneModel = 0x18; // "PhysicsSceneModel"
            inline constexpr std::uintptr_t carVsCarSpecialCollisions = 0x20; // "PhysicsLinkedListData<CarVsCarSpecialCollisionData>"
            inline constexpr std::uintptr_t random = 0x28; // "Random"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x3F88500; // "public void Update(ITick tick)"
            inline constexpr std::uintptr_t HandleCarVsCarCollision = 0x3F874F0; // "private void HandleCarVsCarCollision(long now, CarModel car1, CarModel car2, ref BroadPhaseContactData broadPhaseContact)"
            inline constexpr std::uintptr_t IsCanBeSpecialBonnetToTrunkCollision = 0x3F881B0; // "private bool IsCanBeSpecialBonnetToTrunkCollision(CarModel car1, CarModel car2)"
            inline constexpr std::uintptr_t IsBonnetToTrunkCollision = 0x3F87AF0; // "private bool IsBonnetToTrunkCollision(CarModel car1, CarModel car2, ref BroadPhaseContactData broadPhaseContact, out CarModel carWithBonnet, out CarModel carWithTrunk, out Vector3 contactNormal)"
            inline constexpr std::uintptr_t IsTurnWheelsBonnetToTrunkCollision = 0x3F88240; // "private bool IsTurnWheelsBonnetToTrunkCollision(CarModel carWithBonnet, CarModel carWithTrunk, in Vector3 contactNormal)"
            inline constexpr std::uintptr_t HandleTurnWheelsBonnetToTrunkCollision = 0x3F87990; // "private void HandleTurnWheelsBonnetToTrunkCollision(long now, CarModel carWithBonnet, CarModel carWithTrunk)"
            inline constexpr std::uintptr_t GetRandomInt = 0x3F87460; // "private int GetRandomInt(CarModel carModel)"
        }
    } // namespace CarVsCarCollisionSystem

    namespace CarVsCharacterCollisionKnockdownConfig { // "Models.References.Car.Collision.CarVsCharacterCollisionKnockdownConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t CharacterStartImpulseSpeed = 0x10; // "float"
        }
    } // namespace CarVsCharacterCollisionKnockdownConfig

    namespace CarWheelBurnoutStateTickDataModel { // "Models.Models.TickDataModels.Car.Wheel.CarWheelBurnoutStateTickDataModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsRotationAxis = 0x10; // "bool"
            inline constexpr std::uintptr_t IsRotationAxisPair = 0x11; // "bool"
            inline constexpr std::uintptr_t RotationNormalX = 0x14; // "float"
            inline constexpr std::uintptr_t RotationNormalY = 0x18; // "float"
            inline constexpr std::uintptr_t RotationNormalZ = 0x1C; // "float"
        }
    } // namespace CarWheelBurnoutStateTickDataModel

    namespace CarWheelClientData { // "Game.Battle.Entities.Car.Models.CarWheelClientData (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Description = 0x10; // "VehicleWheelDescription"
            inline constexpr std::uintptr_t SpringLength = 0x18; // "float"
            inline constexpr std::uintptr_t IsTouchGround = 0x1C; // "bool"
            inline constexpr std::uintptr_t GroundSurfaceType = 0x1D; // "byte"
            inline constexpr std::uintptr_t SlipRatio = 0x20; // "float"
            inline constexpr std::uintptr_t SlipRatioSign = 0x24; // "int"
            inline constexpr std::uintptr_t SlipAngle = 0x28; // "float"
            inline constexpr std::uintptr_t SlipAngleSign = 0x2C; // "int"
        }
    } // namespace CarWheelClientData

    namespace CarWheelData { // "Models.Data.Car.CarWheelData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t SpringLength = 0x20; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t IsTouchGround = 0x28; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t GroundSurfaceType = 0x30; // "IPrimitiveData<byte>"
            inline constexpr std::uintptr_t SlipRatio = 0x38; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t IsSlipRatioSignPositive = 0x40; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t SlipAngle = 0x48; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t IsSlipAngleSignPositive = 0x50; // "IPrimitiveData<bool>"
        }
    } // namespace CarWheelData

    namespace CarWheelFrictionTickDataModel { // "Models.Models.TickDataModels.Car.Wheel.CarWheelFrictionTickDataModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t LongFrictionCurve = 0x10; // "Curve"
            inline constexpr std::uintptr_t LatFrictionCurve = 0x18; // "Curve"
            inline constexpr std::uintptr_t LongFrictionStiffness = 0x20; // "float"
            inline constexpr std::uintptr_t LatFrictionStiffness = 0x24; // "float"
            inline constexpr std::uintptr_t BlockFrictionStiffness = 0x28; // "float"
            inline constexpr std::uintptr_t LinearVelocityAlongX = 0x2C; // "float"
            inline constexpr std::uintptr_t LinearVelocityAlongZ = 0x30; // "float"
            inline constexpr std::uintptr_t FakeAngularLinearVelocity = 0x34; // "float"
            inline constexpr std::uintptr_t UseCombinedFrictionType = 0x38; // "bool"
            inline constexpr std::uintptr_t UseBlockedFrictionType = 0x39; // "bool"
            inline constexpr std::uintptr_t UseBurnoutFrictionType = 0x3A; // "bool"
            inline constexpr std::uintptr_t FrictionForceX = 0x3C; // "float"
            inline constexpr std::uintptr_t FrictionForceY = 0x40; // "float"
            inline constexpr std::uintptr_t FrictionForceZ = 0x44; // "float"
            inline constexpr std::uintptr_t FrictionForwardSlipVelocity = 0x48; // "float"
            inline constexpr std::uintptr_t FrictionLateralSlipVelocity = 0x4C; // "float"
            inline constexpr std::uintptr_t FrictionMaxLongForce = 0x50; // "float"
            inline constexpr std::uintptr_t FrictionMaxLatForce = 0x54; // "float"
            inline constexpr std::uintptr_t SlipRatio = 0x58; // "float"
            inline constexpr std::uintptr_t SlipRatioSign = 0x5C; // "int"
            inline constexpr std::uintptr_t SlipAngle = 0x60; // "float"
            inline constexpr std::uintptr_t SlipAngleSign = 0x64; // "int"
            inline constexpr std::uintptr_t FrictionLongForce = 0x68; // "float"
            inline constexpr std::uintptr_t FrictionLatForce = 0x6C; // "float"
        }
    } // namespace CarWheelFrictionTickDataModel

    namespace CarWheelModel { // "Game.Battle.Entities.Car.Models.CarWheelModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t SkiddingModel = 0x10; // "CarWheelSkiddingModel"
            inline constexpr std::uintptr_t Amplitude = 0x18; // "float"
            inline constexpr std::uintptr_t NoisePointer = 0x1C; // "float"
            inline constexpr std::uintptr_t LastOffset = 0x20; // "float"
        }
    } // namespace CarWheelModel

    namespace CarWheelModel_2 { // "Models.Models.CarWheelModel.CarWheelModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Description = 0x10; // "VehicleWheelDescription"
            inline constexpr std::uintptr_t SpringLength = 0x18; // "VehicleWheelSpringModel"
            inline constexpr std::uintptr_t IsTouchGround = 0x20; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t GroundSurfaceType = 0x28; // "IPrimitiveModel<byte>"
            inline constexpr std::uintptr_t SlipRatio = 0x30; // "VehicleWheelSlipRatioModel"
            inline constexpr std::uintptr_t SlipAngle = 0x38; // "VehicleWheelSlipAngleModel"
            inline constexpr std::uintptr_t TickData = 0x40; // "CarWheelTickDataModel"
        }
    } // namespace CarWheelModel_2

    namespace CarWheelPositionEntityViewUpdater { // "Game.Battle.EntityModel.Car.Wheel.CarWheelPositionEntityViewUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t clientModel = 0x18; // "CarClientModel"
            inline constexpr std::uintptr_t view = 0x20; // "CarEntityView"
        }
        namespace Methods {
            inline constexpr std::uintptr_t InnerUpdate = 0xCBF3F0; // "protected override void InnerUpdate()"
            inline constexpr std::uintptr_t InnerStart = 0x7B3360; // "protected override void InnerStart()"
            inline constexpr std::uintptr_t InnerStop = 0x99FF30; // "protected override void InnerStop()"
            inline constexpr std::uintptr_t CalculateWheelAndBrakeSupportOrientation = 0xCBEFF0; // "private ValueTuple<Quaternion, Quaternion> CalculateWheelAndBrakeSupportOrientation(CarAxleClientModel axle, bool isLeft)"
        }
    } // namespace CarWheelPositionEntityViewUpdater

    namespace CarWheelRollEntityModelUpdater { // "Game.Battle.Entities.Car.CarWheelRollEntityModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t clientModel = 0x18; // "CarClientModel"
            inline constexpr std::uintptr_t carDescription = 0x20; // "CarDescription"
            inline constexpr std::uintptr_t suspensionSettings = 0x28; // "VehicleSuspensionSettingsModel"
            inline constexpr std::uintptr_t viewDescription = 0x30; // "CarViewDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t InnerUpdate = 0xB9D3D0; // "protected override void InnerUpdate()"
            inline constexpr std::uintptr_t InnerStart = 0x7B3360; // "protected override void InnerStart()"
            inline constexpr std::uintptr_t InnerStop = 0x7B3360; // "protected override void InnerStop()"
            inline constexpr std::uintptr_t UpdateAxleRoll = 0xB9D4C0; // "private void UpdateAxleRoll(CarWheelClientData leftWheelClientData, CarClientData clientData, CarAxleClientModel axleClientModel, in Vector3 carWorldLinearVelocity, float wheelRadius, bool isForward)"
            inline constexpr std::uintptr_t CalculateAxleRollAngularVelocity = 0xB9D1B0; // "private float CalculateAxleRollAngularVelocity(CarWheelClientData leftWheelClientData, CarDriveInputModel driveInput, CarAxleClientModel axleClientModel, in Vector3 carWorldLinearVelocity, float wheelRadius, bool isWarped, bool isForward)"
        }
    } // namespace CarWheelRollEntityModelUpdater

    namespace CarWheelRpmEntityModelUpdater { // "Game.Battle.Entities.Car.CarWheelRpmEntityModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t clientModel = 0x18; // "CarClientModel"
            inline constexpr std::uintptr_t carDescription = 0x20; // "CarDescription"
            inline constexpr std::uintptr_t suspensionSettings = 0x28; // "VehicleSuspensionSettingsModel"
            inline constexpr std::uintptr_t upgradesSlots = 0x30; // "CarUpgradesSlotsModel"
            inline constexpr std::uintptr_t viewDescription = 0x38; // "CarViewDescription"
            inline constexpr std::uintptr_t now = 0x40; // "ISetNow"
        }
        namespace Methods {
            inline constexpr std::uintptr_t InnerUpdate = 0xB9DB10; // "protected override void InnerUpdate()"
            inline constexpr std::uintptr_t InnerStart = 0x7B3360; // "protected override void InnerStart()"
            inline constexpr std::uintptr_t InnerStop = 0x7B3360; // "protected override void InnerStop()"
            inline constexpr std::uintptr_t CalculateAxleRpm = 0xB9D6E0; // "private float CalculateAxleRpm(CarDriveInputModel driveInput, CarAxleClientModel axleClientModel, in Vector3 carWorldLinearVelocity, float wheelRadius, bool isForward)"
            inline constexpr std::uintptr_t GetRpmByTime = 0xB9D9A0; // "private float GetRpmByTime(CarAxleClientModel axleClientModel)"
        }
    } // namespace CarWheelRpmEntityModelUpdater

    namespace CarWheels { // "Models.References.Car.CarTypes.CarWheels (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t CenterOfMassToWheelBaseCenterOffsetInLocalSpace = 0x10; // "Vector3"
            inline constexpr std::uintptr_t Values = 0x20; // "IReadOnlyList<VehicleWheelDescription>"
            inline constexpr std::uintptr_t DistanceFromCenterOfMassToForwardAxle = 0x28; // "float"
            inline constexpr std::uintptr_t DistanceFromCenterOfMassToBackwardAxle = 0x2C; // "float"
            inline constexpr std::uintptr_t EffectiveStaticModifierForForwardWheels = 0x30; // "float"
            inline constexpr std::uintptr_t EffectiveStaticModifierForBackwardWheels = 0x34; // "float"
            inline constexpr std::uintptr_t EffectiveStaticLoadOnForwardWheel = 0x38; // "float"
            inline constexpr std::uintptr_t EffectiveStaticLoadOnBackwardWheel = 0x3C; // "float"
            inline constexpr std::uintptr_t EffectiveStaticMassOnForwardWheel = 0x40; // "float"
            inline constexpr std::uintptr_t EffectiveStaticMassOnBackwardWheel = 0x44; // "float"
            inline constexpr std::uintptr_t VerticalDistanceFromPivotToGroundInRest = 0x48; // "float"
            inline constexpr std::uintptr_t HeightFromGroundInRest = 0x4C; // "float"
            inline constexpr std::uintptr_t VerticalLocalCenterFromGroundInRestRelativeToPivot = 0x50; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_FlWheel = 0x44990E0; // "public VehicleWheelDescription get_FlWheel()"
            inline constexpr std::uintptr_t get_FrWheel = 0x4499130; // "public VehicleWheelDescription get_FrWheel()"
            inline constexpr std::uintptr_t get_BlWheel = 0x4498FF0; // "public VehicleWheelDescription get_BlWheel()"
            inline constexpr std::uintptr_t get_BrWheel = 0x4499040; // "public VehicleWheelDescription get_BrWheel()"
            inline constexpr std::uintptr_t get_Count = 0x4499090; // "public int get_Count()"
            inline constexpr std::uintptr_t get_Item = 0x4499180; // "public VehicleWheelDescription get_Item(int index)"
            inline constexpr std::uintptr_t GetEnumerator = 0x4498B30; // "public IEnumerator<VehicleWheelDescription> GetEnumerator()"
            inline constexpr std::uintptr_t System_Collections_IEnumerable_GetEnumerator = 0x4498B30; // "private IEnumerator System.Collections.IEnumerable.GetEnumerator()"
        }
    } // namespace CarWheels

    namespace CarWheelsBaseDescription { // "Models.References.Car.CarWheelsBaseDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t WheelBaseLength = 0x20; // "float"
            inline constexpr std::uintptr_t WheelBaseWidth = 0x24; // "float"
            inline constexpr std::uintptr_t WheelBaseOffsetZ = 0x28; // "float"
        }
    } // namespace CarWheelsBaseDescription

    namespace CarWheelsModel { // "Game.Battle.Entities.Car.Models.CarWheelsModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ClientWheels = 0x10; // "CarWheelModel[]"
            inline constexpr std::uintptr_t ServerWheels = 0x18; // "ICarWheelModel[]"
            inline constexpr std::uintptr_t FlWheelModel = 0x20; // "CarWheelModel"
            inline constexpr std::uintptr_t FrWheelModel = 0x28; // "CarWheelModel"
            inline constexpr std::uintptr_t BlWheelModel = 0x30; // "CarWheelModel"
            inline constexpr std::uintptr_t BrWheelModel = 0x38; // "CarWheelModel"
            inline constexpr std::uintptr_t wheels = 0x40; // "Dictionary<ICarWheelModel, CarWheelModel>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t GetClientByServer = 0xBAD770; // "public CarWheelModel GetClientByServer(ICarWheelModel model)"
        }
    } // namespace CarWheelsModel

    namespace CarWheelsModel_2 { // "Models.Models.CarWheelsModel.CarWheelsModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t wheels = 0x10; // "List<ICarWheelModel>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Count = 0x496C450; // "public int get_Count()"
            inline constexpr std::uintptr_t get_Item = 0x496C530; // "public ICarWheelModel get_Item(int index)"
            inline constexpr std::uintptr_t get_FlWheel = 0x496C490; // "public ICarWheelModel get_FlWheel()"
            inline constexpr std::uintptr_t get_FrWheel = 0x496C4E0; // "public ICarWheelModel get_FrWheel()"
            inline constexpr std::uintptr_t get_BlWheel = 0x496C3B0; // "public ICarWheelModel get_BlWheel()"
            inline constexpr std::uintptr_t get_BrWheel = 0x496C400; // "public ICarWheelModel get_BrWheel()"
            inline constexpr std::uintptr_t GetEnumerator = 0x496BF40; // "public IEnumerator<ICarWheelModel> GetEnumerator()"
            inline constexpr std::uintptr_t System_Collections_IEnumerable_GetEnumerator = 0x496BF40; // "private IEnumerator System.Collections.IEnumerable.GetEnumerator()"
        }
    } // namespace CarWheelsModel_2

    namespace CarWheelsSuspensionLengthUpdater { // "Game.Battle.EntityModel.Car.CarWheelsSuspensionLengthUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t clientModel = 0x18; // "CarClientModel"
            inline constexpr std::uintptr_t suspensionSettings = 0x20; // "VehicleSuspensionSettingsModel"
            inline constexpr std::uintptr_t speed = 0x28; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t InnerUpdate = 0xCBFFC0; // "protected override void InnerUpdate()"
            inline constexpr std::uintptr_t InnerStart = 0xCBFE60; // "protected override void InnerStart()"
            inline constexpr std::uintptr_t InnerStop = 0xCBFF30; // "protected override void InnerStop()"
            inline constexpr std::uintptr_t UpdateRightWheelSpring = 0xCC0310; // "private void UpdateRightWheelSpring(CarAxleClientModel carAxleClientModel, float value)"
            inline constexpr std::uintptr_t UpdateLeftWheelSpring = 0xCC0270; // "private void UpdateLeftWheelSpring(CarAxleClientModel carAxleClientModel, float value)"
        }
    } // namespace CarWheelsSuspensionLengthUpdater

    namespace CarWheelStateEntityModelUpdater { // "Game.Battle.Entities.Car.CarWheelStateEntityModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t clientModel = 0x10; // "CarClientModel"
            inline constexpr std::uintptr_t carDescription = 0x18; // "CarDescription"
            inline constexpr std::uintptr_t tireFrictionSettings = 0x20; // "CarTireFrictionSettingsModel"
            inline constexpr std::uintptr_t now = 0x28; // "ISetNow"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB9DEE0; // "public void Update()"
            inline constexpr std::uintptr_t UpdateAxleState = 0xB9DD10; // "private void UpdateAxleState(CarClientData carClientData, CarWheelClientData leftWheelClientData, CarWheelClientData rightWheelClientData, CarAxleClientModel axleClientModel, bool isForward)"
            inline constexpr std::uintptr_t IsWheelSlipping = 0xB9DCD0; // "private bool IsWheelSlipping(CarWheelClientData carWheelClientData)"
        }
    } // namespace CarWheelStateEntityModelUpdater

    namespace CarWheelSteeringOrientationEntityModelUpdater { // "Game.Battle.Entities.Car.CarWheelSteeringOrientationEntityModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t clientModel = 0x18; // "CarClientModel"
            inline constexpr std::uintptr_t suspensionSettings = 0x20; // "VehicleSuspensionSettingsModel"
            inline constexpr std::uintptr_t viewDescription = 0x28; // "CarViewDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t InnerUpdate = 0xB9E260; // "protected override void InnerUpdate()"
            inline constexpr std::uintptr_t UpdateSteering = 0xB9E790; // "private void UpdateSteering(float steeringAngle)"
            inline constexpr std::uintptr_t UpdateCamber = 0xB9E6C0; // "private void UpdateCamber(float pitch, float yaw, float roll)"
            inline constexpr std::uintptr_t UpdateAxleCamber = 0xB9E350; // "private void UpdateAxleCamber(CarAxleClientModel axleClientModel, in Quaternion centerOfMassOrientation)"
            inline constexpr std::uintptr_t InnerStart = 0x7B3360; // "protected override void InnerStart()"
            inline constexpr std::uintptr_t InnerStop = 0xB9E220; // "protected override void InnerStop()"
        }
    } // namespace CarWheelSteeringOrientationEntityModelUpdater

    namespace CarWheelTickDataModel { // "Models.Models.TickDataModels.Car.Wheel.CarWheelTickDataModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t WheelGroundTickData = 0x10; // "VehicleWheelGroundTickDataModel"
            inline constexpr std::uintptr_t WheelLoadTickData = 0x18; // "VehicleWheelLoadTickDataModel"
            inline constexpr std::uintptr_t WheelLinkTickData = 0x20; // "VehicleWheelLinkTickDataModel"
            inline constexpr std::uintptr_t WheelSuspensionLimitTickData = 0x28; // "VehicleWheelSuspensionLimitTickDataModel"
            inline constexpr std::uintptr_t WheelSuspensionTickData = 0x30; // "VehicleWheelSuspensionTickDataModel"
            inline constexpr std::uintptr_t WheelFrictionTickData = 0x38; // "CarWheelFrictionTickDataModel"
            inline constexpr std::uintptr_t WheelBurnoutTickData = 0x40; // "CarWheelBurnoutStateTickDataModel"
        }
    } // namespace CarWheelTickDataModel

    namespace CarWheelTimelineTickData { // "Models.Timeline.Data.Entity.CarWheelTimelineTickData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t SpringLength = 0x0; // "float"
            inline constexpr std::uintptr_t IsTouchGround = 0x4; // "bool"
            inline constexpr std::uintptr_t GroundSurfaceType = 0x5; // "byte"
            inline constexpr std::uintptr_t SlipRatio = 0x8; // "float"
            inline constexpr std::uintptr_t SlipRatioSign = 0xC; // "int"
            inline constexpr std::uintptr_t SlipAngle = 0x10; // "float"
            inline constexpr std::uintptr_t SlipAngleSign = 0x14; // "int"
        }
    } // namespace CarWheelTimelineTickData

    namespace CarWheelTransformEntityModelUpdater { // "Game.Battle.EntityModel.Car.Wheel.CarWheelTransformEntityModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t clientModel = 0x18; // "CarClientModel"
            inline constexpr std::uintptr_t model = 0x20; // "CarModel"
            inline constexpr std::uintptr_t viewDescription = 0x28; // "CarViewDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t InnerUpdate = 0xCBF6A0; // "protected override void InnerUpdate()"
            inline constexpr std::uintptr_t InnerStart = 0x7B3360; // "protected override void InnerStart()"
            inline constexpr std::uintptr_t InnerStop = 0x99FF30; // "protected override void InnerStop()"
            inline constexpr std::uintptr_t UpdateAxleTransform = 0xCBF920; // "private void UpdateAxleTransform(VehicleWheelDescription leftWheelDescription, VehicleWheelDescription rightWheelDescription, CarAxleClientModel axleClientModel, float suspensionVerticalOffset)"
            inline constexpr std::uintptr_t UpdateWheelsPosition = 0xCBF9C0; // "private void UpdateWheelsPosition(VehicleWheelDescription leftWheelDescription, VehicleWheelDescription rightWheelDescription, CarAxleClientModel axleClientModel, float suspensionVerticalOffset)"
        }
    } // namespace CarWheelTransformEntityModelUpdater

    namespace ChangeSelectedCarMessage { // "Models.Messages.ChangeSelectedCarMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t car = 0x20; // "IPrimitiveData<CarDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Car = 0x49EA6D0; // "public CarDescription get_Car()"
            inline constexpr std::uintptr_t get_Type = 0x49EA720; // "public override string get_Type()"
        }
    } // namespace ChangeSelectedCarMessage

    namespace ChangeSelectedHelicopterMessage { // "Models.Messages.ChangeSelectedHelicopterMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t helicopter = 0x20; // "IPrimitiveData<HelicopterDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Helicopter = 0x49EA990; // "public HelicopterDescription get_Helicopter()"
            inline constexpr std::uintptr_t get_Type = 0x49EA9E0; // "public override string get_Type()"
        }
    } // namespace ChangeSelectedHelicopterMessage

    namespace ChangeVehicleRadioStationMessage { // "Models.Messages.ChangeVehicleRadioStationMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t radioStation = 0x20; // "IPrimitiveData<RadioStationDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_RadioStation = 0x49EAF10; // "public RadioStationDescription get_RadioStation()"
            inline constexpr std::uintptr_t get_Type = 0x49EAFD0; // "public override string get_Type()"
        }
    } // namespace ChangeVehicleRadioStationMessage

    namespace ChangeVehicleTrunkEmptyFlagModel { // "Models.Models.CharacterVehicleTrunkModel.ChangeVehicleTrunkEmptyFlagModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t worldEntitiesModel = 0x10; // "WorldEntitiesModel"
            inline constexpr std::uintptr_t occupiedCharacterSlotsModel = 0x18; // "OccupiedCharacterSlotsModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t UpdateVehicleTrunkIsEmptyFlag = 0x49761A0; // "public void UpdateVehicleTrunkIsEmptyFlag(VehicleTrunkInventoriesModel vehicleTrunkInventoriesModel)"
            inline constexpr std::uintptr_t SetVehicleTrunkIsEmptyFlag = 0x4975E80; // "public void SetVehicleTrunkIsEmptyFlag(VehicleTrunkInventoriesModel vehicleTrunkInventoriesModel, bool value)"
            inline constexpr std::uintptr_t SetVehicleTrunkIsEmptyFlag_2 = 0x4975F10; // "public void SetVehicleTrunkIsEmptyFlag(IPrimitiveModel<bool> isTrunkEmptyModel, bool value)"
            inline constexpr std::uintptr_t TryGetVehicleEmptyFlagModel = 0x4975F90; // "private bool TryGetVehicleEmptyFlagModel(VehicleTrunkInventoriesModel vehicleTrunkInventoriesModel, out IPrimitiveModel<bool> isTrunkEmptyModel)"
        }
    } // namespace ChangeVehicleTrunkEmptyFlagModel

    namespace CharacterChangedCarUpgradesData { // "Models.Data.Vehicle.CharacterChangedCarUpgradesData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t CarUpgradesSlots = 0x20; // "CarUpgradesSlotsData"
            inline constexpr std::uintptr_t HasChanges = 0x28; // "IPrimitiveData<bool>"
        }
    } // namespace CharacterChangedCarUpgradesData

    namespace CharacterConstrictByRoof { // "Game.Battle.Entities.Player.Vehicle.Updaters.CharacterConstrictByRoof (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t inVehicleModel = 0x10; // "InVehicleModel"
            inline constexpr std::uintptr_t customizationModel = 0x18; // "CharacterCustomizationModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x20; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t carViews = 0x28; // "IReadOnlyDictionary<int, CarEntityView>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB03DF0; // "public void Update()"
            inline constexpr std::uintptr_t GetActualPositionAndNormal = 0xB03690; // "private ValueTuple<Vector3, Vector3> GetActualPositionAndNormal()"
        }
    } // namespace CharacterConstrictByRoof

    namespace CharacterInCarAnimationModel { // "Game.Battle.Entities.Player.Vehicle.Models.CharacterInVehicleAnimationModel.CharacterInCarAnimationModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t animationView = 0x10; // "CharacterAnimationView"
            inline constexpr std::uintptr_t vehicleSeatTypeViewDescriptions = 0x18; // "VehicleSeatTypeViewDescriptions"
            inline constexpr std::uintptr_t worldEntitiesModel = 0x20; // "WorldEntitiesModel"
            inline constexpr std::uintptr_t inVehicleModel = 0x28; // "InVehicleModel"
            inline constexpr std::uintptr_t now = 0x30; // "INow"
            inline constexpr std::uintptr_t car = 0x38; // "CarModel"
            inline constexpr std::uintptr_t isDriver = 0x40; // "bool"
            inline constexpr std::uintptr_t lookDirectionX = 0x44; // "float"
            inline constexpr std::uintptr_t lookDirectionZ = 0x48; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t OnVehicleEnter = 0xB047F0; // "public void OnVehicleEnter(bool hasAnim)"
            inline constexpr std::uintptr_t OnVehicleLeave = 0xB049B0; // "public void OnVehicleLeave()"
            inline constexpr std::uintptr_t OnUpdate = 0xB04610; // "public void OnUpdate()"
            inline constexpr std::uintptr_t TryGetVehicle = 0xB04A00; // "private bool TryGetVehicle(out CarModel carModel)"
            inline constexpr std::uintptr_t GetSeatType = 0xB045D0; // "private int GetSeatType(VehicleSeatsModel seats)"
        }
    } // namespace CharacterInCarAnimationModel

    namespace CharacterInHelicopterAnimationModel { // "Game.Battle.Entities.Player.Vehicle.Models.CharacterInVehicleAnimationModel.CharacterInHelicopterAnimationModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t animationView = 0x10; // "CharacterAnimationView"
            inline constexpr std::uintptr_t seatTypeViewDescriptions = 0x18; // "VehicleSeatTypeViewDescriptions"
            inline constexpr std::uintptr_t worldEntitiesModel = 0x20; // "WorldEntitiesModel"
            inline constexpr std::uintptr_t inVehicleModel = 0x28; // "InVehicleModel"
            inline constexpr std::uintptr_t helicopter = 0x30; // "HelicopterModel"
            inline constexpr std::uintptr_t isDriver = 0x38; // "bool"
            inline constexpr std::uintptr_t yaw = 0x3C; // "float"
            inline constexpr std::uintptr_t pitch = 0x40; // "float"
            inline constexpr std::uintptr_t roll = 0x44; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t OnVehicleEnter = 0xB04C70; // "public void OnVehicleEnter(bool hasAnim)"
            inline constexpr std::uintptr_t OnVehicleLeave = 0xB04E30; // "public void OnVehicleLeave()"
            inline constexpr std::uintptr_t OnUpdate = 0xB04AD0; // "public void OnUpdate()"
            inline constexpr std::uintptr_t TryGetVehicle = 0xB04E70; // "private bool TryGetVehicle(out HelicopterModel helicopterModel)"
            inline constexpr std::uintptr_t GetSeatType = 0xB045D0; // "private int GetSeatType(VehicleSeatsModel seats)"
        }
    } // namespace CharacterInHelicopterAnimationModel

    namespace CharacterInsideVehicleUpdateTransformSystem { // "Models.Systems.CharacterInsideVehicleUpdateTransformSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t vehicles = 0x38; // "VehiclesWorldModel"
            inline constexpr std::uintptr_t worldTickData = 0x40; // "WorldTickData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x40F37C0; // "protected override void Tick(ITick tick)"
        }
    } // namespace CharacterInsideVehicleUpdateTransformSystem

    namespace CharacterInsideVehicleUpdateVelocitySystem { // "Models.Systems.CharacterInsideVehicleUpdateVelocitySystem (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x40F3C50; // "protected override void Tick(ITick tick)"
        }
    } // namespace CharacterInsideVehicleUpdateVelocitySystem

    namespace CharacterInVehicleAnimationUpdater { // "Game.Battle.Entities.Player.Vehicle.Updaters.CharacterInVehicleAnimationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t stateModel = 0x10; // "IBattleCharacterStateModel"
            inline constexpr std::uintptr_t inVehicleModel = 0x18; // "InVehicleModel"
            inline constexpr std::uintptr_t worldEntitiesModel = 0x20; // "WorldEntitiesModel"
            inline constexpr std::uintptr_t carViewDescriptions = 0x28; // "CarViewDescriptions"
            inline constexpr std::uintptr_t helicopterViewDescriptions = 0x30; // "HelicopterViewDescriptions"
            inline constexpr std::uintptr_t missingVehicleReport = 0x38; // "CharacterInVehicleAnimationUpdater.MissingVehicleReport"
            inline constexpr std::uintptr_t state = 0x40; // "BattleCharacterState"
            inline constexpr std::uintptr_t inCarAnimationModel = 0x48; // "ICharacterInVehicleAnimationModel"
            inline constexpr std::uintptr_t inHelicopterAnimationModel = 0x50; // "ICharacterInVehicleAnimationModel"
            inline constexpr std::uintptr_t vehicleAnimation = 0x58; // "ICharacterInVehicleAnimationModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB05400; // "public void Update()"
            inline constexpr std::uintptr_t GetVehicleAnimationModel = 0xB04F40; // "private ICharacterInVehicleAnimationModel GetVehicleAnimationModel()"
            inline constexpr std::uintptr_t NeedAnimationForVehicleEnter = 0xB05150; // "private bool NeedAnimationForVehicleEnter()"
        }
    } // namespace CharacterInVehicleAnimationUpdater

    namespace CharacterInVehicleAnimationUpdater_MissingVehicleReport { // "Game.Battle.Entities.Player.Vehicle.Updaters.CharacterInVehicleAnimationUpdater.MissingVehicleReport (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t characterModel = 0x10; // "BattleCharacterModel"
            inline constexpr std::uintptr_t serverModel = 0x18; // "BattleCharacterModel"
            inline constexpr std::uintptr_t stateModel = 0x20; // "IBattleCharacterStateModel"
            inline constexpr std::uintptr_t inVehicleModel = 0x28; // "InVehicleModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x30; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t worldEntitiesModel = 0x38; // "WorldEntitiesModel"
            inline constexpr std::uintptr_t time = 0x40; // "TimeModel"
            inline constexpr std::uintptr_t createdTs = 0x48; // "long"
            inline constexpr std::uintptr_t report = 0x50; // "List<ValueTuple<string, object>>"
            inline constexpr std::uintptr_t vehicleEntityId = 0x58; // "int"
            inline constexpr std::uintptr_t startTs = 0x60; // "long"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Start = 0xB09980; // "public void Start(BattleCharacterState fromState)"
            inline constexpr std::uintptr_t Update = 0xB0A780; // "public void Update()"
            inline constexpr std::uintptr_t Finish = 0xB08EC0; // "private void Finish(string outcome)"
            inline constexpr std::uintptr_t IsVehicleFound = 0xB098F0; // "private bool IsVehicleFound()"
            inline constexpr std::uintptr_t IsPlayer = 0xB09860; // "private bool IsPlayer()"
            inline constexpr std::uintptr_t GetPlayerDistance = 0xB096E0; // "private float GetPlayerDistance()"
            inline constexpr std::uintptr_t GetServerTs = 0xB09800; // "private long GetServerTs()"
        }
    } // namespace CharacterInVehicleAnimationUpdater_MissingVehicleReport

    namespace CharacterInVehicleIKUpdater { // "Game.Battle.Entities.BattleCharacter.InVehicle.CharacterInVehicleIKUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t characterAnimationView = 0x10; // "CharacterWithWeaponAnimationView"
            inline constexpr std::uintptr_t stateModel = 0x18; // "IBattleCharacterStateModel"
            inline constexpr std::uintptr_t inVehicle = 0x20; // "InVehicleModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x28; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t carViews = 0x30; // "IReadOnlyDictionary<int, CarEntityView>"
            inline constexpr std::uintptr_t helicViews = 0x38; // "IReadOnlyDictionary<int, HelicopterEntityView>"
            inline constexpr std::uintptr_t isIKSetup = 0x40; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xBEA8C0; // "public void Update()"
            inline constexpr std::uintptr_t SetupInCarIK = 0xBEA580; // "private void SetupInCarIK()"
            inline constexpr std::uintptr_t SetupInHelicopterIK = 0xBEA720; // "private void SetupInHelicopterIK()"
            inline constexpr std::uintptr_t SetupIK = 0xBEA290; // "private void SetupIK(VehicleAnimationView vehicleAnimationView, VehicleSeatsModel seatsModel)"
        }
    } // namespace CharacterInVehicleIKUpdater

    namespace CharacterInVehiclesModel { // "Game.Battle.CharacterInVehiclesModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t VehicleCharacters = 0x10; // "Dictionary<int, HashSet<int>>"
            inline constexpr std::uintptr_t characterVehicle = 0x18; // "Dictionary<int, int>"
            inline constexpr std::uintptr_t charactersVehicleState = 0x20; // "Dictionary<int, CharacterInVehiclesModel.CharacterVehiclesState>"
            inline constexpr std::uintptr_t CharacterInVehicleIds = 0x28; // "ReadOnlyDictionaryNonAlloc<int, int>"
            inline constexpr std::uintptr_t VehicleVisible = 0x30; // "HashSet<int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Clear = 0xA4EB70; // "public void Clear()"
            inline constexpr std::uintptr_t GetCharactersVehicleState = 0xA4EBE0; // "public CharacterInVehiclesModel.CharacterVehiclesState GetCharactersVehicleState(int characterId)"
            inline constexpr std::uintptr_t RemoveCharacterVehicleState = 0xA4EC60; // "public void RemoveCharacterVehicleState(int characterId)"
            inline constexpr std::uintptr_t AddCharacterInVehicleState = 0xA4E880; // "public void AddCharacterInVehicleState(int characterId)"
            inline constexpr std::uintptr_t AddCharacterOutVehicleState = 0xA4EAA0; // "public void AddCharacterOutVehicleState(int characterId)"
            inline constexpr std::uintptr_t AddCharacterInVehicle = 0xA4E950; // "public void AddCharacterInVehicle(int characterId, int vehicleId)"
            inline constexpr std::uintptr_t RemoveCharacter = 0xA4ECC0; // "public void RemoveCharacter(int characterId)"
        }
    } // namespace CharacterInVehiclesModel

    namespace CharactersInVehiclesModelUpdater { // "Game.Battle.Player.CharactersInVehiclesModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleEntitiesModel = 0x10; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t charactersInVehiclesModel = 0x18; // "CharacterInVehiclesModel"
            inline constexpr std::uintptr_t removeIds = 0x20; // "List<int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x9617E0; // "public void Update()"
        }
    } // namespace CharactersInVehiclesModelUpdater

    namespace CharacterSpawnedVehicleData { // "Models.Data.CharacterSpawnedVehicleData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Car = 0x20; // "IPrimitiveData<CarDescription>"
            inline constexpr std::uintptr_t Helicopter = 0x28; // "IPrimitiveData<HelicopterDescription>"
            inline constexpr std::uintptr_t IsRented = 0x30; // "IPrimitiveData<bool>"
        }
    } // namespace CharacterSpawnedVehicleData

    namespace CharacterSpawnedVehicleModel { // "Models.Models.CharacterSpawnedVehicle.CharacterSpawnedVehicleModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t car = 0x10; // "IPrimitiveData<CarDescription>"
            inline constexpr std::uintptr_t helicopter = 0x18; // "IPrimitiveData<HelicopterDescription>"
            inline constexpr std::uintptr_t isRented = 0x20; // "IPrimitiveData<bool>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t HasSpawnedVehicle = 0x497C390; // "public bool HasSpawnedVehicle()"
            inline constexpr std::uintptr_t get_IsRented = 0x497CA20; // "public bool get_IsRented()"
            inline constexpr std::uintptr_t TryGetSpawnedCar = 0x497C760; // "public bool TryGetSpawnedCar(out CarDescription car)"
            inline constexpr std::uintptr_t TryGetSpawnedHelicopter = 0x497C840; // "public bool TryGetSpawnedHelicopter(out HelicopterDescription helicopter)"
            inline constexpr std::uintptr_t SetSpawnedVehicle = 0x497C690; // "public void SetSpawnedVehicle(CarDescription car, HelicopterDescription helicopter, bool isRented)"
            inline constexpr std::uintptr_t SetSpawnedCar = 0x497C550; // "public void SetSpawnedCar(CarDescription car, bool isRented)"
            inline constexpr std::uintptr_t SetSpawnedHelicopter = 0x497C5F0; // "public void SetSpawnedHelicopter(HelicopterDescription helicopter, bool isRented)"
            inline constexpr std::uintptr_t UnsetSpawnedVehicle = 0x497C920; // "public void UnsetSpawnedVehicle()"
        }
    } // namespace CharacterSpawnedVehicleModel

    namespace CharacterWarpInVehicleModelUpdater { // "Game.Battle.Entities.BattleCharacter.InVehicle.CharacterWarpInVehicleModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t inVehicleModel = 0x10; // "InVehicleModel"
            inline constexpr std::uintptr_t worldEntitiesModel = 0x18; // "WorldEntitiesModel"
            inline constexpr std::uintptr_t vehiclesModel = 0x20; // "VehiclesClientModel"
            inline constexpr std::uintptr_t setMovement = 0x28; // "SetMovementModel"
            inline constexpr std::uintptr_t setRotation = 0x30; // "IRotationModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xBECCC0; // "public void Update()"
        }
    } // namespace CharacterWarpInVehicleModelUpdater

    namespace CheatRemoveAllVehiclesWithoutOwnerMessage { // "Models.Messages.CheatRemoveAllVehiclesWithoutOwnerMessage (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x49F4830; // "public override string get_Type()"
        }
    } // namespace CheatRemoveAllVehiclesWithoutOwnerMessage

    namespace CheatSetCarBurnoutSettingsOverrideMessage { // "Models.Messages.CheatSetCarBurnoutSettingsOverrideMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t car = 0x20; // "IPrimitiveData<CarDescription>"
            inline constexpr std::uintptr_t burnoutStartMaxLinearVelocity = 0x28; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t burnoutStartMaxAngularVelocity = 0x30; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t burnoutMaxLinearVelocity = 0x38; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t burnoutMaxAngularVelocity = 0x40; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t torqueAcceleration = 0x48; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t rotationAxisPairFrictionStiffness = 0x50; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t outerFrictionStiffness = 0x58; // "IPrimitiveData<float>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x49F5DA0; // "public override string get_Type()"
            inline constexpr std::uintptr_t get_Car = 0x49F5C60; // "public CarDescription get_Car()"
            inline constexpr std::uintptr_t get_BurnoutStartMaxLinearVelocity = 0x49F5C10; // "public float get_BurnoutStartMaxLinearVelocity()"
            inline constexpr std::uintptr_t get_BurnoutStartMaxAngularVelocity = 0x49F5BC0; // "public float get_BurnoutStartMaxAngularVelocity()"
            inline constexpr std::uintptr_t get_BurnoutMaxLinearVelocity = 0x49F5B70; // "public float get_BurnoutMaxLinearVelocity()"
            inline constexpr std::uintptr_t get_BurnoutMaxAngularVelocity = 0x49F5B20; // "public float get_BurnoutMaxAngularVelocity()"
            inline constexpr std::uintptr_t get_TorqueAcceleration = 0x49F5D50; // "public float get_TorqueAcceleration()"
            inline constexpr std::uintptr_t get_RotationAxisPairFrictionStiffness = 0x49F5D00; // "public float get_RotationAxisPairFrictionStiffness()"
            inline constexpr std::uintptr_t get_OuterFrictionStiffness = 0x49F5CB0; // "public float get_OuterFrictionStiffness()"
        }
    } // namespace CheatSetCarBurnoutSettingsOverrideMessage

    namespace CheatSetCarEngineSettingsOverrideMessage { // "Models.Messages.CheatSetCarEngineSettingsOverrideMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t car = 0x20; // "IPrimitiveData<CarDescription>"
            inline constexpr std::uintptr_t startDuration = 0x28; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t stopDuration = 0x30; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t minNormalizedSpeedForHandling = 0x38; // "IPrimitiveData<float>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x49F6260; // "public override string get_Type()"
            inline constexpr std::uintptr_t get_Car = 0x49F6120; // "public CarDescription get_Car()"
            inline constexpr std::uintptr_t get_StartDuration = 0x49F61C0; // "public long get_StartDuration()"
            inline constexpr std::uintptr_t get_StopDuration = 0x49F6210; // "public long get_StopDuration()"
            inline constexpr std::uintptr_t get_MinNormalizedSpeedForHandling = 0x49F6170; // "public float get_MinNormalizedSpeedForHandling()"
        }
    } // namespace CheatSetCarEngineSettingsOverrideMessage

    namespace CheatSetCarPhysicsDragSettingsOverrideMessage { // "Models.Messages.CheatSetCarPhysicsDragSettingsOverrideMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t car = 0x20; // "IPrimitiveData<CarDescription>"
            inline constexpr std::uintptr_t notFullGroundedAngularDrag = 0x28; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t fullGroundedAngularDragZ = 0x30; // "IPrimitiveData<float>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x49F67A0; // "public override string get_Type()"
            inline constexpr std::uintptr_t get_Car = 0x49F66B0; // "public CarDescription get_Car()"
            inline constexpr std::uintptr_t get_NotFullGroundedAngularDrag = 0x49F6750; // "public float get_NotFullGroundedAngularDrag()"
            inline constexpr std::uintptr_t get_FullGroundedAngularDragZ = 0x49F6700; // "public float get_FullGroundedAngularDragZ()"
        }
    } // namespace CheatSetCarPhysicsDragSettingsOverrideMessage

    namespace CheatSetCarSteeringSettingsOverrideMessage { // "Models.Messages.CheatSetCarSteeringSettingsOverrideMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t car = 0x20; // "IPrimitiveData<CarDescription>"
            inline constexpr std::uintptr_t maxSteeringAngleBySignedLinearVelocityAlongZRatioCurve = 0x28; // "IPrimitiveData<byte[]>"
            inline constexpr std::uintptr_t maxSteeringAngle = 0x30; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t steeringAngleChangeSpeedBySignedLinearVelocityAlongZRatioCurve = 0x38; // "IPrimitiveData<byte[]>"
            inline constexpr std::uintptr_t steeringAngleChangeSpeed = 0x40; // "IPrimitiveData<float>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x49F6D00; // "public override string get_Type()"
            inline constexpr std::uintptr_t get_Car = 0x49F6B70; // "public CarDescription get_Car()"
            inline constexpr std::uintptr_t get_MaxSteeringAngleBySignedLinearVelocityAlongZRatioCurve = 0x49F6BC0; // "public byte[] get_MaxSteeringAngleBySignedLinearVelocityAlongZRatioCurve()"
            inline constexpr std::uintptr_t get_MaxSteeringAngle = 0x49F6C10; // "public float get_MaxSteeringAngle()"
            inline constexpr std::uintptr_t get_SteeringAngleChangeSpeedBySignedLinearVelocityAlongZRatioCurve = 0x49F6C60; // "public byte[] get_SteeringAngleChangeSpeedBySignedLinearVelocityAlongZRatioCurve()"
            inline constexpr std::uintptr_t get_SteeringAngleChangeSpeed = 0x49F6CB0; // "public float get_SteeringAngleChangeSpeed()"
        }
    } // namespace CheatSetCarSteeringSettingsOverrideMessage

    namespace CheatSetCarSuspensionSettingsOverrideMessage { // "Models.Messages.CheatSetCarSuspensionSettingsOverrideMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t car = 0x58; // "IPrimitiveData<CarDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t AddProperties = 0x49F6D30; // "private void AddProperties()"
            inline constexpr std::uintptr_t get_Type = 0x49F70A0; // "public override string get_Type()"
            inline constexpr std::uintptr_t get_Car = 0x49F7050; // "public CarDescription get_Car()"
        }
    } // namespace CheatSetCarSuspensionSettingsOverrideMessage

    namespace CheatSetCarTireFrictionSettingsOverrideMessage { // "Models.Messages.CheatSetCarTireFrictionSettingsOverrideMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t car = 0x20; // "IPrimitiveData<CarDescription>"
            inline constexpr std::uintptr_t fwLongFrictionCurve = 0x28; // "IPrimitiveData<byte[]>"
            inline constexpr std::uintptr_t fwLatFrictionCurve = 0x30; // "IPrimitiveData<byte[]>"
            inline constexpr std::uintptr_t fwFrictionStiffness = 0x38; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t fwBlockFrictionStiffness = 0x40; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t bwLongFrictionCurve = 0x48; // "IPrimitiveData<byte[]>"
            inline constexpr std::uintptr_t bwLatFrictionCurve = 0x50; // "IPrimitiveData<byte[]>"
            inline constexpr std::uintptr_t bwFrictionStiffness = 0x58; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t bwBlockFrictionStiffness = 0x60; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t frictionForceApplyOffsetYAlongLinkDirection = 0x68; // "IPrimitiveData<float>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x49F79E0; // "public override string get_Type()"
            inline constexpr std::uintptr_t get_Car = 0x49F7800; // "public CarDescription get_Car()"
            inline constexpr std::uintptr_t get_FWLongFrictionCurve = 0x49F7940; // "public byte[] get_FWLongFrictionCurve()"
            inline constexpr std::uintptr_t get_FWLatFrictionCurve = 0x49F78F0; // "public byte[] get_FWLatFrictionCurve()"
            inline constexpr std::uintptr_t get_FWFrictionStiffness = 0x49F78A0; // "public float get_FWFrictionStiffness()"
            inline constexpr std::uintptr_t get_FWBlockFrictionStiffness = 0x49F7850; // "public float get_FWBlockFrictionStiffness()"
            inline constexpr std::uintptr_t get_BWLongFrictionCurve = 0x49F77B0; // "public byte[] get_BWLongFrictionCurve()"
            inline constexpr std::uintptr_t get_BWLatFrictionCurve = 0x49F7760; // "public byte[] get_BWLatFrictionCurve()"
            inline constexpr std::uintptr_t get_BWFrictionStiffness = 0x49F7710; // "public float get_BWFrictionStiffness()"
            inline constexpr std::uintptr_t get_BWBlockFrictionStiffness = 0x49F76C0; // "public float get_BWBlockFrictionStiffness()"
            inline constexpr std::uintptr_t get_FrictionForceApplyOffsetYAlongLinkDirection = 0x49F7990; // "public float get_FrictionForceApplyOffsetYAlongLinkDirection()"
        }
    } // namespace CheatSetCarTireFrictionSettingsOverrideMessage

    namespace CheatSetCarTransmissionSettingsOverrideMessage { // "Models.Messages.CheatSetCarTransmissionSettingsOverrideMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t car = 0x20; // "IPrimitiveData<CarDescription>"
            inline constexpr std::uintptr_t forwardGears = 0x28; // "IPrimitiveData<byte[]>"
            inline constexpr std::uintptr_t driveForceAcceleration = 0x30; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t reverseDriveForceAcceleration = 0x38; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t brakeForceAcceleration = 0x40; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t gearShiftDuration = 0x48; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t gearShiftCooldown = 0x50; // "IPrimitiveData<long>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x49F8110; // "public override string get_Type()"
            inline constexpr std::uintptr_t get_Car = 0x49F7F30; // "public CarDescription get_Car()"
            inline constexpr std::uintptr_t get_ForwardGears = 0x49F7FD0; // "public byte[] get_ForwardGears()"
            inline constexpr std::uintptr_t get_DriveForceAcceleration = 0x49F7F80; // "public float get_DriveForceAcceleration()"
            inline constexpr std::uintptr_t get_ReverseDriveForceAcceleration = 0x49F80C0; // "public float get_ReverseDriveForceAcceleration()"
            inline constexpr std::uintptr_t get_BrakeForceAcceleration = 0x49F7EE0; // "public float get_BrakeForceAcceleration()"
            inline constexpr std::uintptr_t get_GearShiftDuration = 0x49F8070; // "public long get_GearShiftDuration()"
            inline constexpr std::uintptr_t get_GearShiftCooldown = 0x49F8020; // "public long get_GearShiftCooldown()"
        }
    } // namespace CheatSetCarTransmissionSettingsOverrideMessage

    namespace CheatSetCarUpgradesSettingsOverrideMessage { // "Models.Messages.CheatSetCarUpgradesSettingsOverrideMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t car = 0x20; // "IPrimitiveData<CarDescription>"
            inline constexpr std::uintptr_t ecu = 0x28; // "IPrimitiveData<byte[]>"
            inline constexpr std::uintptr_t engineCooling = 0x30; // "IPrimitiveData<byte[]>"
            inline constexpr std::uintptr_t steeringRack = 0x38; // "IPrimitiveData<byte[]>"
            inline constexpr std::uintptr_t suspension = 0x40; // "IPrimitiveData<byte[]>"
            inline constexpr std::uintptr_t turbocharger = 0x48; // "IPrimitiveData<byte[]>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x49F8710; // "public override string get_Type()"
            inline constexpr std::uintptr_t get_Car = 0x49F8530; // "public CarDescription get_Car()"
            inline constexpr std::uintptr_t get_Ecu = 0x49F8580; // "public byte[] get_Ecu()"
            inline constexpr std::uintptr_t get_EngineCooling = 0x49F85D0; // "public byte[] get_EngineCooling()"
            inline constexpr std::uintptr_t get_SteeringRack = 0x49F8620; // "public byte[] get_SteeringRack()"
            inline constexpr std::uintptr_t get_Suspension = 0x49F8670; // "public byte[] get_Suspension()"
            inline constexpr std::uintptr_t get_Turbocharger = 0x49F86C0; // "public byte[] get_Turbocharger()"
        }
    } // namespace CheatSetCarUpgradesSettingsOverrideMessage

    namespace CheatSetHelicopterChassisSettingsOverrideMessage { // "Models.Messages.CheatSetHelicopterChassisSettingsOverrideMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t helicopter = 0x20; // "IPrimitiveData<HelicopterDescription>"
            inline constexpr std::uintptr_t frictionAcceleration = 0x28; // "IPrimitiveData<float>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x49F92D0; // "public override string get_Type()"
            inline constexpr std::uintptr_t get_Helicopter = 0x49F9280; // "public HelicopterDescription get_Helicopter()"
            inline constexpr std::uintptr_t get_FrictionAcceleration = 0x49F9230; // "public float get_FrictionAcceleration()"
        }
    } // namespace CheatSetHelicopterChassisSettingsOverrideMessage

    namespace CheatSetHelicopterEngineSettingsOverrideMessage { // "Models.Messages.CheatSetHelicopterEngineSettingsOverrideMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t helicopter = 0x20; // "IPrimitiveData<HelicopterDescription>"
            inline constexpr std::uintptr_t startDuration = 0x28; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t stopDuration = 0x30; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t minNormalizedSpeedForHandling = 0x38; // "IPrimitiveData<float>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x49F9790; // "public override string get_Type()"
            inline constexpr std::uintptr_t get_Helicopter = 0x49F9650; // "public HelicopterDescription get_Helicopter()"
            inline constexpr std::uintptr_t get_StartDuration = 0x49F96F0; // "public long get_StartDuration()"
            inline constexpr std::uintptr_t get_StopDuration = 0x49F9740; // "public long get_StopDuration()"
            inline constexpr std::uintptr_t get_MinNormalizedSpeedForHandling = 0x49F96A0; // "public float get_MinNormalizedSpeedForHandling()"
        }
    } // namespace CheatSetHelicopterEngineSettingsOverrideMessage

    namespace CheatSetHelicopterHandlingSettingsOverrideMessage { // "Models.Messages.CheatSetHelicopterHandlingSettingsOverrideMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t helicopter = 0x20; // "IPrimitiveData<HelicopterDescription>"
            inline constexpr std::uintptr_t mainRotorCruiseAcceleration = 0x28; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t mainRotorThrustMaxAcceleration = 0x30; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t mainRotorThrustMaxDeceleration = 0x38; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t maxPositiveVerticalVelocity = 0x40; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t maxNegativeVerticalVelocity = 0x48; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t maxHeightSoft = 0x50; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t maxHeightHard = 0x58; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t linearVelocityDamping = 0x60; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t rotationResistanceAroundX = 0x68; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t rotationResistanceAroundY = 0x70; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t rotationResistanceAroundZ = 0x78; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t tiltAccelerationAroundX = 0x80; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t tiltAccelerationAroundZ = 0x88; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t rotationAccelerationAroundY = 0x90; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t maxTiltAngleCos = 0x98; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t tiltAdditionalForceModifier = 0xA0; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t sideSlipForceModifier = 0xA8; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t sideSlipTorqueModifier = 0xB0; // "IPrimitiveData<float>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x49FA830; // "public override string get_Type()"
            inline constexpr std::uintptr_t get_Helicopter = 0x49FA240; // "public HelicopterDescription get_Helicopter()"
            inline constexpr std::uintptr_t get_MainRotorCruiseAcceleration = 0x49FA2E0; // "public float get_MainRotorCruiseAcceleration()"
            inline constexpr std::uintptr_t get_MainRotorThrustMaxAcceleration = 0x49FA330; // "public float get_MainRotorThrustMaxAcceleration()"
            inline constexpr std::uintptr_t get_MainRotorThrustMaxDeceleration = 0x49FA380; // "public float get_MainRotorThrustMaxDeceleration()"
            inline constexpr std::uintptr_t get_MaxPositiveVerticalVelocity = 0x49FA4C0; // "public float get_MaxPositiveVerticalVelocity()"
            inline constexpr std::uintptr_t get_MaxNegativeVerticalVelocity = 0x49FA470; // "public float get_MaxNegativeVerticalVelocity()"
            inline constexpr std::uintptr_t get_MaxHeightSoft = 0x49FA420; // "public float get_MaxHeightSoft()"
            inline constexpr std::uintptr_t get_MaxHeightHard = 0x49FA3D0; // "public float get_MaxHeightHard()"
            inline constexpr std::uintptr_t get_LinearVelocityDamping = 0x49FA290; // "public float get_LinearVelocityDamping()"
            inline constexpr std::uintptr_t get_RotationResistanceAroundX = 0x49FA5B0; // "public float get_RotationResistanceAroundX()"
            inline constexpr std::uintptr_t get_RotationResistanceAroundY = 0x49FA600; // "public float get_RotationResistanceAroundY()"
            inline constexpr std::uintptr_t get_RotationResistanceAroundZ = 0x49FA650; // "public float get_RotationResistanceAroundZ()"
            inline constexpr std::uintptr_t get_TiltAccelerationAroundX = 0x49FA740; // "public float get_TiltAccelerationAroundX()"
            inline constexpr std::uintptr_t get_TiltAccelerationAroundZ = 0x49FA790; // "public float get_TiltAccelerationAroundZ()"
            inline constexpr std::uintptr_t get_RotationAccelerationAroundY = 0x49FA560; // "public float get_RotationAccelerationAroundY()"
            inline constexpr std::uintptr_t get_MaxTiltAngleCos = 0x49FA510; // "public float get_MaxTiltAngleCos()"
            inline constexpr std::uintptr_t get_TiltAdditionalForceModifier = 0x49FA7E0; // "public float get_TiltAdditionalForceModifier()"
            inline constexpr std::uintptr_t get_SideSlipForceModifier = 0x49FA6A0; // "public float get_SideSlipForceModifier()"
            inline constexpr std::uintptr_t get_SideSlipTorqueModifier = 0x49FA6F0; // "public float get_SideSlipTorqueModifier()"
        }
    } // namespace CheatSetHelicopterHandlingSettingsOverrideMessage

    namespace CheatSetHelicopterSuspensionSettingsOverrideMessage { // "Models.Messages.CheatSetHelicopterSuspensionSettingsOverrideMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t helicopter = 0x58; // "IPrimitiveData<HelicopterDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t AddProperties = 0x49FA860; // "private void AddProperties()"
            inline constexpr std::uintptr_t get_Type = 0x49FABD0; // "public override string get_Type()"
            inline constexpr std::uintptr_t get_Helicopter = 0x49FAB80; // "public HelicopterDescription get_Helicopter()"
        }
    } // namespace CheatSetHelicopterSuspensionSettingsOverrideMessage

    namespace CheatSetVehicleDrownedMessage { // "Models.Messages.Vehicle.CheatSetVehicleDrownedMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t vehicleEntityId = 0x20; // "BattleEntityIdData"
            inline constexpr std::uintptr_t drownedState = 0x28; // "IPrimitiveData<bool>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x49FBFC0; // "public override string get_Type()"
            inline constexpr std::uintptr_t get_VehicleEntityId = 0x49FBFF0; // "public int get_VehicleEntityId()"
            inline constexpr std::uintptr_t get_DrownedState = 0x49FBF70; // "public bool get_DrownedState()"
        }
    } // namespace CheatSetVehicleDrownedMessage

    namespace CheatSetVehicleMessage { // "Models.Messages.CheatSetVehicleMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t setPositionAndOrientation = 0x20; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t positionX = 0x28; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t positionY = 0x30; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t positionZ = 0x38; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t rotationEulerX = 0x40; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t rotationEulerY = 0x48; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t rotationEulerZ = 0x50; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t useLocalVelocities = 0x58; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t setLinearVelocity = 0x60; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t linearVelocityX = 0x68; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t linearVelocityY = 0x70; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t linearVelocityZ = 0x78; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t setAngularVelocity = 0x80; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t angularVelocityX = 0x88; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t angularVelocityY = 0x90; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t angularVelocityZ = 0x98; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t setForce = 0xA0; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t forceLocalArmX = 0xA8; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t forceLocalArmY = 0xB0; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t forceLocalArmZ = 0xB8; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t forceLocalX = 0xC0; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t forceLocalY = 0xC8; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t forceLocalZ = 0xD0; // "IPrimitiveData<float>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x49FD250; // "public override string get_Type()"
            inline constexpr std::uintptr_t get_SetPositionAndOrientation = 0x49FD200; // "public bool get_SetPositionAndOrientation()"
            inline constexpr std::uintptr_t get_Position = 0x49FD050; // "public Vector3 get_Position()"
            inline constexpr std::uintptr_t get_EulerRotation = 0x49FCD30; // "public Vector3 get_EulerRotation()"
            inline constexpr std::uintptr_t get_UseLocalVelocities = 0x49FD280; // "public bool get_UseLocalVelocities()"
            inline constexpr std::uintptr_t get_SetLinearVelocity = 0x49FD1B0; // "public bool get_SetLinearVelocity()"
            inline constexpr std::uintptr_t get_LinearVelocity = 0x49FCF90; // "public Vector3 get_LinearVelocity()"
            inline constexpr std::uintptr_t get_SetAngularVelocity = 0x49FD110; // "public bool get_SetAngularVelocity()"
            inline constexpr std::uintptr_t get_AngularVelocity = 0x49FCC60; // "public Vector3 get_AngularVelocity()"
            inline constexpr std::uintptr_t get_SetForce = 0x49FD160; // "public bool get_SetForce()"
            inline constexpr std::uintptr_t get_ForceLocalArm = 0x49FCDF0; // "public Vector3 get_ForceLocalArm()"
            inline constexpr std::uintptr_t get_ForceLocal = 0x49FCEC0; // "public Vector3 get_ForceLocal()"
        }
    } // namespace CheatSetVehicleMessage

    namespace CheatSetVehicleSuspensionSettingsOverrideMessage { // "Models.Messages.CheatSetVehicleSuspensionSettingsOverrideMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t suspensionRestLength = 0x20; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t suspensionUpperLimit = 0x28; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t suspensionLowerLimit = 0x30; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t suspensionSpringStiffnessPercent = 0x38; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t suspensionSpringDamperCompressionPercent = 0x40; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t suspensionSpringDamperReboundPercent = 0x48; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t wheelRadius = 0x50; // "IPrimitiveData<float>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_SuspensionRestLength = 0x49FD710; // "public float get_SuspensionRestLength()"
            inline constexpr std::uintptr_t get_SuspensionUpperLimit = 0x49FD850; // "public float get_SuspensionUpperLimit()"
            inline constexpr std::uintptr_t get_SuspensionLowerLimit = 0x49FD6C0; // "public float get_SuspensionLowerLimit()"
            inline constexpr std::uintptr_t get_SuspensionSpringStiffnessPercent = 0x49FD800; // "public float get_SuspensionSpringStiffnessPercent()"
            inline constexpr std::uintptr_t get_SuspensionSpringDamperCompressionPercent = 0x49FD760; // "public float get_SuspensionSpringDamperCompressionPercent()"
            inline constexpr std::uintptr_t get_SuspensionSpringDamperReboundPercent = 0x49FD7B0; // "public float get_SuspensionSpringDamperReboundPercent()"
            inline constexpr std::uintptr_t get_WheelRadius = 0x49FD8A0; // "public float get_WheelRadius()"
        }
    } // namespace CheatSetVehicleSuspensionSettingsOverrideMessage

    namespace CheatSpawnCarMessage { // "Models.Messages.CheatSpawnCarMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t description = 0x58; // "IPrimitiveData<CarDescription>"
            inline constexpr std::uintptr_t upgradesSlots = 0x60; // "CarUpgradesSlotsData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t AddData = 0x4A008D0; // "private void AddData()"
            inline constexpr std::uintptr_t get_Type = 0x4A00C30; // "public override string get_Type()"
            inline constexpr std::uintptr_t get_Description = 0x4A00BE0; // "public CarDescription get_Description()"
            inline constexpr std::uintptr_t get_UpgradesInfo = 0x4A00C60; // "public CarUpgradesInfo get_UpgradesInfo()"
        }
    } // namespace CheatSpawnCarMessage

    namespace CheatSpawnCarModel { // "Game.Battle.Cheats.CheatSpawnCarModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t isNeedSpawn = 0x10; // "bool"
            inline constexpr std::uintptr_t isRequested = 0x11; // "bool"
            inline constexpr std::uintptr_t Description = 0x18; // "CarDescription"
            inline constexpr std::uintptr_t TransformType = 0x20; // "CheatSpawnVehicleTransformType"
            inline constexpr std::uintptr_t CustomPosition = 0x24; // "Vector3"
            inline constexpr std::uintptr_t CustomOrientation = 0x30; // "Quaternion"
            inline constexpr std::uintptr_t UpgradesInfo = 0x40; // "CarUpgradesInfo"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsNeedSpawn = 0x8BC3A0; // "public bool get_IsNeedSpawn()"
            inline constexpr std::uintptr_t get_IsRequested = 0xA98B20; // "public bool get_IsRequested()"
            inline constexpr std::uintptr_t Spawn = 0xA71850; // "public void Spawn()"
            inline constexpr std::uintptr_t SetRequested = 0xA98AC0; // "public void SetRequested()"
            inline constexpr std::uintptr_t Clear = 0xD15670; // "public void Clear()"
        }
    } // namespace CheatSpawnCarModel

    namespace CheatSpawnHelicopterMessage { // "Models.Messages.CheatSpawnHelicopterMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t description = 0x58; // "IPrimitiveData<HelicopterDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t AddData = 0x4A01070; // "private void AddData()"
            inline constexpr std::uintptr_t get_Type = 0x4A01380; // "public override string get_Type()"
            inline constexpr std::uintptr_t get_Description = 0x4A01330; // "public HelicopterDescription get_Description()"
        }
    } // namespace CheatSpawnHelicopterMessage

    namespace CheatSpawnHelicopterModel { // "Game.Battle.Cheats.CheatSpawnHelicopterModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t isNeedSpawn = 0x10; // "bool"
            inline constexpr std::uintptr_t isRequested = 0x11; // "bool"
            inline constexpr std::uintptr_t Description = 0x18; // "HelicopterDescription"
            inline constexpr std::uintptr_t TransformType = 0x20; // "CheatSpawnVehicleTransformType"
            inline constexpr std::uintptr_t CustomPosition = 0x24; // "Vector3"
            inline constexpr std::uintptr_t CustomOrientation = 0x30; // "Quaternion"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsNeedSpawn = 0x8BC3A0; // "public bool get_IsNeedSpawn()"
            inline constexpr std::uintptr_t get_IsRequested = 0xA98B20; // "public bool get_IsRequested()"
            inline constexpr std::uintptr_t Spawn = 0xA71850; // "public void Spawn()"
            inline constexpr std::uintptr_t SetRequested = 0xA98AC0; // "public void SetRequested()"
            inline constexpr std::uintptr_t Clear = 0xD15670; // "public void Clear()"
        }
    } // namespace CheatSpawnHelicopterModel

    namespace CheatSpawnVehicleExtensions { // "Models.Cheats.CheatSpawnVehicleExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t CalculateSpawnPosition = 0x4ADB780; // "public static ValueTuple<Vector3, Quaternion> CalculateSpawnPosition(CheatSpawnVehicleTransformType transformType, LocationDescription location, BattleCharacterModel battleCharacter, in Vector3 customPosition, in Quaternion customOrientation)"
            inline constexpr std::uintptr_t CalculateClosestParkingSpawnPosition = 0x4ADB2F0; // "public static ValueTuple<Vector3, Quaternion> CalculateClosestParkingSpawnPosition(LocationDescription location, BattleCharacterModel battleCharacter)"
            inline constexpr std::uintptr_t FindAnyClosestLocationSpawnPoint = 0x4ADBAB0; // "private static ValueTuple<Vector3, Quaternion> FindAnyClosestLocationSpawnPoint(LocationDescription location, in Vector3 sourcePosition)"
            inline constexpr std::uintptr_t FindClosestSpawnPoint = 0x4ADBC60; // "private static ValueTuple<Vector3, Quaternion, float> FindClosestSpawnPoint(IReadOnlyList<LocationVehicleSpawnPointDescription> points, in Vector3 sourcePosition, in ValueTuple<Vector3, Quaternion, float> progress)"
            inline constexpr std::uintptr_t CalculateInFrontOfPlayerSpawnPosition = 0x4ADB570; // "public static ValueTuple<Vector3, Quaternion> CalculateInFrontOfPlayerSpawnPosition(BattleCharacterModel battleCharacter)"
        }
    } // namespace CheatSpawnVehicleExtensions

    namespace CheatSpawnVehicleMessage { // "Models.Messages.CheatSpawnVehicleMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t positionX = 0x20; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t positionY = 0x28; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t positionZ = 0x30; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t orientationX = 0x38; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t orientationY = 0x40; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t orientationZ = 0x48; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t orientationW = 0x50; // "IPrimitiveData<float>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Position = 0x4A01880; // "public Vector3 get_Position()"
            inline constexpr std::uintptr_t get_Orientation = 0x4A01780; // "public Quaternion get_Orientation()"
        }
    } // namespace CheatSpawnVehicleMessage

    namespace CheatTeleportSpawnedCarMessage { // "Models.Messages.CheatTeleportSpawnedCarMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t x = 0x20; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t y = 0x28; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t z = 0x30; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t ox = 0x38; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t oy = 0x40; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t oz = 0x48; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t ow = 0x50; // "IPrimitiveData<float>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x4A02A50; // "public override string get_Type()"
            inline constexpr std::uintptr_t get_X = 0x4A02A80; // "public float get_X()"
            inline constexpr std::uintptr_t get_Y = 0x4A02AD0; // "public float get_Y()"
            inline constexpr std::uintptr_t get_Z = 0x4A02B20; // "public float get_Z()"
            inline constexpr std::uintptr_t get_Ox = 0x4A02960; // "public float get_Ox()"
            inline constexpr std::uintptr_t get_Oy = 0x4A029B0; // "public float get_Oy()"
            inline constexpr std::uintptr_t get_Oz = 0x4A02A00; // "public float get_Oz()"
            inline constexpr std::uintptr_t get_Ow = 0x4A02910; // "public float get_Ow()"
        }
    } // namespace CheatTeleportSpawnedCarMessage

    namespace CheatUnlockCarMessage { // "Models.Messages.CheatUnlockCarMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t description = 0x20; // "IPrimitiveData<CarDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Description = 0x4A02F00; // "public CarDescription get_Description()"
            inline constexpr std::uintptr_t get_Type = 0x4A02F50; // "public override string get_Type()"
        }
    } // namespace CheatUnlockCarMessage

    namespace CheatUnlockHelicopterMessage { // "Models.Messages.CheatUnlockHelicopterMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t description = 0x20; // "IPrimitiveData<HelicopterDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Description = 0x4A031C0; // "public HelicopterDescription get_Description()"
            inline constexpr std::uintptr_t get_Type = 0x4A03210; // "public override string get_Type()"
        }
    } // namespace CheatUnlockHelicopterMessage

    namespace ClanBattleVehicleTeamOwnerModel { // "Models.Models.ClanBattleVehicleTeamOwner.ClanBattleVehicleTeamOwnerModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dataTeamOwner = 0x10; // "IPrimitiveData<ClanBattleTeamDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_TeamDescription = 0x4982060; // "public ClanBattleTeamDescription get_TeamDescription()"
            inline constexpr std::uintptr_t SetTeam = 0x4982010; // "public void SetTeam(ClanBattleTeamDescription team)"
            inline constexpr std::uintptr_t Clear = 0x4981FD0; // "public void Clear()"
        }
    } // namespace ClanBattleVehicleTeamOwnerModel

    namespace ClearBattleCharacterVehiclesInputSystem { // "Models.Systems.ClearBattleCharacterVehiclesInputSystem (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x40F4020; // "protected override void Tick(ITick tick)"
        }
    } // namespace ClearBattleCharacterVehiclesInputSystem

    namespace ClearCarTimelinesUpdater { // "Game.Battle.EntityModel.Car.ClearCarTimelinesUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t movementTimeline = 0x10; // "MovementTimeline"
            inline constexpr std::uintptr_t rotationTimeline = 0x18; // "RotationTimeline"
            inline constexpr std::uintptr_t time = 0x20; // "TimeModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xCC32A0; // "public void Update()"
        }
    } // namespace ClearCarTimelinesUpdater

    namespace ClearVehicleBreakableCollidersCollisionSystem { // "ClientCore.Systems.ClearVehicleBreakableCollidersCollisionSystem (Client.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t vehicleCollisionsWithBreakableCollidersModel = 0x10; // "IVehicleCollisionsWithBreakableCollidersModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xE52B00; // "public void Update(ITick tick)"
        }
    } // namespace ClearVehicleBreakableCollidersCollisionSystem

    namespace ClearVehiclesCollisionSystem { // "ClientCore.Systems.ClearVehiclesCollisionSystem (Client.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t vehiclesCollisionsModel = 0x10; // "IVehiclesCollisionsModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xE52B50; // "public void Update(ITick tick)"
        }
    } // namespace ClearVehiclesCollisionSystem

    namespace ClientCarControllerApplyCarInputByDriverSystem { // "Models.Systems.ClientCarControllerApplyCarInputByDriverSystem (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t UpdateImmunitiesDueToInputInVehicle = 0x7B3360; // "protected override void UpdateImmunitiesDueToInputInVehicle(VehicleSeatsModel vehicleSeatsModel, long now, ReadOnly.Dictionary<int, BattleCharacterModel> battleCharacters)"
        }
    } // namespace ClientCarControllerApplyCarInputByDriverSystem

    namespace ClientHelicopterControllerApplyHelicopterInputByDriverSystem { // "Models.Systems.ClientHelicopterControllerApplyHelicopterInputByDriverSystem (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t UpdateImmunitiesDueToInputInVehicle = 0x7B3360; // "protected override void UpdateImmunitiesDueToInputInVehicle(VehicleSeatsModel vehicleSeatsModel, long now, ReadOnly.Dictionary<int, BattleCharacterModel> battleCharacters)"
        }
    } // namespace ClientHelicopterControllerApplyHelicopterInputByDriverSystem

    namespace CloseCarUpgradesHolderMessage { // "Models.Messages.Vehicle.Car.CloseCarUpgradesHolderMessage (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x4A04410; // "public override string get_Type()"
        }
    } // namespace CloseCarUpgradesHolderMessage

    namespace ClosePlotCarUpgradesHolderMessage { // "Models.Messages.Vehicle.Car.ClosePlotCarUpgradesHolderMessage (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x4A04440; // "public override string get_Type()"
        }
    } // namespace ClosePlotCarUpgradesHolderMessage

    namespace CloseVehicleTrunkMessage { // "Models.Messages.CloseVehicleTrunkMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t entityId = 0x20; // "BattleEntityIdData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_EntityId = 0x4A04BC0; // "public int get_EntityId()"
            inline constexpr std::uintptr_t get_Type = 0x4A04C00; // "public override string get_Type()"
        }
    } // namespace CloseVehicleTrunkMessage

    namespace CollectVehicleCollisionsWithBreakableCollidersSystem { // "ClientCore.Systems.CollectVehicleCollisionsWithBreakableCollidersSystem (Client.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsSceneModel = 0x38; // "PhysicsSceneModel"
            inline constexpr std::uintptr_t physicsBodiesModel = 0x40; // "PhysicsBodiesModel"
            inline constexpr std::uintptr_t vehicleCollisionsWithBreakableCollidersModel = 0x48; // "IVehicleCollisionsWithBreakableCollidersModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0xE53470; // "protected override void Tick(ITick tick)"
        }
    } // namespace CollectVehicleCollisionsWithBreakableCollidersSystem

    namespace CollectVehiclesCollisionsSystem { // "ClientCore.Systems.CollectVehiclesCollisionsSystem (Client.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsSceneModel = 0x38; // "PhysicsSceneModel"
            inline constexpr std::uintptr_t physicsBodiesModel = 0x40; // "PhysicsBodiesModel"
            inline constexpr std::uintptr_t vehiclesCollisionsModel = 0x48; // "IVehiclesCollisionsModel"
            inline constexpr std::uintptr_t usedContacts = 0x50; // "List<int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0xE537D0; // "protected override void Tick(ITick tick)"
        }
    } // namespace CollectVehiclesCollisionsSystem

    namespace CustomizeSceneCarSkinViewUpdater { // "Game.Global.CustomizeScene.CustomizeSceneCarSkinViewUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t carLoadingModel = 0x10; // "SkinLoadingModel<string>"
            inline constexpr std::uintptr_t viewDescriptions = 0x18; // "CarSkinViewDescriptions"
            inline constexpr std::uintptr_t vehicleContainer = 0x20; // "Transform"
            inline constexpr std::uintptr_t isVisibleFunc = 0x28; // "Func<bool>"
            inline constexpr std::uintptr_t vehicleDisposableContent = 0x30; // "IDisposableContent<SkinCenterDecorativeCarView>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x35F9C90; // "public void Update()"
            inline constexpr std::uintptr_t Dispose = 0x35F9BC0; // "private void Dispose()"
            inline constexpr std::uintptr_t Init = 0x35F9C20; // "private void Init()"
        }
    } // namespace CustomizeSceneCarSkinViewUpdater

    namespace CustomizeSceneHelicopterSkinViewUpdater { // "Game.Global.CustomizeScene.CustomizeSceneHelicopterSkinViewUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t helicopterLoadingModel = 0x10; // "SkinLoadingModel<string>"
            inline constexpr std::uintptr_t viewDescriptions = 0x18; // "HelicopterSkinViewDescriptions"
            inline constexpr std::uintptr_t vehicleContainer = 0x20; // "Transform"
            inline constexpr std::uintptr_t isVisibleFunc = 0x28; // "Func<bool>"
            inline constexpr std::uintptr_t vehicleDisposableContent = 0x30; // "IDisposableContent<SkinCenterDecorativeHelicopterView>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x35FB770; // "public void Update()"
            inline constexpr std::uintptr_t Dispose = 0x35FB710; // "private void Dispose()"
        }
    } // namespace CustomizeSceneHelicopterSkinViewUpdater

    namespace CustomScaleConstraint { // "Game.Battle.Entities.Car.CustomScaleConstraint (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t target = 0x20; // "Transform"
            inline constexpr std::uintptr_t scaleFactor = 0x28; // "Vector3"
            inline constexpr std::uintptr_t initialScale = 0x34; // "Vector3"
            inline constexpr std::uintptr_t initialLocalPosition = 0x40; // "Vector3"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Start = 0xB9EB20; // "private void Start()"
            inline constexpr std::uintptr_t Update = 0xB9EBD0; // "private void Update()"
        }
    } // namespace CustomScaleConstraint

    namespace DatabaseCarSlotData { // "Models.Data.Settlement.Vehicle.DatabaseCarSlotData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t UpgradesSlots = 0x40; // "CarUpgradesSlotsData"
        }
    } // namespace DatabaseCarSlotData

    namespace DeferredOpenEntity_CarTrunk { // "Game.Battle.Entities.DeferredOpen.DeferredOpenEntity.CarTrunk (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t BreachModel = 0x10; // "BreachStateEntityModel"
            inline constexpr std::uintptr_t EntityId = 0x18; // "int"
        }
    } // namespace DeferredOpenEntity_CarTrunk

    namespace DisableCameraCollisionWithPlayerVehicleUpdater { // "Game.Battle.Entities.Player.Vehicle.Updaters.DisableCameraCollisionWithPlayerVehicleUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t vehicleCollidersViews = 0x10; // "Dictionary<int, VehicleEntityView>"
            inline constexpr std::uintptr_t inVehicleModel = 0x18; // "InVehicleModel"
            inline constexpr std::uintptr_t cinemachineBrain = 0x20; // "CinemachineBrain"
            inline constexpr std::uintptr_t blendDuration = 0x28; // "float"
            inline constexpr std::uintptr_t inVehicle = 0x2C; // "bool"
            inline constexpr std::uintptr_t vehicleId = 0x30; // "int"
            inline constexpr std::uintptr_t switchingOnRequested = 0x34; // "bool"
            inline constexpr std::uintptr_t switchingTimer = 0x38; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB065E0; // "public void Update()"
        }
    } // namespace DisableCameraCollisionWithPlayerVehicleUpdater

    namespace DriverSeat { // "Game.Battle.Entities.Car.DriverSeat (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t LeftHandIK_Target = 0x0; // "Transform"
            inline constexpr std::uintptr_t LeftHandIK_Hint = 0x8; // "Transform"
            inline constexpr std::uintptr_t RightHandIK_Target = 0x10; // "Transform"
            inline constexpr std::uintptr_t RightHandIK_Hint = 0x18; // "Transform"
        }
    } // namespace DriverSeat

    namespace EcuCarUpgradeReadAdapter { // "Models.Utils.Adapters.CarUpgradeAdapter.EcuCarUpgradeReadAdapter (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t TryFromItem = 0x3C836A0; // "public bool TryFromItem(InventoryItemDescription item, out EcuCarUpgradeDescription value)"
            inline constexpr std::uintptr_t TryGetUpgradeSlot = 0x3C836E0; // "public bool TryGetUpgradeSlot(CarUpgradesSlotsModel carUpgradesSlotsModel, int slotIndex, CarDescription carDescription, out IPrimitiveModel<EcuCarUpgradeDescription> slotModel)"
            inline constexpr std::uintptr_t CheckUnsetUpgrade = 0x7D5050; // "public bool CheckUnsetUpgrade(int entityId, IPrimitiveModel<EcuCarUpgradeDescription> slotModel)"
            inline constexpr std::uintptr_t CheckSwap = 0x7D5050; // "public bool CheckSwap(int entityId, IPrimitiveModel<EcuCarUpgradeDescription> slotModel, EcuCarUpgradeDescription upgradeDescription)"
        }
    } // namespace EcuCarUpgradeReadAdapter

    namespace EngineCoolingCarUpgradeReadAdapter { // "Models.Utils.Adapters.CarUpgradeAdapter.EngineCoolingCarUpgradeReadAdapter (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t TryFromItem = 0x3C83710; // "public bool TryFromItem(InventoryItemDescription item, out EngineCoolingCarUpgradeDescription value)"
            inline constexpr std::uintptr_t TryGetUpgradeSlot = 0x3C83750; // "public bool TryGetUpgradeSlot(CarUpgradesSlotsModel carUpgradesSlotsModel, int slotIndex, CarDescription carDescription, out IPrimitiveModel<EngineCoolingCarUpgradeDescription> slotModel)"
            inline constexpr std::uintptr_t CheckUnsetUpgrade = 0x7D5050; // "public bool CheckUnsetUpgrade(int entityId, IPrimitiveModel<EngineCoolingCarUpgradeDescription> slotModel)"
            inline constexpr std::uintptr_t CheckSwap = 0x7D5050; // "public bool CheckSwap(int entityId, IPrimitiveModel<EngineCoolingCarUpgradeDescription> slotModel, EngineCoolingCarUpgradeDescription upgradeDescription)"
        }
    } // namespace EngineCoolingCarUpgradeReadAdapter

    namespace EnterLeaveVehicleInputDescription { // "Models.References.Input.EnterLeaveVehicleInputDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x817D928; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t Enter = 0x0; // "EnterLeaveVehicleInputDescription"
            inline constexpr std::uintptr_t StartLeave = 0x8; // "EnterLeaveVehicleInputDescription"
            inline constexpr std::uintptr_t StopLeave = 0x10; // "EnterLeaveVehicleInputDescription"
        }
    } // namespace EnterLeaveVehicleInputDescription

    namespace EnterLeaveVehicleRequestModel { // "Models.Models.EnterLeaveVehicleRequest.EnterLeaveVehicleRequestModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsRequested = 0x10; // "bool"
            inline constexpr std::uintptr_t Request = 0x18; // "EnterLeaveVehicleInputDescription"
            inline constexpr std::uintptr_t TargetEntityId = 0x20; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetRequest = 0x49145D0; // "public void SetRequest(EnterLeaveVehicleInputDescription request, int targetEntityId)"
            inline constexpr std::uintptr_t Clear = 0x844D10; // "public void Clear()"
        }
    } // namespace EnterLeaveVehicleRequestModel

    namespace FromCarUpgradesToInventoryMessage { // "Models.Messages.Vehicle.Car.FromCarUpgradesToInventoryMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t inventorySlot = 0x20; // "IPrimitiveData<InventorySlotDescription>"
            inline constexpr std::uintptr_t entityId = 0x28; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t upgradeType = 0x30; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t slotIndex = 0x38; // "IPrimitiveData<int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_InventorySlot = 0x4A07A30; // "public InventorySlotDescription get_InventorySlot()"
            inline constexpr std::uintptr_t get_EntityId = 0x4A079E0; // "public int get_EntityId()"
            inline constexpr std::uintptr_t get_UpgradeType = 0x4A07B00; // "public CarUpgradeType get_UpgradeType()"
            inline constexpr std::uintptr_t get_SlotIndex = 0x4A07A80; // "public int get_SlotIndex()"
            inline constexpr std::uintptr_t get_Type = 0x4A07AD0; // "public override string get_Type()"
        }
    } // namespace FromCarUpgradesToInventoryMessage

    namespace FromInventoryToCarUpgradesMessage { // "Models.Messages.Vehicle.Car.FromInventoryToCarUpgradesMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t inventorySlot = 0x20; // "IPrimitiveData<InventorySlotDescription>"
            inline constexpr std::uintptr_t entityId = 0x28; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t upgradeType = 0x30; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t slotIndex = 0x38; // "IPrimitiveData<int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_InventorySlot = 0x4A08020; // "public InventorySlotDescription get_InventorySlot()"
            inline constexpr std::uintptr_t get_EntityId = 0x4A07FD0; // "public int get_EntityId()"
            inline constexpr std::uintptr_t get_UpgradeType = 0x4A080F0; // "public CarUpgradeType get_UpgradeType()"
            inline constexpr std::uintptr_t get_SlotIndex = 0x4A08070; // "public int get_SlotIndex()"
            inline constexpr std::uintptr_t get_Type = 0x4A080C0; // "public override string get_Type()"
        }
    } // namespace FromInventoryToCarUpgradesMessage

    namespace GarageAddCarMessage { // "Models.Messages.Settlement.GarageAddCarMessage (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x4A083F0; // "public override string get_Type()"
        }
    } // namespace GarageAddCarMessage

    namespace GarageAddHelicopterMessage { // "Models.Messages.Settlement.GarageAddHelicopterMessage (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x4A085A0; // "public override string get_Type()"
        }
    } // namespace GarageAddHelicopterMessage

    namespace GarageParkingTargetActions { // "Game.Battle.EntityModel.VehicleBench.GarageParkingTargetActions (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t personalNotificationModel = 0x10; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t globalLocalizationKeys = 0x18; // "GlobalLocalizationKeys"
            inline constexpr std::uintptr_t localizationKeys = 0x20; // "LocalizationKeys"
            inline constexpr std::uintptr_t interactEntityModel = 0x28; // "IInteractEntityModel"
            inline constexpr std::uintptr_t vehicleTypeDescription = 0x30; // "VehicleTypeDescription"
            inline constexpr std::uintptr_t roomConnectionsBattle = 0x38; // "IRoomConnection"
            inline constexpr std::uintptr_t globalModel = 0x40; // "GlobalModel"
            inline constexpr std::uintptr_t entityId = 0x48; // "int"
            inline constexpr std::uintptr_t battleModel = 0x50; // "BattleModel"
            inline constexpr std::uintptr_t plotModel = 0x58; // "PlotModel"
            inline constexpr std::uintptr_t inputActions = 0x60; // "InputActions"
            inline constexpr std::uintptr_t Spawn = 0x68; // "TargetAction"
        }
        namespace Methods {
            inline constexpr std::uintptr_t UnavailableSpawnVehicle = 0xC20CD0; // "private void UnavailableSpawnVehicle(LocalizedString obj, PersonalNotificationActionIds id)"
            inline constexpr std::uintptr_t SpawnVehicle = 0xC20B00; // "private void SpawnVehicle()"
            inline constexpr std::uintptr_t SendMessage = 0xC20A50; // "private void SendMessage()"
        }
    } // namespace GarageParkingTargetActions

    namespace GarageRemoveCarMessage { // "Models.Messages.Settlement.GarageRemoveCarMessage (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x4A08700; // "public override string get_Type()"
        }
    } // namespace GarageRemoveCarMessage

    namespace GarageRemoveHelicopterMessage { // "Models.Messages.Settlement.GarageRemoveHelicopterMessage (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x4A088B0; // "public override string get_Type()"
        }
    } // namespace GarageRemoveHelicopterMessage

    namespace GarageSwapCarsMessage { // "Models.Messages.Settlement.GarageSwapCarsMessage (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x4A08A10; // "public override string get_Type()"
        }
    } // namespace GarageSwapCarsMessage

    namespace GarageSwapHelicoptersMessage { // "Models.Messages.Settlement.GarageSwapHelicoptersMessage (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x4A08BC0; // "public override string get_Type()"
        }
    } // namespace GarageSwapHelicoptersMessage

    namespace GarageSwapPlotCarWithInventoryMessage { // "Models.Messages.Settlement.GarageSwapPlotCarWithInventoryMessage (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x4A08D30; // "public override string get_Type()"
        }
    } // namespace GarageSwapPlotCarWithInventoryMessage

    namespace GarageSwapPlotHelicopterWithInventoryMessage { // "Models.Messages.Settlement.GarageSwapPlotHelicopterWithInventoryMessage (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x4A08EE0; // "public override string get_Type()"
        }
    } // namespace GarageSwapPlotHelicopterWithInventoryMessage

    namespace GarageUnsetCarMessage { // "Models.Messages.Settlement.GarageUnsetCarMessage (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x4A09030; // "public override string get_Type()"
        }
    } // namespace GarageUnsetCarMessage

    namespace GarageUnsetHelicopterMessage { // "Models.Messages.Settlement.GarageUnsetHelicopterMessage (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x4A091C0; // "public override string get_Type()"
        }
    } // namespace GarageUnsetHelicopterMessage

    namespace GarageVehicleParkingView { // "Game.Battle.EntityModel.VehicleBench.GarageVehicleParkingView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Collider = 0x20; // "Collider"
            inline constexpr std::uintptr_t MarkerParent = 0x28; // "Transform"
            inline constexpr std::uintptr_t TargetHintPosition = 0x30; // "Transform"
        }
    } // namespace GarageVehicleParkingView

    namespace GarageVehicleSlotTargetView { // "Game.Battle.EntityModel.VehicleBench.GarageVehicleSlotTargetView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t TargetObjectView = 0x20; // "TargetObjectView"
            inline constexpr std::uintptr_t Container = 0x28; // "Transform"
        }
        namespace Methods {
            inline constexpr std::uintptr_t RegisterAndGetTargetObject = 0xC20FE0; // "public ITargetObject RegisterAndGetTargetObject(Collider collider, Transform hintPosition, int entityId)"
            inline constexpr std::uintptr_t RegisterAndGetTargetObject_2 = 0xC210E0; // "public ITargetObject RegisterAndGetTargetObject(Collider collider, TargetObjectView hintSource, int entityId)"
            inline constexpr std::uintptr_t Unregister = 0xC211E0; // "public void Unregister()"
        }
    } // namespace GarageVehicleSlotTargetView

    namespace GarageVehicleSummonRules { // "Game.Battle.EntityModel.VehicleBench.GarageVehicleSummonRules (Battle.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t CanSummon = 0xC21220; // "public static bool CanSummon(IPlotVehicleModel plotVehicleModel, BattleModel battleModel, long publicId, float visibleDistanceSqr)"
            inline constexpr std::uintptr_t GetSummonBlockNotification = 0xC214E0; // "public static LocalizedString GetSummonBlockNotification(BattleCharacterModel character, long now, LocalizationKeys localizationKeys)"
        }
    } // namespace GarageVehicleSummonRules

    namespace GarageVehicleTargetActions { // "Game.Battle.EntityModel.VehicleBench.GarageVehicleTargetActions (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t globalModel = 0x10; // "GlobalModel"
            inline constexpr std::uintptr_t entityId = 0x18; // "int"
            inline constexpr std::uintptr_t interactEntityModel = 0x20; // "IInteractEntityModel"
            inline constexpr std::uintptr_t carSoundEmitter = 0x28; // "GameObject"
            inline constexpr std::uintptr_t localizationKeys = 0x30; // "LocalizationKeys"
            inline constexpr std::uintptr_t globalLocalizationKeys = 0x38; // "GlobalLocalizationKeys"
            inline constexpr std::uintptr_t roomConnectionsBattle = 0x40; // "IRoomConnection"
            inline constexpr std::uintptr_t battleModel = 0x48; // "BattleModel"
            inline constexpr std::uintptr_t plotModel = 0x50; // "PlotModel"
            inline constexpr std::uintptr_t inputActions = 0x58; // "InputActions"
            inline constexpr std::uintptr_t attemptToOpenClosedDoor = 0x60; // "Event"
            inline constexpr std::uintptr_t vehicleTypeDescription = 0x68; // "VehicleTypeDescription"
            inline constexpr std::uintptr_t cooldownTs = 0x70; // "float"
            inline constexpr std::uintptr_t Enter = 0x78; // "TargetAction"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SpawnVehicle = 0xC216B0; // "private void SpawnVehicle()"
            inline constexpr std::uintptr_t SendMessage = 0xC21600; // "private void SendMessage()"
            inline constexpr std::uintptr_t Unavailable = 0xC21960; // "private void Unavailable(LocalizedString invalidNotification, PersonalNotificationActionIds id)"
        }
    } // namespace GarageVehicleTargetActions

    namespace GarageVehicleTargetProvider { // "Game.Battle.EntityModel.VehicleBench.GarageVehicleTargetProvider (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t entityId = 0x20; // "int"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x28; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t localizationKeys = 0x30; // "LocalizationKeys"
            inline constexpr std::uintptr_t enterTargetAction = 0x38; // "TargetAction"
            inline constexpr std::uintptr_t partyModel = 0x40; // "PartyModel"
            inline constexpr std::uintptr_t settlementHelperModel = 0x48; // "ISettlementHelperModel"
            inline constexpr std::uintptr_t publicIdModel = 0x50; // "PublicIdModel"
            inline constexpr std::uintptr_t lockedVehicleString = 0x58; // "LocalizedString"
            inline constexpr std::uintptr_t now = 0x60; // "INow"
        }
        namespace Methods {
            inline constexpr std::uintptr_t GetTargetAction = 0xC21D80; // "protected override ITargetAction GetTargetAction()"
            inline constexpr std::uintptr_t IsCharacterAllowedToEnterVehicle = 0xC22040; // "private bool IsCharacterAllowedToEnterVehicle()"
            inline constexpr std::uintptr_t IsPartyTeammateVehicle = 0xC22110; // "private bool IsPartyTeammateVehicle()"
            inline constexpr std::uintptr_t IsOwnVehicle = 0xC220B0; // "private bool IsOwnVehicle(long publicId)"
            inline constexpr std::uintptr_t CheckCooldown = 0xC21D10; // "private bool CheckCooldown(BattleCharacterModel battleCharacter)"
        }
    } // namespace GarageVehicleTargetProvider

    namespace GlobalMapVehicleData { // "Models.Data.Vehicle.GlobalMapVehicleData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Car = 0x20; // "IPrimitiveData<CarDescription>"
            inline constexpr std::uintptr_t Helicopter = 0x28; // "IPrimitiveData<HelicopterDescription>"
            inline constexpr std::uintptr_t IsRented = 0x30; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t OwnerPrivateId = 0x38; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t OwnerPublicId = 0x40; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t OwnerNickname = 0x48; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t OwnerClanTag = 0x50; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t VehicleTrunk = 0x58; // "VehicleTrunkData"
            inline constexpr std::uintptr_t RadioStation = 0x60; // "IPrimitiveData<RadioStationDescription>"
            inline constexpr std::uintptr_t DirtLevel = 0x68; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t TrunkBreachData = 0x70; // "BreachEntityData"
            inline constexpr std::uintptr_t CarUpgradesSlots = 0x78; // "CarUpgradesSlotsData"
        }
    } // namespace GlobalMapVehicleData

    namespace GrenadeExplosionCameraEffectUpdater { // "Game.Battle.Entities.Car.GrenadeExplosionCameraEffectUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t cameraMultiChannelPerlin = 0x10; // "CinemachineBasicMultiChannelPerlin"
            inline constexpr std::uintptr_t playerCameraTypeModel = 0x18; // "PlayerCameraTypeModel"
            inline constexpr std::uintptr_t grenadeViewDescriptions = 0x20; // "GrenadeViewDescriptions"
            inline constexpr std::uintptr_t grenadeCameraShakingModel = 0x28; // "GrenadeCameraShakingModel"
            inline constexpr std::uintptr_t defaultNoiseAmplitudeGain = 0x30; // "float"
            inline constexpr std::uintptr_t defaultNoiseFrequencyGain = 0x34; // "float"
            inline constexpr std::uintptr_t defaultNoise = 0x38; // "NoiseSettings"
            inline constexpr std::uintptr_t explosionNoise = 0x40; // "NoiseSettings"
            inline constexpr std::uintptr_t cameraType = 0x48; // "CameraType"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB9EE80; // "public void Update()"
            inline constexpr std::uintptr_t TakeCameraPerlin = 0xB9ED60; // "private void TakeCameraPerlin(out float amplitudeGain, out float frequencyGain, out NoiseSettings noiseSettings)"
        }
    } // namespace GrenadeExplosionCameraEffectUpdater

    namespace HelicopterAnyPredictionSavePhysicsAndTickDataSystem { // "ClientCore.Systems.HelicopterAnyPredictionSavePhysicsAndTickDataSystem (Client.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsSceneModel = 0x38; // "PhysicsSceneModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0xE55800; // "protected override void Tick(ITick tick)"
        }
    } // namespace HelicopterAnyPredictionSavePhysicsAndTickDataSystem

    namespace HelicopterAnyPredictionUpdatePhysicsAndTickDataSystem { // "ClientCore.Systems.HelicopterAnyPredictionUpdatePhysicsAndTickDataSystem (Client.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsSceneModel = 0x38; // "PhysicsSceneModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0xE55C80; // "protected override void Tick(ITick tick)"
            inline constexpr std::uintptr_t UpdatePhysicsScene = 0xE55F20; // "private void UpdatePhysicsScene(in HelicopterTimelineData timelineData, PhysicsBodyId bodyId)"
        }
    } // namespace HelicopterAnyPredictionUpdatePhysicsAndTickDataSystem

    namespace HelicopterBenchDialogUpdater { // "Game.Battle.EntityModel.VehicleBench.HelicopterBenchDialogUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t updaters = 0x20; // "List<IUpdater>"
            inline constexpr std::uintptr_t inventoryModels = 0x28; // "InventoryModels"
            inline constexpr std::uintptr_t disposableContent = 0x30; // "IDisposable"
            inline constexpr std::uintptr_t globalModel = 0x38; // "GlobalModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xC224D0; // "public HelicopterBenchDialogUpdater Init(CurrentInventoryModel.HelicopterBench currentInventoryModel, GlobalScreenContent globalScreenContent, BattleScreenContent battleScreenContent, UpdaterPool updaterPool, Transform canvasParent, DeviceModel deviceModel, InputActions inputActions, List<IUpdater> mainInputUpdaters, GlobalModel globalModel, BattleModel battleModel, InteractRaycastModel interactRaycastModel, IRegisterDisposable registerDisposable)"
            inline constexpr std::uintptr_t Dispose = 0xC223C0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t IsDragSuitableHelicopterItem = 0xC233F0; // "private bool IsDragSuitableHelicopterItem()"
            inline constexpr std::uintptr_t IsValidItem = 0xC234B0; // "private bool IsValidItem(IInventoryItemModel itemModel)"
            inline constexpr std::uintptr_t OnUpdate = 0x94CF50; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace HelicopterBenchDialogUpdater

    namespace HelicopterBenchItemMoveContext { // "Game.Battle.EntityModel.VehicleBench.HelicopterBenchItemMoveContext (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t SlotModel = 0x10; // "HelicopterBenchSlotModel"
            inline constexpr std::uintptr_t ItemModel = 0x18; // "IInventoryItemModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_EntityId = 0xC01B80; // "public int get_EntityId()"
            inline constexpr std::uintptr_t get_SlotDescription = 0xC23690; // "public PlotHelicopterSlotDescription get_SlotDescription()"
            inline constexpr std::uintptr_t get_RevealContainerModel = 0xC23600; // "public IRevealContainerModel get_RevealContainerModel()"
            inline constexpr std::uintptr_t get_Revealed = 0x7D5050; // "public bool get_Revealed()"
            inline constexpr std::uintptr_t get_Count = 0xC235A0; // "public int get_Count()"
            inline constexpr std::uintptr_t get_Ammo = 0x7E3AB0; // "public int get_Ammo()"
            inline constexpr std::uintptr_t get_Durability = 0x7E3AB0; // "public int get_Durability()"
            inline constexpr std::uintptr_t get_CumulativePoints = 0x7E3AB0; // "public int get_CumulativePoints()"
        }
    } // namespace HelicopterBenchItemMoveContext

    namespace HelicopterBenchSlotModel { // "Game.Battle.EntityModel.VehicleBench.HelicopterBenchSlotModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t EntityId = 0x10; // "int"
            inline constexpr std::uintptr_t PlotHelicopterModel = 0x18; // "PlotHelicopterModel"
            inline constexpr std::uintptr_t InventoryItemModel = 0x20; // "IInventoryItemModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_PlotVehicleModel = 0x7E7130; // "public IPlotVehicleModel get_PlotVehicleModel()"
            inline constexpr std::uintptr_t get_InventoryItemDescription = 0xC23810; // "public InventoryItemDescription get_InventoryItemDescription()"
            inline constexpr std::uintptr_t get_IsEmpty = 0xC23880; // "public bool get_IsEmpty()"
            inline constexpr std::uintptr_t CreateMoveContext = 0xC23700; // "public IItemMoveContext CreateMoveContext()"
        }
    } // namespace HelicopterBenchSlotModel

    namespace HelicopterBenchSlotsModel { // "Game.Battle.EntityModel.VehicleBench.HelicopterBenchSlotsModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t EntityId = 0x10; // "int"
            inline constexpr std::uintptr_t Slots = 0x18; // "IVehicleBenchSlotModel[]"
        }
    } // namespace HelicopterBenchSlotsModel

    namespace HelicopterBenchTargetActions { // "Game.Battle.EntityModel.VehicleBench.HelicopterBenchTargetActions (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t entityId = 0x10; // "int"
            inline constexpr std::uintptr_t globalModel = 0x18; // "GlobalModel"
            inline constexpr std::uintptr_t battleModel = 0x20; // "BattleModel"
            inline constexpr std::uintptr_t plotModel = 0x28; // "PlotModel"
            inline constexpr std::uintptr_t globalLocalizationKeys = 0x30; // "GlobalLocalizationKeys"
            inline constexpr std::uintptr_t notificationKeys = 0x38; // "NotificationKeys"
            inline constexpr std::uintptr_t personalNotificationModel = 0x40; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t uiSoundModel = 0x48; // "GlobalUISoundModel"
            inline constexpr std::uintptr_t clientCodexModel = 0x50; // "ClientCodexModel"
            inline constexpr std::uintptr_t dialogModel = 0x58; // "InventoryDialogModel"
            inline constexpr std::uintptr_t interactEntityModel = 0x60; // "IInteractEntityModel"
            inline constexpr std::uintptr_t inputActions = 0x68; // "InputActions"
            inline constexpr std::uintptr_t battleRoomConnection = 0x70; // "IRoomConnection"
            inline constexpr std::uintptr_t UseAction = 0x78; // "TargetAction"
            inline constexpr std::uintptr_t CallAction = 0x80; // "TargetAction"
        }
        namespace Methods {
            inline constexpr std::uintptr_t OnCall = 0xC23D40; // "private void OnCall()"
            inline constexpr std::uintptr_t SendSpawnMessage = 0xC240B0; // "private void SendSpawnMessage()"
            inline constexpr std::uintptr_t Unavailable = 0xB90E70; // "private void Unavailable(LocalizedString invalidNotification, PersonalNotificationActionIds id)"
            inline constexpr std::uintptr_t OpenBench = 0xC23F50; // "private void OpenBench()"
        }
    } // namespace HelicopterBenchTargetActions

    namespace HelicopterBenchTargetProvider { // "Game.Battle.EntityModel.VehicleBench.HelicopterBenchTargetProvider (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t settlementHelperModel = 0x20; // "ISettlementHelperModel"
            inline constexpr std::uintptr_t targetActions = 0x28; // "HelicopterBenchTargetActions"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x30; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t battleModel = 0x38; // "BattleModel"
            inline constexpr std::uintptr_t entityId = 0x40; // "int"
            inline constexpr std::uintptr_t localizationKeys = 0x48; // "LocalizationKeys"
            inline constexpr std::uintptr_t helicopterSlots = 0x50; // "IReadOnlyList<PlotHelicopterModel>"
            inline constexpr std::uintptr_t summonVisibleDistanceSqr = 0x58; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t FillTargetActions = 0xC24630; // "protected internal override void FillTargetActions(List<ITargetAction> actions)"
            inline constexpr std::uintptr_t HasAnyVehicle = 0xC24C40; // "private bool HasAnyVehicle()"
            inline constexpr std::uintptr_t CanSummonAny = 0xC24540; // "private bool CanSummonAny(long publicId)"
        }
    } // namespace HelicopterBenchTargetProvider

    namespace HelicopterBenchView { // "Game.Battle.EntityModel.VehicleBench.HelicopterBenchView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t MarkerRoot = 0x20; // "Transform"
            inline constexpr std::uintptr_t Collider = 0x28; // "Collider"
            inline constexpr std::uintptr_t TargetObjectView = 0x30; // "TargetObjectView"
        }
    } // namespace HelicopterBenchView

    namespace HelicopterBladeBlurUpdater { // "Game.Battle.Entities.Helicopter.Updaters.HelicopterBladeBlurUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t helicopterEngineClientModel = 0x10; // "HelicopterEngineClientModel"
            inline constexpr std::uintptr_t helicopterBladeBlurView = 0x18; // "HelicopterBladeBlurView"
            inline constexpr std::uintptr_t normalizedSpeed = 0x20; // "float"
            inline constexpr std::uintptr_t isBladeRenderersActive = 0x24; // "bool"
            inline constexpr std::uintptr_t isBlurRenderersActive = 0x25; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB67E40; // "public void Update()"
        }
    } // namespace HelicopterBladeBlurUpdater

    namespace HelicopterBladeBlurView { // "Game.Battle.Entities.Helicopter.Views.HelicopterBladeBlurView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t bladeMeshRenderers = 0x20; // "MeshRenderer[]"
            inline constexpr std::uintptr_t blurMeshRenderers = 0x28; // "MeshRenderer[]"
            inline constexpr std::uintptr_t propertyBlock = 0x30; // "MaterialPropertyBlock"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Awake = 0xB68100; // "private void Awake()"
            inline constexpr std::uintptr_t UpdateBlurMeshRenderers = 0xB68380; // "public void UpdateBlurMeshRenderers(float normalizedRotationSpeed)"
            inline constexpr std::uintptr_t UpdateBladeMeshRenderers = 0xB68270; // "public void UpdateBladeMeshRenderers(float normalizedRotationSpeed)"
            inline constexpr std::uintptr_t SetActiveBlurMeshRenderers = 0xB681F0; // "public void SetActiveBlurMeshRenderers(bool isActive)"
            inline constexpr std::uintptr_t SetActiveBladeMeshRenderers = 0xB68170; // "public void SetActiveBladeMeshRenderers(bool isActive)"
        }
    } // namespace HelicopterBladeBlurView

    namespace HelicopterChassisDescription { // "Models.References.Helicopter.HelicopterChassisDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t FrictionAcceleration = 0x20; // "float"
        }
    } // namespace HelicopterChassisDescription

    namespace HelicopterChassisRotationViewUpdater { // "Game.Battle.Entities.Helicopter.Updaters.HelicopterChassisRotationViewUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t wheelsServerModel = 0x10; // "HelicopterWheelsModel"
            inline constexpr std::uintptr_t leftChassisView = 0x18; // "HelicopterChassisView"
            inline constexpr std::uintptr_t rightChassisView = 0x20; // "HelicopterChassisView"
            inline constexpr std::uintptr_t physicsDataModel = 0x28; // "VehiclePhysicsDataModel"
            inline constexpr std::uintptr_t timelineTimeOffset = 0x30; // "TimelineTimeOffsetModel"
            inline constexpr std::uintptr_t timelineSnapshots = 0x38; // "TimelineSnapshotsData<HelicopterTimelineData>"
            inline constexpr std::uintptr_t timelineExtrapolations = 0x40; // "TimelineExtrapolationsData<HelicopterTimelineData>"
            inline constexpr std::uintptr_t floatData = 0x48; // "float[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB68700; // "public void Update()"
            inline constexpr std::uintptr_t CalculateChassisRotation = 0xB68490; // "private float CalculateChassisRotation(float forwardSpringLength, float backwardSpringLength, in Vector3 chassisLinkPoint, in Vector3 chassisBottomPoint, float oldRotation, bool inverseRotation)"
        }
    } // namespace HelicopterChassisRotationViewUpdater

    namespace HelicopterChassisSettingsModel { // "Models.Models.HelicopterChassisSettings.HelicopterChassisSettingsModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t description = 0x10; // "HelicopterChassisDescription"
            inline constexpr std::uintptr_t overrideModel = 0x18; // "HelicopterChassisSettingsOverrideModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_FrictionAcceleration = 0x4964C20; // "public float get_FrictionAcceleration()"
        }
    } // namespace HelicopterChassisSettingsModel

    namespace HelicopterChassisSettingsOverrideData { // "Models.Data.SettingsOverride.Helicopters.HelicopterChassisSettingsOverrideData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t OverrideEnabled = 0x20; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t FrictionAcceleration = 0x28; // "IPrimitiveData<float>"
        }
    } // namespace HelicopterChassisSettingsOverrideData

    namespace HelicopterChassisSettingsOverrideModel { // "Models.Models.HelicopterChassisSettingsOverride.HelicopterChassisSettingsOverrideModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "HelicopterChassisSettingsOverrideData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_OverrideEnabled = 0x4964EA0; // "public bool get_OverrideEnabled()"
            inline constexpr std::uintptr_t get_FrictionAcceleration = 0x4964E50; // "public float get_FrictionAcceleration()"
            inline constexpr std::uintptr_t SetOverrideData = 0x4964CF0; // "public void SetOverrideData(float frictionAcceleration)"
        }
    } // namespace HelicopterChassisSettingsOverrideModel

    namespace HelicopterChassisView { // "Game.Battle.EntityModel.Helicopter.Views.HelicopterChassisView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Transform = 0x20; // "Transform"
            inline constexpr std::uintptr_t BottomPointTransform = 0x28; // "Transform"
        }
        namespace Methods {
            inline constexpr std::uintptr_t GetBottomPointPosition = 0x9AF3C0; // "public Vector3 GetBottomPointPosition()"
            inline constexpr std::uintptr_t GetRotationDeg = 0xC8C030; // "public float GetRotationDeg()"
            inline constexpr std::uintptr_t SetRotationDeg = 0xC8C060; // "public void SetRotationDeg(float angleDeg)"
        }
    } // namespace HelicopterChassisView

    namespace HelicopterClientData { // "Game.Battle.EntityModel.Helicopter.Models.HelicopterClientData (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t PhysicsData = 0x10; // "VehiclePhysicsDataModel"
        }
    } // namespace HelicopterClientData

    namespace HelicopterClientDataUpdater { // "Game.Battle.Entities.Helicopter.Updaters.HelicopterClientDataUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t serverModel = 0x10; // "HelicopterModel"
            inline constexpr std::uintptr_t clientData = 0x18; // "HelicopterClientData"
            inline constexpr std::uintptr_t deadReckoningModel = 0x20; // "EntityDeadReckoningModel"
            inline constexpr std::uintptr_t timeOffsetModel = 0x28; // "TimelineTimeOffsetModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB690F0; // "public void Update()"
            inline constexpr std::uintptr_t UpdatePhysicsDataFromDeadReckoning = 0xB68D00; // "private void UpdatePhysicsDataFromDeadReckoning(VehiclePhysicsDataModel physicsDataModel, VehicleTransformModel serverTransformModel, EntityDeadReckoningModel deadReckoningModel)"
            inline constexpr std::uintptr_t UpdatePhysicsDataFromTimeline = 0xB68F60; // "private void UpdatePhysicsDataFromTimeline(VehiclePhysicsDataModel physicsDataModel, VehicleTransformModel serverTransformModel, in HelicopterTimelineData timelineData)"
            inline constexpr std::uintptr_t UpdatePhysicsDataFromServer = 0xB68E00; // "private void UpdatePhysicsDataFromServer(VehiclePhysicsDataModel physicsDataModel, VehicleTransformModel serverTransformModel, VelocityModel serverLinearVelocity, VelocityModel serverAngularVelocity)"
            inline constexpr std::uintptr_t UpdatePhysicsData = 0xB69040; // "private void UpdatePhysicsData(VehiclePhysicsDataModel physicsDataModel, VehicleTransformModel serverTransformModel, in Vector3 centerOfMassPosition, in Quaternion centerOfMassOrientation, in Vector3 linearVelocity, in Vector3 angularVelocity)"
        }
    } // namespace HelicopterClientDataUpdater

    namespace HelicopterClientModel { // "Game.Battle.EntityModel.Helicopter.Models.HelicopterClientModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ClientData = 0x48; // "HelicopterClientData"
            inline constexpr std::uintptr_t ThrustInput = 0x50; // "HelicopterThrustInputClientModel"
            inline constexpr std::uintptr_t Engine = 0x58; // "HelicopterEngineClientModel"
            inline constexpr std::uintptr_t MainRotor = 0x60; // "HelicopterRotorClientModel"
            inline constexpr std::uintptr_t SecondaryRotor = 0x68; // "HelicopterRotorClientModel"
            inline constexpr std::uintptr_t ForwardAxle = 0x70; // "HelicopterAxleClientModel"
            inline constexpr std::uintptr_t BackwardAxle = 0x78; // "HelicopterAxleClientModel"
        }
    } // namespace HelicopterClientModel

    namespace HelicopterConfig { // "Models.References.Helicopter.Settings.HelicopterConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t SuspensionLimitAllowedPenetration = 0x10; // "float"
            inline constexpr std::uintptr_t SuspensionLimitErrorCorrection = 0x14; // "float"
            inline constexpr std::uintptr_t SuspensionLimitRestitution = 0x18; // "float"
            inline constexpr std::uintptr_t MinTouchGroundWheelsForGroundedHandlingState = 0x1C; // "int"
            inline constexpr std::uintptr_t MaxAngleFromWheelsToGroundSurfaceInDegree = 0x20; // "float"
            inline constexpr std::uintptr_t LargeSlopeGroundSurfaceAngleInDegree = 0x24; // "float"
            inline constexpr std::uintptr_t MaxAngleFromWheelsToGroundSurfaceCos = 0x28; // "float"
            inline constexpr std::uintptr_t LargeSlopeGroundSurfaceAngleCos = 0x2C; // "float"
            inline constexpr std::uintptr_t TakeLargeSlopeAsGround = 0x30; // "bool"
            inline constexpr std::uintptr_t DeathFromWaterOffsetY = 0x34; // "float"
        }
    } // namespace HelicopterConfig

    namespace HelicopterControllerApplyHelicopterInputByDriverSystem { // "Models.Systems.HelicopterControllerApplyHelicopterInputByDriverSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsSceneModel = 0x38; // "PhysicsSceneModel"
            inline constexpr std::uintptr_t battleCharacters = 0x40; // "ReadOnly.Dictionary<int, BattleCharacterModel>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x40F9050; // "protected override void Tick(ITick tick)"
            inline constexpr std::uintptr_t GetThrustInput = 0x40F8F50; // "private float GetThrustInput(BattleCharacterHelicopterInputModel driverHelicopterInput, bool isEngineSpeedEnoughForHandling)"
            inline constexpr std::uintptr_t GetTiltInput = 0x40F8F90; // "private ValueTuple<float, float> GetTiltInput(BattleCharacterHelicopterInputModel driverHelicopterInput, bool isEngineSpeedEnoughForHandling)"
            inline constexpr std::uintptr_t GetRotationInput = 0x40F8F10; // "private float GetRotationInput(BattleCharacterHelicopterInputModel driverHelicopterInput, bool isEngineSpeedEnoughForHandling)"
        }
    } // namespace HelicopterControllerApplyHelicopterInputByDriverSystem

    namespace HelicopterControllerApplyHelicopterInputByEmptySystem { // "Models.Systems.HelicopterControllerApplyHelicopterInputByEmptySystem (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x40F9470; // "protected override void Tick(ITick tick)"
        }
    } // namespace HelicopterControllerApplyHelicopterInputByEmptySystem

    namespace HelicopterControllerApplyHelicopterInputByPartialPredictionSystem { // "Models.Systems.HelicopterControllerApplyHelicopterInputByPartialPredictionSystem (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x40F9620; // "protected override void Tick(ITick tick)"
        }
    } // namespace HelicopterControllerApplyHelicopterInputByPartialPredictionSystem

    namespace HelicopterControllerChassisSystem { // "Models.Systems.HelicopterControllerChassisSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsSceneModel = 0x38; // "PhysicsSceneModel"
            inline constexpr std::uintptr_t invDt = 0x40; // "float"
            inline constexpr std::uintptr_t floatData = 0x48; // "float[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x40FA3D0; // "protected override void Tick(ITick tick)"
            inline constexpr std::uintptr_t IsAtLeastOneWheelTouchGround = 0x40FA370; // "private bool IsAtLeastOneWheelTouchGround(ValueTuple<VehicleWheelSuspensionTickDataModel, VehicleWheelLinkTickDataModel, VehicleWheelGroundTickDataModel, HelicopterWheelFrictionTickDataModel, VehicleWheelLoadTickDataModel>[] wheels)"
            inline constexpr std::uintptr_t CalculateGroundSurface = 0x40F9EF0; // "private void CalculateGroundSurface(Span<float> transformMatrix, ValueTuple<VehicleWheelSuspensionTickDataModel, VehicleWheelLinkTickDataModel, VehicleWheelGroundTickDataModel, HelicopterWheelFrictionTickDataModel, VehicleWheelLoadTickDataModel>[] wheels)"
            inline constexpr std::uintptr_t CalculateFrictionForces = 0x40F9800; // "private void CalculateFrictionForces(PhysicsBodyId bodyId, Span<float> transformMatrix, VehicleLinksTickDataModel linksTickData, HelicopterDescription description, HelicopterChassisSettingsModel chassisSettings, ValueTuple<VehicleWheelSuspensionTickDataModel, VehicleWheelLinkTickDataModel, VehicleWheelGroundTickDataModel, HelicopterWheelFrictionTickDataModel, VehicleWheelLoadTickDataModel>[] wheels)"
            inline constexpr std::uintptr_t ApplyFrictionForces = 0x40F9690; // "private void ApplyFrictionForces(PhysicsBodyId bodyId, ValueTuple<VehicleWheelSuspensionTickDataModel, VehicleWheelLinkTickDataModel, VehicleWheelGroundTickDataModel, HelicopterWheelFrictionTickDataModel, VehicleWheelLoadTickDataModel>[] wheels)"
        }
    } // namespace HelicopterControllerChassisSystem

    namespace HelicopterControllerControlOwnerSystem { // "Models.Systems.HelicopterControllerControlOwnerSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleCharacters = 0x38; // "ReadOnly.Dictionary<int, BattleCharacterModel>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x40FA6B0; // "protected override void Tick(ITick tick)"
        }
    } // namespace HelicopterControllerControlOwnerSystem

    namespace HelicopterControllerHandlingSystem { // "Models.Systems.HelicopterControllerHandlingSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsSceneModel = 0x38; // "PhysicsSceneModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x40FBE10; // "protected override void Tick(ITick tick)"
            inline constexpr std::uintptr_t ApplyLinearDamping = 0x40FAA10; // "private void ApplyLinearDamping(ref RigidBodyData body, HelicopterHandlingSettingsModel handlingSettings)"
            inline constexpr std::uintptr_t ApplyThrustForces = 0x40FADF0; // "private void ApplyThrustForces(long now, VehicleEngineModel engine, HelicopterHandlingSettingsModel handlingSettings, HelicopterDescription description, Span<float> transformMatrix, HelicopterThrustInputModel thrustInput, PhysicsBodyId bodyId, ref RigidBodyData body, HelicopterHandlingState handlingState)"
            inline constexpr std::uintptr_t CalculateCruiseAcceleration = 0x40FB8B0; // "private Vector3 CalculateCruiseAcceleration(long now, VehicleEngineModel engine, HelicopterHandlingSettingsModel handlingSettings, HelicopterDescription description, Span<float> transformMatrix, HelicopterHandlingState handlingState)"
            inline constexpr std::uintptr_t CalculateThrustAcceleration = 0x40FBB00; // "private Vector3 CalculateThrustAcceleration(HelicopterThrustInputModel thrustInput, HelicopterHandlingSettingsModel handlingSettings, HelicopterDescription description, Span<float> transformMatrix, ref RigidBodyData body, HelicopterHandlingState handlingState)"
            inline constexpr std::uintptr_t CalculateThrustAccelerationModifierByMaxVerticalVelocities = 0x40FBA10; // "private float CalculateThrustAccelerationModifierByMaxVerticalVelocities(float thrust, Span<float> transformMatrix, ref RigidBodyData body, HelicopterHandlingSettingsModel handlingSettings)"
            inline constexpr std::uintptr_t CalculateThrustModifierByHeight = 0x40FBD50; // "private float CalculateThrustModifierByHeight(Span<float> transformMatrix, HelicopterHandlingSettingsModel handlingSettings)"
            inline constexpr std::uintptr_t ApplyTiltForces = 0x40FB110; // "private void ApplyTiltForces(HelicopterHandlingSettingsModel handlingSettings, HelicopterTiltInputModel tiltInput, Span<float> transformMatrix, PhysicsBodyId bodyId, HelicopterHandlingState handlingState)"
            inline constexpr std::uintptr_t ApplyRotationForces = 0x40FAAD0; // "private void ApplyRotationForces(HelicopterHandlingSettingsModel handlingSettings, HelicopterRotationInputModel rotationInput, Span<float> transformMatrix, PhysicsBodyId bodyId, ref RigidBodyData body, HelicopterHandlingState handlingState)"
            inline constexpr std::uintptr_t ApplyAngularResistance = 0x40FA7B0; // "private void ApplyAngularResistance(HelicopterHandlingSettingsModel handlingSettings, Span<float> transformMatrix, ref RigidBodyData body, HelicopterHandlingState handlingState)"
        }
    } // namespace HelicopterControllerHandlingSystem

    namespace HelicopterControllerPreparePhysicsForSubTickSystem { // "Models.Systems.HelicopterControllerPreparePhysicsForSubTickSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsSceneModel = 0x38; // "PhysicsSceneModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x40FC300; // "protected override void Tick(ITick tick)"
            inline constexpr std::uintptr_t CalculateLinksDirection = 0x3F82350; // "private void CalculateLinksDirection(Span<float> transformMatrix, VehicleLinksTickDataModel linksTickData)"
            inline constexpr std::uintptr_t CalculateWheelLink = 0x40FC170; // "private void CalculateWheelLink(HelicopterWheelModel wheel, Span<float> transformMatrix, VehicleWheelLinkTickDataModel wheelLinkTickData)"
        }
    } // namespace HelicopterControllerPreparePhysicsForSubTickSystem

    namespace HelicopterControllerPreparePhysicsForTickSystem { // "Models.Systems.HelicopterControllerPreparePhysicsForTickSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsSceneModel = 0x38; // "PhysicsSceneModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x40FCCC0; // "protected override void Tick(ITick tick)"
            inline constexpr std::uintptr_t CalculateGroundSearchCastLength = 0x3F82A30; // "private float CalculateGroundSearchCastLength(VehicleSuspensionSettingsModel suspensionSettings)"
            inline constexpr std::uintptr_t CalculateLinksDirection = 0x3F82350; // "private void CalculateLinksDirection(Span<float> transformMatrix, VehicleLinksTickDataModel vehicleLinksTickData)"
            inline constexpr std::uintptr_t SetWheelParams = 0x40FCB90; // "private void SetWheelParams(HelicopterWheelModel wheel, HelicopterDescription description, VehicleWheelSuspensionLimitTickDataModel wheelSuspensionLimitTickData, VehicleWheelGroundTickDataModel wheelGroundTickData, VehicleWheelLoadTickDataModel wheelLoadTickData)"
            inline constexpr std::uintptr_t CalculateWheelLink = 0x40FC170; // "private void CalculateWheelLink(HelicopterWheelModel wheel, Span<float> transformMatrix, VehicleWheelLinkTickDataModel wheelLinkTickData)"
            inline constexpr std::uintptr_t CalculateWheelsBoundingBoxAABB = 0x40FC7E0; // "private void CalculateWheelsBoundingBoxAABB(VehicleLinksTickDataModel vehicleLinksTickData, Span<float> transformMatrix, HelicopterDescription description, float groundSearchCastLength)"
        }
    } // namespace HelicopterControllerPreparePhysicsForTickSystem

    namespace HelicopterControllerStateSystem { // "Models.Systems.HelicopterControllerStateSystem (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x40FD4C0; // "protected override void Tick(ITick tick)"
            inline constexpr std::uintptr_t CalculateHandlingState = 0x40FD400; // "private HelicopterHandlingState CalculateHandlingState(int touchGroundWheelsCount)"
            inline constexpr std::uintptr_t GetWheelsTouchGroundCount = 0x40FD460; // "private int GetWheelsTouchGroundCount(VehicleWheelGroundTickDataModel[] wheels)"
        }
    } // namespace HelicopterControllerStateSystem

    namespace HelicopterControllerWheelGroundCheckSystem { // "Models.Systems.HelicopterControllerWheelGroundCheckSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsDebugModel = 0x70; // "IPhysicsDebugModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t DebugLogGroundFound = 0x40FD5F0; // "protected override void DebugLogGroundFound(int entityId, int wheelIndex, VehicleWheelGroundTickDataModel wheelGroundTickData)"
            inline constexpr std::uintptr_t DebugLogGroundNotFound = 0x40FD6B0; // "protected override void DebugLogGroundNotFound(int entityId, int wheelIndex)"
        }
    } // namespace HelicopterControllerWheelGroundCheckSystem

    namespace HelicopterControllerWheelSuspensionSystem { // "Models.Systems.HelicopterControllerWheelSuspensionSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsDebugModel = 0x60; // "IPhysicsDebugModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t DebugLogSuspension = 0x40FD800; // "protected override void DebugLogSuspension(int entityId, int wheelIndex, float springContactDepth, float springContactSpeed, float contactDepth, float contactSpeed, float stiffness, float damper, float linkVelocityAlongSuspensionDirection, float idleForce, float stiffnessForce, float damperForce, float suspensionTotalForce)"
            inline constexpr std::uintptr_t DebugLogSpringLength = 0x40FD750; // "protected override void DebugLogSpringLength(int entityId, int wheelIndex, float springLengthFromData, float springLengthCalculated)"
        }
    } // namespace HelicopterControllerWheelSuspensionSystem

    namespace HelicopterControlOwnerDescription { // "Models.References.Helicopter.HelicopterControlOwnerDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x81D6D70; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t Empty = 0x0; // "HelicopterControlOwnerDescription"
            inline constexpr std::uintptr_t Driver = 0x8; // "HelicopterControlOwnerDescription"
        }
    } // namespace HelicopterControlOwnerDescription

    namespace HelicopterControlOwnerModel { // "Models.Models.HelicopterControlOwner.HelicopterControlOwnerModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t OwnerType = 0x10; // "HelicopterControlOwnerDescription"
            inline constexpr std::uintptr_t Driver = 0x18; // "BattleCharacterModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetEmpty = 0x4964FA0; // "public void SetEmpty()"
            inline constexpr std::uintptr_t SetDriver = 0x4964EF0; // "public void SetDriver(BattleCharacterModel driver)"
        }
    } // namespace HelicopterControlOwnerModel

    namespace HelicopterControlView { // "Game.Battle.Ui.HelicopterControlView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t LeavePointerButtonView = 0x20; // "PointerButtonView"
            inline constexpr std::uintptr_t LeftDpad = 0x28; // "MoveDpadView"
            inline constexpr std::uintptr_t RightDpad = 0x30; // "MoveDpadView"
            inline constexpr std::uintptr_t YawCCWButton = 0x38; // "PointerButtonView"
            inline constexpr std::uintptr_t YawCWButton = 0x40; // "PointerButtonView"
            inline constexpr std::uintptr_t ThrustUpButton = 0x48; // "PointerButtonView"
            inline constexpr std::uintptr_t ThrustDownButton = 0x50; // "PointerButtonView"
        }
    } // namespace HelicopterControlView

    namespace HelicopterData { // "Models.Data.Helicopter.HelicopterData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Description = 0x20; // "HelicopterDescription"
            inline constexpr std::uintptr_t Position = 0x28; // "IPrimitiveData<Vector3>"
            inline constexpr std::uintptr_t Orientation = 0x30; // "IPrimitiveData<Vector4>"
            inline constexpr std::uintptr_t LinearVelocity = 0x38; // "IPrimitiveData<Vector3>"
            inline constexpr std::uintptr_t AngularVelocity = 0x40; // "IPrimitiveData<Vector3>"
            inline constexpr std::uintptr_t FlWheel = 0x48; // "HelicopterWheelData"
            inline constexpr std::uintptr_t FrWheel = 0x50; // "HelicopterWheelData"
            inline constexpr std::uintptr_t BlWheel = 0x58; // "HelicopterWheelData"
            inline constexpr std::uintptr_t BrWheel = 0x60; // "HelicopterWheelData"
            inline constexpr std::uintptr_t Seats = 0x68; // "ReferenceMapData<VehicleSeatSlotDescription, VehicleSeatData>"
            inline constexpr std::uintptr_t ThrustInput = 0x70; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t TiltAroundXInput = 0x78; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t TiltAroundZInput = 0x80; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t RotationInput = 0x88; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t IsWarped = 0x90; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t IsUnowned = 0x98; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t OwnerPublicId = 0xA0; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t OwnerRole = 0xA8; // "IPrimitiveData<PlayerRoleDescription>"
            inline constexpr std::uintptr_t EngineStateChangeOverTs = 0xB0; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t EngineActive = 0xB8; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t HasFreeCargoSlot = 0xC0; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t HasCargo = 0xC8; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t IsTrunkOpened = 0xD0; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t IsDrowned = 0xD8; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t WaterState = 0xE0; // "IPrimitiveData<VehicleWaterStateDescription>"
            inline constexpr std::uintptr_t RadioStation = 0xE8; // "IPrimitiveData<RadioStationDescription>"
            inline constexpr std::uintptr_t DirtLevel = 0xF0; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t ClanBattleTeamOwner = 0xF8; // "IPrimitiveData<ClanBattleTeamDescription>"
            inline constexpr std::uintptr_t SleepCounter = 0x100; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t TrunkBreachData = 0x108; // "BreachEntityData"
            inline constexpr std::uintptr_t IsRented = 0x110; // "IPrimitiveData<bool>"
        }
    } // namespace HelicopterData

    namespace HelicopterDescription { // "Models.References.Helicopter.HelicopterDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t SeatsDescriptionLazy = 0x20; // "Lazy<VehicleSeatsDescription>"
            inline constexpr std::uintptr_t CollidersDescriptionFunc = 0x28; // "Func<VehicleCollidersDescription>"
            inline constexpr std::uintptr_t RotorsDescriptionFunc = 0x30; // "Func<HelicopterRotorsDescription>"
            inline constexpr std::uintptr_t EngineFunc = 0x38; // "Func<VehicleEngineDescription>"
            inline constexpr std::uintptr_t InteractFunc = 0x40; // "Func<VehicleInteractDescription>"
            inline constexpr std::uintptr_t SuspensionFunc = 0x48; // "Func<VehicleSuspensionDescription>"
            inline constexpr std::uintptr_t ChassisFunc = 0x50; // "Func<HelicopterChassisDescription>"
            inline constexpr std::uintptr_t GroupType = 0x58; // "VehicleGroupType"
            inline constexpr std::uintptr_t HelicopterSlotFunc = 0x60; // "Func<HelicopterSlotDescription>"
            inline constexpr std::uintptr_t AvailableOnStart = 0x68; // "bool"
            inline constexpr std::uintptr_t CryptoCoinsPrice = 0x6C; // "int"
            inline constexpr std::uintptr_t CompensationCryptoCoins = 0x70; // "int"
            inline constexpr std::uintptr_t ImprisonmentYearsRequired = 0x74; // "int"
            inline constexpr std::uintptr_t IsHidden = 0x78; // "bool"
            inline constexpr std::uintptr_t PhysicsDescriptionFunc = 0x80; // "Func<HelicopterPhysicsDescription>"
            inline constexpr std::uintptr_t helicopterPhysics = 0x88; // "Lazy<HelicopterDescription.HelicopterPhysics>"
            inline constexpr std::uintptr_t HandlingFunc = 0x90; // "Func<HelicopterHandlingDescription>"
            inline constexpr std::uintptr_t WheelsBaseFunc = 0x98; // "Func<HelicopterWheelsBaseDescription>"
            inline constexpr std::uintptr_t DrownPointsFunc = 0xA0; // "Func<VehicleDrownPointsDescription>"
            inline constexpr std::uintptr_t InteractionPointsDescriptionFunc = 0xA8; // "Func<HelicopterInteractionPointsDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_SeatsDescription = 0x440E730; // "private VehicleSeatsDescription get_SeatsDescription()"
            inline constexpr std::uintptr_t get_CollidersDescription = 0x993E50; // "public VehicleCollidersDescription get_CollidersDescription()"
            inline constexpr std::uintptr_t get_RotorsDescription = 0x9AA5D0; // "public HelicopterRotorsDescription get_RotorsDescription()"
            inline constexpr std::uintptr_t get_Engine = 0x2AA0B60; // "public VehicleEngineDescription get_Engine()"
            inline constexpr std::uintptr_t get_Interact = 0x4048E60; // "public VehicleInteractDescription get_Interact()"
            inline constexpr std::uintptr_t get_Suspension = 0x4048E90; // "public VehicleSuspensionDescription get_Suspension()"
            inline constexpr std::uintptr_t get_Chassis = 0x1CE7810; // "public HelicopterChassisDescription get_Chassis()"
            inline constexpr std::uintptr_t get_GarageSlotColliders = 0x440E190; // "public CollidersDescription get_GarageSlotColliders()"
            inline constexpr std::uintptr_t get_HelicopterSlot = 0x4048EC0; // "public HelicopterSlotDescription get_HelicopterSlot()"
            inline constexpr std::uintptr_t get_HasSkinPrice = 0x440E2E0; // "public bool get_HasSkinPrice()"
            inline constexpr std::uintptr_t get_BuyParams = 0x440DBF0; // "public ValueTuple<int, int> get_BuyParams()"
            inline constexpr std::uintptr_t get_PhysicsDescription = 0x4048F50; // "public HelicopterPhysicsDescription get_PhysicsDescription()"
            inline constexpr std::uintptr_t get_InvMass = 0x440E430; // "public float get_InvMass()"
            inline constexpr std::uintptr_t get_LocalInvInertiaTensorCol0 = 0x440E4D0; // "public Vector3 get_LocalInvInertiaTensorCol0()"
            inline constexpr std::uintptr_t get_LocalInvInertiaTensorCol1 = 0x440E520; // "public Vector3 get_LocalInvInertiaTensorCol1()"
            inline constexpr std::uintptr_t get_LocalInvInertiaTensorCol2 = 0x440E570; // "public Vector3 get_LocalInvInertiaTensorCol2()"
            inline constexpr std::uintptr_t get_InertiaBoxShapeSize = 0x440E3E0; // "public Vector3 get_InertiaBoxShapeSize()"
            inline constexpr std::uintptr_t get_HP = 0x440E260; // "private HelicopterDescription.HelicopterPhysics get_HP()"
            inline constexpr std::uintptr_t get_Load = 0x440E470; // "public float get_Load()"
            inline constexpr std::uintptr_t get_ColliderShapeRelativeToCenterOfMass = 0x440DD40; // "public CompoundShape get_ColliderShapeRelativeToCenterOfMass()"
            inline constexpr std::uintptr_t get_ColliderShapeRelativeToPivot = 0x440DDA0; // "public CompoundShape get_ColliderShapeRelativeToPivot()"
            inline constexpr std::uintptr_t get_BoundingBoxLocalPositionRelativeToCenterOfMass = 0x440D9F0; // "public Vector3 get_BoundingBoxLocalPositionRelativeToCenterOfMass()"
            inline constexpr std::uintptr_t get_BoundingBoxLocalPositionRelativeToPivot = 0x440DA60; // "public Vector3 get_BoundingBoxLocalPositionRelativeToPivot()"
            inline constexpr std::uintptr_t get_BoundingBoxSize = 0x440DAB0; // "public Vector3 get_BoundingBoxSize()"
            inline constexpr std::uintptr_t get_BoundingSphereRadius = 0x440DB00; // "public float get_BoundingSphereRadius()"
            inline constexpr std::uintptr_t get_EffectiveStaticModifierForForwardWheels = 0x440E010; // "public float get_EffectiveStaticModifierForForwardWheels()"
            inline constexpr std::uintptr_t get_EffectiveStaticModifierForBackwardWheels = 0x440DFB0; // "public float get_EffectiveStaticModifierForBackwardWheels()"
            inline constexpr std::uintptr_t get_EffectiveStaticLoadOnForwardWheel = 0x440DE90; // "public float get_EffectiveStaticLoadOnForwardWheel()"
            inline constexpr std::uintptr_t get_EffectiveStaticLoadOnBackwardWheel = 0x440DE30; // "public float get_EffectiveStaticLoadOnBackwardWheel()"
            inline constexpr std::uintptr_t get_EffectiveStaticMassOnForwardWheel = 0x440DF50; // "public float get_EffectiveStaticMassOnForwardWheel()"
            inline constexpr std::uintptr_t get_EffectiveStaticMassOnBackwardWheel = 0x440DEF0; // "public float get_EffectiveStaticMassOnBackwardWheel()"
            inline constexpr std::uintptr_t get_SeatsType = 0x440E780; // "public VehicleSeatTypeDescription get_SeatsType()"
            inline constexpr std::uintptr_t get_Seats = 0x440E7D0; // "public ReadOnly.Dictionary<VehicleSeatSlotDescription, VehicleSeatDescription> get_Seats()"
            inline constexpr std::uintptr_t get_DriverSlot = 0x440DDD0; // "public VehicleSeatSlotDescription get_DriverSlot()"
            inline constexpr std::uintptr_t get_HitBox = 0x440E3B0; // "public TransformHitBoxDescription get_HitBox()"
            inline constexpr std::uintptr_t get_CenterOfMassToPivotOffsetInLocalSpace = 0x440DC60; // "public Vector3 get_CenterOfMassToPivotOffsetInLocalSpace()"
            inline constexpr std::uintptr_t get_PivotToCenterOfMassOffsetInLocalSpace = 0x440E6C0; // "public Vector3 get_PivotToCenterOfMassOffsetInLocalSpace()"
            inline constexpr std::uintptr_t get_CenterOfMassToWheelBaseCenterOffsetInLocalSpace = 0x440DCD0; // "public Vector3 get_CenterOfMassToWheelBaseCenterOffsetInLocalSpace()"
            inline constexpr std::uintptr_t get_MainRotorLocalPositionRelativeToCenterOfMass = 0x440E5C0; // "public Vector3 get_MainRotorLocalPositionRelativeToCenterOfMass()"
            inline constexpr std::uintptr_t get_MainRotorLocalPositionRelativeToPivot = 0x440E630; // "public Vector3 get_MainRotorLocalPositionRelativeToPivot()"
            inline constexpr std::uintptr_t get_Gravity = 0x440E220; // "public float get_Gravity()"
            inline constexpr std::uintptr_t get_GravityForce = 0x440E1D0; // "public Vector3 get_GravityForce()"
            inline constexpr std::uintptr_t get_MaxLinearVelocity = 0x440E680; // "public float get_MaxLinearVelocity()"
            inline constexpr std::uintptr_t get_Handling = 0x440E2B0; // "public HelicopterHandlingDescription get_Handling()"
            inline constexpr std::uintptr_t get_WheelsBase = 0x4067080; // "public HelicopterWheelsBaseDescription get_WheelsBase()"
            inline constexpr std::uintptr_t get_DrownPoints = 0x40671C0; // "public VehicleDrownPointsDescription get_DrownPoints()"
            inline constexpr std::uintptr_t get_InteractionPointsDescription = 0x4067190; // "public HelicopterInteractionPointsDescription get_InteractionPointsDescription()"
            inline constexpr std::uintptr_t get_HasTrunk = 0x440E2F0; // "public bool get_HasTrunk()"
            inline constexpr std::uintptr_t get_TrunkLocalPosition = 0x440E830; // "public Vector3 get_TrunkLocalPosition()"
            inline constexpr std::uintptr_t get_VerticalDistanceFromPivotToGroundInRest = 0x440E880; // "public float get_VerticalDistanceFromPivotToGroundInRest()"
            inline constexpr std::uintptr_t get_HeightFromGroundInRest = 0x440E350; // "public float get_HeightFromGroundInRest()"
            inline constexpr std::uintptr_t get_VerticalLocalCenterFromGroundInRestRelativeToPivot = 0x440E8E0; // "public float get_VerticalLocalCenterFromGroundInRestRelativeToPivot()"
            inline constexpr std::uintptr_t get_CanRefillCopAmmo = 0x440DC50; // "public bool get_CanRefillCopAmmo()"
            inline constexpr std::uintptr_t get_Wheels = 0x440E940; // "public IReadOnlyList<VehicleWheelDescription> get_Wheels()"
            inline constexpr std::uintptr_t get_FlWheel = 0x440E070; // "public VehicleWheelDescription get_FlWheel()"
            inline constexpr std::uintptr_t get_FrWheel = 0x440E100; // "public VehicleWheelDescription get_FrWheel()"
            inline constexpr std::uintptr_t get_BlWheel = 0x440D960; // "public VehicleWheelDescription get_BlWheel()"
            inline constexpr std::uintptr_t get_BrWheel = 0x440DB60; // "public VehicleWheelDescription get_BrWheel()"
            inline constexpr std::uintptr_t CalculatePivotToCenterOfMassOffsetInLocalSpace = 0x440D6C0; // "private Vector3 CalculatePivotToCenterOfMassOffsetInLocalSpace(HelicopterPhysicsDescription physicsDescription, HelicopterRotorsDescription rotorsDescription)"
            inline constexpr std::uintptr_t CalculateHelicopterPhysics = 0x440CDB0; // "private HelicopterDescription.HelicopterPhysics CalculateHelicopterPhysics()"
        }
    } // namespace HelicopterDescription

    namespace HelicopterDescription_HelicopterPhysics { // "Models.References.Helicopter.HelicopterDescription.HelicopterPhysics (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t PivotToCenterOfMassOffsetInLocalSpace = 0x10; // "Vector3"
            inline constexpr std::uintptr_t CenterOfMassToPivotOffsetInLocalSpace = 0x1C; // "Vector3"
            inline constexpr std::uintptr_t CenterOfMassToWheelBaseCenterOffsetInLocalSpace = 0x28; // "Vector3"
            inline constexpr std::uintptr_t Wheels = 0x38; // "IReadOnlyList<VehicleWheelDescription>"
            inline constexpr std::uintptr_t Load = 0x40; // "float"
            inline constexpr std::uintptr_t EffectiveStaticModifierForForwardWheels = 0x44; // "float"
            inline constexpr std::uintptr_t EffectiveStaticModifierForBackwardWheels = 0x48; // "float"
            inline constexpr std::uintptr_t EffectiveStaticLoadOnForwardWheel = 0x4C; // "float"
            inline constexpr std::uintptr_t EffectiveStaticLoadOnBackwardWheel = 0x50; // "float"
            inline constexpr std::uintptr_t EffectiveStaticMassOnForwardWheel = 0x54; // "float"
            inline constexpr std::uintptr_t EffectiveStaticMassOnBackwardWheel = 0x58; // "float"
            inline constexpr std::uintptr_t ColliderShapeRelativeToCenterOfMass = 0x60; // "CompoundShape"
            inline constexpr std::uintptr_t BoundingBoxLocalPositionRelativeToCenterOfMass = 0x68; // "Vector3"
            inline constexpr std::uintptr_t BoundingSphereRadius = 0x74; // "float"
            inline constexpr std::uintptr_t MainRotorLocalPositionRelativeToCenterOfMass = 0x78; // "Vector3"
            inline constexpr std::uintptr_t VerticalDistanceFromPivotToGroundInRest = 0x84; // "float"
            inline constexpr std::uintptr_t HeightFromGroundInRest = 0x88; // "float"
            inline constexpr std::uintptr_t VerticalLocalCenterFromGroundInRestRelativeToPivot = 0x8C; // "float"
        }
    } // namespace HelicopterDescription_HelicopterPhysics

    namespace HelicopterDescriptionUtility { // "Game.Battle.EntityModel.Helicopter.HelicopterDescriptionUtility (Battle.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x81D8260; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t Skins = 0x0; // "IReadOnlyDictionary<HelicopterSlotDescription, IReadOnlyList<HelicopterDescription>>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t IndexOf = 0xC8C2F0; // "public static int IndexOf(HelicopterDescription car)"
        }
    } // namespace HelicopterDescriptionUtility

    namespace HelicopterDestroyModel { // "Models.Models.HelicopterDestroy.HelicopterDestroyModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "HelicopterModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Destroy = 0x4965050; // "public void Destroy(PhysicsSceneModel physicsSceneModel, WorldEntitiesModel worldEntitiesModel, PhysicsBodiesModel physicsBodiesModel)"
        }
    } // namespace HelicopterDestroyModel

    namespace HelicopterEngineClientModel { // "Game.Battle.EntityModel.Helicopter.Models.HelicopterEngineClientModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t NormalizedSpeed = 0x10; // "float"
        }
    } // namespace HelicopterEngineClientModel

    namespace HelicopterEngineRulesModel { // "Models.Models.VehicleEngineRules.HelicopterEngineRulesModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t transformTickData = 0x18; // "VehicleTransformTickDataModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t IsEngineShouldBeActiveBySpecialRules = 0x48B75C0; // "protected override bool IsEngineShouldBeActiveBySpecialRules()"
        }
    } // namespace HelicopterEngineRulesModel

    namespace HelicopterEngineSpeedUpdater { // "Game.Battle.EntityModel.Helicopter.Updaters.HelicopterEngineSpeedUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t engineClientModel = 0x10; // "HelicopterEngineClientModel"
            inline constexpr std::uintptr_t engineServerModel = 0x18; // "VehicleEngineModel"
            inline constexpr std::uintptr_t timelineTimeOffset = 0x20; // "TimelineTimeOffsetModel"
            inline constexpr std::uintptr_t timelineSnapshots = 0x28; // "TimelineSnapshotsData<HelicopterTimelineData>"
            inline constexpr std::uintptr_t timelineExtrapolations = 0x30; // "TimelineExtrapolationsData<HelicopterTimelineData>"
            inline constexpr std::uintptr_t engineSpeedCurve = 0x38; // "AnimationCurve"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC8C980; // "public void Update()"
            inline constexpr std::uintptr_t GetServerNormalizedSpeed = 0xC8C810; // "private float GetServerNormalizedSpeed(long ts)"
        }
    } // namespace HelicopterEngineSpeedUpdater

    namespace HelicopterEntityDataBuilder { // "Models.Replication.EntityDataBuilder.HelicopterEntityDataBuilder (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t paramsModel = 0x10; // "EntitiesParamsModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Build = 0x44B8370; // "public IData Build(int id)"
        }
    } // namespace HelicopterEntityDataBuilder

    namespace HelicopterEntityModel { // "Game.Battle.EntityModel.Helicopter.Models.HelicopterEntityModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ServerModel = 0x18; // "HelicopterModel"
            inline constexpr std::uintptr_t ClientModel = 0x20; // "HelicopterClientModel"
        }
    } // namespace HelicopterEntityModel

    namespace HelicopterEntityModelUpdater { // "Game.Battle.EntityModel.Helicopter.Updaters.HelicopterEntityModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t updater = 0x10; // "IUpdater"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC8CB20; // "public void Update()"
        }
    } // namespace HelicopterEntityModelUpdater

    namespace HelicopterEntitySkinViewUpdater { // "Game.Battle.Entities.Helicopter.Updaters.HelicopterEntitySkinViewUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t entityModel = 0x10; // "HelicopterEntityModel"
            inline constexpr std::uintptr_t globalModel = 0x18; // "GlobalModel"
            inline constexpr std::uintptr_t battleModel = 0x20; // "BattleModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x28; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t screenContent = 0x30; // "BattleScreenContent"
            inline constexpr std::uintptr_t locationScreenViewModel = 0x38; // "LocationScreenViewModel"
            inline constexpr std::uintptr_t targetSubsystem = 0x40; // "ITargetSubsystem"
            inline constexpr std::uintptr_t raycastModel = 0x48; // "RaycastModel"
            inline constexpr std::uintptr_t helicopterEntityViews = 0x50; // "Dictionary<int, HelicopterEntityView>"
            inline constexpr std::uintptr_t vehicleCollidersViews = 0x58; // "Dictionary<int, VehicleEntityView>"
            inline constexpr std::uintptr_t helicopterViewDescription = 0x60; // "HelicopterViewDescription"
            inline constexpr std::uintptr_t helicopterSkinViewDescription = 0x68; // "HelicopterSkinViewDescription"
            inline constexpr std::uintptr_t registerDisposable = 0x70; // "IRegisterDisposable"
            inline constexpr std::uintptr_t vehiclesLoadingModel = 0x78; // "ScopesLoadingModel"
            inline constexpr std::uintptr_t viewUpdater = 0x80; // "IUpdater"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB69C00; // "public void Update()"
            inline constexpr std::uintptr_t CreateHelicopter = 0xB694E0; // "private void CreateHelicopter()"
        }
    } // namespace HelicopterEntitySkinViewUpdater

    namespace HelicopterEntityStreamReader { // "Models.Replication.EntityStreamReader.HelicopterEntityStreamReader (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t paramsModel = 0x20; // "EntitiesParamsModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t TryReadParams = 0x44B8470; // "protected override bool TryReadParams(int entityId, IBinaryReadStream stream)"
        }
    } // namespace HelicopterEntityStreamReader

    namespace HelicopterEntityTrunkEntityDataBuilder { // "Models.Replication.EntityDataBuilder.HelicopterEntityTrunkEntityDataBuilder (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t paramsModel = 0x10; // "EntitiesParamsModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Build = 0x44B8570; // "public IData Build(int id)"
        }
    } // namespace HelicopterEntityTrunkEntityDataBuilder

    namespace HelicopterEntityView { // "Game.Battle.EntityModel.Helicopter.Views.HelicopterEntityView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t VehicleEntity = 0x20; // "VehicleEntityView"
            inline constexpr std::uintptr_t AnimationView = 0x28; // "VehicleAnimationView"
            inline constexpr std::uintptr_t Transform = 0x30; // "Transform"
            inline constexpr std::uintptr_t MainRotor = 0x38; // "HelicopterRotorView"
            inline constexpr std::uintptr_t SecondaryRotor = 0x40; // "HelicopterRotorView"
            inline constexpr std::uintptr_t HelicopterBladeBlurView = 0x48; // "HelicopterBladeBlurView"
            inline constexpr std::uintptr_t LeftChassis = 0x50; // "HelicopterChassisView"
            inline constexpr std::uintptr_t RightChassis = 0x58; // "HelicopterChassisView"
            inline constexpr std::uintptr_t HelicopterMaterialView = 0x60; // "HelicopterMaterialView"
            inline constexpr std::uintptr_t MaterialInstanceProvider = 0x68; // "MaterialInstanceWrapper"
            inline constexpr std::uintptr_t LightProbeReceiver = 0x70; // "LightProbeReceiver"
            inline constexpr std::uintptr_t LandingEffectPoint = 0x78; // "Transform"
            inline constexpr std::uintptr_t PresentationCamera = 0x80; // "CinemachineVirtualCamera"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetPosition = 0xC8F890; // "public void SetPosition(in Vector3 position)"
            inline constexpr std::uintptr_t SetOrientation = 0xC8F860; // "public void SetOrientation(in Quaternion orientation)"
        }
    } // namespace HelicopterEntityView

    namespace HelicopterEntityViewUpdater { // "Game.Battle.EntityModel.Helicopter.Updaters.HelicopterEntityViewUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t updater = 0x10; // "IUpdater"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC8D8F0; // "public void Update()"
        }
    } // namespace HelicopterEntityViewUpdater

    namespace HelicopterHandlingDescription { // "Models.References.Helicopter.HelicopterHandlingDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t MainRotorCruiseAcceleration = 0x20; // "float"
            inline constexpr std::uintptr_t MainRotorThrustMaxAcceleration = 0x24; // "float"
            inline constexpr std::uintptr_t MainRotorThrustMaxDeceleration = 0x28; // "float"
            inline constexpr std::uintptr_t MaxPositiveVerticalVelocity = 0x2C; // "float"
            inline constexpr std::uintptr_t MaxNegativeVerticalVelocity = 0x30; // "float"
            inline constexpr std::uintptr_t MaxHeightSoft = 0x34; // "float"
            inline constexpr std::uintptr_t MaxHeightHard = 0x38; // "float"
            inline constexpr std::uintptr_t LinearVelocityDamping = 0x3C; // "float"
            inline constexpr std::uintptr_t RotationResistanceAroundX = 0x40; // "float"
            inline constexpr std::uintptr_t RotationResistanceAroundY = 0x44; // "float"
            inline constexpr std::uintptr_t RotationResistanceAroundZ = 0x48; // "float"
            inline constexpr std::uintptr_t TiltAccelerationAroundX = 0x4C; // "float"
            inline constexpr std::uintptr_t TiltAccelerationAroundZ = 0x50; // "float"
            inline constexpr std::uintptr_t RotationAccelerationAroundY = 0x54; // "float"
            inline constexpr std::uintptr_t MaxTiltAngleDegree = 0x58; // "float"
            inline constexpr std::uintptr_t MaxTiltAngleCos = 0x5C; // "float"
            inline constexpr std::uintptr_t TiltAdditionalForceModifier = 0x60; // "float"
            inline constexpr std::uintptr_t SideSlipForceModifier = 0x64; // "float"
            inline constexpr std::uintptr_t SideSlipTorqueModifier = 0x68; // "float"
        }
    } // namespace HelicopterHandlingDescription

    namespace HelicopterHandlingSettingsModel { // "Models.Models.HelicopterHandlingSettings.HelicopterHandlingSettingsModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t description = 0x10; // "HelicopterHandlingDescription"
            inline constexpr std::uintptr_t overrideModel = 0x18; // "HelicopterHandlingSettingsOverrideModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_MainRotorCruiseAcceleration = 0x492DB80; // "public float get_MainRotorCruiseAcceleration()"
            inline constexpr std::uintptr_t get_MainRotorThrustMaxAcceleration = 0x492DC50; // "public float get_MainRotorThrustMaxAcceleration()"
            inline constexpr std::uintptr_t get_MainRotorThrustMaxDeceleration = 0x492DD20; // "public float get_MainRotorThrustMaxDeceleration()"
            inline constexpr std::uintptr_t get_MaxPositiveVerticalVelocity = 0x492E060; // "public float get_MaxPositiveVerticalVelocity()"
            inline constexpr std::uintptr_t get_MaxNegativeVerticalVelocity = 0x492DF90; // "public float get_MaxNegativeVerticalVelocity()"
            inline constexpr std::uintptr_t get_MaxHeightSoft = 0x492DEC0; // "public float get_MaxHeightSoft()"
            inline constexpr std::uintptr_t get_MaxHeightHard = 0x492DDF0; // "public float get_MaxHeightHard()"
            inline constexpr std::uintptr_t get_LinearVelocityDamping = 0x492DAB0; // "public float get_LinearVelocityDamping()"
            inline constexpr std::uintptr_t get_RotationResistanceAroundX = 0x492E2D0; // "public float get_RotationResistanceAroundX()"
            inline constexpr std::uintptr_t get_RotationResistanceAroundY = 0x492E3A0; // "public float get_RotationResistanceAroundY()"
            inline constexpr std::uintptr_t get_RotationResistanceAroundZ = 0x492E470; // "public float get_RotationResistanceAroundZ()"
            inline constexpr std::uintptr_t get_TiltAccelerationAroundX = 0x492E6E0; // "public float get_TiltAccelerationAroundX()"
            inline constexpr std::uintptr_t get_TiltAccelerationAroundZ = 0x492E7B0; // "public float get_TiltAccelerationAroundZ()"
            inline constexpr std::uintptr_t get_RotationAccelerationAroundY = 0x492E200; // "public float get_RotationAccelerationAroundY()"
            inline constexpr std::uintptr_t get_MaxTiltAngleCos = 0x492E130; // "public float get_MaxTiltAngleCos()"
            inline constexpr std::uintptr_t get_TiltAdditionalForceModifier = 0x492E880; // "public float get_TiltAdditionalForceModifier()"
            inline constexpr std::uintptr_t get_SideSlipForceModifier = 0x492E540; // "public float get_SideSlipForceModifier()"
            inline constexpr std::uintptr_t get_SideSlipTorqueModifier = 0x492E610; // "public float get_SideSlipTorqueModifier()"
        }
    } // namespace HelicopterHandlingSettingsModel

    namespace HelicopterHandlingSettingsOverrideData { // "Models.Data.SettingsOverride.Helicopters.HelicopterHandlingSettingsOverrideData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t OverrideEnabled = 0x20; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t MainRotorCruiseAcceleration = 0x28; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t MainRotorThrustMaxAcceleration = 0x30; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t MainRotorThrustMaxDeceleration = 0x38; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t MaxPositiveVerticalVelocity = 0x40; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t MaxNegativeVerticalVelocity = 0x48; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t MaxHeightSoft = 0x50; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t MaxHeightHard = 0x58; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t LinearVelocityDamping = 0x60; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t RotationResistanceAroundX = 0x68; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t RotationResistanceAroundY = 0x70; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t RotationResistanceAroundZ = 0x78; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t TiltAccelerationAroundX = 0x80; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t TiltAccelerationAroundZ = 0x88; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t RotationAccelerationAroundY = 0x90; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t MaxTiltAngleCos = 0x98; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t TiltAdditionalForceModifier = 0xA0; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t SideSlipForceModifier = 0xA8; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t SideSlipTorqueModifier = 0xB0; // "IPrimitiveData<float>"
        }
    } // namespace HelicopterHandlingSettingsOverrideData

    namespace HelicopterHandlingSettingsOverrideModel { // "Models.Models.HelicopterHandlingSettingsOverride.HelicopterHandlingSettingsOverrideModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "HelicopterHandlingSettingsOverrideData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_OverrideEnabled = 0x492F0B0; // "public bool get_OverrideEnabled()"
            inline constexpr std::uintptr_t get_MainRotorCruiseAcceleration = 0x492EE20; // "public float get_MainRotorCruiseAcceleration()"
            inline constexpr std::uintptr_t get_MainRotorThrustMaxAcceleration = 0x492EE70; // "public float get_MainRotorThrustMaxAcceleration()"
            inline constexpr std::uintptr_t get_MainRotorThrustMaxDeceleration = 0x492EEC0; // "public float get_MainRotorThrustMaxDeceleration()"
            inline constexpr std::uintptr_t get_MaxPositiveVerticalVelocity = 0x492F000; // "public float get_MaxPositiveVerticalVelocity()"
            inline constexpr std::uintptr_t get_MaxNegativeVerticalVelocity = 0x492EFB0; // "public float get_MaxNegativeVerticalVelocity()"
            inline constexpr std::uintptr_t get_MaxHeightSoft = 0x492EF60; // "public float get_MaxHeightSoft()"
            inline constexpr std::uintptr_t get_MaxHeightHard = 0x492EF10; // "public float get_MaxHeightHard()"
            inline constexpr std::uintptr_t get_LinearVelocityDamping = 0x492EDD0; // "public float get_LinearVelocityDamping()"
            inline constexpr std::uintptr_t get_RotationResistanceAroundX = 0x492F160; // "public float get_RotationResistanceAroundX()"
            inline constexpr std::uintptr_t get_RotationResistanceAroundY = 0x492F1B0; // "public float get_RotationResistanceAroundY()"
            inline constexpr std::uintptr_t get_RotationResistanceAroundZ = 0x492F200; // "public float get_RotationResistanceAroundZ()"
            inline constexpr std::uintptr_t get_TiltAccelerationAroundX = 0x492F310; // "public float get_TiltAccelerationAroundX()"
            inline constexpr std::uintptr_t get_TiltAccelerationAroundZ = 0x492F370; // "public float get_TiltAccelerationAroundZ()"
            inline constexpr std::uintptr_t get_RotationAccelerationAroundY = 0x492F100; // "public float get_RotationAccelerationAroundY()"
            inline constexpr std::uintptr_t get_MaxTiltAngleCos = 0x492F050; // "public float get_MaxTiltAngleCos()"
            inline constexpr std::uintptr_t get_TiltAdditionalForceModifier = 0x492F3D0; // "public float get_TiltAdditionalForceModifier()"
            inline constexpr std::uintptr_t get_SideSlipForceModifier = 0x492F250; // "public float get_SideSlipForceModifier()"
            inline constexpr std::uintptr_t get_SideSlipTorqueModifier = 0x492F2B0; // "public float get_SideSlipTorqueModifier()"
            inline constexpr std::uintptr_t SetOverrideData = 0x492E950; // "public void SetOverrideData(float mainRotorCruiseAcceleration, float mainRotorThrustMaxAcceleration, float mainRotorThrustMaxDeceleration, float maxPositiveVerticalVelocity, float maxNegativeVerticalVelocity, float maxHeightSoft, float maxHeightHard, float linearVelocityDamping, float rotationResistanceAroundX, float rotationResistanceAroundY, float rotationResistanceAroundZ, float tiltAccelerationAroundX, float tiltAccelerationAroundZ, float rotationAccelerationAroundY, float maxTiltAngleCos, float tiltAdditionalForceModifier, float sideSlipForceModifier, float sideSlipTorqueModifier)"
        }
    } // namespace HelicopterHandlingSettingsOverrideModel

    namespace HelicopterHeightUpdater { // "Game.Battle.Entities.Helicopter.Updaters.HelicopterHeightUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t helicopterHeightView = 0x10; // "HelicopterHeightView"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x18; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t heightProgress = 0x20; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB69F50; // "public void Update()"
            inline constexpr std::uintptr_t GetHeightProgress = 0xB69ED0; // "private float GetHeightProgress(HelicopterModel helicopter)"
        }
    } // namespace HelicopterHeightUpdater

    namespace HelicopterHeightView { // "Game.Battle.Entities.Helicopter.Views.HelicopterHeightView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t heightProgress = 0x20; // "Image"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetHeightProgress = 0x9A55F0; // "public void SetHeightProgress(float height)"
        }
    } // namespace HelicopterHeightView

    namespace HelicopterInitializeModel { // "Models.Models.HelicopterInitialize.HelicopterInitializeModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "HelicopterModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Initialize = 0x492FD90; // "public void Initialize(PhysicsSceneModel physicsSceneModel, WorldEntitiesModel worldEntitiesModel, PhysicsBodiesModel physicsBodiesModel, in Vector3 pivotPosition, in Quaternion pivotOrientation)"
            inline constexpr std::uintptr_t InitializePhysicsBody = 0x492FC10; // "private PhysicsBodyId InitializePhysicsBody(PhysicsSceneModel physicsSceneModel, in Vector3 centerOfMassPosition, in Quaternion centerOfMassOrientation, HelicopterDescription description)"
            inline constexpr std::uintptr_t BuildVehicle = 0x492F430; // "private VehicleModel BuildVehicle()"
        }
    } // namespace HelicopterInitializeModel

    namespace HelicopterInputHintUiUpdater { // "Game.Battle.Entities.Helicopter.Updaters.HelicopterInputHintUiUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t hintState = 0x10; // "StateElementBase"
            inline constexpr std::uintptr_t inputSetting = 0x18; // "IChangeBufferValue<HelicopterInputSetting>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB6A1D0; // "public void Update()"
        }
    } // namespace HelicopterInputHintUiUpdater

    namespace HelicopterInputUpdater { // "Game.Battle.EntityModel.Helicopter.Updaters.HelicopterInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t thrustInputClientModel = 0x10; // "HelicopterThrustInputClientModel"
            inline constexpr std::uintptr_t timelineTimeOffset = 0x18; // "TimelineTimeOffsetModel"
            inline constexpr std::uintptr_t timelineSnapshots = 0x20; // "TimelineSnapshotsData<HelicopterTimelineData>"
            inline constexpr std::uintptr_t timelineExtrapolations = 0x28; // "TimelineExtrapolationsData<HelicopterTimelineData>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC8FA00; // "public void Update()"
            inline constexpr std::uintptr_t GetServerThrustInput = 0xC8F8D0; // "private float GetServerThrustInput(long ts)"
        }
    } // namespace HelicopterInputUpdater

    namespace HelicopterInteractionPointsDescription { // "Models.References.Helicopter.HelicopterInteractionPointsDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t LocalInteractPoint = 0x20; // "Vector3"
            inline constexpr std::uintptr_t InteractDescription = 0x30; // "InteractDescription"
            inline constexpr std::uintptr_t TrunkLocalInteractPoint = 0x38; // "Vector3"
            inline constexpr std::uintptr_t TrunkInteractDescription = 0x48; // "InteractDescription"
        }
    } // namespace HelicopterInteractionPointsDescription

    namespace HelicopterItemTypeViewDescription { // "Game.Battle.ItemType.HelicopterItemTypeViewDescription (Global.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x35596F0; // "public override InventoryItemType get_Type()"
        }
    } // namespace HelicopterItemTypeViewDescription

    namespace HelicopterModel { // "Models.Models.Helicopter.HelicopterModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Id = 0x10; // "int"
            inline constexpr std::uintptr_t BodyId = 0x14; // "PhysicsBodyId"
            inline constexpr std::uintptr_t Initialize = 0x20; // "HelicopterInitializeModel"
            inline constexpr std::uintptr_t Destroy = 0x28; // "HelicopterDestroyModel"
            inline constexpr std::uintptr_t ThrustInput = 0x30; // "HelicopterThrustInputModel"
            inline constexpr std::uintptr_t TiltInput = 0x38; // "HelicopterTiltInputModel"
            inline constexpr std::uintptr_t RotationInput = 0x40; // "HelicopterRotationInputModel"
            inline constexpr std::uintptr_t Description = 0x48; // "HelicopterDescription"
            inline constexpr std::uintptr_t HandlingSettings = 0x50; // "HelicopterHandlingSettingsModel"
            inline constexpr std::uintptr_t SuspensionSettings = 0x58; // "VehicleSuspensionSettingsModel"
            inline constexpr std::uintptr_t ChassisSettings = 0x60; // "HelicopterChassisSettingsModel"
            inline constexpr std::uintptr_t EngineSettings = 0x68; // "VehicleEngineSettingsModel"
            inline constexpr std::uintptr_t Transform = 0x70; // "VehicleTransformModel"
            inline constexpr std::uintptr_t LinearVelocity = 0x78; // "VelocityModel"
            inline constexpr std::uintptr_t AngularVelocity = 0x80; // "VelocityModel"
            inline constexpr std::uintptr_t Wheels = 0x88; // "HelicopterWheelsModel"
            inline constexpr std::uintptr_t Seats = 0x90; // "VehicleSeatsModel"
            inline constexpr std::uintptr_t Engine = 0x98; // "VehicleEngineModel"
            inline constexpr std::uintptr_t EngineRules = 0xA0; // "VehicleEngineRulesModel"
            inline constexpr std::uintptr_t Sleep = 0xA8; // "VehicleSleepModel"
            inline constexpr std::uintptr_t PhysicsAwakeObserver = 0xB0; // "PhysicsAwakeObserverModel"
            inline constexpr std::uintptr_t HitBoxAccess = 0xB8; // "IHitBoxAccessModel"
            inline constexpr std::uintptr_t HitBoxId = 0xC0; // "HitBoxIdModel"
            inline constexpr std::uintptr_t TeleportRequest = 0xC8; // "RequestModel<ValueTuple<Vector3, Quaternion, Vector3, Vector3>>"
            inline constexpr std::uintptr_t ControlOwner = 0xD0; // "HelicopterControlOwnerModel"
            inline constexpr std::uintptr_t CharacterOwner = 0xD8; // "VehicleOwnerModel"
            inline constexpr std::uintptr_t PartyOwner = 0xE0; // "PartyVehicleOwnerModel"
            inline constexpr std::uintptr_t OwnerRole = 0xE8; // "IPrimitiveModel<PlayerRoleDescription>"
            inline constexpr std::uintptr_t Exit = 0xF0; // "VehicleExitModel"
            inline constexpr std::uintptr_t TimelineData = 0xF8; // "ITimelineDataModel<HelicopterTimelineData>"
            inline constexpr std::uintptr_t Snapshots = 0x100; // "TimelineSnapshotsData<HelicopterTimelineData>"
            inline constexpr std::uintptr_t Extrapolation = 0x108; // "TimelineExtrapolationsData<HelicopterTimelineData>"
            inline constexpr std::uintptr_t SubStepSnapshots = 0x110; // "PhysicsEntitySubStepSnapshotsModel"
            inline constexpr std::uintptr_t Events = 0x118; // "EventsModel"
            inline constexpr std::uintptr_t WarpedEvent = 0x120; // "IEventModel"
            inline constexpr std::uintptr_t IsWarped = 0x128; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t IsUnowned = 0x130; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t Water = 0x138; // "VehicleWaterModel"
            inline constexpr std::uintptr_t HasFreeCargoSlot = 0x140; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t HasCargo = 0x148; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t TrunkPosition = 0x150; // "VehicleTrunkPositionModel"
            inline constexpr std::uintptr_t TrunkOpenedModel = 0x158; // "InteractableObjectOpenedModel"
            inline constexpr std::uintptr_t TickData = 0x160; // "HelicopterTickDataModel"
            inline constexpr std::uintptr_t RadioStation = 0x168; // "RadioStationModel"
            inline constexpr std::uintptr_t ClanBattleVehicleTeamOwnerModel = 0x170; // "ClanBattleVehicleTeamOwnerModel"
            inline constexpr std::uintptr_t DirtLevel = 0x178; // "VehicleDirtLevelModel"
            inline constexpr std::uintptr_t TrunkBreachModel = 0x180; // "BreachStateEntityModel"
            inline constexpr std::uintptr_t IsRented = 0x188; // "IPrimitiveModel<bool>"
        }
    } // namespace HelicopterModel

    namespace HelicopterOrientationViewUpdater { // "Game.Battle.EntityModel.Helicopter.Updaters.HelicopterOrientationViewUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t rotationModel = 0x10; // "IRotationModel"
            inline constexpr std::uintptr_t view = 0x18; // "HelicopterEntityView"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC8FB50; // "public void Update()"
        }
    } // namespace HelicopterOrientationViewUpdater

    namespace HelicopterPhysicsDescription { // "Models.References.Helicopter.HelicopterPhysicsDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Mass = 0x20; // "float"
            inline constexpr std::uintptr_t InvMass = 0x24; // "float"
            inline constexpr std::uintptr_t InertiaBoxShapeSize = 0x28; // "Vector3"
            inline constexpr std::uintptr_t LocalInvInertiaTensorCol0 = 0x34; // "Vector3"
            inline constexpr std::uintptr_t LocalInvInertiaTensorCol1 = 0x40; // "Vector3"
            inline constexpr std::uintptr_t LocalInvInertiaTensorCol2 = 0x4C; // "Vector3"
            inline constexpr std::uintptr_t CenterOfMassOffsetY = 0x58; // "float"
            inline constexpr std::uintptr_t Gravity = 0x5C; // "float"
            inline constexpr std::uintptr_t GravityForce = 0x60; // "Vector3"
            inline constexpr std::uintptr_t MaxLinearVelocity = 0x6C; // "float"
        }
    } // namespace HelicopterPhysicsDescription

    namespace HelicopterPositionViewUpdater { // "Game.Battle.EntityModel.Helicopter.Updaters.HelicopterPositionViewUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t positionModel = 0x10; // "IMovementModel"
            inline constexpr std::uintptr_t view = 0x18; // "HelicopterEntityView"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC8FC60; // "public void Update()"
        }
    } // namespace HelicopterPositionViewUpdater

    namespace HelicopterReplicationConfig { // "Models.References.Helicopter.Settings.HelicopterReplicationConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ThrustInputMaxAbsValue = 0x10; // "int"
            inline constexpr std::uintptr_t ThrustInputMinValue = 0x14; // "int"
            inline constexpr std::uintptr_t ThrustInputMaxValue = 0x18; // "int"
            inline constexpr std::uintptr_t TiltInputMaxAbsValue = 0x1C; // "int"
            inline constexpr std::uintptr_t TiltInputMinValue = 0x20; // "int"
            inline constexpr std::uintptr_t TiltInputMaxValue = 0x24; // "int"
            inline constexpr std::uintptr_t RotationInputMaxAbsValue = 0x28; // "int"
            inline constexpr std::uintptr_t RotationInputMinValue = 0x2C; // "int"
            inline constexpr std::uintptr_t RotationInputMaxValue = 0x30; // "int"
        }
    } // namespace HelicopterReplicationConfig

    namespace HelicopterRotationInputModel { // "Models.Models.HelicopterRotationInput.HelicopterRotationInputModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t dataToInputModifier = 0x18; // "float"
            inline constexpr std::uintptr_t inputToDataModifier = 0x1C; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Value = 0x4931230; // "public float get_Value()"
            inline constexpr std::uintptr_t set_Value = 0x4931290; // "public void set_Value(float value)"
        }
    } // namespace HelicopterRotationInputModel

    namespace HelicopterRotorClientModel { // "Game.Battle.EntityModel.Helicopter.Models.HelicopterRotorClientModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t RotationAccumulator = 0x10; // "float"
        }
    } // namespace HelicopterRotorClientModel

    namespace HelicopterRotorRotationUpdater { // "Game.Battle.EntityModel.Helicopter.Updaters.HelicopterRotorRotationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t rotorClientModel = 0x10; // "HelicopterRotorClientModel"
            inline constexpr std::uintptr_t engineClientModel = 0x18; // "HelicopterEngineClientModel"
            inline constexpr std::uintptr_t maxRotationSpeed = 0x20; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC8FCC0; // "public void Update()"
        }
    } // namespace HelicopterRotorRotationUpdater

    namespace HelicopterRotorRotationViewUpdater { // "Game.Battle.EntityModel.Helicopter.Updaters.HelicopterRotorRotationViewUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t rotorClientModel = 0x10; // "HelicopterRotorClientModel"
            inline constexpr std::uintptr_t view = 0x18; // "HelicopterRotorView"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC8FD90; // "public void Update()"
        }
    } // namespace HelicopterRotorRotationViewUpdater

    namespace HelicopterRotorsDescription { // "Models.References.Helicopter.HelicopterRotorsDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t MainRotorLocalPositionRelativeToPivot = 0x20; // "Vector3"
        }
    } // namespace HelicopterRotorsDescription

    namespace HelicopterRotorView { // "Game.Battle.Entities.Helicopter.Views.HelicopterRotorView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Transform = 0x20; // "Transform"
            inline constexpr std::uintptr_t RotationAxis = 0x28; // "Vector3"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetRotation = 0xB6A2B0; // "public void SetRotation(float angleDeg)"
        }
    } // namespace HelicopterRotorView

    namespace HelicopterSettingsOverrideData { // "Models.Data.SettingsOverride.Helicopters.HelicopterSettingsOverrideData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Handling = 0x20; // "HelicopterHandlingSettingsOverrideData"
            inline constexpr std::uintptr_t Suspension = 0x28; // "VehicleSuspensionSettingsOverrideData"
            inline constexpr std::uintptr_t Chassis = 0x30; // "HelicopterChassisSettingsOverrideData"
            inline constexpr std::uintptr_t Engine = 0x38; // "VehicleEngineSettingsOverrideData"
        }
    } // namespace HelicopterSettingsOverrideData

    namespace HelicopterSettingsOverrideModel { // "Models.Models.HelicopterSettingsOverride.HelicopterSettingsOverrideModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Handling = 0x10; // "HelicopterHandlingSettingsOverrideModel"
            inline constexpr std::uintptr_t Suspension = 0x18; // "VehicleSuspensionSettingsOverrideModel"
            inline constexpr std::uintptr_t Chassis = 0x20; // "HelicopterChassisSettingsOverrideModel"
            inline constexpr std::uintptr_t Engine = 0x28; // "VehicleEngineSettingsOverrideModel"
        }
    } // namespace HelicopterSettingsOverrideModel

    namespace HelicopterSkinViewDescription { // "Game.Global.SkinCenter.ViewDescriptions.HelicopterSkinViewDescription (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Identified = 0x10; // "IdentifiedProperty<HelicopterDescription>"
            inline constexpr std::uintptr_t decorativeVehicleView = 0x18; // "AssetReferenceT<GameObject>"
            inline constexpr std::uintptr_t icon = 0x20; // "AssetReferenceSprite"
            inline constexpr std::uintptr_t Rare = 0x28; // "RarityItem"
            inline constexpr std::uintptr_t HelicopterName = 0x30; // "LocalizedString"
            inline constexpr std::uintptr_t Name = 0x38; // "LocalizedString"
            inline constexpr std::uintptr_t Description = 0x40; // "LocalizedString"
            inline constexpr std::uintptr_t CameraType = 0x48; // "SkinCenterVehicleCameraType"
            inline constexpr std::uintptr_t KeysSprite = 0x50; // "Sprite"
            inline constexpr std::uintptr_t DecorativeVehicleView = 0x58; // "LoadedComponentContent<SkinCenterDecorativeHelicopterView>"
            inline constexpr std::uintptr_t Sprite = 0x60; // "NotInstantiateLoadedContent<Sprite>"
            inline constexpr std::uintptr_t Content = 0x68; // "ILoadedContent[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Id = 0x3675820; // "public string get_Id()"
            inline constexpr std::uintptr_t get_Empty = 0x7EC9F0; // "public bool get_Empty()"
            inline constexpr std::uintptr_t GetIconBySexData = 0x8E1B30; // "public LoadedContent<Sprite> GetIconBySexData(CharacterSexDescription sexData)"
            inline constexpr std::uintptr_t CanInteractWithSkin = 0x3675540; // "public bool CanInteractWithSkin()"
        }
    } // namespace HelicopterSkinViewDescription

    namespace HelicopterSkinViewDescriptions { // "Game.Global.SkinCenter.ViewDescriptions.HelicopterSkinViewDescriptions (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t DefaultHelicopterName = 0x28; // "LocalizedString"
        }
    } // namespace HelicopterSkinViewDescriptions

    namespace HelicopterSlotDescription { // "Models.References.Helicopter.HelicopterSlotDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t DefaultHelicopterFunc = 0x20; // "Func<HelicopterDescription>"
            inline constexpr std::uintptr_t InventoryItemFunc = 0x28; // "Func<InventoryItemDescription>"
            inline constexpr std::uintptr_t TrunkFunc = 0x30; // "Func<HelicopterTrunkDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_DefaultHelicopter = 0x9D6230; // "public HelicopterDescription get_DefaultHelicopter()"
            inline constexpr std::uintptr_t get_InventoryItem = 0x993E50; // "public InventoryItemDescription get_InventoryItem()"
            inline constexpr std::uintptr_t get_Trunk = 0x9AA5D0; // "public HelicopterTrunkDescription get_Trunk()"
            inline constexpr std::uintptr_t get_HasTrunk = 0x40A2280; // "public bool get_HasTrunk()"
        }
    } // namespace HelicopterSlotDescription

    namespace HelicopterStateTickDataModel { // "Models.Models.TickDataModels.Helicopter.HelicopterStateTickDataModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t HandlingState = 0x10; // "HelicopterHandlingState"
        }
    } // namespace HelicopterStateTickDataModel

    namespace HelicopterStatsUpdater { // "Game.Battle.EntityModel.Helicopter.Stats.Updaters.HelicopterStatsUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t view = 0x10; // "HelicopterStatsDebugView"
            inline constexpr std::uintptr_t model = 0x18; // "HelicopterStatsDebugModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x20; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t isInsideHelicopter = 0x28; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC8FE20; // "public void Update()"
        }
    } // namespace HelicopterStatsUpdater

    namespace HelicopterTargetActions { // "Game.Battle.EntityModel.Helicopter.HelicopterTargetActions (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleInputModel = 0x10; // "BattleInputModel"
            inline constexpr std::uintptr_t entityId = 0x18; // "int"
            inline constexpr std::uintptr_t inventoryDialogModel = 0x20; // "InventoryDialogModel"
            inline constexpr std::uintptr_t personalNotificationModel = 0x28; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t soundEmitter = 0x30; // "GameObject"
            inline constexpr std::uintptr_t attemptToOpenClosedDoor = 0x38; // "Event"
            inline constexpr std::uintptr_t cooldownTs = 0x40; // "float"
            inline constexpr std::uintptr_t Enter = 0x48; // "TargetAction"
            inline constexpr std::uintptr_t EnterHelicopterUnavailable = 0x50; // "ITargetAction"
            inline constexpr std::uintptr_t UnavailableInteraction = 0x58; // "UnavailableTargetAction"
        }
        namespace Methods {
            inline constexpr std::uintptr_t EnterHelicopter = 0xC90020; // "private void EnterHelicopter()"
            inline constexpr std::uintptr_t Unavailable = 0xC90100; // "private void Unavailable(LocalizedString invalidNotification, PersonalNotificationActionIds id)"
        }
    } // namespace HelicopterTargetActions

    namespace HelicopterThrustInputClientModel { // "Game.Battle.EntityModel.Helicopter.Models.HelicopterThrustInputClientModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Value = 0x10; // "float"
        }
    } // namespace HelicopterThrustInputClientModel

    namespace HelicopterThrustInputModel { // "Models.Models.HelicopterThrustInput.HelicopterThrustInputModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t dataToInputModifier = 0x18; // "float"
            inline constexpr std::uintptr_t inputToDataModifier = 0x1C; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Value = 0x49314E0; // "public float get_Value()"
            inline constexpr std::uintptr_t set_Value = 0x4931540; // "public void set_Value(float value)"
        }
    } // namespace HelicopterThrustInputModel

    namespace HelicopterTickDataModel { // "Models.Models.TickDataModels.Helicopter.HelicopterTickDataModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t TransformTickData = 0x10; // "VehicleTransformTickDataModel"
            inline constexpr std::uintptr_t LinksTickData = 0x18; // "VehicleLinksTickDataModel"
            inline constexpr std::uintptr_t EngineTickData = 0x20; // "VehicleEngineTickDataModel"
            inline constexpr std::uintptr_t StateTickData = 0x28; // "HelicopterStateTickDataModel"
            inline constexpr std::uintptr_t SleepTickData = 0x30; // "VehicleSleepTickDataModel"
            inline constexpr std::uintptr_t WaterTickData = 0x38; // "VehicleWaterTickDataModel"
        }
    } // namespace HelicopterTickDataModel

    namespace HelicopterTiltInputModel { // "Models.Models.HelicopterTiltInput.HelicopterTiltInputModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t tiltAroundX = 0x10; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t tiltAroundZ = 0x18; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t dataToInputModifier = 0x20; // "float"
            inline constexpr std::uintptr_t inputToDataModifier = 0x24; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_TiltAroundX = 0x4931650; // "public float get_TiltAroundX()"
            inline constexpr std::uintptr_t set_TiltAroundX = 0x4931710; // "public void set_TiltAroundX(float value)"
            inline constexpr std::uintptr_t get_TiltAroundZ = 0x49316B0; // "public float get_TiltAroundZ()"
            inline constexpr std::uintptr_t set_TiltAroundZ = 0x4931760; // "public void set_TiltAroundZ(float value)"
        }
    } // namespace HelicopterTiltInputModel

    namespace HelicopterTimelineData { // "Models.Timeline.Data.Entity.HelicopterTimelineData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t BodyTouchAnyBeforeSubTick = 0x0; // "bool"
            inline constexpr std::uintptr_t CenterOfMassPosition = 0x4; // "Vector3"
            inline constexpr std::uintptr_t CenterOfMassOrientation = 0x10; // "Quaternion"
            inline constexpr std::uintptr_t LinearVelocity = 0x20; // "Vector3"
            inline constexpr std::uintptr_t AngularVelocity = 0x2C; // "Vector3"
            inline constexpr std::uintptr_t FLSpringLength = 0x38; // "float"
            inline constexpr std::uintptr_t FRSpringLength = 0x3C; // "float"
            inline constexpr std::uintptr_t BLSpringLength = 0x40; // "float"
            inline constexpr std::uintptr_t BRSpringLength = 0x44; // "float"
            inline constexpr std::uintptr_t EngineActive = 0x48; // "bool"
            inline constexpr std::uintptr_t EngineStateChangeOverTs = 0x50; // "long"
            inline constexpr std::uintptr_t ThrustInput = 0x58; // "float"
            inline constexpr std::uintptr_t WaterState = 0x60; // "VehicleWaterStateDescription"
            inline constexpr std::uintptr_t SleepCounter = 0x68; // "int"
        }
    } // namespace HelicopterTimelineData

    namespace HelicopterTimelineDataExtensions { // "Models.Utils.Timeline.Data.HelicopterTimelineDataExtensions (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x81DDAC8; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t InterpolationFunc = 0x0; // "TimelineDelegates.Interpolation<HelicopterTimelineData>"
            inline constexpr std::uintptr_t ErrorCorrectionInterpolationFunc = 0x8; // "TimelineDelegates.ErrorCorrectionInterpolation<HelicopterTimelineData>"
            inline constexpr std::uintptr_t CastToPhysicsBodyDataFunc = 0x10; // "TimelineDelegates.CastToPhysicsBodyData<HelicopterTimelineData>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Interpolation = 0x394CA80; // "private static void Interpolation(in HelicopterTimelineData from, in HelicopterTimelineData to, float t, out HelicopterTimelineData result)"
            inline constexpr std::uintptr_t ErrorCorrectionInterpolation = 0x394C840; // "private static void ErrorCorrectionInterpolation(in HelicopterTimelineData errorData, in HelicopterTimelineData correctData, float t, out HelicopterTimelineData result)"
            inline constexpr std::uintptr_t CastToPhysicsBodyData = 0x3936050; // "private static PhysicsBodyTimelineData CastToPhysicsBodyData(in HelicopterTimelineData data)"
        }
    } // namespace HelicopterTimelineDataExtensions

    namespace HelicopterTimelineDataModel { // "Models.Models.TimelineDataModel.HelicopterTimelineDataModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t transform = 0x10; // "VehicleTransformModel"
            inline constexpr std::uintptr_t linearVelocity = 0x18; // "VelocityModel"
            inline constexpr std::uintptr_t angularVelocity = 0x20; // "VelocityModel"
            inline constexpr std::uintptr_t engine = 0x28; // "VehicleEngineModel"
            inline constexpr std::uintptr_t thrustInput = 0x30; // "HelicopterThrustInputModel"
            inline constexpr std::uintptr_t wheels = 0x38; // "HelicopterWheelsModel"
            inline constexpr std::uintptr_t sleep = 0x40; // "VehicleSleepModel"
            inline constexpr std::uintptr_t water = 0x48; // "VehicleWaterModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Build = 0x48B77F0; // "public HelicopterTimelineData Build()"
        }
    } // namespace HelicopterTimelineDataModel

    namespace HelicopterTooltipContext { // "Game.Battle.HelicopterTooltipContext (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Description = 0x10; // "HelicopterDescription"
            inline constexpr std::uintptr_t Options = 0x18; // "VehicleTooltipOptions"
        }
    } // namespace HelicopterTooltipContext

    namespace HelicopterTooltipContextAdapter { // "Game.Battle.UiUpdater.HelicopterTooltipContextAdapter (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t description = 0x10; // "HelicopterDescription"
            inline constexpr std::uintptr_t globalScreenContent = 0x18; // "GlobalScreenContent"
            inline constexpr std::uintptr_t helicopterViewDescriptions = 0x20; // "HelicopterViewDescriptions"
            inline constexpr std::uintptr_t helicopterSkinViewDescriptions = 0x28; // "HelicopterSkinViewDescriptions"
            inline constexpr std::uintptr_t Cost = 0x30; // "Money"
            inline constexpr std::uintptr_t CumulativeProgress = 0x50; // "ValueTuple<int, int>"
            inline constexpr std::uintptr_t VehicleStats = 0x58; // "TooltipContextVehicle"
            inline constexpr std::uintptr_t UpgradeStats = 0x78; // "VehicleCharacteristicTooltipData"
            inline constexpr std::uintptr_t ItemStatsStrings = 0x80; // "IReadOnlyList<ValueTuple<string, string, bool>>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Name = 0xAC2D20; // "public LocalizedString get_Name()"
            inline constexpr std::uintptr_t get_Rarity = 0xAC2D80; // "public RarityItem get_Rarity()"
            inline constexpr std::uintptr_t get_Description = 0xAC2CC0; // "public LocalizedString get_Description()"
            inline constexpr std::uintptr_t get_Type = 0xAC2DE0; // "public string get_Type()"
            inline constexpr std::uintptr_t get_IsDurabilityStatActive = 0x7EC9F0; // "public bool get_IsDurabilityStatActive()"
            inline constexpr std::uintptr_t get_IsCumulativeProgressActive = 0x7EC9F0; // "public bool get_IsCumulativeProgressActive()"
            inline constexpr std::uintptr_t get_IsVehicleActive = 0x7D5050; // "public bool get_IsVehicleActive()"
            inline constexpr std::uintptr_t get_IsVehicleUpgrade = 0x7EC9F0; // "public bool get_IsVehicleUpgrade()"
            inline constexpr std::uintptr_t get_IsFurnitureActive = 0x7EC9F0; // "public bool get_IsFurnitureActive()"
            inline constexpr std::uintptr_t get_IsCostActive = 0x7EC9F0; // "public bool get_IsCostActive()"
            inline constexpr std::uintptr_t get_CostText = 0x7E3AB0; // "public LocalizedString get_CostText()"
            inline constexpr std::uintptr_t get_Durability = 0x7E3AB0; // "public string get_Durability()"
            inline constexpr std::uintptr_t get_IsArmorStatActive = 0x7EC9F0; // "public bool get_IsArmorStatActive()"
            inline constexpr std::uintptr_t get_ArmorStatText = 0x7E3AB0; // "public string get_ArmorStatText()"
            inline constexpr std::uintptr_t get_ArmorBar = 0xABFFA0; // "public float get_ArmorBar()"
            inline constexpr std::uintptr_t get_ArmorSegmentCount = 0x7E3AB0; // "public int get_ArmorSegmentCount()"
            inline constexpr std::uintptr_t GetCarUpgradesHolderTypeDescription = 0x7E3AB0; // "public CarUpgradesHolderTypeDescription GetCarUpgradesHolderTypeDescription()"
            inline constexpr std::uintptr_t get_FurnitureStats = 0x7E3AB0; // "public FurnitureTooltipData get_FurnitureStats()"
            inline constexpr std::uintptr_t TryGetCarUpgradeStatsModel = 0xABFE30; // "public bool TryGetCarUpgradeStatsModel(out CarUpgradeViewStatsModel model)"
            inline constexpr std::uintptr_t TryGetRequiredAuthorityLevel = 0xABFE50; // "public bool TryGetRequiredAuthorityLevel(out int level)"
            inline constexpr std::uintptr_t get_WeaponDamageDescription = 0x7E3AB0; // "public IWeaponDamage get_WeaponDamageDescription()"
            inline constexpr std::uintptr_t get_IsShowSplitHint = 0x7EC9F0; // "public bool get_IsShowSplitHint()"
            inline constexpr std::uintptr_t get_IsShowBackHint = 0x7EC9F0; // "public bool get_IsShowBackHint()"
            inline constexpr std::uintptr_t TryGetWarnings = 0xABFE60; // "public bool TryGetWarnings(out IText warning1, out IText warning2)"
            inline constexpr std::uintptr_t Set = 0xAC2AC0; // "public void Set(HelicopterDescription description, VehicleTooltipOptions options)"
        }
    } // namespace HelicopterTooltipContextAdapter

    namespace HelicopterTrunkEntityStreamReader { // "Models.Replication.EntityStreamReader.HelicopterTrunkEntityStreamReader (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t paramsModel = 0x20; // "EntitiesParamsModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t TryReadParams = 0x44B8610; // "protected override bool TryReadParams(int entityId, IBinaryReadStream stream)"
        }
    } // namespace HelicopterTrunkEntityStreamReader

    namespace HelicopterTrunkTargetActions { // "Game.Battle.EntityModel.Helicopter.HelicopterTrunkTargetActions (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t personalNotificationModel = 0x10; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t uiSoundModel = 0x18; // "GlobalUISoundModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x20; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t observerRequestModel = 0x28; // "ObserverRequestModel"
            inline constexpr std::uintptr_t helicopterModel = 0x30; // "HelicopterModel"
            inline constexpr std::uintptr_t dropSound = 0x38; // "Event"
            inline constexpr std::uintptr_t battleInputModel = 0x40; // "BattleInputModel"
            inline constexpr std::uintptr_t trunkSoundEmitter = 0x48; // "GameObject"
            inline constexpr std::uintptr_t carTrunkDistanceOpenModel = 0x50; // "CarTrunkDistanceOpenModel"
            inline constexpr std::uintptr_t partyModel = 0x58; // "PartyModel"
            inline constexpr std::uintptr_t becomeRobberNotificationModel = 0x60; // "BecomeRobberNotificationModel"
            inline constexpr std::uintptr_t unavailableKeys = 0x68; // "UnavailableTargetActionsKeys"
            inline constexpr std::uintptr_t characterSlotsModel = 0x70; // "ICharacterSlotsModel"
            inline constexpr std::uintptr_t clanBattleCharacterTeamModel = 0x78; // "IClanBattleCharacterTeamModel"
            inline constexpr std::uintptr_t Interact = 0x80; // "ITargetAction"
            inline constexpr std::uintptr_t Open = 0x88; // "TargetAction"
            inline constexpr std::uintptr_t PutCargo = 0x90; // "TargetAction"
            inline constexpr std::uintptr_t Refill = 0x98; // "TargetAction"
            inline constexpr std::uintptr_t UnavailableInteraction = 0xA0; // "UnavailableTargetAction"
        }
        namespace Methods {
            inline constexpr std::uintptr_t RefillAmmoWithCopCarTrunk = 0xC908C0; // "private void RefillAmmoWithCopCarTrunk()"
            inline constexpr std::uintptr_t CanTakeCargo = 0xC905F0; // "private bool CanTakeCargo()"
            inline constexpr std::uintptr_t CanOpenTrunk = 0xC90590; // "private bool CanOpenTrunk()"
            inline constexpr std::uintptr_t UnavailableOpenTrunk = 0xC90B50; // "private void UnavailableOpenTrunk()"
            inline constexpr std::uintptr_t UnavailableTakeCargoTrunk = 0xC90BD0; // "private void UnavailableTakeCargoTrunk()"
            inline constexpr std::uintptr_t OpenTrunk = 0xC90780; // "private void OpenTrunk()"
            inline constexpr std::uintptr_t Unavailable = 0xA74590; // "private void Unavailable(LocalizedString invalidNotification, PersonalNotificationActionIds id)"
            inline constexpr std::uintptr_t PutCargoInTrunk = 0xC907D0; // "private void PutCargoInTrunk()"
            inline constexpr std::uintptr_t TakeCargo = 0xC909F0; // "private void TakeCargo()"
            inline constexpr std::uintptr_t HasAccessToTrunk = 0xC906F0; // "public bool HasAccessToTrunk()"
        }
    } // namespace HelicopterTrunkTargetActions

    namespace HelicopterTrunkTargetProvider { // "Game.Battle.Entities.Helicopter.Updaters.HelicopterTrunkTargetProvider (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t targetActions = 0x20; // "HelicopterTrunkTargetActions"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x28; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t helicopterModel = 0x30; // "HelicopterModel"
            inline constexpr std::uintptr_t unavailableKeys = 0x38; // "UnavailableTargetActionsKeys"
        }
        namespace Methods {
            inline constexpr std::uintptr_t GetTargetAction = 0xB6A900; // "protected override ITargetAction GetTargetAction()"
        }
    } // namespace HelicopterTrunkTargetProvider

    namespace HelicopterTrunkUpdater { // "Game.Battle.Entities.Helicopter.Updaters.HelicopterTrunkUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t updaters = 0x10; // "IUpdater"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB6AE80; // "public void Update()"
        }
    } // namespace HelicopterTrunkUpdater

    namespace HelicopterViewDescription { // "Game.Battle.EntityModel.Helicopter.HelicopterViewDescription (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Identified = 0x10; // "IdentifiedProperty<HelicopterDescription>"
            inline constexpr std::uintptr_t prefab = 0x18; // "AssetReference"
            inline constexpr std::uintptr_t HelicopterType = 0x20; // "Switch"
            inline constexpr std::uintptr_t EntityView = 0x28; // "LoadedComponentContent<HelicopterEntityView>"
            inline constexpr std::uintptr_t EngineSpeedCurve = 0x30; // "AnimationCurve"
            inline constexpr std::uintptr_t MainRotorMaxRotationSpeed = 0x38; // "float"
            inline constexpr std::uintptr_t SecondaryRotorMaxRotationSpeed = 0x3C; // "float"
            inline constexpr std::uintptr_t CharacteristicSpeed = 0x40; // "float"
            inline constexpr std::uintptr_t CharacteristicHandling = 0x44; // "float"
            inline constexpr std::uintptr_t noDoorsSeats = 0x48; // "IdentifiedProperty<VehicleSeatSlotDescription>[]"
            inline constexpr std::uintptr_t noDoorsSeatsIds = 0x50; // "HashSet<string>"
            inline constexpr std::uintptr_t SuspensionLimitCollisionThreshold = 0x58; // "float"
            inline constexpr std::uintptr_t Sprite = 0x60; // "Sprite"
            inline constexpr std::uintptr_t Content = 0x68; // "ILoadedContent[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Id = 0xC91A10; // "public string get_Id()"
            inline constexpr std::uintptr_t NeedCharacterDoorAnim = 0xC91720; // "public bool NeedCharacterDoorAnim(VehicleSeatSlotDescription seat)"
        }
    } // namespace HelicopterViewDescription

    namespace HelicopterViewDescriptions { // "Game.Battle.EntityModel.Helicopter.HelicopterViewDescriptions (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t UpLookPitchThreshold = 0x28; // "float"
            inline constexpr std::uintptr_t DownLookPitchThreshold = 0x2C; // "float"
            inline constexpr std::uintptr_t LookRollThreshold = 0x30; // "float"
            inline constexpr std::uintptr_t Speed = 0x38; // "RTPC"
            inline constexpr std::uintptr_t Power = 0x40; // "RTPC"
            inline constexpr std::uintptr_t HelicopterEngineEvent = 0x48; // "Event"
            inline constexpr std::uintptr_t DopplerRtpc = 0x50; // "RTPC"
            inline constexpr std::uintptr_t MinZoom = 0x58; // "float"
            inline constexpr std::uintptr_t MaxZoom = 0x5C; // "float"
            inline constexpr std::uintptr_t HelicopterStartEngineEvent = 0x60; // "Event"
            inline constexpr std::uintptr_t SpawnEvent = 0x68; // "Event"
            inline constexpr std::uintptr_t DoorSound = 0x70; // "Event"
            inline constexpr std::uintptr_t DropCargoSound = 0x78; // "Event"
            inline constexpr std::uintptr_t TrunkOpenedSound = 0x80; // "Event"
            inline constexpr std::uintptr_t VehicleSuspension = 0x88; // "Event"
            inline constexpr std::uintptr_t AttemptToOpenClosedDoor = 0x90; // "Event"
            inline constexpr std::uintptr_t TrunkOpenedSwitch = 0x98; // "Switch"
            inline constexpr std::uintptr_t TrunkClosedSwitch = 0xA0; // "Switch"
            inline constexpr std::uintptr_t MouseYawClamp = 0xA8; // "float"
            inline constexpr std::uintptr_t MouseYawPow = 0xAC; // "float"
            inline constexpr std::uintptr_t BladeVfxMaxHeight = 0xB0; // "float"
            inline constexpr std::uintptr_t BladeVfxLerpWeight = 0xB4; // "float"
            inline constexpr std::uintptr_t AlphaByHelicopterHeight = 0xB8; // "AnimationCurve"
            inline constexpr std::uintptr_t AlphaByBladeSpeed = 0xC0; // "AnimationCurve"
            inline constexpr std::uintptr_t vehicleParking = 0xC8; // "AssetReference"
            inline constexpr std::uintptr_t GarageParking = 0xD0; // "PooledLoadedComponentContent<GarageVehicleParkingView>"
            inline constexpr std::uintptr_t GarageParkingVisibleDistance = 0xD8; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t AfterDeserialize = 0xC91A50; // "protected override void AfterDeserialize()"
        }
    } // namespace HelicopterViewDescriptions

    namespace HelicopterWheelData { // "Models.Data.Helicopter.HelicopterWheelData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t SpringLength = 0x20; // "IPrimitiveData<int>"
        }
    } // namespace HelicopterWheelData

    namespace HelicopterWheelFrictionTickDataModel { // "Models.Models.TickDataModels.Helicopter.Wheel.HelicopterWheelFrictionTickDataModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t FrictionLinearForceX = 0x10; // "float"
            inline constexpr std::uintptr_t FrictionLinearForceY = 0x14; // "float"
            inline constexpr std::uintptr_t FrictionLinearForceZ = 0x18; // "float"
            inline constexpr std::uintptr_t FrictionAngularForceX = 0x1C; // "float"
            inline constexpr std::uintptr_t FrictionAngularForceY = 0x20; // "float"
            inline constexpr std::uintptr_t FrictionAngularForceZ = 0x24; // "float"
        }
    } // namespace HelicopterWheelFrictionTickDataModel

    namespace HelicopterWheelModel { // "Models.Models.HelicopterWheel.HelicopterWheelModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t description = 0x10; // "VehicleWheelDescription"
            inline constexpr std::uintptr_t SpringLength = 0x18; // "VehicleWheelSpringModel"
            inline constexpr std::uintptr_t TickData = 0x20; // "HelicopterWheelTickDataModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsForward = 0x3544390; // "public bool get_IsForward()"
            inline constexpr std::uintptr_t get_IsLeft = 0x3544370; // "public bool get_IsLeft()"
            inline constexpr std::uintptr_t get_LinkLocalOffsetFromCenterOfMass = 0x4931890; // "public Vector3 get_LinkLocalOffsetFromCenterOfMass()"
        }
    } // namespace HelicopterWheelModel

    namespace HelicopterWheelsBaseDescription { // "Models.References.Helicopter.HelicopterWheelsBaseDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t OffsetFromPivotY = 0x20; // "float"
            inline constexpr std::uintptr_t OffsetFromPivotZ = 0x24; // "float"
            inline constexpr std::uintptr_t Width = 0x28; // "float"
            inline constexpr std::uintptr_t Length = 0x2C; // "float"
        }
    } // namespace HelicopterWheelsBaseDescription

    namespace HelicopterWheelsModel { // "Models.Models.HelicopterWheels.HelicopterWheelsModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t wheels = 0x10; // "List<HelicopterWheelModel>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Count = 0x4931D50; // "public int get_Count()"
            inline constexpr std::uintptr_t get_Item = 0x4931E30; // "public HelicopterWheelModel get_Item(int index)"
            inline constexpr std::uintptr_t get_FlWheel = 0x4931D90; // "public HelicopterWheelModel get_FlWheel()"
            inline constexpr std::uintptr_t get_FrWheel = 0x4931DE0; // "public HelicopterWheelModel get_FrWheel()"
            inline constexpr std::uintptr_t get_BlWheel = 0x4931CB0; // "public HelicopterWheelModel get_BlWheel()"
            inline constexpr std::uintptr_t get_BrWheel = 0x4931D00; // "public HelicopterWheelModel get_BrWheel()"
            inline constexpr std::uintptr_t GetEnumerator = 0x49318C0; // "public IEnumerator<HelicopterWheelModel> GetEnumerator()"
            inline constexpr std::uintptr_t System_Collections_IEnumerable_GetEnumerator = 0x49318C0; // "private IEnumerator System.Collections.IEnumerable.GetEnumerator()"
        }
    } // namespace HelicopterWheelsModel

    namespace HelicopterWheelsSuspensionLengthUpdater { // "Game.Battle.Entities.Helicopter.Updaters.HelicopterWheelsSuspensionLengthUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t clientModel = 0x10; // "HelicopterClientModel"
            inline constexpr std::uintptr_t wheelsModel = 0x18; // "HelicopterWheelsModel"
            inline constexpr std::uintptr_t snapshotsModel = 0x20; // "TimelineSnapshotsData<HelicopterTimelineData>"
            inline constexpr std::uintptr_t extrapolationModel = 0x28; // "TimelineExtrapolationsData<HelicopterTimelineData>"
            inline constexpr std::uintptr_t timeOffset = 0x30; // "TimelineTimeOffsetModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB6BB80; // "public void Update()"
        }
    } // namespace HelicopterWheelsSuspensionLengthUpdater

    namespace HelicopterWheelTickDataModel { // "Models.Models.TickDataModels.Helicopter.Wheel.HelicopterWheelTickDataModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t WheelGroundTickData = 0x10; // "VehicleWheelGroundTickDataModel"
            inline constexpr std::uintptr_t WheelLinkTickData = 0x18; // "VehicleWheelLinkTickDataModel"
            inline constexpr std::uintptr_t WheelSuspensionTickData = 0x20; // "VehicleWheelSuspensionTickDataModel"
            inline constexpr std::uintptr_t WheelSuspensionLimitTickData = 0x28; // "VehicleWheelSuspensionLimitTickDataModel"
            inline constexpr std::uintptr_t WheelLoadTickData = 0x30; // "VehicleWheelLoadTickDataModel"
            inline constexpr std::uintptr_t WheelFrictionTickData = 0x38; // "HelicopterWheelFrictionTickDataModel"
        }
    } // namespace HelicopterWheelTickDataModel

    namespace HelicopterYawThrustCoDInputUpdater { // "Game.Battle.Inputs.CompositeUpdaters.HelicopterYawThrustCoDInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleInputModel = 0x10; // "BattleInputModel"
            inline constexpr std::uintptr_t inputSetting = 0x18; // "IChangeBufferValue<HelicopterInputSetting>"
            inline constexpr std::uintptr_t thrust = 0x20; // "InputAction"
            inline constexpr std::uintptr_t yaw = 0x28; // "InputAction"
            inline constexpr std::uintptr_t playerRotationInput = 0x30; // "PlayerRotationInputModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x38; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t helicopterViewDescriptions = 0x40; // "HelicopterViewDescriptions"
            inline constexpr std::uintptr_t helicopterMouseControl = 0x48; // "InputAction"
            inline constexpr std::uintptr_t battleTimeModel = 0x50; // "TimeModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA90B30; // "public void Update()"
        }
    } // namespace HelicopterYawThrustCoDInputUpdater

    namespace HelicopterYawThrustGTAInputUpdater { // "Game.Battle.Inputs.CompositeUpdaters.HelicopterYawThrustGTAInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleInputModel = 0x10; // "BattleInputModel"
            inline constexpr std::uintptr_t inputSetting = 0x18; // "IChangeBufferValue<HelicopterInputSetting>"
            inline constexpr std::uintptr_t thrust = 0x20; // "InputAction"
            inline constexpr std::uintptr_t yaw = 0x28; // "InputAction"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA90FE0; // "public void Update()"
        }
    } // namespace HelicopterYawThrustGTAInputUpdater

    namespace HornCarUpgradeReadAdapter { // "Models.Utils.Adapters.CarUpgradeAdapter.HornCarUpgradeReadAdapter (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t TryFromItem = 0x3C83970; // "public bool TryFromItem(InventoryItemDescription item, out HornCarUpgradeDescription value)"
            inline constexpr std::uintptr_t TryGetUpgradeSlot = 0x3C839B0; // "public bool TryGetUpgradeSlot(CarUpgradesSlotsModel carUpgradesSlotsModel, int slotIndex, CarDescription carDescription, out IPrimitiveModel<HornCarUpgradeDescription> slotModel)"
            inline constexpr std::uintptr_t CheckUnsetUpgrade = 0x7D5050; // "public bool CheckUnsetUpgrade(int entityId, IPrimitiveModel<HornCarUpgradeDescription> slotModel)"
            inline constexpr std::uintptr_t CheckSwap = 0x7D5050; // "public bool CheckSwap(int entityId, IPrimitiveModel<HornCarUpgradeDescription> slotModel, HornCarUpgradeDescription upgradeDescription)"
        }
    } // namespace HornCarUpgradeReadAdapter

    namespace InVehicleCharacterVisibleUpdater { // "Game.Battle.EntityModel.Player.InVehicleCharacterVisibleUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t cameraModel = 0x10; // "BattleCameraModel"
            inline constexpr std::uintptr_t charactersInVehiclesModel = 0x18; // "CharacterInVehiclesModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x20; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t characterInVehicleVisibleDistanceSqr = 0x28; // "float"
            inline constexpr std::uintptr_t characterInVehicleUnVisibleDistanceSqr = 0x2C; // "float"
            inline constexpr std::uintptr_t resultsBuffer = 0x30; // "RaycastHit[]"
            inline constexpr std::uintptr_t layerMask = 0x38; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC39A80; // "public void Update()"
            inline constexpr std::uintptr_t IsVehicleCharacterVisible = 0xC396F0; // "private bool IsVehicleCharacterVisible(int vehicleId, int characterId, Vector3 playerPosition)"
            inline constexpr std::uintptr_t IsRaycastVehicleCharacter = 0xC39500; // "private bool IsRaycastVehicleCharacter(Vector3 from, Vector3 to, Vector3 playerPosition)"
            inline constexpr std::uintptr_t GetPlayerPos = 0xC39210; // "private Vector3 GetPlayerPos()"
        }
    } // namespace InVehicleCharacterVisibleUpdater

    namespace InVehicleModel { // "Models.Models.InVehicle.InVehicleModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t entityId = 0x10; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t seatSlot = 0x18; // "IPrimitiveData<VehicleSeatSlotDescription>"
            inline constexpr std::uintptr_t vehicleType = 0x20; // "IPrimitiveData<VehicleTypeDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_EntityId = 0x4932D50; // "public int get_EntityId()"
            inline constexpr std::uintptr_t get_SeatSlot = 0x4932DF0; // "public VehicleSeatSlotDescription get_SeatSlot()"
            inline constexpr std::uintptr_t Set = 0x4932C80; // "public void Set(int entityId, VehicleSeatSlotDescription seatSlot, VehicleTypeDescription vehicleType)"
            inline constexpr std::uintptr_t Clear = 0x4932BD0; // "public void Clear()"
            inline constexpr std::uintptr_t ChangeSeat = 0x4932B70; // "public void ChangeSeat(VehicleSeatSlotDescription newSeatSlot)"
            inline constexpr std::uintptr_t get_IsInsideVehicle = 0x4932DA0; // "public bool get_IsInsideVehicle()"
        }
    } // namespace InVehicleModel

    namespace IsPlayerInVehicleLODRule { // "Game.Battle.IsPlayerInVehicleLODRule (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t carModel = 0x10; // "CarClientModel"
            inline constexpr std::uintptr_t isInVehicle = 0x18; // "bool"
            inline constexpr std::uintptr_t distanceLODRule = 0x20; // "DistanceLODRule"
        }
        namespace Methods {
            inline constexpr std::uintptr_t CanUpdate = 0xA56DE0; // "public override bool CanUpdate()"
        }
    } // namespace IsPlayerInVehicleLODRule

    namespace KeyboardCarLookInputUpdater { // "Game.Battle.Inputs.Updaters.Keyboard.KeyboardCarLookInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t playerRotationInput = 0x10; // "PlayerRotationInputModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x18; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t sensitivityModel = 0x20; // "SensitivityModel"
            inline constexpr std::uintptr_t actions = 0x28; // "InputActions.BattleActions"
            inline constexpr std::uintptr_t topThreshold = 0x30; // "float"
            inline constexpr std::uintptr_t bottomThreshold = 0x34; // "float"
            inline constexpr std::uintptr_t cameraFollow = 0x38; // "Cinemachine3rdPersonFollow"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA93DB0; // "public void Update()"
        }
    } // namespace KeyboardCarLookInputUpdater

    namespace KeyboardHelicopterLookCoDInputUpdater { // "Game.Battle.Inputs.Updaters.Keyboard.KeyboardHelicopterLookCoDInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t playerRotationInput = 0x10; // "PlayerRotationInputModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x18; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t sensitivityModel = 0x20; // "SensitivityModel"
            inline constexpr std::uintptr_t lookAction = 0x28; // "InputAction"
            inline constexpr std::uintptr_t helicopterRmbCoDAction = 0x30; // "InputAction"
            inline constexpr std::uintptr_t helicopterInput = 0x38; // "IChangeBufferValue<HelicopterInputSetting>"
            inline constexpr std::uintptr_t topThreshold = 0x40; // "float"
            inline constexpr std::uintptr_t bottomThreshold = 0x44; // "float"
            inline constexpr std::uintptr_t direction = 0x48; // "Vector2"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA94280; // "public void Update()"
            inline constexpr std::uintptr_t IsDriver = 0xA94190; // "private bool IsDriver(PlayerEntityModel player)"
        }
    } // namespace KeyboardHelicopterLookCoDInputUpdater

    namespace KeyboardHelicopterLookGTAInputUpdater { // "Game.Battle.Inputs.Updaters.Keyboard.KeyboardHelicopterLookGTAInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t playerRotationInput = 0x10; // "PlayerRotationInputModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x18; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t sensitivityModel = 0x20; // "SensitivityModel"
            inline constexpr std::uintptr_t lookAction = 0x28; // "InputAction"
            inline constexpr std::uintptr_t helicopterRMBGRAAction = 0x30; // "InputAction"
            inline constexpr std::uintptr_t helicopterInput = 0x38; // "IChangeBufferValue<HelicopterInputSetting>"
            inline constexpr std::uintptr_t topThreshold = 0x40; // "float"
            inline constexpr std::uintptr_t bottomThreshold = 0x44; // "float"
            inline constexpr std::uintptr_t rollThreshold = 0x48; // "float"
            inline constexpr std::uintptr_t timeLeft = 0x4C; // "float"
            inline constexpr std::uintptr_t offset = 0x50; // "Vector2"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA94930; // "public void Update()"
            inline constexpr std::uintptr_t HandleDefaultLook = 0xA94870; // "private void HandleDefaultLook(Vector2 lookInput, float roll)"
        }
    } // namespace KeyboardHelicopterLookGTAInputUpdater

    namespace KeyboardHelicopterMouseTiltGTAInputUpdater { // "Game.Battle.Inputs.Updaters.Keyboard.KeyboardHelicopterMouseTiltGTAInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t actions = 0x10; // "InputActions.CharacterControlActions"
            inline constexpr std::uintptr_t battleInputModel = 0x18; // "BattleInputModel"
            inline constexpr std::uintptr_t inputSetting = 0x20; // "IChangeBufferValue<HelicopterInputSetting>"
            inline constexpr std::uintptr_t offset = 0x28; // "Vector2"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA95050; // "public void Update()"
            inline constexpr std::uintptr_t ResolveMouseDrag = 0xA94E70; // "private Vector2 ResolveMouseDrag()"
        }
    } // namespace KeyboardHelicopterMouseTiltGTAInputUpdater

    namespace KeyboardTiltHelicopterInputUpdater { // "Game.Battle.Inputs.Updaters.Keyboard.KeyboardTiltHelicopterInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t pitchRoll = 0x10; // "InputAction"
            inline constexpr std::uintptr_t inputSetting = 0x18; // "IChangeBufferValue<HelicopterInputSetting>"
            inline constexpr std::uintptr_t battleInputModel = 0x20; // "BattleInputModel"
            inline constexpr std::uintptr_t setting = 0x28; // "HelicopterInputSetting"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA959D0; // "public void Update()"
        }
    } // namespace KeyboardTiltHelicopterInputUpdater

    namespace LeaveVehicleInputUpdater { // "Game.Battle.Inputs.LeaveVehicleInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleEntitiesModel = 0x10; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t battleInputModel = 0x18; // "BattleInputModel"
            inline constexpr std::uintptr_t leaveVehicleInputModel = 0x20; // "InputModel"
            inline constexpr std::uintptr_t now = 0x28; // "INow"
            inline constexpr std::uintptr_t endTs = 0x30; // "long"
            inline constexpr std::uintptr_t canTrigger = 0x38; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA7EBB0; // "public void Update()"
        }
    } // namespace LeaveVehicleInputUpdater

    namespace LeaveVehicleProgressUpdater { // "Game.Battle.Entities.Vehicles.Updaters.LeaveVehicleProgressUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t inputHoldModel = 0x10; // "GlobalInputHoldModel"
            inline constexpr std::uintptr_t inVehicleTargetModel = 0x18; // "TargetModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x20; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t now = 0x28; // "INow"
            inline constexpr std::uintptr_t predictionExtraTimeModel = 0x30; // "PredictionExtraTimeModel"
            inline constexpr std::uintptr_t minProgressByDefault = 0x38; // "float"
            inline constexpr std::uintptr_t minProgressInConflictWithTargetSystem = 0x3C; // "float"
            inline constexpr std::uintptr_t progress = 0x40; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xAC5600; // "public void Update()"
        }
    } // namespace LeaveVehicleProgressUpdater

    namespace LocationVehicleSpawnDescription { // "Models.References.Location.LocationVehiclesSpawnPoints.LocationVehicleSpawnDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Points = 0x10; // "IReadOnlyList<LocationVehicleSpawnPointDescription>"
        }
    } // namespace LocationVehicleSpawnDescription

    namespace LocationVehicleSpawnPointDescription { // "Models.References.Location.LocationVehiclesSpawnPoints.LocationVehicleSpawnPointDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t EntityId = 0x10; // "int"
            inline constexpr std::uintptr_t DescriptionFunc = 0x18; // "Func<VehicleSpawnPointDescription>"
            inline constexpr std::uintptr_t Position = 0x20; // "Vector3"
            inline constexpr std::uintptr_t Orientation = 0x2C; // "Quaternion"
            inline constexpr std::uintptr_t Slots = 0x40; // "IReadOnlyList<OrientedPoint>"
            inline constexpr std::uintptr_t InteractPoint = 0x48; // "Vector3"
            inline constexpr std::uintptr_t InteractDescription = 0x58; // "InteractDescription"
            inline constexpr std::uintptr_t InteractIgnoreStaticBodies = 0x60; // "HashSet<PhysicsBodyId>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Description = 0x26CF2F0; // "public VehicleSpawnPointDescription get_Description()"
            inline constexpr std::uintptr_t New = 0x4348070; // "public static LocationVehicleSpawnPointDescription New(int entityId, VehicleSpawnPointDescription description, Vector3 position, Quaternion orientation, IReadOnlyList<OrientedPoint> slots, Vector3 interactPoint, InteractDescription interactDescription, HashSet<PhysicsBodyId> interactIgnoreStaticBodies)"
        }
    } // namespace LocationVehicleSpawnPointDescription

    namespace MailItemContext_CarSkin { // "Game.Global.Mail.Models.MailItemContext.CarSkin (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Description = 0x10; // "CarDescription"
        }
    } // namespace MailItemContext_CarSkin

    namespace MailItemContext_HelicopterSkin { // "Game.Global.Mail.Models.MailItemContext.HelicopterSkin (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Description = 0x10; // "HelicopterDescription"
        }
    } // namespace MailItemContext_HelicopterSkin

    namespace MapVehicleData { // "Models.Data.Vehicle.MapVehicleData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t X = 0x20; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t Z = 0x28; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t EntityId = 0x30; // "BattleEntityIdData"
            inline constexpr std::uintptr_t VehicleSpawnedType = 0x38; // "IPrimitiveData<VehicleTypeDescription>"
        }
    } // namespace MapVehicleData

    namespace MapVehicleModel { // "Models.Models.MapVehicle.MapVehicleModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t EntityId = 0x10; // "BattleEntityIdModel"
            inline constexpr std::uintptr_t MapTransform = 0x18; // "VehicleMapTransformModel"
            inline constexpr std::uintptr_t VehicleType = 0x20; // "IPrimitiveModel<VehicleTypeDescription>"
        }
    } // namespace MapVehicleModel

    namespace MapVehiclesModel { // "Models.Models.MapVehicles.MapVehiclesModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t models = 0x10; // "Dictionary<int, MapVehicleModel>"
            inline constexpr std::uintptr_t freeSlots = 0x18; // "Queue<MapVehicleModel>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Contains = 0x4911640; // "public bool Contains(int entityId)"
            inline constexpr std::uintptr_t TryGet = 0x49117A0; // "public bool TryGet(int entityId, out MapVehicleModel model)"
            inline constexpr std::uintptr_t Add = 0x4911560; // "public MapVehicleModel Add(int entityId, VehicleTypeDescription vehicleType)"
            inline constexpr std::uintptr_t Remove = 0x49116A0; // "public void Remove(int entityId)"
        }
    } // namespace MapVehiclesModel

    namespace MoveCarCityTouchInputUpdater { // "Game.Battle.Inputs.Updaters.Touch.MoveCarCityTouchInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t carControlView = 0x10; // "CarControlView"
            inline constexpr std::uintptr_t battleInputModel = 0x18; // "BattleInputModel"
            inline constexpr std::uintptr_t movementInputModel = 0x20; // "PlayerMovementInputModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA964A0; // "public void Update()"
        }
    } // namespace MoveCarCityTouchInputUpdater

    namespace MoveVehicleCityKeyboardInputUpdater { // "Game.Battle.Inputs.Updaters.Keyboard.MoveVehicleCityKeyboardInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t moveAction = 0x10; // "InputAction"
            inline constexpr std::uintptr_t battleInputModel = 0x18; // "BattleInputModel"
            inline constexpr std::uintptr_t movementInputModel = 0x20; // "PlayerMovementInputModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA968F0; // "public void Update()"
        }
    } // namespace MoveVehicleCityKeyboardInputUpdater

    namespace NitroCarUpgradeReadAdapter { // "Models.Utils.Adapters.CarUpgradeAdapter.NitroCarUpgradeReadAdapter (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t TryFromItem = 0x3C916A0; // "public bool TryFromItem(InventoryItemDescription item, out NitroCarUpgradeDescription value)"
            inline constexpr std::uintptr_t TryGetUpgradeSlot = 0x3C916E0; // "public bool TryGetUpgradeSlot(CarUpgradesSlotsModel carUpgradesSlotsModel, int slotIndex, CarDescription carDescription, out IPrimitiveModel<NitroCarUpgradeDescription> slotModel)"
            inline constexpr std::uintptr_t CheckUnsetUpgrade = 0x7D5050; // "public bool CheckUnsetUpgrade(int entityId, IPrimitiveModel<NitroCarUpgradeDescription> slotModel)"
            inline constexpr std::uintptr_t CheckSwap = 0x7D5050; // "public bool CheckSwap(int entityId, IPrimitiveModel<NitroCarUpgradeDescription> slotModel, NitroCarUpgradeDescription upgradeDescription)"
        }
    } // namespace NitroCarUpgradeReadAdapter

    namespace OpenCarUpgradesHolderMessage { // "Models.Messages.Vehicle.Car.OpenCarUpgradesHolderMessage (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x4A0B270; // "public override string get_Type()"
        }
    } // namespace OpenCarUpgradesHolderMessage

    namespace OpenPlotCarUpgradesHolderMessage { // "Models.Messages.Vehicle.Car.OpenPlotCarUpgradesHolderMessage (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x4A0B2A0; // "public override string get_Type()"
        }
    } // namespace OpenPlotCarUpgradesHolderMessage

    namespace OpenVehicleTrunkMessage { // "Models.Messages.OpenVehicleTrunkMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t entityId = 0x20; // "BattleEntityIdData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_EntityId = 0x4A0BA20; // "public int get_EntityId()"
            inline constexpr std::uintptr_t get_Type = 0x4A0BA60; // "public override string get_Type()"
        }
    } // namespace OpenVehicleTrunkMessage

    namespace OverridePlayerPositionAfterLeavingCarUpdater { // "Game.Battle.EntityModel.Player.Movement.OverridePlayerPositionAfterLeavingCarUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t stateModel = 0x10; // "IBattleCharacterStateModel"
            inline constexpr std::uintptr_t setMovement = 0x18; // "SetMovementModel"
            inline constexpr std::uintptr_t transform = 0x20; // "ITransformModel"
            inline constexpr std::uintptr_t timeModel = 0x28; // "TimeModel"
            inline constexpr std::uintptr_t tickStartTs = 0x30; // "long"
            inline constexpr std::uintptr_t next = 0x38; // "bool"
            inline constexpr std::uintptr_t stage = 0x3C; // "OverridePlayerPositionAfterLeavingCarUpdater.Stage"
            inline constexpr std::uintptr_t oldState = 0x40; // "BattleCharacterState"
            inline constexpr std::uintptr_t p1 = 0x48; // "MovementData"
            inline constexpr std::uintptr_t p2 = 0x70; // "MovementData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC72C60; // "public void Update()"
            inline constexpr std::uintptr_t UpdatePosition = 0xC72850; // "private void UpdatePosition()"
            inline constexpr std::uintptr_t UpdateStage = 0xC72940; // "private void UpdateStage()"
        }
    } // namespace OverridePlayerPositionAfterLeavingCarUpdater

    namespace OwnedVehiclesModel { // "Models.Models.OwnedVehicles.OwnedVehiclesModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t vehicles = 0x10; // "Dictionary<long, VehicleModel>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t TryGetVehicle = 0x49160F0; // "public bool TryGetVehicle(long publicId, out VehicleModel vehicleModel)"
            inline constexpr std::uintptr_t AddVehicle = 0x4915FD0; // "public void AddVehicle(VehicleModel vehicleModel)"
            inline constexpr std::uintptr_t RemoveVehicle = 0x4916060; // "public void RemoveVehicle(VehicleModel vehicleModel)"
        }
    } // namespace OwnedVehiclesModel

    namespace PartiesVehiclesModel { // "Models.Models.PartiesVehicles.PartiesVehiclesModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t registrationsByVehicleId = 0x10; // "Dictionary<int, ValueTuple<PartyModel, long, PartyVehicleModel>>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetPartyVehicle = 0x49162E0; // "public PartyVehicleModel SetPartyVehicle(long publicId, int vehicleEntityId, VehicleTypeDescription vehicleType, PartyModel partyModel, out PartyModel previousParty)"
            inline constexpr std::uintptr_t RemovePartyVehicle = 0x49161E0; // "public bool RemovePartyVehicle(int vehicleEntityId, out PartyModel partyModel)"
            inline constexpr std::uintptr_t TryGetPartyVehicle = 0x4916620; // "public bool TryGetPartyVehicle(int vehicleId, out PartyVehicleModel partyVehicleModel)"
        }
    } // namespace PartiesVehiclesModel

    namespace PartyVehicleData { // "Models.Data.Party.PartyVehicleData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t EntityId = 0x20; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t Type = 0x28; // "IPrimitiveData<VehicleTypeDescription>"
            inline constexpr std::uintptr_t X = 0x30; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t Z = 0x38; // "IPrimitiveData<int>"
        }
    } // namespace PartyVehicleData

    namespace PartyVehicleExitData { // "Models.Data.PartyVehicleExitData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t UsePartyVehicleEnter = 0x20; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t VehicleCharacterPublicId = 0x28; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t VehicleSeatSlot = 0x30; // "IPrimitiveData<VehicleSeatSlotDescription>"
        }
    } // namespace PartyVehicleExitData

    namespace PartyVehicleExitModel { // "Models.Models.PartyVehicleExit.PartyVehicleExitModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "PartyVehicleExitData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_ReplicationData = 0x7EC6B0; // "public IData get_ReplicationData()"
            inline constexpr std::uintptr_t get_UsePartyVehicleEnter = 0x49175E0; // "public bool get_UsePartyVehicleEnter()"
            inline constexpr std::uintptr_t get_VehicleCharacterPublicId = 0x4917630; // "public long get_VehicleCharacterPublicId()"
            inline constexpr std::uintptr_t get_VehicleSeatSlot = 0x4917680; // "public VehicleSeatSlotDescription get_VehicleSeatSlot()"
            inline constexpr std::uintptr_t Set = 0x49173D0; // "public void Set(long vehicleCharacterPublicId, VehicleSeatSlotDescription vehicleSeatSlot)"
            inline constexpr std::uintptr_t Unset = 0x4917550; // "public void Unset()"
            inline constexpr std::uintptr_t Set_2 = 0x49173F0; // "private void Set(bool usePartyVehicleEnter, long vehicleCharacterPublicId, VehicleSeatSlotDescription vehicleSeatSlot)"
        }
    } // namespace PartyVehicleExitModel

    namespace PartyVehicleModel { // "Models.Models.PartyVehicle.PartyVehicleModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "PartyVehicleData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Set = 0x4917750; // "public void Set(int entityId, VehicleTypeDescription type)"
            inline constexpr std::uintptr_t UpdatePosition = 0x49177F0; // "public void UpdatePosition(int x, int z)"
        }
    } // namespace PartyVehicleModel

    namespace PartyVehicleOwnerModel { // "Models.Models.PartyVehicleOwner.PartyVehicleOwnerModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t OwnerId = 0x10; // "string"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsHaveOwner = 0xA18FC0; // "public bool get_IsHaveOwner()"
            inline constexpr std::uintptr_t Set = 0x7EC730; // "public void Set(string ownerId)"
            inline constexpr std::uintptr_t Clear = 0xA18FA0; // "public void Clear()"
        }
    } // namespace PartyVehicleOwnerModel

    namespace PartyVehiclesModel { // "Game.Global.Party.PartyVehiclesModel (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t partyVehiclesData = 0x10; // "PartyVehiclesData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetData = 0x7EC730; // "public void SetData(PartyVehiclesData partyVehiclesData)"
            inline constexpr std::uintptr_t Contains = 0x3577370; // "public bool Contains(int vehicleEntityId)"
            inline constexpr std::uintptr_t TryGetVehicleData = 0x3577500; // "public bool TryGetVehicleData(long publicId, out PartyVehicleData partyVehicleData)"
        }
    } // namespace PartyVehiclesModel

    namespace PartyVehiclesModel_2 { // "Models.Models.PartyVehicles.PartyVehiclesModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "DictionaryData<long, PartyVehicleData>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Count = 0x4917B00; // "public int get_Count()"
            inline constexpr std::uintptr_t Add = 0x49178A0; // "public PartyVehicleModel Add(long publicId, int entityId, VehicleTypeDescription type)"
            inline constexpr std::uintptr_t Remove = 0x4917AA0; // "public void Remove(long publicId)"
            inline constexpr std::uintptr_t GetAllVehicles = 0x4917A20; // "public IEnumerable<int> GetAllVehicles()"
            inline constexpr std::uintptr_t GetAllVehicleOwnerPublicIds = 0x49179D0; // "public Dictionary.KeyCollection<long, PartyVehicleData> GetAllVehicleOwnerPublicIds()"
        }
    } // namespace PartyVehiclesModel_2

    namespace PhysicsDebugCarSubTickData { // "Models.Models.PhysicsDebug.Data.Car.PhysicsDebugCarSubTickData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t PositionCoM = 0x10; // "Vector3"
            inline constexpr std::uintptr_t OrientationCoM = 0x1C; // "Quaternion"
            inline constexpr std::uintptr_t LinearVelocity = 0x2C; // "Vector3"
            inline constexpr std::uintptr_t AngularVelocity = 0x38; // "Vector3"
            inline constexpr std::uintptr_t ManifoldsCount = 0x44; // "int"
            inline constexpr std::uintptr_t Manifolds = 0x48; // "ManifoldPoint[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Clear = 0x491C090; // "public void Clear()"
            inline constexpr std::uintptr_t CopyTo = 0x491C110; // "public void CopyTo(PhysicsDebugCarSubTickData copy)"
        }
    } // namespace PhysicsDebugCarSubTickData

    namespace PhysicsDebugCarTickData { // "Models.Models.PhysicsDebug.Data.Car.PhysicsDebugCarTickData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Description = 0x10; // "CarDescription"
            inline constexpr std::uintptr_t TimeOffsetData = 0x18; // "PhysicsDebugTimeOffsetData"
            inline constexpr std::uintptr_t DeadReckoningData = 0x20; // "PhysicsDebugDeadReckoningData"
            inline constexpr std::uintptr_t Wheels = 0x28; // "PhysicsDebugCarWheelTickData[]"
            inline constexpr std::uintptr_t SubTicks = 0x30; // "PhysicsDebugCarSubTickData[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Clear = 0x491C220; // "public void Clear()"
            inline constexpr std::uintptr_t Copy = 0x491C440; // "public PhysicsDebugCarTickData Copy()"
        }
    } // namespace PhysicsDebugCarTickData

    namespace PhysicsDebugCarView { // "Game.Battle.PhysicsDebug.View.Car.PhysicsDebugCarView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t LinearVelocity = 0x20; // "Vector3"
            inline constexpr std::uintptr_t LinearVelocityMagnitude = 0x2C; // "float"
            inline constexpr std::uintptr_t AngularVelocity = 0x30; // "Vector3"
            inline constexpr std::uintptr_t AngularVelocityAxis = 0x3C; // "Vector3"
            inline constexpr std::uintptr_t AngularVelocityMagnitude = 0x48; // "float"
            inline constexpr std::uintptr_t CarEntityView = 0x50; // "IDisposableContent<CarEntityView>"
            inline constexpr std::uintptr_t TimeOffset = 0x58; // "PhysicsDebugTimeOffsetView"
            inline constexpr std::uintptr_t DeadReckoning = 0x60; // "PhysicsDebugDeadReckoningView"
            inline constexpr std::uintptr_t Wheels = 0x68; // "PhysicsDebugCarWheelView[]"
            inline constexpr std::uintptr_t ManifoldsData = 0x70; // "PhysicsDebugManifoldData"
            inline constexpr std::uintptr_t WheelsRaycasts = 0x98; // "PhysicsDebugRaycastsModel"
            inline constexpr std::uintptr_t Manifolds = 0xA0; // "PhysicsDebugManifoldPointsModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t OnDrawGizmos = 0x965C90; // "private void OnDrawGizmos()"
        }
    } // namespace PhysicsDebugCarView

    namespace PhysicsDebugCarWheelTickData { // "Models.Models.PhysicsDebug.Data.Car.PhysicsDebugCarWheelTickData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t GroundFound = 0x10; // "bool"
            inline constexpr std::uintptr_t GroundContactDistance = 0x14; // "float"
            inline constexpr std::uintptr_t IsGroundWithLargeSlope = 0x18; // "bool"
            inline constexpr std::uintptr_t SpringLengthFromData = 0x1C; // "float"
            inline constexpr std::uintptr_t SpringLengthCalculated = 0x20; // "float"
            inline constexpr std::uintptr_t SpringContactDepth = 0x24; // "float"
            inline constexpr std::uintptr_t SpringContactSpeed = 0x28; // "float"
            inline constexpr std::uintptr_t ContactDepth = 0x2C; // "float"
            inline constexpr std::uintptr_t ContactSpeed = 0x30; // "float"
            inline constexpr std::uintptr_t Stiffness = 0x34; // "float"
            inline constexpr std::uintptr_t Damper = 0x38; // "float"
            inline constexpr std::uintptr_t LinkVelocityAlongSuspensionDirection = 0x3C; // "float"
            inline constexpr std::uintptr_t IdleForce = 0x40; // "float"
            inline constexpr std::uintptr_t StiffnessForce = 0x44; // "float"
            inline constexpr std::uintptr_t DamperForce = 0x48; // "float"
            inline constexpr std::uintptr_t TotalForce = 0x4C; // "float"
            inline constexpr std::uintptr_t LinearVelocityAlongX = 0x50; // "float"
            inline constexpr std::uintptr_t LinearVelocityAlongZ = 0x54; // "float"
            inline constexpr std::uintptr_t FakeAngularLinearVelocity = 0x58; // "float"
            inline constexpr std::uintptr_t UseCombinedFrictionType = 0x5C; // "bool"
            inline constexpr std::uintptr_t UseBlockedFrictionType = 0x5D; // "bool"
            inline constexpr std::uintptr_t UseBurnoutFrictionType = 0x5E; // "bool"
            inline constexpr std::uintptr_t FrictionForwardSlipVelocity = 0x60; // "float"
            inline constexpr std::uintptr_t FrictionLateralSlipVelocity = 0x64; // "float"
            inline constexpr std::uintptr_t FrictionMaxLongForce = 0x68; // "float"
            inline constexpr std::uintptr_t FrictionMaxLatForce = 0x6C; // "float"
            inline constexpr std::uintptr_t SlipRatioType = 0x70; // "int"
            inline constexpr std::uintptr_t SlipRatio = 0x74; // "float"
            inline constexpr std::uintptr_t SlipRatioSign = 0x78; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Clear = 0x491CAD0; // "public void Clear()"
            inline constexpr std::uintptr_t CopyTo = 0x491CB20; // "public void CopyTo(PhysicsDebugCarWheelTickData copy)"
        }
    } // namespace PhysicsDebugCarWheelTickData

    namespace PhysicsDebugCarWheelView { // "Game.Battle.PhysicsDebug.View.Car.PhysicsDebugCarWheelView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t LinearVelocityAtLink = 0x20; // "Vector3"
            inline constexpr std::uintptr_t LinearVelocityAtLinkAlongLinkDirection = 0x2C; // "float"
            inline constexpr std::uintptr_t GroundFound = 0x30; // "bool"
            inline constexpr std::uintptr_t GroundContactDistance = 0x34; // "float"
            inline constexpr std::uintptr_t SpringLengthFromData = 0x38; // "float"
            inline constexpr std::uintptr_t SpringLengthCalculated = 0x3C; // "float"
            inline constexpr std::uintptr_t SpringContactDepth = 0x40; // "float"
            inline constexpr std::uintptr_t SpringContactSpeed = 0x44; // "float"
            inline constexpr std::uintptr_t ContactDepth = 0x48; // "float"
            inline constexpr std::uintptr_t ContactSpeed = 0x4C; // "float"
            inline constexpr std::uintptr_t Stiffness = 0x50; // "float"
            inline constexpr std::uintptr_t Damper = 0x54; // "float"
            inline constexpr std::uintptr_t LinkVelocityAlongSuspensionDirection = 0x58; // "float"
            inline constexpr std::uintptr_t IdleForce = 0x5C; // "float"
            inline constexpr std::uintptr_t StiffnessForce = 0x60; // "float"
            inline constexpr std::uintptr_t DamperForce = 0x64; // "float"
            inline constexpr std::uintptr_t TotalForce = 0x68; // "float"
            inline constexpr std::uintptr_t LinearVelocityAlongX = 0x6C; // "float"
            inline constexpr std::uintptr_t LinearVelocityAlongZ = 0x70; // "float"
            inline constexpr std::uintptr_t FakeAngularLinearVelocity = 0x74; // "float"
            inline constexpr std::uintptr_t UseCombinedFrictionType = 0x78; // "bool"
            inline constexpr std::uintptr_t UseBlockedFrictionType = 0x79; // "bool"
            inline constexpr std::uintptr_t UseBurnoutFrictionType = 0x7A; // "bool"
            inline constexpr std::uintptr_t FrictionForwardSlipVelocity = 0x7C; // "float"
            inline constexpr std::uintptr_t FrictionLateralSlipVelocity = 0x80; // "float"
            inline constexpr std::uintptr_t FrictionMaxLongForce = 0x84; // "float"
            inline constexpr std::uintptr_t FrictionMaxLatForce = 0x88; // "float"
            inline constexpr std::uintptr_t SlipRatioType = 0x8C; // "int"
            inline constexpr std::uintptr_t SlipRatio = 0x90; // "float"
            inline constexpr std::uintptr_t SlipRatioSign = 0x94; // "int"
        }
    } // namespace PhysicsDebugCarWheelView

    namespace PhysicsDebugClientNotPredictedVehiclesSpringStateSystem { // "Models.Systems.PhysicsDebugClientNotPredictedVehiclesSpringStateSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t notPredictedCars = 0x10; // "List<CarModel>"
            inline constexpr std::uintptr_t notPredictedHelicopters = 0x18; // "List<HelicopterModel>"
            inline constexpr std::uintptr_t physicsDebugEnabledModel = 0x20; // "PhysicsDebugEnabledModel"
            inline constexpr std::uintptr_t physicsDebugModel = 0x28; // "IPhysicsDebugModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x4101220; // "public void Update(ITick tick)"
        }
    } // namespace PhysicsDebugClientNotPredictedVehiclesSpringStateSystem

    namespace PhysicsDebugHelicopterSubTickData { // "Models.Models.PhysicsDebug.Data.Helicopter.PhysicsDebugHelicopterSubTickData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t PositionCoM = 0x10; // "Vector3"
            inline constexpr std::uintptr_t OrientationCoM = 0x1C; // "Quaternion"
            inline constexpr std::uintptr_t LinearVelocity = 0x2C; // "Vector3"
            inline constexpr std::uintptr_t AngularVelocity = 0x38; // "Vector3"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Clear = 0x491CE40; // "public void Clear()"
            inline constexpr std::uintptr_t CopyTo = 0x491CEC0; // "public void CopyTo(PhysicsDebugHelicopterSubTickData copy)"
        }
    } // namespace PhysicsDebugHelicopterSubTickData

    namespace PhysicsDebugHelicopterTickData { // "Models.Models.PhysicsDebug.Data.Helicopter.PhysicsDebugHelicopterTickData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Description = 0x10; // "HelicopterDescription"
            inline constexpr std::uintptr_t TimeOffsetData = 0x18; // "PhysicsDebugTimeOffsetData"
            inline constexpr std::uintptr_t DeadReckoningData = 0x20; // "PhysicsDebugDeadReckoningData"
            inline constexpr std::uintptr_t Wheels = 0x28; // "PhysicsDebugHelicopterWheelTickData[]"
            inline constexpr std::uintptr_t SubTicks = 0x30; // "PhysicsDebugHelicopterSubTickData[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Clear = 0x491CF10; // "public void Clear()"
            inline constexpr std::uintptr_t Copy = 0x491D0F0; // "public PhysicsDebugHelicopterTickData Copy()"
        }
    } // namespace PhysicsDebugHelicopterTickData

    namespace PhysicsDebugHelicopterView { // "Game.Battle.PhysicsDebug.View.Helicopter.PhysicsDebugHelicopterView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t LinearVelocity = 0x20; // "Vector3"
            inline constexpr std::uintptr_t LinearVelocityMagnitude = 0x2C; // "float"
            inline constexpr std::uintptr_t AngularVelocity = 0x30; // "Vector3"
            inline constexpr std::uintptr_t AngularVelocityAxis = 0x3C; // "Vector3"
            inline constexpr std::uintptr_t AngularVelocityMagnitude = 0x48; // "float"
            inline constexpr std::uintptr_t HelicopterEntityView = 0x50; // "IDisposableContent<HelicopterEntityView>"
            inline constexpr std::uintptr_t TimeOffset = 0x58; // "PhysicsDebugTimeOffsetView"
            inline constexpr std::uintptr_t DeadReckoning = 0x60; // "PhysicsDebugDeadReckoningView"
            inline constexpr std::uintptr_t Wheels = 0x68; // "PhysicsDebugHelicopterWheelView[]"
            inline constexpr std::uintptr_t WheelsRaycasts = 0x70; // "PhysicsDebugRaycastsModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t OnDrawGizmos = 0x972090; // "private void OnDrawGizmos()"
        }
    } // namespace PhysicsDebugHelicopterView

    namespace PhysicsDebugHelicopterWheelTickData { // "Models.Models.PhysicsDebug.Data.Helicopter.PhysicsDebugHelicopterWheelTickData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t GroundFound = 0x10; // "bool"
            inline constexpr std::uintptr_t GroundContactDistance = 0x14; // "float"
            inline constexpr std::uintptr_t IsGroundWithLargeSlope = 0x18; // "bool"
            inline constexpr std::uintptr_t SpringLengthFromData = 0x1C; // "float"
            inline constexpr std::uintptr_t SpringLengthCalculated = 0x20; // "float"
            inline constexpr std::uintptr_t SpringContactDepth = 0x24; // "float"
            inline constexpr std::uintptr_t SpringContactSpeed = 0x28; // "float"
            inline constexpr std::uintptr_t ContactDepth = 0x2C; // "float"
            inline constexpr std::uintptr_t ContactSpeed = 0x30; // "float"
            inline constexpr std::uintptr_t Stiffness = 0x34; // "float"
            inline constexpr std::uintptr_t Damper = 0x38; // "float"
            inline constexpr std::uintptr_t LinkVelocityAlongSuspensionDirection = 0x3C; // "float"
            inline constexpr std::uintptr_t IdleForce = 0x40; // "float"
            inline constexpr std::uintptr_t StiffnessForce = 0x44; // "float"
            inline constexpr std::uintptr_t DamperForce = 0x48; // "float"
            inline constexpr std::uintptr_t TotalForce = 0x4C; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Clear = 0x491D6B0; // "public void Clear()"
            inline constexpr std::uintptr_t CopyTo = 0x491D6E0; // "public void CopyTo(PhysicsDebugHelicopterWheelTickData copy)"
        }
    } // namespace PhysicsDebugHelicopterWheelTickData

    namespace PhysicsDebugHelicopterWheelView { // "Game.Battle.PhysicsDebug.View.Helicopter.PhysicsDebugHelicopterWheelView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t GroundFound = 0x20; // "bool"
            inline constexpr std::uintptr_t GroundContactDistance = 0x24; // "float"
            inline constexpr std::uintptr_t SpringLengthFromData = 0x28; // "float"
            inline constexpr std::uintptr_t SpringLengthCalculated = 0x2C; // "float"
            inline constexpr std::uintptr_t SpringContactDepth = 0x30; // "float"
            inline constexpr std::uintptr_t SpringContactSpeed = 0x34; // "float"
            inline constexpr std::uintptr_t ContactDepth = 0x38; // "float"
            inline constexpr std::uintptr_t ContactSpeed = 0x3C; // "float"
            inline constexpr std::uintptr_t Stiffness = 0x40; // "float"
            inline constexpr std::uintptr_t Damper = 0x44; // "float"
            inline constexpr std::uintptr_t LinkVelocityAlongSuspensionDirection = 0x48; // "float"
            inline constexpr std::uintptr_t IdleForce = 0x4C; // "float"
            inline constexpr std::uintptr_t StiffnessForce = 0x50; // "float"
            inline constexpr std::uintptr_t DamperForce = 0x54; // "float"
            inline constexpr std::uintptr_t TotalForce = 0x58; // "float"
        }
    } // namespace PhysicsDebugHelicopterWheelView

    namespace PlayerDelayInputVehicleLeaveModel { // "Game.Battle.Entities.Player.Models.PlayerDelayInputVehicleLeaveModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t NextInputUpdateTime = 0x10; // "long"
        }
    } // namespace PlayerDelayInputVehicleLeaveModel

    namespace PlayerDesiredYawInVehicleUpdater { // "Game.Battle.Entities.Player.Rotation.Updaters.PlayerDesiredYawInVehicleUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t clientDesiredYawModel = 0x10; // "DesiredYawModel"
            inline constexpr std::uintptr_t serverDesiredYawModel = 0x18; // "DesiredYawModel"
            inline constexpr std::uintptr_t playerRotationInputModel = 0x20; // "PlayerRotationInputModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB1F790; // "public void Update()"
        }
    } // namespace PlayerDesiredYawInVehicleUpdater

    namespace PlayerFollowVehicleCameraPositionUpdater { // "Game.Battle.Entities.Player.Updaters.PlayerFollowVehicleCameraPositionUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t state = 0x10; // "IBattleCharacterStateModel"
            inline constexpr std::uintptr_t inVehicleModel = 0x18; // "InVehicleModel"
            inline constexpr std::uintptr_t vehiclesModel = 0x20; // "VehiclesClientModel"
            inline constexpr std::uintptr_t cameraFollowVehicle = 0x28; // "Transform"
            inline constexpr std::uintptr_t oldState = 0x30; // "BattleCharacterState"
            inline constexpr std::uintptr_t oldPositionVehicle = 0x34; // "Vector3"
            inline constexpr std::uintptr_t localPositionOfVehicleCameraAfterWarp = 0x40; // "Vector3"
            inline constexpr std::uintptr_t rotationBeforeLeavingVehicle = 0x4C; // "Matrix4x4"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB0CC20; // "public void Update()"
            inline constexpr std::uintptr_t GetVehiclePivotPosition = 0xB0CBB0; // "private Vector3 GetVehiclePivotPosition()"
            inline constexpr std::uintptr_t GetRotation = 0xB0CA50; // "private Matrix4x4 GetRotation(Transform transform)"
        }
    } // namespace PlayerFollowVehicleCameraPositionUpdater

    namespace PlayerInVehicleModel { // "Game.Battle.EntityModel.Player.PlayerInVehicleModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsDriveVehicle = 0x10; // "bool"
            inline constexpr std::uintptr_t VehicleEntityId = 0x14; // "int"
        }
    } // namespace PlayerInVehicleModel

    namespace PlayerVehicleMapMarkerUpdater { // "Game.Battle.Entities.Player.Vehicle.Updaters.PlayerVehicleMapMarkerUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleEntitiesModel = 0x10; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t partyModel = 0x18; // "PartyModel"
            inline constexpr std::uintptr_t mapMarkersModel = 0x20; // "MapMarkersModel"
            inline constexpr std::uintptr_t ownersModel = 0x28; // "VehicleOwnersModel"
            inline constexpr std::uintptr_t markerModel = 0x30; // "VehicleMapMarkerModel"
            inline constexpr std::uintptr_t canDrawMarker = 0x38; // "bool"
            inline constexpr std::uintptr_t vehicleType = 0x40; // "VehicleTypeDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB101C0; // "public void Update()"
            inline constexpr std::uintptr_t CanDrawMarker = 0xB10040; // "private bool CanDrawMarker(PlayerEntityModel player)"
            inline constexpr std::uintptr_t IsPlayerInside = 0xB10150; // "private bool IsPlayerInside(PlayerEntityModel player)"
            inline constexpr std::uintptr_t Clear = 0xAB3BB0; // "private void Clear()"
        }
    } // namespace PlayerVehicleMapMarkerUpdater

    namespace PlayerVehiclesData { // "Models.Data.Vehicle.PlayerVehiclesData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t OwnedCars = 0x20; // "SetData<CarDescription>"
            inline constexpr std::uintptr_t OwnedHelicopters = 0x28; // "SetData<HelicopterDescription>"
            inline constexpr std::uintptr_t SelectedCars = 0x30; // "ReferenceMapData<CarSlotDescription, IPrimitiveData<CarDescription>>"
            inline constexpr std::uintptr_t SelectedHelicopters = 0x38; // "ReferenceMapData<HelicopterSlotDescription, IPrimitiveData<HelicopterDescription>>"
        }
    } // namespace PlayerVehiclesData

    namespace PlayerVehiclesModel { // "Models.Models.PlayerVehicles.PlayerVehiclesModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t OwnedCars = 0x10; // "IOwnedItemsModel<CarDescription>"
            inline constexpr std::uintptr_t OwnedHelicopters = 0x18; // "IOwnedItemsModel<HelicopterDescription>"
            inline constexpr std::uintptr_t SelectedCars = 0x20; // "SelectedVehiclesModel<CarSlotDescription, CarDescription>"
            inline constexpr std::uintptr_t SelectedHelicopters = 0x28; // "SelectedVehiclesModel<HelicopterSlotDescription, HelicopterDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Clear = 0x492A2D0; // "public void Clear()"
        }
    } // namespace PlayerVehiclesModel

    namespace PlayerVehicleSpawnersUpdater { // "Game.Battle.EntityModel.VehicleSpawner.PlayerVehicleSpawnersUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t updaters = 0x10; // "IUpdater"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xBF4670; // "public void Update()"
            inline constexpr std::uintptr_t RegisterVehicleSpawner = 0xBF43A0; // "private static void RegisterVehicleSpawner(int entityId, GlobalModel globalModel, GlobalScreenContent globalScreenContent, BattleModel battleModel, BattleScreenContent battleScreenContent, IRoomConnection battleRoomConnection, InputActions inputActions, ITargetSubsystem targetSubsystem, LocationVehicleSpawnPointDescription locationVehicle, VehicleTypeDescription vehicleTypeDescription, VehicleSpawnerView view, IRegisterDisposable registerDisposable)"
        }
    } // namespace PlayerVehicleSpawnersUpdater

    namespace PlotCarData { // "Models.Data.PlotCarData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsHoodOpened = 0x58; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t UpgradesSlots = 0x60; // "CarUpgradesSlotsData"
        }
    } // namespace PlotCarData

    namespace PlotCarDestroyModel { // "Models.Models.PlotCarDestroy.PlotCarDestroyModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "IPlotCarModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Destroy = 0x48EEA70; // "public void Destroy(WorldEntitiesModel worldEntitiesModel)"
        }
    } // namespace PlotCarDestroyModel

    namespace PlotCarGarageDestroyModel { // "Models.Models.PlotCarGarageDestroy.PlotCarGarageDestroyModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "PlotCarGarageModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Destroy = 0x48EEB20; // "public void Destroy(WorldEntitiesModel worldEntitiesModel)"
        }
    } // namespace PlotCarGarageDestroyModel

    namespace PlotCarGarageInitializeModel { // "Models.Models.PlotCarGarageInitialize.PlotCarGarageInitializeModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "PlotCarGarageModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Initialize = 0x48EEFE0; // "public void Initialize(WorldEntitiesModel worldEntitiesModel, LocationGarageDescription<PlotCarSlotDescription> garageDescription)"
        }
    } // namespace PlotCarGarageInitializeModel

    namespace PlotCarGarageModel { // "Models.Models.PlotCarGarage.PlotCarGarageModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t cars = 0x10; // "Dictionary<PlotCarSlotDescription, IPlotCarModel>"
            inline constexpr std::uintptr_t DescriptionModel = 0x18; // "DescriptionModel<LocationGarageDescription<PlotCarSlotDescription>>"
            inline constexpr std::uintptr_t InitializeModel = 0x20; // "PlotCarGarageInitializeModel"
            inline constexpr std::uintptr_t DestroyModel = 0x28; // "PlotCarGarageDestroyModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Cars = 0x7EC6B0; // "public IReadOnlyDictionary<PlotCarSlotDescription, IPlotCarModel> get_Cars()"
        }
    } // namespace PlotCarGarageModel

    namespace PlotCarInitializeModel { // "Models.Models.PlotCarInitialize.PlotCarInitializeModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "IPlotCarModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Initialize = 0x48EF990; // "public void Initialize(WorldEntitiesModel worldEntitiesModel, LocationVehicleSlotDescription<PlotCarSlotDescription> vehicleSlotDescription)"
        }
    } // namespace PlotCarInitializeModel

    namespace PlotCarModel { // "Models.Models.PlotCarModel.PlotCarModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t InitializeModel = 0x60; // "PlotCarInitializeModel"
            inline constexpr std::uintptr_t DestroyModel = 0x68; // "PlotCarDestroyModel"
            inline constexpr std::uintptr_t IsHoodOpened = 0x70; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t UpgradesSlots = 0x78; // "CarUpgradesSlotsModel"
        }
    } // namespace PlotCarModel

    namespace PlotCarModelAdapter { // "Models.Models.PlotVehicleModelAdapter.PlotCarModelAdapter (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t GetVehicleGarageSlotColliders = 0x48EFA90; // "public CollidersDescription GetVehicleGarageSlotColliders(CarDescription vehicle)"
            inline constexpr std::uintptr_t GetTrunkLocalPosition = 0x48EFA50; // "public Vector3 GetTrunkLocalPosition(CarDescription vehicle)"
            inline constexpr std::uintptr_t GetVerticalDistanceFromPivotToGroundInRest = 0x48EFAC0; // "public float GetVerticalDistanceFromPivotToGroundInRest(CarDescription vehicle)"
            inline constexpr std::uintptr_t HasTrunk = 0x48EFAF0; // "public bool HasTrunk(CarDescription vehicle)"
        }
    } // namespace PlotCarModelAdapter

    namespace PlotCarTrunkEntityDataBuilder { // "Models.Replication.EntityDataBuilder.PlotCarTrunkEntityDataBuilder (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t paramsModel = 0x10; // "EntitiesParamsModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Build = 0x44C0F10; // "public IData Build(int id)"
        }
    } // namespace PlotCarTrunkEntityDataBuilder

    namespace PlotCarTrunkEntityStreamReader { // "Models.Replication.EntityStreamReader.PlotCarTrunkEntityStreamReader (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t paramsModel = 0x20; // "EntitiesParamsModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t TryReadParams = 0x44C0FB0; // "protected override bool TryReadParams(int entityId, IBinaryReadStream stream)"
        }
    } // namespace PlotCarTrunkEntityStreamReader

    namespace PlotGarageExtensions { // "Models.Utils.Extensions.PlotGarageExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t BuildEntityIds_TPlotVehicleSlotDescription_inst_1 = 0x112AEA0; // "PlotGarageExtensions.BuildEntityIds<object>"
            inline constexpr std::uintptr_t BuildLocationDescription_TPlotVehicleSlotDescription_inst_1 = 0x112B1B0; // "PlotGarageExtensions.BuildLocationDescription<object>"
            inline constexpr std::uintptr_t BuildLocationVehicleSlots_TPlotVehicleSlotDescription_inst_1 = 0x112BB40; // "PlotGarageExtensions.BuildLocationVehicleSlots<object>"
            inline constexpr std::uintptr_t BuildLocationVehicleSlots_TPlotVehicleSlotDescription_inst_2 = 0x112B4C0; // "PlotGarageExtensions.BuildLocationVehicleSlots<__Il2CppFullySharedGenericType>"
        }
    } // namespace PlotGarageExtensions

    namespace PlotGarageSlotDescription { // "Models.References.Plot.PlotGarageSlotDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Position = 0x10; // "Vector3"
            inline constexpr std::uintptr_t Orientation = 0x1C; // "Quaternion"
            inline constexpr std::uintptr_t InitialDirtyLevel = 0x2C; // "float"
        }
    } // namespace PlotGarageSlotDescription

    namespace PlotGarageSlotsUpdater { // "ClientCore.Builder.PlotGarageSlotsUpdater (Client.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dataModel = 0x10; // "IDataModel"
            inline constexpr std::uintptr_t updater = 0x18; // "List<IClientUpdater>"
            inline constexpr std::uintptr_t dataTickIndex = 0x20; // "long"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xE89A60; // "public void Update()"
        }
    } // namespace PlotGarageSlotsUpdater

    namespace PlotHelicopterDestroyModel { // "Models.Models.PlotHelicopterDestroy.PlotHelicopterDestroyModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "PlotHelicopterModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Destroy = 0x48F9F10; // "public void Destroy(WorldEntitiesModel worldEntitiesModel)"
        }
    } // namespace PlotHelicopterDestroyModel

    namespace PlotHelicopterGarageDestroyModel { // "Models.Models.PlotHelicopterGarageDestroy.PlotHelicopterGarageDestroyModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "PlotHelicopterGarageModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Destroy = 0x48F9FB0; // "public void Destroy(WorldEntitiesModel worldEntitiesModel)"
        }
    } // namespace PlotHelicopterGarageDestroyModel

    namespace PlotHelicopterGarageInitializeModel { // "Models.Models.PlotHelicopterGarageInitialize.PlotHelicopterGarageInitializeModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "PlotHelicopterGarageModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Initialize = 0x48FA3D0; // "public void Initialize(WorldEntitiesModel worldEntitiesModel, LocationGarageDescription<PlotHelicopterSlotDescription> garageDescription)"
        }
    } // namespace PlotHelicopterGarageInitializeModel

    namespace PlotHelicopterGarageModel { // "Models.Models.PlotHelicopterGarage.PlotHelicopterGarageModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t helicopters = 0x10; // "Dictionary<PlotHelicopterSlotDescription, PlotHelicopterModel>"
            inline constexpr std::uintptr_t DescriptionModel = 0x18; // "DescriptionModel<LocationGarageDescription<PlotHelicopterSlotDescription>>"
            inline constexpr std::uintptr_t InitializeModel = 0x20; // "PlotHelicopterGarageInitializeModel"
            inline constexpr std::uintptr_t DestroyModel = 0x28; // "PlotHelicopterGarageDestroyModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Helicopters = 0x7EC6B0; // "public IReadOnlyDictionary<PlotHelicopterSlotDescription, PlotHelicopterModel> get_Helicopters()"
        }
    } // namespace PlotHelicopterGarageModel

    namespace PlotHelicopterInitializeModel { // "Models.Models.PlotHelicopterInitialize.PlotHelicopterInitializeModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "PlotHelicopterModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Initialize = 0x48FAC40; // "public void Initialize(WorldEntitiesModel worldEntitiesModel, LocationVehicleSlotDescription<PlotHelicopterSlotDescription> locationVehicleSlotDescription)"
        }
    } // namespace PlotHelicopterInitializeModel

    namespace PlotHelicopterModel { // "Models.Models.PlotHelicopter.PlotHelicopterModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t InitializeModel = 0x60; // "PlotHelicopterInitializeModel"
            inline constexpr std::uintptr_t DestroyModel = 0x68; // "PlotHelicopterDestroyModel"
        }
    } // namespace PlotHelicopterModel

    namespace PlotHelicopterModelAdapter { // "Models.Models.PlotVehicleModelAdapter.PlotHelicopterModelAdapter (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t GetVehicleGarageSlotColliders = 0x48FAD30; // "public CollidersDescription GetVehicleGarageSlotColliders(HelicopterDescription vehicle)"
            inline constexpr std::uintptr_t GetTrunkLocalPosition = 0x48FACF0; // "public Vector3 GetTrunkLocalPosition(HelicopterDescription vehicle)"
            inline constexpr std::uintptr_t GetVerticalDistanceFromPivotToGroundInRest = 0x48FAD50; // "public float GetVerticalDistanceFromPivotToGroundInRest(HelicopterDescription vehicle)"
            inline constexpr std::uintptr_t HasTrunk = 0x48FAD70; // "public bool HasTrunk(HelicopterDescription vehicle)"
        }
    } // namespace PlotHelicopterModelAdapter

    namespace PlotHelicopterSlotDescription { // "Models.References.PlotHelicopterSlotDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x81816D0; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t enum_id = 0x0; // "Enum<PlotHelicopterSlotDescription>"
            inline constexpr std::uintptr_t Slot0 = 0x8; // "PlotHelicopterSlotDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Enum = 0x4051050; // "public static ReadOnlyEnum<PlotHelicopterSlotDescription> get_Enum()"
        }
    } // namespace PlotHelicopterSlotDescription

    namespace PlotHelicopterTrunkEntityDataBuilder { // "Models.Replication.EntityDataBuilder.PlotHelicopterTrunkEntityDataBuilder (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t paramsModel = 0x10; // "EntitiesParamsModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Build = 0x44C13C0; // "public IData Build(int id)"
        }
    } // namespace PlotHelicopterTrunkEntityDataBuilder

    namespace PlotHelicopterTrunkEntityStreamReader { // "Models.Replication.EntityStreamReader.PlotHelicopterTrunkEntityStreamReader (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t paramsModel = 0x20; // "EntitiesParamsModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t TryReadParams = 0x44C1460; // "protected override bool TryReadParams(int entityId, IBinaryReadStream stream)"
        }
    } // namespace PlotHelicopterTrunkEntityStreamReader

    namespace PlotMainBuildingVehicleSlotUpdater { // "ClientCore.Builder.PlotMainBuildingVehicleSlotUpdater (Client.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t mainBuildingModel = 0x10; // "IMainBuildingModel"
            inline constexpr std::uintptr_t worldEntitiesModel = 0x18; // "WorldEntitiesModel"
            inline constexpr std::uintptr_t updater = 0x20; // "List<IClientUpdater>"
            inline constexpr std::uintptr_t description = 0x28; // "LocationMainBuildingDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xE8A4C0; // "public void Update()"
            inline constexpr std::uintptr_t Create = 0xE8A100; // "private void Create()"
            inline constexpr std::uintptr_t Dispose = 0xE8A460; // "private void Dispose()"
        }
    } // namespace PlotMainBuildingVehicleSlotUpdater

    namespace PlotOutbuildingVehicleSlotUpdater { // "ClientCore.Builder.PlotOutbuildingVehicleSlotUpdater (Client.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t worldEntitiesModel = 0x10; // "WorldEntitiesModel"
            inline constexpr std::uintptr_t updater = 0x18; // "List<IClientUpdater>"
            inline constexpr std::uintptr_t description = 0x20; // "LocationOutbuildingDescription"
            inline constexpr std::uintptr_t outbuildingModel = 0x28; // "OutbuildingModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xE8AEF0; // "public void Update()"
            inline constexpr std::uintptr_t Create = 0xE8A8C0; // "private void Create()"
            inline constexpr std::uintptr_t Dispose = 0xE8AE90; // "private void Dispose()"
        }
    } // namespace PlotOutbuildingVehicleSlotUpdater

    namespace PlotRentCarMessage { // "Models.Messages.Vehicle.Car.PlotRentCarMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t garageEntityId = 0x20; // "BattleEntityIdData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_GarageEntityId = 0x4A0C190; // "public int get_GarageEntityId()"
            inline constexpr std::uintptr_t get_Type = 0x4A0C1D0; // "public override string get_Type()"
        }
    } // namespace PlotRentCarMessage

    namespace PlotVehicleDescription { // "Models.References.Plot.PlotVehicleDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x8186010; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t ChangePlotVehicleExpiringResource = 0x0; // "ExpiringResourceDescription"
        }
    } // namespace PlotVehicleDescription

    namespace PlotVehicleGarageExtensions { // "Models.Utils.Extensions.Builder.PlotVehicleGarageExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t AreAllVehicleGaragesEmpty = 0x3C9B8A0; // "public static bool AreAllVehicleGaragesEmpty(PlotModel plotModel, VehicleTypeDescription vehicleType)"
            inline constexpr std::uintptr_t AreAllVehicleGaragesEmpty_2 = 0x3C9BA10; // "private static bool AreAllVehicleGaragesEmpty(IEnumerable<IPlotVehicleModel> plotVehicles)"
            inline constexpr std::uintptr_t TryGetPlotFirstEmptyVehicleSlot = 0x3C9BED0; // "public static bool TryGetPlotFirstEmptyVehicleSlot(PlotModel plotModel, VehicleTypeDescription vehicleType, out Vector3 spawnPosition, out Quaternion spawnOrientation, out float dirtyLevel)"
            inline constexpr std::uintptr_t TryGetPlotFirstEmptyVehicleSlot_TPlotVehicleSlotDescription_TVehicleDescription_inst_1 = 0x112C590; // "PlotVehicleGarageExtensions.TryGetPlotFirstEmptyVehicleSlot<object, object>"
            inline constexpr std::uintptr_t TryGetPlotFirstEmptyVehicleSlot_TPlotVehicleSlotDescription_TVehicleDescription_inst_2 = 0x112C230; // "PlotVehicleGarageExtensions.TryGetPlotFirstEmptyVehicleSlot<__Il2CppFullySharedGenericType, __Il2CppFullySharedGenericType>"
            inline constexpr std::uintptr_t GetRentCarSpawnPointAndDirtyLevel = 0x3C9BB80; // "public static ValueTuple<OrientedPoint, float> GetRentCarSpawnPointAndDirtyLevel(PlotCarGarageModel carGarageModel)"
        }
    } // namespace PlotVehicleGarageExtensions

    namespace PlotVehicleModelAdapters { // "Models.Models.PlotVehicleModelAdapter.PlotVehicleModelAdapters (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x81861A8; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t Car = 0x0; // "PlotCarModelAdapter"
            inline constexpr std::uintptr_t Helicopter = 0x8; // "PlotHelicopterModelAdapter"
        }
    } // namespace PlotVehicleModelAdapters

    namespace PlotVehicleTrunkEntityData { // "Models.Data.Vehicle.PlotVehicleTrunkEntityData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Description = 0x20; // "VehicleTrunkDescription"
            inline constexpr std::uintptr_t Inventory = 0x28; // "InventoryData"
            inline constexpr std::uintptr_t InventoryRevealId = 0x30; // "InventoryRevealIdData"
            inline constexpr std::uintptr_t CargoInventory = 0x38; // "CargoInventoryData"
            inline constexpr std::uintptr_t InventoryAdditionalLines = 0x40; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t CargoInventoryAdditionalSlots = 0x48; // "IPrimitiveData<int>"
        }
    } // namespace PlotVehicleTrunkEntityData

    namespace PlotVehicleTrunkEntityModel { // "Game.Battle.EntityModel.PlotVehicleTrunk.Models.PlotVehicleTrunkEntityModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ServerModel = 0x18; // "PlotVehicleTrunkModel"
            inline constexpr std::uintptr_t BusySlotsModel = 0x20; // "BusySlotsModel"
            inline constexpr std::uintptr_t ChangedSlotsInventoryModel = 0x28; // "ChangedSlotsInventoryModel"
            inline constexpr std::uintptr_t InventoriesModel = 0x30; // "VehicleTrunkInventoriesModel"
        }
    } // namespace PlotVehicleTrunkEntityModel

    namespace PlotVehicleTrunkExtensions { // "Models.Utils.Extensions.Vehicles.PlotVehicleTrunkExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t CalculateAssetsValues = 0x3966F30; // "public static void CalculateAssetsValues(RealmAssetsValuesCounter counter, int vehicleEntityId, WorldEntitiesModel worldEntitiesModel)"
        }
    } // namespace PlotVehicleTrunkExtensions

    namespace PlotVehicleTrunkModel { // "Models.Models.PlotVehicleTrunk.PlotVehicleTrunkModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Id = 0x10; // "int"
            inline constexpr std::uintptr_t InventoryAdditionalLines = 0x18; // "IPrimitiveModel<int>"
            inline constexpr std::uintptr_t Inventory = 0x20; // "IInventoryModel"
            inline constexpr std::uintptr_t InventoryRevealIdModel = 0x28; // "InventoryRevealIdModel"
            inline constexpr std::uintptr_t CargoInventoryAdditionalSlots = 0x30; // "IPrimitiveModel<int>"
            inline constexpr std::uintptr_t CargoInventoryModel = 0x38; // "CargoInventoryModel"
        }
    } // namespace PlotVehicleTrunkModel

    namespace PoliceCarTrunkDescription { // "Models.References.Vehicle.Trunk.PoliceCarTrunkDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t CarTrunkFunc = 0x20; // "Func<CarTrunkDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_CarTrunk = 0x9D6230; // "public CarTrunkDescription get_CarTrunk()"
        }
    } // namespace PoliceCarTrunkDescription

    namespace PoliceRadioCarUpgradeReadAdapter { // "Models.Utils.Adapters.CarUpgradeAdapter.PoliceRadioCarUpgradeReadAdapter (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t TryFromItem = 0x3C9C090; // "public bool TryFromItem(InventoryItemDescription item, out PoliceRadioCarUpgradeDescription value)"
            inline constexpr std::uintptr_t TryGetUpgradeSlot = 0x3C9C0D0; // "public bool TryGetUpgradeSlot(CarUpgradesSlotsModel carUpgradesSlotsModel, int slotIndex, CarDescription carDescription, out IPrimitiveModel<PoliceRadioCarUpgradeDescription> slotModel)"
            inline constexpr std::uintptr_t CheckUnsetUpgrade = 0x7D5050; // "public bool CheckUnsetUpgrade(int entityId, IPrimitiveModel<PoliceRadioCarUpgradeDescription> slotModel)"
            inline constexpr std::uintptr_t CheckSwap = 0x7D5050; // "public bool CheckSwap(int entityId, IPrimitiveModel<PoliceRadioCarUpgradeDescription> slotModel, PoliceRadioCarUpgradeDescription upgradeDescription)"
        }
    } // namespace PoliceRadioCarUpgradeReadAdapter

    namespace PredictVehicleEnterSystem { // "Models.Systems.PredictVehicleEnterSystem (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x4105C80; // "protected override void Tick(ITick tick)"
        }
    } // namespace PredictVehicleEnterSystem

    namespace PredictVehicleLeaveSystem { // "Models.Systems.PredictVehicleLeaveSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t predictionExtraTimeModel = 0x38; // "PredictionExtraTimeModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x4105D90; // "protected override void Tick(ITick tick)"
        }
    } // namespace PredictVehicleLeaveSystem

    namespace PresentedObject_Car { // "Game.Battle.PopUpPresentationDialog.PresentedObject.Car (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Description = 0x18; // "CarDescription"
        }
    } // namespace PresentedObject_Car

    namespace PresentedObject_Helicopter { // "Game.Battle.PopUpPresentationDialog.PresentedObject.Helicopter (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Description = 0x18; // "HelicopterDescription"
        }
    } // namespace PresentedObject_Helicopter

    namespace RentCarMessage { // "Models.Messages.Vehicle.Car.RentCarMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t vehicleSpawnerEntityId = 0x20; // "BattleEntityIdData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_VehicleSpawnerEntityId = 0x4A0D450; // "public int get_VehicleSpawnerEntityId()"
            inline constexpr std::uintptr_t get_Type = 0x4A0D420; // "public override string get_Type()"
        }
    } // namespace RentCarMessage

    namespace RouletteWheelView { // "Game.Battle.EntityModel.Roulette.RouletteWheelView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t trigger = 0x20; // "int"
            inline constexpr std::uintptr_t randomIndex = 0x24; // "int"
            inline constexpr std::uintptr_t BallNormalizedShift = 0x28; // "float"
            inline constexpr std::uintptr_t BallContainerForShift = 0x30; // "Transform"
            inline constexpr std::uintptr_t wheelAnimator = 0x38; // "Animator"
            inline constexpr std::uintptr_t AnimationsCount = 0x40; // "int"
            inline constexpr std::uintptr_t wheelNumbers = 0x48; // "List<int>"
            inline constexpr std::uintptr_t SoundEventPosted = 0x50; // "Action<string>"
            inline constexpr std::uintptr_t fromShift = 0x58; // "float"
            inline constexpr std::uintptr_t toShift = 0x5C; // "float"
            inline constexpr std::uintptr_t lastShift = 0x60; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC16770; // "private void Update()"
            inline constexpr std::uintptr_t RollWheel = 0xC16590; // "public void RollWheel(int winningNumber, int animationIndex)"
        }
    } // namespace RouletteWheelView

    namespace RouletteWheelViewUpdater { // "Game.Battle.EntityModel.Roulette.RouletteWheelViewUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "RouletteModel"
            inline constexpr std::uintptr_t view = 0x18; // "RouletteWheelView"
            inline constexpr std::uintptr_t soundEmitter = 0x20; // "SoundEmitter"
            inline constexpr std::uintptr_t sounds = 0x28; // "Dictionary<string, Event>"
            inline constexpr std::uintptr_t lastPhase = 0x30; // "RoulettePhaseDescription"
            inline constexpr std::uintptr_t phaseSumDuration = 0x38; // "long"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC15F70; // "public void Update()"
            inline constexpr std::uintptr_t OnSoundEventPosted = 0xC15CF0; // "private void OnSoundEventPosted(string eventKey)"
        }
    } // namespace RouletteWheelViewUpdater

    namespace ScopesLoadingUpdater { // "Game.Battle.Entities.Vehicles.Updaters.ScopesLoadingUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "ScopesLoadingModel"
            inline constexpr std::uintptr_t scopeRefCounts = 0x18; // "Dictionary<ILoadedContentScope, int>"
            inline constexpr std::uintptr_t countLoading = 0x20; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xACB380; // "public void Update()"
            inline constexpr std::uintptr_t UnloadContent = 0xACB2A0; // "private void UnloadContent(ILoadedContentScope viewDescription, bool isLastConsumer)"
            inline constexpr std::uintptr_t LoadContent = 0xACB1D0; // "private void LoadContent(ILoadedContentScope viewDescription)"
        }
    } // namespace ScopesLoadingUpdater

    namespace Seat { // "Game.Battle.Entities.Car.Seat (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t LeftFootIKTarget = 0x0; // "Transform"
            inline constexpr std::uintptr_t RightFootIKTarget = 0x8; // "Transform"
            inline constexpr std::uintptr_t AntiLowSetRoofTarget = 0x10; // "Transform"
            inline constexpr std::uintptr_t AntiLowSetRoofHint = 0x18; // "Transform"
            inline constexpr std::uintptr_t MaskHeightLimit = 0x20; // "Transform"
        }
    } // namespace Seat

    namespace SelectedScrollModel { // "Game.Battle.Cars.Parking.SelectedScrollModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsScrollNext = 0x10; // "bool"
            inline constexpr std::uintptr_t IsScrollPrev = 0x11; // "bool"
            inline constexpr std::uintptr_t SelectedIndex = 0x14; // "int"
        }
    } // namespace SelectedScrollModel

    namespace SetCarSirenEnableMessage { // "Models.Messages.SetCarSirenEnableMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t isEnabled = 0x20; // "IPrimitiveData<bool>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsEnabled = 0x4A0EEA0; // "public bool get_IsEnabled()"
            inline constexpr std::uintptr_t get_Type = 0x4A0EEF0; // "public override string get_Type()"
        }
    } // namespace SetCarSirenEnableMessage

    namespace SkinCenterCarsContext { // "Game.Global.SkinCenter.Context.SkinCenterCarsContext (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t globalModel = 0x10; // "GlobalModel"
            inline constexpr std::uintptr_t dialogModel = 0x18; // "SkinCenterDialogModel"
            inline constexpr std::uintptr_t slotDescription = 0x20; // "CarSlotDescription"
            inline constexpr std::uintptr_t viewDescriptions = 0x28; // "CarSkinViewDescriptions"
            inline constexpr std::uintptr_t model = 0x30; // "TemporaryEnumValue<CarDescription>"
            inline constexpr std::uintptr_t achievementsModel = 0x38; // "AchievementsModel"
            inline constexpr std::uintptr_t CellDescription = 0x40; // "SkinCenterCellSizesViewDescription.CellDescription"
            inline constexpr std::uintptr_t IsClicked = 0x48; // "bool"
            inline constexpr std::uintptr_t IsBeganHover = 0x49; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Cell = 0x36505E0; // "public ISkinCenterCellViewDescription get_Cell()"
            inline constexpr std::uintptr_t get_Rarity = 0x36506E0; // "public RarityItem get_Rarity()"
            inline constexpr std::uintptr_t get_Selected = 0x7EC9F0; // "public bool get_Selected()"
            inline constexpr std::uintptr_t get_Confirmed = 0x7EC9F0; // "public bool get_Confirmed()"
            inline constexpr std::uintptr_t get_IsOwned = 0x7D5050; // "public bool get_IsOwned()"
            inline constexpr std::uintptr_t get_NeedDebt = 0x7EC9F0; // "public bool get_NeedDebt()"
            inline constexpr std::uintptr_t get_Index = 0x7E3AB0; // "public int get_Index()"
            inline constexpr std::uintptr_t get_Name = 0x3650640; // "public LocalizedString get_Name()"
            inline constexpr std::uintptr_t get_HasParts = 0x7EC9F0; // "public bool get_HasParts()"
            inline constexpr std::uintptr_t get_OwnedParts = 0x7E3AB0; // "public int get_OwnedParts()"
            inline constexpr std::uintptr_t get_MaxParts = 0x7E3AB0; // "public int get_MaxParts()"
            inline constexpr std::uintptr_t get_HasCoins = 0x7EC9F0; // "public bool get_HasCoins()"
            inline constexpr std::uintptr_t get_Coins = 0xACDA50; // "public Money get_Coins()"
            inline constexpr std::uintptr_t get_NeedImprisonment = 0x7EC9F0; // "public bool get_NeedImprisonment()"
            inline constexpr std::uintptr_t get_NeedAchievement = 0x7EC9F0; // "public bool get_NeedAchievement()"
            inline constexpr std::uintptr_t get_NeedPack = 0x7EC9F0; // "public bool get_NeedPack()"
            inline constexpr std::uintptr_t get_NeedBattlePass = 0x7EC9F0; // "public bool get_NeedBattlePass()"
            inline constexpr std::uintptr_t get_NewlyUnlockedCount = 0x36506B0; // "public int get_NewlyUnlockedCount()"
            inline constexpr std::uintptr_t GetEmptyIconBySexData = 0x7E3AB0; // "public Sprite GetEmptyIconBySexData(CharacterSexDescription sexData)"
            inline constexpr std::uintptr_t GetIconBySexData = 0x36503D0; // "public Sprite GetIconBySexData(CharacterSexDescription sexData)"
            inline constexpr std::uintptr_t OnSelect = 0x3650470; // "public void OnSelect()"
            inline constexpr std::uintptr_t OnBeginHover = 0x7B3360; // "public void OnBeginHover()"
        }
    } // namespace SkinCenterCarsContext

    namespace SkinCenterDecorativeCarView { // "Game.Battle.Entities.Car.SkinCenterDecorativeCarView (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t CarMaterialView = 0x20; // "CarMaterialView"
            inline constexpr std::uintptr_t CarHeadlightsView = 0x28; // "CarHeadlightsView"
            inline constexpr std::uintptr_t RotatedDetails = 0x30; // "Transform[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Content_ContentWrappers_IComponentContent_ResetOnDisposeContent = 0x3561070; // "private void Content.ContentWrappers.IComponentContent.ResetOnDisposeContent()"
        }
    } // namespace SkinCenterDecorativeCarView

    namespace SkinCenterDecorativeHelicopterView { // "Game.Global.SkinCenter.Scene.SkinCenterDecorativeHelicopterView (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t HelicopterMaterialView = 0x20; // "HelicopterMaterialView"
        }
    } // namespace SkinCenterDecorativeHelicopterView

    namespace SkinCenterHelicopterContext { // "Game.Global.SkinCenter.Context.SkinCenterHelicopterContext (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t globalModel = 0x10; // "GlobalModel"
            inline constexpr std::uintptr_t dialogModel = 0x18; // "SkinCenterDialogModel"
            inline constexpr std::uintptr_t slotDescription = 0x20; // "HelicopterSlotDescription"
            inline constexpr std::uintptr_t viewDescriptions = 0x28; // "HelicopterSkinViewDescriptions"
            inline constexpr std::uintptr_t model = 0x30; // "TemporaryEnumValue<HelicopterDescription>"
            inline constexpr std::uintptr_t CellDescription = 0x38; // "SkinCenterCellSizesViewDescription.CellDescription"
            inline constexpr std::uintptr_t IsClicked = 0x40; // "bool"
            inline constexpr std::uintptr_t IsBeganHover = 0x41; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Cell = 0x3651980; // "public ISkinCenterCellViewDescription get_Cell()"
            inline constexpr std::uintptr_t get_Rarity = 0x3651A50; // "public RarityItem get_Rarity()"
            inline constexpr std::uintptr_t get_Selected = 0x7EC9F0; // "public bool get_Selected()"
            inline constexpr std::uintptr_t get_Confirmed = 0x7EC9F0; // "public bool get_Confirmed()"
            inline constexpr std::uintptr_t get_IsOwned = 0x7D5050; // "public bool get_IsOwned()"
            inline constexpr std::uintptr_t get_NeedDebt = 0x7EC9F0; // "public bool get_NeedDebt()"
            inline constexpr std::uintptr_t get_Index = 0x7E3AB0; // "public int get_Index()"
            inline constexpr std::uintptr_t get_Name = 0x36519E0; // "public LocalizedString get_Name()"
            inline constexpr std::uintptr_t get_HasParts = 0x7EC9F0; // "public bool get_HasParts()"
            inline constexpr std::uintptr_t get_OwnedParts = 0x7E3AB0; // "public int get_OwnedParts()"
            inline constexpr std::uintptr_t get_MaxParts = 0x7E3AB0; // "public int get_MaxParts()"
            inline constexpr std::uintptr_t get_HasCoins = 0x7EC9F0; // "public bool get_HasCoins()"
            inline constexpr std::uintptr_t get_Coins = 0xACDA50; // "public Money get_Coins()"
            inline constexpr std::uintptr_t get_NeedImprisonment = 0x7EC9F0; // "public bool get_NeedImprisonment()"
            inline constexpr std::uintptr_t get_NeedAchievement = 0x7EC9F0; // "public bool get_NeedAchievement()"
            inline constexpr std::uintptr_t get_NeedPack = 0x7EC9F0; // "public bool get_NeedPack()"
            inline constexpr std::uintptr_t get_NeedBattlePass = 0x7EC9F0; // "public bool get_NeedBattlePass()"
            inline constexpr std::uintptr_t get_NewlyUnlockedCount = 0x36506B0; // "public int get_NewlyUnlockedCount()"
            inline constexpr std::uintptr_t GetEmptyIconBySexData = 0x7E3AB0; // "public Sprite GetEmptyIconBySexData(CharacterSexDescription sexData)"
            inline constexpr std::uintptr_t GetIconBySexData = 0x3651800; // "public Sprite GetIconBySexData(CharacterSexDescription sexData)"
            inline constexpr std::uintptr_t OnSelect = 0x36518D0; // "public void OnSelect()"
            inline constexpr std::uintptr_t OnBeginHover = 0x7B3360; // "public void OnBeginHover()"
        }
    } // namespace SkinCenterHelicopterContext

    namespace SkinCenterRequestingVehicleTabModelUpdater { // "Game.Realm.SkinCenter.SkinCenterRequestingVehicleTabModelUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dialogModel = 0x10; // "SkinCenterDialogModel"
            inline constexpr std::uintptr_t skinCenterSceneModel = 0x18; // "SkinCenterSceneModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x35430D0; // "public void Update()"
        }
    } // namespace SkinCenterRequestingVehicleTabModelUpdater

    namespace SkinCenterTab_Helicopter { // "Game.Global.UI.SkinCenter.SkinCenterTab.Helicopter (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Value = 0x10; // "HelicopterSlotDescription"
        }
    } // namespace SkinCenterTab_Helicopter

    namespace SkinCenterVehicleCameraStateViewUpdater { // "Game.Global.SkinCenter.Scene.SkinCenterVehicleCameraStateViewUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t skinCenterView = 0x10; // "SkinCenterSceneView"
            inline constexpr std::uintptr_t skinCenterSceneModel = 0x18; // "SkinCenterSceneModel"
            inline constexpr std::uintptr_t carSkinViewDescriptions = 0x20; // "CarSkinViewDescriptions"
            inline constexpr std::uintptr_t helicopterSkinViewDescriptions = 0x28; // "HelicopterSkinViewDescriptions"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x3652C70; // "public void Update()"
            inline constexpr std::uintptr_t GetCameraType = 0x3652B60; // "private bool GetCameraType(out SkinCenterVehicleCameraType cameraType)"
        }
    } // namespace SkinCenterVehicleCameraStateViewUpdater

    namespace SkinCenterVehicleRotationResetModelUpdater { // "Game.Global.SkinCenter.UI.ModelUpdaters.SkinCenterVehicleRotationResetModelUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dialogModel = 0x10; // "SkinCenterDialogModel"
            inline constexpr std::uintptr_t previewModel = 0x18; // "SkinCenterShopPackPreviewModel"
            inline constexpr std::uintptr_t rotationModel = 0x20; // "CustomizeSceneRotationModel"
            inline constexpr std::uintptr_t selectedVehicleId = 0x28; // "string"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x363DE10; // "public void Update()"
            inline constexpr std::uintptr_t GetPackPreviewVehicleId = 0x363DD30; // "private string GetPackPreviewVehicleId()"
        }
    } // namespace SkinCenterVehicleRotationResetModelUpdater

    namespace SpawnCarClearWaterUpdater { // "Game.Battle.EntityModel.Car.SpawnCarClearWaterUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleEntitiesModel = 0x10; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t serverModel = 0x18; // "CarModel"
            inline constexpr std::uintptr_t carTimeOffset = 0x20; // "TimelineTimeOffsetModel"
            inline constexpr std::uintptr_t carSoakingView = 0x28; // "CarSoakingView"
            inline constexpr std::uintptr_t last = 0x30; // "long"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xCC4B20; // "public void Update()"
        }
    } // namespace SpawnCarClearWaterUpdater

    namespace SpawnCarMessage { // "Models.Messages.SpawnCarMessage (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x4A110E0; // "public override string get_Type()"
        }
    } // namespace SpawnCarMessage

    namespace SpawnCarUpdater { // "Game.Battle.SpawnCarUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t roomConnections = 0x10; // "IRoomConnections"
            inline constexpr std::uintptr_t battleModel = 0x18; // "BattleModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x20; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t cheatSpawnCarModel = 0x28; // "CheatSpawnCarModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC54990; // "public void Update()"
            inline constexpr std::uintptr_t CheatSpawnCar = 0xC548E0; // "private void CheatSpawnCar()"
        }
    } // namespace SpawnCarUpdater

    namespace SpawnHelicopterMessage { // "Models.Messages.SpawnHelicopterMessage (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x4A11110; // "public override string get_Type()"
        }
    } // namespace SpawnHelicopterMessage

    namespace SpawnHelicopterUpdater { // "Game.Battle.SpawnHelicopterUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t roomConnections = 0x10; // "IRoomConnections"
            inline constexpr std::uintptr_t battleModel = 0x18; // "BattleModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x20; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t cheatSpawnHelicopterModel = 0x28; // "CheatSpawnHelicopterModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC54C20; // "public void Update()"
            inline constexpr std::uintptr_t CheatSpawnHelicopter = 0xC54B70; // "private void CheatSpawnHelicopter()"
        }
    } // namespace SpawnHelicopterUpdater

    namespace SpawnPlotVehicleMessage { // "Models.Messages.SpawnPlotVehicleMessage (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x4A11140; // "public override string get_Type()"
        }
    } // namespace SpawnPlotVehicleMessage

    namespace SpawnVehicleMessage { // "Models.Messages.SpawnVehicleMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t entityId = 0x20; // "IPrimitiveData<int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_EntityId = 0x4A11210; // "public int get_EntityId()"
        }
    } // namespace SpawnVehicleMessage

    namespace StaticCarUpdater { // "Game.Battle.EntityModel.VehicleBench.StaticCarUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t plotCarModel = 0x10; // "IPlotCarModel"
            inline constexpr std::uintptr_t globalModel = 0x18; // "GlobalModel"
            inline constexpr std::uintptr_t battleModel = 0x20; // "BattleModel"
            inline constexpr std::uintptr_t battleScreenContent = 0x28; // "BattleScreenContent"
            inline constexpr std::uintptr_t globalScreenContent = 0x30; // "GlobalScreenContent"
            inline constexpr std::uintptr_t inputActions = 0x38; // "InputActions"
            inline constexpr std::uintptr_t targetSubsystem = 0x40; // "ITargetSubsystem"
            inline constexpr std::uintptr_t roomConnectionsBattle = 0x48; // "IRoomConnection"
            inline constexpr std::uintptr_t plotModel = 0x50; // "PlotModel"
            inline constexpr std::uintptr_t collectionTableDescriptionModel = 0x58; // "ICollectionTableDescriptionModel"
            inline constexpr std::uintptr_t vehiclesLoadingModel = 0x60; // "ScopesLoadingModel"
            inline constexpr std::uintptr_t collectionTableDescription = 0x68; // "CollectionTableDescription"
            inline constexpr std::uintptr_t registerDisposable = 0x70; // "IRegisterDisposable"
            inline constexpr std::uintptr_t isActive = 0x78; // "bool"
            inline constexpr std::uintptr_t vehicleDescription = 0x80; // "CarDescription"
            inline constexpr std::uintptr_t updater = 0x88; // "IUpdater"
            inline constexpr std::uintptr_t isPlaySound = 0x90; // "bool"
            inline constexpr std::uintptr_t needPlaySound = 0x91; // "bool"
            inline constexpr std::uintptr_t needCreateMarker = 0x92; // "bool"
            inline constexpr std::uintptr_t switchCarLayer = 0x98; // "IDisposable"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC32710; // "public void Update()"
            inline constexpr std::uintptr_t InitializeStaticCarUpdater = 0xC2FF40; // "private void InitializeStaticCarUpdater()"
            inline constexpr std::uintptr_t UnregisterVehicleColliders = 0xC32590; // "private void UnregisterVehicleColliders(HashSet<Collider> viewVehicleColliders)"
            inline constexpr std::uintptr_t RegisterVehicleColliders = 0xC31A50; // "private void RegisterVehicleColliders(VehicleEntityView editorVehicleEntity)"
            inline constexpr std::uintptr_t SetWheelsPositions = 0xC31C50; // "private void SetWheelsPositions(IPlotCarModel plotCarModel, CarEntityView view, CarViewDescription viewDescription)"
            inline constexpr std::uintptr_t IsActive = 0xC318C0; // "private bool IsActive()"
            inline constexpr std::uintptr_t PlaySound = 0xC31940; // "private static void PlaySound(GameObject vehicleSoundEmitter, Event spawnEvent, IRegisterDisposable registerDisposable)"
        }
    } // namespace StaticCarUpdater

    namespace StaticHelicopterUpdater { // "Game.Battle.Entities.Plot.VehicleBench.StaticVehicle.Helicopter.StaticHelicopterUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t plotHelicopterModel = 0x10; // "PlotHelicopterModel"
            inline constexpr std::uintptr_t globalModel = 0x18; // "GlobalModel"
            inline constexpr std::uintptr_t battleModel = 0x20; // "BattleModel"
            inline constexpr std::uintptr_t battleScreenContent = 0x28; // "BattleScreenContent"
            inline constexpr std::uintptr_t globalScreenContent = 0x30; // "GlobalScreenContent"
            inline constexpr std::uintptr_t inputActions = 0x38; // "InputActions"
            inline constexpr std::uintptr_t targetSubsystem = 0x40; // "ITargetSubsystem"
            inline constexpr std::uintptr_t locationScreenViewModel = 0x48; // "LocationScreenViewModel"
            inline constexpr std::uintptr_t roomConnectionsBattle = 0x50; // "IRoomConnection"
            inline constexpr std::uintptr_t plotModel = 0x58; // "PlotModel"
            inline constexpr std::uintptr_t collectionTableDescriptionModel = 0x60; // "ICollectionTableDescriptionModel"
            inline constexpr std::uintptr_t vehiclesLoadingModel = 0x68; // "ScopesLoadingModel"
            inline constexpr std::uintptr_t updater = 0x70; // "IUpdater"
            inline constexpr std::uintptr_t collectionTableDescription = 0x78; // "CollectionTableDescription"
            inline constexpr std::uintptr_t registerDisposable = 0x80; // "IRegisterDisposable"
            inline constexpr std::uintptr_t isActive = 0x88; // "bool"
            inline constexpr std::uintptr_t vehicleDescription = 0x90; // "HelicopterDescription"
            inline constexpr std::uintptr_t isPlaySound = 0x98; // "bool"
            inline constexpr std::uintptr_t needPlaySound = 0x99; // "bool"
            inline constexpr std::uintptr_t needCreateMarker = 0x9A; // "bool"
            inline constexpr std::uintptr_t switchHelicopterLayer = 0xA0; // "IDisposable"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xAFDD40; // "public void Update()"
            inline constexpr std::uintptr_t InitializeStaticHelicopterUpdater = 0xAFC6C0; // "private void InitializeStaticHelicopterUpdater()"
            inline constexpr std::uintptr_t PlaySound = 0xAFD840; // "private static void PlaySound(GameObject vehicleSoundEmitter, Event spawnEvent, IRegisterDisposable registerDisposable)"
            inline constexpr std::uintptr_t UnregisterVehicleColliders = 0xAFDBC0; // "private void UnregisterVehicleColliders(HashSet<Collider> viewVehicleColliders)"
            inline constexpr std::uintptr_t RegisterVehicleColliders = 0xAFD950; // "private void RegisterVehicleColliders(VehicleEntityView editorVehicleEntity)"
        }
    } // namespace StaticHelicopterUpdater

    namespace SteeringRackCarUpgradeReadAdapter { // "Models.Utils.Adapters.CarUpgradeAdapter.SteeringRackCarUpgradeReadAdapter (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t TryFromItem = 0x3CA0D50; // "public bool TryFromItem(InventoryItemDescription item, out SteeringRackCarUpgradeDescription value)"
            inline constexpr std::uintptr_t TryGetUpgradeSlot = 0x3CA0D90; // "public bool TryGetUpgradeSlot(CarUpgradesSlotsModel carUpgradesSlotsModel, int slotIndex, CarDescription carDescription, out IPrimitiveModel<SteeringRackCarUpgradeDescription> slotModel)"
            inline constexpr std::uintptr_t CheckUnsetUpgrade = 0x7D5050; // "public bool CheckUnsetUpgrade(int entityId, IPrimitiveModel<SteeringRackCarUpgradeDescription> slotModel)"
            inline constexpr std::uintptr_t CheckSwap = 0x7D5050; // "public bool CheckSwap(int entityId, IPrimitiveModel<SteeringRackCarUpgradeDescription> slotModel, SteeringRackCarUpgradeDescription upgradeDescription)"
        }
    } // namespace SteeringRackCarUpgradeReadAdapter

    namespace SuspensionCarUpgradeReadAdapter { // "Models.Utils.Adapters.CarUpgradeAdapter.SuspensionCarUpgradeReadAdapter (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t TryFromItem = 0x3CA1280; // "public bool TryFromItem(InventoryItemDescription item, out SuspensionCarUpgradeDescription value)"
            inline constexpr std::uintptr_t TryGetUpgradeSlot = 0x3CA12C0; // "public bool TryGetUpgradeSlot(CarUpgradesSlotsModel carUpgradesSlotsModel, int slotIndex, CarDescription carDescription, out IPrimitiveModel<SuspensionCarUpgradeDescription> slotModel)"
            inline constexpr std::uintptr_t CheckUnsetUpgrade = 0x7D5050; // "public bool CheckUnsetUpgrade(int entityId, IPrimitiveModel<SuspensionCarUpgradeDescription> slotModel)"
            inline constexpr std::uintptr_t CheckSwap = 0x7D5050; // "public bool CheckSwap(int entityId, IPrimitiveModel<SuspensionCarUpgradeDescription> slotModel, SuspensionCarUpgradeDescription upgradeDescription)"
        }
    } // namespace SuspensionCarUpgradeReadAdapter

    namespace SwapBetweenCarUpgradesMessage { // "Models.Messages.Vehicle.Car.SwapBetweenCarUpgradesMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t entityId = 0x20; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t upgradeType = 0x28; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t firstSlotIndex = 0x30; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t secondSlotIndex = 0x38; // "IPrimitiveData<int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_EntityId = 0x4A120D0; // "public int get_EntityId()"
            inline constexpr std::uintptr_t get_UpgradeType = 0x4A121F0; // "public CarUpgradeType get_UpgradeType()"
            inline constexpr std::uintptr_t get_FirstSlotIndex = 0x4A12120; // "public int get_FirstSlotIndex()"
            inline constexpr std::uintptr_t get_SecondSlotIndex = 0x4A12170; // "public int get_SecondSlotIndex()"
            inline constexpr std::uintptr_t get_Type = 0x4A121C0; // "public override string get_Type()"
        }
    } // namespace SwapBetweenCarUpgradesMessage

    namespace SwapInventoryWithCarUpgradesMessage { // "Models.Messages.Vehicle.Car.SwapInventoryWithCarUpgradesMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t fromInventorySlot = 0x20; // "IPrimitiveData<InventorySlotDescription>"
            inline constexpr std::uintptr_t toInventorySlot = 0x28; // "IPrimitiveData<InventorySlotDescription>"
            inline constexpr std::uintptr_t entityId = 0x30; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t upgradeType = 0x38; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t slotIndex = 0x40; // "IPrimitiveData<int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_FromInventorySlot = 0x4A12B10; // "public InventorySlotDescription get_FromInventorySlot()"
            inline constexpr std::uintptr_t get_ToInventorySlot = 0x4A12BB0; // "public InventorySlotDescription get_ToInventorySlot()"
            inline constexpr std::uintptr_t get_EntityId = 0x4A12AC0; // "public int get_EntityId()"
            inline constexpr std::uintptr_t get_UpgradeType = 0x4A12C30; // "public CarUpgradeType get_UpgradeType()"
            inline constexpr std::uintptr_t get_SlotIndex = 0x4A12B60; // "public int get_SlotIndex()"
            inline constexpr std::uintptr_t get_Type = 0x4A12C00; // "public override string get_Type()"
        }
    } // namespace SwapInventoryWithCarUpgradesMessage

    namespace TeleportVehicleSystem { // "Models.Systems.TeleportVehicleSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t vehicles = 0x38; // "VehiclesWorldModel"
            inline constexpr std::uintptr_t teleportWorldModel = 0x40; // "TeleportWorldModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x4367670; // "protected override void Tick(ITick tick)"
            inline constexpr std::uintptr_t HandleCarTeleport = 0x4367620; // "private void HandleCarTeleport(CarModel car)"
        }
    } // namespace TeleportVehicleSystem

    namespace ToggleTargetInVehicleUpdater { // "Game.Battle.Entities.Player.Vehicle.Updaters.ToggleTargetInVehicleUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t inVehicleModel = 0x10; // "InVehicleModel"
            inline constexpr std::uintptr_t targetModel = 0x18; // "TargetModel"
            inline constexpr std::uintptr_t inVehicleTargetModel = 0x20; // "TargetModel"
            inline constexpr std::uintptr_t isInVehicle = 0x28; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB16580; // "public void Update()"
        }
    } // namespace ToggleTargetInVehicleUpdater

    namespace TouchCarLookInputUpdater { // "Game.Battle.Inputs.Updaters.Touch.TouchCarLookInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t playerRotationInput = 0x10; // "PlayerRotationInputModel"
            inline constexpr std::uintptr_t topThreshold = 0x18; // "float"
            inline constexpr std::uintptr_t bottomThreshold = 0x1C; // "float"
            inline constexpr std::uintptr_t sensitivityModel = 0x20; // "SensitivityModel"
            inline constexpr std::uintptr_t lookView = 0x28; // "LookView"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x30; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t cameraFollow = 0x38; // "Cinemachine3rdPersonFollow"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA9B340; // "public void Update()"
        }
    } // namespace TouchCarLookInputUpdater

    namespace TouchHelicopterAlternativeInputUpdater { // "Game.Battle.Inputs.Updaters.Touch.TouchHelicopterAlternativeInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t helicopterControlView = 0x10; // "HelicopterControlView"
            inline constexpr std::uintptr_t battleInputModel = 0x18; // "BattleInputModel"
            inline constexpr std::uintptr_t helicopterInput = 0x20; // "IChangeBufferValue<HelicopterInputSetting>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA9B8F0; // "public void Update()"
        }
    } // namespace TouchHelicopterAlternativeInputUpdater

    namespace TouchHelicopterAlternativeLookInputUpdater { // "Game.Battle.Inputs.Updaters.Touch.TouchHelicopterAlternativeLookInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t playerRotationInput = 0x10; // "PlayerRotationInputModel"
            inline constexpr std::uintptr_t topThreshold = 0x18; // "float"
            inline constexpr std::uintptr_t bottomThreshold = 0x1C; // "float"
            inline constexpr std::uintptr_t sensitivityModel = 0x20; // "SensitivityModel"
            inline constexpr std::uintptr_t lookView = 0x28; // "LookView"
            inline constexpr std::uintptr_t helicopterInput = 0x30; // "IChangeBufferValue<HelicopterInputSetting>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA9BBF0; // "public void Update()"
        }
    } // namespace TouchHelicopterAlternativeLookInputUpdater

    namespace TouchHelicopterStandardInputUpdater { // "Game.Battle.Inputs.Updaters.Touch.TouchHelicopterStandardInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t helicopterControlView = 0x10; // "HelicopterControlView"
            inline constexpr std::uintptr_t battleInputModel = 0x18; // "BattleInputModel"
            inline constexpr std::uintptr_t helicopterInput = 0x20; // "IChangeBufferValue<HelicopterInputSetting>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA9BE20; // "public void Update()"
        }
    } // namespace TouchHelicopterStandardInputUpdater

    namespace TouchHelicopterStandardLookInputUpdater { // "Game.Battle.Inputs.Updaters.Touch.TouchHelicopterStandardLookInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t playerRotationInput = 0x10; // "PlayerRotationInputModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x18; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t topThreshold = 0x20; // "float"
            inline constexpr std::uintptr_t bottomThreshold = 0x24; // "float"
            inline constexpr std::uintptr_t sensitivityModel = 0x28; // "SensitivityModel"
            inline constexpr std::uintptr_t lookView = 0x30; // "LookView"
            inline constexpr std::uintptr_t helicopterInput = 0x38; // "IChangeBufferValue<HelicopterInputSetting>"
            inline constexpr std::uintptr_t timeLeft = 0x40; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA9C0F0; // "public void Update()"
            inline constexpr std::uintptr_t HandleDefaultLook = 0xA9BF80; // "private void HandleDefaultLook(Vector2 lookInput)"
        }
    } // namespace TouchHelicopterStandardLookInputUpdater

    namespace TouchThirdPersonCarCameraRotationUpdater { // "Game.Battle.EntityModel.Player.TouchThirdPersonCarCameraRotationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleCharacterEntityView = 0x10; // "BattleCharacterEntityView"
            inline constexpr std::uintptr_t lookView = 0x18; // "LookView"
            inline constexpr std::uintptr_t playerCameraViewDescriptions = 0x20; // "PlayerCameraViewDescriptions"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x28; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t rotationInputModel = 0x30; // "PlayerRotationInputModel"
            inline constexpr std::uintptr_t movementInputModel = 0x38; // "PlayerMovementInputModel"
            inline constexpr std::uintptr_t playerInVehicleModel = 0x40; // "PlayerInVehicleModel"
            inline constexpr std::uintptr_t delayTimer = 0x48; // "float"
            inline constexpr std::uintptr_t cachedRotation = 0x4C; // "Quaternion"
            inline constexpr std::uintptr_t cachedCarEntityModel = 0x60; // "CarEntityModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC80870; // "public void Update()"
            inline constexpr std::uintptr_t Reset = 0xC80530; // "private void Reset()"
            inline constexpr std::uintptr_t SetRotation = 0xC80590; // "private void SetRotation(float targetAngleY)"
            inline constexpr std::uintptr_t get_CarInputModel = 0xC80B30; // "private CarDriveInputModel get_CarInputModel()"
        }
    } // namespace TouchThirdPersonCarCameraRotationUpdater

    namespace TriggerCondition_EventSourceEntityIsVehicleWithType { // "Models.Models.Triggers.TriggerCondition.EventSourceEntityIsVehicleWithType (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Type = 0x10; // "VehicleTypeDescription"
        }
    } // namespace TriggerCondition_EventSourceEntityIsVehicleWithType

    namespace TriggerConditionDescription_EventSourceEntityIsVehicleWithType { // "Models.References.Trigger.TriggerConditionDescription.EventSourceEntityIsVehicleWithType (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t TypeFunc = 0x10; // "Func<VehicleTypeDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x1765CB0; // "public VehicleTypeDescription get_Type()"
            inline constexpr std::uintptr_t New = 0x406A030; // "public static TriggerConditionDescription.EventSourceEntityIsVehicleWithType New(VehicleTypeDescription type)"
        }
    } // namespace TriggerConditionDescription_EventSourceEntityIsVehicleWithType

    namespace TriggerEvent_KinematicObjectsControllerTouchedByWheel { // "Models.Models.Triggers.TriggerEvent.KinematicObjectsControllerTouchedByWheel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t KinematicObjectsControllerEntityId = 0x10; // "int"
        }
    } // namespace TriggerEvent_KinematicObjectsControllerTouchedByWheel

    namespace TriggerEventDescription_KinematicObjectsControllerTouchedByWheel { // "Models.References.Trigger.TriggerEventDescription.KinematicObjectsControllerTouchedByWheel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t KinematicObjectsControllerIndex = 0x10; // "int"
        }
    } // namespace TriggerEventDescription_KinematicObjectsControllerTouchedByWheel

    namespace TrunkCargoInventoryCarUpgradeDescription { // "Models.References.Car.Upgrades.TrunkCargoInventoryCarUpgradeDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t AdditionalSlots = 0x30; // "int"
        }
    } // namespace TrunkCargoInventoryCarUpgradeDescription

    namespace TrunkCargoInventoryCarUpgradeReadAdapter { // "Models.Utils.Adapters.CarUpgradeAdapter.TrunkCargoInventoryCarUpgradeReadAdapter (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t worldEntitiesModel = 0x10; // "WorldEntitiesModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t TryFromItem = 0x3CA18D0; // "public bool TryFromItem(InventoryItemDescription item, out TrunkCargoInventoryCarUpgradeDescription value)"
            inline constexpr std::uintptr_t TryGetUpgradeSlot = 0x3CA1910; // "public bool TryGetUpgradeSlot(CarUpgradesSlotsModel carUpgradesSlotsModel, int slotIndex, CarDescription carDescription, out IPrimitiveModel<TrunkCargoInventoryCarUpgradeDescription> slotModel)"
            inline constexpr std::uintptr_t CheckUnsetUpgrade = 0x3CA1660; // "public bool CheckUnsetUpgrade(int entityId, IPrimitiveModel<TrunkCargoInventoryCarUpgradeDescription> slotModel)"
            inline constexpr std::uintptr_t CheckSwap = 0x3CA1510; // "public bool CheckSwap(int entityId, IPrimitiveModel<TrunkCargoInventoryCarUpgradeDescription> slotModel, TrunkCargoInventoryCarUpgradeDescription upgradeDescription)"
            inline constexpr std::uintptr_t GetInventory = 0x3CA1770; // "private void GetInventory(int entityId, out CargoInventoryModel cargoInventoryModel)"
            inline constexpr std::uintptr_t CheckReduceInventory = 0x3CA1460; // "private bool CheckReduceInventory(CargoInventoryModel cargoInventoryModel, int slotsCount)"
        }
    } // namespace TrunkCargoInventoryCarUpgradeReadAdapter

    namespace TrunkDialogUpdater { // "Game.Battle.Trunk.TrunkDialogUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t updaters = 0x20; // "List<IUpdater>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xD963B0; // "public TrunkDialogUpdater Init(CurrentInventoryModel.Trunk currentInventoryModel, GlobalModel globalModel, List<IUpdater> mainInputUpdaters, GlobalScreenContent globalScreenContent, BattleScreenContent battleScreenContent, UpdaterPool updaterPool, Transform canvasParent, BattleModel battleModel, InputActions.BattleActions actions, GlobalUISoundModel uiSoundModel, PersonalNotificationModel notificationModel, PlayerEntityModel player, Camera uiCamera, InteractRaycastModel interactRaycastModel, IRegisterDisposable registerDisposable)"
            inline constexpr std::uintptr_t Dispose = 0xD96350; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0x94CF50; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t SetHeader = 0xD986C0; // "private void SetHeader(int id, string ownerClanTag, string ownerNickname, TrunkDialogView trunkDialogView, IBattleEntitiesModel battleEntitiesModel, CarSkinViewDescriptions carSkinViewDescriptions)"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace TrunkDialogUpdater

    namespace TrunkDialogView { // "Game.Battle.Trunk.TrunkDialogView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t CargoInventoryTabView = 0x38; // "CargoInventoryTabView"
            inline constexpr std::uintptr_t trunkTabsState = 0x40; // "StateElementBase"
            inline constexpr std::uintptr_t itemsCount = 0x48; // "TextLabel<int>"
            inline constexpr std::uintptr_t cargosCount = 0x50; // "TextLabel<int>"
            inline constexpr std::uintptr_t NavigationTabs = 0x58; // "List<ChosenTabView<TrunkDialogView.TrunkTab>>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetItemsCount = 0xD98A70; // "public void SetItemsCount(int count)"
            inline constexpr std::uintptr_t SetCargosCount = 0xD98A10; // "public void SetCargosCount(int count)"
            inline constexpr std::uintptr_t SetTab = 0xD98AD0; // "public void SetTab(TrunkDialogView.TrunkTab tab)"
            inline constexpr std::uintptr_t get_CurrentTab = 0xD98B00; // "public TrunkDialogView.TrunkTab get_CurrentTab()"
        }
    } // namespace TrunkDialogView

    namespace TrunkInventoryCarUpgradeDescription { // "Models.References.Car.Upgrades.TrunkInventoryCarUpgradeDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t AdditionalLines = 0x30; // "int"
        }
    } // namespace TrunkInventoryCarUpgradeDescription

    namespace TrunkInventoryCarUpgradeReadAdapter { // "Models.Utils.Adapters.CarUpgradeAdapter.TrunkInventoryCarUpgradeReadAdapter (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t worldEntitiesModel = 0x10; // "WorldEntitiesModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t TryFromItem = 0x3CA1DE0; // "public bool TryFromItem(InventoryItemDescription item, out TrunkInventoryCarUpgradeDescription value)"
            inline constexpr std::uintptr_t TryGetUpgradeSlot = 0x3CA1E20; // "public bool TryGetUpgradeSlot(CarUpgradesSlotsModel carUpgradesSlotsModel, int slotIndex, CarDescription carDescription, out IPrimitiveModel<TrunkInventoryCarUpgradeDescription> slotModel)"
            inline constexpr std::uintptr_t CheckUnsetUpgrade = 0x3CA1BA0; // "public bool CheckUnsetUpgrade(int entityId, IPrimitiveModel<TrunkInventoryCarUpgradeDescription> slotModel)"
            inline constexpr std::uintptr_t CheckSwap = 0x3CA1AD0; // "public bool CheckSwap(int entityId, IPrimitiveModel<TrunkInventoryCarUpgradeDescription> slotModel, TrunkInventoryCarUpgradeDescription upgradeDescription)"
            inline constexpr std::uintptr_t GetInventory = 0x3CA1C80; // "private void GetInventory(int entityId, out IInventoryModel inventoryModel)"
        }
    } // namespace TrunkInventoryCarUpgradeReadAdapter

    namespace TrunkItemCountViewUpdater { // "Game.Battle.Trunk.TrunkItemCountViewUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t cargoInventoryModel = 0x20; // "CargoInventoryModel"
            inline constexpr std::uintptr_t inventoryModel = 0x28; // "IInventoryModel"
            inline constexpr std::uintptr_t trunkUIView = 0x30; // "TrunkDialogView"
            inline constexpr std::uintptr_t cargosCount = 0x38; // "int"
            inline constexpr std::uintptr_t itemsCount = 0x3C; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xD99070; // "public TrunkItemCountViewUpdater Init(CargoInventoryModel cargoInventoryModel, IInventoryModel inventoryModel, TrunkDialogView trunkUIView)"
            inline constexpr std::uintptr_t Dispose = 0x9F6DA0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xD99170; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t UpdateItems = 0xD992A0; // "private void UpdateItems(int newItemsCount)"
            inline constexpr std::uintptr_t GetItemsCount = 0xD98D00; // "private int GetItemsCount()"
            inline constexpr std::uintptr_t UpdateCargos = 0xD99240; // "private void UpdateCargos(int newCargosCount)"
            inline constexpr std::uintptr_t GetCargosCount = 0xD98B30; // "private int GetCargosCount()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace TrunkItemCountViewUpdater

    namespace TrunkKeyboardInputHandler { // "Game.Battle.Trunk.TrunkKeyboardInputHandler (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t updater = 0x10; // "IUpdater"
            inline constexpr std::uintptr_t baggageInputUpdater = 0x18; // "IUpdater"
            inline constexpr std::uintptr_t cargoInputUpdater = 0x20; // "IUpdater"
            inline constexpr std::uintptr_t trunkDialogView = 0x28; // "KeyboardMouseTrunkDialogView"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xD99300; // "public void Update()"
        }
    } // namespace TrunkKeyboardInputHandler

    namespace TrunkModel { // "Game.Battle.Trunk.TrunkModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Tab = 0x10; // "TrunkDialogView.TrunkTab"
        }
    } // namespace TrunkModel

    namespace TrunkTouchInputHandler { // "Game.Battle.Trunk.TrunkTouchInputHandler (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t updater = 0x10; // "IUpdater"
            inline constexpr std::uintptr_t baggageInputUpdater = 0x18; // "IUpdater"
            inline constexpr std::uintptr_t cargoInputUpdater = 0x20; // "IUpdater"
            inline constexpr std::uintptr_t trunkDialogView = 0x28; // "TouchTrunkDialogView"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xD99B00; // "public void Update()"
        }
    } // namespace TrunkTouchInputHandler

    namespace TrunkViewTabInputUpdater { // "Game.Battle.Trunk.TrunkViewTabInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t entityId = 0x10; // "int"
            inline constexpr std::uintptr_t trunkDialogView = 0x18; // "TrunkDialogView"
            inline constexpr std::uintptr_t inventoryModelsInventoryTabsModel = 0x20; // "InventoryDialogTabsModel"
            inline constexpr std::uintptr_t uiSoundModel = 0x28; // "GlobalUISoundModel"
            inline constexpr std::uintptr_t updater = 0x30; // "IUpdater"
            inline constexpr std::uintptr_t trunkModel = 0x38; // "TrunkModel"
            inline constexpr std::uintptr_t lastTab = 0x40; // "TrunkDialogView.TrunkTab"
        }
        namespace Methods {
            inline constexpr std::uintptr_t OnTabClicked = 0xD9A630; // "private void OnTabClicked(TrunkDialogView.TrunkTab trunkTab)"
            inline constexpr std::uintptr_t Update = 0xD9AAE0; // "public void Update()"
            inline constexpr std::uintptr_t UpdateTabView = 0xD9A830; // "private void UpdateTabView()"
            inline constexpr std::uintptr_t GetImportantTab = 0xD9A230; // "private TrunkDialogView.TrunkTab GetImportantTab(IInventorySlotsModel inventorySlots, CargoInventoryModel cargoInventoryModel)"
            inline constexpr std::uintptr_t UpdateTabActive = 0xD9A6C0; // "private void UpdateTabActive()"
            inline constexpr std::uintptr_t OnBaggageTabClicked = 0xD9A470; // "private void OnBaggageTabClicked()"
            inline constexpr std::uintptr_t OnCargoTabClicked = 0xD9A550; // "private void OnCargoTabClicked()"
            inline constexpr std::uintptr_t SetCurrentTab = 0xD9A650; // "private void SetCurrentTab(TrunkDialogView.TrunkTab tab)"
        }
    } // namespace TrunkViewTabInputUpdater

    namespace TurbochargerCarUpgradeReadAdapter { // "Models.Utils.Adapters.CarUpgradeAdapter.TurbochargerCarUpgradeReadAdapter (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t TryFromItem = 0x3CA1FE0; // "public bool TryFromItem(InventoryItemDescription item, out TurbochargerCarUpgradeDescription value)"
            inline constexpr std::uintptr_t TryGetUpgradeSlot = 0x3CA2020; // "public bool TryGetUpgradeSlot(CarUpgradesSlotsModel carUpgradesSlotsModel, int slotIndex, CarDescription carDescription, out IPrimitiveModel<TurbochargerCarUpgradeDescription> slotModel)"
            inline constexpr std::uintptr_t CheckUnsetUpgrade = 0x7D5050; // "public bool CheckUnsetUpgrade(int entityId, IPrimitiveModel<TurbochargerCarUpgradeDescription> slotModel)"
            inline constexpr std::uintptr_t CheckSwap = 0x7D5050; // "public bool CheckSwap(int entityId, IPrimitiveModel<TurbochargerCarUpgradeDescription> slotModel, TurbochargerCarUpgradeDescription upgradeDescription)"
        }
    } // namespace TurbochargerCarUpgradeReadAdapter

    namespace UnsetCarUpgradeMessage { // "Models.Messages.Vehicle.Car.UnsetCarUpgradeMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t entityId = 0x20; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t upgradeType = 0x28; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t slotIndex = 0x30; // "IPrimitiveData<int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_EntityId = 0x4A142C0; // "public int get_EntityId()"
            inline constexpr std::uintptr_t get_UpgradeType = 0x4A14390; // "public CarUpgradeType get_UpgradeType()"
            inline constexpr std::uintptr_t get_SlotIndex = 0x4A14310; // "public int get_SlotIndex()"
            inline constexpr std::uintptr_t get_Type = 0x4A14360; // "public override string get_Type()"
        }
    } // namespace UnsetCarUpgradeMessage

    namespace UpdateVehicleSleepFromPhysicsSceneSystem { // "Models.Systems.UpdateVehicleSleepFromPhysicsSceneSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsSceneModel = 0x38; // "PhysicsSceneModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x4369670; // "protected override void Tick(ITick tick)"
        }
    } // namespace UpdateVehicleSleepFromPhysicsSceneSystem

    namespace UpdateVehiclesRuntimeModelsUpdater { // "ClientCore.Updaters.UpdateVehiclesRuntimeModelsUpdater (Client.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dataModels = 0x10; // "IDataModels"
            inline constexpr std::uintptr_t updatedEntitiesModel = 0x18; // "IUpdatedEntitiesModel"
            inline constexpr std::uintptr_t cars = 0x20; // "ReadOnly.Dictionary<int, CarModel>"
            inline constexpr std::uintptr_t time = 0x28; // "TimeModel"
            inline constexpr std::uintptr_t entityIdToLastDataTickIndex = 0x30; // "Dictionary<int, long>"
            inline constexpr std::uintptr_t lastServerUpdateTs = 0x38; // "long"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xE7C0A0; // "public void Update()"
            inline constexpr std::uintptr_t NeedUpdateCar = 0xE7BDE0; // "private bool NeedUpdateCar(CarModel car, IDataModel carDataModel, out long newDataTickIndex)"
            inline constexpr std::uintptr_t UpdateCarDriveInput = 0xE7BED0; // "private void UpdateCarDriveInput(CarModel car)"
        }
    } // namespace UpdateVehiclesRuntimeModelsUpdater

    namespace UpdateVehicleTransformFromPhysicsSceneSystem { // "Models.Systems.UpdateVehicleTransformFromPhysicsSceneSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsSceneModel = 0x38; // "PhysicsSceneModel"
            inline constexpr std::uintptr_t worldTickData = 0x40; // "WorldTickData"
            inline constexpr std::uintptr_t eps = 0x48; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x4369760; // "protected override void Tick(ITick tick)"
        }
    } // namespace UpdateVehicleTransformFromPhysicsSceneSystem

    namespace UpdateVehicleVelocitiesFromPhysicsSceneSystem { // "Models.Systems.UpdateVehicleVelocitiesFromPhysicsSceneSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsSceneModel = 0x38; // "PhysicsSceneModel"
            inline constexpr std::uintptr_t eps = 0x40; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x4369AF0; // "protected override void Tick(ITick tick)"
        }
    } // namespace UpdateVehicleVelocitiesFromPhysicsSceneSystem

    namespace UseVehicleHintViewUpdater { // "Game.Battle.Use.UseVehicleHintViewUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t platformHintViewDescription = 0x10; // "TargetHintViewDescription"
            inline constexpr std::uintptr_t preferredTargetModel = 0x18; // "PreferredTargetModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x20; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t rectCanvas = 0x28; // "RectTransform"
            inline constexpr std::uintptr_t parent = 0x30; // "RectTransform"
            inline constexpr std::uintptr_t targetHintViewDescriptions = 0x38; // "TargetHintViewDescriptions"
            inline constexpr std::uintptr_t camera = 0x40; // "Camera"
            inline constexpr std::uintptr_t now = 0x48; // "INow"
            inline constexpr std::uintptr_t viewContent = 0x50; // "IDisposableContent<TargetHintMarkerView>"
            inline constexpr std::uintptr_t isActive = 0x58; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xD593F0; // "public void Update()"
            inline constexpr std::uintptr_t UpdateView = 0xD592C0; // "private void UpdateView(TargetHintMarkerView view, Vector3 parentNormalizedPosition)"
            inline constexpr std::uintptr_t HasIntentionToLeaveVehicle = 0xD59150; // "private bool HasIntentionToLeaveVehicle(PlayerEntityModel player)"
            inline constexpr std::uintptr_t GetAlpha = 0xD59090; // "private float GetAlpha(Vector3 viewportPosition)"
        }
    } // namespace UseVehicleHintViewUpdater

    namespace Vehicle3DMarkerTypeSet { // "Game.Battle.Entities.Player.Vehicle.Updaters.Vehicle3DMarkerTypeSet (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Own = 0x10; // "MapMarkerType"
            inline constexpr std::uintptr_t Party = 0x14; // "MapMarkerType"
            inline constexpr std::uintptr_t Clan = 0x18; // "MapMarkerType"
        }
    } // namespace Vehicle3DMarkerTypeSet

    namespace Vehicle3DMarkerUpdater { // "Game.Battle.Entities.Player.Vehicle.Updaters.Vehicle3DMarkerUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleEntitiesModel = 0x10; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t markersModel = 0x18; // "Markers3DModel"
            inline constexpr std::uintptr_t charactersInVehiclesModel = 0x20; // "CharacterInVehiclesModel"
            inline constexpr std::uintptr_t vehicleId = 0x28; // "int"
            inline constexpr std::uintptr_t partyModel = 0x30; // "PartyModel"
            inline constexpr std::uintptr_t clanModel = 0x38; // "ClanModel"
            inline constexpr std::uintptr_t tutorialModel = 0x40; // "TutorialModel"
            inline constexpr std::uintptr_t vehicleOwnerModel = 0x48; // "VehicleOwnerModel"
            inline constexpr std::uintptr_t markerView = 0x50; // "VehicleMarkerRootView"
            inline constexpr std::uintptr_t markerTypes = 0x58; // "Vehicle3DMarkerTypeSet"
            inline constexpr std::uintptr_t markerModel = 0x60; // "Marker3DVehicleModel"
            inline constexpr std::uintptr_t canDrawMarker = 0x68; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB18910; // "public void Update()"
            inline constexpr std::uintptr_t GetMarkerType = 0xB18340; // "private MapMarkerType GetMarkerType(PlayerEntityModel player, out int partyIndex, out bool isPartyMarker)"
            inline constexpr std::uintptr_t IsVehicleOccupied = 0xB18840; // "private bool IsVehicleOccupied()"
            inline constexpr std::uintptr_t IsPartyMemberInside = 0xB18660; // "private bool IsPartyMemberInside(BattleCharacterModel playerModel)"
            inline constexpr std::uintptr_t RemoveMarker = 0xB188D0; // "private void RemoveMarker()"
        }
    } // namespace Vehicle3DMarkerUpdater

    namespace VehicleAnimationView { // "Game.Battle.Entities.Car.VehicleAnimationView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t seat0 = 0x20; // "Seat"
            inline constexpr std::uintptr_t seat1 = 0x48; // "Seat"
            inline constexpr std::uintptr_t seat2 = 0x70; // "Seat"
            inline constexpr std::uintptr_t seat3 = 0x98; // "Seat"
            inline constexpr std::uintptr_t seat4 = 0xC0; // "Seat"
            inline constexpr std::uintptr_t seat5 = 0xE8; // "Seat"
            inline constexpr std::uintptr_t steeringWheel = 0x110; // "Transform"
            inline constexpr std::uintptr_t maxSteeringWheelAngle = 0x118; // "float"
            inline constexpr std::uintptr_t inverseAngle = 0x11C; // "bool"
            inline constexpr std::uintptr_t DriverSeat = 0x120; // "DriverSeat"
            inline constexpr std::uintptr_t localEulerAngles = 0x140; // "Vector3"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Awake = 0xBA1170; // "private void Awake()"
            inline constexpr std::uintptr_t SetSteeringWheelRelativeAngle = 0xBA1520; // "public void SetSteeringWheelRelativeAngle(float angleT)"
            inline constexpr std::uintptr_t GetSeat = 0xBA1210; // "public Seat GetSeat(VehicleSeatSlotDescription slot)"
        }
    } // namespace VehicleAnimationView

    namespace VehicleAxleClientModel { // "Game.Battle.Entities.Vehicles.Models.VehicleAxleClientModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t BaseLeftSpringLength = 0x10; // "float"
            inline constexpr std::uintptr_t BaseRightSpringLength = 0x14; // "float"
            inline constexpr std::uintptr_t ExtraLeftSpringLength = 0x18; // "float"
            inline constexpr std::uintptr_t ExtraRightSpringLength = 0x1C; // "float"
            inline constexpr std::uintptr_t LeftSpringLength = 0x20; // "float"
            inline constexpr std::uintptr_t RightSpringLength = 0x24; // "float"
        }
    } // namespace VehicleAxleClientModel

    namespace VehicleBenchDialogView { // "Game.Battle.EntityModel.VehicleBench.VehicleBenchDialogView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Header = 0x20; // "InventoryDialogHeaderView"
            inline constexpr std::uintptr_t CountBusy = 0x28; // "TextLabel<int, int>"
            inline constexpr std::uintptr_t VehicleBenchItems = 0x30; // "VehicleBenchItemView[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t ActivateVehicleItem = 0xC342C0; // "public void ActivateVehicleItem(int amount)"
            inline constexpr std::uintptr_t SetItemState = 0xC343B0; // "public void SetItemState(int index, VehicleBenchDialogView.VehicleItemType state)"
            inline constexpr std::uintptr_t SetGlow = 0xC34370; // "public void SetGlow(int index, bool isActive)"
        }
    } // namespace VehicleBenchDialogView

    namespace VehicleBenchItemActionModel { // "Game.Battle.Entities.Plot.VehicleBench.VehicleBenchItemActionModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t slotModel = 0x10; // "IVehicleBenchSlotModel"
            inline constexpr std::uintptr_t inventoryItemType = 0x18; // "InventoryItemType"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Initialize = 0xAFF860; // "public void Initialize(IVehicleBenchSlotModel slotModel, InventoryItemType inventoryItemType)"
            inline constexpr std::uintptr_t CheckSet = 0xAFF7B0; // "public bool CheckSet(InventoryItemDescription item, int count, int ammo, int durability, int cumulativePoints, out bool isSet)"
            inline constexpr std::uintptr_t CheckMoveFrom = 0xAFF610; // "public bool CheckMoveFrom(int count, out InventoryItemDescription item, out int ammo, out int durability, out int cumulativePoints, out bool isUnset)"
            inline constexpr std::uintptr_t CheckMoveTo = 0xAFF700; // "public bool CheckMoveTo(InventoryItemDescription item, int count, int ammo, int durability, int cumulativePoints, IItemActionModel fromModel, out bool isSet)"
            inline constexpr std::uintptr_t CheckUnset = 0x7D5050; // "public bool CheckUnset()"
            inline constexpr std::uintptr_t CheckSwap = 0xAFF7F0; // "public bool CheckSwap(InventoryItemDescription item, int count, int ammo, int durability, int cumulativePoints)"
            inline constexpr std::uintptr_t TryGetContent = 0xAFF8D0; // "public bool TryGetContent(out InventoryItemDescription item, out int count, out int ammo, out int durability, out int cumulativePoints)"
            inline constexpr std::uintptr_t AreEqual = 0xAFF510; // "public bool AreEqual(IItemActionModel other)"
            inline constexpr std::uintptr_t Set = 0xAFF890; // "public void Set(long now, InventoryItemDescription item, int count, int ammo, int durability, int cumulativePoints)"
            inline constexpr std::uintptr_t Unset = 0xAFFA10; // "public void Unset()"
            inline constexpr std::uintptr_t ChangeStack = 0xAFF5D0; // "public void ChangeStack(int count)"
            inline constexpr std::uintptr_t ChangeAmmo = 0xAFF590; // "public void ChangeAmmo(int ammo)"
            inline constexpr std::uintptr_t get_IsSlotBusy = 0x7EC9F0; // "public bool get_IsSlotBusy()"
            inline constexpr std::uintptr_t CheckUnloadAmmo = 0xAFF820; // "public bool CheckUnloadAmmo(long now)"
        }
    } // namespace VehicleBenchItemActionModel

    namespace VehicleBenchItemView { // "Game.Battle.Entities.Plot.VehicleBench.VehicleBenchItemView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t icon = 0x20; // "Image"
            inline constexpr std::uintptr_t rareView = 0x28; // "LineAndBackgroundRareView"
            inline constexpr std::uintptr_t vehicleItemType = 0x30; // "EnumStateElement<VehicleBenchDialogView.VehicleItemType>"
            inline constexpr std::uintptr_t slotGlowView = 0x38; // "InventorySlotGlowView"
            inline constexpr std::uintptr_t DraggableItemView = 0x40; // "DraggableItemView"
            inline constexpr std::uintptr_t PointerButtonView = 0x48; // "PointerButtonView"
            inline constexpr std::uintptr_t DropAreaView = 0x50; // "DropAreaView"
            inline constexpr std::uintptr_t SlotBlockedView = 0x58; // "SlotBlockedView"
            inline constexpr std::uintptr_t SlotLockedView = 0x60; // "SlotLockedView"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetItemState = 0xAFFAE0; // "public void SetItemState(VehicleBenchDialogView.VehicleItemType state)"
            inline constexpr std::uintptr_t SetGlow = 0xAFFAC0; // "public void SetGlow(bool isActive)"
            inline constexpr std::uintptr_t Show = 0xAFFB40; // "public void Show(Sprite sprite, RarityItem rare)"
            inline constexpr std::uintptr_t Hide = 0xAFFA50; // "public void Hide()"
        }
    } // namespace VehicleBenchItemView

    namespace VehicleBenchKeyboardMouseInputHandler { // "Game.Battle.EntityModel.VehicleBench.VehicleBenchKeyboardMouseInputHandler (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t updaters = 0x20; // "List<IUpdater>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xC34450; // "public VehicleBenchKeyboardMouseInputHandler Init(GlobalModel globalModel, BattleModel battleModel, CurrentInventoryModel currentInventoryModel, IVehicleBenchSlotModel[] slots, Dictionary<IVehicleBenchSlotModel, IItemMoveContext> itemMoveContexts, InputActions inputActions, VehicleBenchDialogView dialogView, BattleScreenContent battleScreenContent, UpdaterPool updaterPool, IRegisterDisposable registerDisposable)"
            inline constexpr std::uintptr_t Dispose = 0xC343F0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0x94CF50; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace VehicleBenchKeyboardMouseInputHandler

    namespace VehicleBenchSlotModelUpdater { // "Game.Battle.EntityModel.VehicleBench.VehicleBenchSlotModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t slotModel = 0x20; // "IVehicleBenchSlotModel"
            inline constexpr std::uintptr_t inventoryModels = 0x28; // "InventoryModels"
            inline constexpr std::uintptr_t itemMoveContext = 0x30; // "IItemMoveContext"
            inline constexpr std::uintptr_t view = 0x38; // "VehicleBenchItemView"
            inline constexpr std::uintptr_t isEmpty = 0x40; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xC34BA0; // "public VehicleBenchSlotModelUpdater Init(IVehicleBenchSlotModel slotModel, InventoryModels inventoryModels, IItemMoveContext itemMoveContext, VehicleBenchItemView view)"
            inline constexpr std::uintptr_t Dispose = 0xA695F0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xC34C40; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace VehicleBenchSlotModelUpdater

    namespace VehicleBenchSlotsIconUpdater { // "Game.Battle.EntityModel.VehicleBench.VehicleBenchSlotsIconUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t slots = 0x20; // "IVehicleBenchSlotModel[]"
            inline constexpr std::uintptr_t uiView = 0x28; // "VehicleBenchDialogView"
            inline constexpr std::uintptr_t inventoryItemViewDescriptions = 0x30; // "InventoryItemViewDescriptions"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xC34D50; // "public VehicleBenchSlotsIconUpdater Init(VehicleBenchDialogView uiView, IVehicleBenchSlotModel[] slots, InventoryItemViewDescriptions inventoryItemViewDescriptions)"
            inline constexpr std::uintptr_t Dispose = 0x9F6DA0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xC34E00; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace VehicleBenchSlotsIconUpdater

    namespace VehicleBuilderGlowViewUpdater { // "Game.Battle.EntityModel.VehicleBench.VehicleBuilderGlowViewUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t view = 0x20; // "VehicleBenchDialogView"
            inline constexpr std::uintptr_t slots = 0x28; // "IVehicleBenchSlotModel[]"
            inline constexpr std::uintptr_t battleModel = 0x30; // "BattleModel"
            inline constexpr std::uintptr_t plotModel = 0x38; // "PlotModel"
            inline constexpr std::uintptr_t isDragSuitableItem = 0x40; // "Func<bool>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA5F7A0; // "public VehicleBuilderGlowViewUpdater Init(VehicleBenchDialogView view, IVehicleBenchSlotModel[] slots, BattleModel battleModel, PlotModel plotModel, Func<bool> isDragSuitableItemSuitableItem)"
            inline constexpr std::uintptr_t Dispose = 0xA123B0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xC35010; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace VehicleBuilderGlowViewUpdater

    namespace VehicleBuilderRule { // "Game.Battle.Entities.Plot.VehicleBench.VehicleBuilderRule (Battle.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t GetSlotState = 0xAFFC00; // "public static VehicleBenchDialogView.VehicleItemType GetSlotState(IVehicleBenchSlotModel slotModel, BattleModel battleModel, PlotModel plotModel)"
        }
    } // namespace VehicleBuilderRule

    namespace VehicleClearingAttention { // "Game.Battle.Cars.VehicleClearingAttention (Battle.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t TryShowAttentionByVehicle = 0xD23FE0; // "public static bool TryShowAttentionByVehicle(GlobalModel globalModel, PlotModel plotModel, BattleModel battleModel, InputActions inputActions, NotificationKeys notificationKeys, GlobalLocalizationKeys globalLocalizationKeys, Action onOkClickAction, IInteractEntityModel interactEntityModel, VehicleTypeDescription vehicleTypeDescription, bool despawnsRentedVehicle)"
            inline constexpr std::uintptr_t TryShowAttentionRemoveHelicopter = 0xD24870; // "public static bool TryShowAttentionRemoveHelicopter(GlobalModel globalModel, IBattleEntitiesModel battleEntitiesModel, InputActions inputActions, NotificationKeys notificationKeys, GlobalLocalizationKeys globalLocalizationKeys, Action onOkClickAction, IInteractEntityModel interactEntityModel, VehicleTypeDescription vehicleTypeDescription)"
            inline constexpr std::uintptr_t TryShowAttentionByPartyVehicle = 0xD23E40; // "public static bool TryShowAttentionByPartyVehicle(GlobalModel globalModel, IBattleEntitiesModel battleEntitiesModel, InputActions inputActions, NotificationKeys notificationKeys, GlobalLocalizationKeys globalLocalizationKeys, Action onOkClickAction, IInteractEntityModel interactEntityModel, VehicleTypeDescription vehicleTypeDescription)"
            inline constexpr std::uintptr_t TryShowAttentionForUnsetCarBench = 0xD24450; // "public static bool TryShowAttentionForUnsetCarBench(GlobalModel globalModel, IPlotVehicleModel plotVehicleModel, IBattleEntitiesModel battleEntitiesModel, ModalDialogModel modalDialogModel, InputActions inputActions, LocalizationKeys localizationKeys, GlobalLocalizationKeys globalLocalizationKeys, Action onOkClickAction, IInteractEntityModel interactEntityModel, bool isRemovePlotVehicle, VehicleOwnersModel vehicleOwnersModel)"
            inline constexpr std::uintptr_t CheckShowAttentionRemoveVehicle = 0xD22600; // "public static bool CheckShowAttentionRemoveVehicle(GlobalModel globalModel, IPlotVehicleModel plotVehicleModel, PlayerBattleModel playerBattleModel, IBattleEntitiesModel battleEntitiesModel, InputActions inputActions, LocalizationKeys localizationKeys, GlobalLocalizationKeys globalLocalizationKeys, Action onOkClickAction, IInteractEntityModel interactEntityModel)"
            inline constexpr std::uintptr_t CheckShowAttentionReuseVehicle = 0xD22AA0; // "public static bool CheckShowAttentionReuseVehicle(GlobalModel globalModel, IPlotVehicleModel plotVehicleModel, PlayerBattleModel playerBattleModel, IBattleEntitiesModel battleEntitiesModel, InputActions inputActions, LocalizationKeys localizationKeys, GlobalLocalizationKeys globalLocalizationKeys, Action onOkClickAction, VehicleOwnersModel vehicleOwnersModel, IInteractEntityModel interactEntityModel)"
            inline constexpr std::uintptr_t CheckShowAttentionReplaceVehicle = 0xD22890; // "public static bool CheckShowAttentionReplaceVehicle(GlobalModel globalModel, IPlotVehicleModel plotVehicleModel, CarSlotDescription newCar, PlayerBattleModel playerBattleModel, IBattleEntitiesModel battleEntitiesModel, InputActions inputActions, LocalizationKeys localizationKeys, Text description, GlobalLocalizationKeys globalLocalizationKeys, Action onOkClickAction, VehicleOwnersModel vehicleOwnersModel, IInteractEntityModel interactEntityModel)"
            inline constexpr std::uintptr_t AllMemberPartyInThisLocation = 0xD21F80; // "private static bool AllMemberPartyInThisLocation(PartyModel partyModel)"
            inline constexpr std::uintptr_t IsVehicleOnOtherLocation = 0xD23A60; // "private static bool IsVehicleOnOtherLocation(GlobalModel globalModel, IPlotVehicleModel plotVehicleModel, PlayerEntityModel player)"
            inline constexpr std::uintptr_t HasTrunkLoot = 0xD22FB0; // "private static bool HasTrunkLoot(IPlotVehicleModel plotVehicleModel, PlayerBattleModel playerBattleModel)"
            inline constexpr std::uintptr_t HasAnyCarUpgrades = 0xD22CA0; // "private static bool HasAnyCarUpgrades(IPlotVehicleModel plotVehicleModel, PlayerBattleModel playerBattleModel)"
            inline constexpr std::uintptr_t HasFallingUpgrades = 0xD22D90; // "private static bool HasFallingUpgrades(IBattleEntitiesModel battleEntitiesModel, VehicleOwnersModel vehicleOwnersModel, IPlotVehicleModel plotVehicleModel, CarSlotDescription newCar)"
            inline constexpr std::uintptr_t CalculateTrunkModules = 0xD220E0; // "private static bool CalculateTrunkModules(CarUpgradesSlotsModel upgradesSlotsModel, out int trunkCargoUpgradesCount, out int trunkInventoryUpgradesCount)"
            inline constexpr std::uintptr_t TryShowAttention = 0xD24A20; // "public static void TryShowAttention(BattleCharacterModel serverModel, ModalDialogModel modalDialogModel, InputActions inputActions, NotificationKeys notificationKeys, GlobalLocalizationKeys globalLocalizationKeys, Action onOkClickAction, IInteractEntityModel interactEntityModel, VehicleTypeDescription vehicleTypeDescription)"
            inline constexpr std::uintptr_t OpenDialog = 0xD23B90; // "private static void OpenDialog(LocalizedString localizedHeader, Text localizedDescription, Action onOkClickAction, ModalDialogModel modalDialogModel, InputActions inputActions, BattleCharacterModel battleCharacterModel, IInteractEntityModel interactEntityModel, GlobalLocalizationKeys globalLocalizationKeys)"
            inline constexpr std::uintptr_t IsCarGaragesSpawned = 0xD23080; // "private static bool IsCarGaragesSpawned(PlotModel plotModel, ReadOnly.Dictionary<int, PlotCarGarageModel> carGarages)"
            inline constexpr std::uintptr_t IsPlotCarGaragesSpawned = 0xD233D0; // "private static bool IsPlotCarGaragesSpawned(int carGarageId, ReadOnly.Dictionary<int, PlotCarGarageModel> carGarages)"
            inline constexpr std::uintptr_t IsVehicleInsideBase = 0xD235D0; // "public static bool IsVehicleInsideBase(int vehicleId, IPlotVehicleModel plotVehicleModel, WorldEntitiesModel worldEntitiesModel)"
            inline constexpr std::uintptr_t IsVehicleInsideBase_2 = 0xD23830; // "private static bool IsVehicleInsideBase(int vehicleId, PlotModel plotModel, WorldEntitiesModel worldEntitiesModel)"
            inline constexpr std::uintptr_t IsVehicleInsideBase_3 = 0xD23900; // "private static bool IsVehicleInsideBase(PlotModel plotModel, BattleModel battleModel, PlayerEntityModel player)"
            inline constexpr std::uintptr_t IsVehicleInsideBase_4 = 0xD23740; // "private static bool IsVehicleInsideBase(PlayerEntityModel player, VehicleOwnersModel vehicleOwnersModel, IPlotVehicleModel plotVehicleModel, IBattleEntitiesModel battleEntitiesModel)"
        }
    } // namespace VehicleClearingAttention

    namespace VehicleClientModel { // "Game.Battle.Entities.Vehicles.Models.VehicleClientModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Position = 0x10; // "SetMovementModel"
            inline constexpr std::uintptr_t Rotation = 0x18; // "VehicleRotationModel"
            inline constexpr std::uintptr_t SuspensionLimitCollision = 0x20; // "VehicleSuspensionLimitCollisionModel"
            inline constexpr std::uintptr_t TimeOffsetTarget = 0x28; // "TimelineTimeOffsetTargetModel"
            inline constexpr std::uintptr_t TimeOffset = 0x30; // "TimelineTimeOffsetModel"
            inline constexpr std::uintptr_t DeadReckoning = 0x38; // "EntityDeadReckoningModel"
            inline constexpr std::uintptr_t SqrDistanceToPlayer = 0x40; // "float"
        }
    } // namespace VehicleClientModel

    namespace VehicleCollidersDescription { // "Models.References.Vehicle.VehicleCollidersDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t TransformHitBoxDescription = 0x20; // "TransformHitBoxDescription"
            inline constexpr std::uintptr_t CollidersShapeRelativeToPivot = 0x28; // "CompoundShape"
            inline constexpr std::uintptr_t BoundingBoxLocalPositionRelativeToPivot = 0x30; // "Vector3"
            inline constexpr std::uintptr_t BoundingBoxSize = 0x3C; // "Vector3"
            inline constexpr std::uintptr_t garageSlotColliders = 0x48; // "CollidersDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_GarageSlotColliders = 0x407CFD0; // "public CollidersDescription get_GarageSlotColliders()"
            inline constexpr std::uintptr_t CalculateGarageSlotColliders = 0x407C760; // "private CollidersDescription CalculateGarageSlotColliders()"
        }
    } // namespace VehicleCollidersDescription

    namespace VehicleCollisionPointData { // "ClientCore.Models.VehiclesCollisionsModel.VehicleCollisionPointData (Client.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t WorldPositionOnVehicle = 0x0; // "Vector3"
            inline constexpr std::uintptr_t LocalPositionOnVehicle = 0xC; // "Vector3"
            inline constexpr std::uintptr_t WorldNormalOnAnotherBody = 0x18; // "Vector3"
            inline constexpr std::uintptr_t AnotherBodyId = 0x24; // "PhysicsBodyId"
            inline constexpr std::uintptr_t AnotherBodySurfaceType = 0x2C; // "byte"
            inline constexpr std::uintptr_t LowVelocityContact = 0x2D; // "bool"
            inline constexpr std::uintptr_t HighVelocityContact = 0x2E; // "bool"
            inline constexpr std::uintptr_t ScratchContact = 0x2F; // "bool"
        }
    } // namespace VehicleCollisionPointData

    namespace VehicleCollisionsWithBreakableCollidersModel { // "ClientCore.Models.VehiclesCollisionsModel.VehicleCollisionsWithBreakableCollidersModel (Client.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t breakableColliderBodyIds = 0x10; // "HashSet<PhysicsBodyId>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t GetEnumerator = 0xE91CF0; // "public HashSet.Enumerator<PhysicsBodyId> GetEnumerator()"
            inline constexpr std::uintptr_t AddBreakableColliderCollision = 0xE91C40; // "public void AddBreakableColliderCollision(PhysicsBodyId bodyId)"
            inline constexpr std::uintptr_t Clear = 0xE91CA0; // "public void Clear()"
        }
    } // namespace VehicleCollisionsWithBreakableCollidersModel

    namespace VehicleCollisionsWithBreakableCollidersModelUpdater { // "Game.Battle.Entities.Player.Vehicle.Updaters.VehicleCollisionsWithBreakableCollidersModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t vehicleCollisionsWithBreakableCollidersModel = 0x10; // "IVehicleCollisionsWithBreakableCollidersModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x18; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t inVehicleModel = 0x20; // "InVehicleModel"
            inline constexpr std::uintptr_t now = 0x28; // "INow"
            inline constexpr std::uintptr_t currentCollisions = 0x30; // "Queue<ValueTuple<long, PhysicsBodyId>>"
            inline constexpr std::uintptr_t isInVehicle = 0x38; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB194B0; // "public void Update()"
            inline constexpr std::uintptr_t RemoveOldCollisions = 0xB19180; // "private void RemoveOldCollisions()"
            inline constexpr std::uintptr_t AddNewCollisions = 0xB18C80; // "private void AddNewCollisions()"
            inline constexpr std::uintptr_t TryGetBreakableColliderSetEntityModel = 0xB192F0; // "private bool TryGetBreakableColliderSetEntityModel(PhysicsBodyId breakableColliderBodyId, out BreakableColliderSetEntityModel result)"
            inline constexpr std::uintptr_t Dispose = 0xB18F70; // "private void Dispose()"
        }
    } // namespace VehicleCollisionsWithBreakableCollidersModelUpdater

    namespace VehicleComputedConfig { // "Models.References.Character.Customizer.VehicleComputedConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t carsBySlot = 0x10; // "Dictionary<CarSlotDescription, ReadOnly.HashSet<CarDescription>>"
            inline constexpr std::uintptr_t helicoptersBySlot = 0x18; // "Dictionary<HelicopterSlotDescription, ReadOnly.HashSet<HelicopterDescription>>"
            inline constexpr std::uintptr_t emptyCars = 0x20; // "ReadOnly.HashSet<CarDescription>"
            inline constexpr std::uintptr_t emptyHelicopters = 0x28; // "ReadOnly.HashSet<HelicopterDescription>"
            inline constexpr std::uintptr_t NotFreeCarsCount = 0x30; // "int"
            inline constexpr std::uintptr_t NotFreeHelicoptersCount = 0x34; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t GetCarsBySlot = 0x4478EB0; // "public ReadOnly.HashSet<CarDescription> GetCarsBySlot(CarSlotDescription carSlotDescription)"
            inline constexpr std::uintptr_t GetHelicoptersBySlot = 0x4478F00; // "public ReadOnly.HashSet<HelicopterDescription> GetHelicoptersBySlot(HelicopterSlotDescription helicopterSlotDescription)"
        }
    } // namespace VehicleComputedConfig

    namespace VehicleConfig { // "Models.References.Vehicle.Settings.VehicleConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t MaxWheelsCount = 0x10; // "int"
            inline constexpr std::uintptr_t LeaveDuration = 0x18; // "long"
            inline constexpr std::uintptr_t DelayToFindOutPlayerIntentionToLeaveVehicleInsteadOfInteractingWithTargetSystem = 0x20; // "long"
            inline constexpr std::uintptr_t SuspensionPredictionLength = 0x28; // "float"
            inline constexpr std::uintptr_t UnderWaterStateHysteresis = 0x2C; // "float"
            inline constexpr std::uintptr_t UnderWaterLinearDrag = 0x30; // "float"
            inline constexpr std::uintptr_t UnderWaterAngularDrag = 0x34; // "float"
        }
    } // namespace VehicleConfig

    namespace VehicleConstraintIslandEnableUpdater { // "Game.Battle.Entities.Vehicles.Updaters.VehicleConstraintIslandEnableUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t constraintSolverData = 0x18; // "ConstraintSolverData"
            inline constexpr std::uintptr_t constraintIslandModel = 0x20; // "ConstraintIslandModel"
            inline constexpr std::uintptr_t isSleepingFunc = 0x28; // "Func<bool>"
            inline constexpr std::uintptr_t disableCounter = 0x30; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t InnerUpdate = 0xAE14B0; // "protected override void InnerUpdate()"
            inline constexpr std::uintptr_t InnerStart = 0xAE1430; // "protected override void InnerStart()"
            inline constexpr std::uintptr_t InnerStop = 0xAE1470; // "protected override void InnerStop()"
        }
    } // namespace VehicleConstraintIslandEnableUpdater

    namespace VehicleControllerDrownedPhysicsDragSystem { // "Models.Systems.VehicleControllerDrownedPhysicsDragSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsSceneModel = 0x38; // "PhysicsSceneModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x436AF30; // "protected override void Tick(ITick tick)"
        }
    } // namespace VehicleControllerDrownedPhysicsDragSystem

    namespace VehicleControllerSuspensionLimitAddConstraintSystem { // "Models.Systems.VehicleControllerSuspensionLimitAddConstraintSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsSceneModel = 0x38; // "PhysicsSceneModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x436B250; // "protected override void Tick(ITick tick)"
        }
    } // namespace VehicleControllerSuspensionLimitAddConstraintSystem

    namespace VehicleControllerSuspensionLimitClearConstraintSystem { // "Models.Systems.VehicleControllerSuspensionLimitClearConstraintSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsSceneModel = 0x38; // "PhysicsSceneModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x436B760; // "protected override void Tick(ITick tick)"
        }
    } // namespace VehicleControllerSuspensionLimitClearConstraintSystem

    namespace VehicleControllerWaterCheckByCollisionsSystem { // "Models.Systems.VehicleControllerWaterCheckByCollisionsSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsSceneModel = 0x38; // "PhysicsSceneModel"
            inline constexpr std::uintptr_t physicsBodiesModel = 0x40; // "PhysicsBodiesModel"
            inline constexpr std::uintptr_t touchingBodiesResult = 0x48; // "List<PhysicsBodyId>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x436BB50; // "protected override void Tick(ITick tick)"
            inline constexpr std::uintptr_t CalculateNewState = 0x436B8C0; // "private VehicleWaterStateDescription CalculateNewState(VehicleWaterStateDescription oldState, Span<float> transformMatrix, VehicleDrownPointsDescription drownPointsDescription, float waterSurfacePlaneDistance)"
            inline constexpr std::uintptr_t SetVehicleWaterState = 0x436BAF0; // "private void SetVehicleWaterState(VehicleWaterModel water, VehicleWaterTickDataModel waterTickData, VehicleWaterStateDescription value, bool isServerOrFullPrediction)"
        }
    } // namespace VehicleControllerWaterCheckByCollisionsSystem

    namespace VehicleControllerWheelGroundCheckSystem { // "Models.Systems.VehicleControllerWheelGroundCheckSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsSceneModel = 0x38; // "PhysicsSceneModel"
            inline constexpr std::uintptr_t physicsBodiesModel = 0x40; // "PhysicsBodiesModel"
            inline constexpr std::uintptr_t physicsDebugEnabledModel = 0x48; // "PhysicsDebugEnabledModel"
            inline constexpr std::uintptr_t overlapsQueryBodiesResult = 0x50; // "List<PhysicsBodyId>"
            inline constexpr std::uintptr_t groundInfoCalculationInput = 0x58; // "VehicleControllerWheelGroundCheckSystem.GroundInfoCalculationInput"
            inline constexpr std::uintptr_t groundInfoCalculationOutput = 0x60; // "VehicleControllerWheelGroundCheckSystem.GroundInfoCalculationOutput"
            inline constexpr std::uintptr_t transparentBodies = 0x68; // "List<PhysicsBodyId>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x436FA60; // "protected override void Tick(ITick tick)"
            inline constexpr std::uintptr_t ShouldIgnoreBakedBody = 0x436FA40; // "private bool ShouldIgnoreBakedBody(PhysicsBodiesModel physicsBodiesModel, PhysicsBodyId bodyId)"
            inline constexpr std::uintptr_t ShouldIgnoreRuntimeBody = 0x435F3D0; // "private bool ShouldIgnoreRuntimeBody(PhysicsBodiesModel physicsBodiesModel, PhysicsBodyId bodyId)"
            inline constexpr std::uintptr_t IsTransparentBody = 0x435F380; // "private bool IsTransparentBody(PhysicsBodiesModel physicsBodiesModel, PhysicsBodyId bodyId)"
            inline constexpr std::uintptr_t CalculateGroundInfoVsRuntimeBody = 0x436E060; // "private void CalculateGroundInfoVsRuntimeBody(PhysicsShapesData shapes, VehicleControllerWheelGroundCheckSystem.GroundInfoCalculationInput input, VehicleControllerWheelGroundCheckSystem.GroundInfoCalculationOutput output, PhysicsBodyId bodyId, in RigidBodyData body)"
            inline constexpr std::uintptr_t CalculateGroundInfoVsBakedBody = 0x436C090; // "private void CalculateGroundInfoVsBakedBody(PhysicsStaticShapesData staticShapes, VehicleControllerWheelGroundCheckSystem.GroundInfoCalculationInput input, VehicleControllerWheelGroundCheckSystem.GroundInfoCalculationOutput output, PhysicsBodyId bodyId, in StaticBodyData body)"
            inline constexpr std::uintptr_t CalculateGroundInfoVsBox = 0x436CA50; // "private void CalculateGroundInfoVsBox(VehicleControllerWheelGroundCheckSystem.GroundInfoCalculationInput input, VehicleControllerWheelGroundCheckSystem.GroundInfoCalculationOutput output, PhysicsBodyId bodyId, in RigidBodyData body, in BoxShapeData box)"
            inline constexpr std::uintptr_t CalculateGroundInfoVsStaticBox = 0x436E440; // "private void CalculateGroundInfoVsStaticBox(VehicleControllerWheelGroundCheckSystem.GroundInfoCalculationInput input, VehicleControllerWheelGroundCheckSystem.GroundInfoCalculationOutput output, PhysicsBodyId bodyId, in StaticBoxShapeData box)"
            inline constexpr std::uintptr_t CalculateGroundInfoVsBoxShape = 0x436C3C0; // "private void CalculateGroundInfoVsBoxShape(VehicleControllerWheelGroundCheckSystem.GroundInfoCalculationInput input, VehicleControllerWheelGroundCheckSystem.GroundInfoCalculationOutput output, PhysicsBodyId bodyId, in Vector3 bodyPosition, in Quaternion bodyOrientation, float boxWidth, float boxHeight, float boxLength, byte boxSurfaceType)"
            inline constexpr std::uintptr_t CalculateGroundInfoVsTerrain = 0x436EA30; // "private void CalculateGroundInfoVsTerrain(VehicleControllerWheelGroundCheckSystem.GroundInfoCalculationInput input, VehicleControllerWheelGroundCheckSystem.GroundInfoCalculationOutput output, PhysicsBodyId bodyId, in RigidBodyData body, in TerrainShapeData terrain)"
            inline constexpr std::uintptr_t CalculateGroundInfoVsTerrainTriangle = 0x436E5F0; // "private bool CalculateGroundInfoVsTerrainTriangle(ref VehicleWheelsGroundCheckTerrainTriangleRaycastData data)"
            inline constexpr std::uintptr_t CalculateGroundInfoVsTriangle = 0x436E5A0; // "private void CalculateGroundInfoVsTriangle(VehicleControllerWheelGroundCheckSystem.GroundInfoCalculationInput input, VehicleControllerWheelGroundCheckSystem.GroundInfoCalculationOutput output, PhysicsBodyId bodyId, in TriangleShapeData triangle)"
            inline constexpr std::uintptr_t CalculateGroundInfoVsStaticTriangle = 0x436E5A0; // "private void CalculateGroundInfoVsStaticTriangle(VehicleControllerWheelGroundCheckSystem.GroundInfoCalculationInput input, VehicleControllerWheelGroundCheckSystem.GroundInfoCalculationOutput output, PhysicsBodyId bodyId, in StaticTriangleShapeData triangle)"
            inline constexpr std::uintptr_t CalculateGroundInfoVsTriangleShape = 0x436F340; // "private void CalculateGroundInfoVsTriangleShape(VehicleControllerWheelGroundCheckSystem.GroundInfoCalculationInput input, VehicleControllerWheelGroundCheckSystem.GroundInfoCalculationOutput output, PhysicsBodyId bodyId, in Vector3 worldPositionA, in Vector3 worldPositionB, in Vector3 worldPositionC, byte surfaceType)"
            inline constexpr std::uintptr_t CalculateGroundInfoVsCapsule = 0x436D3B0; // "private void CalculateGroundInfoVsCapsule(VehicleControllerWheelGroundCheckSystem.GroundInfoCalculationInput input, VehicleControllerWheelGroundCheckSystem.GroundInfoCalculationOutput output, PhysicsBodyId bodyId, in RigidBodyData body, in CapsuleShapeData capsule)"
            inline constexpr std::uintptr_t CalculateGroundInfoVsStaticCapsule = 0x436E4A0; // "private void CalculateGroundInfoVsStaticCapsule(VehicleControllerWheelGroundCheckSystem.GroundInfoCalculationInput input, VehicleControllerWheelGroundCheckSystem.GroundInfoCalculationOutput output, PhysicsBodyId bodyId, in StaticCapsuleShapeData capsule)"
            inline constexpr std::uintptr_t CalculateGroundInfoVsCapsuleShape = 0x436CAC0; // "private void CalculateGroundInfoVsCapsuleShape(VehicleControllerWheelGroundCheckSystem.GroundInfoCalculationInput input, VehicleControllerWheelGroundCheckSystem.GroundInfoCalculationOutput output, PhysicsBodyId bodyId, in Vector3 bodyPosition, in Vector3 capsuleUp, float capsuleLength, float capsuleRadius, byte capsuleSurfaceType)"
            inline constexpr std::uintptr_t CalculateGroundInfoVsHull = 0x436DFB0; // "private void CalculateGroundInfoVsHull(VehicleControllerWheelGroundCheckSystem.GroundInfoCalculationInput input, VehicleControllerWheelGroundCheckSystem.GroundInfoCalculationOutput output, PhysicsBodyId bodyId, in RigidBodyData body, in RuntimeHullShapeData hull, PhysicsLinkedListData<HullShapeData> hullData)"
            inline constexpr std::uintptr_t CalculateGroundInfoVsStaticHull = 0x436E500; // "private void CalculateGroundInfoVsStaticHull(VehicleControllerWheelGroundCheckSystem.GroundInfoCalculationInput input, VehicleControllerWheelGroundCheckSystem.GroundInfoCalculationOutput output, PhysicsBodyId bodyId, in StaticHullShapeData hull, PhysicsLinkedListData<HullShapeData> hullData)"
            inline constexpr std::uintptr_t CalculateGroundInfoVsHullShape = 0x436D4A0; // "private void CalculateGroundInfoVsHullShape(VehicleControllerWheelGroundCheckSystem.GroundInfoCalculationInput input, VehicleControllerWheelGroundCheckSystem.GroundInfoCalculationOutput output, PhysicsBodyId bodyId, in Vector3 bodyPosition, in Quaternion bodyOrientation, in HullShapeData hull, byte hullSurfaceType)"
            inline constexpr std::uintptr_t PrepareGroundInfoCalculationData = 0x436F890; // "private void PrepareGroundInfoCalculationData(VehicleControllerWheelGroundCheckSystem.GroundInfoCalculationInput input, VehicleControllerWheelGroundCheckSystem.GroundInfoCalculationOutput output, VehicleLinksTickDataModel linksTickData, ValueTuple<VehicleWheelLinkTickDataModel, VehicleWheelGroundTickDataModel, IPrimitiveModel<byte>>[] wheels)"
            inline constexpr std::uintptr_t UpdateGroundInfoCalculationData = 0x43706E0; // "private void UpdateGroundInfoCalculationData(VehicleControllerWheelGroundCheckSystem.GroundInfoCalculationInput input, VehicleControllerWheelGroundCheckSystem.GroundInfoCalculationOutput output)"
        }
    } // namespace VehicleControllerWheelGroundCheckSystem

    namespace VehicleControllerWheelGroundCheckSystem_GroundInfoCalculationInput { // "Models.Systems.VehicleControllerWheelGroundCheckSystem.GroundInfoCalculationInput (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t RayDirectionX = 0x10; // "float"
            inline constexpr std::uintptr_t RayDirectionY = 0x14; // "float"
            inline constexpr std::uintptr_t RayDirectionZ = 0x18; // "float"
            inline constexpr std::uintptr_t RaysCount = 0x1C; // "int"
            inline constexpr std::uintptr_t Rays = 0x20; // "VehicleControllerWheelGroundCheckSystem.GroundInfoCalculationRayInput[]"
        }
    } // namespace VehicleControllerWheelGroundCheckSystem_GroundInfoCalculationInput

    namespace VehicleControllerWheelGroundCheckSystem_GroundInfoCalculationOutput { // "Models.Systems.VehicleControllerWheelGroundCheckSystem.GroundInfoCalculationOutput (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Rays = 0x10; // "VehicleControllerWheelGroundCheckSystem.GroundInfoCalculationRayOutput[]"
        }
    } // namespace VehicleControllerWheelGroundCheckSystem_GroundInfoCalculationOutput

    namespace VehicleControllerWheelGroundCheckSystem_GroundInfoCalculationRayInput { // "Models.Systems.VehicleControllerWheelGroundCheckSystem.GroundInfoCalculationRayInput (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t RayFromX = 0x0; // "float"
            inline constexpr std::uintptr_t RayFromY = 0x4; // "float"
            inline constexpr std::uintptr_t RayFromZ = 0x8; // "float"
            inline constexpr std::uintptr_t RayDistance = 0xC; // "float"
        }
    } // namespace VehicleControllerWheelGroundCheckSystem_GroundInfoCalculationRayInput

    namespace VehicleControllerWheelGroundCheckSystem_GroundInfoCalculationRayOutput { // "Models.Systems.VehicleControllerWheelGroundCheckSystem.GroundInfoCalculationRayOutput (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t GroundFound = 0x0; // "bool"
            inline constexpr std::uintptr_t GroundBodyId = 0x4; // "PhysicsBodyId"
            inline constexpr std::uintptr_t GroundContactNormalX = 0xC; // "float"
            inline constexpr std::uintptr_t GroundContactNormalY = 0x10; // "float"
            inline constexpr std::uintptr_t GroundContactNormalZ = 0x14; // "float"
            inline constexpr std::uintptr_t GroundContactDistance = 0x18; // "float"
            inline constexpr std::uintptr_t GroundContactSurfaceType = 0x1C; // "byte"
        }
    } // namespace VehicleControllerWheelGroundCheckSystem_GroundInfoCalculationRayOutput

    namespace VehicleControllerWheelSuspensionSystem { // "Models.Systems.VehicleControllerWheelSuspensionSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsSceneModel = 0x38; // "PhysicsSceneModel"
            inline constexpr std::uintptr_t physicsDebugEnabledModel = 0x40; // "PhysicsDebugEnabledModel"
            inline constexpr std::uintptr_t triggersEventsModel = 0x48; // "ITriggersEventsModel"
            inline constexpr std::uintptr_t physicsBodiesModel = 0x50; // "PhysicsBodiesModel"
            inline constexpr std::uintptr_t invDt = 0x58; // "float"
            inline constexpr std::uintptr_t invSqrDt = 0x5C; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x4370980; // "protected override void Tick(ITick tick)"
        }
    } // namespace VehicleControllerWheelSuspensionSystem

    namespace VehicleDirtLevelModel { // "Models.Models.VehicleDirtLevel.VehicleDirtLevelModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t quantizeModel = 0x18; // "QuantizeModel"
            inline constexpr std::uintptr_t value = 0x20; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Value = 0x98BBA0; // "public float get_Value()"
            inline constexpr std::uintptr_t set_Value = 0x48CD4E0; // "public void set_Value(float value)"
            inline constexpr std::uintptr_t get_DequantizedValue = 0x48CD420; // "public float get_DequantizedValue()"
            inline constexpr std::uintptr_t get_QuantizedValue = 0x48CD490; // "public int get_QuantizedValue()"
            inline constexpr std::uintptr_t InitializeWithQuantizedValue = 0x48CD2E0; // "public void InitializeWithQuantizedValue(int value)"
            inline constexpr std::uintptr_t Clear = 0x48CD290; // "public void Clear()"
        }
    } // namespace VehicleDirtLevelModel

    namespace VehicleDoorsViewUpdater { // "Game.Battle.EntityModel.Car.VehicleDoorsViewUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t updater = 0x10; // "IUpdater"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xCC57C0; // "public void Update()"
        }
    } // namespace VehicleDoorsViewUpdater

    namespace VehicleDoorViewUpdater { // "Game.Battle.EntityModel.Car.VehicleDoorViewUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t index = 0x10; // "int"
            inline constexpr std::uintptr_t carSeatSlotDescription = 0x18; // "VehicleSeatSlotDescription"
            inline constexpr std::uintptr_t carSeatsModel = 0x20; // "VehicleSeatsModel"
            inline constexpr std::uintptr_t isWarpedModel = 0x28; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t vehicleEntityEntityEditor = 0x30; // "VehicleEntityView"
            inline constexpr std::uintptr_t soundEvent = 0x38; // "Event"
            inline constexpr std::uintptr_t isOccupied = 0x40; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xCC5600; // "public void Update()"
        }
    } // namespace VehicleDoorViewUpdater

    namespace VehicleDopplerUpdater { // "Game.Battle.VehicleDopplerEffect.VehicleDopplerUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleEntitiesModel = 0x18; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t vehicleMovementModel = 0x20; // "SetMovementModel"
            inline constexpr std::uintptr_t vehicleEntityId = 0x28; // "int"
            inline constexpr std::uintptr_t vehicleSoundEmitter = 0x30; // "GameObject"
            inline constexpr std::uintptr_t dopplerRtpc = 0x38; // "RTPC"
            inline constexpr std::uintptr_t lastPlayerPosition = 0x40; // "Vector3"
            inline constexpr std::uintptr_t lastPlayerVelocity = 0x4C; // "Vector3"
            inline constexpr std::uintptr_t playerDampVelocity = 0x58; // "Vector3"
            inline constexpr std::uintptr_t lastVehiclePosition = 0x64; // "Vector3"
            inline constexpr std::uintptr_t lastVehicleVelocity = 0x70; // "Vector3"
            inline constexpr std::uintptr_t vehicleDampVelocity = 0x7C; // "Vector3"
        }
        namespace Methods {
            inline constexpr std::uintptr_t InnerUpdate = 0xD5CCF0; // "protected override void InnerUpdate()"
            inline constexpr std::uintptr_t InnerStart = 0xD5CB80; // "protected override void InnerStart()"
            inline constexpr std::uintptr_t InnerStop = 0xD5CC70; // "protected override void InnerStop()"
            inline constexpr std::uintptr_t GetVelocity = 0xD5C9B0; // "private Vector3 GetVelocity(Vector3 previousVelocity, Vector3 previousFramePosition, Vector3 currentPosition, ref Vector3 smoothDampVelocity, out bool isStationary)"
        }
    } // namespace VehicleDopplerUpdater

    namespace VehicleDrownPointsDescription { // "Models.References.Vehicle.Water.VehicleDrownPointsDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t DrownPointRelativeToPivot = 0x20; // "Vector3"
        }
    } // namespace VehicleDrownPointsDescription

    namespace VehicleEngineDescription { // "Models.References.Vehicle.VehicleEngineDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t StartDuration = 0x20; // "long"
            inline constexpr std::uintptr_t StopDuration = 0x28; // "long"
            inline constexpr std::uintptr_t MinNormalizedSpeedForHandling = 0x30; // "float"
        }
    } // namespace VehicleEngineDescription

    namespace VehicleEngineModel { // "Models.Models.VehicleEngine.VehicleEngineModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t engineActive = 0x10; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t engineStateChangeOverTs = 0x18; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t settings = 0x20; // "VehicleEngineSettingsModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsActive = 0x48CDA20; // "public bool get_IsActive()"
            inline constexpr std::uintptr_t set_IsActive = 0x48CDAC0; // "public void set_IsActive(bool value)"
            inline constexpr std::uintptr_t get_StateChangeOverTs = 0x48CDA70; // "public long get_StateChangeOverTs()"
            inline constexpr std::uintptr_t set_StateChangeOverTs = 0x48CDB10; // "public void set_StateChangeOverTs(long value)"
            inline constexpr std::uintptr_t IsEnoughSpeedForHandlingByData = 0x48CD740; // "public bool IsEnoughSpeedForHandlingByData(long now)"
            inline constexpr std::uintptr_t CalculateNormalizedSpeed = 0x48CD690; // "public float CalculateNormalizedSpeed(long now, bool isActive, long stateChangeOverTs)"
            inline constexpr std::uintptr_t CalculateNormalizedSpeedByData = 0x48CD550; // "public float CalculateNormalizedSpeedByData(long now)"
            inline constexpr std::uintptr_t SwitchState = 0x48CD930; // "public void SwitchState(long now, bool oldIsActive, long oldStateChangeOverTs, out bool newIsActive, out long newStateChangeOverTs)"
        }
    } // namespace VehicleEngineModel

    namespace VehicleEngineRulesModel { // "Models.Models.VehicleEngineRules.VehicleEngineRulesModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t seats = 0x10; // "VehicleSeatsModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t IsEngineShouldBeActive = 0x48CDB60; // "public bool IsEngineShouldBeActive()"
        }
    } // namespace VehicleEngineRulesModel

    namespace VehicleEngineSettingsModel { // "Models.Models.VehicleEngineSettings.VehicleEngineSettingsModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t description = 0x10; // "VehicleEngineDescription"
            inline constexpr std::uintptr_t overrideModel = 0x18; // "VehicleEngineSettingsOverrideModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_StartDuration = 0x48CDCA0; // "public long get_StartDuration()"
            inline constexpr std::uintptr_t get_StopDuration = 0x48CDD70; // "public long get_StopDuration()"
            inline constexpr std::uintptr_t get_MinNormalizedSpeedForHandling = 0x48CDBD0; // "public float get_MinNormalizedSpeedForHandling()"
        }
    } // namespace VehicleEngineSettingsModel

    namespace VehicleEngineSettingsOverrideData { // "Models.Data.SettingsOverride.Vehicles.VehicleEngineSettingsOverrideData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t OverrideEnabled = 0x20; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t StartDuration = 0x28; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t StopDuration = 0x30; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t MinNormalizedSpeedForHandling = 0x38; // "IPrimitiveData<float>"
        }
    } // namespace VehicleEngineSettingsOverrideData

    namespace VehicleEngineSettingsOverrideModel { // "Models.Models.VehicleEngineSettingsOverride.VehicleEngineSettingsOverrideModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "VehicleEngineSettingsOverrideData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_OverrideEnabled = 0x48CDFF0; // "public bool get_OverrideEnabled()"
            inline constexpr std::uintptr_t get_StartDuration = 0x48CE040; // "public long get_StartDuration()"
            inline constexpr std::uintptr_t get_StopDuration = 0x48CE090; // "public long get_StopDuration()"
            inline constexpr std::uintptr_t get_MinNormalizedSpeedForHandling = 0x48CDFA0; // "public float get_MinNormalizedSpeedForHandling()"
            inline constexpr std::uintptr_t SetOverrideData = 0x48CDE40; // "public void SetOverrideData(long startDuration, long stopDuration, float minNormalizedSpeedForHandling)"
        }
    } // namespace VehicleEngineSettingsOverrideModel

    namespace VehicleEngineSystem { // "Models.Systems.VehicleEngineSystem (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x4371380; // "protected override void Tick(ITick tick)"
        }
    } // namespace VehicleEngineSystem

    namespace VehicleEngineTickDataModel { // "Models.Models.TickDataModels.Vehicle.VehicleEngineTickDataModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t EngineActive = 0x10; // "bool"
            inline constexpr std::uintptr_t EngineStateChangeOverTs = 0x18; // "long"
        }
    } // namespace VehicleEngineTickDataModel

    namespace VehicleEntityTrunkData { // "Models.Data.Vehicle.VehicleEntityTrunkData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Description = 0x20; // "VehicleTrunkDescription"
            inline constexpr std::uintptr_t Inventory = 0x28; // "InventoryData"
            inline constexpr std::uintptr_t InventoryRevealId = 0x30; // "InventoryRevealIdData"
            inline constexpr std::uintptr_t CargoInventory = 0x38; // "CargoInventoryData"
            inline constexpr std::uintptr_t InventoryAdditionalLines = 0x40; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t CargoInventoryAdditionalSlots = 0x48; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t OwnerNickname = 0x50; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t OwnerClanTag = 0x58; // "IPrimitiveData<string>"
        }
    } // namespace VehicleEntityTrunkData

    namespace VehicleEntityView { // "Game.Battle.EntityModel.Vehicles.Views.VehicleEntityView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t TargetObjectView = 0x20; // "TargetObjectView"
            inline constexpr std::uintptr_t Collider = 0x28; // "Collider"
            inline constexpr std::uintptr_t TrunkCollider = 0x30; // "Collider"
            inline constexpr std::uintptr_t HoodCollider = 0x38; // "Collider"
            inline constexpr std::uintptr_t UnderCarriageCollider = 0x40; // "Collider"
            inline constexpr std::uintptr_t colliders = 0x48; // "Collider[]"
            inline constexpr std::uintptr_t doorsAnim = 0x50; // "TweenAnimation[]"
            inline constexpr std::uintptr_t MarkerRoot = 0x58; // "VehicleMarkerRootView"
            inline constexpr std::uintptr_t SoundEmitter = 0x60; // "GameObject"
            inline constexpr std::uintptr_t TrunkTargetObjectView = 0x68; // "TargetObjectView"
            inline constexpr std::uintptr_t TrunkMarkerParent = 0x70; // "Transform"
            inline constexpr std::uintptr_t trunkAnimation = 0x78; // "TweenGroup"
            inline constexpr std::uintptr_t insideHoodRenderers = 0x80; // "Renderer[]"
            inline constexpr std::uintptr_t HoodTargetObjectView = 0x88; // "TargetObjectView"
            inline constexpr std::uintptr_t hoodAnimation = 0x90; // "TweenGroup"
            inline constexpr std::uintptr_t UndercarriageTargetObjectView = 0x98; // "TargetObjectView"
            inline constexpr std::uintptr_t isTrunkOpened = 0xA0; // "bool"
            inline constexpr std::uintptr_t isHoodOpened = 0xA1; // "bool"
            inline constexpr std::uintptr_t Colliders = 0xA8; // "HashSet<Collider>"
            inline constexpr std::uintptr_t trunkTarget = 0xB0; // "UnityRaycastTargetObject"
            inline constexpr std::uintptr_t hoodTarget = 0xB8; // "UnityRaycastTargetObject"
            inline constexpr std::uintptr_t underTarget = 0xC0; // "UnityRaycastTargetObject"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsHoodAnimationPlaying = 0xBFD1E0; // "public bool get_IsHoodAnimationPlaying()"
            inline constexpr std::uintptr_t get_HasTrunk = 0xBFD140; // "public bool get_HasTrunk()"
            inline constexpr std::uintptr_t get_HasHood = 0xBFD0F0; // "public bool get_HasHood()"
            inline constexpr std::uintptr_t get_HasUndercarriage = 0xBFD190; // "public bool get_HasUndercarriage()"
            inline constexpr std::uintptr_t Awake = 0xBFC9A0; // "private void Awake()"
            inline constexpr std::uintptr_t SetCameraCollisionActive = 0xBFCAB0; // "public void SetCameraCollisionActive(bool isActive)"
            inline constexpr std::uintptr_t PlayAnimDoor = 0xBFCA40; // "public void PlayAnimDoor(int index)"
            inline constexpr std::uintptr_t SetHoodAnimationProgress = 0xBFCE00; // "public void SetHoodAnimationProgress(bool isHoodOpened, float progress)"
            inline constexpr std::uintptr_t SetHoodOpened = 0xBFCEA0; // "public void SetHoodOpened(bool isHoodOpened)"
            inline constexpr std::uintptr_t SetEnableInsideHoodRenderers = 0xBFCD30; // "public void SetEnableInsideHoodRenderers(bool enable)"
            inline constexpr std::uintptr_t SetTrunkAnimationProgress = 0xBFCFE0; // "public void SetTrunkAnimationProgress(bool isTrunkOpened, float progress)"
            inline constexpr std::uintptr_t SetTrunkOpened = 0xBFD010; // "public void SetTrunkOpened(bool isTrunkOpened)"
        }
    } // namespace VehicleEntityView

    namespace VehicleExitModel { // "Models.Models.VehicleExit.VehicleExitModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsLocationBorderMarked = 0x10; // "bool"
            inline constexpr std::uintptr_t IsForced = 0x11; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_NeedSpawnLoot = 0x36B5880; // "public bool get_NeedSpawnLoot()"
        }
    } // namespace VehicleExitModel

    namespace VehicleHitBoxAccessModel { // "Models.Models.HitBoxAccessModel.VehicleHitBoxAccessModel (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t get_IsHaveAccess = 0x7D5050; // "public bool get_IsHaveAccess()"
        }
    } // namespace VehicleHitBoxAccessModel

    namespace VehicleHitBoxSystem { // "Models.Systems.VehicleHitBoxSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t hitBoxes = 0x38; // "HitBoxesModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x4371580; // "protected override void Tick(ITick tick)"
        }
    } // namespace VehicleHitBoxSystem

    namespace VehicleInteractDescription { // "Models.References.Vehicle.VehicleInteractDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t SubscribeOffsetDistance = 0x20; // "float"
        }
    } // namespace VehicleInteractDescription

    namespace VehicleInteractExtensions { // "Models.Utils.Extensions.Vehicles.VehicleInteractExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t IsVehicleUnowned = 0x39719D0; // "public static bool IsVehicleUnowned(IPrimitiveModel<bool> vehicleIsUnowned)"
            inline constexpr std::uintptr_t IsVehicleGroupAvailableForRole = 0x39719A0; // "public static bool IsVehicleGroupAvailableForRole(PlayerRoleDescription role, VehicleGroupType vehicleGroupType)"
            inline constexpr std::uintptr_t IsVehicleFriendly = 0x3971730; // "public static bool IsVehicleFriendly(IParties parties, BattleModeDescription battleMode, IClanBattleCharacterTeamModel clanBattleCharacterTeamModel, int characterEntityId, long characterPublicId, VehicleOwnerModel vehicleCharacterOwner, PartyVehicleOwnerModel vehiclePartyOwner, ClanBattleVehicleTeamOwnerModel clanBattleVehicleTeamOwner)"
            inline constexpr std::uintptr_t IsSelfOwner = 0x3971530; // "private static bool IsSelfOwner(long characterPublicId, VehicleOwnerModel vehicleCharacterOwner)"
            inline constexpr std::uintptr_t IsPartyTeammateVehicle = 0x3971300; // "private static bool IsPartyTeammateVehicle(IParties parties, int characterEntityId, PartyVehicleOwnerModel vehiclePartyOwner)"
            inline constexpr std::uintptr_t IsPartyVehicle = 0x3971430; // "private static bool IsPartyVehicle(IParties parties, int characterEntityId, string vehiclePartyOwnerId)"
            inline constexpr std::uintptr_t IsClanBattleTeammateVehicle = 0x39711D0; // "private static bool IsClanBattleTeammateVehicle(BattleModeDescription battleMode, IClanBattleCharacterTeamModel clanBattleCharacterTeamModel, int characterEntityId, VehicleOwnerModel vehicleCharacterOwner, ClanBattleVehicleTeamOwnerModel clanBattleVehicleTeamOwnerModel)"
            inline constexpr std::uintptr_t IsVehicleAvailableForInteraction = 0x3971580; // "public static bool IsVehicleAvailableForInteraction(VehicleModel vehicle)"
            inline constexpr std::uintptr_t IsVehicleAvailableForInteraction_2 = 0x3971700; // "public static bool IsVehicleAvailableForInteraction(CarModel car)"
            inline constexpr std::uintptr_t IsVehicleAvailableForInteraction_3 = 0x39716D0; // "public static bool IsVehicleAvailableForInteraction(HelicopterModel helicopter)"
            inline constexpr std::uintptr_t IsVehicleAvailableForInteraction_4 = 0x39716B0; // "public static bool IsVehicleAvailableForInteraction(VehicleWaterModel water)"
            inline constexpr std::uintptr_t IsVehicleAvailableForInteraction_5 = 0x3971610; // "public static bool IsVehicleAvailableForInteraction(WorldEntitiesModel worldEntitiesModel, int vehicleEntityId)"
            inline constexpr std::uintptr_t IsVehicleAvailableForInteraction_6 = 0x39715B0; // "public static bool IsVehicleAvailableForInteraction(VehiclesWorldModel vehicles, int vehicleEntityId)"
            inline constexpr std::uintptr_t IsBattleCharacterSpawnVehicleOnCooldown = 0x3971110; // "public static bool IsBattleCharacterSpawnVehicleOnCooldown(BattleCharacterModel battleCharacter, long ts)"
        }
    } // namespace VehicleInteractExtensions

    namespace VehicleInventoryItemModel { // "Game.Battle.Entities.Plot.VehicleBench.VehicleInventoryItemModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t slotModel = 0x10; // "IVehicleBenchSlotModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Value = 0xAFFE40; // "public InventoryItemDescription get_Value()"
            inline constexpr std::uintptr_t set_Value = 0xAFFE90; // "public void set_Value(InventoryItemDescription value)"
            inline constexpr std::uintptr_t get_IsEmpty = 0xAFFDE0; // "public bool get_IsEmpty()"
        }
    } // namespace VehicleInventoryItemModel

    namespace VehicleInventoryModel { // "Models.Models.InventoryModel.VehicleInventoryModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t startLinesCount = 0x20; // "int"
            inline constexpr std::uintptr_t additionalLinesModel = 0x28; // "IPrimitiveModel<int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_LinesCount = 0x4948D70; // "public override int get_LinesCount()"
        }
    } // namespace VehicleInventoryModel

    namespace VehicleLeaveModel { // "Models.Models.VehicleLeave.VehicleLeaveModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t endTs = 0x10; // "IPrimitiveData<long>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsActive = 0x48CE260; // "public bool get_IsActive()"
            inline constexpr std::uintptr_t get_EndTs = 0x48CE210; // "public long get_EndTs()"
            inline constexpr std::uintptr_t Start = 0x48CE0E0; // "public void Start(long now)"
            inline constexpr std::uintptr_t Stop = 0x48CE180; // "public void Stop()"
        }
    } // namespace VehicleLeaveModel

    namespace VehicleLeaveRequestSystem { // "Models.Systems.VehicleLeaveRequestSystem (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x4371860; // "protected override void Tick(ITick tick)"
        }
    } // namespace VehicleLeaveRequestSystem

    namespace VehicleLinksTickDataModel { // "Models.Models.TickDataModels.Vehicle.VehicleLinksTickDataModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t WheelsAABBMinX = 0x10; // "float"
            inline constexpr std::uintptr_t WheelsAABBMinY = 0x14; // "float"
            inline constexpr std::uintptr_t WheelsAABBMinZ = 0x18; // "float"
            inline constexpr std::uintptr_t WheelsAABBMaxX = 0x1C; // "float"
            inline constexpr std::uintptr_t WheelsAABBMaxY = 0x20; // "float"
            inline constexpr std::uintptr_t WheelsAABBMaxZ = 0x24; // "float"
            inline constexpr std::uintptr_t WheelsLinkDirectionX = 0x28; // "float"
            inline constexpr std::uintptr_t WheelsLinkDirectionY = 0x2C; // "float"
            inline constexpr std::uintptr_t WheelsLinkDirectionZ = 0x30; // "float"
        }
    } // namespace VehicleLinksTickDataModel

    namespace VehicleLootClientModel { // "Game.Battle.Entities.VehicleLoot.VehicleLootClientModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t DataState = 0x10; // "EntityDataStateModel"
            inline constexpr std::uintptr_t MovementTimeline = 0x18; // "MovementTimeline"
            inline constexpr std::uintptr_t Position = 0x20; // "SetMovementModel"
            inline constexpr std::uintptr_t SleepState = 0x28; // "SleepStateSimpleDotPhysicsModel"
        }
    } // namespace VehicleLootClientModel

    namespace VehicleLootData { // "Models.Data.VehicleLoot.VehicleLootData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t SpawnTickIndex = 0x20; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t X = 0x28; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t Y = 0x30; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t Z = 0x38; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t HasCargo = 0x40; // "IPrimitiveData<bool>"
        }
    } // namespace VehicleLootData

    namespace VehicleLootDescription { // "Models.References.Vehicle.VehicleLootDescription (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t get_InteractDescription = 0x407E270; // "public static InteractDescription get_InteractDescription()"
            inline constexpr std::uintptr_t get_InteractPosition = 0x407E300; // "public static Vector3 get_InteractPosition()"
            inline constexpr std::uintptr_t GetVehicleLootInventoryCargoInventorySlotEntityId = 0x407E240; // "public static int GetVehicleLootInventoryCargoInventorySlotEntityId(VehicleLootEntityInventoryModel lootInventoryModel, CargoInventorySlotDescription slotDescription)"
            inline constexpr std::uintptr_t GetVehicleLootInventoryCargoInventorySlotEntityId_2 = 0x407E220; // "public static int GetVehicleLootInventoryCargoInventorySlotEntityId(int lootInventoryEntityId, CargoInventorySlotDescription slotDescription)"
        }
    } // namespace VehicleLootDescription

    namespace VehicleLootDialogUpdater { // "Game.Battle.VehicleLoot.VehicleLootDialogUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t updaters = 0x20; // "List<IUpdater>"
            inline constexpr std::uintptr_t selectedCargoModel = 0x28; // "SelectedCargoModel"
            inline constexpr std::uintptr_t trunkDisposableContent = 0x30; // "IDisposable"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xD5D4C0; // "public VehicleLootDialogUpdater Init(CurrentInventoryModel.VehicleLoot currentInventoryModel, GlobalModel globalModel, List<IUpdater> mainInputUpdaters, GlobalScreenContent globalScreenContent, BattleScreenContent battleScreenContent, UpdaterPool updaterPool, Transform canvasParent, DeviceModel deviceModel, BattleModel battleModel, GlobalUISoundModel uiSoundModel, InteractRaycastModel interactRaycastModel, InputActions.BattleActions actions, PersonalNotificationModel notificationModel, Camera uiCamera, IRegisterDisposable registerDisposable)"
            inline constexpr std::uintptr_t Dispose = 0xD5D400; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0x94CF50; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace VehicleLootDialogUpdater

    namespace VehicleLootEnabledViewUpdater { // "Game.Battle.Entities.VehicleLoot.VehicleLootEnabledViewUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t view = 0x20; // "VehicleLootView"
            inline constexpr std::uintptr_t dataState = 0x28; // "EntityDataStateModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0x9F7740; // "public VehicleLootEnabledViewUpdater Init(VehicleLootView view, EntityDataStateModel dataState)"
            inline constexpr std::uintptr_t Dispose = 0x92B5C0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xAE1700; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace VehicleLootEnabledViewUpdater

    namespace VehicleLootEntityInventoryData { // "Models.Data.VehicleLoot.VehicleLootEntityInventoryData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Inventory = 0x20; // "InventoryData"
            inline constexpr std::uintptr_t InventoryRevealId = 0x28; // "InventoryRevealIdData"
            inline constexpr std::uintptr_t CargoInventory = 0x30; // "CargoInventoryData"
            inline constexpr std::uintptr_t OwnerNickname = 0x38; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t OwnerClanTag = 0x40; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t PublicId = 0x48; // "PublicIdData"
            inline constexpr std::uintptr_t DynamicLineCount = 0x50; // "IPrimitiveData<int>"
        }
    } // namespace VehicleLootEntityInventoryData

    namespace VehicleLootEntityInventoryModel { // "Models.Models.VehicleLootEntityInventory.VehicleLootEntityInventoryModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Id = 0x10; // "int"
            inline constexpr std::uintptr_t Inventory = 0x18; // "IInventoryModel"
            inline constexpr std::uintptr_t InventoryRevealIdModel = 0x20; // "InventoryRevealIdModel"
            inline constexpr std::uintptr_t CargoInventoryModel = 0x28; // "CargoInventoryModel"
            inline constexpr std::uintptr_t OwnerNickname = 0x30; // "IPrimitiveModel<string>"
            inline constexpr std::uintptr_t OwnerClanTag = 0x38; // "IPrimitiveModel<string>"
            inline constexpr std::uintptr_t PublicId = 0x40; // "IPrimitiveModel<long>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t IsEmpty = 0x48A6C30; // "public bool IsEmpty()"
        }
    } // namespace VehicleLootEntityInventoryModel

    namespace VehicleLootEntityModel { // "Game.Battle.EntityModel.VehicleLoot.VehicleLootEntityModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ServerModel = 0x18; // "VehicleLootModel"
            inline constexpr std::uintptr_t ClientModel = 0x20; // "VehicleLootClientModel"
        }
    } // namespace VehicleLootEntityModel

    namespace VehicleLootInventoryEntityModel { // "Game.Battle.EntityModel.VehicleLoot.VehicleLootInventoryEntityModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ServerModel = 0x18; // "VehicleLootEntityInventoryModel"
        }
    } // namespace VehicleLootInventoryEntityModel

    namespace VehicleLootModel { // "Models.Models.VehicleLootModel.VehicleLootModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Id = 0x10; // "int"
            inline constexpr std::uintptr_t SpawnTickIndex = 0x18; // "IPrimitiveModel<int>"
            inline constexpr std::uintptr_t Transform = 0x20; // "ITransformModel"
            inline constexpr std::uintptr_t InteractPositionModel = 0x28; // "IPositionModel"
            inline constexpr std::uintptr_t LootChanged = 0x30; // "bool"
            inline constexpr std::uintptr_t HasCargo = 0x38; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t PhysicsSource = 0x40; // "ISimpleDotPhysicsSourceModel"
            inline constexpr std::uintptr_t PhysicsState = 0x48; // "ISimpleDotPhysicsStateModel"
            inline constexpr std::uintptr_t PhysicsAwakeObserver = 0x50; // "PhysicsAwakeObserverModel"
        }
    } // namespace VehicleLootModel

    namespace VehicleLootModelUpdater { // "Game.Battle.Entities.VehicleLoot.VehicleLootModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t client = 0x20; // "VehicleLootClientModel"
            inline constexpr std::uintptr_t noDataUpdaters = 0x28; // "List<IUpdater>"
            inline constexpr std::uintptr_t dataUpdaters = 0x30; // "List<IUpdater>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xAE1810; // "public VehicleLootModelUpdater Init(VehicleLootEntityModel entityModel, IDataTickModel dataTickModel, TimeModel time, UpdaterPool updaterPool, IRegisterDisposable registerDisposable)"
            inline constexpr std::uintptr_t Dispose = 0xAE1770; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xAE1BB0; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace VehicleLootModelUpdater

    namespace VehicleLootPositionViewUpdater { // "Game.Battle.Entities.VehicleLoot.VehicleLootPositionViewUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t positionModel = 0x20; // "IPositionModel"
            inline constexpr std::uintptr_t view = 0x28; // "VehicleLootView"
            inline constexpr std::uintptr_t position = 0x30; // "Vector3"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xAE1CB0; // "public VehicleLootPositionViewUpdater Init(IPositionModel positionModel, VehicleLootView view)"
            inline constexpr std::uintptr_t Dispose = 0x92B5C0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xAE1D10; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace VehicleLootPositionViewUpdater

    namespace VehicleLootTargetActions { // "Game.Battle.Entities.VehicleLoot.VehicleLootTargetActions (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleModel = 0x10; // "BattleModel"
            inline constexpr std::uintptr_t battleInputModel = 0x18; // "BattleInputModel"
            inline constexpr std::uintptr_t personalNotificationModel = 0x20; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t uiSoundModel = 0x28; // "GlobalUISoundModel"
            inline constexpr std::uintptr_t entityModel = 0x30; // "VehicleLootEntityModel"
            inline constexpr std::uintptr_t entityId = 0x38; // "int"
            inline constexpr std::uintptr_t unavailableKeys = 0x40; // "UnavailableTargetActionsKeys"
            inline constexpr std::uintptr_t becomeRobberNotificationModel = 0x48; // "BecomeRobberNotificationModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x50; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t observerRequestModel = 0x58; // "ObserverRequestModel"
            inline constexpr std::uintptr_t Open = 0x60; // "ITargetAction"
            inline constexpr std::uintptr_t Arrest = 0x68; // "ITargetAction"
            inline constexpr std::uintptr_t UnavailableRole = 0x70; // "ITargetAction"
        }
        namespace Methods {
            inline constexpr std::uintptr_t UnavailableWithHighlightBecomeRobber = 0xAE2720; // "private void UnavailableWithHighlightBecomeRobber()"
            inline constexpr std::uintptr_t UnavailableOpenLootTrunk = 0xAE2300; // "private void UnavailableOpenLootTrunk()"
            inline constexpr std::uintptr_t UnavailableTakeCargoTrunk = 0xAE24E0; // "private void UnavailableTakeCargoTrunk()"
            inline constexpr std::uintptr_t Unavailable = 0x9CDF30; // "private void Unavailable(LocalizedString invalidNotification, PersonalNotificationActionIds id)"
            inline constexpr std::uintptr_t ArrestAction = 0xAE1E30; // "private void ArrestAction()"
            inline constexpr std::uintptr_t OpenLoot = 0xAE2170; // "private void OpenLoot()"
            inline constexpr std::uintptr_t TakeCargo = 0xAE2230; // "private void TakeCargo()"
            inline constexpr std::uintptr_t CanOpenLoot = 0xAE1F50; // "private bool CanOpenLoot()"
            inline constexpr std::uintptr_t CanTakeCargo = 0xAE2030; // "private bool CanTakeCargo()"
        }
    } // namespace VehicleLootTargetActions

    namespace VehicleLootTargetProvider { // "Game.Battle.EntityModel.VehicleLoot.VehicleLootTargetProvider (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t targetActions = 0x20; // "VehicleLootTargetActions"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x28; // "IBattleEntitiesModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t GetTargetAction = 0xBFD290; // "protected override ITargetAction GetTargetAction()"
        }
    } // namespace VehicleLootTargetProvider

    namespace VehicleLootView { // "Game.Battle.EntityModel.VehicleLoot.VehicleLootView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t TargetObjectView = 0x20; // "TargetObjectView"
            inline constexpr std::uintptr_t TimerParent = 0x28; // "Transform"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetPosition = 0xBFDC30; // "public void SetPosition(Vector3 position, Quaternion orientation)"
        }
    } // namespace VehicleLootView

    namespace VehicleLootViewDescriptions { // "Game.Battle.EntityModel.VehicleLoot.VehicleLootViewDescriptions (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t TriggerMarkerTime = 0x18; // "long"
            inline constexpr std::uintptr_t prefab = 0x20; // "AssetReference"
            inline constexpr std::uintptr_t Title = 0x28; // "LocalizedString"
            inline constexpr std::uintptr_t VehicleLootDropSound = 0x30; // "Event"
            inline constexpr std::uintptr_t View = 0x38; // "PooledLoadedComponentContent<VehicleLootView>"
        }
    } // namespace VehicleLootViewDescriptions

    namespace VehicleLootViewUpdater { // "Game.Battle.EntityModel.VehicleLoot.VehicleLootViewUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t updaters = 0x20; // "List<IUpdater>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xBFD530; // "public VehicleLootViewUpdater Init(VehicleLootEntityModel model, GlobalModel globalModel, BattleModel battleModel, ITargetSubsystem targetSubsystem, VehicleLootView view, GlobalScreenContent globalScreenContent, BattleScreenContent battleScreenContent, UpdaterPool updaterPool, IRegisterDisposable registerDisposable)"
            inline constexpr std::uintptr_t Dispose = 0xBFD4D0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0x94CF50; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace VehicleLootViewUpdater

    namespace VehicleMapMarkerModel { // "Game.Battle.Map.VehicleMapMarkerModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t getUserColorType = 0x30; // "Func<UserColorType>"
            inline constexpr std::uintptr_t InVehiclePartyIndexes = 0x38; // "List<int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_UserColorType = 0x9AA5D0; // "public UserColorType get_UserColorType()"
        }
    } // namespace VehicleMapMarkerModel

    namespace VehicleMapMarkerView { // "Game.Battle.Map.VehicleMapMarkerView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t colorPartyViewDescription = 0x70; // "ColorPartyViewDescription"
            inline constexpr std::uintptr_t partyArrowsSpacing = 0x78; // "float"
            inline constexpr std::uintptr_t seatsContainer = 0x80; // "GameObject"
            inline constexpr std::uintptr_t seatViews = 0x88; // "List<SpriteRenderer>"
            inline constexpr std::uintptr_t ActiveSeatRenderers = 0x90; // "List<SpriteRenderer>"
            inline constexpr std::uintptr_t activeCount = 0x98; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetSeats = 0x9C64A0; // "public void SetSeats(List<int> seats)"
            inline constexpr std::uintptr_t RecenterMarkers = 0x9C6130; // "private void RecenterMarkers()"
            inline constexpr std::uintptr_t SetMarkersPositions = 0x9C6280; // "private void SetMarkersPositions()"
        }
    } // namespace VehicleMapMarkerView

    namespace VehicleMapTransformModel { // "Models.Models.VehicleMapTransform.VehicleMapTransformModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t x = 0x10; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t z = 0x18; // "IPrimitiveData<int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_X = 0x48A7300; // "public int get_X()"
            inline constexpr std::uintptr_t get_Z = 0x48A7350; // "public int get_Z()"
            inline constexpr std::uintptr_t Set = 0x48A71B0; // "public void Set(int x, int z)"
            inline constexpr std::uintptr_t UpdateData = 0x48A7290; // "private void UpdateData(IPrimitiveData<int> data, int value)"
        }
    } // namespace VehicleMapTransformModel

    namespace VehicleMapTransformUpdateModel { // "Models.Models.VehicleMapTransformUpdate.VehicleMapTransformUpdateModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t locationBoundsModel = 0x10; // "LocationBoundsModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t UpdateVehicleMapTransform = 0x48A7430; // "public void UpdateVehicleMapTransform(VehicleTransformModel vehicleTransformModel, VehicleMapTransformModel vehicleMapTransformModel)"
            inline constexpr std::uintptr_t CalculateVehicleMapTransformParams = 0x48A73A0; // "public void CalculateVehicleMapTransformParams(VehicleTransformModel vehicleTransformModel, out int x, out int z)"
        }
    } // namespace VehicleMapTransformUpdateModel

    namespace VehicleMarkerRootView { // "Game.Battle.EntityModel.Vehicles.Views.VehicleMarkerRootView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Center = 0x20; // "Transform"
            inline constexpr std::uintptr_t collider = 0x28; // "Collider"
            inline constexpr std::uintptr_t raySize = 0x30; // "Nullable<float>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t GetPosition = 0xBFDC90; // "public Vector3 GetPosition()"
        }
    } // namespace VehicleMarkerRootView

    namespace VehicleModel { // "Models.Models.Vehicle.VehicleModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Id = 0x10; // "int"
            inline constexpr std::uintptr_t BodyId = 0x14; // "PhysicsBodyId"
            inline constexpr std::uintptr_t HasTrunk = 0x1C; // "bool"
            inline constexpr std::uintptr_t GroupType = 0x1D; // "VehicleGroupType"
            inline constexpr std::uintptr_t Interact = 0x20; // "VehicleInteractDescription"
            inline constexpr std::uintptr_t Transform = 0x28; // "VehicleTransformModel"
            inline constexpr std::uintptr_t Seats = 0x30; // "VehicleSeatsModel"
            inline constexpr std::uintptr_t Engine = 0x38; // "VehicleEngineModel"
            inline constexpr std::uintptr_t CharacterOwner = 0x40; // "VehicleOwnerModel"
            inline constexpr std::uintptr_t PartyOwner = 0x48; // "PartyVehicleOwnerModel"
            inline constexpr std::uintptr_t OwnerRole = 0x50; // "IPrimitiveModel<PlayerRoleDescription>"
            inline constexpr std::uintptr_t Exit = 0x58; // "VehicleExitModel"
            inline constexpr std::uintptr_t LinearVelocity = 0x60; // "VelocityModel"
            inline constexpr std::uintptr_t AngularVelocity = 0x68; // "VelocityModel"
            inline constexpr std::uintptr_t Sleep = 0x70; // "VehicleSleepModel"
            inline constexpr std::uintptr_t PhysicsAwakeObserver = 0x78; // "PhysicsAwakeObserverModel"
            inline constexpr std::uintptr_t SubStepSnapshots = 0x80; // "PhysicsEntitySubStepSnapshotsModel"
            inline constexpr std::uintptr_t IsWarped = 0x88; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t IsUnowned = 0x90; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t Water = 0x98; // "VehicleWaterModel"
            inline constexpr std::uintptr_t ColliderShapeRelativeToCenterOfMass = 0xA0; // "CompoundShape"
            inline constexpr std::uintptr_t BoundingBoxLocalPositionRelativeToCenterOfMass = 0xA8; // "Vector3"
            inline constexpr std::uintptr_t BoundingBoxSize = 0xB4; // "Vector3"
            inline constexpr std::uintptr_t InertiaBoxShapeSize = 0xC0; // "Vector3"
            inline constexpr std::uintptr_t TeleportRequest = 0xD0; // "RequestModel<ValueTuple<Vector3, Quaternion, Vector3, Vector3>>"
            inline constexpr std::uintptr_t WarpedEvent = 0xD8; // "IEventModel"
            inline constexpr std::uintptr_t HasFreeCargoSlot = 0xE0; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t HasCargo = 0xE8; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t CanRefillCopAmmo = 0xF0; // "bool"
            inline constexpr std::uintptr_t TrunkPosition = 0xF8; // "VehicleTrunkPositionModel"
            inline constexpr std::uintptr_t TrunkLocalPosition = 0x100; // "Vector3"
            inline constexpr std::uintptr_t TrunkOpenedModel = 0x110; // "InteractableObjectOpenedModel"
            inline constexpr std::uintptr_t VehicleType = 0x118; // "VehicleTypeDescription"
            inline constexpr std::uintptr_t IsRented = 0x120; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t LeaveSafeZoneFlags = 0x128; // "int"
            inline constexpr std::uintptr_t RadioStation = 0x130; // "RadioStationModel"
            inline constexpr std::uintptr_t DirtLevel = 0x138; // "VehicleDirtLevelModel"
            inline constexpr std::uintptr_t ClanBattleTeamOwner = 0x140; // "ClanBattleVehicleTeamOwnerModel"
            inline constexpr std::uintptr_t VerticalDistanceFromPivotToGroundInRest = 0x148; // "float"
            inline constexpr std::uintptr_t VerticalLocalCenterFromGroundInRestRelativeToPivot = 0x14C; // "float"
            inline constexpr std::uintptr_t TrunkBreachModel = 0x150; // "BreachStateEntityModel"
            inline constexpr std::uintptr_t HitBoxAccess = 0x158; // "IHitBoxAccessModel"
            inline constexpr std::uintptr_t TickData = 0x160; // "VehicleTickDataModel"
        }
    } // namespace VehicleModel

    namespace VehicleMovementAndOrientationUpdater { // "Game.Battle.Entities.Vehicles.Updaters.VehicleMovementAndOrientationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsDataModel = 0x10; // "VehiclePhysicsDataModel"
            inline constexpr std::uintptr_t movementModel = 0x18; // "SetMovementModel"
            inline constexpr std::uintptr_t rotationModel = 0x20; // "VehicleRotationModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xAE2EC0; // "public void Update()"
        }
    } // namespace VehicleMovementAndOrientationUpdater

    namespace VehicleNotificationDialogModelUpdater { // "Game.Global.PopupNotificationDialog.VehicleNotificationDialogModelUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t regionUserModel = 0x10; // "RegionUserModel"
            inline constexpr std::uintptr_t modalDialogModel = 0x18; // "ModalDialogModel"
            inline constexpr std::uintptr_t globalScreenContent = 0x20; // "GlobalScreenContent"
            inline constexpr std::uintptr_t isActive = 0x28; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x35BE980; // "public void Update()"
            inline constexpr std::uintptr_t OpenTrunkClearingDialog = 0x35BE810; // "private void OpenTrunkClearingDialog()"
        }
    } // namespace VehicleNotificationDialogModelUpdater

    namespace VehicleOwnerExtensions { // "Models.Utils.Extensions.Vehicles.VehicleOwnerExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t GetCharacterOwnerData = 0x3971A20; // "public static void GetCharacterOwnerData(ICharacterSlotsModel characterSlotsModel, WorldEntitiesModel worldEntitiesModel, int vehicleEntityId, out int vehicleOwnerEntityId, out PlayerRoleDescription vehicleOwnerRole)"
        }
    } // namespace VehicleOwnerExtensions

    namespace VehicleOwnerModel { // "Models.Models.VehicleOwner.VehicleOwnerModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ownerPublicId = 0x10; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t emptyPublicId = 0x18; // "long"
            inline constexpr std::uintptr_t emptyPrivateId = 0x20; // "string"
            inline constexpr std::uintptr_t ownerPrivateId = 0x28; // "string"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_OwnerPrivateId = 0x7AA000; // "public string get_OwnerPrivateId()"
            inline constexpr std::uintptr_t get_OwnerPublicId = 0x48A7720; // "public long get_OwnerPublicId()"
            inline constexpr std::uintptr_t get_IsHaveOwner = 0x48A76D0; // "public bool get_IsHaveOwner()"
            inline constexpr std::uintptr_t Set = 0x48A75F0; // "public void Set(string ownerPrivateId, long ownerPublicId)"
            inline constexpr std::uintptr_t Clear = 0x48A7570; // "public void Clear()"
        }
    } // namespace VehicleOwnerModel

    namespace VehicleOwnersModel { // "Game.Battle.VehicleOwnersModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t entityIdByPublicId = 0x10; // "Dictionary<long, int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t AddVehicle = 0xC5DD80; // "public void AddVehicle(long ownerPublicId, int vehicleEntityId)"
            inline constexpr std::uintptr_t RemoveVehicle = 0xC5DDF0; // "public void RemoveVehicle(long ownerPublicId)"
            inline constexpr std::uintptr_t TryGet = 0xC5DE50; // "public bool TryGet(long publicId, out int vehicleEntityId)"
        }
    } // namespace VehicleOwnersModel

    namespace VehiclePerformedInputActionUpdater { // "Game.Global.Inputs.VehiclePerformedInputActionUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t inputModel = 0x10; // "InputModel"
            inline constexpr std::uintptr_t inputAction = 0x18; // "InputAction"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x20; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t wasPressedOutOfVehicle = 0x28; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x92AEE0; // "public void Update()"
        }
    } // namespace VehiclePerformedInputActionUpdater

    namespace VehiclePhysicsDataModel { // "Game.Battle.Entities.Vehicles.Models.VehiclePhysicsDataModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t CenterOfMassPosition = 0x10; // "Vector3"
            inline constexpr std::uintptr_t CenterOfMassOrientation = 0x1C; // "Quaternion"
            inline constexpr std::uintptr_t PivotPosition = 0x2C; // "Vector3"
            inline constexpr std::uintptr_t PivotOrientation = 0x38; // "Quaternion"
            inline constexpr std::uintptr_t LinearVelocity = 0x48; // "Vector3"
            inline constexpr std::uintptr_t AngularVelocity = 0x54; // "Vector3"
        }
    } // namespace VehiclePhysicsDataModel

    namespace VehiclePingMarkerCollidersRegistrationUpdater { // "Game.Battle.Entities.Vehicles.Updaters.VehiclePingMarkerCollidersRegistrationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleEntitiesModel = 0x10; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t pingMarkerCollidersModel = 0x18; // "PingMarkerCollidersModel"
            inline constexpr std::uintptr_t vehicleColliders = 0x20; // "HashSet<Collider>"
            inline constexpr std::uintptr_t serverId = 0x28; // "int"
            inline constexpr std::uintptr_t pingMarkTypeDescription = 0x30; // "PingMarkTypeDescription"
            inline constexpr std::uintptr_t needRegisterColliders = 0x38; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xAE3400; // "public void Update()"
            inline constexpr std::uintptr_t GetNeedRegisterColliders = 0xAE3150; // "private bool GetNeedRegisterColliders(PlayerEntityModel player)"
            inline constexpr std::uintptr_t RegisterColliders = 0xAE31C0; // "private void RegisterColliders()"
            inline constexpr std::uintptr_t UnregisterColliders = 0xAE32E0; // "private void UnregisterColliders()"
        }
    } // namespace VehiclePingMarkerCollidersRegistrationUpdater

    namespace VehicleRotationModel { // "Game.Global.Party.VehicleRotationModel (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Yaw = 0x10; // "float"
            inline constexpr std::uintptr_t Pitch = 0x14; // "float"
            inline constexpr std::uintptr_t Roll = 0x18; // "float"
        }
    } // namespace VehicleRotationModel

    namespace VehiclesClientModel { // "Game.Battle.Entities.Vehicles.Models.VehiclesClientModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t vehicles = 0x10; // "Dictionary<int, VehicleClientModel>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Values = 0xAE5560; // "public Dictionary.ValueCollection<int, VehicleClientModel> get_Values()"
            inline constexpr std::uintptr_t get_Item = 0xAE5500; // "public VehicleClientModel get_Item(int entityId)"
            inline constexpr std::uintptr_t TryGet = 0xAE5410; // "public bool TryGet(int entityId, out VehicleClientModel model)"
            inline constexpr std::uintptr_t Add = 0xAE5340; // "public void Add(int entityId, VehicleClientModel model)"
            inline constexpr std::uintptr_t Remove = 0xAE53B0; // "public void Remove(int entityId)"
        }
    } // namespace VehiclesClientModel

    namespace VehiclesCollisionPointsViewDescription { // "Game.Battle.EntityModel.Vehicles.VehiclesCollisionPointsViewDescription (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t SearchRadius = 0x18; // "float"
            inline constexpr std::uintptr_t MaxVehiclesCount = 0x1C; // "int"
            inline constexpr std::uintptr_t TerrainFilterCos = 0x20; // "float"
            inline constexpr std::uintptr_t BreakableWwiseSwitch = 0x28; // "Switch"
        }
    } // namespace VehiclesCollisionPointsViewDescription

    namespace VehiclesCollisionsModel { // "ClientCore.Models.VehiclesCollisionsModel.VehiclesCollisionsModel (Client.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t bodyIdToCollisionPointsIndex = 0x10; // "Dictionary<PhysicsBodyId, int>"
            inline constexpr std::uintptr_t collisionPoints = 0x18; // "PhysicsListData<VehicleCollisionPointData>[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_VehiclesWithCollisionPointsCount = 0xE92F20; // "public int get_VehiclesWithCollisionPointsCount()"
            inline constexpr std::uintptr_t TryGetVehicleCollisionPoints = 0xE92D30; // "public bool TryGetVehicleCollisionPoints(PhysicsBodyId vehicleBodyId, out ReadOnlySpan<VehicleCollisionPointData> collisionPoints)"
            inline constexpr std::uintptr_t AddVehicleDefaultCollision = 0xE921D0; // "public void AddVehicleDefaultCollision(PhysicsBodyId vehicleBodyId, PhysicsBodyId anotherBodyId, in Vector3 vehicleCenterOfMassPosition, in Vector3 vehicleLinearVelocity, in Vector3 vehicleAngularVelocity, in ManifoldPoint manifoldPoint, bool inverse)"
            inline constexpr std::uintptr_t AddVehicleVehicleCollision = 0xE92560; // "public void AddVehicleVehicleCollision(PhysicsBodyId vehicleBodyId1, in Vector3 vehicleCenterOfMassPosition1, in Vector3 vehicleLinearVelocity1, in Vector3 vehicleAngularVelocity1, PhysicsBodyId vehicleBodyId2, in Vector3 vehicleCenterOfMassPosition2, in Vector3 vehicleLinearVelocity2, in Vector3 vehicleAngularVelocity2, in ManifoldPoint manifoldPoint)"
            inline constexpr std::uintptr_t AddCollisionPoint = 0xE91DE0; // "private void AddCollisionPoint(PhysicsBodyId vehicleBodyId, PhysicsBodyId anotherBodyId, float linearVelocityTowardsEachOther, float sqrLinearVelocitySideEachOther, in ManifoldPoint manifoldPoint, bool inverse)"
            inline constexpr std::uintptr_t Clear = 0xE92BD0; // "public void Clear()"
            inline constexpr std::uintptr_t ClearVehicleCollisionPoints = 0xE92B30; // "public void ClearVehicleCollisionPoints(PhysicsBodyId vehicleBodyId)"
            inline constexpr std::uintptr_t ClientCore_Models_VehiclesCollisionsModel_IVehiclesCollisionsModel_AddVehicleDefaultCollision = 0xE92CA0; // "private void ClientCore.Models.VehiclesCollisionsModel.IVehiclesCollisionsModel.AddVehicleDefaultCollision(PhysicsBodyId vehicleBodyId, PhysicsBodyId anotherBodyId, in Vector3 vehicleCenterOfMassPosition, in Vector3 vehicleLinearVelocity, in Vector3 vehicleAngularVelocity, in ManifoldPoint manifoldPoint, bool inverse)"
            inline constexpr std::uintptr_t ClientCore_Models_VehiclesCollisionsModel_IVehiclesCollisionsModel_AddVehicleVehicleCollision = 0xE92CC0; // "private void ClientCore.Models.VehiclesCollisionsModel.IVehiclesCollisionsModel.AddVehicleVehicleCollision(PhysicsBodyId vehicleBodyId1, in Vector3 vehicleCenterOfMassPosition1, in Vector3 vehicleLinearVelocity1, in Vector3 vehicleAngularVelocity1, PhysicsBodyId vehicleBodyId2, in Vector3 vehicleCenterOfMassPosition2, in Vector3 vehicleLinearVelocity2, in Vector3 vehicleAngularVelocity2, in ManifoldPoint manifoldPoint)"
        }
    } // namespace VehiclesCollisionsModel

    namespace VehicleScratch { // "Game.Battle.Entities.VehicleScratch.VehicleScratch (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ScratchPosition = 0x0; // "Vector3"
            inline constexpr std::uintptr_t ScratchLocalPosition = 0xC; // "Vector3"
            inline constexpr std::uintptr_t ScratchNormal = 0x18; // "Vector3"
            inline constexpr std::uintptr_t SurfaceType = 0x24; // "byte"
            inline constexpr std::uintptr_t Vfx = 0x28; // "IDisposableContent<ParticleSystem>"
            inline constexpr std::uintptr_t IsPlayingSfx = 0x30; // "bool"
            inline constexpr std::uintptr_t SoundScratchEndTime = 0x38; // "long"
            inline constexpr std::uintptr_t VfxScratchEndTime = 0x40; // "long"
        }
    } // namespace VehicleScratch

    namespace VehicleSeatData { // "Models.Data.Vehicle.VehicleSeatData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Occupied = 0x20; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t EntityId = 0x28; // "IPrimitiveData<int>"
        }
    } // namespace VehicleSeatData

    namespace VehicleSeatDescription { // "Models.References.Vehicle.Seat.VehicleSeatDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Type = 0x10; // "int"
            inline constexpr std::uintptr_t LocalPosition = 0x14; // "Vector3"
            inline constexpr std::uintptr_t LocalExitPosition = 0x20; // "Vector3"
            inline constexpr std::uintptr_t IsDriver = 0x2C; // "bool"
            inline constexpr std::uintptr_t CanChangeRadio = 0x2D; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t IsFlagSet = 0x36D0790; // "private bool IsFlagSet(int flag)"
        }
    } // namespace VehicleSeatDescription

    namespace VehicleSeatExtensions { // "Models.Utils.Extensions.Vehicles.VehicleSeatExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t CalculateSeatWorldPosition = 0x3971B80; // "public static void CalculateSeatWorldPosition(VehicleSeatDescription seatDescription, Vector3 vehiclePivotPosition, Quaternion vehiclePivotOrientation, out Vector3 seatWorldPosition, out Quaternion seatWorldOrientation)"
            inline constexpr std::uintptr_t TryGetDriver = 0x3971C50; // "public static bool TryGetDriver(ReadOnly.Dictionary<int, BattleCharacterModel> battleCharacters, VehicleSeatsModel seats, out BattleCharacterModel driver)"
        }
    } // namespace VehicleSeatExtensions

    namespace VehicleSeatsDescription { // "Models.References.Vehicle.Seat.VehicleSeatsDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t SeatsType = 0x20; // "VehicleSeatTypeDescription"
            inline constexpr std::uintptr_t SeatsLazy = 0x28; // "Lazy<Dictionary<VehicleSeatSlotDescription, VehicleSeatDescription>>"
            inline constexpr std::uintptr_t seatsValue = 0x30; // "ReadOnly.Dictionary<VehicleSeatSlotDescription, VehicleSeatDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Seats = 0x407FC60; // "public ReadOnly.Dictionary<VehicleSeatSlotDescription, VehicleSeatDescription> get_Seats()"
            inline constexpr std::uintptr_t GetDriverSlot = 0x407FA60; // "public VehicleSeatSlotDescription GetDriverSlot()"
        }
    } // namespace VehicleSeatsDescription

    namespace VehicleSeatSlotDescription { // "Models.References.Vehicle.Seat.VehicleSeatSlotDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x8200BF0; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t enum_id = 0x0; // "Enum<VehicleSeatSlotDescription>"
            inline constexpr std::uintptr_t Slot0 = 0x8; // "VehicleSeatSlotDescription"
            inline constexpr std::uintptr_t Slot1 = 0x10; // "VehicleSeatSlotDescription"
            inline constexpr std::uintptr_t Slot2 = 0x18; // "VehicleSeatSlotDescription"
            inline constexpr std::uintptr_t Slot3 = 0x20; // "VehicleSeatSlotDescription"
            inline constexpr std::uintptr_t Slot4 = 0x28; // "VehicleSeatSlotDescription"
            inline constexpr std::uintptr_t Slot5 = 0x30; // "VehicleSeatSlotDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Enum = 0x407EA00; // "public static ReadOnlyEnum<VehicleSeatSlotDescription> get_Enum()"
        }
    } // namespace VehicleSeatSlotDescription

    namespace VehicleSeatsModel { // "Models.Models.VehicleSeats.VehicleSeatsModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "ReferenceMapData<VehicleSeatSlotDescription, VehicleSeatData>"
            inline constexpr std::uintptr_t description = 0x18; // "ReadOnly.Dictionary<VehicleSeatSlotDescription, VehicleSeatDescription>"
            inline constexpr std::uintptr_t transform = 0x20; // "VehicleTransformModel"
            inline constexpr std::uintptr_t Type = 0x28; // "VehicleSeatTypeDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Description = 0x7E7130; // "public ReadOnly.Dictionary<VehicleSeatSlotDescription, VehicleSeatDescription> get_Description()"
            inline constexpr std::uintptr_t GetSeatSlotDescription = 0x48A7E10; // "public VehicleSeatDescription GetSeatSlotDescription(VehicleSeatSlotDescription slot)"
            inline constexpr std::uintptr_t GetFreeSeatSlotWithDriverPriority = 0x48A7D70; // "public VehicleSeatSlotDescription GetFreeSeatSlotWithDriverPriority()"
            inline constexpr std::uintptr_t GetFreePassengerSeatSlot = 0x48A7B30; // "public VehicleSeatSlotDescription GetFreePassengerSeatSlot()"
            inline constexpr std::uintptr_t GetDriverSeatSlot = 0x48A7990; // "public VehicleSeatSlotDescription GetDriverSeatSlot()"
            inline constexpr std::uintptr_t OccupySlot = 0x48A8020; // "public void OccupySlot(VehicleSeatSlotDescription slot, int entityId)"
            inline constexpr std::uintptr_t FreeSlot = 0x48A78E0; // "public void FreeSlot(VehicleSeatSlotDescription slot)"
            inline constexpr std::uintptr_t TryGetSlotEntityId = 0x48A80E0; // "public bool TryGetSlotEntityId(VehicleSeatSlotDescription slot, out int entityId)"
            inline constexpr std::uintptr_t CheckSlotOccupied = 0x48A7860; // "public bool CheckSlotOccupied(VehicleSeatSlotDescription slot)"
            inline constexpr std::uintptr_t IsHaveFreeSlots = 0x48A7E70; // "public bool IsHaveFreeSlots()"
            inline constexpr std::uintptr_t CalculateSeatWorldPosition = 0x48A7770; // "public void CalculateSeatWorldPosition(VehicleSeatSlotDescription slot, out Vector3 seatWorldPosition, out Quaternion seatWorldOrientation)"
        }
    } // namespace VehicleSeatsModel

    namespace VehicleSeatTypeDescription { // "Models.References.Vehicle.Seat.VehicleSeatTypeDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x8200D88; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace Fields {
            inline constexpr std::uintptr_t DriverCharacterAnimatorState = 0x20; // "BattleCharacterAnimatorStateDescription"
            inline constexpr std::uintptr_t DriverStartingEngineCharacterAnimatorState = 0x28; // "BattleCharacterAnimatorStateDescription"
            inline constexpr std::uintptr_t PassengerCharacterAnimatorState = 0x30; // "BattleCharacterAnimatorStateDescription"
        }
        namespace StaticFields {
            inline constexpr std::uintptr_t enum_id = 0x0; // "Enum<VehicleSeatTypeDescription>"
            inline constexpr std::uintptr_t DefaultCar = 0x8; // "VehicleSeatTypeDescription"
            inline constexpr std::uintptr_t DefaultHelicopter = 0x10; // "VehicleSeatTypeDescription"
            inline constexpr std::uintptr_t SportCar = 0x18; // "VehicleSeatTypeDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Enum = 0x407F260; // "public static ReadOnlyEnum<VehicleSeatTypeDescription> get_Enum()"
        }
    } // namespace VehicleSeatTypeDescription

    namespace VehicleSeatTypeViewDescription { // "Game.Battle.EntityModel.Vehicles.VehicleSeatTypeViewDescription (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Identified = 0x10; // "IdentifiedProperty<VehicleSeatTypeDescription>"
            inline constexpr std::uintptr_t driverSittingInVehicleAnimationIndex = 0x18; // "int"
            inline constexpr std::uintptr_t leftSidePassengerSittingInVehicleAnimationIndex = 0x1C; // "int"
            inline constexpr std::uintptr_t rightSidePassengerSittingInVehicleAnimationIndex = 0x20; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Id = 0xBFDFC0; // "public string get_Id()"
            inline constexpr std::uintptr_t GetSitIndexByType = 0xBFDF90; // "public int GetSitIndexByType(int seatType)"
        }
    } // namespace VehicleSeatTypeViewDescription

    namespace VehicleSettingsOverrideExtensions { // "Models.Utils.Extensions.Vehicles.VehicleSettingsOverrideExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t SerializeCurve = 0x3972170; // "public static byte[] SerializeCurve(Curve data)"
            inline constexpr std::uintptr_t DeserializeCurve = 0x3971E50; // "public static Curve DeserializeCurve(byte[] rawData)"
            inline constexpr std::uintptr_t SerializeCarTransmissionGears = 0x3971F30; // "public static byte[] SerializeCarTransmissionGears(List<CarTransmissionGearDescription> data)"
            inline constexpr std::uintptr_t DeserializeCarTransmissionGears = 0x3971D10; // "public static List<CarTransmissionGearDescription> DeserializeCarTransmissionGears(byte[] rawData)"
            inline constexpr std::uintptr_t SerializeCarUpgrades_T_inst_1 = 0x126C510; // "VehicleSettingsOverrideExtensions.SerializeCarUpgrades<object>"
            inline constexpr std::uintptr_t SerializeCarUpgrades_T_inst_2 = 0x126C2C0; // "VehicleSettingsOverrideExtensions.SerializeCarUpgrades<__Il2CppFullySharedGenericType>"
            inline constexpr std::uintptr_t DeserializeCarUpgrades_T_inst_1 = 0x126C170; // "VehicleSettingsOverrideExtensions.DeserializeCarUpgrades<object>"
            inline constexpr std::uintptr_t DeserializeCarUpgrades_T_inst_2 = 0x126C020; // "VehicleSettingsOverrideExtensions.DeserializeCarUpgrades<__Il2CppFullySharedGenericType>"
        }
    } // namespace VehicleSettingsOverrideExtensions

    namespace VehicleSkinExtensions { // "Models.Utils.Extensions.VehicleSkinExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t CheckSelectSkin = 0x3972350; // "public static bool CheckSelectSkin(CarDescription carDescription, IOwnedItemsModel<CarDescription> ownedCarsModel)"
            inline constexpr std::uintptr_t CheckSelectSkin_2 = 0x3972430; // "public static bool CheckSelectSkin(HelicopterDescription helicopterDescription, IOwnedItemsModel<HelicopterDescription> ownedHelicoptersModel)"
        }
    } // namespace VehicleSkinExtensions

    namespace VehicleSleepModel { // "Models.Models.VehicleSleep.VehicleSleepModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t sleepCounter = 0x10; // "IPrimitiveData<int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Counter = 0x48A81B0; // "public int get_Counter()"
            inline constexpr std::uintptr_t set_Counter = 0x48A8200; // "public void set_Counter(int value)"
        }
    } // namespace VehicleSleepModel

    namespace VehicleSleepTickDataModel { // "Models.Models.TickDataModels.Vehicle.VehicleSleepTickDataModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsSleeping = 0x10; // "bool"
        }
    } // namespace VehicleSleepTickDataModel

    namespace VehicleSlotTrunkInventoriesItemsCountData { // "Models.Data.Vehicle.VehicleSlotTrunkInventoriesItemsCountData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t inventoryItemsCount = 0x20; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t cargoInventoryItemsCount = 0x28; // "IPrimitiveData<int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_InventoryItemsCount = 0x4A9E940; // "public int get_InventoryItemsCount()"
            inline constexpr std::uintptr_t set_InventoryItemsCount = 0x4A9E9F0; // "public void set_InventoryItemsCount(int value)"
            inline constexpr std::uintptr_t get_CargoInventoryItemsCount = 0x4A9E8F0; // "public int get_CargoInventoryItemsCount()"
            inline constexpr std::uintptr_t set_CargoInventoryItemsCount = 0x4A9E990; // "public void set_CargoInventoryItemsCount(int value)"
        }
    } // namespace VehicleSlotTrunkInventoriesItemsCountData

    namespace VehicleSpawnConfig { // "Models.References.Location.LocationVehiclesSpawnPoints.VehicleSpawnConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t SpawnDelay = 0x10; // "long"
        }
    } // namespace VehicleSpawnConfig

    namespace VehicleSpawnerEntityMarkerUpdater { // "Game.Battle.EntityModel.VehicleSpawner.VehicleSpawnerEntityMarkerUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t tutorialModel = 0x10; // "TutorialModel"
            inline constexpr std::uintptr_t markersModel = 0x18; // "Markers3DModel"
            inline constexpr std::uintptr_t markerModel = 0x20; // "Marker3DIconModel"
            inline constexpr std::uintptr_t isActive = 0x28; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xBFE040; // "public void Update()"
        }
    } // namespace VehicleSpawnerEntityMarkerUpdater

    namespace VehicleSpawnerModel { // "Models.Models.VehicleSpawner.VehicleSpawnerModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t EntityId = 0x10; // "int"
            inline constexpr std::uintptr_t VehicleType = 0x18; // "VehicleTypeDescription"
            inline constexpr std::uintptr_t Position = 0x20; // "Vector3"
            inline constexpr std::uintptr_t VehicleSpawnerPoints = 0x30; // "VehicleSpawnerPointsModel"
        }
    } // namespace VehicleSpawnerModel

    namespace VehicleSpawnerPointsModel { // "Models.Models.VehicleSpawnerPoints.VehicleSpawnerPointsModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t pointsTransforms = 0x10; // "IReadOnlyList<OrientedPoint>"
            inline constexpr std::uintptr_t pointIndex = 0x18; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t GetPositionAndOrientation = 0x48A8310; // "public ValueTuple<Vector3, Quaternion> GetPositionAndOrientation()"
        }
    } // namespace VehicleSpawnerPointsModel

    namespace VehicleSpawnerTargetActions { // "Game.Battle.EntityModel.VehicleSpawner.VehicleSpawnerTargetActions (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleEntitiesModel = 0x10; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t entityId = 0x18; // "int"
            inline constexpr std::uintptr_t targetActionsKeys = 0x20; // "TargetActionsLocalization"
            inline constexpr std::uintptr_t notificationKeys = 0x28; // "NotificationKeys"
            inline constexpr std::uintptr_t inputActions = 0x30; // "InputActions"
            inline constexpr std::uintptr_t globalScreenContent = 0x38; // "GlobalScreenContent"
            inline constexpr std::uintptr_t battleModel = 0x40; // "BattleModel"
            inline constexpr std::uintptr_t globalModel = 0x48; // "GlobalModel"
            inline constexpr std::uintptr_t battleConnection = 0x50; // "IRoomConnection"
            inline constexpr std::uintptr_t locationVehicle = 0x58; // "LocationVehicleSpawnPointDescription"
            inline constexpr std::uintptr_t personalNotification = 0x60; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t interactEntityModel = 0x68; // "IInteractEntityModel"
            inline constexpr std::uintptr_t isInProcess = 0x70; // "bool"
            inline constexpr std::uintptr_t IsCarSpawner = 0x71; // "bool"
            inline constexpr std::uintptr_t RentAction = 0x78; // "TargetAction"
            inline constexpr std::uintptr_t SpawnAction = 0x80; // "TargetAction"
        }
        namespace Methods {
            inline constexpr std::uintptr_t OnRent = 0xBFEBB0; // "private void OnRent()"
            inline constexpr std::uintptr_t TryShowRentCodex = 0xBFF230; // "private void TryShowRentCodex()"
            inline constexpr std::uintptr_t SendRentMessage = 0xBFECE0; // "private void SendRentMessage()"
            inline constexpr std::uintptr_t Unavailable = 0xBFF880; // "private void Unavailable(LocalizedString invalidNotification, PersonalNotificationActionIds id)"
            inline constexpr std::uintptr_t CanSpawn = 0xBFE5E0; // "public bool CanSpawn()"
            inline constexpr std::uintptr_t SpawnCar = 0xBFEEF0; // "private void SpawnCar()"
            inline constexpr std::uintptr_t UnavailableCar = 0xBFF400; // "private void UnavailableCar(LocalizedString invalidNotification, PersonalNotificationActionIds id)"
            inline constexpr std::uintptr_t UnavailableSpawnCar = 0xBFF420; // "private void UnavailableSpawnCar(PersonalNotificationActionIds id)"
            inline constexpr std::uintptr_t CanSpawnCar = 0xBFE320; // "private bool CanSpawnCar()"
            inline constexpr std::uintptr_t SpawnHelicopter = 0xBFF090; // "private void SpawnHelicopter()"
            inline constexpr std::uintptr_t UnavailableHelicopter = 0xBFF410; // "private void UnavailableHelicopter(LocalizedString invalidNotification, PersonalNotificationActionIds id)"
            inline constexpr std::uintptr_t UnavailableSpawnHelicopter = 0xBFF650; // "private void UnavailableSpawnHelicopter(PersonalNotificationActionIds id)"
            inline constexpr std::uintptr_t CanSpawnHelicopter = 0xBFE480; // "private bool CanSpawnHelicopter()"
            inline constexpr std::uintptr_t CheckCooldown = 0xBFE8C0; // "private bool CheckCooldown(BattleCharacterModel battleCharacter)"
            inline constexpr std::uintptr_t CheckCharacterIsCapable = 0xBFE850; // "private bool CheckCharacterIsCapable(BattleCharacterModel player)"
            inline constexpr std::uintptr_t SendSpawnCarMessage = 0xBFED90; // "private void SendSpawnCarMessage()"
            inline constexpr std::uintptr_t SendSpawnHelicopterMessage = 0xBFEE40; // "private void SendSpawnHelicopterMessage()"
            inline constexpr std::uintptr_t GetHasVehicleToSpawn = 0xBFE950; // "private bool GetHasVehicleToSpawn(BattleCharacterModel battleCharacterModel, VehicleTypeDescription vehicleTypeDescription)"
            inline constexpr std::uintptr_t HasSummonVehicle = 0xBFEB30; // "private static bool HasSummonVehicle(BattleCharacterModel player, VehicleTypeDescription vehicleTypeDescription)"
        }
    } // namespace VehicleSpawnerTargetActions

    namespace VehicleSpawnerTargetProvider { // "Game.Battle.EntityModel.VehicleSpawner.VehicleSpawnerTargetProvider (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t tutorialModel = 0x20; // "TutorialModel"
            inline constexpr std::uintptr_t battleMode = 0x28; // "BattleModeDescription"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x30; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t actions = 0x38; // "VehicleSpawnerTargetActions"
            inline constexpr std::uintptr_t localizationKeys = 0x40; // "LocalizationKeys"
        }
        namespace Methods {
            inline constexpr std::uintptr_t FillTargetActions = 0xBFFE40; // "protected internal override void FillTargetActions(List<ITargetAction> actions)"
        }
    } // namespace VehicleSpawnerTargetProvider

    namespace VehicleSpawnerView { // "Game.Battle.EntityModel.VehicleSpawner.VehicleSpawnerView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t TargetObjectView = 0x20; // "TargetObjectView"
            inline constexpr std::uintptr_t MarkerRoot = 0x28; // "Transform"
        }
    } // namespace VehicleSpawnerView

    namespace VehiclesSearchCollisionPointsUpdater { // "Game.Battle.Entities.Vehicles.Updaters.VehiclesSearchCollisionPointsUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleEntitiesModel = 0x10; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t predictionSimulationModel = 0x18; // "PredictionSimulationModel"
            inline constexpr std::uintptr_t physicsSceneModel = 0x20; // "PhysicsSceneModel"
            inline constexpr std::uintptr_t vehiclesCollisionsModel = 0x28; // "IVehiclesCollisionsModel"
            inline constexpr std::uintptr_t enableDebug = 0x30; // "bool"
            inline constexpr std::uintptr_t vehicleSurfaceType = 0x31; // "byte"
            inline constexpr std::uintptr_t vehicles = 0x38; // "PhysicsListData<VehiclesSearchCollisionPointsUpdater.VehiclesSearchItemData>"
            inline constexpr std::uintptr_t bodyIdToVehicleIndex = 0x40; // "Dictionary<PhysicsBodyId, int>"
            inline constexpr std::uintptr_t vehiclesCenterOfMassTransformMatricesCache = 0x48; // "float[]"
            inline constexpr std::uintptr_t vehicleShapesCache = 0x50; // "PhysicsListData<VehiclesSearchCollisionPointsUpdater.VehicleShapeCacheItemData>"
            inline constexpr std::uintptr_t bodiesQueryResult = 0x58; // "List<PhysicsBodyId>"
            inline constexpr std::uintptr_t vehicleVsVehicleManifoldsUsed = 0x60; // "HashSet<ValueTuple<PhysicsBodyId, PhysicsBodyId>>"
            inline constexpr std::uintptr_t searchSqrRadius = 0x68; // "float"
            inline constexpr std::uintptr_t maxVehiclesCount = 0x6C; // "int"
            inline constexpr std::uintptr_t terrainFilterCos = 0x70; // "float"
            inline constexpr std::uintptr_t manifolds = 0x78; // "ManifoldPoint[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xAE7E90; // "public void Update()"
            inline constexpr std::uintptr_t ClearOldContactsForVehiclesWithoutPrediction = 0xAE6980; // "private void ClearOldContactsForVehiclesWithoutPrediction()"
            inline constexpr std::uintptr_t GetPointOfView = 0xAE79D0; // "private Vector3 GetPointOfView()"
            inline constexpr std::uintptr_t FindAllNotPredictedVehiclesFromPointOfViewInRadius = 0xAE7100; // "private void FindAllNotPredictedVehiclesFromPointOfViewInRadius(in Vector3 pointOfView)"
            inline constexpr std::uintptr_t SortVehiclesByDistanceAndLimitByMaxVehiclesCount = 0xAE7B20; // "private void SortVehiclesByDistanceAndLimitByMaxVehiclesCount()"
            inline constexpr std::uintptr_t CalculateVehiclesTransforms = 0xAE65B0; // "private void CalculateVehiclesTransforms()"
            inline constexpr std::uintptr_t CalculateVehiclesContactPoints = 0xAE55B0; // "private void CalculateVehiclesContactPoints()"
            inline constexpr std::uintptr_t DebugPointOfView = 0xAE6EB0; // "private void DebugPointOfView(in Vector3 pointOfView)"
            inline constexpr std::uintptr_t DebugVehiclesList = 0xAE6F70; // "private void DebugVehiclesList()"
            inline constexpr std::uintptr_t DebugBoundingBox = 0xAE6D50; // "private void DebugBoundingBox(in Vector3 position, in Quaternion orientation, in Vector3 size)"
            inline constexpr std::uintptr_t DebugAABB = 0xAE6B30; // "private void DebugAABB(in AABB aabb)"
        }
    } // namespace VehiclesSearchCollisionPointsUpdater

    namespace VehiclesSearchCollisionPointsUpdater_VehicleShapeCacheItemData { // "Game.Battle.Entities.Vehicles.Updaters.VehiclesSearchCollisionPointsUpdater.VehicleShapeCacheItemData (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Position = 0x0; // "Vector3"
            inline constexpr std::uintptr_t Orientation = 0xC; // "Quaternion"
            inline constexpr std::uintptr_t ShapeType = 0x1C; // "ShapeType"
            inline constexpr std::uintptr_t ShapeId = 0x20; // "int"
        }
    } // namespace VehiclesSearchCollisionPointsUpdater_VehicleShapeCacheItemData

    namespace VehiclesSearchCollisionPointsUpdater_VehiclesSearchItemData { // "Game.Battle.Entities.Vehicles.Updaters.VehiclesSearchCollisionPointsUpdater.VehiclesSearchItemData (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t SqrDistanceToPointOfView = 0x0; // "float"
            inline constexpr std::uintptr_t BodyId = 0x4; // "PhysicsBodyId"
            inline constexpr std::uintptr_t CenterOfMassPosition = 0xC; // "Vector3"
            inline constexpr std::uintptr_t CenterOfMassOrientation = 0x18; // "Quaternion"
            inline constexpr std::uintptr_t LinearVelocity = 0x28; // "Vector3"
            inline constexpr std::uintptr_t AngularVelocity = 0x34; // "Vector3"
            inline constexpr std::uintptr_t BoundingBoxPosition = 0x40; // "Vector3"
            inline constexpr std::uintptr_t BoundingBoxOrientation = 0x4C; // "Quaternion"
            inline constexpr std::uintptr_t BoundingBoxSize = 0x5C; // "Vector3"
            inline constexpr std::uintptr_t CenterOfMassTransformMatrixPointer = 0x68; // "int"
        }
    } // namespace VehiclesSearchCollisionPointsUpdater_VehiclesSearchItemData

    namespace VehicleStartPredictionUpdater { // "Game.Battle.Prediction.VehicleStartPredictionUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleEntitiesModel = 0x10; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t battleEntityDataModels = 0x18; // "IBattleEntityDataModels"
            inline constexpr std::uintptr_t playerCharacterDateModel = 0x20; // "IDataModel"
            inline constexpr std::uintptr_t dataUpdatesModel = 0x28; // "IDataUpdatesModel"
            inline constexpr std::uintptr_t predictionSimulationModel = 0x30; // "PredictionSimulationModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x95E140; // "public void Update()"
            inline constexpr std::uintptr_t IsVehicleNeedStartPrediction = 0x95D8F0; // "private bool IsVehicleNeedStartPrediction()"
            inline constexpr std::uintptr_t StartVehiclePrediction = 0x95DA50; // "private void StartVehiclePrediction()"
            inline constexpr std::uintptr_t AddVehicleToSimulation = 0x95D770; // "private void AddVehicleToSimulation(int vehicleEntityId, IDataModel vehicleDataModel)"
        }
    } // namespace VehicleStartPredictionUpdater

    namespace VehicleStatsModel { // "Game.Battle.Entities.Vehicles.Stats.Models.VehicleStatsModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsEnabled = 0x10; // "bool"
            inline constexpr std::uintptr_t DebugDrawType = 0x14; // "VehicleStatsDebugDrawType"
        }
    } // namespace VehicleStatsModel

    namespace VehicleStatsUpdater { // "Game.Battle.EntityModel.Vehicles.Stats.Updaters.VehicleStatsUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t view = 0x10; // "VehicleStatsDebugView"
            inline constexpr std::uintptr_t model = 0x18; // "VehicleStatsModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x20; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t vehicles = 0x28; // "VehiclesClientModel"
            inline constexpr std::uintptr_t physicsSceneModel = 0x30; // "PhysicsSceneModel"
            inline constexpr std::uintptr_t isInsideVehicle = 0x38; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC00410; // "public void Update()"
        }
    } // namespace VehicleStatsUpdater

    namespace VehicleStopPredictionUpdater { // "Game.Battle.Prediction.VehicleStopPredictionUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleEntitiesModel = 0x10; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t battleEntityDataModels = 0x18; // "IBattleEntityDataModels"
            inline constexpr std::uintptr_t predictionSimulationModel = 0x20; // "PredictionSimulationModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x95E5F0; // "public void Update()"
            inline constexpr std::uintptr_t IsVehicleNeedStopPrediction = 0x95E380; // "private bool IsVehicleNeedStopPrediction()"
            inline constexpr std::uintptr_t StopVehiclePrediction = 0x95E410; // "private void StopVehiclePrediction()"
        }
    } // namespace VehicleStopPredictionUpdater

    namespace VehicleSuspensionDescription { // "Models.References.Vehicle.VehicleSuspensionDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t SuspensionRestLength = 0x20; // "float"
            inline constexpr std::uintptr_t SuspensionUpperLimit = 0x24; // "float"
            inline constexpr std::uintptr_t SuspensionLowerLimit = 0x28; // "float"
            inline constexpr std::uintptr_t SuspensionSpringStiffnessPercent = 0x2C; // "float"
            inline constexpr std::uintptr_t SuspensionSpringDamperCompressionPercent = 0x30; // "float"
            inline constexpr std::uintptr_t SuspensionSpringDamperReboundPercent = 0x34; // "float"
            inline constexpr std::uintptr_t WheelRadius = 0x38; // "float"
        }
    } // namespace VehicleSuspensionDescription

    namespace VehicleSuspensionLimitCollisionModel { // "Game.Battle.Entities.Vehicles.Models.VehicleSuspensionLimitCollisionModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t PrevLimitState = 0x10; // "bool"
            inline constexpr std::uintptr_t IsHit = 0x11; // "bool"
        }
    } // namespace VehicleSuspensionLimitCollisionModel

    namespace VehicleSuspensionLimitCollisionUpdater { // "Game.Battle.Entities.Vehicles.Updaters.VehicleSuspensionLimitCollisionUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t suspensionLimitCollision = 0x18; // "VehicleSuspensionLimitCollisionModel"
            inline constexpr std::uintptr_t forwardAxle = 0x20; // "VehicleAxleClientModel"
            inline constexpr std::uintptr_t backwardAxle = 0x28; // "VehicleAxleClientModel"
            inline constexpr std::uintptr_t suspensionSettings = 0x30; // "VehicleSuspensionSettingsModel"
            inline constexpr std::uintptr_t vehiclePosition = 0x38; // "IPositionModel"
            inline constexpr std::uintptr_t suspensionLimitCollisionThreshold = 0x40; // "float"
            inline constexpr std::uintptr_t enableDebug = 0x44; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t InnerUpdate = 0xAE44D0; // "protected override void InnerUpdate()"
            inline constexpr std::uintptr_t InnerStart = 0x7B3360; // "protected override void InnerStart()"
            inline constexpr std::uintptr_t InnerStop = 0x7B3360; // "protected override void InnerStop()"
            inline constexpr std::uintptr_t RecalculateSuspensionLimitCollisionState = 0xAE4700; // "private ValueTuple<bool, bool> RecalculateSuspensionLimitCollisionState(bool prevLimitState)"
        }
    } // namespace VehicleSuspensionLimitCollisionUpdater

    namespace VehicleSuspensionSettingsModel { // "Models.Models.VehicleSuspensionSettings.VehicleSuspensionSettingsModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t suspensionDescription = 0x10; // "VehicleSuspensionDescription"
            inline constexpr std::uintptr_t overrideModel = 0x18; // "VehicleSuspensionSettingsOverrideModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_SuspensionRestLength = 0x48A85D0; // "public float get_SuspensionRestLength()"
            inline constexpr std::uintptr_t get_SuspensionUpperLimit = 0x48A8AD0; // "public float get_SuspensionUpperLimit()"
            inline constexpr std::uintptr_t get_SuspensionLowerLimit = 0x48A8500; // "public float get_SuspensionLowerLimit()"
            inline constexpr std::uintptr_t get_SuspensionSpringStiffnessPercent = 0x48A8A00; // "public float get_SuspensionSpringStiffnessPercent()"
            inline constexpr std::uintptr_t get_SuspensionSpringDamperCompressionPercent = 0x48A86A0; // "public float get_SuspensionSpringDamperCompressionPercent()"
            inline constexpr std::uintptr_t get_SuspensionSpringDamperReboundPercent = 0x48A8770; // "public float get_SuspensionSpringDamperReboundPercent()"
            inline constexpr std::uintptr_t get_WheelRadius = 0x48A8BA0; // "public float get_WheelRadius()"
            inline constexpr std::uintptr_t get_SuspensionSpringLengthOnMaxCompression = 0x48A8840; // "public float get_SuspensionSpringLengthOnMaxCompression()"
            inline constexpr std::uintptr_t get_SuspensionSpringLengthOnMaxExtension = 0x48A8920; // "public float get_SuspensionSpringLengthOnMaxExtension()"
            inline constexpr std::uintptr_t get_MinDistanceAlongSuspensionSpringBetweenLinkAndGround = 0x48A84C0; // "public float get_MinDistanceAlongSuspensionSpringBetweenLinkAndGround()"
            inline constexpr std::uintptr_t get_MaxDistanceAlongSuspensionSpringBetweenLinkAndGround = 0x48A8480; // "public float get_MaxDistanceAlongSuspensionSpringBetweenLinkAndGround()"
        }
    } // namespace VehicleSuspensionSettingsModel

    namespace VehicleSuspensionSettingsOverrideData { // "Models.Data.SettingsOverride.Vehicles.VehicleSuspensionSettingsOverrideData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t OverrideEnabled = 0x20; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t SuspensionRestLength = 0x28; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t SuspensionUpperLimit = 0x30; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t SuspensionLowerLimit = 0x38; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t SuspensionSpringStiffnessPercent = 0x40; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t SuspensionSpringDamperCompressionPercent = 0x48; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t SuspensionSpringDamperReboundPercent = 0x50; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t WheelRadius = 0x58; // "IPrimitiveData<float>"
        }
    } // namespace VehicleSuspensionSettingsOverrideData

    namespace VehicleSuspensionSettingsOverrideModel { // "Models.Models.VehicleSuspensionSettingsOverride.VehicleSuspensionSettingsOverrideModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "VehicleSuspensionSettingsOverrideData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_OverrideEnabled = 0x48A8EA0; // "public bool get_OverrideEnabled()"
            inline constexpr std::uintptr_t get_SuspensionRestLength = 0x48A8F40; // "public float get_SuspensionRestLength()"
            inline constexpr std::uintptr_t get_SuspensionUpperLimit = 0x48A9080; // "public float get_SuspensionUpperLimit()"
            inline constexpr std::uintptr_t get_SuspensionLowerLimit = 0x48A8EF0; // "public float get_SuspensionLowerLimit()"
            inline constexpr std::uintptr_t get_SuspensionSpringStiffnessPercent = 0x48A9030; // "public float get_SuspensionSpringStiffnessPercent()"
            inline constexpr std::uintptr_t get_SuspensionSpringDamperCompressionPercent = 0x48A8F90; // "public float get_SuspensionSpringDamperCompressionPercent()"
            inline constexpr std::uintptr_t get_SuspensionSpringDamperReboundPercent = 0x48A8FE0; // "public float get_SuspensionSpringDamperReboundPercent()"
            inline constexpr std::uintptr_t get_WheelRadius = 0x48A90D0; // "public float get_WheelRadius()"
            inline constexpr std::uintptr_t SetOverrideData = 0x48A8C70; // "public void SetOverrideData(float suspensionRestLength, float suspensionUpperLimit, float suspensionLowerLimit, float suspensionSpringStiffnessPercent, float suspensionSpringDamperCompressionPercent, float suspensionSpringDamperReboundPercent, float wheelRadius)"
        }
    } // namespace VehicleSuspensionSettingsOverrideModel

    namespace VehicleSuspensionUpdater { // "Game.Battle.Entities.Car.VehicleSuspensionUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t suspensionLimitCollisionModel = 0x10; // "VehicleSuspensionLimitCollisionModel"
            inline constexpr std::uintptr_t vehicleSuspension = 0x18; // "Event"
            inline constexpr std::uintptr_t soundEmitter = 0x20; // "GameObject"
            inline constexpr std::uintptr_t isHit = 0x28; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xBA16B0; // "public void Update()"
        }
    } // namespace VehicleSuspensionUpdater

    namespace VehiclesWorldModel { // "Models.Models.WorldModel.VehiclesWorld.VehiclesWorldModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t worldEntitiesModel = 0x10; // "WorldEntitiesModel"
            inline constexpr std::uintptr_t physicsSceneModel = 0x18; // "PhysicsSceneModel"
            inline constexpr std::uintptr_t safeZone = 0x20; // "SafeZoneWorldModel"
            inline constexpr std::uintptr_t parties = 0x28; // "IParties"
            inline constexpr std::uintptr_t changeSubscribeEntityModel = 0x30; // "ChangeSubscribeEntityModel"
            inline constexpr std::uintptr_t battleMode = 0x38; // "BattleModeDescription"
            inline constexpr std::uintptr_t clanBattleCharacterTeamModel = 0x40; // "IClanBattleCharacterTeamModel"
            inline constexpr std::uintptr_t occupiedCharacterSlotsModel = 0x48; // "OccupiedCharacterSlotsModel"
            inline constexpr std::uintptr_t partiesVehiclesModel = 0x50; // "PartiesVehiclesModel"
            inline constexpr std::uintptr_t vehicleMapTransformUpdateModel = 0x58; // "VehicleMapTransformUpdateModel"
            inline constexpr std::uintptr_t partiesUnreleasedSlotsModel = 0x60; // "BattlePartiesUnreleasedSlotsModel"
            inline constexpr std::uintptr_t worldInterruptModel = 0x68; // "IWorldInterruptModel"
            inline constexpr std::uintptr_t ownedVehiclesModel = 0x70; // "OwnedVehiclesModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t IsCharacterInsideCar = 0x48AC230; // "public bool IsCharacterInsideCar(InVehicleModel characterInVehicle)"
            inline constexpr std::uintptr_t IsCharacterInsideHelicopter = 0x48AC2C0; // "public bool IsCharacterInsideHelicopter(InVehicleModel characterInVehicle)"
            inline constexpr std::uintptr_t TryGetVehicleByCharacterInside = 0x48AD990; // "public bool TryGetVehicleByCharacterInside(InVehicleModel characterInVehicle, out VehicleModel vehicle)"
            inline constexpr std::uintptr_t TryGetCarByCharacterInside = 0x48AD470; // "public bool TryGetCarByCharacterInside(InVehicleModel characterInVehicle, out CarModel car)"
            inline constexpr std::uintptr_t TryGetHelicopterByCharacterInside = 0x48AD860; // "public bool TryGetHelicopterByCharacterInside(InVehicleModel characterInVehicle, out HelicopterModel helicopter)"
            inline constexpr std::uintptr_t GetVehicleByCharacterInside = 0x48AC150; // "public VehicleModel GetVehicleByCharacterInside(InVehicleModel characterInVehicle)"
            inline constexpr std::uintptr_t GetCarByCharacterInside = 0x48ABF90; // "public CarModel GetCarByCharacterInside(InVehicleModel characterInVehicle)"
            inline constexpr std::uintptr_t GetHelicopterByCharacterInside = 0x48AC070; // "public HelicopterModel GetHelicopterByCharacterInside(InVehicleModel characterInVehicle)"
            inline constexpr std::uintptr_t TryGetCharacterVehicle = 0x48AD7C0; // "public bool TryGetCharacterVehicle(int characterEntityId, out VehicleModel vehicle)"
            inline constexpr std::uintptr_t TryGetCharacterCar = 0x48AD5A0; // "public bool TryGetCharacterCar(int characterEntityId, out CarModel car)"
            inline constexpr std::uintptr_t TryGetCharacterHelicopter = 0x48AD6B0; // "public bool TryGetCharacterHelicopter(int characterEntityId, out HelicopterModel helicopter)"
            inline constexpr std::uintptr_t TryGetVehicleByEntityId = 0x48ADA50; // "public bool TryGetVehicleByEntityId(int entityId, out VehicleModel vehicle)"
            inline constexpr std::uintptr_t TryGetCarByEntityId = 0x48AD530; // "public bool TryGetCarByEntityId(int entityId, out CarModel car)"
            inline constexpr std::uintptr_t TryGetHelicopterByEntityId = 0x48AD920; // "public bool TryGetHelicopterByEntityId(int entityId, out HelicopterModel helicopter)"
            inline constexpr std::uintptr_t TryGetVehicleByPublicId = 0x48ADAC0; // "public bool TryGetVehicleByPublicId(long publicId, out VehicleModel vehicleModel)"
            inline constexpr std::uintptr_t GetVehicleByEntityId = 0x48AC1D0; // "public VehicleModel GetVehicleByEntityId(int entityId)"
            inline constexpr std::uintptr_t GetCarByEntityId = 0x48AC010; // "public CarModel GetCarByEntityId(int entityId)"
            inline constexpr std::uintptr_t GetHelicopterByEntityId = 0x48AC0F0; // "public HelicopterModel GetHelicopterByEntityId(int entityId)"
            inline constexpr std::uintptr_t AddCharacterToVehicle = 0x48AB530; // "public void AddCharacterToVehicle(BattleCharacterModel character, int vehicleEntityId, VehicleSeatsModel vehicleSeats, VehicleSeatSlotDescription targetVehicleSeatSlot, VehicleTypeDescription vehicleType)"
            inline constexpr std::uintptr_t AddCharacterToVehicle_2 = 0x48AB5B0; // "public void AddCharacterToVehicle(int characterEntityId, InVehicleModel characterInVehicle, CharacterControllerModel characterController, SubscribeEntitiesModel subscribeEntities, IEventModel characterWarpedEvent, int vehicleEntityId, VehicleSeatsModel vehicleSeats, VehicleSeatSlotDescription targetVehicleSeatSlot, VehicleTypeDescription vehicleType)"
            inline constexpr std::uintptr_t ChangeCharacterVehicleSeat = 0x48ABEE0; // "public void ChangeCharacterVehicleSeat(int characterEntityId, InVehicleModel characterInVehicle, IEventModel characterWarpedEvent, VehicleSeatsModel vehicleSeats, VehicleSeatSlotDescription newVehicleSeatSlot)"
            inline constexpr std::uintptr_t ObserveVehicleTrunkInventory = 0x48AC350; // "private void ObserveVehicleTrunkInventory(int characterEntityId, SubscribeEntitiesModel subscribeEntities, VehicleModel vehicle)"
            inline constexpr std::uintptr_t RemoveCharacterFromVehicle = 0x48AC410; // "public void RemoveCharacterFromVehicle(long now, BattleCharacterModel character, VehicleSeatsModel vehicleSeats, int safeZoneFlags)"
            inline constexpr std::uintptr_t RemoveCharacterFromVehicle_2 = 0x48AC4D0; // "public void RemoveCharacterFromVehicle(long now, ITransformModel characterTransform, CharacterReplicatedTransformModel replicatedTransformModel, LookDirectionModel lookDirectionModel, DesiredYawModel desiredYawModel, InVehicleModel characterInVehicle, IBattleCharacterStateModel stateModel, CharacterControllerModel characterController, VehicleLeaveModel characterVehicleLeave, IEventModel characterWarpedEvent, CharacterInterruptModel characterInterrupt, VehicleSeatsModel vehicleSeats, int safeZoneFlags)"
            inline constexpr std::uintptr_t RemoveAllCharactersFromVehicle = 0x48AC3F0; // "public void RemoveAllCharactersFromVehicle(long now, VehicleSeatsModel vehicleSeats, int safeZoneFlags)"
            inline constexpr std::uintptr_t RemoveCharactersFromVehicle = 0x48AC7C0; // "public void RemoveCharactersFromVehicle(long now, VehicleSeatsModel vehicleSeats, int safeZoneFlags, int ignoreCharacterId)"
            inline constexpr std::uintptr_t AddVehiclePartyAndClanBattleOwnership = 0x48AB9F0; // "public void AddVehiclePartyAndClanBattleOwnership(BattleCharacterModel character, long vehicleOwnerPublicId, int vehicleEntityId, VehicleTypeDescription vehicleType, PartyVehicleOwnerModel vehiclePartyOwner, VehicleTransformModel vehicleTransform, ClanBattleVehicleTeamOwnerModel clanBattleVehicleTeamOwnerModel)"
            inline constexpr std::uintptr_t AddClanBattleTeamOwner = 0x48AB790; // "private void AddClanBattleTeamOwner(ClanBattleVehicleTeamOwnerModel clanBattleVehicleTeamOwnerModel, int characterId)"
            inline constexpr std::uintptr_t AddVehicleCharacterOwnership = 0x48AB880; // "public void AddVehicleCharacterOwnership(string characterPrivateId, long characterPublicId, VehicleModel vehicleModel)"
            inline constexpr std::uintptr_t SyncVehiclePartyOwnership = 0x48AD0B0; // "public void SyncVehiclePartyOwnership(long now, int vehicleOwnerEntityId, VehicleModel vehicle)"
            inline constexpr std::uintptr_t AddVehiclePartyOwnership = 0x48ABD60; // "private void AddVehiclePartyOwnership(long vehicleOwnerPublicId, int vehicleEntityId, VehicleTypeDescription vehicleType, PartyVehicleOwnerModel vehiclePartyOwner, VehicleTransformModel vehicleTransform, PartyModel partyModel)"
            inline constexpr std::uintptr_t RemoveVehicleOwnership = 0x48ACDA0; // "public void RemoveVehicleOwnership(VehicleModel vehicle)"
            inline constexpr std::uintptr_t RemoveClanBattleTeamOwner = 0x48ACB70; // "private void RemoveClanBattleTeamOwner(ClanBattleVehicleTeamOwnerModel clanBattleVehicleTeamOwnerModel)"
            inline constexpr std::uintptr_t RemoveVehicleCharacterOwnership = 0x48ACB90; // "private void RemoveVehicleCharacterOwnership(VehicleModel vehicle)"
            inline constexpr std::uintptr_t RemoveVehiclePartyOwnership = 0x48ACDF0; // "public void RemoveVehiclePartyOwnership(VehicleModel vehicle)"
            inline constexpr std::uintptr_t SetVehicleEngineEnabled = 0x48ACFD0; // "public void SetVehicleEngineEnabled(int vehicleEntityId, long now)"
            inline constexpr std::uintptr_t SetVehicleDrownedState = 0x48ACEA0; // "public void SetVehicleDrownedState(long now, VehicleModel vehicle, bool value)"
        }
    } // namespace VehiclesWorldModel

    namespace VehicleTargetProvider { // "Game.Battle.Entities.Vehicles.Updaters.VehicleTargetProvider (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t vehicleServerModel = 0x20; // "VehicleModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x28; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t enterTargetAction = 0x30; // "TargetAction"
            inline constexpr std::uintptr_t options = 0x38; // "UnityRaycastTargetOptions"
            inline constexpr std::uintptr_t partyModel = 0x40; // "PartyModel"
            inline constexpr std::uintptr_t unavailableKeys = 0x48; // "UnavailableTargetActionsKeys"
            inline constexpr std::uintptr_t enterPoliceVehicleUnavailable = 0x50; // "ITargetAction"
            inline constexpr std::uintptr_t battleModeDescription = 0x58; // "BattleModeDescription"
            inline constexpr std::uintptr_t clanBattleTeamsCacheModel = 0x60; // "ClanBattleTeamsCacheModel"
            inline constexpr std::uintptr_t vehicleOwnersModel = 0x68; // "VehicleOwnersModel"
            inline constexpr std::uintptr_t unavailableInteractionAction = 0x70; // "UnavailableTargetAction"
            inline constexpr std::uintptr_t isHintInvisible = 0x78; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t GetTargetAction = 0xAE48B0; // "protected override ITargetAction GetTargetAction()"
            inline constexpr std::uintptr_t IsPlayerInsideVehicle = 0xAE51D0; // "private bool IsPlayerInsideVehicle(PlayerEntityModel player)"
            inline constexpr std::uintptr_t HasAvailableSlotToEnter = 0xAE4BB0; // "private bool HasAvailableSlotToEnter(PlayerEntityModel player)"
            inline constexpr std::uintptr_t IsCharacterAllowedToEnterVehicle = 0xAE4E40; // "private bool IsCharacterAllowedToEnterVehicle(PlayerEntityModel player)"
            inline constexpr std::uintptr_t IsOwnVehicle = 0xAE4FC0; // "private bool IsOwnVehicle(PlayerEntityModel player)"
            inline constexpr std::uintptr_t IsPartyTeammateVehicle = 0xAE5000; // "private bool IsPartyTeammateVehicle()"
            inline constexpr std::uintptr_t IsClanBattleTeammate = 0xAE4F50; // "private bool IsClanBattleTeammate(ClanBattleVehicleTeamOwnerModel clanBattleTeamOwner)"
        }
    } // namespace VehicleTargetProvider

    namespace VehicleTeleportExtensions { // "Models.Utils.Extensions.Vehicles.VehicleTeleportExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t SetTeleportRequestFromBottomPoint = 0x3972640; // "public static void SetTeleportRequestFromBottomPoint(VehicleModel vehicle, in Vector3 bottomPoint, in Quaternion targetOrientation)"
            inline constexpr std::uintptr_t CalculateTeleportPositionFromBottomPoint = 0x3972510; // "public static Vector3 CalculateTeleportPositionFromBottomPoint(VehicleModel vehicle, in Vector3 bottomPoint, in Quaternion targetOrientation)"
        }
    } // namespace VehicleTeleportExtensions

    namespace VehicleTickDataModel { // "Models.Models.TickDataModels.Vehicle.VehicleTickDataModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t TransformTickData = 0x10; // "VehicleTransformTickDataModel"
            inline constexpr std::uintptr_t LinksTickData = 0x18; // "VehicleLinksTickDataModel"
            inline constexpr std::uintptr_t SleepTickData = 0x20; // "VehicleSleepTickDataModel"
            inline constexpr std::uintptr_t WaterTickData = 0x28; // "VehicleWaterTickDataModel"
            inline constexpr std::uintptr_t EngineTickData = 0x30; // "VehicleEngineTickDataModel"
        }
    } // namespace VehicleTickDataModel

    namespace VehicleTransformModel { // "Models.Models.VehicleTransform.VehicleTransformModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t position = 0x10; // "IPrimitiveData<Vector3>"
            inline constexpr std::uintptr_t orientation = 0x18; // "IPrimitiveData<Vector4>"
            inline constexpr std::uintptr_t centerOfMassToPivotOffsetInLocalSpace = 0x20; // "Vector3"
            inline constexpr std::uintptr_t pivotToCenterOfMassOffsetInLocalSpace = 0x2C; // "Vector3"
            inline constexpr std::uintptr_t centerOfMassPosition = 0x38; // "Vector3"
            inline constexpr std::uintptr_t centerOfMassOrientation = 0x44; // "Quaternion"
            inline constexpr std::uintptr_t centerOfMassPivotBasedPosition = 0x54; // "Vector3"
            inline constexpr std::uintptr_t centerOfMassPivotBasedOrientationAsVector4 = 0x60; // "Vector4"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_X = 0x48A9D20; // "public float get_X()"
            inline constexpr std::uintptr_t get_Y = 0x48A9DD0; // "public float get_Y()"
            inline constexpr std::uintptr_t get_Z = 0x48A9E80; // "public float get_Z()"
            inline constexpr std::uintptr_t get_PivotWorldPosition = 0x48A9C50; // "public Vector3 get_PivotWorldPosition()"
            inline constexpr std::uintptr_t get_PivotWorldOrientation = 0x48A9B40; // "public Quaternion get_PivotWorldOrientation()"
            inline constexpr std::uintptr_t get_PivotWorldOrientationAsVector4 = 0x48A9A70; // "public Vector4 get_PivotWorldOrientationAsVector4()"
            inline constexpr std::uintptr_t get_CenterOfMassPosition = 0x48A9A20; // "public Vector3 get_CenterOfMassPosition()"
            inline constexpr std::uintptr_t get_CenterOfMassOrientation = 0x48A99E0; // "public Quaternion get_CenterOfMassOrientation()"
            inline constexpr std::uintptr_t get_CenterOfMassOrientationAsVector4 = 0x48A9960; // "public Vector4 get_CenterOfMassOrientationAsVector4()"
            inline constexpr std::uintptr_t SetPivotWorldTransform = 0x48A9860; // "public void SetPivotWorldTransform(in Vector3 position, in Quaternion orientation)"
            inline constexpr std::uintptr_t SetPivotWorldPosition = 0x48A9840; // "public void SetPivotWorldPosition(in Vector3 position)"
            inline constexpr std::uintptr_t SetPivotWorldOrientation = 0x48A97D0; // "public void SetPivotWorldOrientation(in Quaternion orientation)"
            inline constexpr std::uintptr_t SetCenterOfMassWorldTransform = 0x48A97B0; // "public void SetCenterOfMassWorldTransform(in Vector3 position, in Quaternion orientation)"
            inline constexpr std::uintptr_t SetCenterOfMassWorldPosition = 0x48A9790; // "public void SetCenterOfMassWorldPosition(in Vector3 position)"
            inline constexpr std::uintptr_t SetCenterOfMassWorldOrientation = 0x48A9780; // "public void SetCenterOfMassWorldOrientation(in Quaternion orientation)"
            inline constexpr std::uintptr_t CalculatePivotForCenterOfMass = 0x48A91E0; // "public Vector3 CalculatePivotForCenterOfMass(in Vector3 position, in Quaternion orientation)"
            inline constexpr std::uintptr_t CalculateCenterOfMassForPivot = 0x48A9120; // "public Vector3 CalculateCenterOfMassForPivot(in Vector3 position, in Quaternion orientation)"
            inline constexpr std::uintptr_t IsNeedUpdateCenterOfMass = 0x48A92A0; // "private bool IsNeedUpdateCenterOfMass()"
            inline constexpr std::uintptr_t RecalculateCenterOfMass = 0x48A94F0; // "private void RecalculateCenterOfMass()"
            inline constexpr std::uintptr_t TryRecalculateCenterOfMass = 0x48A98A0; // "private void TryRecalculateCenterOfMass()"
            inline constexpr std::uintptr_t RecalculatePivot = 0x48A9600; // "private void RecalculatePivot()"
        }
    } // namespace VehicleTransformModel

    namespace VehicleTransformTickDataModel { // "Models.Models.TickDataModels.Vehicle.VehicleTransformTickDataModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t TransformMatrix = 0x10; // "float[]"
        }
    } // namespace VehicleTransformTickDataModel

    namespace VehicleTrunkAnimationUpdater { // "Game.Battle.Entities.Car.VehicleTrunkAnimationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t vehicleEntityEntityEditor = 0x10; // "VehicleEntityView"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x18; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t vehicleId = 0x20; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xBA1870; // "public void Update()"
            inline constexpr std::uintptr_t IsTrunkOpened = 0xBA1700; // "private bool IsTrunkOpened(int id)"
        }
    } // namespace VehicleTrunkAnimationUpdater

    namespace VehicleTrunkData { // "Models.Data.Vehicle.VehicleTrunkData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Inventory = 0x20; // "InventoryData"
            inline constexpr std::uintptr_t InventoryRevealId = 0x28; // "InventoryRevealIdData"
            inline constexpr std::uintptr_t CargoInventory = 0x30; // "CargoInventoryData"
            inline constexpr std::uintptr_t InventoryAdditionalLines = 0x38; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t CargoInventoryAdditionalSlots = 0x40; // "IPrimitiveData<int>"
        }
    } // namespace VehicleTrunkData

    namespace VehicleTrunkDescription { // "Models.References.Vehicle.Trunk.VehicleTrunkDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t InventoryFunc = 0x20; // "Func<InventoryCellsSizeDescription>"
            inline constexpr std::uintptr_t CargoInventory = 0x28; // "CargoInventoryDescription"
            inline constexpr std::uintptr_t InventorySettingsFunc = 0x30; // "Func<VehicleTrunkInventorySettingsDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Inventory = 0x9D6230; // "public InventoryCellsSizeDescription get_Inventory()"
            inline constexpr std::uintptr_t get_InventorySettings = 0x9AA5D0; // "public VehicleTrunkInventorySettingsDescription get_InventorySettings()"
        }
    } // namespace VehicleTrunkDescription

    namespace VehicleTrunkEntityModel { // "Game.Battle.EntityModel.CarTrunk.Models.VehicleTrunkEntityModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ServerModel = 0x18; // "VehicleTrunkModel"
            inline constexpr std::uintptr_t BusySlotsModel = 0x20; // "BusySlotsModel"
            inline constexpr std::uintptr_t ChangedSlotsInventoryModel = 0x28; // "ChangedSlotsInventoryModel"
            inline constexpr std::uintptr_t ShadowAreaModel = 0x30; // "InventoryShadowAreaModel"
            inline constexpr std::uintptr_t InventoriesModel = 0x38; // "VehicleTrunkInventoriesModel"
        }
    } // namespace VehicleTrunkEntityModel

    namespace VehicleTrunkExtensions { // "Models.Utils.Extensions.Vehicles.VehicleTrunkExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t IsVehicleTrunkEmpty = 0x3973820; // "public static bool IsVehicleTrunkEmpty(IInventoryModel inventoryModel, CargoInventoryModel cargoInventoryModel)"
            inline constexpr std::uintptr_t ClearVehicleTrunk = 0x3972EC0; // "public static void ClearVehicleTrunk(int vehicleEntityId, WorldEntitiesModel worldEntitiesModel, ChangeVehicleTrunkEmptyFlagModel changeVehicleTrunkEmptyFlagModel)"
            inline constexpr std::uintptr_t UpdateHasCargoAndHasFreeCargoSlot = 0x39739F0; // "public static void UpdateHasCargoAndHasFreeCargoSlot(CargoInventoryModel cargoInventoryModel, VehicleModel vehicleModel)"
            inline constexpr std::uintptr_t HasRepairAccess = 0x3973280; // "public static bool HasRepairAccess(int characterId, VehicleModel vehicleModel, BattleCharacterModel battleCharacterModel, ICharacterSlotsModel characterSlotsModel)"
            inline constexpr std::uintptr_t HasBreachAccess = 0x3973090; // "public static bool HasBreachAccess(int characterId, VehicleModel vehicleModel, BattleCharacterModel battleCharacterModel, IPartyMemberAccessModel partyMemberAccessModel, ICharacterSlotsModel characterSlotsModel, IClanBattleCharacterTeamModel clanBattleCharacterTeamModel)"
            inline constexpr std::uintptr_t HasChangeInventoryAccess = 0x39731D0; // "public static bool HasChangeInventoryAccess(int characterId, VehicleModel vehicleModel, IPartyMemberAccessModel partyMemberAccessModel, ICharacterSlotsModel characterSlotsModel, IClanBattleCharacterTeamModel clanBattleCharacterTeamModel)"
            inline constexpr std::uintptr_t HasOwner = 0x3973250; // "private static bool HasOwner(VehicleModel vehicleModel)"
            inline constexpr std::uintptr_t IsOwner = 0x3973700; // "private static bool IsOwner(int characterId, VehicleModel vehicleModel, ICharacterSlotsModel characterSlotsModel)"
            inline constexpr std::uintptr_t IsOwnerOrSamePartyOrSameClan = 0x3973440; // "private static bool IsOwnerOrSamePartyOrSameClan(int characterId, VehicleModel vehicleModel, IPartyMemberAccessModel partyMemberAccessModel, ICharacterSlotsModel characterSlotsModel, IClanBattleCharacterTeamModel clanBattleCharacterTeamModel)"
            inline constexpr std::uintptr_t TryGetOwnerId = 0x3973990; // "private static bool TryGetOwnerId(VehicleModel vehicleModel, out long ownerPublicId)"
            inline constexpr std::uintptr_t TryGetCharacterPublicId = 0x39738C0; // "private static bool TryGetCharacterPublicId(ICharacterSlotsModel characterSlotsModel, int characterId, out long characterPublicId)"
            inline constexpr std::uintptr_t BuildTrunkCargoInventoryUpgradeSlotEnum = 0x3972B20; // "public static ReadOnlyEnum<TrunkCargoInventoryCarUpgradeSlotDescription> BuildTrunkCargoInventoryUpgradeSlotEnum(ReadOnlyEnum<VehicleTrunkInventorySettingsDescription> vehicleTrunkInventorySettings)"
            inline constexpr std::uintptr_t BuildTrunkInventoryCarUpgradeSlotEnum = 0x3972CF0; // "public static ReadOnlyEnum<TrunkInventoryCarUpgradeSlotDescription> BuildTrunkInventoryCarUpgradeSlotEnum(ReadOnlyEnum<VehicleTrunkInventorySettingsDescription> vehicleTrunkInventorySettings)"
            inline constexpr std::uintptr_t BuildMaxVehicleTrunkCellsSize = 0x39729B0; // "public static InventoryCellsSizeDescription BuildMaxVehicleTrunkCellsSize(int trunkLineLength, ReadOnlyEnum<VehicleTrunkInventorySettingsDescription> vehicleTrunkInventorySettingsDescriptions)"
            inline constexpr std::uintptr_t BuildMaxVehicleLootCellsSize = 0x3972880; // "public static InventoryCellsSizeDescription BuildMaxVehicleLootCellsSize(int trunkLineLength, InventoryCellsSizeDescription vehicleTrunkMax, ReadOnlyEnum<TrunkInventoryCarUpgradeSlotDescription> trunkInventoryCarUpgradeSlots, ReadOnlyEnum<TrunkCargoInventoryCarUpgradeSlotDescription> trunkCargoInventoryCarUpgradeSlots)"
        }
    } // namespace VehicleTrunkExtensions

    namespace VehicleTrunkInventoriesModel { // "Models.Models.VehicleTrunkInventories.VehicleTrunkInventoriesModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Id = 0x10; // "int"
            inline constexpr std::uintptr_t Inventory = 0x18; // "IInventoryModel"
            inline constexpr std::uintptr_t CargoInventoryModel = 0x20; // "CargoInventoryModel"
        }
    } // namespace VehicleTrunkInventoriesModel

    namespace VehicleTrunkInventorySettingsDescription { // "Models.References.Vehicle.Trunk.VehicleTrunkInventorySettingsDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t InventoryStartLinesCount = 0x20; // "int"
            inline constexpr std::uintptr_t InventoryUpgradeSlotsCount = 0x24; // "int"
            inline constexpr std::uintptr_t InventoryMaxLinesCount = 0x28; // "int"
            inline constexpr std::uintptr_t CargoInventoryStartSlotsCount = 0x2C; // "int"
            inline constexpr std::uintptr_t CargoInventoryUpgradesSlotsCount = 0x30; // "int"
            inline constexpr std::uintptr_t CargoInventoryMaxSlotsCount = 0x34; // "int"
        }
    } // namespace VehicleTrunkInventorySettingsDescription

    namespace VehicleTrunkModel { // "Models.Models.VehicleTrunk.VehicleTrunkModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Id = 0x10; // "int"
            inline constexpr std::uintptr_t InventoryAdditionalLines = 0x18; // "IPrimitiveModel<int>"
            inline constexpr std::uintptr_t Inventory = 0x20; // "IInventoryModel"
            inline constexpr std::uintptr_t InventoryRevealIdModel = 0x28; // "InventoryRevealIdModel"
            inline constexpr std::uintptr_t CargoInventoryAdditionalSlots = 0x30; // "IPrimitiveModel<int>"
            inline constexpr std::uintptr_t CargoInventoryModel = 0x38; // "CargoInventoryModel"
            inline constexpr std::uintptr_t OwnerNickname = 0x40; // "IPrimitiveModel<string>"
            inline constexpr std::uintptr_t OwnerClanTag = 0x48; // "IPrimitiveModel<string>"
            inline constexpr std::uintptr_t InventoryData = 0x50; // "IData"
            inline constexpr std::uintptr_t CargoInventoryData = 0x58; // "IData"
        }
    } // namespace VehicleTrunkModel

    namespace VehicleTrunkPositionModel { // "Models.Models.VehicleTrunkPosition.VehicleTrunkPositionModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t X = 0x10; // "float"
            inline constexpr std::uintptr_t Y = 0x14; // "float"
            inline constexpr std::uintptr_t Z = 0x18; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Set = 0x48AA800; // "public void Set(float x, float y, float z)"
        }
    } // namespace VehicleTrunkPositionModel

    namespace VehicleTrunkPositionSystem { // "Models.Systems.VehicleTrunkPositionSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t worldTickData = 0x38; // "WorldTickData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x4371AA0; // "protected override void Tick(ITick tick)"
        }
    } // namespace VehicleTrunkPositionSystem

    namespace VehicleTrunkPositionUpdater { // "Game.Battle.Entities.Car.VehicleTrunkPositionUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t transform = 0x18; // "VehicleTransformModel"
            inline constexpr std::uintptr_t trunkPositionModel = 0x20; // "VehicleTrunkPositionModel"
            inline constexpr std::uintptr_t trunkLocalPosition = 0x28; // "Vector3"
        }
        namespace Methods {
            inline constexpr std::uintptr_t InnerUpdate = 0xBA1940; // "protected override void InnerUpdate()"
            inline constexpr std::uintptr_t InnerStart = 0x7B3360; // "protected override void InnerStart()"
            inline constexpr std::uintptr_t InnerStop = 0x7B3360; // "protected override void InnerStop()"
        }
    } // namespace VehicleTrunkPositionUpdater

    namespace VehicleTrunkSettingsDescription { // "Models.References.Vehicle.Trunk.VehicleTrunkSettingsDescription (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t GetVehicleTrunkEntityId = 0x40808C0; // "public static int GetVehicleTrunkEntityId(int vehicleEntityId)"
            inline constexpr std::uintptr_t GetVehicleEntityId = 0x40808B0; // "public static int GetVehicleEntityId(int vehicleTrunkEntityId)"
            inline constexpr std::uintptr_t GetVehicleTrunkWorldPosition = 0x3955A10; // "public static Vector3 GetVehicleTrunkWorldPosition(in Vector3 trunkLocalPosition, in Vector3 vehiclePivotPosition, in Quaternion vehiclePivotOrientation)"
            inline constexpr std::uintptr_t GetVehicleTrunkCargoInventorySlotEntityId = 0x407E240; // "public static int GetVehicleTrunkCargoInventorySlotEntityId(VehicleTrunkModel trunkModel, CargoInventorySlotDescription slotDescription)"
            inline constexpr std::uintptr_t GetVehicleTrunkCargoInventorySlotEntityId_2 = 0x407E220; // "public static int GetVehicleTrunkCargoInventorySlotEntityId(int trunkEntityId, CargoInventorySlotDescription slotDescription)"
        }
    } // namespace VehicleTrunkSettingsDescription

    namespace VehicleTrunkTargetHintUpdater { // "Game.Battle.Entities.Car.VehicleTrunkTargetHintUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t targetHintModel = 0x10; // "TargetHintObjectsModel"
            inline constexpr std::uintptr_t inventoryDialogModel = 0x18; // "InventoryDialogModel"
            inline constexpr std::uintptr_t entityId = 0x20; // "int"
            inline constexpr std::uintptr_t targetObject = 0x28; // "ITargetObject"
            inline constexpr std::uintptr_t isVisible = 0x30; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xBA1F20; // "public void Update()"
        }
    } // namespace VehicleTrunkTargetHintUpdater

    namespace VehicleTypeDescription { // "Models.References.Vehicle.VehicleTypeDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x8205120; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t enum_id = 0x0; // "Enum<VehicleTypeDescription>"
            inline constexpr std::uintptr_t Car = 0x8; // "VehicleTypeDescription"
            inline constexpr std::uintptr_t Helicopter = 0x10; // "VehicleTypeDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Enum = 0x4080B30; // "public static ReadOnlyEnum<VehicleTypeDescription> get_Enum()"
        }
    } // namespace VehicleTypeDescription

    namespace VehicleUpgradeHolderPositionSystem { // "Models.Systems.VehicleUpgradeHolderPositionSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t worldTickData = 0x38; // "WorldTickData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x4371D30; // "protected override void Tick(ITick tick)"
        }
    } // namespace VehicleUpgradeHolderPositionSystem

    namespace VehicleUpgradeHolderSettingsDescription { // "Models.References.Vehicle.UpgradeHolder.VehicleUpgradeHolderSettingsDescription (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t GetVehicleHoodEntityId = 0x4080E90; // "public static int GetVehicleHoodEntityId(CarDescription carDescription, int vehicleEntityId)"
            inline constexpr std::uintptr_t GetVehicleUndercarriageEntityId = 0x4080F90; // "public static int GetVehicleUndercarriageEntityId(CarDescription carDescription, int vehicleEntityId)"
            inline constexpr std::uintptr_t GetPlotVehicleHoodEntityId = 0x4080CB0; // "public static int GetPlotVehicleHoodEntityId(int plotVehicleEntityId)"
            inline constexpr std::uintptr_t GetPlotVehicleUndercarriageEntityId = 0x4080D40; // "public static int GetPlotVehicleUndercarriageEntityId(int plotVehicleEntityId)"
            inline constexpr std::uintptr_t GetLiveVehicleUpgradeHolderOffset = 0x4080BD0; // "private static int GetLiveVehicleUpgradeHolderOffset(CarDescription carDescription)"
            inline constexpr std::uintptr_t GetTrunkCargoSlotsCount = 0x4080DD0; // "private static int GetTrunkCargoSlotsCount(CarDescription carDescription)"
        }
    } // namespace VehicleUpgradeHolderSettingsDescription

    namespace VehicleUpgradesDialogView { // "Game.Battle.VehicleModules.VehicleUpgradesDialogView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t lastSelectedSlots = 0x20; // "CarUpgradeDialogSlotView[]"
            inline constexpr std::uintptr_t counter = 0x28; // "Dictionary<CarUpgradeType, int>"
            inline constexpr std::uintptr_t Header = 0x30; // "InventoryDialogHeaderView"
            inline constexpr std::uintptr_t hoodSlots = 0x38; // "CarUpgradeDialogSlotView[]"
            inline constexpr std::uintptr_t undercarriageSlots = 0x40; // "CarUpgradeDialogSlotView[]"
            inline constexpr std::uintptr_t trunkSlots = 0x48; // "CarUpgradeDialogSlotView[]"
            inline constexpr std::uintptr_t hoodContainer = 0x50; // "GameObject"
            inline constexpr std::uintptr_t undercarriageContainer = 0x58; // "GameObject"
            inline constexpr std::uintptr_t trunkContainer = 0x60; // "GameObject"
            inline constexpr std::uintptr_t trunkItemsContainer = 0x68; // "GameObject"
            inline constexpr std::uintptr_t trunkCargoContainer = 0x70; // "GameObject"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SwitchHolders = 0xD5F890; // "public void SwitchHolders(CarUpgradesHolderTypeDescription holderType)"
            inline constexpr std::uintptr_t GetSlotsByHolder = 0xD5F640; // "public CarUpgradeDialogSlotView[] GetSlotsByHolder(CarUpgradesHolderTypeDescription holderType)"
            inline constexpr std::uintptr_t UpdateSlots = 0xD5FAA0; // "public void UpdateSlots(CarUpgradesHolderTypeDescription holderType, int inventoryUpgradeSlotsCount, int cargoInventoryUpgradesSlotsCount)"
            inline constexpr std::uintptr_t UpdateSlotIndex = 0xD5F990; // "private void UpdateSlotIndex(CarUpgradeDialogSlotView[] slots)"
        }
    } // namespace VehicleUpgradesDialogView

    namespace VehicleUpgradesViewUpdater { // "Game.Battle.Entities.Car.VehicleUpgradesViewUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t updaters = 0x10; // "IUpdater"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xBA2120; // "public void Update()"
        }
    } // namespace VehicleUpgradesViewUpdater

    namespace VehicleUtils { // "Game.Battle.Vehicle.VehicleUtils (Battle.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t GetVehicleMarkerType = 0xD5FC60; // "public static MapMarkerType GetVehicleMarkerType(VehicleTypeDescription vehicleTypeDescription, bool isPlayerVehicle)"
            inline constexpr std::uintptr_t TryGetVehicleSimulatedPivotTransform_T_inst_1 = 0x126C760; // "VehicleUtils.TryGetVehicleSimulatedPivotTransform<CarTimelineSubTickData>"
            inline constexpr std::uintptr_t TryGetVehicleSimulatedPivotTransform_T_inst_2 = 0x126C980; // "VehicleUtils.TryGetVehicleSimulatedPivotTransform<HelicopterTimelineData>"
            inline constexpr std::uintptr_t TryGetVehicleSimulatedPivotTransform_T_inst_3 = 0x126CBC0; // "VehicleUtils.TryGetVehicleSimulatedPivotTransform<__Il2CppFullySharedGenericStructType>"
            inline constexpr std::uintptr_t TryGetVehicleSimulatedTimelineData_T_inst_1 = 0x126CD90; // "VehicleUtils.TryGetVehicleSimulatedTimelineData<CarTimelineSubTickData>"
            inline constexpr std::uintptr_t TryGetVehicleSimulatedTimelineData_T_inst_2 = 0x126CEA0; // "VehicleUtils.TryGetVehicleSimulatedTimelineData<HelicopterTimelineData>"
            inline constexpr std::uintptr_t TryGetVehicleSimulatedTimelineData_T_inst_3 = 0x126CFC0; // "VehicleUtils.TryGetVehicleSimulatedTimelineData<__Il2CppFullySharedGenericStructType>"
        }
    } // namespace VehicleUtils

    namespace VehicleVsCharacterCollisionClientSystem { // "Models.Systems.VehicleVsCharacterCollisionClientSystem (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t ApplyKnockdown = 0x7B3360; // "protected override void ApplyKnockdown(long now, BattleCharacterModel battleCharacter, VehicleModel vehicle, in Vector3 vehiclePosition, in Quaternion vehicleOrientation)"
        }
    } // namespace VehicleVsCharacterCollisionClientSystem

    namespace VehicleVsCharacterCollisionSystem { // "Models.Systems.VehicleVsCharacterCollisionSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsSceneModel = 0x10; // "PhysicsSceneModel"
            inline constexpr std::uintptr_t battleCharacters = 0x18; // "ReadOnly.Dictionary<int, BattleCharacterModel>"
            inline constexpr std::uintptr_t location = 0x20; // "LocationDescription"
            inline constexpr std::uintptr_t vehicleVsCharacterSpecialCollisions = 0x28; // "PhysicsLinkedListData<VehicleVsCharacterSpecialCollisionData>"
            inline constexpr std::uintptr_t allowedPenetration = 0x30; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x43729D0; // "public void Update(ITick tick)"
            inline constexpr std::uintptr_t HandleVehicleVsBattleCharacterCollision = 0x4372110; // "private void HandleVehicleVsBattleCharacterCollision(long now, VehicleModel vehicle, BattleCharacterModel battleCharacter, ref BroadPhaseContactData broadPhaseContact, bool isInverted)"
            inline constexpr std::uintptr_t IsKnockedDownByVehiclePressure = 0x43727E0; // "private bool IsKnockedDownByVehiclePressure(BattleCharacterModel battleCharacter, in Vector3 pressureDirection, float contactDistance)"
            inline constexpr std::uintptr_t IsKnockedDownByVehicleContactVelocity = 0x4372740; // "private bool IsKnockedDownByVehicleContactVelocity(in Vector3 vehicleLinearVelocity, in Vector3 contactDirectionTowardsCharacter, in Vector3 vehicleForward)"
            inline constexpr std::uintptr_t IsBattleCharacterHaveOppositePressure = 0x43723D0; // "private bool IsBattleCharacterHaveOppositePressure(BattleCharacterModel battleCharacter, in Vector3 pressureDirection)"
        }
    } // namespace VehicleVsCharacterCollisionSystem

    namespace VehicleWaterModel { // "Models.Models.VehicleWater.VehicleWaterModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t isDrowned = 0x10; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t state = 0x18; // "IPrimitiveData<VehicleWaterStateDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsDrowned = 0x48AA900; // "public bool get_IsDrowned()"
            inline constexpr std::uintptr_t set_IsDrowned = 0x48AAA10; // "public void set_IsDrowned(bool value)"
            inline constexpr std::uintptr_t get_State = 0x48AA950; // "public VehicleWaterStateDescription get_State()"
            inline constexpr std::uintptr_t set_State = 0x48AAA60; // "public void set_State(VehicleWaterStateDescription value)"
            inline constexpr std::uintptr_t Clear = 0x48AA810; // "public void Clear()"
        }
    } // namespace VehicleWaterModel

    namespace VehicleWaterStateDescription { // "Models.References.Vehicle.Water.VehicleWaterStateDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x8205790; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t enum_id = 0x0; // "Enum<VehicleWaterStateDescription>"
            inline constexpr std::uintptr_t NotInWater = 0x8; // "VehicleWaterStateDescription"
            inline constexpr std::uintptr_t UnderWater = 0x10; // "VehicleWaterStateDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Enum = 0x40812A0; // "public static ReadOnlyEnum<VehicleWaterStateDescription> get_Enum()"
        }
    } // namespace VehicleWaterStateDescription

    namespace VehicleWaterTickDataModel { // "Models.Models.TickDataModels.Vehicle.VehicleWaterTickDataModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t WaterState = 0x10; // "VehicleWaterStateDescription"
        }
    } // namespace VehicleWaterTickDataModel

    namespace VehicleWheelDescription { // "Models.References.Vehicle.VehicleWheelDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsForward = 0x10; // "bool"
            inline constexpr std::uintptr_t IsLeft = 0x11; // "bool"
            inline constexpr std::uintptr_t LinkLocalOffsetFromCenterOfMass = 0x14; // "Vector3"
        }
        namespace Methods {
            inline constexpr std::uintptr_t CalculateWheelsFromWheelBase = 0x4081390; // "public static IReadOnlyList<VehicleWheelDescription> CalculateWheelsFromWheelBase(in Vector3 centerOfMassToWheelBaseCenterOffsetInLocalSpace, float wheelBaseWidth, float wheelBaseLength)"
        }
    } // namespace VehicleWheelDescription

    namespace VehicleWheelGroundTickDataModel { // "Models.Models.TickDataModels.Vehicle.Wheel.VehicleWheelGroundTickDataModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t GroundSearchCastLength = 0x10; // "float"
            inline constexpr std::uintptr_t LargeSlopeGroundSurfaceAngleCos = 0x14; // "float"
            inline constexpr std::uintptr_t MaxAngleFromWheelsToGroundSurfaceCos = 0x18; // "float"
            inline constexpr std::uintptr_t TakeLargeSlopeAsGround = 0x1C; // "bool"
            inline constexpr std::uintptr_t GroundFound = 0x1D; // "bool"
            inline constexpr std::uintptr_t IsGroundWithLargeSlope = 0x1E; // "bool"
            inline constexpr std::uintptr_t GroundBodyId = 0x20; // "PhysicsBodyId"
            inline constexpr std::uintptr_t GroundContactPositionX = 0x28; // "float"
            inline constexpr std::uintptr_t GroundContactPositionY = 0x2C; // "float"
            inline constexpr std::uintptr_t GroundContactPositionZ = 0x30; // "float"
            inline constexpr std::uintptr_t GroundContactNormalX = 0x34; // "float"
            inline constexpr std::uintptr_t GroundContactNormalY = 0x38; // "float"
            inline constexpr std::uintptr_t GroundContactNormalZ = 0x3C; // "float"
            inline constexpr std::uintptr_t GroundContactDistance = 0x40; // "float"
            inline constexpr std::uintptr_t GroundContactSurfaceType = 0x44; // "byte"
            inline constexpr std::uintptr_t GroundOrientationMatrix = 0x48; // "float[]"
            inline constexpr std::uintptr_t IsTouchGround = 0x50; // "bool"
        }
    } // namespace VehicleWheelGroundTickDataModel

    namespace VehicleWheelLinkTickDataModel { // "Models.Models.TickDataModels.Vehicle.Wheel.VehicleWheelLinkTickDataModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t LinkPositionX = 0x10; // "float"
            inline constexpr std::uintptr_t LinkPositionY = 0x14; // "float"
            inline constexpr std::uintptr_t LinkPositionZ = 0x18; // "float"
            inline constexpr std::uintptr_t LinkOffsetX = 0x1C; // "float"
            inline constexpr std::uintptr_t LinkOffsetY = 0x20; // "float"
            inline constexpr std::uintptr_t LinkOffsetZ = 0x24; // "float"
        }
    } // namespace VehicleWheelLinkTickDataModel

    namespace VehicleWheelLoadTickDataModel { // "Models.Models.TickDataModels.Vehicle.Wheel.VehicleWheelLoadTickDataModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t EffectiveStaticModifier = 0x10; // "float"
            inline constexpr std::uintptr_t EffectiveStaticMass = 0x14; // "float"
            inline constexpr std::uintptr_t EffectiveStaticLoad = 0x18; // "float"
        }
    } // namespace VehicleWheelLoadTickDataModel

    namespace VehicleWheelsGroundCheckTerrainTriangleRaycastData { // "Models.Models.VehicleWheelsGroundCheckModels.VehicleWheelsGroundCheckTerrainTriangleRaycastData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Ax = 0x0; // "float"
            inline constexpr std::uintptr_t Ay = 0x4; // "float"
            inline constexpr std::uintptr_t Az = 0x8; // "float"
            inline constexpr std::uintptr_t Bx = 0xC; // "float"
            inline constexpr std::uintptr_t By = 0x10; // "float"
            inline constexpr std::uintptr_t Bz = 0x14; // "float"
            inline constexpr std::uintptr_t Cx = 0x18; // "float"
            inline constexpr std::uintptr_t Cy = 0x1C; // "float"
            inline constexpr std::uintptr_t Cz = 0x20; // "float"
            inline constexpr std::uintptr_t CastFromX = 0x24; // "float"
            inline constexpr std::uintptr_t CastFromY = 0x28; // "float"
            inline constexpr std::uintptr_t CastFromZ = 0x2C; // "float"
            inline constexpr std::uintptr_t CastDirectionX = 0x30; // "float"
            inline constexpr std::uintptr_t CastDirectionY = 0x34; // "float"
            inline constexpr std::uintptr_t CastDirectionZ = 0x38; // "float"
            inline constexpr std::uintptr_t CastLength = 0x3C; // "float"
            inline constexpr std::uintptr_t ResultContactNormalX = 0x40; // "float"
            inline constexpr std::uintptr_t ResultContactNormalY = 0x44; // "float"
            inline constexpr std::uintptr_t ResultContactNormalZ = 0x48; // "float"
            inline constexpr std::uintptr_t ResultContactDistance = 0x4C; // "float"
        }
    } // namespace VehicleWheelsGroundCheckTerrainTriangleRaycastData

    namespace VehicleWheelSlipAngleModel { // "Models.Models.VehicleWheelSlipAngle.VehicleWheelSlipAngleModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t valueData = 0x10; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t isSignPositiveData = 0x18; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t quantizeModel = 0x20; // "QuantizeModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Set = 0x48AAB10; // "public void Set(int quantizedValue)"
            inline constexpr std::uintptr_t get_Value = 0x48AAC70; // "public float get_Value()"
            inline constexpr std::uintptr_t ConvertToDiscrete = 0x48AAAB0; // "public void ConvertToDiscrete(float value, out float discreteValue, out int quantizedValue)"
            inline constexpr std::uintptr_t get_Sign = 0x48AAC10; // "public int get_Sign()"
            inline constexpr std::uintptr_t set_Sign = 0x48AACD0; // "public void set_Sign(int value)"
        }
    } // namespace VehicleWheelSlipAngleModel

    namespace VehicleWheelSlipRatioModel { // "Models.Models.VehicleWheelSlipRatio.VehicleWheelSlipRatioModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t valueData = 0x10; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t isSignPositiveData = 0x18; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t settings = 0x20; // "CarTireFrictionSettingsModel"
            inline constexpr std::uintptr_t quantizeModel = 0x28; // "QuantizeModel"
            inline constexpr std::uintptr_t min = 0x30; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Set = 0x48AAEE0; // "public void Set(int quantizedValue)"
            inline constexpr std::uintptr_t get_Value = 0x48AB070; // "public float get_Value()"
            inline constexpr std::uintptr_t ConvertToDiscrete = 0x48AAD20; // "public void ConvertToDiscrete(float value, out float discreteValue, out int quantizedValue)"
            inline constexpr std::uintptr_t get_Sign = 0x48AB010; // "public int get_Sign()"
            inline constexpr std::uintptr_t set_Sign = 0x48AB110; // "public void set_Sign(int value)"
            inline constexpr std::uintptr_t GetLength = 0x48AAE50; // "private float GetLength()"
            inline constexpr std::uintptr_t Normalize = 0x48AAE80; // "private float Normalize(float value)"
            inline constexpr std::uintptr_t Denormalize = 0x48AADF0; // "private float Denormalize(float normalizedValue)"
        }
    } // namespace VehicleWheelSlipRatioModel

    namespace VehicleWheelSpringModel { // "Models.Models.VehicleWheelSpring.VehicleWheelSpringModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t settings = 0x18; // "VehicleSuspensionSettingsModel"
            inline constexpr std::uintptr_t quantizeModel = 0x20; // "QuantizeModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Set = 0x48AB3C0; // "public void Set(int quantizedValue)"
            inline constexpr std::uintptr_t get_Value = 0x48AB4C0; // "public float get_Value()"
            inline constexpr std::uintptr_t ConvertToDiscrete = 0x48AB160; // "public void ConvertToDiscrete(float value, out float discreteValue, out int quantizedValue)"
            inline constexpr std::uintptr_t GetLength = 0x48AB2E0; // "private float GetLength()"
            inline constexpr std::uintptr_t Normalize = 0x48AB330; // "private float Normalize(float value)"
            inline constexpr std::uintptr_t Denormalize = 0x48AB250; // "private float Denormalize(float normalizedValue)"
        }
    } // namespace VehicleWheelSpringModel

    namespace VehicleWheelSuspensionLimitTickDataModel { // "Models.Models.TickDataModels.Vehicle.Wheel.VehicleWheelSuspensionLimitTickDataModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t AllowedPenetration = 0x10; // "float"
            inline constexpr std::uintptr_t ErrorCorrection = 0x14; // "float"
            inline constexpr std::uintptr_t Restitution = 0x18; // "float"
            inline constexpr std::uintptr_t SuspensionLimitConstraintId = 0x1C; // "int"
        }
    } // namespace VehicleWheelSuspensionLimitTickDataModel

    namespace VehicleWheelSuspensionTickDataModel { // "Models.Models.TickDataModels.Vehicle.Wheel.VehicleWheelSuspensionTickDataModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t SpringLength = 0x10; // "float"
            inline constexpr std::uintptr_t SuspensionTotalForce = 0x14; // "float"
        }
    } // namespace VehicleWheelSuspensionTickDataModel

    namespace WheelStiffnessExtensions { // "Models.Utils.Extensions.Vehicles.Car.WheelStiffnessExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t CalculateLongStiffnessForWheel = 0x3976DC0; // "public static float CalculateLongStiffnessForWheel(CarWheelFrictionTickDataModel wheelFrictionTickData, VehicleWheelGroundTickDataModel wheelGroundTickData)"
            inline constexpr std::uintptr_t CalculateLatStiffnessForWheel = 0x3976D90; // "public static float CalculateLatStiffnessForWheel(CarWheelFrictionTickDataModel wheelFrictionTickData, VehicleWheelGroundTickDataModel wheelGroundTickData)"
            inline constexpr std::uintptr_t CalculateBlockStiffnessForWheel = 0x3976D60; // "public static float CalculateBlockStiffnessForWheel(CarWheelFrictionTickDataModel wheelFrictionTickData, VehicleWheelGroundTickDataModel wheelGroundTickData)"
            inline constexpr std::uintptr_t CalculateStiffnessForWheel = 0x3976DF0; // "private static float CalculateStiffnessForWheel(float baseStiffness, bool isGroundWithLargeSlope, byte groundContactSurfaceType)"
        }
    } // namespace WheelStiffnessExtensions

} // namespace Offsets::Vehicles
