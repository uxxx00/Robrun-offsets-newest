#pragma once
#include <cstdint>

namespace Offsets::Player_Character {

    namespace AchievementPointerClickInputUpdater { // "Game.Battle.Achievement.AchievementPointerClickInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t button = 0x10; // "PointerButtonView"
            inline constexpr std::uintptr_t onClick = 0x18; // "Action<PointerButtonView>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xD41660; // "public void Update()"
        }
    } // namespace AchievementPointerClickInputUpdater

    namespace ActionInputsUpdater { // "Game.Global.ActionInputsUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t action = 0x10; // "Action<int>"
            inline constexpr std::uintptr_t inputs = 0x18; // "InputAction[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x36567B0; // "public void Update()"
        }
    } // namespace ActionInputsUpdater

    namespace ActionInputThisFrameUpdater { // "Game.Shared.ActionInputThisFrameUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t action = 0x10; // "Action"
            inline constexpr std::uintptr_t input = 0x18; // "InputAction"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x354FEE0; // "public void Update()"
        }
    } // namespace ActionInputThisFrameUpdater

    namespace ActionInputUpdater { // "Game.Shared.ActionInputUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t action = 0x10; // "Action"
            inline constexpr std::uintptr_t input = 0x18; // "InputAction"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x354FF30; // "public void Update()"
        }
    } // namespace ActionInputUpdater

    namespace ActionReleasedInputUpdater { // "Game.Global.ActionReleasedInputUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t action = 0x10; // "Action"
            inline constexpr std::uintptr_t input = 0x18; // "InputAction"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x3656850; // "public void Update()"
        }
    } // namespace ActionReleasedInputUpdater

    namespace ActionsMapEnabledByAuthorizedUpdater { // "Game.Battle.Inputs.ActionsMapEnabledByAuthorizedUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleModel = 0x10; // "BattleModel"
            inline constexpr std::uintptr_t roomConnectionInfo = 0x18; // "RoomConnectionInfo"
            inline constexpr std::uintptr_t actionMap = 0x20; // "InputEnabledModel"
            inline constexpr std::uintptr_t enabled = 0x28; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA71120; // "public void Update()"
        }
    } // namespace ActionsMapEnabledByAuthorizedUpdater

    namespace AdaptMoveInputToSprintSystem { // "Models.Systems.AdaptMoveInputToSprintSystem (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x3C77A00; // "protected override void Tick(ITick tick)"
            inline constexpr std::uintptr_t RotateYawVectorTowardsMoveInput = 0x3C77920; // "private static Vector2 RotateYawVectorTowardsMoveInput(Vector2 current, Vector2 target, PhysicsCharacterConfig config)"
        }
    } // namespace AdaptMoveInputToSprintSystem

    namespace AdditionalTargetPoint { // "Game.Battle.Entities.Player.BattleAssistance.AdditionalTargetPoint (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Transform = 0x10; // "Transform"
            inline constexpr std::uintptr_t Range = 0x18; // "TargetPointRange"
        }
    } // namespace AdditionalTargetPoint

    namespace AnimationStateAssistant { // "Game.Battle.Entities.BattleCharacter.AnimationStateAssistant (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t events = 0x20; // "Dictionary<AnimatorId.Layer, Dictionary<AnimatorId.State, AnimationStateAssistant.EventContainer>>"
            inline constexpr std::uintptr_t enteredStatesByLayer = 0x28; // "Dictionary<ValueTuple<AnimatorId.Layer, AnimatorId.State>, int>"
            inline constexpr std::uintptr_t enteredStates = 0x30; // "Dictionary<AnimatorId.State, int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Add = 0xBBB0F0; // "public void Add(int layer, AnimatorId.State state, AnimatorId.Event e, AnimatorStateInfo stateInfo)"
            inline constexpr std::uintptr_t Update = 0xBBB600; // "private void Update()"
            inline constexpr std::uintptr_t Clear = 0xBBB430; // "private void Clear()"
            inline constexpr std::uintptr_t IsInvoked = 0xBBB750; // "public bool IsInvoked(AnimatorId.Layer layer, AnimatorId.State state, AnimatorId.Event e)"
            inline constexpr std::uintptr_t TryGetInfo = 0xBBB840; // "public bool TryGetInfo(AnimatorId.Layer layer, AnimatorId.State state, out AnimatorStateInfo stateInfo)"
            inline constexpr std::uintptr_t IsInState = 0xBBB610; // "public bool IsInState(AnimatorId.State state)"
            inline constexpr std::uintptr_t IsInState_2 = 0xBBB690; // "public bool IsInState(AnimatorId.Layer layer, AnimatorId.State state)"
            inline constexpr std::uintptr_t Content_ContentWrappers_IComponentContent_ResetOnDisposeContent = 0xBBB600; // "private void Content.ContentWrappers.IComponentContent.ResetOnDisposeContent()"
        }
    } // namespace AnimationStateAssistant

    namespace AnimationStateAssistant_EventContainer { // "Game.Battle.Entities.BattleCharacter.AnimationStateAssistant.EventContainer (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Event1 = 0x0; // "AnimatorId.Event"
            inline constexpr std::uintptr_t Event2 = 0x1; // "AnimatorId.Event"
            inline constexpr std::uintptr_t Event3 = 0x2; // "AnimatorId.Event"
            inline constexpr std::uintptr_t Event4 = 0x3; // "AnimatorId.Event"
            inline constexpr std::uintptr_t AnimatorStateInfo = 0x4; // "AnimatorStateInfo"
            inline constexpr std::uintptr_t Count = 0x28; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Add = 0xBCB360; // "public void Add(AnimatorId.Event e)"
            inline constexpr std::uintptr_t IsInvoked = 0xBCB580; // "public bool IsInvoked(AnimatorId.Event e)"
        }
    } // namespace AnimationStateAssistant_EventContainer

    namespace AnimatorControllersPool { // "Game.Battle.Entities.BattleCharacter.AnimatorControllersPool (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dictionary = 0x10; // "Dictionary<BattleCharacterAnimatorLayerDescription, RuntimeAnimatorController>"
            inline constexpr std::uintptr_t unarmedPool = 0x18; // "ObjectPool<AnimatorOverrideController>"
            inline constexpr std::uintptr_t overridesBuffer = 0x20; // "List<KeyValuePair<AnimationClip, AnimationClip>>"
            inline constexpr std::uintptr_t unarmedBaseOverrides = 0x28; // "List<KeyValuePair<AnimationClip, AnimationClip>>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Controllers = 0x7EC6B0; // "public Dictionary<BattleCharacterAnimatorLayerDescription, RuntimeAnimatorController> get_Controllers()"
            inline constexpr std::uintptr_t TakeUnarmed = 0xBBBEC0; // "public AnimatorOverrideController TakeUnarmed()"
            inline constexpr std::uintptr_t ReleaseUnarmed = 0xBBBBA0; // "public void ReleaseUnarmed(AnimatorOverrideController controller)"
            inline constexpr std::uintptr_t Dispose = 0xBBBB50; // "public void Dispose()"
            inline constexpr std::uintptr_t Create = 0xBBBA40; // "private AnimatorOverrideController Create()"
            inline constexpr std::uintptr_t Release = 0xBBBD00; // "private void Release(AnimatorOverrideController controller)"
        }
    } // namespace AnimatorControllersPool

    namespace AnimatorLayerValue { // "Game.Global.CharacterAnimation.AnimatorLayerValue (Global.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x821A370; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace Fields {
            inline constexpr std::uintptr_t Id = 0x10; // "string"
        }
        namespace StaticFields {
            inline constexpr std::uintptr_t ids = 0x0; // "string[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Description = 0x36C42B0; // "public BattleCharacterAnimatorLayerDescription get_Description()"
            inline constexpr std::uintptr_t get_Ids = 0x36C4390; // "public static string[] get_Ids()"
        }
    } // namespace AnimatorLayerValue

    namespace ApplyInputSystem { // "Models.Systems.ApplyInputSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t snapshotsHistorySize = 0x38; // "int"
            inline constexpr std::uintptr_t worldInterruptModel = 0x40; // "IWorldInterruptModel"
            inline constexpr std::uintptr_t battleMode = 0x48; // "BattleModeDescription"
            inline constexpr std::uintptr_t dropCargoModel = 0x50; // "IDropCargoModel"
            inline constexpr std::uintptr_t crouchStandUpModel = 0x58; // "CrouchStandUpModel"
            inline constexpr std::uintptr_t vehicles = 0x60; // "VehiclesWorldModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x3C787E0; // "protected override void Tick(ITick tick)"
            inline constexpr std::uintptr_t InteractInput = 0x3C784F0; // "private void InteractInput(bool isInteractInput, int entityId, InteractModel interactModel, RequestModel<int> interactRequest, CharacterInterruptModel characterInterruptModel, CharacterValidationModel validationModel)"
            inline constexpr std::uintptr_t EmotionInput = 0x3C78260; // "private void EmotionInput(EmotionSlotDescription emotionSlot, RequestModel<EmotionDescription> emotionRequest, BecomeRobberModel becomeRobber, ArrestTargetModel arrestTarget, CharacterCargoModel cargoModel, int id, CrouchModel crouchModel, CharacterControllerModel characterControllerModel, MeleeAttackModel meleeAttackModel, CharacterValidationModel validationModel, ItemActionProcessModel itemActionProcess, EmotionSlotsModel emotionSlotsModel)"
            inline constexpr std::uintptr_t TryGetEmotion = 0x3C7CF50; // "private bool TryGetEmotion(EmotionSlotsModel emotionSlotsModel, EmotionSlotDescription slot, out EmotionDescription emotion)"
            inline constexpr std::uintptr_t CheckUseItemOnMove = 0x3C78160; // "private bool CheckUseItemOnMove(UsableItemDescription usableItem, VectorInputModel inputModel, CharacterControllerModel characterController)"
            inline constexpr std::uintptr_t StandUpCheck = 0x3C785B0; // "private bool StandUpCheck(int id, CrouchModel crouchModel, CharacterControllerModel characterControllerModel)"
            inline constexpr std::uintptr_t StopFire = 0x3C78620; // "private void StopFire(FireModel fireModel, IEventModel shotInput)"
            inline constexpr std::uintptr_t TryGetOtherWeapon = 0x3C7D050; // "private bool TryGetOtherWeapon(QuickSlotDescription currentWeaponSlot, QuickSlotsModel quickSlots, IEquipAmmoModel equipAmmoModel, out QuickSlotDescription otherWeaponSlot, out WeaponDescription otherWeaponSlotWeapon, out IAmmoModel otherWeaponAmmoModel)"
            inline constexpr std::uintptr_t StopSprint = 0x3C786B0; // "private void StopSprint(SprintModel sprintModel)"
            inline constexpr std::uintptr_t StopUnavailableWhileMovingItemUse = 0x3C786F0; // "private void StopUnavailableWhileMovingItemUse(ContextMenuUseItemModel contextMenuUseItemModel, SelectedQuickSlotModel selectedQuickSlot, IInventoryModel inventoryModel, IPocketsModel pockets, ItemActionProcessModel itemActionProcess, CharacterInterruptModel characterInterruptModel)"
        }
    } // namespace ApplyInputSystem

    namespace AuthorityCodexNoteUpdater { // "Game.Battle.Entities.Player.Updaters.AuthorityCodexNoteUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t authority = 0x10; // "RobberAuthorityModel"
            inline constexpr std::uintptr_t codex = 0x18; // "ClientCodexModel"
            inline constexpr std::uintptr_t points = 0x20; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB017C0; // "public void Update()"
        }
    } // namespace AuthorityCodexNoteUpdater

    namespace BackInputUpdater { // "Game.Battle.Player.BackInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t sideMenuDialog = 0x10; // "IScreenModel"
            inline constexpr std::uintptr_t backInputModel = 0x18; // "InputModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x95ECE0; // "public void Update()"
        }
    } // namespace BackInputUpdater

    namespace BattleAssistanceModel { // "Game.Battle.Entities.Player.BattleAssistance.BattleAssistanceModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsActive = 0x10; // "bool"
            inline constexpr std::uintptr_t MinDistance = 0x14; // "float"
            inline constexpr std::uintptr_t MaxDistance = 0x18; // "float"
            inline constexpr std::uintptr_t AssistanceWeaponViewDescription = 0x20; // "BattleAssistanceWeaponViewDescription"
            inline constexpr std::uintptr_t RaycastOrigin = 0x28; // "Vector3"
            inline constexpr std::uintptr_t AvailableIndexesHash = 0x34; // "int"
            inline constexpr std::uintptr_t AvailableIndexes = 0x38; // "List<int>"
            inline constexpr std::uintptr_t BattleAssistanceTargets = 0x40; // "Dictionary<int, BattleAssistanceTargetModel>"
            inline constexpr std::uintptr_t AimAssistTargets = 0x48; // "Dictionary<int, AimAssistTargetModel>"
            inline constexpr std::uintptr_t AutoFireTargets = 0x50; // "Dictionary<int, AutoFireTargetModel>"
            inline constexpr std::uintptr_t Colliders = 0x58; // "Dictionary<int, Collider>"
            inline constexpr std::uintptr_t dynamicIndexes = 0x60; // "HashSet<int>"
            inline constexpr std::uintptr_t regularGrid = 0x68; // "IRegularGrid"
        }
        namespace Methods {
            inline constexpr std::uintptr_t AddStaticTarget = 0xB34A90; // "public void AddStaticTarget(BattleAssistanceTargetView battleAssistanceView)"
            inline constexpr std::uintptr_t AddDynamicTarget = 0xB34A80; // "public void AddDynamicTarget(BattleAssistanceTargetView battleAssistanceView)"
            inline constexpr std::uintptr_t Add = 0xB34AA0; // "private void Add(BattleAssistanceTargetView battleAssistanceView, bool isDynamic)"
            inline constexpr std::uintptr_t Remove = 0xB34DC0; // "public void Remove(BattleAssistanceTargetView battleAssistanceView)"
            inline constexpr std::uintptr_t ContainsTarget = 0xB34D40; // "public bool ContainsTarget(Collider collider)"
            inline constexpr std::uintptr_t UpdateAvailableIndexes = 0xB34FA0; // "public void UpdateAvailableIndexes(Vector3 playerPosition, float distance)"
        }
    } // namespace BattleAssistanceModel

    namespace BattleAssistanceModelUpdater { // "Game.Battle.Entities.Player.BattleAssistance.BattleAssistanceModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleCameraModel = 0x10; // "BattleCameraModel"
            inline constexpr std::uintptr_t battleAssistanceModel = 0x18; // "BattleAssistanceModel"
            inline constexpr std::uintptr_t playerModel = 0x20; // "PlayerEntityModel"
            inline constexpr std::uintptr_t battleAssistanceViewDescription = 0x28; // "BattleAssistanceViewDescription"
            inline constexpr std::uintptr_t aimAssistModel = 0x30; // "AimAssistModel"
            inline constexpr std::uintptr_t autoFireModel = 0x38; // "AutoFireModel"
            inline constexpr std::uintptr_t weaponDescription = 0x40; // "WeaponDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB347E0; // "public void Update()"
        }
    } // namespace BattleAssistanceModelUpdater

    namespace BattleAssistanceTargetModel { // "Game.Battle.Entities.Player.BattleAssistance.BattleAssistanceTargetModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t DistanceToPlayer = 0x10; // "float"
            inline constexpr std::uintptr_t IsInScreenRange = 0x14; // "bool"
            inline constexpr std::uintptr_t CheckAdditionalPoints = 0x15; // "bool"
            inline constexpr std::uintptr_t MainTargetPointModel = 0x18; // "BattleAssistanceTargetPointModel"
            inline constexpr std::uintptr_t AdditionalTargetPointModels = 0x20; // "HashSet<BattleAssistanceTargetPointModel>"
            inline constexpr std::uintptr_t view = 0x28; // "BattleAssistanceTargetView"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_WorldCenterPoint = 0xB35AA0; // "public Vector3 get_WorldCenterPoint()"
            inline constexpr std::uintptr_t Reset = 0xB356C0; // "public void Reset()"
        }
    } // namespace BattleAssistanceTargetModel

    namespace BattleAssistanceTargetPointModel { // "Game.Battle.Entities.Player.BattleAssistance.BattleAssistanceTargetPointModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t DistanceFromScreenCenter = 0x10; // "float"
            inline constexpr std::uintptr_t IsInRange = 0x14; // "bool"
            inline constexpr std::uintptr_t IsInScreenCircle = 0x15; // "bool"
            inline constexpr std::uintptr_t IsReachableByRaycast = 0x16; // "bool"
            inline constexpr std::uintptr_t RangeType = 0x18; // "Nullable<TargetPointRange>"
            inline constexpr std::uintptr_t transform = 0x20; // "Transform"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_WorldPosition = 0xB35B70; // "public Vector3 get_WorldPosition()"
            inline constexpr std::uintptr_t Reset = 0xB35AF0; // "public void Reset()"
        }
    } // namespace BattleAssistanceTargetPointModel

    namespace BattleAssistanceTargetsUpdater { // "Game.Battle.Entities.Player.BattleAssistance.BattleAssistanceTargetsUpdater (Battle.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x823BD30; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace Fields {
            inline constexpr std::uintptr_t deviceScreenModel = 0x10; // "DeviceScreenModel"
            inline constexpr std::uintptr_t battleCameraModel = 0x18; // "BattleCameraModel"
            inline constexpr std::uintptr_t battleAssistanceModel = 0x20; // "BattleAssistanceModel"
            inline constexpr std::uintptr_t playerModel = 0x28; // "PlayerEntityModel"
            inline constexpr std::uintptr_t aimAssistModel = 0x30; // "AimAssistModel"
            inline constexpr std::uintptr_t autoFireModel = 0x38; // "AutoFireModel"
            inline constexpr std::uintptr_t raycastModel = 0x40; // "RaycastModel"
            inline constexpr std::uintptr_t physicsSceneModel = 0x48; // "PhysicsSceneModel"
            inline constexpr std::uintptr_t hitBoxesModel = 0x50; // "HitBoxesModel"
            inline constexpr std::uintptr_t camera = 0x58; // "Camera"
            inline constexpr std::uintptr_t battleAssistanceViewDescription = 0x60; // "BattleAssistanceViewDescription"
            inline constexpr std::uintptr_t availableIndexesHash = 0x68; // "int"
            inline constexpr std::uintptr_t currentTargetIndex = 0x6C; // "int"
        }
        namespace StaticFields {
            inline constexpr std::uintptr_t targetLayer = 0x0; // "int"
            inline constexpr std::uintptr_t layerMask = 0x4; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB37B40; // "public void Update()"
            inline constexpr std::uintptr_t UpdateTarget = 0xB377D0; // "private void UpdateTarget(BattleAssistanceTargetModel battleAssistanceTarget, Vector3 playerPosition)"
            inline constexpr std::uintptr_t IsInScreen = 0xB35FB0; // "private bool IsInScreen(Vector3 worldPosition)"
            inline constexpr std::uintptr_t IsBetweenCameraAndPlayer = 0xB35E70; // "private bool IsBetweenCameraAndPlayer(Vector3 worldPosition, Vector3 playerPosition)"
            inline constexpr std::uintptr_t UpdateTargetPoints = 0xB37640; // "private void UpdateTargetPoints(BattleAssistanceTargetModel battleAssistanceTarget)"
            inline constexpr std::uintptr_t UpdateTargetPoint = 0xB37310; // "private void UpdateTargetPoint(BattleAssistanceTargetPointModel targetPoint)"
            inline constexpr std::uintptr_t IsPointInsideScreenCircle = 0xB36080; // "private bool IsPointInsideScreenCircle(BattleAssistanceTargetPointModel targetPoint, float circleRadius)"
            inline constexpr std::uintptr_t UpdateAimAssistTarget = 0xB369B0; // "private void UpdateAimAssistTarget(BattleAssistanceTargetModel battleAssistanceTarget, AimAssistTargetModel aimAssistTargetModel)"
            inline constexpr std::uintptr_t UpdateAutoFireTarget = 0xB36C00; // "private void UpdateAutoFireTarget(BattleAssistanceTargetModel battleAssistanceTarget, AutoFireTargetModel autoFireTargetModel, Collider targetCollider, Vector3 playerPosition)"
            inline constexpr std::uintptr_t UpdateScreenRect = 0xB36FF0; // "private void UpdateScreenRect(BattleAssistanceTargetModel battleAssistanceTarget, Vector2 worldRectHalfSize, ref Rect rect)"
            inline constexpr std::uintptr_t IsScreenRectUnderAim = 0xB366B0; // "private bool IsScreenRectUnderAim(Rect rect)"
            inline constexpr std::uintptr_t UpdateReachableTargetPoints = 0xB36DD0; // "private void UpdateReachableTargetPoints(BattleAssistanceTargetModel battleAssistanceTarget, Collider targetCollider, Vector3 playerPosition)"
            inline constexpr std::uintptr_t IsTargetPointReachableByRaycast = 0xB367B0; // "private bool IsTargetPointReachableByRaycast(BattleAssistanceTargetPointModel targetPoint, Collider targetCollider, Vector3 playerPosition)"
            inline constexpr std::uintptr_t IsReachableByUnityRaycast = 0xB362E0; // "private bool IsReachableByUnityRaycast(Vector3 origin, Vector3 normalizedDirection, float distance, Collider targetCollider, Vector3 playerPosition)"
            inline constexpr std::uintptr_t IsReachableByCustomPhysics = 0xB360D0; // "private bool IsReachableByCustomPhysics(Vector3 origin, Vector3 normalizedDirection, float distance)"
        }
    } // namespace BattleAssistanceTargetsUpdater

    namespace BattleAssistanceUpdater { // "Game.Battle.Entities.Player.BattleAssistance.BattleAssistanceUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t updaters = 0x10; // "IUpdater[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x9AC080; // "public void Update()"
        }
    } // namespace BattleAssistanceUpdater

    namespace BattleCameraModel { // "Game.Battle.Entities.Player.Camera.BattleCameraModel (Battle.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x823C210; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace Fields {
            inline constexpr std::uintptr_t Position = 0x10; // "Vector3"
            inline constexpr std::uintptr_t Orientation = 0x1C; // "Quaternion"
            inline constexpr std::uintptr_t LookAtCameraOrientation = 0x2C; // "Quaternion"
            inline constexpr std::uintptr_t Forward = 0x3C; // "Vector3"
            inline constexpr std::uintptr_t Right = 0x48; // "Vector3"
            inline constexpr std::uintptr_t Up = 0x54; // "Vector3"
            inline constexpr std::uintptr_t DistanceToFollowTarget = 0x60; // "float"
        }
        namespace StaticFields {
            inline constexpr std::uintptr_t flip = 0x0; // "Quaternion"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetPositionAndRotation = 0xB1A220; // "public void SetPositionAndRotation(Vector3 position, Quaternion orientation)"
        }
    } // namespace BattleCameraModel

    namespace BattleCameraModelUpdater { // "Game.Battle.Entities.Player.Camera.BattleCameraModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "BattleCameraModel"
            inline constexpr std::uintptr_t camera = 0x18; // "Transform"
            inline constexpr std::uintptr_t characterFollowCamera = 0x20; // "Cinemachine3rdPersonFollow"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB19EE0; // "public void Update()"
        }
    } // namespace BattleCameraModelUpdater

    namespace BattleCharacterAmmoModel { // "Models.Models.AmmoModel.BattleCharacterAmmoModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t amountData = 0x10; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t hasArmor = 0x18; // "IPrimitiveData<bool>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Value = 0x49D5540; // "public int get_Value()"
            inline constexpr std::uintptr_t set_Value = 0x49D5590; // "public void set_Value(int value)"
        }
    } // namespace BattleCharacterAmmoModel

    namespace BattleCharacterAnimatorConfig { // "Models.References.Character.BattleCharacterAnimatorConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t NativeMotionMaxDuration = 0x10; // "long"
        }
    } // namespace BattleCharacterAnimatorConfig

    namespace BattleCharacterAnimatorLayerDescription { // "Models.References.Character.BattleCharacterAnimatorLayerDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x823CBD0; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace Fields {
            inline constexpr std::uintptr_t parentLayerFunc = 0x20; // "Func<BattleCharacterAnimatorLayerDescription>"
        }
        namespace StaticFields {
            inline constexpr std::uintptr_t enum_id = 0x0; // "Enum<BattleCharacterAnimatorLayerDescription>"
            inline constexpr std::uintptr_t Unarmed = 0x8; // "BattleCharacterAnimatorLayerDescription"
            inline constexpr std::uintptr_t Rifle = 0x10; // "BattleCharacterAnimatorLayerDescription"
            inline constexpr std::uintptr_t Pistol = 0x18; // "BattleCharacterAnimatorLayerDescription"
            inline constexpr std::uintptr_t UsableItem = 0x20; // "BattleCharacterAnimatorLayerDescription"
            inline constexpr std::uintptr_t Knockout = 0x28; // "BattleCharacterAnimatorLayerDescription"
            inline constexpr std::uintptr_t CargoBox = 0x30; // "BattleCharacterAnimatorLayerDescription"
            inline constexpr std::uintptr_t CargoBags = 0x38; // "BattleCharacterAnimatorLayerDescription"
            inline constexpr std::uintptr_t CargoBushes = 0x40; // "BattleCharacterAnimatorLayerDescription"
            inline constexpr std::uintptr_t BoxingUnarmed = 0x48; // "BattleCharacterAnimatorLayerDescription"
            inline constexpr std::uintptr_t ActionUpperBody = 0x50; // "BattleCharacterAnimatorLayerDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Enum = 0x4441730; // "public static ReadOnlyEnum<BattleCharacterAnimatorLayerDescription> get_Enum()"
            inline constexpr std::uintptr_t GetParentLayer = 0x9D6230; // "public BattleCharacterAnimatorLayerDescription GetParentLayer()"
            inline constexpr std::uintptr_t get_Default = 0x44416A0; // "public static BattleCharacterAnimatorLayerDescription get_Default()"
        }
    } // namespace BattleCharacterAnimatorLayerDescription

    namespace BattleCharacterAnimatorMaskDescription { // "Models.References.Character.BattleCharacterAnimatorMaskDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x823CD70; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace Fields {
            inline constexpr std::uintptr_t skeletonAnimationMasks = 0x20; // "Lazy<IReadOnlyDictionary<BattleCharacterAnimatorLayerDescription, ISkeletonAnimationMask>>"
        }
        namespace StaticFields {
            inline constexpr std::uintptr_t enum_id = 0x0; // "Enum<BattleCharacterAnimatorMaskDescription>"
            inline constexpr std::uintptr_t Empty = 0x8; // "BattleCharacterAnimatorMaskDescription"
            inline constexpr std::uintptr_t MeleeAttackUnarmedMale = 0x10; // "BattleCharacterAnimatorMaskDescription"
            inline constexpr std::uintptr_t MeleeAttackPistolMale = 0x18; // "BattleCharacterAnimatorMaskDescription"
            inline constexpr std::uintptr_t MeleeAttackRifleMale = 0x20; // "BattleCharacterAnimatorMaskDescription"
            inline constexpr std::uintptr_t MeleeAttackMP7Male = 0x28; // "BattleCharacterAnimatorMaskDescription"
            inline constexpr std::uintptr_t MeleeAttackP90Male = 0x30; // "BattleCharacterAnimatorMaskDescription"
            inline constexpr std::uintptr_t MeleeAttackVectorMale = 0x38; // "BattleCharacterAnimatorMaskDescription"
            inline constexpr std::uintptr_t BreakColliderUnarmedMale = 0x40; // "BattleCharacterAnimatorMaskDescription"
            inline constexpr std::uintptr_t ThrowActionMale = 0x48; // "BattleCharacterAnimatorMaskDescription"
            inline constexpr std::uintptr_t LootNodeGrab = 0x50; // "BattleCharacterAnimatorMaskDescription"
            inline constexpr std::uintptr_t ThrowAimingMale = 0x58; // "BattleCharacterAnimatorMaskDescription"
            inline constexpr std::uintptr_t ThrowAimingFemale = 0x60; // "BattleCharacterAnimatorMaskDescription"
            inline constexpr std::uintptr_t MeleeAttackUnarmedFemale = 0x68; // "BattleCharacterAnimatorMaskDescription"
            inline constexpr std::uintptr_t MeleeAttackPistolFemale = 0x70; // "BattleCharacterAnimatorMaskDescription"
            inline constexpr std::uintptr_t MeleeAttackRifleFemale = 0x78; // "BattleCharacterAnimatorMaskDescription"
            inline constexpr std::uintptr_t MeleeAttackMP7Female = 0x80; // "BattleCharacterAnimatorMaskDescription"
            inline constexpr std::uintptr_t MeleeAttackP90Female = 0x88; // "BattleCharacterAnimatorMaskDescription"
            inline constexpr std::uintptr_t MeleeAttackVectorFemale = 0x90; // "BattleCharacterAnimatorMaskDescription"
            inline constexpr std::uintptr_t BreakColliderUnarmedFemale = 0x98; // "BattleCharacterAnimatorMaskDescription"
            inline constexpr std::uintptr_t ThrowActionFemale = 0xA0; // "BattleCharacterAnimatorMaskDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Enum = 0x4443070; // "public static ReadOnlyEnum<BattleCharacterAnimatorMaskDescription> get_Enum()"
            inline constexpr std::uintptr_t GetSkeletonAnimationMask = 0x4441910; // "public ISkeletonAnimationMask GetSkeletonAnimationMask(BattleCharacterAnimatorLayerDescription layer)"
        }
    } // namespace BattleCharacterAnimatorMaskDescription

    namespace BattleCharacterAnimatorModel { // "Models.Models.BattleCharacterAnimator.BattleCharacterAnimatorModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t state = 0x10; // "IPrimitiveData<BattleCharacterAnimatorStateDescription>"
            inline constexpr std::uintptr_t lastMotionTime = 0x18; // "IPrimitiveData<BlendTreeMotionTime>"
            inline constexpr std::uintptr_t nativeMotionTimeLastUpdateTs = 0x20; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t nativeMotionTimeDuration = 0x28; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t nativeMotionTimeValueQuantized = 0x30; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t nativeMotionTimeValueQuantize = 0x38; // "QuantizeModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_State = 0x49D5C00; // "public BattleCharacterAnimatorStateDescription get_State()"
            inline constexpr std::uintptr_t get_LastMotionTime = 0x49D5A30; // "public BlendTreeMotionTime get_LastMotionTime()"
            inline constexpr std::uintptr_t get_NativeMotionTimeLastUpdateTs = 0x49D5B40; // "public long get_NativeMotionTimeLastUpdateTs()"
            inline constexpr std::uintptr_t get_NativeMotionTimeDuration = 0x49D5AF0; // "public long get_NativeMotionTimeDuration()"
            inline constexpr std::uintptr_t get_NativeMotionTimeValue = 0x49D5B90; // "public float get_NativeMotionTimeValue()"
            inline constexpr std::uintptr_t ConvertNativeMotionTimeValueToDiscrete = 0x49D5650; // "public void ConvertNativeMotionTimeValueToDiscrete(float value, out float discreteValue, out int quantizedValue)"
            inline constexpr std::uintptr_t Update = 0x49D5860; // "public void Update(BattleCharacterAnimatorStateDescription state, BlendTreeMotionTime lastMotionTime, long nativeMotionTimeLastUpdateTs, long nativeMotionTimeDuration, int nativeMotionTimeValueQuantized)"
            inline constexpr std::uintptr_t ResetOnRespawn = 0x49D56B0; // "public void ResetOnRespawn()"
        }
    } // namespace BattleCharacterAnimatorModel

    namespace BattleCharacterAnimatorSpineAdaptationDescription { // "Models.References.Character.BattleCharacterAnimatorSpineAdaptationDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Rotation = 0x10; // "Quaternion"
        }
    } // namespace BattleCharacterAnimatorSpineAdaptationDescription

    namespace BattleCharacterAnimatorStateDescription { // "Models.References.Character.BattleCharacterAnimatorStateDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x823D3F0; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace Fields {
            inline constexpr std::uintptr_t skeletonAnimationStates = 0x20; // "Lazy<IReadOnlyDictionary<BattleCharacterAnimatorLayerDescription, ISkeletonAnimationState>>"
        }
        namespace StaticFields {
            inline constexpr std::uintptr_t enum_id = 0x0; // "Enum<BattleCharacterAnimatorStateDescription>"
            inline constexpr std::uintptr_t Idle = 0x8; // "BattleCharacterAnimatorStateDescription"
            inline constexpr std::uintptr_t Movement = 0x10; // "BattleCharacterAnimatorStateDescription"
            inline constexpr std::uintptr_t Jump = 0x18; // "BattleCharacterAnimatorStateDescription"
            inline constexpr std::uintptr_t Falling = 0x20; // "BattleCharacterAnimatorStateDescription"
            inline constexpr std::uintptr_t GroundedIdle = 0x28; // "BattleCharacterAnimatorStateDescription"
            inline constexpr std::uintptr_t JumpInMotion = 0x30; // "BattleCharacterAnimatorStateDescription"
            inline constexpr std::uintptr_t FallingInMotion = 0x38; // "BattleCharacterAnimatorStateDescription"
            inline constexpr std::uintptr_t JumpInSprint = 0x40; // "BattleCharacterAnimatorStateDescription"
            inline constexpr std::uintptr_t FallingInSprint = 0x48; // "BattleCharacterAnimatorStateDescription"
            inline constexpr std::uintptr_t GroundedInMotion = 0x50; // "BattleCharacterAnimatorStateDescription"
            inline constexpr std::uintptr_t GroundedInSprint = 0x58; // "BattleCharacterAnimatorStateDescription"
            inline constexpr std::uintptr_t InsideCarDriver = 0x60; // "BattleCharacterAnimatorStateDescription"
            inline constexpr std::uintptr_t InsideCarPassenger = 0x68; // "BattleCharacterAnimatorStateDescription"
            inline constexpr std::uintptr_t InsideCarStartingEngine = 0x70; // "BattleCharacterAnimatorStateDescription"
            inline constexpr std::uintptr_t InsideHelicopterDriver = 0x78; // "BattleCharacterAnimatorStateDescription"
            inline constexpr std::uintptr_t InsideHelicopterPassenger = 0x80; // "BattleCharacterAnimatorStateDescription"
            inline constexpr std::uintptr_t InsideSportCarDriver = 0x88; // "BattleCharacterAnimatorStateDescription"
            inline constexpr std::uintptr_t InsideSportCarPassenger = 0x90; // "BattleCharacterAnimatorStateDescription"
            inline constexpr std::uintptr_t InsideSportCarStartingEngine = 0x98; // "BattleCharacterAnimatorStateDescription"
            inline constexpr std::uintptr_t UseMedKit = 0xA0; // "BattleCharacterAnimatorStateDescription"
            inline constexpr std::uintptr_t UseMedKitFinish = 0xA8; // "BattleCharacterAnimatorStateDescription"
            inline constexpr std::uintptr_t KnockdownInKnockout = 0xB0; // "BattleCharacterAnimatorStateDescription"
            inline constexpr std::uintptr_t KnockoutInMale = 0xB8; // "BattleCharacterAnimatorStateDescription"
            inline constexpr std::uintptr_t KnockoutInFemale = 0xC0; // "BattleCharacterAnimatorStateDescription"
            inline constexpr std::uintptr_t KnockoutInCrouchMale = 0xC8; // "BattleCharacterAnimatorStateDescription"
            inline constexpr std::uintptr_t KnockoutInCrouchFemale = 0xD0; // "BattleCharacterAnimatorStateDescription"
            inline constexpr std::uintptr_t KnockoutOut = 0xD8; // "BattleCharacterAnimatorStateDescription"
            inline constexpr std::uintptr_t Arresting = 0xE0; // "BattleCharacterAnimatorStateDescription"
            inline constexpr std::uintptr_t ArrestingInterrupt = 0xE8; // "BattleCharacterAnimatorStateDescription"
            inline constexpr std::uintptr_t ArrestedIdle = 0xF0; // "BattleCharacterAnimatorStateDescription"
            inline constexpr std::uintptr_t ArrestedIn = 0xF8; // "BattleCharacterAnimatorStateDescription"
            inline constexpr std::uintptr_t ArrestedOut = 0x100; // "BattleCharacterAnimatorStateDescription"
            inline constexpr std::uintptr_t KnockdownForward = 0x108; // "BattleCharacterAnimatorStateDescription"
            inline constexpr std::uintptr_t KnockdownBackward = 0x110; // "BattleCharacterAnimatorStateDescription"
            inline constexpr std::uintptr_t KnockdownArrestedForward = 0x118; // "BattleCharacterAnimatorStateDescription"
            inline constexpr std::uintptr_t KnockdownArrestedBackward = 0x120; // "BattleCharacterAnimatorStateDescription"
            inline constexpr std::uintptr_t SurrenderMovement = 0x128; // "BattleCharacterAnimatorStateDescription"
            inline constexpr std::uintptr_t BecomeRobberStandPreCast = 0x130; // "BattleCharacterAnimatorStateDescription"
            inline constexpr std::uintptr_t BecomeRobberStandPostCast = 0x138; // "BattleCharacterAnimatorStateDescription"
            inline constexpr std::uintptr_t BecomeRobberCrouchPreCast = 0x140; // "BattleCharacterAnimatorStateDescription"
            inline constexpr std::uintptr_t BecomeRobberCrouchPostCast = 0x148; // "BattleCharacterAnimatorStateDescription"
            inline constexpr std::uintptr_t BecomeRobberCast = 0x150; // "BattleCharacterAnimatorStateDescription"
            inline constexpr std::uintptr_t Unlocking = 0x158; // "BattleCharacterAnimatorStateDescription"
            inline constexpr std::uintptr_t Reviving = 0x160; // "BattleCharacterAnimatorStateDescription"
            inline constexpr std::uintptr_t SwimmingIdle = 0x168; // "BattleCharacterAnimatorStateDescription"
            inline constexpr std::uintptr_t SwimmingMovement = 0x170; // "BattleCharacterAnimatorStateDescription"
            inline constexpr std::uintptr_t SwimmingKnockdown = 0x178; // "BattleCharacterAnimatorStateDescription"
            inline constexpr std::uintptr_t SwimmingFallToWater = 0x180; // "BattleCharacterAnimatorStateDescription"
            inline constexpr std::uintptr_t EmotionPreCast = 0x188; // "BattleCharacterAnimatorStateDescription"
            inline constexpr std::uintptr_t EmotionCast = 0x190; // "BattleCharacterAnimatorStateDescription"
            inline constexpr std::uintptr_t ForceArresting = 0x198; // "BattleCharacterAnimatorStateDescription"
            inline constexpr std::uintptr_t ArrestedInKnockout = 0x1A0; // "BattleCharacterAnimatorStateDescription"
            inline constexpr std::uintptr_t DiggingInTrashCan = 0x1A8; // "BattleCharacterAnimatorStateDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Enum = 0x44634B0; // "public static ReadOnlyEnum<BattleCharacterAnimatorStateDescription> get_Enum()"
            inline constexpr std::uintptr_t GetSkeletonAnimationState = 0x445CB40; // "public ISkeletonAnimationState GetSkeletonAnimationState(BattleCharacterAnimatorLayerDescription layer)"
        }
    } // namespace BattleCharacterAnimatorStateDescription

    namespace BattleCharacterBurstingModel { // "Game.Battle.Entities.BattleCharacter.Shoot.BattleCharacterBurstingModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ShotPeriod = 0x10; // "float"
            inline constexpr std::uintptr_t ShotClips = 0x18; // "ShuffleContainer<AnimationIKClip>"
            inline constexpr std::uintptr_t FirstShot = 0x20; // "AnimationIKClip"
            inline constexpr std::uintptr_t IsFiring = 0x28; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Clear = 0xBD3510; // "public void Clear()"
        }
    } // namespace BattleCharacterBurstingModel

    namespace BattleCharacterCameraModel { // "Models.Models.BattleCharacterCamera.BattleCharacterCameraModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleCharacterConfig = 0x10; // "BattleCharacterConfig"
            inline constexpr std::uintptr_t aimingModel = 0x18; // "AimingModel"
            inline constexpr std::uintptr_t crouchModel = 0x20; // "CrouchModel"
            inline constexpr std::uintptr_t weaponModel = 0x28; // "IWeaponModel"
            inline constexpr std::uintptr_t bodyIdModel = 0x30; // "BodyIdModel"
            inline constexpr std::uintptr_t aimModeModel = 0x38; // "IPrimitiveModel<AimModeDescription>"
            inline constexpr std::uintptr_t isLeftShoulderView = 0x40; // "IPrimitiveModel<bool>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t CalculateCameraPositionForShot = 0x49D5FE0; // "public Vector3 CalculateCameraPositionForShot(in Vector3 battleCharacterShotTransformPosition, in Quaternion battleCharacterShotLookRotation, long now, SphereCastModel sphereCastModel, PhysicsData physicsData)"
            inline constexpr std::uintptr_t CalculateCameraPositionForInteract = 0x49D5CC0; // "public Vector3 CalculateCameraPositionForInteract(in Vector3 battleCharacterTransformPosition, in Quaternion battleCharacterLookRotation, long now, SphereCastModel sphereCastModel, PhysicsData physicsData)"
            inline constexpr std::uintptr_t CalculateCameraPositionForThreatNpc = 0x49D64E0; // "public Vector3 CalculateCameraPositionForThreatNpc(in Vector3 battleCharacterTransformPosition, in Vector3 battleCharacterLookDirection, long now)"
            inline constexpr std::uintptr_t get_IsLeftShoulder = 0x49D6790; // "private bool get_IsLeftShoulder()"
        }
    } // namespace BattleCharacterCameraModel

    namespace BattleCharacterClientModel { // "Game.Battle.EntityModel.BattleCharacter.BattleCharacterClientModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ReceiveDamageFromPlayerModel = 0x128; // "CharacterReceiveDamageFromPlayerModel"
            inline constexpr std::uintptr_t IsInstantDead = 0x130; // "bool"
        }
    } // namespace BattleCharacterClientModel

    namespace BattleCharacterCommonData { // "Models.Data.BattleCharacterCommonData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Role = 0x20; // "IPrimitiveData<PlayerRoleDescription>"
            inline constexpr std::uintptr_t Position = 0x28; // "IPrimitiveData<Vector3>"
            inline constexpr std::uintptr_t LookDirection = 0x30; // "IPrimitiveData<Vector3>"
            inline constexpr std::uintptr_t Rx = 0x38; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t Ry = 0x40; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t Rz = 0x48; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t TurningStartTs = 0x50; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t TurningToLeft = 0x58; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t TurningOriginalYaw = 0x60; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t IsFiring = 0x68; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t ShotEndTs = 0x70; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t CharacterControllerState = 0x78; // "IPrimitiveData<CharacterControllerStateDescription>"
            inline constexpr std::uintptr_t GroundSurfaceType = 0x80; // "IPrimitiveData<byte>"
            inline constexpr std::uintptr_t IsSprinting = 0x88; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t ReloadState = 0x90; // "IPrimitiveData<WeaponReloadStateDescription>"
            inline constexpr std::uintptr_t ReloadEndTs = 0x98; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t IsBackgroundReload = 0xA0; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t IsCrouching = 0xA8; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t CrouchTransitionEndTs = 0xB0; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t ItemInHands = 0xB8; // "IPrimitiveData<InventoryItemDescription>"
            inline constexpr std::uintptr_t QuickSlotSelectTs = 0xC0; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t ItemActionType = 0xC8; // "IPrimitiveData<ItemActionTypeDescription>"
            inline constexpr std::uintptr_t ItemActionCastProcess = 0xD0; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t ItemActionProcessEndTs = 0xD8; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t IsDead = 0xE0; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t WeaponClickTickIndex = 0xE8; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t VehicleEntityId = 0xF0; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t VehicleSeatSlot = 0xF8; // "IPrimitiveData<VehicleSeatSlotDescription>"
            inline constexpr std::uintptr_t BattleStance = 0x100; // "IPrimitiveData<BattleStanceDescription>"
            inline constexpr std::uintptr_t IsArmed = 0x108; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t Customization = 0x110; // "CustomizationData"
            inline constexpr std::uintptr_t CustomizationVersion = 0x118; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t SurrenderTs = 0x120; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t SurrenderCommandTs = 0x128; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t ArrestTs = 0x130; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t ArrestState = 0x138; // "IPrimitiveData<ArrestStateDescription>"
            inline constexpr std::uintptr_t UncuffBySomeoneTs = 0x140; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t ThreatenTs = 0x148; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t MeleeAttackHitTs = 0x150; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t KnockoutEndTs = 0x158; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t KnockoutPhase = 0x160; // "IPrimitiveData<KnockoutPhaseDescription>"
            inline constexpr std::uintptr_t KnockoutHitDirectionSectorIndex = 0x168; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t ReviveEndTs = 0x170; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t BreakColliderHitTs = 0x178; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t CopCustomize = 0x180; // "IPrimitiveData<CopCustomizeDescription>"
            inline constexpr std::uintptr_t KnockdownEndTs = 0x188; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t IsKnockedForward = 0x190; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t EmotionEndTs = 0x198; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t Emotion = 0x1A0; // "IPrimitiveData<EmotionDescription>"
            inline constexpr std::uintptr_t ProlongedInteractionEntityId = 0x1A8; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t ProlongedInteractionEndTs = 0x1B0; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t MutuallyExclusiveProcess = 0x1B8; // "IPrimitiveData<MutuallyExclusiveProcessesDescription>"
            inline constexpr std::uintptr_t Cargo = 0x1C0; // "CargoData"
            inline constexpr std::uintptr_t BlindedEffect = 0x1C8; // "IPrimitiveData<BlindedEffectDescription>"
            inline constexpr std::uintptr_t CurrentWeaponSkin = 0x1D0; // "IPrimitiveData<WeaponSkinDescription>"
            inline constexpr std::uintptr_t AnimatorState = 0x1D8; // "IPrimitiveData<BattleCharacterAnimatorStateDescription>"
            inline constexpr std::uintptr_t AnimatorLastMotionTime = 0x1E0; // "IPrimitiveData<BlendTreeMotionTime>"
            inline constexpr std::uintptr_t AnimatorNativeMotionTimeLastUpdateTs = 0x1E8; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t AnimatorNativeMotionTimeDuration = 0x1F0; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t AnimatorNativeMotionTimeValueQuantized = 0x1F8; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t ImmuneEndTs = 0x200; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t IsLeftShoulderView = 0x208; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t HasMovementIntention = 0x210; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t BribeCoinsAmount = 0x218; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t TimeFalling = 0x220; // "IPrimitiveData<long>"
        }
    } // namespace BattleCharacterCommonData

    namespace BattleCharacterConfig { // "Models.References.Character.BattleCharacterConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t InteractDescription = 0x10; // "InteractDescription"
            inline constexpr std::uintptr_t PhysicsCharacter = 0x18; // "PhysicsCharacterConfig"
            inline constexpr std::uintptr_t SkeletonDeformation = 0x20; // "BattleCharacterSkeletonDeformationConfig"
            inline constexpr std::uintptr_t MaxHealth = 0x28; // "int"
            inline constexpr std::uintptr_t CriticalHealth = 0x2C; // "int"
            inline constexpr std::uintptr_t CameraStand = 0x30; // "TripodDescription"
            inline constexpr std::uintptr_t CameraCrouch = 0x48; // "TripodDescription"
            inline constexpr std::uintptr_t CameraRadius = 0x60; // "float"
            inline constexpr std::uintptr_t CameraRadiusCastAgainstTripodHandModifier = 0x64; // "float"
            inline constexpr std::uintptr_t SprintTransitionTime = 0x68; // "long"
            inline constexpr std::uintptr_t SprintCooldownTime = 0x70; // "long"
            inline constexpr std::uintptr_t MaxSprintAngleDot = 0x78; // "float"
            inline constexpr std::uintptr_t CrouchTransitionTime = 0x80; // "long"
            inline constexpr std::uintptr_t StartInventoryLinesCount = 0x88; // "int"
            inline constexpr std::uintptr_t StartPocketsCount = 0x8C; // "int"
            inline constexpr std::uintptr_t EmptyHandsCharacterSpeed = 0x90; // "CharacterSpeed"
            inline constexpr std::uintptr_t CargoCharacterSpeed = 0x98; // "CharacterSpeed"
            inline constexpr std::uintptr_t KnockoutCharacterSpeed = 0xA0; // "CharacterSpeed"
            inline constexpr std::uintptr_t SwimmingCharacterSpeed = 0xA8; // "CharacterSpeed"
            inline constexpr std::uintptr_t ForwardSpeedMinCos = 0xB0; // "float"
            inline constexpr std::uintptr_t SideSpeedMinCos = 0xB4; // "float"
            inline constexpr std::uintptr_t JumpStartVelocityY = 0xB8; // "float"
            inline constexpr std::uintptr_t AirControlAcceleration = 0xBC; // "float"
            inline constexpr std::uintptr_t AirControlMaxVelocity = 0xC0; // "float"
            inline constexpr std::uintptr_t WeaponSpreadMovingSqrThreshold = 0xC4; // "float"
            inline constexpr std::uintptr_t CheatSprintModifier = 0xC8; // "float"
            inline constexpr std::uintptr_t BlockableShotRange = 0xCC; // "float"
            inline constexpr std::uintptr_t GrenadeThrowPositionStandOffset = 0xD0; // "Vector3"
            inline constexpr std::uintptr_t GrenadeThrowPositionCrouchOffset = 0xDC; // "Vector3"
            inline constexpr std::uintptr_t DeathFromWaterOffsetY = 0xE8; // "float"
            inline constexpr std::uintptr_t SprintRelativeVelocityThreshold = 0xEC; // "float"
            inline constexpr std::uintptr_t MaxTimeFallingToRegister = 0xF0; // "long"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Stamina = 0x44653C0; // "public BattleCharacterStaminaConfig get_Stamina()"
        }
    } // namespace BattleCharacterConfig

    namespace BattleCharacterContactEventData { // "Models.Models.BattleCharacterContactEventsModel.BattleCharacterContactEventData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ContactNormalOnObstacle = 0x0; // "Vector3"
        }
    } // namespace BattleCharacterContactEventData

    namespace BattleCharacterControllerRigidBodyEnabledUpdater { // "Game.Battle.EntityModel.BattleCharacter.BattleCharacterControllerRigidBodyEnabledUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t playerEntityId = 0x10; // "int"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x18; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t time = 0x20; // "TimeModel"
            inline constexpr std::uintptr_t physicsSceneModel = 0x28; // "PhysicsSceneModel"
            inline constexpr std::uintptr_t previousTickIndex = 0x30; // "long"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xCB0E20; // "public void Update()"
        }
    } // namespace BattleCharacterControllerRigidBodyEnabledUpdater

    namespace BattleCharacterData { // "Models.Data.BattleCharacterData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t CommonData = 0x20; // "BattleCharacterCommonData"
            inline constexpr std::uintptr_t PrivateData = 0x28; // "BattleCharacterPrivateData"
            inline constexpr std::uintptr_t PublicData = 0x30; // "BattleCharacterPublicData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t CreateBattleCharacter = 0x4A67BA0; // "public static BattleCharacterData CreateBattleCharacter()"
            inline constexpr std::uintptr_t CreatePrivateBattleCharacter = 0x4A67C80; // "public static BattleCharacterData CreatePrivateBattleCharacter(BattleCharacterCommonData commonData, BattleCharacterPrivateData privateData)"
            inline constexpr std::uintptr_t CreatePublicBattleCharacter = 0x4A67D90; // "public static BattleCharacterData CreatePublicBattleCharacter(BattleCharacterCommonData commonData, BattleCharacterPublicData publicData)"
        }
    } // namespace BattleCharacterData

    namespace BattleCharacterEntityModel { // "Game.Battle.EntityModel.BattleCharacter.BattleCharacterEntityModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t slots = 0x18; // "ClientCharacterSlotsModel"
            inline constexpr std::uintptr_t ClientModel = 0x20; // "BattleCharacterClientModel"
            inline constexpr std::uintptr_t ServerModel = 0x28; // "BattleCharacterModel"
            inline constexpr std::uintptr_t SimulatedModel = 0x30; // "BattleCharacterModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_BattleCharacterSlotModel = 0xCB2520; // "public BattleCharacterSlotModel get_BattleCharacterSlotModel()"
            inline constexpr std::uintptr_t get_PublicId = 0xCB2550; // "public long get_PublicId()"
        }
    } // namespace BattleCharacterEntityModel

    namespace BattleCharacterEntityModelUpdater { // "Game.Battle.EntityModel.BattleCharacter.BattleCharacterEntityModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t server = 0x10; // "BattleCharacterModel"
            inline constexpr std::uintptr_t idleUpdater = 0x18; // "IUpdater"
            inline constexpr std::uintptr_t updater = 0x20; // "IUpdater"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xCB1020; // "public void Update()"
        }
    } // namespace BattleCharacterEntityModelUpdater

    namespace BattleCharacterHoldingCellModel { // "Models.Models.BattleCharacterHoldingCell.BattleCharacterHoldingCellModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t holdingCellReleaseTs = 0x10; // "IPrimitiveData<long>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_HoldingCellReleaseTs = 0x49D6970; // "public long get_HoldingCellReleaseTs()"
            inline constexpr std::uintptr_t set_HoldingCellReleaseTs = 0x49D69C0; // "public void set_HoldingCellReleaseTs(long value)"
        }
    } // namespace BattleCharacterHoldingCellModel

    namespace BattleCharacterImmuneStateExtensions { // "Models.Utils.Extensions.BattleCharacterImmuneStateExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t SetImmuneState = 0x3931910; // "public static void SetImmuneState(BattleModeDescription battleMode, int entityId, CharacterImmuneStateModel immuneState, long endTs, HashSet<int> charactersWithImmune)"
        }
    } // namespace BattleCharacterImmuneStateExtensions

    namespace BattleCharacterInterruptionsByCharacterControllerSystem { // "Models.Systems.BattleCharacterInterruptionsByCharacterControllerSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dropCargoModel = 0x38; // "IDropCargoModel"
            inline constexpr std::uintptr_t worldInterruptModel = 0x40; // "IWorldInterruptModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x3F7B450; // "protected override void Tick(ITick tick)"
        }
    } // namespace BattleCharacterInterruptionsByCharacterControllerSystem

    namespace BattleCharacterLootNotificationModel { // "Models.Models.BattleCharacterLootNotification.BattleCharacterLootNotificationModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t items = 0x10; // "List<ValueTuple<InventoryItemDescription, int, bool>>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Items = 0x7EC6B0; // "public IReadOnlyCollection<ValueTuple<InventoryItemDescription, int, bool>> get_Items()"
            inline constexpr std::uintptr_t LootReceived = 0x49D6D70; // "public void LootReceived(InventoryItemDescription item, int amount)"
            inline constexpr std::uintptr_t LootLost = 0x49D6D50; // "public void LootLost(InventoryItemDescription item, int amount)"
            inline constexpr std::uintptr_t Add = 0x49D6B60; // "private void Add(InventoryItemDescription item, int amount, bool isLost)"
            inline constexpr std::uintptr_t Clear = 0x49D6CF0; // "public void Clear()"
        }
    } // namespace BattleCharacterLootNotificationModel

    namespace BattleCharacterModel { // "Models.Models.BattleCharacter.BattleCharacterModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t PrivateModel = 0x10; // "BattleCharacterPrivateModel"
            inline constexpr std::uintptr_t Events = 0x18; // "EventsModel"
            inline constexpr std::uintptr_t GroundedEvent = 0x20; // "IEventModel"
            inline constexpr std::uintptr_t SwimmingStartEvent = 0x28; // "IEventModel"
            inline constexpr std::uintptr_t EnteredDeepWaterEvent = 0x30; // "IEventModel"
            inline constexpr std::uintptr_t Id = 0x38; // "int"
            inline constexpr std::uintptr_t Data = 0x40; // "BattleCharacterData"
            inline constexpr std::uintptr_t Config = 0x48; // "BattleCharacterConfig"
            inline constexpr std::uintptr_t BodyIdModel = 0x50; // "BodyIdModel"
            inline constexpr std::uintptr_t Transform = 0x58; // "ITransformModel"
            inline constexpr std::uintptr_t ReplicatedTransform = 0x60; // "CharacterReplicatedTransformModel"
            inline constexpr std::uintptr_t LastPositionModel = 0x68; // "LastPositionModel"
            inline constexpr std::uintptr_t LookDirection = 0x70; // "LookDirectionModel"
            inline constexpr std::uintptr_t ReplicatedLookDirection = 0x78; // "ReplicatedLookDirectionModel"
            inline constexpr std::uintptr_t TurningModel = 0x80; // "TurningModel"
            inline constexpr std::uintptr_t LastLookDirection = 0x88; // "LastLookDirectionModel"
            inline constexpr std::uintptr_t InputsModel = 0x90; // "InputsModel"
            inline constexpr std::uintptr_t Input = 0x98; // "InputModel"
            inline constexpr std::uintptr_t LastInput = 0xA0; // "InputModel"
            inline constexpr std::uintptr_t MoveInput = 0xA8; // "VectorInputModel"
            inline constexpr std::uintptr_t LookDirectionInput = 0xB0; // "LookDirectionInputModel"
            inline constexpr std::uintptr_t Velocity = 0xB8; // "CharacterVelocityModel"
            inline constexpr std::uintptr_t FireModel = 0xC0; // "FireModel"
            inline constexpr std::uintptr_t CharacterControllerState = 0xC8; // "IPrimitiveModel<CharacterControllerStateDescription>"
            inline constexpr std::uintptr_t CharacterControllerGroundModel = 0xD0; // "CharacterControllerGroundModel"
            inline constexpr std::uintptr_t GroundConstraintsModel = 0xD8; // "GroundConstraintsModel"
            inline constexpr std::uintptr_t WaterConstraintsModel = 0xE0; // "WaterConstraintsModel"
            inline constexpr std::uintptr_t CharacterControllerWaterModel = 0xE8; // "CharacterControllerWaterModel"
            inline constexpr std::uintptr_t IsDead = 0xF0; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t ShotArgsModel = 0xF8; // "ShotArgsModel"
            inline constexpr std::uintptr_t ShotResultModel = 0x100; // "ShotResultModel"
            inline constexpr std::uintptr_t ShotInterpolationModel = 0x108; // "ShotInterpolationModel"
            inline constexpr std::uintptr_t DamageImmuneModel = 0x110; // "DamageImmuneModel"
            inline constexpr std::uintptr_t MoveDirectionModel = 0x118; // "IMoveDirectionModel"
            inline constexpr std::uintptr_t HitBoxAccess = 0x120; // "IHitBoxAccessModel"
            inline constexpr std::uintptr_t HitBoxId = 0x128; // "HitBoxIdModel"
            inline constexpr std::uintptr_t SkeletonAnimationModel = 0x130; // "SkeletonAnimationModel"
            inline constexpr std::uintptr_t SkeletonModel = 0x138; // "SkeletonModel"
            inline constexpr std::uintptr_t Animator = 0x140; // "BattleCharacterAnimatorModel"
            inline constexpr std::uintptr_t IsSprintingModel = 0x148; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t Weapon = 0x150; // "IWeaponModel"
            inline constexpr std::uintptr_t WeaponReload = 0x158; // "WeaponReloadModel"
            inline constexpr std::uintptr_t CrouchModel = 0x160; // "CrouchModel"
            inline constexpr std::uintptr_t QuickSlotSelectProgress = 0x168; // "QuickSlotSelectProgressModel"
            inline constexpr std::uintptr_t ItemInHandsModel = 0x170; // "ItemInHandsModel"
            inline constexpr std::uintptr_t ExitModel = 0x178; // "CharacterExitModel"
            inline constexpr std::uintptr_t CharacterSpeedModel = 0x180; // "CharacterSpeedModel"
            inline constexpr std::uintptr_t ItemActionProcess = 0x188; // "ItemActionProcessModel"
            inline constexpr std::uintptr_t ThrowItem = 0x190; // "ThrowItemModel"
            inline constexpr std::uintptr_t PhysicsContactEvents = 0x198; // "IEventsSet<BattleCharacterContactEventData>"
            inline constexpr std::uintptr_t UsableItemModel = 0x1A0; // "UsableItemModel"
            inline constexpr std::uintptr_t ThrowableItemModel = 0x1A8; // "ThrowableItemModel"
            inline constexpr std::uintptr_t EnterLeaveVehicleRequestModel = 0x1B0; // "EnterLeaveVehicleRequestModel"
            inline constexpr std::uintptr_t HasArmor = 0x1B8; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t WeaponClickTickIndex = 0x1C0; // "IPrimitiveModel<int>"
            inline constexpr std::uintptr_t InVehicleModel = 0x1C8; // "InVehicleModel"
            inline constexpr std::uintptr_t CarInput = 0x1D0; // "BattleCharacterCarInputModel"
            inline constexpr std::uintptr_t HelicopterInput = 0x1D8; // "BattleCharacterHelicopterInputModel"
            inline constexpr std::uintptr_t StateModel = 0x1E0; // "IBattleCharacterStateModel"
            inline constexpr std::uintptr_t RigidBodyEnabled = 0x1E8; // "IRigidBodyEnabledModel"
            inline constexpr std::uintptr_t BattleStanceModel = 0x1F0; // "BattleStanceModel"
            inline constexpr std::uintptr_t ArmedModel = 0x1F8; // "ArmedModel"
            inline constexpr std::uintptr_t IsBackgroundReload = 0x200; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t Role = 0x208; // "IPrimitiveModel<PlayerRoleDescription>"
            inline constexpr std::uintptr_t RestoreHealthModel = 0x210; // "RestoreHealthModel"
            inline constexpr std::uintptr_t ChangeRoleTickIndexModel = 0x218; // "ChangeRoleTickIndexModel"
            inline constexpr std::uintptr_t DeserterModel = 0x220; // "DeserterModel"
            inline constexpr std::uintptr_t DesiredYawModel = 0x228; // "DesiredYawModel"
            inline constexpr std::uintptr_t CustomizationModel = 0x230; // "ICustomizationModel"
            inline constexpr std::uintptr_t CustomizationVersionModel = 0x238; // "ICustomizationVersionModel"
            inline constexpr std::uintptr_t AoiModel = 0x240; // "EntityAoiModel"
            inline constexpr std::uintptr_t SurrenderCommandModel = 0x248; // "SurrenderCommandModel"
            inline constexpr std::uintptr_t ArrestTargetModel = 0x250; // "ArrestTargetModel"
            inline constexpr std::uintptr_t PlayerBattleModel = 0x258; // "PlayerBattleModel"
            inline constexpr std::uintptr_t BecomeRobberModel = 0x260; // "BecomeRobberModel"
            inline constexpr std::uintptr_t RobberInventoryCostModel = 0x268; // "RobberInventoryCostModel"
            inline constexpr std::uintptr_t ThreatenTs = 0x270; // "IPrimitiveModel<long>"
            inline constexpr std::uintptr_t LootNotification = 0x278; // "BattleCharacterLootNotificationModel"
            inline constexpr std::uintptr_t ShotDebugInfoModel = 0x280; // "IShotDebugInfoModel"
            inline constexpr std::uintptr_t MeleeAttackModel = 0x288; // "MeleeAttackModel"
            inline constexpr std::uintptr_t CenterPosition = 0x290; // "IPositionModel"
            inline constexpr std::uintptr_t KnockoutModel = 0x298; // "KnockoutModel"
            inline constexpr std::uintptr_t RevivalModel = 0x2A0; // "RevivalModel"
            inline constexpr std::uintptr_t SubscribeEntities = 0x2A8; // "SubscribeEntitiesModel"
            inline constexpr std::uintptr_t RoleTimeModel = 0x2B0; // "RoleTimeModel"
            inline constexpr std::uintptr_t ClientNotifications = 0x2B8; // "IClientNotificationsCollection"
            inline constexpr std::uintptr_t BreakColliderModel = 0x2C0; // "BreakColliderModel"
            inline constexpr std::uintptr_t CopCustomizeModel = 0x2C8; // "CopCustomizeModel"
            inline constexpr std::uintptr_t KnockdownModel = 0x2D0; // "KnockdownModel"
            inline constexpr std::uintptr_t KnockdownLeaveStateModel = 0x2D8; // "KnockdownLeaveStateModel"
            inline constexpr std::uintptr_t EmotionModel = 0x2E0; // "EmotionModel"
            inline constexpr std::uintptr_t CargoModel = 0x2E8; // "CharacterCargoModel"
            inline constexpr std::uintptr_t ValidationModel = 0x2F0; // "CharacterValidationModel"
            inline constexpr std::uintptr_t BlindedEffectModel = 0x2F8; // "IPrimitiveModel<BlindedEffectDescription>"
            inline constexpr std::uintptr_t YawTowardsWorldObjectsModel = 0x300; // "YawTowardsWorldObjectsModel"
            inline constexpr std::uintptr_t CurrentWeaponSkin = 0x308; // "IPrimitiveModel<WeaponSkinDescription>"
            inline constexpr std::uintptr_t SurrenderStateModel = 0x310; // "SurrenderStateModel"
            inline constexpr std::uintptr_t CapsuleColliderParams = 0x318; // "ICapsuleColliderParamsModel"
            inline constexpr std::uintptr_t ImmuneStateModel = 0x320; // "CharacterImmuneStateModel"
            inline constexpr std::uintptr_t IsLeftShoulderView = 0x328; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t HasMovementIntention = 0x330; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t BribeModel = 0x338; // "BribeModel"
            inline constexpr std::uintptr_t ProlongedInteractionModel = 0x340; // "ProlongedInteractionModel"
            inline constexpr std::uintptr_t TimeFalling = 0x348; // "IPrimitiveModel<long>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_BodyId = 0x49D9720; // "public PhysicsBodyId get_BodyId()"
        }
    } // namespace BattleCharacterModel

    namespace BattleCharacterPrivateData { // "Models.Data.BattleCharacterPrivateData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t InventoryItems = 0x20; // "InventoryItemsData"
            inline constexpr std::uintptr_t EquipSlotsDelays = 0x28; // "EquipSlotsDelaysData"
            inline constexpr std::uintptr_t EquipIntentionAfterEquipDelay = 0x30; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t Health = 0x38; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t IndexRollback = 0x40; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t DamageData = 0x48; // "DamageData"
            inline constexpr std::uintptr_t SprintTransitionEndTs = 0x50; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t SprintCooldownEndTs = 0x58; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t ReloadIntention = 0x60; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t TargetAiming = 0x68; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t Aiming = 0x70; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t AimStateEndTs = 0x78; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t AimCooldownEndTs = 0x80; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t AimState = 0x88; // "IPrimitiveData<AimStateDescription>"
            inline constexpr std::uintptr_t AimMode = 0x90; // "IPrimitiveData<AimModeDescription>"
            inline constexpr std::uintptr_t HitsMask = 0x98; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t HitsTs = 0xA0; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t NonLethalHitTs = 0xA8; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t Seed = 0xB0; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t WeaponSpread = 0xB8; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t CrouchIntention = 0xC0; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t SelectedQuickSlot = 0xC8; // "IPrimitiveData<QuickSlotDescription>"
            inline constexpr std::uintptr_t CheatSprintEnabled = 0xD0; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t MovementInertiaDisabledByCheat = 0xD8; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t VehicleLeaveTs = 0xE0; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t ContextMenuUseItemActionType = 0xE8; // "IPrimitiveData<ItemActionTypeDescription>"
            inline constexpr std::uintptr_t ItemUseRememberedQuickSlot = 0xF0; // "IPrimitiveData<QuickSlotDescription>"
            inline constexpr std::uintptr_t ItemUseTargetInventorySlot = 0xF8; // "IPrimitiveData<InventorySlotDescription>"
            inline constexpr std::uintptr_t InventoryUseItemTs = 0x100; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t ParamItemActionType = 0x108; // "IPrimitiveData<ItemActionTypeDescription>"
            inline constexpr std::uintptr_t ParamSourceInventorySlot = 0x110; // "IPrimitiveData<InventorySlotDescription>"
            inline constexpr std::uintptr_t ParamSourcePocketSlot = 0x118; // "IPrimitiveData<PocketSlotDescription>"
            inline constexpr std::uintptr_t ParamTargetInventorySlot = 0x120; // "IPrimitiveData<InventorySlotDescription>"
            inline constexpr std::uintptr_t ParamTargetEquipSlot = 0x128; // "IPrimitiveData<EquipSlotDescription>"
            inline constexpr std::uintptr_t CopInfo = 0x130; // "CopInfoData"
            inline constexpr std::uintptr_t HideObjectEntityId = 0x138; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t SurrenderCooldownTs = 0x140; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t TeleportTs = 0x148; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t InteractEntityId = 0x150; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t LastQuickSlot = 0x158; // "IPrimitiveData<QuickSlotDescription>"
            inline constexpr std::uintptr_t IsLastQuickSlotEmptyHands = 0x160; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t FallDamageTrackActive = 0x168; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t FallDamageTrackStartPositionY = 0x170; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t UsableItemCooldown = 0x178; // "ReferenceMapData<UsableItemTypeDescription, IPrimitiveData<long>>"
            inline constexpr std::uintptr_t ThrowableItemCooldown = 0x180; // "ReferenceMapData<ThrowableItemTypeDescription, IPrimitiveData<long>>"
            inline constexpr std::uintptr_t TimeEffects = 0x188; // "ReferenceMapData<TimeEffectTypeDescription, TimeEffectData>"
            inline constexpr std::uintptr_t LastBlindedStateStartTickIndex = 0x190; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t MainMenuExitTs = 0x198; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t MainMenuExitReason = 0x1A0; // "IPrimitiveData<MainMenuExitReasonDescription>"
            inline constexpr std::uintptr_t CharacterControllerData = 0x1A8; // "CharacterControllerData"
            inline constexpr std::uintptr_t CharacterControllerWaterZoneEntityIdByCollision = 0x1B0; // "BattleEntityIdData"
            inline constexpr std::uintptr_t DamageZoneEffect = 0x1B8; // "IPrimitiveData<DamageZoneEffectDescription>"
            inline constexpr std::uintptr_t StaminaDirectionChangeTs = 0x1C0; // "TimestampData"
            inline constexpr std::uintptr_t StaminaDirectionChangeAmount = 0x1C8; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t StaminaDecreaseDirection = 0x1D0; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t DetentionPoints = 0x1D8; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t DetentionPointDecreaseTs = 0x1E0; // "IPrimitiveData<long>"
        }
    } // namespace BattleCharacterPrivateData

    namespace BattleCharacterPrivateModel { // "Models.Models.BattleCharacterPrivate.BattleCharacterPrivateModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ShotInput = 0x10; // "IEventModel"
            inline constexpr std::uintptr_t ShotEvent = 0x18; // "IEventModel"
            inline constexpr std::uintptr_t DamagedEvent = 0x20; // "IEventModel"
            inline constexpr std::uintptr_t WeaponReloadEvent = 0x28; // "IEventModel"
            inline constexpr std::uintptr_t JumpInput = 0x30; // "IEventModel"
            inline constexpr std::uintptr_t SelectNotEmptyQuickSlotEvent = 0x38; // "IEventModel"
            inline constexpr std::uintptr_t LeaveEvent = 0x40; // "IEventModel"
            inline constexpr std::uintptr_t LeaveHideObjectEvent = 0x48; // "IEventModel"
            inline constexpr std::uintptr_t SurrenderCommandEvent = 0x50; // "IEventModel"
            inline constexpr std::uintptr_t FinishArrestEvent = 0x58; // "IEventModel"
            inline constexpr std::uintptr_t BecomeRobberEvent = 0x60; // "IEventModel"
            inline constexpr std::uintptr_t WarpedEvent = 0x68; // "IEventModel"
            inline constexpr std::uintptr_t MeleeAttackEvent = 0x70; // "IEventModel"
            inline constexpr std::uintptr_t ForceKnockoutEndEvent = 0x78; // "IEventModel"
            inline constexpr std::uintptr_t DropCargoEvent = 0x80; // "IEventModel"
            inline constexpr std::uintptr_t SuicideEvent = 0x88; // "IEventModel"
            inline constexpr std::uintptr_t KnockedOutByFallDamage = 0x90; // "IEventModel"
            inline constexpr std::uintptr_t RespawnRequest = 0x98; // "RequestModel<ValueTuple<OutbuildingSlotDescription, FirstAidCabinetSlotDescription, CopPresetDescription, bool>>"
            inline constexpr std::uintptr_t InventoryUseItemRequest = 0xA0; // "RequestModel<InventoryUseItemInputInfo>"
            inline constexpr std::uintptr_t TeleportRequest = 0xA8; // "RequestModel<ValueTuple<Vector3, Vector3>>"
            inline constexpr std::uintptr_t SprintRequest = 0xB0; // "RequestModel<SprintInputDescription>"
            inline constexpr std::uintptr_t CrouchRequest = 0xB8; // "RequestModel<CrouchInputDescription>"
            inline constexpr std::uintptr_t SelectQuickSlotRequest = 0xC0; // "RequestModel<QuickSlotDescription>"
            inline constexpr std::uintptr_t ItemActionRequest = 0xC8; // "RequestModel<ItemActionTypeDescription>"
            inline constexpr std::uintptr_t UseEntityRequest = 0xD0; // "RequestModel<ValueTuple<UseEntityCommandDescription, int>>"
            inline constexpr std::uintptr_t RemoveRequest = 0xD8; // "RequestModel<PlayerRoleDescription>"
            inline constexpr std::uintptr_t TeleportIntoHideObject = 0xE0; // "RequestModel<LocationHideObjectDescription>"
            inline constexpr std::uintptr_t TeleportOutOfHideObject = 0xE8; // "RequestModel<Unit>"
            inline constexpr std::uintptr_t SurrenderRequest = 0xF0; // "RequestModel<SurrenderInputDescription>"
            inline constexpr std::uintptr_t InteractRequest = 0xF8; // "RequestModel<int>"
            inline constexpr std::uintptr_t KnockdownRequest = 0x100; // "RequestModel<Vector3>"
            inline constexpr std::uintptr_t FallDamageTrackRequest = 0x108; // "RequestModel<FallDamageTrackRequestDescription>"
            inline constexpr std::uintptr_t FallDamageRequest = 0x110; // "RequestModel<float>"
            inline constexpr std::uintptr_t ThrowGrenadeRequest = 0x118; // "RequestModel<ValueTuple<GrenadeDescription, Vector3, Vector3>>"
            inline constexpr std::uintptr_t PutCargoInInventoryRequest = 0x120; // "RequestModel<int>"
            inline constexpr std::uintptr_t AimModeRequest = 0x128; // "RequestModel<AimModeDescription>"
            inline constexpr std::uintptr_t LeftShoulderViewRequest = 0x130; // "RequestModel<LeftShoulderViewInputDescription>"
            inline constexpr std::uintptr_t EmotionRequest = 0x138; // "RequestModel<EmotionDescription>"
            inline constexpr std::uintptr_t CargoProductionWorkbenchInputRequest = 0x140; // "RequestModel<ValueTuple<CargoProductionWorkbenchInputDescription, int>>"
            inline constexpr std::uintptr_t ProlongedInteractionRequest = 0x148; // "RequestModel<ValueTuple<ProlongedInteractionInputDescription, MutuallyExclusiveProcessesDescription, int>>"
            inline constexpr std::uintptr_t Inventory = 0x150; // "IInventoryModel"
            inline constexpr std::uintptr_t EquipSlots = 0x158; // "IEquipSlotsModel"
            inline constexpr std::uintptr_t EquipAmmo = 0x160; // "IEquipAmmoModel"
            inline constexpr std::uintptr_t InitArmorModel = 0x168; // "InitArmorModel"
            inline constexpr std::uintptr_t Pockets = 0x170; // "IPocketsModel"
            inline constexpr std::uintptr_t Armor = 0x178; // "ArmorModel"
            inline constexpr std::uintptr_t EquipSlotsDelays = 0x180; // "EquipSlotsDelaysModel"
            inline constexpr std::uintptr_t TakeInHandsIntentionOnEquipDelayEnds = 0x188; // "TakeInHandsIntentionOnEquipDelayEndsModel"
            inline constexpr std::uintptr_t SelectedQuickSlot = 0x190; // "SelectedQuickSlotModel"
            inline constexpr std::uintptr_t Magazine = 0x198; // "WeaponMagazineModel"
            inline constexpr std::uintptr_t ContextMenuUseItemModel = 0x1A0; // "ContextMenuUseItemModel"
            inline constexpr std::uintptr_t QuickSlots = 0x1A8; // "QuickSlotsModel"
            inline constexpr std::uintptr_t Health = 0x1B0; // "HealthModel"
            inline constexpr std::uintptr_t ReloadParamsModel = 0x1B8; // "ReloadParamsModel"
            inline constexpr std::uintptr_t InterruptModel = 0x1C0; // "CharacterInterruptModel"
            inline constexpr std::uintptr_t IndexRollback = 0x1C8; // "IPrimitiveModel<long>"
            inline constexpr std::uintptr_t DamageModel = 0x1D0; // "DamageModel"
            inline constexpr std::uintptr_t SprintModel = 0x1D8; // "SprintModel"
            inline constexpr std::uintptr_t ReloadIntention = 0x1E0; // "IntentionModel"
            inline constexpr std::uintptr_t TargetAiming = 0x1E8; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t Aiming = 0x1F0; // "AimingModel"
            inline constexpr std::uintptr_t AimStateModel = 0x1F8; // "AimStateModel"
            inline constexpr std::uintptr_t AimModeModel = 0x200; // "IPrimitiveModel<AimModeDescription>"
            inline constexpr std::uintptr_t HitsModel = 0x208; // "HitsModel"
            inline constexpr std::uintptr_t NonLethalHitTs = 0x210; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t Random = 0x218; // "RandomModel"
            inline constexpr std::uintptr_t WeaponSpreadArgsModel = 0x220; // "WeaponSpreadArgsModel"
            inline constexpr std::uintptr_t WeaponSpread = 0x228; // "IPrimitiveModel<float>"
            inline constexpr std::uintptr_t CrouchIntention = 0x230; // "IntentionModel"
            inline constexpr std::uintptr_t CheatSprintEnabled = 0x238; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t CheatReduceIncomeDamageToOneEnabled = 0x240; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t MovementInertiaDisabledByCheat = 0x248; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t CheatReduceIncomeDetentionPointsToOneEnabled = 0x250; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t VehicleLeave = 0x258; // "VehicleLeaveModel"
            inline constexpr std::uintptr_t InventoryUseItemModel = 0x260; // "InventoryUseItemModel"
            inline constexpr std::uintptr_t CopInfoModel = 0x268; // "CopInfoModel"
            inline constexpr std::uintptr_t HideObjectStateModel = 0x270; // "CharacterHideObjectStateModel"
            inline constexpr std::uintptr_t SurrenderModel = 0x278; // "SurrenderModel"
            inline constexpr std::uintptr_t TeleportTs = 0x280; // "IPrimitiveModel<long>"
            inline constexpr std::uintptr_t InteractModel = 0x288; // "InteractModel"
            inline constexpr std::uintptr_t LastQuickSlotModel = 0x290; // "LastQuickSlotModel"
            inline constexpr std::uintptr_t FallDamageTrack = 0x298; // "FallDamageTrackModel"
            inline constexpr std::uintptr_t UsableItemCooldownModel = 0x2A0; // "UsableItemCooldownModel"
            inline constexpr std::uintptr_t ThrowableItemCooldownModel = 0x2A8; // "ThrowableItemCooldownModel"
            inline constexpr std::uintptr_t TimeEffectsModel = 0x2B0; // "ITimeEffectsModel"
            inline constexpr std::uintptr_t BlindedState = 0x2B8; // "BlindedStateModel"
            inline constexpr std::uintptr_t MainMenuExitModel = 0x2C0; // "CharacterMainMenuExitModel"
            inline constexpr std::uintptr_t MoveSpeedModel = 0x2C8; // "MoveSpeedModel"
            inline constexpr std::uintptr_t CameraModel = 0x2D0; // "BattleCharacterCameraModel"
            inline constexpr std::uintptr_t CharacterController = 0x2D8; // "CharacterControllerModel"
            inline constexpr std::uintptr_t PlayerLeaveBattleReasonModel = 0x2E0; // "IPrimitiveModel<PlayerLeaveBattleReasonDescription>"
            inline constexpr std::uintptr_t Stamina = 0x2E8; // "BattleCharacterStaminaModel"
            inline constexpr std::uintptr_t StaminaDamage = 0x2F0; // "BattleCharacterStaminaDamageModel"
            inline constexpr std::uintptr_t VelocityDamage = 0x2F8; // "VelocityDamageModel"
            inline constexpr std::uintptr_t DetentionPoints = 0x300; // "DetentionPointsModel"
            inline constexpr std::uintptr_t DamageZone = 0x308; // "BattleCharacterDamageZoneModel"
        }
    } // namespace BattleCharacterPrivateModel

    namespace BattleCharacterPublicData { // "Models.Data.BattleCharacterPublicData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ShotPosition = 0x20; // "IPrimitiveData<Vector3>"
            inline constexpr std::uintptr_t ShotDirection = 0x28; // "IPrimitiveData<Vector3>"
            inline constexpr std::uintptr_t ShotWeapon = 0x30; // "IPrimitiveData<WeaponDescription>"
            inline constexpr std::uintptr_t HasArmor = 0x38; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t VehicleType = 0x40; // "IPrimitiveData<VehicleTypeDescription>"
            inline constexpr std::uintptr_t MeleeAttackSurfaceHit = 0x48; // "IPrimitiveData<byte>"
        }
    } // namespace BattleCharacterPublicData

    namespace BattleCharacterRigidBodyEnabledModel { // "Models.Models.RigidBodyEnabledModel.BattleCharacterRigidBodyEnabledModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t stateModel = 0x10; // "IBattleCharacterStateModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Value = 0x48D0A90; // "public bool get_Value()"
        }
    } // namespace BattleCharacterRigidBodyEnabledModel

    namespace BattleCharacterRobberStateExtensions { // "Models.Utils.Extensions.BattleCharacterRobberStateExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t IsBattleCharacterAvailableForBecomeRobber = 0x3931CF0; // "public static bool IsBattleCharacterAvailableForBecomeRobber(BattleCharacterModel battleCharacter)"
            inline constexpr std::uintptr_t IsPartyAvailableForBecomeRobber = 0x3931E20; // "public static bool IsPartyAvailableForBecomeRobber(PartyModel partyModel, WorldEntitiesModel worldEntitiesModel)"
        }
    } // namespace BattleCharacterRobberStateExtensions

    namespace BattleCharacterSkeletonDeformationConfig { // "Models.References.Character.BattleCharacterSkeletonDeformationConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t LookBottomThreshold = 0x10; // "float"
            inline constexpr std::uintptr_t LookTopThreshold = 0x14; // "float"
            inline constexpr std::uintptr_t BattleStanceWalkRotationMods = 0x18; // "Vector3"
            inline constexpr std::uintptr_t BattleStanceCrouchRotationMods = 0x24; // "Vector3"
            inline constexpr std::uintptr_t ArmedWalkRotationMods = 0x30; // "Vector3"
            inline constexpr std::uintptr_t ArmedCrouchRotationMods = 0x3C; // "Vector3"
            inline constexpr std::uintptr_t BoxingWalkRotationMods = 0x48; // "Vector3"
            inline constexpr std::uintptr_t ThrowingWalkRotationMods = 0x54; // "Vector3"
            inline constexpr std::uintptr_t ThrowingCrouchRotationMods = 0x60; // "Vector3"
            inline constexpr std::uintptr_t ArmedWeaponDeformationChangeSpeed = 0x6C; // "float"
            inline constexpr std::uintptr_t HeadNeckDeformationChangeSpeed = 0x70; // "float"
            inline constexpr std::uintptr_t YawDeformationChangeSpeed = 0x74; // "float"
            inline constexpr std::uintptr_t RollPitchDeformationChangeSpeed = 0x78; // "float"
            inline constexpr std::uintptr_t NeckWeight = 0x7C; // "float"
            inline constexpr std::uintptr_t HeadWeight = 0x80; // "float"
            inline constexpr std::uintptr_t HeadMovingWeight = 0x84; // "float"
            inline constexpr std::uintptr_t NeckForward = 0x88; // "Vector3"
            inline constexpr std::uintptr_t HeadForward = 0x94; // "Vector3"
            inline constexpr std::uintptr_t HeadRotationMinAngle = 0xA0; // "float"
            inline constexpr std::uintptr_t ArmedAndBattleStanceDuration = 0xA8; // "long"
            inline constexpr std::uintptr_t TurnAngle = 0xB0; // "float"
            inline constexpr std::uintptr_t TurnThreshold = 0xB4; // "float"
            inline constexpr std::uintptr_t TurnDuration = 0xB8; // "long"
            inline constexpr std::uintptr_t BoxingYawOffset = 0xC0; // "float"
            inline constexpr std::uintptr_t TimeFallingToTreatAnimatorStateAsFalling = 0xC8; // "long"
            inline constexpr std::uintptr_t TimeFallingToTreatAnimatorStateAsFallingFromHeight = 0xD0; // "long"
        }
    } // namespace BattleCharacterSkeletonDeformationConfig

    namespace BattleCharacterSlotData { // "Models.Data.BattleCharacterSlotData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t EntityId = 0x20; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t PublicId = 0x28; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t Nickname = 0x30; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t ClanTag = 0x38; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t EOSProductUserId = 0x40; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t HasChatAccess = 0x48; // "IPrimitiveData<bool>"
        }
    } // namespace BattleCharacterSlotData

    namespace BattleCharacterSlotDescription { // "Models.References.BattleCharacterSlotDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x8241348; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t enum_id = 0x0; // "Enum<BattleCharacterSlotDescription>"
            inline constexpr std::uintptr_t Slot0 = 0x8; // "BattleCharacterSlotDescription"
            inline constexpr std::uintptr_t Slot1 = 0x10; // "BattleCharacterSlotDescription"
            inline constexpr std::uintptr_t Slot2 = 0x18; // "BattleCharacterSlotDescription"
            inline constexpr std::uintptr_t Slot3 = 0x20; // "BattleCharacterSlotDescription"
            inline constexpr std::uintptr_t Slot4 = 0x28; // "BattleCharacterSlotDescription"
            inline constexpr std::uintptr_t Slot5 = 0x30; // "BattleCharacterSlotDescription"
            inline constexpr std::uintptr_t Slot6 = 0x38; // "BattleCharacterSlotDescription"
            inline constexpr std::uintptr_t Slot7 = 0x40; // "BattleCharacterSlotDescription"
            inline constexpr std::uintptr_t Slot8 = 0x48; // "BattleCharacterSlotDescription"
            inline constexpr std::uintptr_t Slot9 = 0x50; // "BattleCharacterSlotDescription"
            inline constexpr std::uintptr_t Slot10 = 0x58; // "BattleCharacterSlotDescription"
            inline constexpr std::uintptr_t Slot11 = 0x60; // "BattleCharacterSlotDescription"
            inline constexpr std::uintptr_t Slot12 = 0x68; // "BattleCharacterSlotDescription"
            inline constexpr std::uintptr_t Slot13 = 0x70; // "BattleCharacterSlotDescription"
            inline constexpr std::uintptr_t Slot14 = 0x78; // "BattleCharacterSlotDescription"
            inline constexpr std::uintptr_t Slot15 = 0x80; // "BattleCharacterSlotDescription"
            inline constexpr std::uintptr_t Slot16 = 0x88; // "BattleCharacterSlotDescription"
            inline constexpr std::uintptr_t Slot17 = 0x90; // "BattleCharacterSlotDescription"
            inline constexpr std::uintptr_t Slot18 = 0x98; // "BattleCharacterSlotDescription"
            inline constexpr std::uintptr_t Slot19 = 0xA0; // "BattleCharacterSlotDescription"
            inline constexpr std::uintptr_t Slot20 = 0xA8; // "BattleCharacterSlotDescription"
            inline constexpr std::uintptr_t Slot21 = 0xB0; // "BattleCharacterSlotDescription"
            inline constexpr std::uintptr_t Slot22 = 0xB8; // "BattleCharacterSlotDescription"
            inline constexpr std::uintptr_t Slot23 = 0xC0; // "BattleCharacterSlotDescription"
            inline constexpr std::uintptr_t Slot24 = 0xC8; // "BattleCharacterSlotDescription"
            inline constexpr std::uintptr_t Slot25 = 0xD0; // "BattleCharacterSlotDescription"
            inline constexpr std::uintptr_t Slot26 = 0xD8; // "BattleCharacterSlotDescription"
            inline constexpr std::uintptr_t Slot27 = 0xE0; // "BattleCharacterSlotDescription"
            inline constexpr std::uintptr_t Slot28 = 0xE8; // "BattleCharacterSlotDescription"
            inline constexpr std::uintptr_t Slot29 = 0xF0; // "BattleCharacterSlotDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Enum = 0x4022980; // "public static ReadOnlyEnum<BattleCharacterSlotDescription> get_Enum()"
        }
    } // namespace BattleCharacterSlotDescription

    namespace BattleCharacterSlotModel { // "Models.Models.BattleCharacterSlots.BattleCharacterSlotModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "BattleCharacterSlotData"
            inline constexpr std::uintptr_t Description = 0x18; // "BattleCharacterSlotDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsEmpty = 0x49DBD90; // "public bool get_IsEmpty()"
            inline constexpr std::uintptr_t get_EntityId = 0x49DBCF0; // "public int get_EntityId()"
            inline constexpr std::uintptr_t get_PublicId = 0x49DBE40; // "public long get_PublicId()"
            inline constexpr std::uintptr_t get_Nickname = 0x49DBDF0; // "public string get_Nickname()"
            inline constexpr std::uintptr_t get_ClanTag = 0x49DBC50; // "public string get_ClanTag()"
            inline constexpr std::uintptr_t get_EOSProductUserId = 0x49DBCA0; // "public string get_EOSProductUserId()"
            inline constexpr std::uintptr_t set_EOSProductUserId = 0x49DBE90; // "public void set_EOSProductUserId(string value)"
            inline constexpr std::uintptr_t get_HasChatAccess = 0x49DBD40; // "public bool get_HasChatAccess()"
            inline constexpr std::uintptr_t Set = 0x49DBA50; // "public void Set(int entityId, long publicId)"
            inline constexpr std::uintptr_t SetNickname = 0x49DB9E0; // "public void SetNickname(string nickname)"
            inline constexpr std::uintptr_t SetClanTag = 0x49DB900; // "public void SetClanTag(string tag)"
            inline constexpr std::uintptr_t SetHasChatAccess = 0x49DB970; // "public void SetHasChatAccess(bool hasChatAccess)"
            inline constexpr std::uintptr_t Unset = 0x49DBAF0; // "public void Unset()"
        }
    } // namespace BattleCharacterSlotModel

    namespace BattleCharacterSlotsModel { // "Models.Models.BattleCharacterSlots.BattleCharacterSlotsModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t slots = 0x10; // "Dictionary<BattleCharacterSlotDescription, BattleCharacterSlotModel>"
            inline constexpr std::uintptr_t Slots = 0x18; // "ReadOnly.Dictionary<BattleCharacterSlotDescription, BattleCharacterSlotModel>"
        }
    } // namespace BattleCharacterSlotsModel

    namespace BattleCharacterStateModel { // "Models.Models.BattleCharacterStateModel.BattleCharacterStateModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t isDeadModel = 0x10; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t inVehicleModel = 0x18; // "InVehicleModel"
            inline constexpr std::uintptr_t characterHiddenStateModel = 0x20; // "ICharacterHiddenStateModel"
            inline constexpr std::uintptr_t arrestTargetModel = 0x28; // "ArrestTargetModel"
            inline constexpr std::uintptr_t knockoutModel = 0x30; // "KnockoutModel"
            inline constexpr std::uintptr_t characterControllerState = 0x38; // "IPrimitiveModel<CharacterControllerStateDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Value = 0x49DC330; // "public BattleCharacterState get_Value()"
        }
    } // namespace BattleCharacterStateModel

    namespace BattleCharacterTargetActions { // "Game.Battle.EntityModel.BattleCharacter.BattleCharacterTargetActions (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t unavailableKeys = 0x10; // "UnavailableTargetActionsKeys"
            inline constexpr std::uintptr_t personalNotificationModel = 0x18; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t battleInputModel = 0x20; // "BattleInputModel"
            inline constexpr std::uintptr_t battleCharacterModel = 0x28; // "BattleCharacterModel"
            inline constexpr std::uintptr_t uiSoundModel = 0x30; // "GlobalUISoundModel"
            inline constexpr std::uintptr_t playerContextMenuModel = 0x38; // "PlayerContextMenuModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x40; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t becomeRobberNotificationModel = 0x48; // "BecomeRobberNotificationModel"
            inline constexpr std::uintptr_t notificationKeys = 0x50; // "NotificationKeys"
            inline constexpr std::uintptr_t roomConnectionBattle = 0x58; // "IRoomConnection"
            inline constexpr std::uintptr_t isSendingAcceptBribe = 0x60; // "bool"
            inline constexpr std::uintptr_t Arrest = 0x68; // "TargetAction"
            inline constexpr std::uintptr_t InterruptArrested = 0x70; // "TargetAction"
            inline constexpr std::uintptr_t ContextInteraction = 0x78; // "TargetAction"
            inline constexpr std::uintptr_t Revive = 0x80; // "TargetAction"
            inline constexpr std::uintptr_t InterruptArrestedUnavailableRole = 0x88; // "ITargetAction"
            inline constexpr std::uintptr_t AcceptBribe = 0x90; // "TargetAction"
            inline constexpr std::uintptr_t ForceArrest = 0x98; // "TargetAction"
        }
        namespace Methods {
            inline constexpr std::uintptr_t ArrestAction = 0xCB4FD0; // "private void ArrestAction()"
            inline constexpr std::uintptr_t ReviveAction = 0xCB54C0; // "private void ReviveAction()"
            inline constexpr std::uintptr_t InterruptArrestedAction = 0xCB53C0; // "private void InterruptArrestedAction()"
            inline constexpr std::uintptr_t ForceArrestAction = 0xCB52C0; // "private void ForceArrestAction()"
            inline constexpr std::uintptr_t AcceptBribeAction = 0xCB4F20; // "private void AcceptBribeAction()"
            inline constexpr std::uintptr_t SendAcceptBribeMessage = 0xCB5640; // "private void SendAcceptBribeMessage()"
            inline constexpr std::uintptr_t ContextInteractionAction = 0xCB50D0; // "private void ContextInteractionAction()"
            inline constexpr std::uintptr_t UnavailableArrest = 0xCB56F0; // "private void UnavailableArrest(LocalizedString invalidNotification, PersonalNotificationActionIds id)"
            inline constexpr std::uintptr_t UnavailableInterruptArrest = 0xCB5770; // "private void UnavailableInterruptArrest()"
            inline constexpr std::uintptr_t Unavailable = 0xCB56F0; // "private void Unavailable(LocalizedString invalidNotification, PersonalNotificationActionIds id)"
        }
    } // namespace BattleCharacterTargetActions

    namespace BattleCharacterTargetProvider { // "Game.Battle.EntityModel.BattleCharacter.BattleCharacterTargetProvider (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t serverModel = 0x20; // "BattleCharacterModel"
            inline constexpr std::uintptr_t actions = 0x28; // "BattleCharacterTargetActions"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x30; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t crouchStandUpModel = 0x38; // "CrouchStandUpModel"
            inline constexpr std::uintptr_t unavailableKeys = 0x40; // "UnavailableTargetActionsKeys"
            inline constexpr std::uintptr_t battleMode = 0x48; // "BattleModeDescription"
            inline constexpr std::uintptr_t clanBattleTeamsCacheModel = 0x50; // "ClanBattleTeamsCacheModel"
            inline constexpr std::uintptr_t battleCharacterSlotModel = 0x58; // "BattleCharacterSlotModel"
            inline constexpr std::uintptr_t cachedAction = 0x60; // "ValueTuple<ITargetAction, UnityRaycastTargetOptions>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t FillTargetActions = 0xCB6020; // "protected internal override void FillTargetActions(List<ITargetAction> actions)"
        }
    } // namespace BattleCharacterTargetProvider

    namespace BattleCharacterTransformExtensions { // "Models.Utils.Extensions.BattleCharacterTransformExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t CalculateFaceDirection = 0x3932980; // "public static Vector2 CalculateFaceDirection(ITransformModel transform)"
        }
    } // namespace BattleCharacterTransformExtensions

    namespace BattleCharacterVisibleModel { // "Game.Battle.EntityModel.BattleCharacter.BattleCharacterVisibleModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t HideCharacterCameraDistanceCounter = 0x10; // "int"
            inline constexpr std::uintptr_t HideCharacterArrestedCounter = 0x14; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsVisible = 0xCB6EC0; // "public bool get_IsVisible()"
            inline constexpr std::uintptr_t get_IsFullHide = 0xCB6EB0; // "public bool get_IsFullHide()"
        }
    } // namespace BattleCharacterVisibleModel

    namespace BattleChatInputAvailableUpdater { // "Game.Battle.Player.BattleChatInputAvailableUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t chatChannel = 0x10; // "ChatChannelModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x18; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t battleRoom = 0x20; // "IRoomConnection"
            inline constexpr std::uintptr_t now = 0x28; // "INow"
            inline constexpr std::uintptr_t accessRules = 0x30; // "ChatAccessRules"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x95ED60; // "public void Update()"
        }
    } // namespace BattleChatInputAvailableUpdater

    namespace BattleInputCache { // "ClientCore.Prediction.BattleInputCache.BattleInputCache (Client.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t previousInput = 0x10; // "BattleInputData"
            inline constexpr std::uintptr_t currentInput = 0x108; // "BattleInputData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetNewInput = 0xE7F990; // "public void SetNewInput(in BattleInputData inputData)"
            inline constexpr std::uintptr_t get_PreviousInput = 0xE7FC30; // "public BattleInputData get_PreviousInput()"
            inline constexpr std::uintptr_t get_CurrentInput = 0xE7FB90; // "public BattleInputData get_CurrentInput()"
            inline constexpr std::uintptr_t ClientCore_Prediction_BattleInputCache_IBattleInputCache_SetNewInput = 0xE7F990; // "private void ClientCore.Prediction.BattleInputCache.IBattleInputCache.SetNewInput(in BattleInputData inputData)"
        }
    } // namespace BattleInputCache

    namespace BattleInputData { // "Models.Prediction.BattleInputData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Ts = 0x0; // "long"
            inline constexpr std::uintptr_t IsMoveInput = 0x8; // "bool"
            inline constexpr std::uintptr_t X = 0xC; // "float"
            inline constexpr std::uintptr_t Y = 0x10; // "float"
            inline constexpr std::uintptr_t IsLookDirectionInput = 0x14; // "bool"
            inline constexpr std::uintptr_t Lx = 0x18; // "float"
            inline constexpr std::uintptr_t Ly = 0x1C; // "float"
            inline constexpr std::uintptr_t IsTiltInput = 0x20; // "bool"
            inline constexpr std::uintptr_t TiltX = 0x24; // "float"
            inline constexpr std::uintptr_t TiltY = 0x28; // "float"
            inline constexpr std::uintptr_t IsShotInput = 0x2C; // "bool"
            inline constexpr std::uintptr_t IsFirstShotInQueue = 0x2D; // "bool"
            inline constexpr std::uintptr_t ShotPlayerTimeOffset = 0x30; // "int"
            inline constexpr std::uintptr_t ShotSimulatedTimeOffset = 0x34; // "int"
            inline constexpr std::uintptr_t ShotLookOffset = 0x38; // "int"
            inline constexpr std::uintptr_t IsRollbackValueInput = 0x3C; // "bool"
            inline constexpr std::uintptr_t RollbackValue = 0x40; // "long"
            inline constexpr std::uintptr_t SprintInput = 0x48; // "SprintInputDescription"
            inline constexpr std::uintptr_t IsWeaponReloadInput = 0x50; // "bool"
            inline constexpr std::uintptr_t IsTargetAimingInput = 0x51; // "bool"
            inline constexpr std::uintptr_t TargetAiming = 0x52; // "bool"
            inline constexpr std::uintptr_t CrouchInput = 0x58; // "CrouchInputDescription"
            inline constexpr std::uintptr_t IsJump = 0x60; // "bool"
            inline constexpr std::uintptr_t IsCarHornInput = 0x61; // "bool"
            inline constexpr std::uintptr_t IsCarBurnoutInput = 0x62; // "bool"
            inline constexpr std::uintptr_t QuickSlot = 0x68; // "QuickSlotDescription"
            inline constexpr std::uintptr_t ItemActionInput = 0x70; // "ItemActionTypeDescription"
            inline constexpr std::uintptr_t UseItemQuickSlotTarget = 0x78; // "QuickSlotDescription"
            inline constexpr std::uintptr_t UseItemInventorySlotTarget = 0x80; // "InventorySlotDescription"
            inline constexpr std::uintptr_t UseEntityCommandInput = 0x88; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t UseEntityId = 0x90; // "int"
            inline constexpr std::uintptr_t InventoryItemInput = 0x98; // "InventoryItemInputDescription"
            inline constexpr std::uintptr_t InventoryUseItemActionType = 0xA0; // "ItemActionTypeDescription"
            inline constexpr std::uintptr_t InventoryUseItemSourceInventorySlot = 0xA8; // "InventorySlotDescription"
            inline constexpr std::uintptr_t InventoryUseItemSourcePocketSlot = 0xB0; // "PocketSlotDescription"
            inline constexpr std::uintptr_t InventoryUseItemTargetInventorySlot = 0xB8; // "InventorySlotDescription"
            inline constexpr std::uintptr_t InventoryUseItemTargetEquipSlot = 0xC0; // "EquipSlotDescription"
            inline constexpr std::uintptr_t IsStopWeaponReload = 0xC8; // "bool"
            inline constexpr std::uintptr_t SurrenderInput = 0xD0; // "SurrenderInputDescription"
            inline constexpr std::uintptr_t IsSurrenderCommandInput = 0xD8; // "bool"
            inline constexpr std::uintptr_t IsInteractInput = 0xD9; // "bool"
            inline constexpr std::uintptr_t IsMeleeAttackInput = 0xDA; // "bool"
            inline constexpr std::uintptr_t IsDropCargoInput = 0xDB; // "bool"
            inline constexpr std::uintptr_t EmotionSlotInput = 0xE0; // "EmotionSlotDescription"
            inline constexpr std::uintptr_t AimModeInput = 0xE8; // "AimModeDescription"
            inline constexpr std::uintptr_t LeftShoulderViewInput = 0xF0; // "LeftShoulderViewInputDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t HasInput = 0x455D3C0; // "public bool HasInput()"
        }
    } // namespace BattleInputData

    namespace BattleInputDataModel { // "ClientCore.Prediction.BattleInputDataModel.BattleInputDataModel (Client.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t HasNewInputData = 0x10; // "bool"
            inline constexpr std::uintptr_t InputData = 0x18; // "BattleInputData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetNew = 0xE7FCD0; // "public void SetNew(in BattleInputData inputData)"
            inline constexpr std::uintptr_t Clear = 0x844D10; // "public void Clear()"
            inline constexpr std::uintptr_t ClientCore_Prediction_BattleInputDataModel_IBattleInputDataModel_SetNew = 0xE7FCD0; // "private void ClientCore.Prediction.BattleInputDataModel.IBattleInputDataModel.SetNew(in BattleInputData inputData)"
        }
    } // namespace BattleInputDataModel

    namespace BattleInputMessage { // "Models.Messages.BattleInputMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t worldStateIndex = 0x20; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t previousInput = 0x28; // "BattleInputMessageData"
            inline constexpr std::uintptr_t currentInput = 0x30; // "BattleInputMessageData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x49DF710; // "public override string get_Type()"
            inline constexpr std::uintptr_t Set = 0x49DF380; // "public void Set(long worldStateIndex, in BattleInputData previousInput, in BattleInputData currentInput)"
            inline constexpr std::uintptr_t get_WorldStateIndex = 0x49DF740; // "public long get_WorldStateIndex()"
            inline constexpr std::uintptr_t get_PreviousInput = 0x49DF650; // "public BattleInputData get_PreviousInput()"
            inline constexpr std::uintptr_t get_CurrentInput = 0x49DF590; // "public BattleInputData get_CurrentInput()"
        }
    } // namespace BattleInputMessage

    namespace BattleInputMessageData { // "Models.Data.BattleInputMessageData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ts = 0x20; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t isMoveInput = 0x28; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t x = 0x30; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t y = 0x38; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t isLookDirectionInput = 0x40; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t lx = 0x48; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t ly = 0x50; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t isTiltInput = 0x58; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t tiltX = 0x60; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t tiltY = 0x68; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t isShot = 0x70; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t isFirstShotInQueue = 0x78; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t shotLookOffset = 0x80; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t shotPlayerTimeOffset = 0x88; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t shotSimulatedTimeOffset = 0x90; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t isRollbackValue = 0x98; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t rollbackValue = 0xA0; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t sprintInput = 0xA8; // "IPrimitiveData<SprintInputDescription>"
            inline constexpr std::uintptr_t isWeaponReload = 0xB0; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t isTargetAimingInput = 0xB8; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t targetAiming = 0xC0; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t crouchInput = 0xC8; // "IPrimitiveData<CrouchInputDescription>"
            inline constexpr std::uintptr_t isJump = 0xD0; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t quickSlot = 0xD8; // "IPrimitiveData<QuickSlotDescription>"
            inline constexpr std::uintptr_t itemActionInput = 0xE0; // "IPrimitiveData<ItemActionTypeDescription>"
            inline constexpr std::uintptr_t useItemQuickSlotTarget = 0xE8; // "IPrimitiveData<QuickSlotDescription>"
            inline constexpr std::uintptr_t useItemInventorySlotTarget = 0xF0; // "IPrimitiveData<InventorySlotDescription>"
            inline constexpr std::uintptr_t useEntityCommandInput = 0xF8; // "IPrimitiveData<UseEntityCommandDescription>"
            inline constexpr std::uintptr_t useEntityId = 0x100; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t inventoryItemInput = 0x108; // "IPrimitiveData<InventoryItemInputDescription>"
            inline constexpr std::uintptr_t inventoryUseItemActionType = 0x110; // "IPrimitiveData<ItemActionTypeDescription>"
            inline constexpr std::uintptr_t inventoryUseItemSourceInventorySlot = 0x118; // "IPrimitiveData<InventorySlotDescription>"
            inline constexpr std::uintptr_t inventoryUseItemSourcePocketSlot = 0x120; // "IPrimitiveData<PocketSlotDescription>"
            inline constexpr std::uintptr_t inventoryUseItemTargetInventorySlot = 0x128; // "IPrimitiveData<InventorySlotDescription>"
            inline constexpr std::uintptr_t inventoryUseItemTargetEquipSlot = 0x130; // "IPrimitiveData<EquipSlotDescription>"
            inline constexpr std::uintptr_t isStopWeaponReload = 0x138; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t surrenderInput = 0x140; // "IPrimitiveData<SurrenderInputDescription>"
            inline constexpr std::uintptr_t isSurrenderCommandInput = 0x148; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t isMeleeAttackInput = 0x150; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t isInteractInput = 0x158; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t isDropCargoInput = 0x160; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t emotionSlotInput = 0x168; // "IPrimitiveData<EmotionSlotDescription>"
            inline constexpr std::uintptr_t aimModeInput = 0x170; // "IPrimitiveData<AimModeDescription>"
            inline constexpr std::uintptr_t isCarHornInput = 0x178; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t isCarBurnoutInput = 0x180; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t leftShoulderViewInput = 0x188; // "IPrimitiveData<LeftShoulderViewInputDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Set = 0x4A6B590; // "public void Set(in BattleInputData inputData)"
            inline constexpr std::uintptr_t Get = 0x4A6A6B0; // "public BattleInputData Get()"
        }
    } // namespace BattleInputMessageData

    namespace BattleInputModel { // "Models.Prediction.BattleInput.BattleInputModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t moveDirection = 0x10; // "Vector2"
            inline constexpr std::uintptr_t lookDirection = 0x18; // "Vector2"
            inline constexpr std::uintptr_t tiltDirection = 0x20; // "Vector2"
            inline constexpr std::uintptr_t rollbackValue = 0x28; // "long"
            inline constexpr std::uintptr_t targetAiming = 0x30; // "bool"
            inline constexpr std::uintptr_t IsForceSendInput = 0x31; // "bool"
            inline constexpr std::uintptr_t IsLookDirectionChanged = 0x32; // "bool"
            inline constexpr std::uintptr_t IsRollbackValueChanged = 0x33; // "bool"
            inline constexpr std::uintptr_t IsShot = 0x34; // "bool"
            inline constexpr std::uintptr_t IsFirstShotInQueue = 0x35; // "bool"
            inline constexpr std::uintptr_t ShotLookOffset = 0x38; // "int"
            inline constexpr std::uintptr_t ShotPlayerTimeOffset = 0x3C; // "int"
            inline constexpr std::uintptr_t ShotSimulatedTimeOffset = 0x40; // "int"
            inline constexpr std::uintptr_t SprintInput = 0x48; // "SprintInputDescription"
            inline constexpr std::uintptr_t IsWeaponReload = 0x50; // "bool"
            inline constexpr std::uintptr_t TargetAimingChanged = 0x51; // "bool"
            inline constexpr std::uintptr_t CrouchInput = 0x58; // "CrouchInputDescription"
            inline constexpr std::uintptr_t IsJump = 0x60; // "bool"
            inline constexpr std::uintptr_t QuickSlot = 0x68; // "QuickSlotDescription"
            inline constexpr std::uintptr_t ItemActionInput = 0x70; // "ItemActionTypeDescription"
            inline constexpr std::uintptr_t UseItemQuickSlotTarget = 0x78; // "QuickSlotDescription"
            inline constexpr std::uintptr_t UseItemInventorySlotTarget = 0x80; // "InventorySlotDescription"
            inline constexpr std::uintptr_t UseEntityCommandInput = 0x88; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t UseEntityId = 0x90; // "int"
            inline constexpr std::uintptr_t InventoryItemInput = 0x98; // "InventoryItemInputDescription"
            inline constexpr std::uintptr_t InventoryUseItemActionType = 0xA0; // "ItemActionTypeDescription"
            inline constexpr std::uintptr_t InventoryUseItemSourceInventorySlot = 0xA8; // "InventorySlotDescription"
            inline constexpr std::uintptr_t InventoryUseItemSourcePocketSlot = 0xB0; // "PocketSlotDescription"
            inline constexpr std::uintptr_t InventoryUseItemTargetInventorySlot = 0xB8; // "InventorySlotDescription"
            inline constexpr std::uintptr_t InventoryUseItemTargetEquipSlot = 0xC0; // "EquipSlotDescription"
            inline constexpr std::uintptr_t IsStopWeaponReload = 0xC8; // "bool"
            inline constexpr std::uintptr_t SurrenderInput = 0xD0; // "SurrenderInputDescription"
            inline constexpr std::uintptr_t IsSurrenderCommandInput = 0xD8; // "bool"
            inline constexpr std::uintptr_t IsInteractInput = 0xD9; // "bool"
            inline constexpr std::uintptr_t IsCarHornInput = 0xDA; // "bool"
            inline constexpr std::uintptr_t IsCarBurnoutInput = 0xDB; // "bool"
            inline constexpr std::uintptr_t IsMeleeAttackInput = 0xDC; // "bool"
            inline constexpr std::uintptr_t IsDropCargoInput = 0xDD; // "bool"
            inline constexpr std::uintptr_t EmotionSlotInput = 0xE0; // "EmotionSlotDescription"
            inline constexpr std::uintptr_t AimModeInput = 0xE8; // "AimModeDescription"
            inline constexpr std::uintptr_t LeftShoulderViewInput = 0xF0; // "LeftShoulderViewInputDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_HasNewInput = 0x455DDE0; // "public bool get_HasNewInput()"
            inline constexpr std::uintptr_t get_IsMoveDirectionChanged = 0x455DE40; // "public bool get_IsMoveDirectionChanged()"
            inline constexpr std::uintptr_t get_IsTiltDirectionChanged = 0x455DE90; // "public bool get_IsTiltDirectionChanged()"
            inline constexpr std::uintptr_t get_MoveDirection = 0x9B7170; // "public Vector2 get_MoveDirection()"
            inline constexpr std::uintptr_t set_MoveDirection = 0x8BFD60; // "public void set_MoveDirection(Vector2 value)"
            inline constexpr std::uintptr_t get_LookDirection = 0x9BF400; // "public Vector2 get_LookDirection()"
            inline constexpr std::uintptr_t set_LookDirection = 0x455DF50; // "public void set_LookDirection(Vector2 value)"
            inline constexpr std::uintptr_t get_TiltDirection = 0x9BCAC0; // "public Vector2 get_TiltDirection()"
            inline constexpr std::uintptr_t set_TiltDirection = 0x9BCAE0; // "public void set_TiltDirection(Vector2 value)"
            inline constexpr std::uintptr_t get_RollbackValue = 0x7AA000; // "public long get_RollbackValue()"
            inline constexpr std::uintptr_t set_RollbackValue = 0x455E050; // "public void set_RollbackValue(long value)"
            inline constexpr std::uintptr_t get_TargetAiming = 0x9AFED0; // "public bool get_TargetAiming()"
            inline constexpr std::uintptr_t set_TargetAiming = 0x455E060; // "public void set_TargetAiming(bool value)"
            inline constexpr std::uintptr_t Reset = 0x455D7F0; // "public void Reset()"
            inline constexpr std::uintptr_t TryGetInputData = 0x455D9B0; // "public bool TryGetInputData(long ts, out BattleInputData inputData)"
        }
    } // namespace BattleInputModel

    namespace BattleInputRules { // "Models.Prediction.BattleInputRules (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t CreateInputDataForRepeat = 0x455E070; // "public static BattleInputData CreateInputDataForRepeat(BattleInputData inputData, long ts)"
        }
    } // namespace BattleInputRules

    namespace BattleInputUpdater { // "ClientCore.Prediction.BattleInputUpdater.BattleInputUpdater (Client.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleInputModel = 0x10; // "BattleInputModel"
            inline constexpr std::uintptr_t battleInputDataModel = 0x18; // "IBattleInputDataModel"
            inline constexpr std::uintptr_t time = 0x20; // "TimeModel"
            inline constexpr std::uintptr_t hasDelayedInput = 0x28; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xE7FF60; // "public void Update()"
        }
    } // namespace BattleInputUpdater

    namespace BattleObserverInputHandler { // "Game.Battle.Observer.BattleObserverInputHandler (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Handlers = 0x10; // "ValueTuple<InputMask, IUpdater>[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Priority = 0x7E3AB0; // "public InputHandlerPriority get_Priority()"
        }
    } // namespace BattleObserverInputHandler

    namespace BattleObserverLookInputUpdater { // "Game.Battle.Observer.BattleObserverLookInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t observerModel = 0x10; // "ObserverInputModel"
            inline constexpr std::uintptr_t lookAction = 0x18; // "InputAction"
            inline constexpr std::uintptr_t orientation = 0x20; // "Vector3"
            inline constexpr std::uintptr_t orientationLerp = 0x2C; // "Vector3"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x97A400; // "public void Update()"
        }
    } // namespace BattleObserverLookInputUpdater

    namespace BattleObserverMainActionsInputUpdater { // "Game.Battle.Observer.BattleObserverMainActionsInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t inputActions = 0x10; // "InputActions.ObserverActions"
            inline constexpr std::uintptr_t observerModel = 0x18; // "ObserverInputModel"
            inline constexpr std::uintptr_t cursorLockModel = 0x20; // "CursorLockModel"
            inline constexpr std::uintptr_t hasLock = 0x28; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x97A660; // "public void Update()"
        }
    } // namespace BattleObserverMainActionsInputUpdater

    namespace BattleObserverMoveInputUpdater { // "Game.Battle.Observer.BattleObserverMoveInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t moveAction = 0x10; // "InputAction"
            inline constexpr std::uintptr_t downAction = 0x18; // "InputAction"
            inline constexpr std::uintptr_t upAction = 0x20; // "InputAction"
            inline constexpr std::uintptr_t moveAcceleration = 0x28; // "InputAction"
            inline constexpr std::uintptr_t observerModel = 0x30; // "ObserverInputModel"
            inline constexpr std::uintptr_t worldPosition = 0x38; // "Vector3"
            inline constexpr std::uintptr_t worldPositionLerp = 0x44; // "Vector3"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x97ABD0; // "public void Update()"
        }
    } // namespace BattleObserverMoveInputUpdater

    namespace BattlePassInputUpdater { // "Game.Global.BattlePass.BattlePassInputUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t globalModel = 0x10; // "GlobalModel"
            inline constexpr std::uintptr_t dialogModel = 0x18; // "SkinCenterDialogModel"
            inline constexpr std::uintptr_t skinCenterBattlePassModel = 0x20; // "SkinCenterBattlePassModel"
            inline constexpr std::uintptr_t skinCenterBattlePassViewModel = 0x28; // "SkinCenterBattlePassViewModel"
            inline constexpr std::uintptr_t premiumDialogModel = 0x30; // "BattlePassPremiumDialogModel"
            inline constexpr std::uintptr_t uiSoundModel = 0x38; // "GlobalUISoundModel"
            inline constexpr std::uintptr_t purchaseRules = 0x40; // "BattlePassPurchaseRules"
            inline constexpr std::uintptr_t tooltipTriggerMode = 0x48; // "PointerButtonDelayInputUpdater.TriggerMode"
            inline constexpr std::uintptr_t swipeView = 0x50; // "SwipeView"
            inline constexpr std::uintptr_t bannerMainRewardTooltipButton = 0x58; // "PointerButtonView"
            inline constexpr std::uintptr_t cosmeticTooltipButton = 0x60; // "PointerButtonView"
            inline constexpr std::uintptr_t updaters = 0x68; // "IUpdater[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x36DE450; // "public void Update()"
            inline constexpr std::uintptr_t IsRewardsScrolling = 0x36DD880; // "private bool IsRewardsScrolling()"
            inline constexpr std::uintptr_t UpdateSwipe = 0x36DE250; // "private void UpdateSwipe()"
            inline constexpr std::uintptr_t UpdateTooltipInput = 0x36DE360; // "private void UpdateTooltipInput(bool isActive, PointerButtonView button, InputModel input)"
            inline constexpr std::uintptr_t OnOpenRewards = 0x36DDBB0; // "private void OnOpenRewards()"
            inline constexpr std::uintptr_t OnBannerRewardClicked = 0x36DD930; // "private void OnBannerRewardClicked(BattlePassRewardId reward)"
            inline constexpr std::uintptr_t OnBuyPremium = 0x36DDAB0; // "private void OnBuyPremium()"
            inline constexpr std::uintptr_t OnBuyReward = 0x36DDB10; // "private void OnBuyReward()"
            inline constexpr std::uintptr_t OnShowRewardSkin = 0x36DE000; // "private void OnShowRewardSkin()"
            inline constexpr std::uintptr_t OnSexSwitch = 0x36DDF50; // "private void OnSexSwitch()"
            inline constexpr std::uintptr_t OnArrowLeft = 0x36DD910; // "private void OnArrowLeft()"
            inline constexpr std::uintptr_t OnArrowRight = 0x36DD920; // "private void OnArrowRight()"
            inline constexpr std::uintptr_t SwitchWeapon = 0x36DE180; // "private void SwitchWeapon(int offset)"
            inline constexpr std::uintptr_t OnPagesScrolled = 0x36DDDF0; // "private void OnPagesScrolled(int direction)"
            inline constexpr std::uintptr_t OnPageIndicatorClicked = 0x36DDD20; // "private void OnPageIndicatorClicked(int pageIndex)"
            inline constexpr std::uintptr_t OnRewardClicked = 0x36DDEA0; // "private void OnRewardClicked(BattlePassRewardId reward)"
        }
    } // namespace BattlePassInputUpdater

    namespace BattlePlayerUpdater { // "Game.Battle.Player.BattlePlayerUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t predictedInputsModel = 0x10; // "IPredictedInputsModel"
            inline constexpr std::uintptr_t dataTickModel = 0x18; // "IDataTickModel"
            inline constexpr std::uintptr_t predictedInputsModelUpdater = 0x20; // "IPredictedInputsModelUpdater"
            inline constexpr std::uintptr_t battleConnectionInfo = 0x28; // "RoomConnectionInfo"
            inline constexpr std::uintptr_t forceSendInputUpdater = 0x30; // "IForceSendInputUpdater"
            inline constexpr std::uintptr_t battleInputUpdater = 0x38; // "IBattleInputUpdater"
            inline constexpr std::uintptr_t sendBattleInputDataUpdater = 0x40; // "ISendBattleInputUpdater"
            inline constexpr std::uintptr_t simulatePreviousTicksUpdater = 0x48; // "ISimulatePreviousTicksUpdater"
            inline constexpr std::uintptr_t simulateNewTickUpdater = 0x50; // "ISimulateNewTickUpdater"
            inline constexpr std::uintptr_t playerSkeletonUpdater = 0x58; // "IUpdater"
            inline constexpr std::uintptr_t characterControlEnabledUpdater = 0x60; // "IUpdater"
            inline constexpr std::uintptr_t inputsUpdater = 0x68; // "IUpdater"
            inline constexpr std::uintptr_t itemSendMessageUpdater = 0x70; // "IUpdater"
            inline constexpr std::uintptr_t focusKeeperPositionUpdater = 0x78; // "IUpdater"
            inline constexpr std::uintptr_t predictionExtraTimeModelUpdater = 0x80; // "IUpdater"
            inline constexpr std::uintptr_t playerCargoSellsUpdater = 0x88; // "IUpdater"
            inline constexpr std::uintptr_t hitBoxesUpdater = 0x90; // "IUpdater"
            inline constexpr std::uintptr_t unsetItemUpdater = 0x98; // "IUpdater"
            inline constexpr std::uintptr_t containerDeferredOpenUpdater = 0xA0; // "IUpdater"
            inline constexpr std::uintptr_t playerVehicleSpawnersUpdater = 0xA8; // "IUpdater"
            inline constexpr std::uintptr_t playerCopJobViewUpdater = 0xB0; // "IUpdater"
            inline constexpr std::uintptr_t taxPointViewUpdater = 0xB8; // "IUpdater"
            inline constexpr std::uintptr_t clearCharacterInSmokescreenModelUpdater = 0xC0; // "IUpdater"
            inline constexpr std::uintptr_t regularGridUpdater = 0xC8; // "IUpdater"
            inline constexpr std::uintptr_t particleEffectUpdater = 0xD0; // "IUpdater"
            inline constexpr std::uintptr_t trafficLightSystemsUpdater = 0xD8; // "IUpdater"
            inline constexpr std::uintptr_t playerTeleportUpdater = 0xE0; // "IUpdater"
            inline constexpr std::uintptr_t battleToMainMenuUpdater = 0xE8; // "IUpdater"
            inline constexpr std::uintptr_t copsChatUpdater = 0xF0; // "IUpdater"
            inline constexpr std::uintptr_t battleChatInputUpdater = 0xF8; // "IUpdater"
            inline constexpr std::uintptr_t locationConstraintIslandsUpdater = 0x100; // "IUpdater"
            inline constexpr std::uintptr_t inventoryProgressUpdater = 0x108; // "InventoryProgressItemModelUpdater"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x95F520; // "public void Update()"
        }
    } // namespace BattlePlayerUpdater

    namespace BattleSuicideInputModelUpdater { // "Game.Battle.Suicide.BattleSuicideInputModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t inputModel = 0x10; // "InputModel"
            inline constexpr std::uintptr_t roomConnection = 0x18; // "IRoomConnection"
            inline constexpr std::uintptr_t inputActions = 0x20; // "InputActions"
            inline constexpr std::uintptr_t now = 0x28; // "INow"
            inline constexpr std::uintptr_t globalModel = 0x30; // "GlobalModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x38; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t suicideLocalization = 0x40; // "SuicideLocalization"
            inline constexpr std::uintptr_t globalLocalizationKeys = 0x48; // "GlobalLocalizationKeys"
            inline constexpr std::uintptr_t isRequested = 0x50; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xDA0690; // "public void Update()"
            inline constexpr std::uintptr_t OnSuicide = 0xDA0130; // "private void OnSuicide()"
            inline constexpr std::uintptr_t SendSuicideMessage = 0xDA0510; // "private void SendSuicideMessage()"
        }
    } // namespace BattleSuicideInputModelUpdater

    namespace BecomeRobberInputUpdater { // "Game.Battle.Inputs.BecomeRobberInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleEntitiesModel = 0x10; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t becomeRobberInputModel = 0x18; // "InputHoldModel"
            inline constexpr std::uintptr_t roomConnection = 0x20; // "IRoomConnection"
            inline constexpr std::uintptr_t isRequest = 0x28; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA730B0; // "public void Update()"
            inline constexpr std::uintptr_t SendMessage = 0xA73000; // "private void SendMessage()"
        }
    } // namespace BecomeRobberInputUpdater

    namespace BecomeRobberProlongedAction { // "Game.Battle.Entities.Player.ProlongedActions.BecomeRobberProlongedAction (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "BecomeRobberModel"
            inline constexpr std::uintptr_t Label = 0x18; // "LocalizedString"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsActive = 0xB1A580; // "public bool get_IsActive()"
            inline constexpr std::uintptr_t get_EndTs = 0xB1A560; // "public long get_EndTs()"
            inline constexpr std::uintptr_t get_Duration = 0xB1A500; // "public long get_Duration()"
        }
    } // namespace BecomeRobberProlongedAction

    namespace BlendTreeDescription { // "Models.References.Character.BlendTreeDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t AnimationContentId = 0x10; // "int"
        }
    } // namespace BlendTreeDescription

    namespace BollardActiveModel { // "Game.Battle.Entities.Player.Bollard.BollardActiveModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t BollardData = 0x10; // "BollardData"
            inline constexpr std::uintptr_t LocationBollardDescription = 0x18; // "LocationBollardDescription"
            inline constexpr std::uintptr_t NeedPlaySound = 0x20; // "bool"
            inline constexpr std::uintptr_t IsBollardOnCooldown = 0x21; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsActive = 0xB1A620; // "public bool get_IsActive()"
            inline constexpr std::uintptr_t SetData = 0xB1A5E0; // "public void SetData(LocationBollardDescription locationBollardDescription, BollardData bollardData)"
            inline constexpr std::uintptr_t Clear = 0xB1A5A0; // "public void Clear()"
        }
    } // namespace BollardActiveModel

    namespace BollardActiveUpdater { // "Game.Battle.Entities.Player.Updaters.BollardActiveUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t bollardActiveModel = 0x10; // "BollardActiveModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x18; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t copsRoleData = 0x20; // "CopsRoleData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB02900; // "public void Update()"
        }
    } // namespace BollardActiveUpdater

    namespace BollardInputUpdater { // "Game.Battle.Player.BollardInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t bollardInputModel = 0x10; // "InputModel"
            inline constexpr std::uintptr_t bollardActiveModel = 0x18; // "BollardActiveModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x20; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t copsRoleData = 0x28; // "CopsRoleData"
            inline constexpr std::uintptr_t roomConnection = 0x30; // "IRoomConnection"
            inline constexpr std::uintptr_t now = 0x38; // "ISetNow"
            inline constexpr std::uintptr_t isInProgress = 0x40; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x960F60; // "public void Update()"
            inline constexpr std::uintptr_t SendMessage = 0x960EA0; // "private void SendMessage(int bollardId)"
        }
    } // namespace BollardInputUpdater

    namespace BotMoveDirectionInput { // "Models.Messages.BotMoveDirectionInput (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Input = 0x10; // "Vector2"
            inline constexpr std::uintptr_t Time = 0x18; // "long"
        }
    } // namespace BotMoveDirectionInput

    namespace BotMoveDirectionInputData { // "Models.Messages.BotMoveDirectionInputData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t input = 0x20; // "IPrimitiveData<Vector2>"
            inline constexpr std::uintptr_t time = 0x28; // "IPrimitiveData<long>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Value = 0x49EFB70; // "public BotMoveDirectionInput get_Value()"
            inline constexpr std::uintptr_t set_Value = 0x49EFCA0; // "public void set_Value(BotMoveDirectionInput value)"
        }
    } // namespace BotMoveDirectionInputData

    namespace BuffsInputUpdater { // "Game.Battle.Buffs.BuffsInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t globalModel = 0x10; // "GlobalModel"
            inline constexpr std::uintptr_t updater = 0x18; // "IUpdater"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xD49300; // "public void Update()"
            inline constexpr std::uintptr_t OnClicked = 0xD49270; // "private void OnClicked(CodexBuffsDescription description)"
        }
    } // namespace BuffsInputUpdater

    namespace BuilderDropAreaInputUpdater { // "Game.Battle.Builder.BuilderDropAreaInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t builderSlotsModel = 0x20; // "BuilderSlotsModel"
            inline constexpr std::uintptr_t uiView = 0x28; // "BuilderDialogView"
            inline constexpr std::uintptr_t inventoryIntention = 0x30; // "InventoryIntention"
            inline constexpr std::uintptr_t personalNotificationModel = 0x38; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t notificationError = 0x40; // "NotificationError"
            inline constexpr std::uintptr_t dragAndDropModel = 0x48; // "InventoryDragAndDropModel"
            inline constexpr std::uintptr_t itemMoveModel = 0x50; // "ItemMoveModel"
            inline constexpr std::uintptr_t blockedSlotsModel = 0x58; // "BlockedSlotsModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xD2A1B0; // "public BuilderDropAreaInputUpdater Init(BuilderSlotsModel builderSlotsModel, BuilderDialogView uiView, InventoryModels inventoryModels, InventoryIntention inventoryIntention, PersonalNotificationModel personalNotificationModel, NotificationError notificationError, BlockedSlotsModel blockedSlotsModel)"
            inline constexpr std::uintptr_t Dispose = 0xB62AB0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xD2A270; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t UpdateSlot = 0xD2A460; // "private void UpdateSlot(BuilderSlotView view, BuilderSlotModel slotModel)"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace BuilderDropAreaInputUpdater

    namespace BuilderInputHandler { // "Game.Battle.Builder.BuilderInputHandler (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t updater = 0x20; // "IUpdater"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xD2A820; // "public BuilderInputHandler Init(BattleModel battleModel, PersonalNotificationModel personalNotificationModel, BuilderDialogView uiView, BuilderSlotsModel builderSlotsModel, NotificationError notificationError, UpdaterPool updaterPool, IRegisterDisposable registerDisposable)"
            inline constexpr std::uintptr_t Dispose = 0xA12060; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xD2A9B0; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace BuilderInputHandler

    namespace BuyCharacterBagSkinMessage { // "Models.Messages.BuyCharacterBagSkinMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t skin = 0x20; // "IPrimitiveData<CharacterBagDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Skin = 0x49E7430; // "public CharacterBagDescription get_Skin()"
            inline constexpr std::uintptr_t get_Type = 0x49E74F0; // "public override string get_Type()"
        }
    } // namespace BuyCharacterBagSkinMessage

    namespace BuyCharacterBodySkinMessage { // "Models.Messages.BuyCharacterBodySkinMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t skin = 0x20; // "IPrimitiveData<CharacterBodyDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Skin = 0x49E7760; // "public CharacterBodyDescription get_Skin()"
            inline constexpr std::uintptr_t get_Type = 0x49E7820; // "public override string get_Type()"
        }
    } // namespace BuyCharacterBodySkinMessage

    namespace BuyCharacterFBodySkinMessage { // "Models.Messages.BuyCharacterFBodySkinMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t skin = 0x20; // "IPrimitiveData<CharacterFBodyDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Skin = 0x49E7A90; // "public CharacterFBodyDescription get_Skin()"
            inline constexpr std::uintptr_t get_Type = 0x49E7B50; // "public override string get_Type()"
        }
    } // namespace BuyCharacterFBodySkinMessage

    namespace BuyCharacterKeychainSkinMessage { // "Models.Messages.BuyCharacterKeychainSkinMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t skin = 0x20; // "IPrimitiveData<CharacterKeychainDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Skin = 0x49E7DC0; // "public CharacterKeychainDescription get_Skin()"
            inline constexpr std::uintptr_t get_Type = 0x49E7E80; // "public override string get_Type()"
        }
    } // namespace BuyCharacterKeychainSkinMessage

    namespace BuyCharacterMaskSkinMessage { // "Models.Messages.BuyCharacterMaskSkinMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t skin = 0x20; // "IPrimitiveData<CharacterMaskDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Skin = 0x49E80F0; // "public CharacterMaskDescription get_Skin()"
            inline constexpr std::uintptr_t get_Type = 0x49E81B0; // "public override string get_Type()"
        }
    } // namespace BuyCharacterMaskSkinMessage

    namespace CachedCharacterCustomizationLoadingModelUpdater { // "Game.Global.SkinCenter.Customization.CachedCharacterCustomizationLoadingModelUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t characterCustomizationModel = 0x10; // "CharacterCustomizationModel"
            inline constexpr std::uintptr_t customizationModel = 0x18; // "ICustomizationModel"
            inline constexpr std::uintptr_t versionModel = 0x20; // "ICustomizationVersionModel"
            inline constexpr std::uintptr_t loadingModel = 0x28; // "ISkinLoadingModel<ICustomizationSnapshotModel>"
            inline constexpr std::uintptr_t scopesLoadingModel = 0x30; // "ScopesLoadingModel"
            inline constexpr std::uintptr_t loadedContents = 0x38; // "HashSet<ILoadedContent>"
            inline constexpr std::uintptr_t finishedScopes = 0x40; // "List<LoadedContentScope>"
            inline constexpr std::uintptr_t loadingScope = 0x48; // "LoadedContentScope"
            inline constexpr std::uintptr_t loadingCompletionSource = 0x50; // "TaskCompletionSource<bool>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x3640A50; // "public void Update()"
            inline constexpr std::uintptr_t StartLoading = 0x3640450; // "private void StartLoading()"
            inline constexpr std::uintptr_t FinishLoading = 0x36402B0; // "private void FinishLoading()"
            inline constexpr std::uintptr_t CancelLoading = 0x3640220; // "private void CancelLoading()"
        }
    } // namespace CachedCharacterCustomizationLoadingModelUpdater

    namespace CameraAnimationUpdater { // "Game.Battle.Entities.Player.Camera.CameraAnimationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t armedCamera = 0x10; // "CinemachineVirtualCamera"
            inline constexpr std::uintptr_t aimingCameraFollow = 0x18; // "CinemachineAimingCameraFollow"
            inline constexpr std::uintptr_t armedCameraOffset = 0x20; // "CinemachineCameraOffset"
            inline constexpr std::uintptr_t animationView = 0x28; // "AnimationIKView"
            inline constexpr std::uintptr_t fireModel = 0x30; // "CharacterFireModel"
            inline constexpr std::uintptr_t selectedWeaponModel = 0x38; // "SelectedWeaponModel"
            inline constexpr std::uintptr_t deltaFovArmed = 0x40; // "float"
            inline constexpr std::uintptr_t deltaFovAimed = 0x44; // "float"
            inline constexpr std::uintptr_t deltaDutchArmed = 0x48; // "float"
            inline constexpr std::uintptr_t cachedFovArmed = 0x4C; // "float"
            inline constexpr std::uintptr_t cachedFovAimed = 0x50; // "float"
            inline constexpr std::uintptr_t cachedDutchArmed = 0x54; // "float"
            inline constexpr std::uintptr_t shotFovTarget = 0x58; // "float"
            inline constexpr std::uintptr_t shotFovCurrent = 0x5C; // "float"
            inline constexpr std::uintptr_t shotFovVelocity = 0x60; // "float"
            inline constexpr std::uintptr_t shotFovAttackTime = 0x64; // "float"
            inline constexpr std::uintptr_t shotFovAttackEndTs = 0x68; // "float"
            inline constexpr std::uintptr_t shotFovDecayTime = 0x6C; // "float"
            inline constexpr std::uintptr_t rollKickTarget = 0x70; // "float"
            inline constexpr std::uintptr_t rollKickCurrent = 0x74; // "float"
            inline constexpr std::uintptr_t rollKickVelocity = 0x78; // "float"
            inline constexpr std::uintptr_t rollKickAttackTime = 0x7C; // "float"
            inline constexpr std::uintptr_t rollKickAttackEndTs = 0x80; // "float"
            inline constexpr std::uintptr_t rollKickDecayTime = 0x84; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB1AFC0; // "public void Update()"
            inline constexpr std::uintptr_t ResolveShotAnimations = 0xB1A820; // "private void ResolveShotAnimations()"
            inline constexpr std::uintptr_t ResolveFovAttack = 0xB1A640; // "private void ResolveFovAttack(WeaponShotCameraViewDescription description)"
            inline constexpr std::uintptr_t ResolveRollKick = 0xB1A6E0; // "private void ResolveRollKick(WeaponShotCameraViewDescription description)"
            inline constexpr std::uintptr_t UpdateFovAttack = 0xB1ACA0; // "private void UpdateFovAttack()"
            inline constexpr std::uintptr_t UpdateFovDecay = 0xB1AD70; // "private void UpdateFovDecay()"
            inline constexpr std::uintptr_t UpdateRollAttack = 0xB1AE50; // "private void UpdateRollAttack()"
            inline constexpr std::uintptr_t UpdateRollDecay = 0xB1AF10; // "private void UpdateRollDecay()"
            inline constexpr std::uintptr_t RollbackFov = 0xB1ABD0; // "private void RollbackFov(float delta, float cachedValue, CinemachineVirtualCamera camera)"
            inline constexpr std::uintptr_t RollbackFov_2 = 0xB1AB00; // "private void RollbackFov(float delta, float cachedValue, CinemachineAimingCameraFollow camera)"
            inline constexpr std::uintptr_t RollbackDutch = 0xB1AA30; // "private void RollbackDutch(float delta, float cachedValue, CinemachineVirtualCamera camera)"
        }
    } // namespace CameraAnimationUpdater

    namespace CameraArmedUpdater { // "Game.Battle.EntityModel.Player.CameraArmedUpdater (Battle.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x7B3360; // "public void Update()"
        }
    } // namespace CameraArmedUpdater

    namespace CameraBattleAssistanceTargetUpdater { // "Game.Battle.Entities.Player.BattleAssistance.CameraBattleAssistanceTargetUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleEntitiesModel = 0x20; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t battleAssistanceModel = 0x28; // "BattleAssistanceModel"
            inline constexpr std::uintptr_t model = 0x30; // "CameraModel"
            inline constexpr std::uintptr_t view = 0x38; // "CameraEntityView"
            inline constexpr std::uintptr_t isActive = 0x40; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xB3B6A0; // "public CameraBattleAssistanceTargetUpdater Init(BattleModel battleModel, CameraModel model, CameraEntityView view)"
            inline constexpr std::uintptr_t Dispose = 0xB3B610; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xB3B840; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t UpdateActive = 0xB3B9A0; // "private void UpdateActive(bool isActive)"
            inline constexpr std::uintptr_t Stop = 0xB3B960; // "public void Stop()"
            inline constexpr std::uintptr_t IsActive = 0xB3B730; // "private bool IsActive()"
            inline constexpr std::uintptr_t Core_Updater_IStoppedUpdater_Update = 0x9165B0; // "private void Core.Updater.IStoppedUpdater.Update()"
        }
    } // namespace CameraBattleAssistanceTargetUpdater

    namespace CargoProductionWorkbenchInputDescription { // "Models.References.Input.CargoProductionWorkbenchInputDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x81A1510; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t SetRecipeFromCargo = 0x0; // "CargoProductionWorkbenchInputDescription"
            inline constexpr std::uintptr_t UnsetRecipe = 0x8; // "CargoProductionWorkbenchInputDescription"
        }
    } // namespace CargoProductionWorkbenchInputDescription

    namespace ChangeImmunityRules { // "Models.Utils.InputRules.ChangeImmunityRules (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t CanInputAffectImmunity = 0x393FF00; // "public static bool CanInputAffectImmunity(long now, CharacterImmuneStateModel immuneModel, BattleCharacterHoldingCellModel holdingCellModel)"
            inline constexpr std::uintptr_t UpdateImmunityDueToInput = 0x3940290; // "public static void UpdateImmunityDueToInput(long now, CharacterImmuneStateModel immuneModel, BattleCharacterHoldingCellModel holdingCellModel)"
            inline constexpr std::uintptr_t RemoveImmunityDueToAttack = 0x3940010; // "public static void RemoveImmunityDueToAttack(CharacterImmuneStateModel immuneModel, BattleCharacterHoldingCellModel holdingCellModel)"
            inline constexpr std::uintptr_t UpdateImmunitiesDueToInputInVehicle = 0x39400B0; // "public static void UpdateImmunitiesDueToInputInVehicle(VehicleSeatsModel vehicleSeatsModel, long now, ReadOnly.Dictionary<int, BattleCharacterModel> battleCharacters)"
        }
    } // namespace ChangeImmunityRules

    namespace CharacterAimingAnimationUpdater { // "Game.Battle.Entities.BattleCharacter.Updaters.CharacterAimingAnimationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t aimingModel = 0x10; // "CharacterAimingModel"
            inline constexpr std::uintptr_t view = 0x18; // "CharacterAnimationView"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xBC4830; // "public void Update()"
        }
    } // namespace CharacterAimingAnimationUpdater

    namespace CharacterAimingModel { // "Game.Battle.EntityModel.BattleCharacter.CharacterAimingModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Aim = 0x10; // "float"
            inline constexpr std::uintptr_t AimDirectionX = 0x14; // "float"
            inline constexpr std::uintptr_t AimDirectionY = 0x18; // "float"
        }
    } // namespace CharacterAimingModel

    namespace CharacterAnimatorControllersPools { // "Game.Battle.Entities.BattleCharacter.CharacterAnimatorControllersPools (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t viewDescriptions = 0x10; // "CharacterAnimatorControllerViewDescriptions"
            inline constexpr std::uintptr_t pools = 0x18; // "Dictionary<CharacterSexDescription, AnimatorControllersPool>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Item = 0xBC4AB0; // "public AnimatorControllersPool get_Item(CharacterSexDescription sex)"
            inline constexpr std::uintptr_t Dispose = 0xBC4860; // "public void Dispose()"
        }
    } // namespace CharacterAnimatorControllersPools

    namespace CharacterArmedAnimationUpdater { // "Game.Battle.Entities.BattleCharacter.Armed.CharacterArmedAnimationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t armedModel = 0x10; // "ArmedModel"
            inline constexpr std::uintptr_t characterArmedModel = 0x18; // "CharacterArmedModel"
            inline constexpr std::uintptr_t animationView = 0x20; // "CharacterAnimationView"
            inline constexpr std::uintptr_t isArmed = 0x28; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xBE96B0; // "public void Update()"
        }
    } // namespace CharacterArmedAnimationUpdater

    namespace CharacterArmedModel { // "Game.Battle.EntityModel.BattleCharacter.Weapon.CharacterArmedModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Armed = 0x10; // "float"
        }
    } // namespace CharacterArmedModel

    namespace CharacterArmedModelUpdater { // "Game.Battle.Entities.BattleCharacter.Armed.CharacterArmedModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t characterModel = 0x10; // "BattleCharacterModel"
            inline constexpr std::uintptr_t characterArmedModel = 0x18; // "CharacterArmedModel"
            inline constexpr std::uintptr_t armed = 0x20; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xBE9720; // "public void Update()"
        }
    } // namespace CharacterArmedModelUpdater

    namespace CharacterArrestedVisibleModelUpdater { // "Game.Battle.EntityModel.BattleCharacter.CharacterArrestedVisibleModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t characterClientModel = 0x10; // "CharacterClientModel"
            inline constexpr std::uintptr_t arrestTargetModel = 0x18; // "ArrestTargetModel"
            inline constexpr std::uintptr_t now = 0x20; // "INow"
            inline constexpr std::uintptr_t isHidden = 0x28; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xCC0890; // "public void Update()"
        }
    } // namespace CharacterArrestedVisibleModelUpdater

    namespace CharacterBagAndMaskVisibleModelUpdater { // "Game.Battle.Entities.BattleCharacter.Customize.Updaters.CharacterBagAndMaskVisibleModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t characterCustomizationModel = 0x10; // "CharacterCustomizationModel"
            inline constexpr std::uintptr_t role = 0x18; // "IPrimitiveModel<PlayerRoleDescription>"
            inline constexpr std::uintptr_t stateModel = 0x20; // "IBattleCharacterStateModel"
            inline constexpr std::uintptr_t becomeRobberModel = 0x28; // "BecomeRobberModel"
            inline constexpr std::uintptr_t inVehicleModel = 0x30; // "InVehicleModel"
            inline constexpr std::uintptr_t characterCopBodiesViewDescription = 0x38; // "CharacterPoliceBodiesViewDescription"
            inline constexpr std::uintptr_t customizationModel = 0x40; // "ICustomizationModel"
            inline constexpr std::uintptr_t now = 0x48; // "INow"
            inline constexpr std::uintptr_t state = 0x50; // "BattleCharacterState"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xBE97E0; // "public void Update()"
        }
    } // namespace CharacterBagAndMaskVisibleModelUpdater

    namespace CharacterBagContent { // "Game.Global.SkinCenter.ViewDescriptions.Character.Contents.CharacterBagContent (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t BagMaterial = 0x18; // "Material"
            inline constexpr std::uintptr_t StrapMaterial = 0x20; // "Material"
            inline constexpr std::uintptr_t Lods = 0x28; // "Mesh[]"
        }
    } // namespace CharacterBagContent

    namespace CharacterBagDescription { // "Models.References.Character.Customizer.CharacterBagDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsAvailable = 0x20; // "bool"
            inline constexpr std::uintptr_t CryptoCoinsPrice = 0x24; // "int"
            inline constexpr std::uintptr_t CompensationCryptoCoins = 0x28; // "int"
            inline constexpr std::uintptr_t ImprisonmentYearsRequired = 0x2C; // "int"
            inline constexpr std::uintptr_t IsHidden = 0x30; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_HasPrice = 0x4406310; // "public bool get_HasPrice()"
            inline constexpr std::uintptr_t get_BuyParams = 0x4469A00; // "public ValueTuple<int, int> get_BuyParams()"
        }
    } // namespace CharacterBagDescription

    namespace CharacterBattleAssistanceTargetUpdater { // "Game.Battle.Entities.Player.BattleAssistance.CharacterBattleAssistanceTargetUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t globalModel = 0x10; // "GlobalModel"
            inline constexpr std::uintptr_t battleModel = 0x18; // "BattleModel"
            inline constexpr std::uintptr_t characterModel = 0x20; // "BattleCharacterEntityModel"
            inline constexpr std::uintptr_t view = 0x28; // "BattleCharacterEntityView"
            inline constexpr std::uintptr_t battleAssistanceTargetModel = 0x30; // "BattleAssistanceTargetModel"
            inline constexpr std::uintptr_t isActive = 0x38; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB3C2A0; // "public void Update()"
            inline constexpr std::uintptr_t IsActive = 0xB3BDE0; // "private bool IsActive(BattleCharacterModel serverModel)"
            inline constexpr std::uintptr_t AddTarget = 0xB3BCF0; // "private void AddTarget()"
            inline constexpr std::uintptr_t RemoveTarget = 0xB3C240; // "private void RemoveTarget()"
        }
    } // namespace CharacterBattleAssistanceTargetUpdater

    namespace CharacterBeardDescription { // "Models.References.Character.Customizer.CharacterBeardDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t SexDescriptionFunc = 0x20; // "Func<CharacterSexDescription>"
            inline constexpr std::uintptr_t IsHidden = 0x28; // "bool"
            inline constexpr std::uintptr_t NoBeard = 0x29; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_SexDescription = 0x9D6230; // "public CharacterSexDescription get_SexDescription()"
        }
    } // namespace CharacterBeardDescription

    namespace CharacterBeardMaterialsContent { // "Game.Global.SkinCenter.ViewDescriptions.Character.Contents.CharacterBeardMaterialsContent (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Materials = 0x18; // "Material[]"
            inline constexpr std::uintptr_t BristleMaterial = 0x20; // "Material"
        }
    } // namespace CharacterBeardMaterialsContent

    namespace CharacterBecomeRobberAnimationUpdater { // "Game.Battle.EntityModel.BattleCharacter.BecomeRobber.CharacterBecomeRobberAnimationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t animationView = 0x10; // "CharacterAnimationView"
            inline constexpr std::uintptr_t becomeRobberModel = 0x18; // "BecomeRobberModel"
            inline constexpr std::uintptr_t now = 0x20; // "INow"
            inline constexpr std::uintptr_t skeletonAnimationModel = 0x28; // "SkeletonAnimationModel"
            inline constexpr std::uintptr_t stateModel = 0x30; // "IBattleCharacterStateModel"
            inline constexpr std::uintptr_t isActive = 0x38; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xCE1E80; // "public void Update()"
            inline constexpr std::uintptr_t GetParams = 0xCE1BE0; // "private ValueTuple<CharacterBecomeRobberAnimationUpdater.PutMaskAnimPhase, float> GetParams()"
        }
    } // namespace CharacterBecomeRobberAnimationUpdater

    namespace CharacterBlindAnimationUpdater { // "Game.Battle.Entities.BattleCharacter.Affliction.CharacterBlindAnimationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t blindedEffectModel = 0x18; // "IPrimitiveModel<BlindedEffectDescription>"
            inline constexpr std::uintptr_t animationView = 0x20; // "CharacterAnimationView"
            inline constexpr std::uintptr_t underGas = 0x28; // "CharacterUnderGasModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t InnerUpdate = 0xBE9C30; // "protected override void InnerUpdate()"
            inline constexpr std::uintptr_t InnerStart = 0x7B3360; // "protected override void InnerStart()"
            inline constexpr std::uintptr_t InnerStop = 0xBE9C00; // "protected override void InnerStop()"
        }
    } // namespace CharacterBlindAnimationUpdater

    namespace CharacterBodyContent { // "Game.Global.SkinCenter.ViewDescriptions.Character.Contents.CharacterBodyContent (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Materials = 0x18; // "Material[]"
            inline constexpr std::uintptr_t Lods = 0x20; // "Mesh[]"
            inline constexpr std::uintptr_t StrapLods = 0x28; // "Mesh[]"
        }
    } // namespace CharacterBodyContent

    namespace CharacterBodyDescription { // "Models.References.Character.Customizer.CharacterBodyDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsAvailable = 0x20; // "bool"
            inline constexpr std::uintptr_t CryptoCoinsPrice = 0x24; // "int"
            inline constexpr std::uintptr_t CompensationCryptoCoins = 0x28; // "int"
            inline constexpr std::uintptr_t ImprisonmentYearsRequired = 0x2C; // "int"
            inline constexpr std::uintptr_t IsHidden = 0x30; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_HasPrice = 0x4406310; // "public bool get_HasPrice()"
            inline constexpr std::uintptr_t get_BuyParams = 0x446A370; // "public ValueTuple<int, int> get_BuyParams()"
        }
    } // namespace CharacterBodyDescription

    namespace CharacterBodyPoseStateUpdater { // "Game.Battle.Entities.BattleCharacter.Updaters.CharacterBodyPoseStateUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x18; // "BattleCharacterModel"
            inline constexpr std::uintptr_t stateGroup = 0x20; // "EnumStateElement<BodyPose>"
            inline constexpr std::uintptr_t pose = 0x28; // "BodyPose"
        }
        namespace Methods {
            inline constexpr std::uintptr_t InnerStart = 0xBC4E20; // "protected override void InnerStart()"
            inline constexpr std::uintptr_t InnerUpdate = 0xBC4E80; // "protected override void InnerUpdate()"
            inline constexpr std::uintptr_t InnerStop = 0x7B3360; // "protected override void InnerStop()"
            inline constexpr std::uintptr_t GetBodyPose = 0xBC4C90; // "private BodyPose GetBodyPose()"
        }
    } // namespace CharacterBodyPoseStateUpdater

    namespace CharacterBoxingYawModelUpdater { // "Game.Battle.Entities.BattleCharacter.Rotation.CharacterBoxingYawModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t rotationModel = 0x10; // "CharacterRotationModel"
            inline constexpr std::uintptr_t battleStance = 0x18; // "BattleStanceModel"
            inline constexpr std::uintptr_t skeletonDeformationDescription = 0x20; // "BattleCharacterSkeletonDeformationConfig"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xBD45C0; // "public void Update()"
        }
    } // namespace CharacterBoxingYawModelUpdater

    namespace CharacterCargoAnimationUpdater { // "Game.Battle.Entities.BattleCharacter.Updaters.CharacterCargoAnimationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t cargoModel = 0x18; // "CharacterCargoModel"
            inline constexpr std::uintptr_t view = 0x20; // "CharacterAnimationView"
            inline constexpr std::uintptr_t cargo = 0x28; // "CargoDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t InnerUpdate = 0xBC4F90; // "protected override void InnerUpdate()"
            inline constexpr std::uintptr_t InnerStart = 0xBC4EF0; // "protected override void InnerStart()"
            inline constexpr std::uintptr_t InnerStop = 0xBC4F60; // "protected override void InnerStop()"
        }
    } // namespace CharacterCargoAnimationUpdater

    namespace CharacterCargoModel { // "Models.Models.CharacterCargo.CharacterCargoModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "CargoData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_HasCargo = 0x4976430; // "public bool get_HasCargo()"
            inline constexpr std::uintptr_t get_Cargo = 0x4976390; // "public CargoDescription get_Cargo()"
            inline constexpr std::uintptr_t get_CumulativePoints = 0x49763E0; // "public int get_CumulativePoints()"
            inline constexpr std::uintptr_t Set = 0x4976250; // "public void Set(CargoDescription cargoDescription, int cumulativePoints)"
            inline constexpr std::uintptr_t Unset = 0x4976300; // "public void Unset()"
        }
    } // namespace CharacterCargoModel

    namespace CharacterCenterPositionModel { // "Models.Models.CharacterCenterPositionModel.CharacterCenterPositionModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t positionModel = 0x10; // "IPositionModel"
            inline constexpr std::uintptr_t crouchModel = 0x18; // "CrouchModel"
            inline constexpr std::uintptr_t physicsCharacterConfig = 0x20; // "PhysicsCharacterConfig"
            inline constexpr std::uintptr_t knockoutModel = 0x28; // "KnockoutModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_X = 0x49764F0; // "public float get_X()"
            inline constexpr std::uintptr_t get_Y = 0x4976540; // "public float get_Y()"
            inline constexpr std::uintptr_t get_Z = 0x49765F0; // "public float get_Z()"
            inline constexpr std::uintptr_t get_Length = 0x4976490; // "private float get_Length()"
        }
    } // namespace CharacterCenterPositionModel

    namespace CharacterChangeCopEquipSkinModelUpdater { // "Game.Battle.Entities.BattleCharacter.ChangeCopEquip.CharacterChangeCopEquipSkinModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t currentCustomizationModel = 0x10; // "CharacterCustomizationModel"
            inline constexpr std::uintptr_t copCustomizeModel = 0x18; // "CopCustomizeModel"
            inline constexpr std::uintptr_t copCustomize = 0x20; // "CopCustomizeDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xBE9D30; // "public void Update()"
        }
    } // namespace CharacterChangeCopEquipSkinModelUpdater

    namespace CharacterChargeCumulativeAnimationUpdater { // "Game.Battle.Entities.BattleCharacter.Animations.CharacterChargeCumulativeAnimationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t animationView = 0x18; // "CharacterAnimationView"
            inline constexpr std::uintptr_t prolongedInteractionModel = 0x20; // "ProlongedInteractionModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t InnerUpdate = 0xBE9E00; // "protected override void InnerUpdate()"
            inline constexpr std::uintptr_t InnerStart = 0x7B3360; // "protected override void InnerStart()"
            inline constexpr std::uintptr_t InnerStop = 0xBE9DD0; // "protected override void InnerStop()"
        }
    } // namespace CharacterChargeCumulativeAnimationUpdater

    namespace CharacterClientModel { // "Game.Battle.EntityModel.BattleCharacter.CharacterClientModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t MovementTimeline = 0x10; // "MovementTimeline"
            inline constexpr std::uintptr_t LookRotationTimeline = 0x18; // "RotationTimeline"
            inline constexpr std::uintptr_t RotationTimeline = 0x20; // "RotationTimeline"
            inline constexpr std::uintptr_t Movement = 0x28; // "MovementModel"
            inline constexpr std::uintptr_t SetMovement = 0x30; // "SetMovementModel"
            inline constexpr std::uintptr_t RotationModel = 0x38; // "CharacterRotationModel"
            inline constexpr std::uintptr_t RotationInterpolated = 0x40; // "CharacterRotationModel"
            inline constexpr std::uintptr_t RelativeVelocityModel = 0x48; // "CharacterRelativeVelocityModel"
            inline constexpr std::uintptr_t MovementIntentionDirectionModel = 0x50; // "CharacterMovementIntentionDirectionModel"
            inline constexpr std::uintptr_t SelfHitsModel = 0x58; // "BattleCharacterHitsModel"
            inline constexpr std::uintptr_t StateAnimationModel = 0x60; // "StateAnimationModel"
            inline constexpr std::uintptr_t CharacterReloadingModel = 0x68; // "CharacterReloadingModel"
            inline constexpr std::uintptr_t CharacterCrouchModel = 0x70; // "CharacterCrouchModel"
            inline constexpr std::uintptr_t SelectedItemModel = 0x78; // "SelectedItemModel"
            inline constexpr std::uintptr_t CharacterHeadManualControlRulesModel = 0x80; // "CharacterHeadManualControlRulesModel"
            inline constexpr std::uintptr_t CharacterArmedModel = 0x88; // "CharacterArmedModel"
            inline constexpr std::uintptr_t CharacterTurningModel = 0x90; // "CharacterTurningModel"
            inline constexpr std::uintptr_t VisibleModel = 0x98; // "BattleCharacterVisibleModel"
            inline constexpr std::uintptr_t VelocityModel = 0xA0; // "CharacterVelocityModel"
            inline constexpr std::uintptr_t SexModel = 0xA8; // "CharacterSexModel"
            inline constexpr std::uintptr_t IsHiddenModel = 0xB0; // "IsHiddenModel"
            inline constexpr std::uintptr_t CharacterFireModel = 0xB8; // "CharacterFireModel"
            inline constexpr std::uintptr_t MeleeAttackProgressModel = 0xC0; // "CharacterMeleeAttackProgressModel"
            inline constexpr std::uintptr_t BlendArgs = 0xC8; // "BlendArgs"
            inline constexpr std::uintptr_t CharacterAimingModel = 0xD0; // "CharacterAimingModel"
            inline constexpr std::uintptr_t FirstFootstepSoundModel = 0xD8; // "CharacterFirstFootstepSoundModel"
            inline constexpr std::uintptr_t CharacterUnderGasModel = 0xE0; // "CharacterUnderGasModel"
            inline constexpr std::uintptr_t MaleSkinLoadingModel = 0xE8; // "SkinLoadingModel<CustomizationMaleSnapshotModel>"
            inline constexpr std::uintptr_t FemaleSkinLoadingModel = 0xF0; // "SkinLoadingModel<CustomizationFemaleSnapshotModel>"
            inline constexpr std::uintptr_t CharacterCustomizationViewModel = 0xF8; // "CharacterCustomizationViewModel"
            inline constexpr std::uintptr_t CharacterCustomizationModel = 0x100; // "CharacterCustomizationModel"
            inline constexpr std::uintptr_t CharacterUseItemModel = 0x108; // "CharacterUseItemModel"
            inline constexpr std::uintptr_t CompositeMaterialsProvider = 0x110; // "CompositeSharedMaterialsProvider"
            inline constexpr std::uintptr_t CharacterWaterZonesModel = 0x118; // "CharacterWaterZonesModel"
            inline constexpr std::uintptr_t SqrDistanceToPlayer = 0x120; // "float"
        }
    } // namespace CharacterClientModel

    namespace CharacterControllerAirObstaclesSystem { // "Models.Systems.CharacterControllerAirObstaclesSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsSceneModel = 0x38; // "PhysicsSceneModel"
            inline constexpr std::uintptr_t tickDeltaTime = 0x40; // "float"
            inline constexpr std::uintptr_t airVelocityYChangeEvents = 0x48; // "IEventsSet<CharacterControllerAirVelocityYChangedEvent>"
            inline constexpr std::uintptr_t physicsDebugEnabledModel = 0x50; // "PhysicsDebugEnabledModel"
            inline constexpr std::uintptr_t physicsDebugModel = 0x58; // "IPhysicsDebugModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x3F88650; // "protected override void Tick(ITick tick)"
            inline constexpr std::uintptr_t UpdateCharacterAirVelocityY = 0x3F88880; // "private void UpdateCharacterAirVelocityY(CharacterControllerModel character, IEventsSet<BattleCharacterContactEventData> physicsContactEvents, in Vector3 recalculatedByPhysicsLinearVelocity, PhysicsDebugBattleCharacterTickData physicsDebug)"
            inline constexpr std::uintptr_t UpdateCharacterHorizontalVelocity = 0x3F88C10; // "private void UpdateCharacterHorizontalVelocity(CharacterControllerModel character, in Vector3 recalculatedByPhysicsLinearVelocity)"
            inline constexpr std::uintptr_t WriteVerticalVelocityChangeEventDataToDebug = 0x3F88DC0; // "private static void WriteVerticalVelocityChangeEventDataToDebug(PhysicsDebugBattleCharacterTickData physicsDebug, ref CharacterControllerAirVelocityYChangedEvent eventData)"
        }
    } // namespace CharacterControllerAirObstaclesSystem

    namespace CharacterControllerAirTriggersSystem { // "Models.Systems.CharacterControllerAirTriggersSystem (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x3F88F60; // "protected override void Tick(ITick tick)"
            inline constexpr std::uintptr_t ShouldUpdateAirVelocity = 0x3F88ED0; // "private static bool ShouldUpdateAirVelocity(BattleCharacterDamageZoneModel battleCharacterDamageZone)"
            inline constexpr std::uintptr_t IsDamageZoneEffectWithVelocityModifier = 0x3F88E90; // "private static bool IsDamageZoneEffectWithVelocityModifier(DamageZoneEffectDescription damageZoneEffect)"
        }
    } // namespace CharacterControllerAirTriggersSystem

    namespace CharacterControllerAirVelocityYChangedEvent { // "Models.CharacterController.CharacterControllerAirVelocityYChangedEvent (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t BodyId = 0x0; // "PhysicsBodyId"
            inline constexpr std::uintptr_t OldAirVelocityY = 0x8; // "float"
            inline constexpr std::uintptr_t NewAirVelocityY = 0xC; // "float"
            inline constexpr std::uintptr_t WaterSoftCollisionCorrection = 0x10; // "bool"
        }
    } // namespace CharacterControllerAirVelocityYChangedEvent

    namespace CharacterControllerApplyVelocitySystem { // "Models.Systems.CharacterControllerApplyVelocitySystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t scene = 0x38; // "PhysicsSceneModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x3F89160; // "protected override void Tick(ITick tick)"
        }
    } // namespace CharacterControllerApplyVelocitySystem

    namespace CharacterControllerData { // "Models.Data.CharacterControllerData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t LastInputVelocityX = 0x20; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t LastInputVelocityY = 0x28; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t LastInputVelocityZ = 0x30; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t AirVelocityY = 0x38; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t AirControlVelocityX = 0x40; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t AirControlVelocityZ = 0x48; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t CapsuleColliderRadius = 0x50; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t CapsuleColliderLength = 0x58; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t CapsuleColliderDistanceToGround = 0x60; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t StuckInFallingStateCounter = 0x68; // "IPrimitiveData<byte>"
        }
    } // namespace CharacterControllerData

    namespace CharacterControllerExtraHorizontalVelocitySystem { // "Models.Systems.CharacterControllerExtraHorizontalVelocitySystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t tickDeltaTime = 0x38; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x3F8A110; // "protected override void Tick(ITick tick)"
            inline constexpr std::uintptr_t UpdateDisabledMovementHorizontalVelocity = 0x3F8A480; // "private void UpdateDisabledMovementHorizontalVelocity(CharacterControllerModel character)"
            inline constexpr std::uintptr_t UpdateGroundMovementHorizontalVelocity = 0x3F8A480; // "private void UpdateGroundMovementHorizontalVelocity(CharacterControllerModel character)"
            inline constexpr std::uintptr_t UpdateSwimmingMovementHorizontalVelocity = 0x3F8A480; // "private void UpdateSwimmingMovementHorizontalVelocity(CharacterControllerModel character)"
            inline constexpr std::uintptr_t UpdateAirMovementHorizontalVelocity = 0x3F8A290; // "private void UpdateAirMovementHorizontalVelocity(CharacterControllerModel character, float airControlAcceleration, float airControlMaxVelocity)"
            inline constexpr std::uintptr_t UpdateBunnyHopMovementHorizontalVelocity = 0x3F8A3C0; // "private void UpdateBunnyHopMovementHorizontalVelocity(CharacterControllerModel character, float airControlAcceleration, float airControlMaxVelocity)"
            inline constexpr std::uintptr_t RecalculateAirControlVelocity = 0x3F89D70; // "private void RecalculateAirControlVelocity(CharacterControllerModel character, float airControlAcceleration, float airControlMaxVelocity, float oldAirControlVelocityX, float oldAirControlVelocityZ, out float airControlVelocityX, out float airControlIntegratedVelocityX, out float airControlVelocityZ, out float airControlIntegratedVelocityZ)"
            inline constexpr std::uintptr_t SetAirControlVelocity = 0x3F8A000; // "private void SetAirControlVelocity(CharacterControllerModel character, float airControlVelocityX, float airControlIntegratedVelocityX, float airControlVelocityZ, float airControlIntegratedVelocityZ)"
        }
    } // namespace CharacterControllerExtraHorizontalVelocitySystem

    namespace CharacterControllerExtraVerticalVelocitySystem { // "Models.Systems.CharacterControllerExtraVerticalVelocitySystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsSceneModel = 0x38; // "PhysicsSceneModel"
            inline constexpr std::uintptr_t tickDeltaTime = 0x40; // "float"
            inline constexpr std::uintptr_t airVelocityYChangeEvents = 0x48; // "IEventsSet<CharacterControllerAirVelocityYChangedEvent>"
            inline constexpr std::uintptr_t physicsDebugEnabledModel = 0x50; // "PhysicsDebugEnabledModel"
            inline constexpr std::uintptr_t physicsDebugModel = 0x58; // "IPhysicsDebugModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x3F8A7B0; // "protected override void Tick(ITick tick)"
            inline constexpr std::uintptr_t UpdateDisabledMovementVerticalVelocity = 0x3F8AF80; // "private void UpdateDisabledMovementVerticalVelocity(CharacterControllerModel character, PhysicsDebugBattleCharacterTickData physicsDebug)"
            inline constexpr std::uintptr_t UpdateGroundMovementVerticalVelocity = 0x3F8AF80; // "private void UpdateGroundMovementVerticalVelocity(CharacterControllerModel character, PhysicsDebugBattleCharacterTickData physicsDebug)"
            inline constexpr std::uintptr_t UpdateSwimmingMovementVerticalVelocity = 0x3F8AF80; // "private void UpdateSwimmingMovementVerticalVelocity(CharacterControllerModel character, PhysicsDebugBattleCharacterTickData physicsDebug)"
            inline constexpr std::uintptr_t UpdateAirMovementVerticalVelocity = 0x3F8ACE0; // "private void UpdateAirMovementVerticalVelocity(CharacterControllerModel character, BattleCharacterDamageZoneModel battleCharacterDamageZone, PhysicsDebugBattleCharacterTickData physicsDebug)"
            inline constexpr std::uintptr_t UpdateStartJumpMovementVerticalVelocity = 0x3F8AFB0; // "private void UpdateStartJumpMovementVerticalVelocity(CharacterControllerModel character, float jumpStartVelocityY, PhysicsDebugBattleCharacterTickData physicsDebug)"
            inline constexpr std::uintptr_t RecalculateAirVelocityYByGravity = 0x3F8A5B0; // "private void RecalculateAirVelocityYByGravity(CharacterControllerModel character, float gravity, float oldAirVelocityY, out float newAirVelocityY, out float newAirIntegratedVelocityY)"
            inline constexpr std::uintptr_t TryRecalculateAirVelocityYForWaterSoftCollision = 0x3F8A9A0; // "private bool TryRecalculateAirVelocityYForWaterSoftCollision(CharacterControllerModel character, float gravity, float airVelocityY, float airIntegratedVelocityY, out float newAirVelocityY, out float newAirIntegratedVelocityY)"
            inline constexpr std::uintptr_t RecalculateAirVelocityYByDamageZone = 0x3F8A510; // "private void RecalculateAirVelocityYByDamageZone(BattleCharacterDamageZoneModel battleCharacterDamageZone, float airVelocityY, float airIntegratedVelocityY, out float newAirVelocityY, out float newAirIntegratedVelocityY)"
            inline constexpr std::uintptr_t SetAirVelocityY = 0x3F8A640; // "private void SetAirVelocityY(CharacterControllerModel character, float airVelocityY, float airIntegratedVelocityY, bool waterSoftCollisionCorrection, PhysicsDebugBattleCharacterTickData physicsDebug)"
            inline constexpr std::uintptr_t WriteVelocityDataToDebug = 0x3F8B0A0; // "private static void WriteVelocityDataToDebug(PhysicsDebugBattleCharacterTickData physicsDebug, CharacterMovementType movementType, float airVelocityY, float airIntegratedVelocityY)"
            inline constexpr std::uintptr_t WriteVerticalVelocityChangeEventDataToDebug = 0x3F8B0C0; // "private static void WriteVerticalVelocityChangeEventDataToDebug(PhysicsDebugBattleCharacterTickData physicsDebug, ref CharacterControllerAirVelocityYChangedEvent eventData)"
        }
    } // namespace CharacterControllerExtraVerticalVelocitySystem

    namespace CharacterControllerForwardMovementClearSystem { // "Models.Systems.CharacterControllerForwardMovementClearSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t scene = 0x38; // "PhysicsSceneModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x3F8B190; // "protected override void Tick(ITick tick)"
        }
    } // namespace CharacterControllerForwardMovementClearSystem

    namespace CharacterControllerForwardMovementSystem { // "Models.Systems.CharacterControllerForwardMovementSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t scene = 0x38; // "PhysicsSceneModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x3F8B2B0; // "protected override void Tick(ITick tick)"
        }
    } // namespace CharacterControllerForwardMovementSystem

    namespace CharacterControllerGroundAndWaterCheckBySphereCastSystem { // "Models.Systems.CharacterControllerGroundAndWaterCheckBySphereCastSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsSceneModel = 0x38; // "PhysicsSceneModel"
            inline constexpr std::uintptr_t tickDeltaTime = 0x40; // "float"
            inline constexpr std::uintptr_t sphereCastModel = 0x48; // "SphereCastModel"
            inline constexpr std::uintptr_t physicsBodiesModel = 0x50; // "PhysicsBodiesModel"
            inline constexpr std::uintptr_t physicsDebugEnabledModel = 0x58; // "PhysicsDebugEnabledModel"
            inline constexpr std::uintptr_t physicsDebugModel = 0x60; // "IPhysicsDebugModel"
            inline constexpr std::uintptr_t sphereCastResult = 0x68; // "SphereCastResult"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x3F8B9D0; // "protected override void Tick(ITick tick)"
            inline constexpr std::uintptr_t GetCastLength = 0x3F8B650; // "private float GetCastLength(CharacterControllerModel character, float castRadius)"
            inline constexpr std::uintptr_t GetGroundedCastLength = 0x3F8B970; // "private float GetGroundedCastLength(CharacterControllerModel character, float castRadius)"
            inline constexpr std::uintptr_t GetFallingCastLength = 0x3F8B880; // "private float GetFallingCastLength(CharacterControllerModel character, float castRadius)"
            inline constexpr std::uintptr_t WriteStateToDebug = 0x3F8C150; // "private static void WriteStateToDebug(PhysicsDebugBattleCharacterGroundAndWaterCheckBySphereCastTickData physicsDebug, CharacterControllerStateDescription characterState, bool isGroundAndWaterCheckState)"
            inline constexpr std::uintptr_t WriteSphereCastDataToDebug = 0x3F8C100; // "private static void WriteSphereCastDataToDebug(PhysicsDebugBattleCharacterGroundAndWaterCheckBySphereCastTickData physicsDebug, in Vector3 sphereCastFrom, in Vector3 sphereCastDirection, float sphereCastLengthDefault, float sphereCastRadiusDefault, float sphereCastLengthVsCharacter, float sphereCastRadiusVsCharacter)"
            inline constexpr std::uintptr_t WriteWaterResultToDebug = 0x3F8C190; // "private static void WriteWaterResultToDebug(PhysicsDebugBattleCharacterGroundAndWaterCheckBySphereCastTickData physicsDebug, in SphereCastHit hit, float waterSurfacePlaneDistance)"
            inline constexpr std::uintptr_t WriteGroundResultToDebug = 0x3F8C0C0; // "private static void WriteGroundResultToDebug(PhysicsDebugBattleCharacterGroundAndWaterCheckBySphereCastTickData physicsDebug, in SphereCastHit hit)"
        }
    } // namespace CharacterControllerGroundAndWaterCheckBySphereCastSystem

    namespace CharacterControllerGroundModel { // "Models.Models.CharacterControllerGround.CharacterControllerGroundModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t groundSurfaceType = 0x10; // "IPrimitiveData<byte>"
            inline constexpr std::uintptr_t GroundFound = 0x18; // "bool"
            inline constexpr std::uintptr_t GroundPoint = 0x1C; // "Vector3"
            inline constexpr std::uintptr_t GroundNormal = 0x28; // "Vector3"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_GroundSurfaceType = 0x4976720; // "public byte get_GroundSurfaceType()"
            inline constexpr std::uintptr_t Update = 0x4976690; // "public void Update(bool groundFound, Vector3 groundPoint, Vector3 groundNormal, byte groundSurfaceType)"
            inline constexpr std::uintptr_t Clear = 0x4976640; // "public void Clear()"
        }
    } // namespace CharacterControllerGroundModel

    namespace CharacterControllerHeightAboveWaterSystem { // "Models.Systems.CharacterControllerHeightAboveWaterSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsSceneModel = 0x38; // "PhysicsSceneModel"
            inline constexpr std::uintptr_t physicsDebugEnabledModel = 0x40; // "PhysicsDebugEnabledModel"
            inline constexpr std::uintptr_t physicsDebugModel = 0x48; // "IPhysicsDebugModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x3F8C2F0; // "protected override void Tick(ITick tick)"
            inline constexpr std::uintptr_t WriteWaterFoundToDebug = 0x3F8CAD0; // "private static void WriteWaterFoundToDebug(PhysicsDebugBattleCharacterHeightAboveWaterTickData physicsDebug, CharacterControllerModel character)"
            inline constexpr std::uintptr_t WritePhysicsStateToDebug = 0x3F8C9E0; // "private static void WritePhysicsStateToDebug(PhysicsDebugBattleCharacterHeightAboveWaterTickData physicsDebug, PhysicsSceneModel physicsSceneModel, CharacterControllerModel character)"
            inline constexpr std::uintptr_t WriteCharacterCapsuleStateToDebug = 0x3F8C850; // "private static void WriteCharacterCapsuleStateToDebug(PhysicsDebugBattleCharacterHeightAboveWaterTickData physicsDebug, CharacterControllerModel character)"
            inline constexpr std::uintptr_t WriteCharacterHeightAboveWaterToDebug = 0x3F8C8A0; // "private static void WriteCharacterHeightAboveWaterToDebug(PhysicsDebugBattleCharacterHeightAboveWaterTickData physicsDebug, CharacterControllerModel character, float characterTopPointY, float characterHeightAboveWater)"
            inline constexpr std::uintptr_t WriteDeepWaterByCrouchToDebug = 0x3F8C900; // "private static void WriteDeepWaterByCrouchToDebug(PhysicsDebugBattleCharacterHeightAboveWaterTickData physicsDebug, CharacterControllerModel character, float characterHeightAboveWater)"
            inline constexpr std::uintptr_t WriteDeepWaterByKnockoutToDebug = 0x3F8C9D0; // "private static void WriteDeepWaterByKnockoutToDebug(PhysicsDebugBattleCharacterHeightAboveWaterTickData physicsDebug)"
            inline constexpr std::uintptr_t WriteResultToDebug = 0x3F8CAB0; // "private static void WriteResultToDebug(PhysicsDebugBattleCharacterHeightAboveWaterTickData physicsDebug, CharacterControllerModel character)"
        }
    } // namespace CharacterControllerHeightAboveWaterSystem

    namespace CharacterControllerImpulseVelocitySystem { // "Models.Systems.CharacterControllerImpulseVelocitySystem (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x3F8CBA0; // "protected override void Tick(ITick tick)"
        }
    } // namespace CharacterControllerImpulseVelocitySystem

    namespace CharacterControllerInputSystem { // "Models.Systems.CharacterControllerInputSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsDebugEnabledModel = 0x38; // "PhysicsDebugEnabledModel"
            inline constexpr std::uintptr_t physicsDebugModel = 0x40; // "IPhysicsDebugModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x3F8D090; // "protected override void Tick(ITick tick)"
            inline constexpr std::uintptr_t WriteInputToDebug = 0x3F8D4D0; // "private static void WriteInputToDebug(PhysicsDebugBattleCharacterTickData physicsDebug, in Vector2 moveInput, in Vector3 lookInput)"
        }
    } // namespace CharacterControllerInputSystem

    namespace CharacterControllerInputVelocitySystem { // "Models.Systems.CharacterControllerInputVelocitySystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t tickDeltaTime = 0x38; // "float"
            inline constexpr std::uintptr_t physicsDebugEnabledModel = 0x40; // "PhysicsDebugEnabledModel"
            inline constexpr std::uintptr_t physicsDebugModel = 0x48; // "IPhysicsDebugModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x3F8E560; // "protected override void Tick(ITick tick)"
            inline constexpr std::uintptr_t UpdateLastInputVelocity = 0x3F8F490; // "private static void UpdateLastInputVelocity(CharacterControllerModel character, IEventModel groundedEvent, PhysicsDebugCharacterControllerInputVelocitySystemTickData physicsDebug)"
            inline constexpr std::uintptr_t UpdateDisabledMovementInputVelocity = 0x3F8ED40; // "private static void UpdateDisabledMovementInputVelocity(CharacterControllerModel character, PhysicsDebugCharacterControllerInputVelocitySystemTickData physicsDebug)"
            inline constexpr std::uintptr_t UpdateGroundMovementWithoutInertiaInputVelocity = 0x3F8F0B0; // "private static void UpdateGroundMovementWithoutInertiaInputVelocity(CharacterControllerModel character, MoveSpeedModel moveSpeedModel, float velocityModifier, PhysicsDebugCharacterControllerInputVelocitySystemTickData physicsDebug)"
            inline constexpr std::uintptr_t UpdateGroundMovementInputVelocity = 0x3F8EE60; // "private static void UpdateGroundMovementInputVelocity(CharacterControllerModel character, MoveSpeedModel moveSpeedModel, float velocityModifier, float dt, PhysicsDebugCharacterControllerInputVelocitySystemTickData physicsDebug)"
            inline constexpr std::uintptr_t UpdateSwimmingMovementWithoutInertiaInputVelocity = 0x3F8F900; // "private static void UpdateSwimmingMovementWithoutInertiaInputVelocity(CharacterControllerModel character, MoveSpeedModel moveSpeedModel, float velocityModifier, PhysicsDebugCharacterControllerInputVelocitySystemTickData physicsDebug)"
            inline constexpr std::uintptr_t UpdateSwimmingMovementInputVelocity = 0x3F8F6D0; // "private static void UpdateSwimmingMovementInputVelocity(CharacterControllerModel character, MoveSpeedModel moveSpeedModel, float velocityModifier, float dt, PhysicsDebugCharacterControllerInputVelocitySystemTickData physicsDebug)"
            inline constexpr std::uintptr_t UpdateAirMovementInputVelocity = 0x3F8E890; // "private static void UpdateAirMovementInputVelocity(CharacterControllerModel character, PhysicsDebugCharacterControllerInputVelocitySystemTickData physicsDebug)"
            inline constexpr std::uintptr_t UpdateBunnyHopMovementInputVelocity = 0x3F8EB30; // "private static void UpdateBunnyHopMovementInputVelocity(CharacterControllerModel character, MoveSpeedModel moveSpeedModel, float velocityModifier, float dt, PhysicsDebugCharacterControllerInputVelocitySystemTickData physicsDebug)"
            inline constexpr std::uintptr_t CalculateGroundMovementInputVelocityBasis = 0x3F8D970; // "private static void CalculateGroundMovementInputVelocityBasis(in Vector3 lookInput, in Vector3 groundNormal, out Vector3 velocityBasisX, out Vector3 velocityBasisY, out Vector3 velocityBasisZ)"
            inline constexpr std::uintptr_t CalculateFlatMovementInputVelocityBasis = 0x3F8D7A0; // "private static void CalculateFlatMovementInputVelocityBasis(in Vector3 lookInput, out Vector3 velocityBasisX, out Vector3 velocityBasisY, out Vector3 velocityBasisZ)"
            inline constexpr std::uintptr_t CalculateDisabledMovementInputVelocity = 0x3F8D760; // "private static void CalculateDisabledMovementInputVelocity(out Vector3 velocityDirection, out float velocityMagnitude)"
            inline constexpr std::uintptr_t CalculateInertiaMovementInputVelocity = 0x3F8DC80; // "private static void CalculateInertiaMovementInputVelocity(in Vector2 moveInput, MoveSpeedModel moveSpeedModel, float velocityModifier, in Vector3 lastVelocity, float velocityChangeMaxSpeedXPerTick, float velocityChangeMaxSpeedZPerTick, in Vector3 velocityBasisX, in Vector3 velocityBasisY, in Vector3 velocityBasisZ, PhysicsDebugCharacterControllerInputVelocitySystemTickData physicsDebug, out Vector3 velocityDirection, out float velocityMagnitude)"
            inline constexpr std::uintptr_t CalculateSimpleMovementInputVelocity = 0x3F8E350; // "private static void CalculateSimpleMovementInputVelocity(in Vector2 moveInput, MoveSpeedModel moveSpeedModel, float velocityModifier, in Vector3 velocityBasisX, in Vector3 velocityBasisZ, out Vector3 velocityDirection, out float velocityMagnitude)"
            inline constexpr std::uintptr_t CalculateAirMovementInputVelocity = 0x3F8D580; // "private static void CalculateAirMovementInputVelocity(in Vector2 moveInput, in Vector3 velocityBasisX, in Vector3 velocityBasisZ, out Vector3 velocityDirection, out float velocityMagnitude)"
            inline constexpr std::uintptr_t WriteCharacterMovementStateToDebug = 0x3F8FCB0; // "private static void WriteCharacterMovementStateToDebug(PhysicsDebugCharacterControllerInputVelocitySystemTickData physicsDebug, CharacterControllerModel character)"
            inline constexpr std::uintptr_t WriteLastInputVelocityUpdateToDebug = 0x3F8FCE0; // "private static void WriteLastInputVelocityUpdateToDebug(PhysicsDebugCharacterControllerInputVelocitySystemTickData physicsDebug, in Vector3 lastInputVelocityBeforeUpdate, in Vector3 lastInputVelocityAfterUpdate)"
            inline constexpr std::uintptr_t WriteVelocityBasisToDebug = 0x3F8FD30; // "private static void WriteVelocityBasisToDebug(PhysicsDebugCharacterControllerInputVelocitySystemTickData physicsDebug, in Vector3 velocityBasisX, in Vector3 velocityBasisY, in Vector3 velocityBasisZ)"
            inline constexpr std::uintptr_t WriteTargetVelocityDataToDebug = 0x3F8FD10; // "private static void WriteTargetVelocityDataToDebug(PhysicsDebugCharacterControllerInputVelocitySystemTickData physicsDebug, in Vector3 targetInputVelocityDirection, float targetInputVelocityMagnitude)"
            inline constexpr std::uintptr_t WriteVelocityDataToDebug = 0x3F8FD70; // "private static void WriteVelocityDataToDebug(PhysicsDebugCharacterControllerInputVelocitySystemTickData physicsDebug, CharacterControllerModel character)"
        }
    } // namespace CharacterControllerInputVelocitySystem

    namespace CharacterControllerModel { // "Models.Models.CharacterController.CharacterControllerModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t bodyIdModel = 0x10; // "BodyIdModel"
            inline constexpr std::uintptr_t capsuleColliderParams = 0x18; // "ICapsuleColliderParamsModel"
            inline constexpr std::uintptr_t state = 0x20; // "IPrimitiveModel<CharacterControllerStateDescription>"
            inline constexpr std::uintptr_t characterControllerGround = 0x28; // "CharacterControllerGroundModel"
            inline constexpr std::uintptr_t characterControllerWater = 0x30; // "CharacterControllerWaterModel"
            inline constexpr std::uintptr_t groundConstraintsModel = 0x38; // "GroundConstraintsModel"
            inline constexpr std::uintptr_t waterConstraintsModel = 0x40; // "WaterConstraintsModel"
            inline constexpr std::uintptr_t data = 0x48; // "CharacterControllerData"
            inline constexpr std::uintptr_t Config = 0x50; // "PhysicsCharacterConfig"
            inline constexpr std::uintptr_t HeightAboveWater = 0x58; // "float"
            inline constexpr std::uintptr_t ForwardMovementConstraintContains = 0x5C; // "bool"
            inline constexpr std::uintptr_t ForwardMovementConstraintId1 = 0x60; // "int"
            inline constexpr std::uintptr_t ForwardMovementConstraintId2 = 0x64; // "int"
            inline constexpr std::uintptr_t MoveInput = 0x68; // "Vector2"
            inline constexpr std::uintptr_t LookInput = 0x70; // "Vector3"
            inline constexpr std::uintptr_t InputVelocityDirection = 0x7C; // "Vector3"
            inline constexpr std::uintptr_t InputVelocityMagnitude = 0x88; // "float"
            inline constexpr std::uintptr_t AirIntegratedVelocityY = 0x8C; // "float"
            inline constexpr std::uintptr_t AirControlIntegratedVelocityX = 0x90; // "float"
            inline constexpr std::uintptr_t AirControlIntegratedVelocityZ = 0x94; // "float"
            inline constexpr std::uintptr_t ImpulseVelocity = 0x98; // "Vector3"
            inline constexpr std::uintptr_t JumpEvent = 0xA4; // "bool"
            inline constexpr std::uintptr_t CharacterMovementType = 0xA8; // "CharacterMovementType"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_BodyId = 0xC52AE0; // "public PhysicsBodyId get_BodyId()"
            inline constexpr std::uintptr_t get_State = 0x4977280; // "public CharacterControllerStateDescription get_State()"
            inline constexpr std::uintptr_t SetState = 0x4976A60; // "public void SetState(CharacterControllerStateDescription state)"
            inline constexpr std::uintptr_t get_CapsuleColliderRadius = 0x4976F10; // "public float get_CapsuleColliderRadius()"
            inline constexpr std::uintptr_t get_CapsuleColliderLength = 0x4976EC0; // "public float get_CapsuleColliderLength()"
            inline constexpr std::uintptr_t get_CapsuleColliderDistanceToGround = 0x4976E70; // "public float get_CapsuleColliderDistanceToGround()"
            inline constexpr std::uintptr_t SetCapsuleColliderParams = 0x4976920; // "public void SetCapsuleColliderParams(float radius, float length, float distanceToGround)"
            inline constexpr std::uintptr_t get_GroundFound = 0x4976FA0; // "public bool get_GroundFound()"
            inline constexpr std::uintptr_t get_GroundPoint = 0x4976FF0; // "public Vector3 get_GroundPoint()"
            inline constexpr std::uintptr_t get_GroundNormal = 0x4976FC0; // "public Vector3 get_GroundNormal()"
            inline constexpr std::uintptr_t get_GroundSurfaceType = 0x4977020; // "public byte get_GroundSurfaceType()"
            inline constexpr std::uintptr_t UpdateGround = 0x4976C00; // "public void UpdateGround(bool groundFound, Vector3 groundPoint, Vector3 groundNormal, byte groundSurfaceType)"
            inline constexpr std::uintptr_t ClearGround = 0x49767A0; // "public void ClearGround()"
            inline constexpr std::uintptr_t get_GroundConstraintContains = 0x4976F60; // "public bool get_GroundConstraintContains()"
            inline constexpr std::uintptr_t get_GroundConstraintId = 0x4976F80; // "public int get_GroundConstraintId()"
            inline constexpr std::uintptr_t SetGroundConstraint = 0x4976A20; // "public void SetGroundConstraint(int id)"
            inline constexpr std::uintptr_t ClearGroundConstraint = 0x4976780; // "public void ClearGroundConstraint()"
            inline constexpr std::uintptr_t SetHeightAboveWater = 0x900920; // "public void SetHeightAboveWater(float heightAboveWater)"
            inline constexpr std::uintptr_t get_WaterFound = 0x49773D0; // "public bool get_WaterFound()"
            inline constexpr std::uintptr_t get_WaterZoneSurfacePlaneDistance = 0x4977460; // "public float get_WaterZoneSurfacePlaneDistance()"
            inline constexpr std::uintptr_t SetWater = 0x4976BD0; // "public void SetWater(float waterZoneSurfacePlaneDistance)"
            inline constexpr std::uintptr_t ClearWater = 0x4976890; // "public void ClearWater()"
            inline constexpr std::uintptr_t get_WaterFoundBySphereCast = 0x49773B0; // "public bool get_WaterFoundBySphereCast()"
            inline constexpr std::uintptr_t get_WaterZoneEntityIdBySphereCast = 0x4977440; // "public int get_WaterZoneEntityIdBySphereCast()"
            inline constexpr std::uintptr_t SetWaterBySphereCast = 0x4976B90; // "public void SetWaterBySphereCast(int waterZoneEntityId)"
            inline constexpr std::uintptr_t ClearWaterBySphereCast = 0x4976850; // "public void ClearWaterBySphereCast()"
            inline constexpr std::uintptr_t get_WaterFoundByCollision = 0x4977360; // "public bool get_WaterFoundByCollision()"
            inline constexpr std::uintptr_t get_WaterZoneEntityIdByCollision = 0x49773F0; // "public int get_WaterZoneEntityIdByCollision()"
            inline constexpr std::uintptr_t SetWaterByCollision = 0x4976B30; // "public void SetWaterByCollision(int waterZoneEntityId)"
            inline constexpr std::uintptr_t ClearWaterByCollision = 0x4976800; // "public void ClearWaterByCollision()"
            inline constexpr std::uintptr_t get_WaterConstraintContains = 0x4977320; // "public bool get_WaterConstraintContains()"
            inline constexpr std::uintptr_t get_WaterConstraintId = 0x4977340; // "public int get_WaterConstraintId()"
            inline constexpr std::uintptr_t SetWaterConstraint = 0x4976BB0; // "public void SetWaterConstraint(int id)"
            inline constexpr std::uintptr_t ClearWaterConstraint = 0x4976870; // "public void ClearWaterConstraint()"
            inline constexpr std::uintptr_t SetForwardMovementConstraint = 0x4976A10; // "public void SetForwardMovementConstraint(int id1, int id2)"
            inline constexpr std::uintptr_t ClearForwardMovementConstraint = 0x4976770; // "public void ClearForwardMovementConstraint()"
            inline constexpr std::uintptr_t SetInput = 0x4976A40; // "public void SetInput(Vector2 move, Vector3 look)"
            inline constexpr std::uintptr_t get_LastInputVelocityX = 0x4977070; // "public float get_LastInputVelocityX()"
            inline constexpr std::uintptr_t set_LastInputVelocityX = 0x49775F0; // "public void set_LastInputVelocityX(float value)"
            inline constexpr std::uintptr_t get_LastInputVelocityY = 0x49770C0; // "public float get_LastInputVelocityY()"
            inline constexpr std::uintptr_t set_LastInputVelocityY = 0x4977650; // "public void set_LastInputVelocityY(float value)"
            inline constexpr std::uintptr_t get_LastInputVelocityZ = 0x4977110; // "public float get_LastInputVelocityZ()"
            inline constexpr std::uintptr_t set_LastInputVelocityZ = 0x49776B0; // "public void set_LastInputVelocityZ(float value)"
            inline constexpr std::uintptr_t get_LastInputVelocity = 0x4977160; // "public Vector3 get_LastInputVelocity()"
            inline constexpr std::uintptr_t set_LastInputVelocity = 0x4977710; // "public void set_LastInputVelocity(Vector3 value)"
            inline constexpr std::uintptr_t get_AirVelocityY = 0x4976E20; // "public float get_AirVelocityY()"
            inline constexpr std::uintptr_t set_AirVelocityY = 0x4977560; // "public void set_AirVelocityY(float value)"
            inline constexpr std::uintptr_t get_AirControlVelocityX = 0x4976D80; // "public float get_AirControlVelocityX()"
            inline constexpr std::uintptr_t set_AirControlVelocityX = 0x4977480; // "public void set_AirControlVelocityX(float value)"
            inline constexpr std::uintptr_t get_AirControlVelocityZ = 0x4976DD0; // "public float get_AirControlVelocityZ()"
            inline constexpr std::uintptr_t set_AirControlVelocityZ = 0x49774F0; // "public void set_AirControlVelocityZ(float value)"
            inline constexpr std::uintptr_t IntegrateVelocity = 0x49768C0; // "public void IntegrateVelocity(float oldVelocity, float acceleration, float dt, out float newVelocity, out float newIntegratedVelocity)"
            inline constexpr std::uintptr_t RecalculateVelocityByIntegratedVelocity = 0x49768F0; // "public void RecalculateVelocityByIntegratedVelocity(float integratedVelocity, float acceleration, float dt, out float newVelocity, out float newIntegratedVelocity)"
            inline constexpr std::uintptr_t get_StuckInFallingStateCounter = 0x49772D0; // "public byte get_StuckInFallingStateCounter()"
            inline constexpr std::uintptr_t set_StuckInFallingStateCounter = 0x49777F0; // "public void set_StuckInFallingStateCounter(byte value)"
        }
    } // namespace CharacterControllerModel

    namespace CharacterControllerMovementTypeSystem { // "Models.Systems.CharacterControllerMovementTypeSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsDebugEnabledModel = 0x38; // "PhysicsDebugEnabledModel"
            inline constexpr std::uintptr_t physicsDebugModel = 0x40; // "IPhysicsDebugModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x3F90090; // "protected override void Tick(ITick tick)"
            inline constexpr std::uintptr_t GetCharacterMovementType = 0x3F8FE60; // "private CharacterMovementType GetCharacterMovementType(CharacterControllerModel character, IEventModel groundedEvent)"
            inline constexpr std::uintptr_t WriteMovementTypeToDebug = 0x3F901A0; // "private static void WriteMovementTypeToDebug(PhysicsDebugBattleCharacterTickData physicsDebug, CharacterMovementType movementType)"
        }
    } // namespace CharacterControllerMovementTypeSystem

    namespace CharacterControllerStartJumpSystem { // "Models.Systems.CharacterControllerStartJumpSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsSceneModel = 0x38; // "PhysicsSceneModel"
            inline constexpr std::uintptr_t sphereCastModel = 0x40; // "SphereCastModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x3F906A0; // "protected override void Tick(ITick tick)"
            inline constexpr std::uintptr_t IsFreeSpaceAbove = 0x3F90340; // "private bool IsFreeSpaceAbove(CharacterControllerModel character)"
            inline constexpr std::uintptr_t CalculateCastParams = 0x3F90230; // "private ValueTuple<float, float, float> CalculateCastParams(PhysicsCharacterConfig config, float capsuleLength, float capsuleRadius)"
            inline constexpr std::uintptr_t IsJumpBlockedByDamageZone = 0x3F90650; // "private bool IsJumpBlockedByDamageZone(BattleCharacterDamageZoneModel battleCharacterDamageZone)"
            inline constexpr std::uintptr_t ClearEvents = 0x3F90320; // "private void ClearEvents(CharacterControllerModel character)"
        }
    } // namespace CharacterControllerStartJumpSystem

    namespace CharacterControllerStateByGroundAndWaterSystem { // "Models.Systems.CharacterControllerStateByGroundAndWaterSystem (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x3F90C60; // "protected override void Tick(ITick tick)"
            inline constexpr std::uintptr_t GetNewState = 0x3F90940; // "private CharacterControllerStateDescription GetNewState(CharacterControllerModel character)"
        }
    } // namespace CharacterControllerStateByGroundAndWaterSystem

    namespace CharacterControllerStateDescription { // "Models.References.Character.CharacterControllerStateDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x81B2F88; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t enum_id = 0x0; // "Enum<CharacterControllerStateDescription>"
            inline constexpr std::uintptr_t Disabled = 0x8; // "CharacterControllerStateDescription"
            inline constexpr std::uintptr_t Falling = 0x10; // "CharacterControllerStateDescription"
            inline constexpr std::uintptr_t Grounded = 0x18; // "CharacterControllerStateDescription"
            inline constexpr std::uintptr_t Rising = 0x20; // "CharacterControllerStateDescription"
            inline constexpr std::uintptr_t Swimming = 0x28; // "CharacterControllerStateDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Enum = 0x446A740; // "public static ReadOnlyEnum<CharacterControllerStateDescription> get_Enum()"
        }
    } // namespace CharacterControllerStateDescription

    namespace CharacterControllerStateInAirSystem { // "Models.Systems.CharacterControllerStateInAirSystem (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x3F910D0; // "protected override void Tick(ITick tick)"
            inline constexpr std::uintptr_t GetNewState = 0x3F90F30; // "private CharacterControllerStateDescription GetNewState(CharacterControllerStateDescription oldState, float airVelocityY)"
        }
    } // namespace CharacterControllerStateInAirSystem

    namespace CharacterControllerStickToGroundClearSystem { // "Models.Systems.CharacterControllerStickToGroundClearSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t scene = 0x38; // "PhysicsSceneModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x40F12E0; // "protected override void Tick(ITick tick)"
        }
    } // namespace CharacterControllerStickToGroundClearSystem

    namespace CharacterControllerStickToGroundSystem { // "Models.Systems.CharacterControllerStickToGroundSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t scene = 0x38; // "PhysicsSceneModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x40F13D0; // "protected override void Tick(ITick tick)"
        }
    } // namespace CharacterControllerStickToGroundSystem

    namespace CharacterControllerStickToWaterClearSystem { // "Models.Systems.CharacterControllerStickToWaterClearSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t scene = 0x38; // "PhysicsSceneModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x40F12E0; // "protected override void Tick(ITick tick)"
        }
    } // namespace CharacterControllerStickToWaterClearSystem

    namespace CharacterControllerStickToWaterSystem { // "Models.Systems.CharacterControllerStickToWaterSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsSceneModel = 0x38; // "PhysicsSceneModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x40F1B50; // "protected override void Tick(ITick tick)"
        }
    } // namespace CharacterControllerStickToWaterSystem

    namespace CharacterControllerStuckExtensions { // "Models.CharacterController.CharacterControllerStuckExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t IsStuckInFalling = 0x4ADA890; // "public static bool IsStuckInFalling(CharacterControllerModel character)"
        }
    } // namespace CharacterControllerStuckExtensions

    namespace CharacterControllerStuckInFallingSystem { // "Models.Systems.CharacterControllerStuckInFallingSystem (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x40F1FE0; // "protected override void Tick(ITick tick)"
        }
    } // namespace CharacterControllerStuckInFallingSystem

    namespace CharacterControllerVelocityExtensions { // "Models.CharacterController.CharacterControllerVelocityExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t CalculateVelocityModifier = 0x4ADA8D0; // "public static float CalculateVelocityModifier(DamageZoneEffectDescription damageZoneEffect)"
        }
    } // namespace CharacterControllerVelocityExtensions

    namespace CharacterControllerVerticalExtraVelocityChangedSystem { // "Models.Systems.CharacterControllerVerticalExtraVelocityChangedSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsBodiesModel = 0x10; // "PhysicsBodiesModel"
            inline constexpr std::uintptr_t airVelocityYChangeEvents = 0x18; // "IEventsSet<CharacterControllerAirVelocityYChangedEvent>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x40F2840; // "public void Update(ITick tick)"
            inline constexpr std::uintptr_t HandleEvent = 0x40F2550; // "private static void HandleEvent(BattleCharacterModel battleCharacterModel, ref CharacterControllerAirVelocityYChangedEvent eventData)"
            inline constexpr std::uintptr_t FallDamageHandle = 0x40F2250; // "private static void FallDamageHandle(BattleCharacterModel battleCharacterModel, ref CharacterControllerAirVelocityYChangedEvent eventData)"
            inline constexpr std::uintptr_t TryStartTrackFallDamage = 0x40F2560; // "private static void TryStartTrackFallDamage(BattleCharacterModel battleCharacterModel, ref CharacterControllerAirVelocityYChangedEvent eventData)"
            inline constexpr std::uintptr_t TryStopTrackFallDamage = 0x40F26D0; // "private static void TryStopTrackFallDamage(BattleCharacterModel battleCharacterModel, ref CharacterControllerAirVelocityYChangedEvent eventData)"
        }
    } // namespace CharacterControllerVerticalExtraVelocityChangedSystem

    namespace CharacterControllerWaterCheckByCollisionsSystem { // "Models.Systems.CharacterControllerWaterCheckByCollisionsSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsSceneModel = 0x38; // "PhysicsSceneModel"
            inline constexpr std::uintptr_t worldWaterZones = 0x40; // "IWorldWaterZonesModel"
            inline constexpr std::uintptr_t worldTickData = 0x48; // "WorldTickData"
            inline constexpr std::uintptr_t physicsDebugEnabledModel = 0x50; // "PhysicsDebugEnabledModel"
            inline constexpr std::uintptr_t physicsDebugModel = 0x58; // "IPhysicsDebugModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x40F2BD0; // "protected override void Tick(ITick tick)"
            inline constexpr std::uintptr_t WriteStateToDebug = 0x3F8C150; // "private static void WriteStateToDebug(PhysicsDebugBattleCharacterWaterCheckByCollisionsTickData physicsDebug, CharacterControllerStateDescription characterState, bool isWaterCheckState)"
            inline constexpr std::uintptr_t WritePhysicsStateToDebug = 0x40F2F00; // "private static void WritePhysicsStateToDebug(PhysicsDebugBattleCharacterWaterCheckByCollisionsTickData physicsDebug, PhysicsSceneModel physicsSceneModel, PhysicsBodyId bodyId)"
            inline constexpr std::uintptr_t WriteResultToDebug = 0x40F2FC0; // "private static void WriteResultToDebug(PhysicsDebugBattleCharacterWaterCheckByCollisionsTickData physicsDebug, int waterEntityId, float waterSurfacePlaneDistance)"
        }
    } // namespace CharacterControllerWaterCheckByCollisionsSystem

    namespace CharacterControllerWaterExtensions { // "Models.CharacterController.CharacterControllerWaterExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t CalculateExpectedCharacterHeightAboveWaterForGroundedState = 0x4ADA920; // "public static float CalculateExpectedCharacterHeightAboveWaterForGroundedState(in Vector3 characterBodyPosition, float groundedCharacterDistanceToGround, float groundedCharacterRadius, float groundedCharacterLength, in Vector3 groundPoint, in Vector3 groundNormal, float waterZoneSurfacePlaneDistance)"
            inline constexpr std::uintptr_t CalculateMaxExpectedCharacterHeightAboveWaterForGroundedState = 0x4ADAAD0; // "public static float CalculateMaxExpectedCharacterHeightAboveWaterForGroundedState(float groundSurfaceMinCos, float groundedCharacterLength, float groundedCharacterCapsuleLength, float groundedCharacterCapsuleRadius, float groundedCharacterCapsuleDistanceToGround, float swimmingStateCharacterHeightAboveWater)"
        }
    } // namespace CharacterControllerWaterExtensions

    namespace CharacterControllerWaterModel { // "Models.Models.CharacterControllerWater.CharacterControllerWaterModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t waterZoneEntityIdByCollision = 0x10; // "BattleEntityIdData"
            inline constexpr std::uintptr_t Found = 0x18; // "bool"
            inline constexpr std::uintptr_t WaterZoneSurfacePlaneDistance = 0x1C; // "float"
            inline constexpr std::uintptr_t WaterZoneEntityIdBySphereCast = 0x20; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Set = 0x49778F0; // "public void Set(float waterZoneSurfacePlaneDistance)"
            inline constexpr std::uintptr_t Clear = 0x4977890; // "public void Clear()"
            inline constexpr std::uintptr_t get_FoundBySphereCast = 0x4977950; // "public bool get_FoundBySphereCast()"
            inline constexpr std::uintptr_t SetBySphereCast = 0x837DF0; // "public void SetBySphereCast(int waterZoneEntityId)"
            inline constexpr std::uintptr_t ClearBySphereCast = 0x18FB190; // "public void ClearBySphereCast()"
            inline constexpr std::uintptr_t get_FoundByCollision = 0x4977900; // "public bool get_FoundByCollision()"
            inline constexpr std::uintptr_t get_WaterZoneEntityIdByCollision = 0x4977960; // "public int get_WaterZoneEntityIdByCollision()"
            inline constexpr std::uintptr_t SetByCollision = 0x49778A0; // "public void SetByCollision(int waterZoneEntityId)"
            inline constexpr std::uintptr_t ClearByCollision = 0x4977850; // "public void ClearByCollision()"
        }
    } // namespace CharacterControllerWaterModel

    namespace CharacterControllerWaterSystem { // "Models.Systems.CharacterControllerWaterSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t worldEntitiesModel = 0x38; // "WorldEntitiesModel"
            inline constexpr std::uintptr_t physicsDebugEnabledModel = 0x40; // "PhysicsDebugEnabledModel"
            inline constexpr std::uintptr_t physicsDebugModel = 0x48; // "IPhysicsDebugModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x40F30A0; // "protected override void Tick(ITick tick)"
            inline constexpr std::uintptr_t TryGetWater = 0x40F3200; // "private bool TryGetWater(CharacterControllerModel character, PhysicsDebugBattleCharacterWaterTickData physicsDebug, out float waterSurfacePlaneDistance)"
            inline constexpr std::uintptr_t WriteWaterZoneBySphereCastToDebug = 0x40F3420; // "private static void WriteWaterZoneBySphereCastToDebug(PhysicsDebugBattleCharacterWaterTickData physicsDebug, CharacterControllerModel character, float waterZoneSurfacePlaneDistance)"
            inline constexpr std::uintptr_t WriteWaterZoneByCollisionToDebug = 0x40F33C0; // "private static void WriteWaterZoneByCollisionToDebug(PhysicsDebugBattleCharacterWaterTickData physicsDebug, CharacterControllerModel character, float waterZoneSurfacePlaneDistance)"
            inline constexpr std::uintptr_t WriteWaterZoneResultToDebug = 0x40F3480; // "private static void WriteWaterZoneResultToDebug(PhysicsDebugBattleCharacterWaterTickData physicsDebug, bool waterFound, float waterZoneSurfacePlaneDistance)"
        }
    } // namespace CharacterControllerWaterSystem

    namespace CharacterCopRoleAnimationUpdater { // "Game.Battle.Entities.BattleCharacter.Updaters.CharacterCopRoleAnimationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t characterModelRole = 0x10; // "IPrimitiveModel<PlayerRoleDescription>"
            inline constexpr std::uintptr_t view = 0x18; // "CharacterAnimationView"
            inline constexpr std::uintptr_t isCop = 0x20; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xBC5A30; // "public void Update()"
            inline constexpr std::uintptr_t SetView = 0xBC59C0; // "private void SetView()"
        }
    } // namespace CharacterCopRoleAnimationUpdater

    namespace CharacterCrouchAnimationUpdater { // "Game.Battle.EntityModel.BattleCharacter.Crouch.CharacterCrouchAnimationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t crouch = 0x10; // "CharacterCrouchModel"
            inline constexpr std::uintptr_t animationView = 0x18; // "CharacterAnimationView"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xCE1F40; // "public void Update()"
        }
    } // namespace CharacterCrouchAnimationUpdater

    namespace CharacterCrouchArgsUpdater { // "Game.Battle.Entities.BattleCharacter.Crouch.CharacterCrouchArgsUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t blendArgs = 0x10; // "BlendArgs"
            inline constexpr std::uintptr_t characterCrouchModel = 0x18; // "CharacterCrouchModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xBE9E40; // "public void Update()"
        }
    } // namespace CharacterCrouchArgsUpdater

    namespace CharacterCrouchModel { // "Game.Battle.EntityModel.BattleCharacter.Crouch.CharacterCrouchModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Crouch = 0x10; // "float"
        }
    } // namespace CharacterCrouchModel

    namespace CharacterCrouchModelUpdater { // "Game.Battle.EntityModel.BattleCharacter.Crouch.CharacterCrouchModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t crouch = 0x10; // "CharacterCrouchModel"
            inline constexpr std::uintptr_t character = 0x18; // "BattleCharacterModel"
            inline constexpr std::uintptr_t now = 0x20; // "INow"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xCE1F70; // "public void Update()"
        }
    } // namespace CharacterCrouchModelUpdater

    namespace CharacterCustomizationCloseOnConfirmationModelUpdater { // "Game.Global.CharacterCustomization.CharacterCustomizationCloseOnConfirmationModelUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dialogModel = 0x10; // "SkinCenterDialogModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x36C7310; // "public void Update()"
        }
    } // namespace CharacterCustomizationCloseOnConfirmationModelUpdater

    namespace CharacterCustomizationLoadingModelUpdater { // "Game.Global.SkinCenter.Customization.CharacterCustomizationLoadingModelUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t characterCustomizationModel = 0x10; // "CharacterCustomizationModel"
            inline constexpr std::uintptr_t customizationModel = 0x18; // "ICustomizationModel"
            inline constexpr std::uintptr_t versionModel = 0x20; // "ICustomizationVersionModel"
            inline constexpr std::uintptr_t loadingModel = 0x28; // "ISkinLoadingModel<ICustomizationSnapshotModel>"
            inline constexpr std::uintptr_t scopesLoadingModel = 0x30; // "ScopesLoadingModel"
            inline constexpr std::uintptr_t loadedScope = 0x38; // "ILoadedContentScope"
            inline constexpr std::uintptr_t pendingScope = 0x40; // "ILoadedContentScope"
            inline constexpr std::uintptr_t pendingCompletion = 0x48; // "TaskCompletionSource<bool>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x3640E50; // "public void Update()"
        }
    } // namespace CharacterCustomizationLoadingModelUpdater

    namespace CharacterCustomizationModel { // "Game.Global.SkinCenter.Customization.Models.CharacterCustomizationModel (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsBagVisible = 0x10; // "bool"
            inline constexpr std::uintptr_t IsBagStrapVisible = 0x11; // "bool"
            inline constexpr std::uintptr_t IsMaskVisible = 0x12; // "bool"
            inline constexpr std::uintptr_t IsCopEquipVisible = 0x13; // "bool"
            inline constexpr std::uintptr_t IsPrisonerEquipVisible = 0x14; // "bool"
            inline constexpr std::uintptr_t IsNaked = 0x15; // "bool"
            inline constexpr std::uintptr_t ForceBald = 0x16; // "bool"
            inline constexpr std::uintptr_t IsDetailCustomization = 0x17; // "bool"
            inline constexpr std::uintptr_t IsTattooAnimationVisible = 0x18; // "bool"
            inline constexpr std::uintptr_t TattooGrade = 0x1C; // "int"
            inline constexpr std::uintptr_t ConstrictionProgress = 0x20; // "float"
            inline constexpr std::uintptr_t ConstrictionPosition = 0x24; // "Vector3"
            inline constexpr std::uintptr_t ConstrictionNormal = 0x30; // "Vector3"
            inline constexpr std::uintptr_t CopCustomizeDescription = 0x40; // "CopCustomizeDescription"
        }
    } // namespace CharacterCustomizationModel

    namespace CharacterCustomizationSceneUpdater { // "Game.Global.CharacterCustomization.CharacterCustomizationSceneUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t modelUpdater = 0x10; // "IUpdater"
            inline constexpr std::uintptr_t updater = 0x18; // "IUpdater"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x36CA1A0; // "public void Update()"
        }
    } // namespace CharacterCustomizationSceneUpdater

    namespace CharacterDeathAnimationUpdater { // "Game.Battle.EntityModel.BattleCharacter.CharacterDeathAnimationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t animationView = 0x10; // "CharacterAnimationView"
            inline constexpr std::uintptr_t withWeaponAnimationView = 0x18; // "CharacterWithWeaponAnimationView"
            inline constexpr std::uintptr_t isInstantDead = 0x20; // "bool"
            inline constexpr std::uintptr_t stateModel = 0x28; // "IBattleCharacterStateModel"
            inline constexpr std::uintptr_t characterControllerState = 0x30; // "IPrimitiveModel<CharacterControllerStateDescription>"
            inline constexpr std::uintptr_t state = 0x38; // "BattleCharacterState"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xCC17D0; // "public void Update()"
        }
    } // namespace CharacterDeathAnimationUpdater

    namespace CharacterDeathModel { // "Models.Models.CharacterDeath.CharacterDeathModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ts = 0x10; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t killerName = 0x18; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t killerPublicId = 0x20; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t reason = 0x28; // "IPrimitiveData<DeathReasonDescription>"
            inline constexpr std::uintptr_t killerClanTag = 0x30; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t KillerRole = 0x38; // "PlayerRoleDescription"
            inline constexpr std::uintptr_t IsSurrendered = 0x40; // "bool"
            inline constexpr std::uintptr_t IsHandcuffing = 0x41; // "bool"
            inline constexpr std::uintptr_t IsHandcuffed = 0x42; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Ts = 0x4977EF0; // "public long get_Ts()"
            inline constexpr std::uintptr_t get_KillerName = 0x4977D90; // "public string get_KillerName()"
            inline constexpr std::uintptr_t get_KillerClanTag = 0x4977D40; // "public string get_KillerClanTag()"
            inline constexpr std::uintptr_t get_KillerPublicId = 0x4977DE0; // "public long get_KillerPublicId()"
            inline constexpr std::uintptr_t get_Reason = 0x4977E30; // "public DeathReasonDescription get_Reason()"
            inline constexpr std::uintptr_t SetDead = 0x4977A90; // "public void SetDead(long ts, string killerName, string killerClanTag, PlayerRoleDescription killerRole, long killerPublicId, DeathReasonDescription reason, CharacterKnockoutOrDeathRobberStateDescription robberState)"
            inline constexpr std::uintptr_t Clear = 0x49779A0; // "public void Clear()"
        }
    } // namespace CharacterDeathModel

    namespace CharacterEmotionAnimationUpdater { // "Game.Battle.EntityModel.BattleCharacter.Emotion.CharacterEmotionAnimationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t scopesLoadingModel = 0x10; // "ScopesLoadingModel"
            inline constexpr std::uintptr_t animationView = 0x18; // "CharacterAnimationView"
            inline constexpr std::uintptr_t emotionOverrideController = 0x20; // "AnimatorOverrideController"
            inline constexpr std::uintptr_t stateAssistant = 0x28; // "AnimationStateAssistant"
            inline constexpr std::uintptr_t emotion = 0x30; // "EmotionModel"
            inline constexpr std::uintptr_t customization = 0x38; // "ICustomizationModel"
            inline constexpr std::uintptr_t viewDescriptions = 0x40; // "EmotionViewDescriptions"
            inline constexpr std::uintptr_t now = 0x48; // "INow"
            inline constexpr std::uintptr_t overrides = 0x50; // "List<KeyValuePair<AnimationClip, AnimationClip>>"
            inline constexpr std::uintptr_t togglingIndex = 0x58; // "int"
            inline constexpr std::uintptr_t isActive = 0x5C; // "bool"
            inline constexpr std::uintptr_t isContentLoading = 0x5D; // "bool"
            inline constexpr std::uintptr_t lastEndTs = 0x60; // "long"
            inline constexpr std::uintptr_t startTs = 0x68; // "long"
            inline constexpr std::uintptr_t lastFrameTs = 0x70; // "long"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xCE23F0; // "public void Update()"
            inline constexpr std::uintptr_t GetClipsForOverride = 0xCE2370; // "private void GetClipsForOverride(int index, out AnimationClip precast, out AnimationClip cast)"
        }
    } // namespace CharacterEmotionAnimationUpdater

    namespace CharacterExitModel { // "Models.Models.CharacterExit.CharacterExitModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsExitUsed = 0x10; // "bool"
            inline constexpr std::uintptr_t VehicleId = 0x14; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsExitWithVehicle = 0xCEF9B0; // "public bool get_IsExitWithVehicle()"
        }
    } // namespace CharacterExitModel

    namespace CharacterFBodyDescription { // "Models.References.Character.Customizer.CharacterFBodyDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsAvailable = 0x20; // "bool"
            inline constexpr std::uintptr_t CryptoCoinsPrice = 0x24; // "int"
            inline constexpr std::uintptr_t CompensationCryptoCoins = 0x28; // "int"
            inline constexpr std::uintptr_t ImprisonmentYearsRequired = 0x2C; // "int"
            inline constexpr std::uintptr_t IsHidden = 0x30; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_HasPrice = 0x4406310; // "public bool get_HasPrice()"
            inline constexpr std::uintptr_t get_BuyParams = 0x446B000; // "public ValueTuple<int, int> get_BuyParams()"
        }
    } // namespace CharacterFBodyDescription

    namespace CharacterFHairDescription { // "Models.References.Character.Customizer.CharacterFHairDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsHidden = 0x20; // "bool"
            inline constexpr std::uintptr_t NoHair = 0x21; // "bool"
        }
    } // namespace CharacterFHairDescription

    namespace CharacterFHeadDescription { // "Models.References.Character.Customizer.CharacterFHeadDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsHidden = 0x20; // "bool"
        }
    } // namespace CharacterFHeadDescription

    namespace CharacterFMakeupDescription { // "Models.References.Character.Customizer.CharacterFMakeupDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsHidden = 0x20; // "bool"
            inline constexpr std::uintptr_t IsClear = 0x21; // "bool"
        }
    } // namespace CharacterFMakeupDescription

    namespace CharacterFMarkDescription { // "Models.References.Character.Customizer.CharacterFMarkDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsHidden = 0x20; // "bool"
        }
    } // namespace CharacterFMarkDescription

    namespace CharacterGridSystem { // "Models.Systems.CharacterGridSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t grid = 0x38; // "IRegularGrid"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x40F3530; // "protected override void Tick(ITick tick)"
        }
    } // namespace CharacterGridSystem

    namespace CharacterGroupTitles { // "Game.Global.SkinCenter.ViewDescriptions.CharacterGroupTitles (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t WeaponType = 0x10; // "SkinCenterCharacterType"
            inline constexpr std::uintptr_t Title = 0x18; // "LocalizedString"
        }
    } // namespace CharacterGroupTitles

    namespace CharacterHairDescription { // "Models.References.Character.Customizer.CharacterHairDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsHidden = 0x20; // "bool"
            inline constexpr std::uintptr_t NoHair = 0x21; // "bool"
        }
    } // namespace CharacterHairDescription

    namespace CharacterHairMaterialsContent { // "Game.Global.SkinCenter.ViewDescriptions.Character.Contents.CharacterHairMaterialsContent (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Materials = 0x18; // "Material[]"
            inline constexpr std::uintptr_t DetailMaterials = 0x20; // "Material[]"
        }
    } // namespace CharacterHairMaterialsContent

    namespace CharacterHandcuffStartAnimationUpdater { // "Game.Battle.Entities.BattleCharacter.Updaters.CharacterHandcuffStartAnimationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t arrestModel = 0x10; // "ArrestTargetModel"
            inline constexpr std::uintptr_t animationView = 0x18; // "CharacterAnimationView"
            inline constexpr std::uintptr_t isActive = 0x20; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xBC60C0; // "public void Update()"
        }
    } // namespace CharacterHandcuffStartAnimationUpdater

    namespace CharacterHeadContent { // "Game.Global.SkinCenter.ViewDescriptions.Character.Contents.CharacterHeadContent (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Material = 0x18; // "Material"
            inline constexpr std::uintptr_t BrowsMaterial = 0x20; // "Material"
            inline constexpr std::uintptr_t TattooMaterial = 0x28; // "Material"
            inline constexpr std::uintptr_t Lods = 0x30; // "Mesh[]"
            inline constexpr std::uintptr_t BrowsLods = 0x38; // "Mesh[]"
            inline constexpr std::uintptr_t EyelashesLods = 0x40; // "Mesh[]"
            inline constexpr std::uintptr_t BaldLods = 0x48; // "Mesh[]"
            inline constexpr std::uintptr_t BristleLods = 0x50; // "Mesh[]"
        }
    } // namespace CharacterHeadContent

    namespace CharacterHeadDescription { // "Models.References.Character.Customizer.CharacterHeadDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsHidden = 0x20; // "bool"
        }
    } // namespace CharacterHeadDescription

    namespace CharacterHeadManualControlRulesModel { // "Game.Battle.EntityModel.BattleCharacter.HeadManualControl.CharacterHeadManualControlRulesModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t NeckControlRule = 0x10; // "ICharacterHeadManualControlRule"
            inline constexpr std::uintptr_t HeadControlRule = 0x18; // "ICharacterHeadManualControlRule"
        }
    } // namespace CharacterHeadManualControlRulesModel

    namespace CharacterHiddenModelUpdater { // "Game.Battle.EntityModel.BattleCharacter.Location.CharacterHiddenModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t hidden = 0x10; // "IsHiddenModel"
            inline constexpr std::uintptr_t interactionView = 0x18; // "HidingInteractionView"
            inline constexpr std::uintptr_t crouchModel = 0x20; // "CrouchModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xCCE730; // "public void Update()"
        }
    } // namespace CharacterHiddenModelUpdater

    namespace CharacterHideObjectInteractionUpdater { // "Game.Battle.HideObject.CharacterHideObjectInteractionUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t hideObjectViewsDictionaryModel = 0x10; // "HideObjectViewsDictionaryModel"
            inline constexpr std::uintptr_t notificationModel = 0x18; // "HideAndSeekNotificationModel"
            inline constexpr std::uintptr_t viewDescriptions = 0x20; // "HideObjectViewDescriptions"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA87E10; // "public void Update()"
            inline constexpr std::uintptr_t PlaySound = 0xA87D70; // "private void PlaySound(LocationHideObjectDescription locationHideObjectDescription, HideObjectView view)"
        }
    } // namespace CharacterHideObjectInteractionUpdater

    namespace CharacterHideObjectStateModel { // "Models.Models.CharacterHideObjectState.CharacterHideObjectStateModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t hideObjectEntityIdData = 0x10; // "IPrimitiveData<int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_HideObjectEntityId = 0x4977FF0; // "public int get_HideObjectEntityId()"
            inline constexpr std::uintptr_t get_IsHidden = 0x4978040; // "public bool get_IsHidden()"
            inline constexpr std::uintptr_t Hide = 0x4977F40; // "public void Hide(int entityId)"
            inline constexpr std::uintptr_t Leave = 0x4977FA0; // "public void Leave()"
            inline constexpr std::uintptr_t SetEntityId = 0x4977F40; // "private void SetEntityId(int entityId)"
        }
    } // namespace CharacterHideObjectStateModel

    namespace CharacterHitData { // "Game.Battle.EntityModel.BattleCharacter.Hit.CharacterHitData (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t TickIndex = 0x10; // "long"
            inline constexpr std::uintptr_t EntityId = 0x18; // "int"
            inline constexpr std::uintptr_t PositionDiff = 0x1C; // "Vector3"
        }
    } // namespace CharacterHitData

    namespace CharacterImmuneStateConfig { // "Models.References.CharacterImmuneStateConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Duration = 0x10; // "long"
            inline constexpr std::uintptr_t DurationAfterInterrupt = 0x18; // "long"
        }
    } // namespace CharacterImmuneStateConfig

    namespace CharacterImmuneStateModel { // "Models.Models.CharacterImmuneState.CharacterImmuneStateModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t endTs = 0x10; // "IPrimitiveData<long>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsActive = 0x49781D0; // "public bool get_IsActive()"
            inline constexpr std::uintptr_t get_EndTs = 0x4978180; // "public long get_EndTs()"
            inline constexpr std::uintptr_t Set = 0x4978120; // "public void Set(long endTs)"
            inline constexpr std::uintptr_t Clear = 0x4978090; // "public void Clear()"
        }
    } // namespace CharacterImmuneStateModel

    namespace CharacterInterruptArrestingAnimationUpdater { // "Game.Battle.Entities.BattleCharacter.Updaters.CharacterInterruptArrestingAnimationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t animationView = 0x10; // "CharacterAnimationView"
            inline constexpr std::uintptr_t prolongedInteractionModel = 0x18; // "ProlongedInteractionModel"
            inline constexpr std::uintptr_t now = 0x20; // "INow"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xBC66A0; // "public void Update()"
        }
    } // namespace CharacterInterruptArrestingAnimationUpdater

    namespace CharacterInterruptionConfig { // "Models.References.Character.CharacterInterruptionConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Arrest = 0x10; // "CharacterInterruptionDependencyDescription"
            inline constexpr std::uintptr_t ArrestLoot = 0x18; // "CharacterInterruptionDependencyDescription"
            inline constexpr std::uintptr_t ChargeCumulativeItem = 0x20; // "CharacterInterruptionDependencyDescription"
            inline constexpr std::uintptr_t CheckHideObject = 0x28; // "CharacterInterruptionDependencyDescription"
            inline constexpr std::uintptr_t CloseSafe = 0x30; // "CharacterInterruptionDependencyDescription"
            inline constexpr std::uintptr_t CollectChargedCargoReward = 0x38; // "CharacterInterruptionDependencyDescription"
            inline constexpr std::uintptr_t EnterDeepWater = 0x40; // "CharacterInterruptionDependencyDescription"
            inline constexpr std::uintptr_t EnteringVehicle = 0x48; // "CharacterInterruptionDependencyDescription"
            inline constexpr std::uintptr_t Evict = 0x50; // "CharacterInterruptionDependencyDescription"
            inline constexpr std::uintptr_t GetAccess = 0x58; // "CharacterInterruptionDependencyDescription"
            inline constexpr std::uintptr_t HideInHideObject = 0x60; // "CharacterInterruptionDependencyDescription"
            inline constexpr std::uintptr_t InterruptArresting = 0x68; // "CharacterInterruptionDependencyDescription"
            inline constexpr std::uintptr_t Knockdown = 0x70; // "CharacterInterruptionDependencyDescription"
            inline constexpr std::uintptr_t Knockout = 0x78; // "CharacterInterruptionDependencyDescription"
            inline constexpr std::uintptr_t MeleeAttack = 0x80; // "CharacterInterruptionDependencyDescription"
            inline constexpr std::uintptr_t Reloading = 0x88; // "CharacterInterruptionDependencyDescription"
            inline constexpr std::uintptr_t RemoveDrill = 0x90; // "CharacterInterruptionDependencyDescription"
            inline constexpr std::uintptr_t RemovedFromVehicle = 0x98; // "CharacterInterruptionDependencyDescription"
            inline constexpr std::uintptr_t RepairLaunderingCable = 0xA0; // "CharacterInterruptionDependencyDescription"
            inline constexpr std::uintptr_t ResetAccess = 0xA8; // "CharacterInterruptionDependencyDescription"
            inline constexpr std::uintptr_t ReviveCharacter = 0xB0; // "CharacterInterruptionDependencyDescription"
            inline constexpr std::uintptr_t SelectQuickSlot = 0xB8; // "CharacterInterruptionDependencyDescription"
            inline constexpr std::uintptr_t SetDrill = 0xC0; // "CharacterInterruptionDependencyDescription"
            inline constexpr std::uintptr_t Sprinting = 0xC8; // "CharacterInterruptionDependencyDescription"
            inline constexpr std::uintptr_t BecomeRobber = 0xD0; // "CharacterInterruptionDependencyDescription"
            inline constexpr std::uintptr_t StartEmotion = 0xD8; // "CharacterInterruptionDependencyDescription"
            inline constexpr std::uintptr_t StartLootingNode = 0xE0; // "CharacterInterruptionDependencyDescription"
            inline constexpr std::uintptr_t RaidDefenseBlockCommand = 0xE8; // "CharacterInterruptionDependencyDescription"
            inline constexpr std::uintptr_t RefillEquip = 0xF0; // "CharacterInterruptionDependencyDescription"
            inline constexpr std::uintptr_t RemovePoopPile = 0xF8; // "CharacterInterruptionDependencyDescription"
            inline constexpr std::uintptr_t RepairBreach = 0x100; // "CharacterInterruptionDependencyDescription"
            inline constexpr std::uintptr_t RepairDefenseBlock = 0x108; // "CharacterInterruptionDependencyDescription"
            inline constexpr std::uintptr_t StartSwimming = 0x110; // "CharacterInterruptionDependencyDescription"
            inline constexpr std::uintptr_t StartTakeCash = 0x118; // "CharacterInterruptionDependencyDescription"
            inline constexpr std::uintptr_t StartThrowThrowableItem = 0x120; // "CharacterInterruptionDependencyDescription"
            inline constexpr std::uintptr_t StartUnlocking = 0x128; // "CharacterInterruptionDependencyDescription"
            inline constexpr std::uintptr_t UseFirstAidCabinet = 0x130; // "CharacterInterruptionDependencyDescription"
            inline constexpr std::uintptr_t Surrender = 0x138; // "CharacterInterruptionDependencyDescription"
            inline constexpr std::uintptr_t TakeCargo = 0x140; // "CharacterInterruptionDependencyDescription"
            inline constexpr std::uintptr_t TakeLootObjectProlonged = 0x148; // "CharacterInterruptionDependencyDescription"
            inline constexpr std::uintptr_t TakeLootObjectInstant = 0x150; // "CharacterInterruptionDependencyDescription"
            inline constexpr std::uintptr_t UseItemByContextMenu = 0x158; // "CharacterInterruptionDependencyDescription"
            inline constexpr std::uintptr_t UsePointOfInterest = 0x160; // "CharacterInterruptionDependencyDescription"
            inline constexpr std::uintptr_t UseUsableItem = 0x168; // "CharacterInterruptionDependencyDescription"
            inline constexpr std::uintptr_t SecurityAlarmInteraction = 0x170; // "CharacterInterruptionDependencyDescription"
            inline constexpr std::uintptr_t CrouchDisable = 0x178; // "CharacterInterruptionDependencyDescription"
            inline constexpr std::uintptr_t CrouchEnable = 0x180; // "CharacterInterruptionDependencyDescription"
            inline constexpr std::uintptr_t JumpStart = 0x188; // "CharacterInterruptionDependencyDescription"
            inline constexpr std::uintptr_t MoveInput = 0x190; // "CharacterInterruptionDependencyDescription"
            inline constexpr std::uintptr_t ShotFire = 0x198; // "CharacterInterruptionDependencyDescription"
            inline constexpr std::uintptr_t TargetAimingOff = 0x1A0; // "CharacterInterruptionDependencyDescription"
            inline constexpr std::uintptr_t TargetAimingOn = 0x1A8; // "CharacterInterruptionDependencyDescription"
            inline constexpr std::uintptr_t UseInventoryItem = 0x1B0; // "CharacterInterruptionDependencyDescription"
            inline constexpr std::uintptr_t WeaponClick = 0x1B8; // "CharacterInterruptionDependencyDescription"
            inline constexpr std::uintptr_t ReloadStart = 0x1C0; // "CharacterInterruptionDependencyDescription"
            inline constexpr std::uintptr_t OpenClose = 0x1C8; // "CharacterInterruptionDependencyDescription"
            inline constexpr std::uintptr_t StartLeaveVehicle = 0x1D0; // "CharacterInterruptionDependencyDescription"
            inline constexpr std::uintptr_t BreakCollider = 0x1D8; // "CharacterInterruptionDependencyDescription"
            inline constexpr std::uintptr_t ForceArrest = 0x1E0; // "CharacterInterruptionDependencyDescription"
        }
    } // namespace CharacterInterruptionConfig

    namespace CharacterInterruptionDependencyDescription { // "Models.References.Character.CharacterInterruptionDependencyDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Fire = 0x18; // "bool"
            inline constexpr std::uintptr_t ClearSprint = 0x19; // "bool"
            inline constexpr std::uintptr_t StopSprint = 0x1A; // "bool"
            inline constexpr std::uintptr_t Reload = 0x1B; // "bool"
            inline constexpr std::uintptr_t Aiming = 0x1C; // "bool"
            inline constexpr std::uintptr_t Crouch = 0x1D; // "bool"
            inline constexpr std::uintptr_t Unlock = 0x1E; // "bool"
            inline constexpr std::uintptr_t UseHideObject = 0x1F; // "bool"
            inline constexpr std::uintptr_t TakeLootObject = 0x20; // "bool"
            inline constexpr std::uintptr_t TakeLootNode = 0x21; // "bool"
            inline constexpr std::uintptr_t TakeCash = 0x22; // "bool"
            inline constexpr std::uintptr_t RemovePoopPile = 0x23; // "bool"
            inline constexpr std::uintptr_t Arrest = 0x24; // "bool"
            inline constexpr std::uintptr_t VehicleLeave = 0x25; // "bool"
            inline constexpr std::uintptr_t RevivalCharacter = 0x26; // "bool"
            inline constexpr std::uintptr_t BecomeRobber = 0x27; // "bool"
            inline constexpr std::uintptr_t MeleeAttack = 0x28; // "bool"
            inline constexpr std::uintptr_t BattleStance = 0x29; // "bool"
            inline constexpr std::uintptr_t ArmedState = 0x2A; // "bool"
            inline constexpr std::uintptr_t InterruptArresting = 0x2B; // "bool"
            inline constexpr std::uintptr_t KnockdownState = 0x2C; // "bool"
            inline constexpr std::uintptr_t RefillEquip = 0x2D; // "bool"
            inline constexpr std::uintptr_t ArrestLoot = 0x2E; // "bool"
            inline constexpr std::uintptr_t TakeCargo = 0x2F; // "bool"
            inline constexpr std::uintptr_t SetDrill = 0x30; // "bool"
            inline constexpr std::uintptr_t GetAccess = 0x31; // "bool"
            inline constexpr std::uintptr_t ResetAccess = 0x32; // "bool"
            inline constexpr std::uintptr_t RemoveDrill = 0x33; // "bool"
            inline constexpr std::uintptr_t RepairBreach = 0x34; // "bool"
            inline constexpr std::uintptr_t UseFirstAidCabinet = 0x35; // "bool"
            inline constexpr std::uintptr_t Surrender = 0x36; // "bool"
            inline constexpr std::uintptr_t UseItem = 0x37; // "bool"
            inline constexpr std::uintptr_t ThrowItem = 0x38; // "bool"
            inline constexpr std::uintptr_t Emotion = 0x39; // "bool"
            inline constexpr std::uintptr_t MainMenuExit = 0x3A; // "bool"
            inline constexpr std::uintptr_t ChargeCumulativeItem = 0x3B; // "bool"
            inline constexpr std::uintptr_t DefenseBlockInteraction = 0x3C; // "bool"
            inline constexpr std::uintptr_t CloseSafeInteraction = 0x3D; // "bool"
            inline constexpr std::uintptr_t UnsetTakeInHandsIntention = 0x3E; // "bool"
            inline constexpr std::uintptr_t CollectChargedCargoReward = 0x3F; // "bool"
            inline constexpr std::uintptr_t Evict = 0x40; // "bool"
            inline constexpr std::uintptr_t RepairLaunderingCable = 0x41; // "bool"
            inline constexpr std::uintptr_t SecurityAlarmCommand = 0x42; // "bool"
            inline constexpr std::uintptr_t ImmuneState = 0x43; // "bool"
            inline constexpr std::uintptr_t FireCooldown = 0x44; // "bool"
            inline constexpr std::uintptr_t CrouchSoft = 0x45; // "bool"
            inline constexpr std::uintptr_t Interact = 0x46; // "bool"
            inline constexpr std::uintptr_t Arresting = 0x47; // "bool"
            inline constexpr std::uintptr_t LastQuickSlot = 0x48; // "bool"
            inline constexpr std::uintptr_t ClearUseItem = 0x49; // "bool"
            inline constexpr std::uintptr_t ClearThrowItem = 0x4A; // "bool"
            inline constexpr std::uintptr_t RememberAndUnselectItemInHands = 0x4B; // "bool"
            inline constexpr std::uintptr_t UsePointOfInterest = 0x4C; // "bool"
            inline constexpr std::uintptr_t ForceArrest = 0x4D; // "bool"
        }
    } // namespace CharacterInterruptionDependencyDescription

    namespace CharacterInterruptModel { // "Models.Models.CharacterInterrupt.CharacterInterruptModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t id = 0x10; // "int"
            inline constexpr std::uintptr_t fireModel = 0x18; // "FireModel"
            inline constexpr std::uintptr_t sprintModel = 0x20; // "SprintModel"
            inline constexpr std::uintptr_t weaponReloadModel = 0x28; // "WeaponReloadModel"
            inline constexpr std::uintptr_t targetAiming = 0x30; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t aimingModel = 0x38; // "AimingModel"
            inline constexpr std::uintptr_t aimStateModel = 0x40; // "AimStateModel"
            inline constexpr std::uintptr_t crouchModel = 0x48; // "CrouchModel"
            inline constexpr std::uintptr_t itemActionProcessModel = 0x50; // "ItemActionProcessModel"
            inline constexpr std::uintptr_t mainMenuExitModel = 0x58; // "CharacterMainMenuExitModel"
            inline constexpr std::uintptr_t reloadParamsModel = 0x60; // "ReloadParamsModel"
            inline constexpr std::uintptr_t reloadIntention = 0x68; // "IntentionModel"
            inline constexpr std::uintptr_t crouchIntention = 0x70; // "IntentionModel"
            inline constexpr std::uintptr_t contextMenuUseItemModel = 0x78; // "ContextMenuUseItemModel"
            inline constexpr std::uintptr_t inventoryUseItemModel = 0x80; // "InventoryUseItemModel"
            inline constexpr std::uintptr_t inventoryUseItemRequest = 0x88; // "RequestModel<InventoryUseItemInputInfo>"
            inline constexpr std::uintptr_t itemActionRequest = 0x90; // "RequestModel<ItemActionTypeDescription>"
            inline constexpr std::uintptr_t weaponReloadEvent = 0x98; // "IEventModel"
            inline constexpr std::uintptr_t surrenderModel = 0xA0; // "SurrenderModel"
            inline constexpr std::uintptr_t becomeRobberModel = 0xA8; // "BecomeRobberModel"
            inline constexpr std::uintptr_t vehicleLeaveModel = 0xB0; // "VehicleLeaveModel"
            inline constexpr std::uintptr_t arrestTargetModel = 0xB8; // "ArrestTargetModel"
            inline constexpr std::uintptr_t meleeAttackModel = 0xC0; // "MeleeAttackModel"
            inline constexpr std::uintptr_t battleStanceModel = 0xC8; // "BattleStanceModel"
            inline constexpr std::uintptr_t armedModel = 0xD0; // "ArmedModel"
            inline constexpr std::uintptr_t breakColliderModel = 0xD8; // "BreakColliderModel"
            inline constexpr std::uintptr_t knockdownModel = 0xE0; // "KnockdownModel"
            inline constexpr std::uintptr_t emotionRequest = 0xE8; // "RequestModel<EmotionDescription>"
            inline constexpr std::uintptr_t emotionModel = 0xF0; // "EmotionModel"
            inline constexpr std::uintptr_t crouchRequest = 0xF8; // "RequestModel<CrouchInputDescription>"
            inline constexpr std::uintptr_t shotInput = 0x100; // "IEventModel"
            inline constexpr std::uintptr_t interactModel = 0x108; // "InteractModel"
            inline constexpr std::uintptr_t selectedQuickSlotRequest = 0x110; // "RequestModel<QuickSlotDescription>"
            inline constexpr std::uintptr_t itemInHandsModel = 0x118; // "ItemInHandsModel"
            inline constexpr std::uintptr_t selectedQuickSlotModel = 0x120; // "SelectedQuickSlotModel"
            inline constexpr std::uintptr_t lastQuickSlotModel = 0x128; // "LastQuickSlotModel"
            inline constexpr std::uintptr_t immuneStateModel = 0x130; // "CharacterImmuneStateModel"
            inline constexpr std::uintptr_t takeInHandsIntentionOnEquipDelayEnds = 0x138; // "TakeInHandsIntentionOnEquipDelayEndsModel"
            inline constexpr std::uintptr_t holdingCellModel = 0x140; // "BattleCharacterHoldingCellModel"
            inline constexpr std::uintptr_t prolongedInteractionModel = 0x148; // "ProlongedInteractionModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t InterruptWhen = 0x4978FA0; // "public void InterruptWhen(CharacterInterruptionDependencyDescription interruptDescription, long now, IWorldInterruptModel worldInterruptModel)"
            inline constexpr std::uintptr_t Interrupt = 0x4979A90; // "public void Interrupt(long now, IWorldInterruptModel worldInterruptModel)"
            inline constexpr std::uintptr_t InterruptAndClear = 0x4978600; // "public void InterruptAndClear(long now, IWorldInterruptModel worldInterruptModel)"
            inline constexpr std::uintptr_t StopReload = 0x497AD20; // "public void StopReload(long now)"
            inline constexpr std::uintptr_t StopCrouchSoft = 0x497A560; // "public void StopCrouchSoft()"
            inline constexpr std::uintptr_t StopCrouchHard = 0x497A4D0; // "public void StopCrouchHard()"
            inline constexpr std::uintptr_t StopSurrender = 0x497B0E0; // "public void StopSurrender(long now)"
            inline constexpr std::uintptr_t StopUseItem = 0x497B2E0; // "public void StopUseItem()"
            inline constexpr std::uintptr_t ClearUseItem = 0x4978460; // "private void ClearUseItem()"
            inline constexpr std::uintptr_t StopThrowItem = 0x497B1B0; // "public void StopThrowItem()"
            inline constexpr std::uintptr_t ClearThrowItem = 0x49783E0; // "public void ClearThrowItem()"
            inline constexpr std::uintptr_t InterruptFire = 0x4978D90; // "private void InterruptFire()"
            inline constexpr std::uintptr_t InterruptFireCooldown = 0x4978D20; // "private void InterruptFireCooldown()"
            inline constexpr std::uintptr_t ClearSprint = 0x49782A0; // "public void ClearSprint()"
            inline constexpr std::uintptr_t StopSprint = 0x497B0A0; // "private void StopSprint()"
            inline constexpr std::uintptr_t InterruptAiming = 0x4978500; // "public void InterruptAiming()"
            inline constexpr std::uintptr_t InterruptUnlock = 0x4978ED0; // "public void InterruptUnlock()"
            inline constexpr std::uintptr_t InterruptUseHideObject = 0x4978F10; // "private void InterruptUseHideObject()"
            inline constexpr std::uintptr_t InterruptTakeLootObject = 0x4978E90; // "private void InterruptTakeLootObject()"
            inline constexpr std::uintptr_t InterruptTakeLootNode = 0x4978E50; // "private void InterruptTakeLootNode()"
            inline constexpr std::uintptr_t InterruptBecomeRobber = 0x4978CD0; // "private void InterruptBecomeRobber()"
            inline constexpr std::uintptr_t ClearSurrender = 0x4978330; // "private void ClearSurrender()"
            inline constexpr std::uintptr_t InterruptVehicleLeave = 0x4978F50; // "public void InterruptVehicleLeave()"
            inline constexpr std::uintptr_t StopSecurityAlarmCommand = 0x497B000; // "public void StopSecurityAlarmCommand()"
            inline constexpr std::uintptr_t StopBattleStance = 0x497A310; // "private void StopBattleStance()"
            inline constexpr std::uintptr_t StopArmedState = 0x497A1C0; // "public void StopArmedState()"
            inline constexpr std::uintptr_t StopArrest = 0x497A250; // "private void StopArrest(IWorldInterruptModel worldInterruptModel)"
            inline constexpr std::uintptr_t StopInterruptArresting = 0x497A860; // "private void StopInterruptArresting(IWorldInterruptModel worldInterruptModel)"
            inline constexpr std::uintptr_t StopForceArrestTarget = 0x497A790; // "private void StopForceArrestTarget()"
            inline constexpr std::uintptr_t StopArresting = 0x497A2C0; // "private void StopArresting()"
            inline constexpr std::uintptr_t StopRevivalCharacter = 0x497AF10; // "private void StopRevivalCharacter(long now, IWorldInterruptModel worldInterruptModel)"
            inline constexpr std::uintptr_t StopMeleeAttack = 0x497ABF0; // "public void StopMeleeAttack()"
            inline constexpr std::uintptr_t StopKnockdownState = 0x497A8D0; // "private void StopKnockdownState()"
            inline constexpr std::uintptr_t StopRefillEquip = 0x497ACB0; // "public void StopRefillEquip(IWorldInterruptModel worldInterruptModel)"
            inline constexpr std::uintptr_t StopEmotion = 0x497A6D0; // "public void StopEmotion()"
            inline constexpr std::uintptr_t StopArrestLoot = 0x497A210; // "public void StopArrestLoot()"
            inline constexpr std::uintptr_t StopTakeCargo = 0x497B130; // "public void StopTakeCargo()"
            inline constexpr std::uintptr_t StopSetDrill = 0x497B060; // "public void StopSetDrill()"
            inline constexpr std::uintptr_t StopRemoveDrill = 0x497ADD0; // "public void StopRemoveDrill()"
            inline constexpr std::uintptr_t StopGetAccess = 0x497A7D0; // "public void StopGetAccess()"
            inline constexpr std::uintptr_t StopResetAccess = 0x497AED0; // "public void StopResetAccess()"
            inline constexpr std::uintptr_t StopInteract = 0x497A810; // "private void StopInteract()"
            inline constexpr std::uintptr_t UnselectItemInHands = 0x497B570; // "public void UnselectItemInHands()"
            inline constexpr std::uintptr_t RememberAndUnselectItemInHands = 0x497A0E0; // "public void RememberAndUnselectItemInHands()"
            inline constexpr std::uintptr_t ClearLastQuickSlot = 0x4978250; // "private void ClearLastQuickSlot()"
            inline constexpr std::uintptr_t StopTakeCash = 0x497B170; // "public void StopTakeCash()"
            inline constexpr std::uintptr_t StopRemovePoopPile = 0x497AE10; // "public void StopRemovePoopPile()"
            inline constexpr std::uintptr_t StopRepairBreach = 0x497AE50; // "public void StopRepairBreach()"
            inline constexpr std::uintptr_t StopMainMenuExit = 0x497A920; // "public void StopMainMenuExit()"
            inline constexpr std::uintptr_t StopChargeCumulativeItem = 0x497A3E0; // "public void StopChargeCumulativeItem()"
            inline constexpr std::uintptr_t StopDefenseBlockInteraction = 0x497A670; // "public void StopDefenseBlockInteraction()"
            inline constexpr std::uintptr_t StopCloseSafeInteraction = 0x497A420; // "public void StopCloseSafeInteraction(IWorldInterruptModel worldInterruptModel)"
            inline constexpr std::uintptr_t InterruptImmuneState = 0x4978E30; // "public void InterruptImmuneState(long now)"
            inline constexpr std::uintptr_t RemoveImmuneState = 0x497A1A0; // "public void RemoveImmuneState()"
            inline constexpr std::uintptr_t StopUseFirstAidCabinet = 0x497B2A0; // "public void StopUseFirstAidCabinet()"
            inline constexpr std::uintptr_t UnsetTakeInHandsIntentionOnEquipDelay = 0x497B6B0; // "private void UnsetTakeInHandsIntentionOnEquipDelay()"
            inline constexpr std::uintptr_t StopCollectChargedCargoReward = 0x497A490; // "public void StopCollectChargedCargoReward()"
            inline constexpr std::uintptr_t StopEvict = 0x497A750; // "public void StopEvict()"
            inline constexpr std::uintptr_t StopRepairLaunderingCable = 0x497AE90; // "public void StopRepairLaunderingCable()"
            inline constexpr std::uintptr_t StopUsePointOfInterest = 0x497B530; // "public void StopUsePointOfInterest()"
        }
    } // namespace CharacterInterruptModel

    namespace CharacterInventoryModel { // "Models.Models.InventoryModel.CharacterInventoryModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t backpackSlotModel = 0x20; // "IEquipSlotModel"
            inline constexpr std::uintptr_t startLinesCount = 0x28; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_LinesCount = 0x492CFE0; // "public override int get_LinesCount()"
            inline constexpr std::uintptr_t get_AdditionalLinesCount = 0x492CF20; // "private int get_AdditionalLinesCount()"
        }
    } // namespace CharacterInventoryModel

    namespace CharacterItemActionAnimationUpdater { // "Game.Battle.EntityModel.BattleCharacter.Equipment.CharacterItemActionAnimationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t animationView = 0x18; // "CharacterAnimationView"
            inline constexpr std::uintptr_t itemActionProcessModel = 0x20; // "ItemActionProcessModel"
            inline constexpr std::uintptr_t useItemModel = 0x28; // "CharacterUseItemModel"
            inline constexpr std::uintptr_t isInCast = 0x30; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t InnerUpdate = 0xCCE8C0; // "protected override void InnerUpdate()"
            inline constexpr std::uintptr_t InnerStart = 0x7B3360; // "protected override void InnerStart()"
            inline constexpr std::uintptr_t InnerStop = 0xCCE890; // "protected override void InnerStop()"
        }
    } // namespace CharacterItemActionAnimationUpdater

    namespace CharacterItemWasThrownAnimationUpdater { // "Game.Battle.Entities.BattleCharacter.Equipment.CharacterItemWasThrownAnimationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t itemActionProcess = 0x18; // "ItemActionProcessModel"
            inline constexpr std::uintptr_t animationView = 0x20; // "CharacterAnimationView"
            inline constexpr std::uintptr_t state = 0x28; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t InnerUpdate = 0xBEAA90; // "protected override void InnerUpdate()"
            inline constexpr std::uintptr_t InnerStart = 0x7B3360; // "protected override void InnerStart()"
            inline constexpr std::uintptr_t InnerStop = 0xBEAA40; // "protected override void InnerStop()"
        }
    } // namespace CharacterItemWasThrownAnimationUpdater

    namespace CharacterKeychainContent { // "Game.Global.SkinCenter.ViewDescriptions.Character.Contents.CharacterKeychainContent (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Materials = 0x18; // "Material[]"
            inline constexpr std::uintptr_t ChainMaterial = 0x20; // "Material"
            inline constexpr std::uintptr_t Lods = 0x28; // "Mesh[]"
        }
    } // namespace CharacterKeychainContent

    namespace CharacterKeychainDescription { // "Models.References.Character.Customizer.CharacterKeychainDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsAvailable = 0x20; // "bool"
            inline constexpr std::uintptr_t CryptoCoinsPrice = 0x24; // "int"
            inline constexpr std::uintptr_t CompensationCryptoCoins = 0x28; // "int"
            inline constexpr std::uintptr_t ImprisonmentYearsRequired = 0x2C; // "int"
            inline constexpr std::uintptr_t IsHidden = 0x30; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_HasPrice = 0x4406310; // "public bool get_HasPrice()"
            inline constexpr std::uintptr_t get_BuyParams = 0x446FF40; // "public ValueTuple<int, int> get_BuyParams()"
        }
    } // namespace CharacterKeychainDescription

    namespace CharacterKeychainMeshesContent { // "Game.Global.SkinCenter.ViewDescriptions.Character.Contents.CharacterKeychainMeshesContent (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t RingMeshes = 0x18; // "Mesh[]"
            inline constexpr std::uintptr_t ChainMeshes = 0x20; // "Mesh[]"
        }
    } // namespace CharacterKeychainMeshesContent

    namespace CharacterLaunderingConfig { // "Models.References.CharacterLaundering.CharacterLaunderingConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Period = 0x10; // "long"
            inline constexpr std::uintptr_t DirtyCashPerPeriod = 0x18; // "int"
            inline constexpr std::uintptr_t DirtyToCleanCashModifier = 0x1C; // "float"
            inline constexpr std::uintptr_t MaxDirtyCashAmount = 0x20; // "int"
        }
    } // namespace CharacterLaunderingConfig

    namespace CharacterLaunderingData { // "Models.Data.CharacterLaunderingData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t DirtyAmount = 0x20; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t CleanAmount = 0x28; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t LastTickTs = 0x30; // "IPrimitiveData<long>"
        }
    } // namespace CharacterLaunderingData

    namespace CharacterLaunderingInventoryItemsSearchSource { // "Models.Inventory.InventoryItemsSearch.Sources.CharacterLaunderingInventoryItemsSearchSource (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t CharacterLaundering = 0x0; // "CharacterLaunderingModel"
            inline constexpr std::uintptr_t State = 0x8; // "LaunderingState"
        }
    } // namespace CharacterLaunderingInventoryItemsSearchSource

    namespace CharacterLaunderingModel { // "Models.Models.CharacterLaundering.CharacterLaunderingModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "CharacterLaunderingData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_DirtyAmount = 0x497BCE0; // "public int get_DirtyAmount()"
            inline constexpr std::uintptr_t get_CleanAmount = 0x497BC90; // "public int get_CleanAmount()"
            inline constexpr std::uintptr_t get_LastTickTs = 0x497BD30; // "public long get_LastTickTs()"
            inline constexpr std::uintptr_t Set = 0x497BBD0; // "public void Set(int dirtyAmount, int cleanAmount, long lastTickTs)"
            inline constexpr std::uintptr_t Clear = 0x497BAF0; // "public void Clear()"
        }
    } // namespace CharacterLaunderingModel

    namespace CharacterLaunderingRules { // "Models.Models.LaunderingRules.CharacterLaunderingRules (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t GetState = 0x492D260; // "public static LaunderingState GetState(long now, CharacterLaunderingModel model, VipModel vipModel)"
            inline constexpr std::uintptr_t GetStateInternal = 0x492D190; // "private static LaunderingState GetStateInternal(long toTs, LaunderingState state, int dirtyByPeriodModifier)"
            inline constexpr std::uintptr_t RefreshState = 0x492D6C0; // "public static void RefreshState(long now, CharacterLaunderingModel model, VipModel vipModel)"
            inline constexpr std::uintptr_t AddDirtyAmount = 0x492D0A0; // "public static LaunderingState AddDirtyAmount(long now, int amount, CharacterLaunderingModel model, VipModel vipModel)"
            inline constexpr std::uintptr_t LimitCalcClearCash = 0x492D650; // "public static int LimitCalcClearCash(int dirtyAmount)"
            inline constexpr std::uintptr_t GetTimeToFullyLaunder = 0x492D520; // "public static long GetTimeToFullyLaunder(int dirtyAmount, VipModel vipModel, long now)"
        }
    } // namespace CharacterLaunderingRules

    namespace CharacterLimbComponentsEnableUpdater { // "Game.Battle.Entities.BattleCharacter.Animations.CharacterLimbComponentsEnableUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t entityView = 0x10; // "BattleCharacterEntityView"
            inline constexpr std::uintptr_t serverModel = 0x18; // "BattleCharacterModel"
            inline constexpr std::uintptr_t areLimbsEnabled = 0x20; // "Nullable<bool>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xBEAC20; // "public void Update()"
            inline constexpr std::uintptr_t EnableLimbComponents = 0xBEABC0; // "private void EnableLimbComponents(bool isLimbIKEnabled)"
        }
    } // namespace CharacterLimbComponentsEnableUpdater

    namespace CharacterMainMenuExitModel { // "Models.Models.CharacterMainMenuExit.CharacterMainMenuExitModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ts = 0x10; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t exitReasonDescription = 0x18; // "IPrimitiveData<MainMenuExitReasonDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsActive = 0x497BFB0; // "public bool get_IsActive()"
            inline constexpr std::uintptr_t get_Reason = 0x497C030; // "public MainMenuExitReasonDescription get_Reason()"
            inline constexpr std::uintptr_t get_Ts = 0x497C0F0; // "public long get_Ts()"
            inline constexpr std::uintptr_t Set = 0x497BEB0; // "public void Set(long ts, MainMenuExitReasonDescription reason)"
            inline constexpr std::uintptr_t Clear = 0x497BD80; // "public void Clear()"
        }
    } // namespace CharacterMainMenuExitModel

    namespace CharacterMarkDescription { // "Models.References.Character.Customizer.CharacterMarkDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsHidden = 0x20; // "bool"
        }
    } // namespace CharacterMarkDescription

    namespace CharacterMarkTexturesContent { // "Game.Global.SkinCenter.ViewDescriptions.Character.Contents.CharacterMarkTexturesContent (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Texture = 0x18; // "Texture2D"
            inline constexpr std::uintptr_t NormalMap = 0x20; // "Texture2D"
            inline constexpr std::uintptr_t MaskMap = 0x28; // "Texture2D"
        }
    } // namespace CharacterMarkTexturesContent

    namespace CharacterMaskContent { // "Game.Global.SkinCenter.ViewDescriptions.Character.Contents.CharacterMaskContent (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Materials = 0x18; // "Material[]"
            inline constexpr std::uintptr_t Lods = 0x20; // "Mesh[]"
        }
    } // namespace CharacterMaskContent

    namespace CharacterMaskDescription { // "Models.References.Character.Customizer.CharacterMaskDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsAvailable = 0x20; // "bool"
            inline constexpr std::uintptr_t CryptoCoinsPrice = 0x24; // "int"
            inline constexpr std::uintptr_t CompensationCryptoCoins = 0x28; // "int"
            inline constexpr std::uintptr_t ImprisonmentYearsRequired = 0x2C; // "int"
            inline constexpr std::uintptr_t IsHidden = 0x30; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_HasPrice = 0x4406310; // "public bool get_HasPrice()"
            inline constexpr std::uintptr_t get_BuyParams = 0x4470770; // "public ValueTuple<int, int> get_BuyParams()"
        }
    } // namespace CharacterMaskDescription

    namespace CharacterMeshLodsContent { // "Game.Global.SkinCenter.ViewDescriptions.Character.Contents.CharacterMeshLodsContent (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Lods = 0x18; // "Mesh[]"
        }
    } // namespace CharacterMeshLodsContent

    namespace CharacterMovementAnimationUpdater { // "Game.Battle.EntityModel.BattleCharacter.Movement.CharacterMovementAnimationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t animationView = 0x10; // "IVelocityAnimationView"
            inline constexpr std::uintptr_t relativeVelocity = 0x18; // "CharacterRelativeVelocityModel"
            inline constexpr std::uintptr_t blendArgs = 0x20; // "BlendArgs"
            inline constexpr std::uintptr_t armedModel = 0x28; // "ArmedModel"
            inline constexpr std::uintptr_t currentVelocity = 0x30; // "Vector2"
            inline constexpr std::uintptr_t smoothDampVelocity = 0x38; // "Vector2"
            inline constexpr std::uintptr_t lastVelocityX = 0x40; // "float"
            inline constexpr std::uintptr_t lastVelocityY = 0x44; // "float"
            inline constexpr std::uintptr_t acceleration = 0x48; // "float"
            inline constexpr std::uintptr_t isArmed = 0x4C; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xCCEA50; // "public void Update()"
        }
    } // namespace CharacterMovementAnimationUpdater

    namespace CharacterMovementIntentionAnimationUpdater { // "Game.Battle.Entities.BattleCharacter.Updaters.CharacterMovementIntentionAnimationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t hasMovementIntention = 0x10; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t becomeRobberModel = 0x18; // "BecomeRobberModel"
            inline constexpr std::uintptr_t characterAnimationView = 0x20; // "CharacterAnimationView"
            inline constexpr std::uintptr_t isInitialized = 0x28; // "bool"
            inline constexpr std::uintptr_t isActive = 0x29; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xBC71C0; // "public void Update()"
        }
    } // namespace CharacterMovementIntentionAnimationUpdater

    namespace CharacterMovementIntentionDirectionModel { // "Game.Battle.EntityModel.BattleCharacter.Movement.CharacterMovementIntentionDirectionModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t HasDirection = 0x10; // "bool"
            inline constexpr std::uintptr_t Direction = 0x14; // "Vector2"
        }
    } // namespace CharacterMovementIntentionDirectionModel

    namespace CharacterMovementModeAnimationUpdater { // "Game.Battle.EntityModel.BattleCharacter.CharacterMovementModeAnimationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t animationView = 0x10; // "CharacterAnimationView"
            inline constexpr std::uintptr_t crouchModel = 0x18; // "CharacterCrouchModel"
            inline constexpr std::uintptr_t relativeVelocityModel = 0x20; // "CharacterRelativeVelocityModel"
            inline constexpr std::uintptr_t battleCharacterConfig = 0x28; // "BattleCharacterConfig"
            inline constexpr std::uintptr_t isSprintingModel = 0x30; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t armedModel = 0x38; // "ArmedModel"
            inline constexpr std::uintptr_t moveMode = 0x40; // "Vector2"
            inline constexpr std::uintptr_t sprint = 0x48; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xCC26E0; // "public void Update()"
        }
    } // namespace CharacterMovementModeAnimationUpdater

    namespace CharacterMoveSpeedAnimationUpdater { // "Game.Battle.Entities.BattleCharacter.Updaters.CharacterMoveSpeedAnimationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t animationView = 0x10; // "CharacterAnimationView"
            inline constexpr std::uintptr_t stateModel = 0x18; // "IBattleCharacterStateModel"
            inline constexpr std::uintptr_t config = 0x20; // "BattleCharacterConfig"
            inline constexpr std::uintptr_t viewDescription = 0x28; // "BattleCharacterViewDescription"
            inline constexpr std::uintptr_t isInKnockout = 0x30; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xBC6FE0; // "public void Update()"
            inline constexpr std::uintptr_t IsKnockOut = 0xBC6F90; // "private bool IsKnockOut()"
            inline constexpr std::uintptr_t CalculateKnockoutSpeedModifier = 0xBC6F40; // "private float CalculateKnockoutSpeedModifier()"
        }
    } // namespace CharacterMoveSpeedAnimationUpdater

    namespace CharacterOverlayModel { // "Game.Battle.CharacterOverlayModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t slotModel = 0x10; // "BattleCharacterSlotModel"
            inline constexpr std::uintptr_t UserType = 0x18; // "UserColorType"
            inline constexpr std::uintptr_t Status = 0x1C; // "CharacterStatus"
            inline constexpr std::uintptr_t StatusEndTs = 0x20; // "long"
            inline constexpr std::uintptr_t StatusDuration = 0x28; // "long"
            inline constexpr std::uintptr_t BribeAmount = 0x30; // "int"
            inline constexpr std::uintptr_t Position = 0x34; // "Vector3"
            inline constexpr std::uintptr_t InScreen = 0x40; // "bool"
            inline constexpr std::uintptr_t AnchoredPosition = 0x44; // "Vector2"
            inline constexpr std::uintptr_t VisibleState = 0x4C; // "CharacterOverlayStatView.VisibleState"
            inline constexpr std::uintptr_t IsVisible = 0x50; // "bool"
            inline constexpr std::uintptr_t IsNicknameVisible = 0x51; // "bool"
            inline constexpr std::uintptr_t IsIndicatorVisible = 0x52; // "bool"
            inline constexpr std::uintptr_t IsVoiceIndicatorVisible = 0x53; // "bool"
            inline constexpr std::uintptr_t IsStatusVisible = 0x54; // "bool"
            inline constexpr std::uintptr_t NicknameContainerAlpha = 0x58; // "float"
            inline constexpr std::uintptr_t IsInNicknameDistance = 0x5C; // "bool"
            inline constexpr std::uintptr_t IsInClanMemberIndicatorDistance = 0x5D; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_PublicId = 0xA4F030; // "public long get_PublicId()"
            inline constexpr std::uintptr_t get_Nickname = 0xA4F010; // "public string get_Nickname()"
            inline constexpr std::uintptr_t get_ClanTag = 0xA4EFB0; // "public string get_ClanTag()"
        }
    } // namespace CharacterOverlayModel

    namespace CharacterOverlayModelUpdater { // "Game.Battle.Entities.BattleCharacter.Stats.Updaters.CharacterOverlayModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t globalModel = 0x10; // "GlobalModel"
            inline constexpr std::uintptr_t battleModel = 0x18; // "BattleModel"
            inline constexpr std::uintptr_t hideObjectViewDescriptions = 0x20; // "HideObjectViewDescriptions"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xBD5F70; // "public void Update()"
            inline constexpr std::uintptr_t UpdatePositionAndStatus = 0xBD5B40; // "private void UpdatePositionAndStatus(BattleCharacterSlotModel slotModel, CharacterOverlayModel model)"
            inline constexpr std::uintptr_t UpdateUserType = 0xBD5E10; // "private void UpdateUserType(BattleCharacterSlotModel slotModel, CharacterOverlayModel model)"
            inline constexpr std::uintptr_t UpdatePositionAndStatusFromPartyMember = 0xBD55B0; // "private void UpdatePositionAndStatusFromPartyMember(CharacterOverlayModel model, IMemberBattleDataModel characterInfo, PartyMemberModel partyMemberModel, IEntityModel entityModel)"
            inline constexpr std::uintptr_t UpdatePositionAndStatusFromEntity = 0xBD5440; // "private void UpdatePositionAndStatusFromEntity(CharacterOverlayModel model, CharacterClientModel clientModel, BattleCharacterModel battleCharacterModel, InVehicleModel warpInVehicleModel)"
            inline constexpr std::uintptr_t GetWarpInVehicleModel = 0xBD5410; // "private static InVehicleModel GetWarpInVehicleModel(BattleCharacterEntityModel characterEntityModel)"
            inline constexpr std::uintptr_t GetOverlayPosition = 0xBD5250; // "private Vector3 GetOverlayPosition(IPositionModel positionModel, PhysicsCharacterConfig physicsCharacter, CharacterStatus status, bool isKnockedOut, float crouch, bool isInVehicle)"
        }
    } // namespace CharacterOverlayModelUpdater

    namespace CharacterOverlayVisibleModelUpdater { // "Game.Battle.Entities.BattleCharacter.Stats.Updaters.CharacterOverlayVisibleModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t partyModel = 0x10; // "PartyModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x18; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t charactersInVehiclesModel = 0x20; // "CharacterInVehiclesModel"
            inline constexpr std::uintptr_t clanBattleTeamsCacheModel = 0x28; // "ClanBattleTeamsCacheModel"
            inline constexpr std::uintptr_t battleCharacterSlotsModel = 0x30; // "BattleCharacterSlotsModel"
            inline constexpr std::uintptr_t overlayModel = 0x38; // "OverlayModel"
            inline constexpr std::uintptr_t aimTargetModel = 0x40; // "AimTargetModel"
            inline constexpr std::uintptr_t battleSettingsDescription = 0x48; // "BattleSettingsDescription"
            inline constexpr std::uintptr_t voiceChatBattleRoomModel = 0x50; // "VoiceChatBattleRoomModel"
            inline constexpr std::uintptr_t cinemachineBrain = 0x58; // "CinemachineBrain"
            inline constexpr std::uintptr_t weaponViewDescriptions = 0x60; // "WeaponViewDescriptions"
            inline constexpr std::uintptr_t characterRoleViewDescriptions = 0x68; // "CharacterRoleViewDescriptions"
            inline constexpr std::uintptr_t clanModel = 0x70; // "ClanModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xBDA100; // "public void Update()"
            inline constexpr std::uintptr_t UpdateOverlayModel = 0xBD9A20; // "private void UpdateOverlayModel(CharacterOverlayModel overlayModel, BattleCharacterSlotModel item)"
            inline constexpr std::uintptr_t GetOverlayIsVisible = 0xBD8CF0; // "private bool GetOverlayIsVisible(CharacterOverlayModel overlayModel, BattleCharacterModel player, BattleCharacterEntityModel characterEntityModel, VoiceChatRoomParticipantModel voiceChatParticipantModel)"
            inline constexpr std::uintptr_t IsClanBattleAlly = 0xBD9100; // "private bool IsClanBattleAlly(PlayerRoleDescription playerRole, BattleCharacterSlotDescription slot)"
            inline constexpr std::uintptr_t IsClanMemberIndicatorVisible = 0xBD91B0; // "private bool IsClanMemberIndicatorVisible(CharacterOverlayModel overlayModel, BattleCharacterEntityModel characterEntityModel)"
            inline constexpr std::uintptr_t IsInAimTarget = 0xBD92C0; // "private bool IsInAimTarget(int characterId)"
            inline constexpr std::uintptr_t IsHiddenFromPlayer = 0xBD9230; // "private bool IsHiddenFromPlayer(BattleCharacterEntityModel character)"
            inline constexpr std::uintptr_t OverlayIsVisibleByStatus = 0xBD96B0; // "private bool OverlayIsVisibleByStatus(CharacterStatus status, PlayerRoleDescription playerRole, PlayerRoleDescription targetRole, BattleCharacterSlotDescription targetSlot)"
            inline constexpr std::uintptr_t CanShowStatusByKnockout = 0xBD8B90; // "private bool CanShowStatusByKnockout(PlayerRoleDescription playerRole, PlayerRoleDescription targetRole, BattleCharacterSlotDescription targetSlot)"
            inline constexpr std::uintptr_t IsVisibleThroughWall = 0xBD9620; // "private bool IsVisibleThroughWall(BattleCharacterEntityModel battleCharacterEntityModel, PlayerRoleDescription playerRole)"
            inline constexpr std::uintptr_t UpdateDistanceVisibility = 0xBD98F0; // "private void UpdateDistanceVisibility(CharacterOverlayModel overlayModel, BattleCharacterModel player, BattleCharacterModel battleCharacterModel)"
            inline constexpr std::uintptr_t IsReachableByRaycast = 0xBD9310; // "private bool IsReachableByRaycast(BattleCharacterModel playerServerModel, BattleCharacterEntityModel characterEntityModel)"
        }
    } // namespace CharacterOverlayVisibleModelUpdater

    namespace CharacterProgressLootAnimationUpdater { // "Game.Battle.EntityModel.BattleCharacter.CharacterProgressLootAnimationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t characterModel = 0x18; // "BattleCharacterModel"
            inline constexpr std::uintptr_t prolongedInteractionModel = 0x20; // "ProlongedInteractionModel"
            inline constexpr std::uintptr_t animationView = 0x28; // "CharacterAnimationView"
            inline constexpr std::uintptr_t worldEntitiesModel = 0x30; // "WorldEntitiesModel"
            inline constexpr std::uintptr_t now = 0x38; // "INow"
            inline constexpr std::uintptr_t endTs = 0x40; // "long"
            inline constexpr std::uintptr_t isActive = 0x48; // "bool"
            inline constexpr std::uintptr_t isBagVisible = 0x49; // "bool"
            inline constexpr std::uintptr_t isUnlocking = 0x4A; // "bool"
            inline constexpr std::uintptr_t isSearchingTrash = 0x4B; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t InnerStart = 0xCD0480; // "protected override void InnerStart()"
            inline constexpr std::uintptr_t InnerUpdate = 0xCD0480; // "protected override void InnerUpdate()"
            inline constexpr std::uintptr_t InnerStop = 0xCD04D0; // "protected override void InnerStop()"
            inline constexpr std::uintptr_t UpdateByActive = 0xCD0550; // "private void UpdateByActive(bool isActive)"
            inline constexpr std::uintptr_t StopLootingWithoutBag = 0xCD0540; // "private void StopLootingWithoutBag()"
            inline constexpr std::uintptr_t UpdateLootingWithoutBag = 0xCD0940; // "private void UpdateLootingWithoutBag(bool isActive)"
            inline constexpr std::uintptr_t StopLootingWithBag = 0xCD0510; // "private void StopLootingWithBag()"
            inline constexpr std::uintptr_t UpdateLootingWithBag = 0xCD07A0; // "private void UpdateLootingWithBag(bool isActive)"
            inline constexpr std::uintptr_t IsActive = 0xCD04E0; // "private bool IsActive()"
            inline constexpr std::uintptr_t GetTakeTime = 0xCD0150; // "private long GetTakeTime()"
        }
    } // namespace CharacterProgressLootAnimationUpdater

    namespace CharacterRelativeVelocityModel { // "Game.Battle.EntityModel.BattleCharacter.Movement.CharacterRelativeVelocityModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t RelativeVelocity = 0x10; // "float"
            inline constexpr std::uintptr_t DirectionX = 0x14; // "float"
            inline constexpr std::uintptr_t DirectionY = 0x18; // "float"
        }
    } // namespace CharacterRelativeVelocityModel

    namespace CharacterReloadingAnimationUpdater { // "Game.Battle.Entities.Player.Reload.CharacterReloadingAnimationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t reloadingModel = 0x10; // "CharacterReloadingModel"
            inline constexpr std::uintptr_t animationView = 0x18; // "CharacterAnimationView"
            inline constexpr std::uintptr_t selectedWeaponModel = 0x20; // "SelectedWeaponModel"
            inline constexpr std::uintptr_t animationStateAssistant = 0x28; // "AnimationStateAssistant"
            inline constexpr std::uintptr_t isReloading = 0x30; // "bool"
            inline constexpr std::uintptr_t wasReloading = 0x31; // "bool"
            inline constexpr std::uintptr_t startTime = 0x34; // "float"
            inline constexpr std::uintptr_t startCastIndex = 0x38; // "int"
            inline constexpr std::uintptr_t castIndex = 0x3C; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB1BA50; // "public void Update()"
            inline constexpr std::uintptr_t DelayReloadingUntilOverrideLayerFinishItsWork = 0xB1B940; // "private void DelayReloadingUntilOverrideLayerFinishItsWork(ref bool isReloading, ref float progress, ref int castIndex)"
        }
    } // namespace CharacterReloadingAnimationUpdater

    namespace CharacterReloadingModel { // "Game.Battle.EntityModel.BattleCharacter.Reloading.CharacterReloadingModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Weapon = 0x10; // "WeaponDescription"
            inline constexpr std::uintptr_t IsReloadingSelectedWeapon = 0x18; // "bool"
            inline constexpr std::uintptr_t IsBackgroundReloading = 0x19; // "bool"
            inline constexpr std::uintptr_t IsReloadingBySingleBullet = 0x1A; // "bool"
            inline constexpr std::uintptr_t Progress = 0x1C; // "float"
            inline constexpr std::uintptr_t CastIndex = 0x20; // "int"
        }
    } // namespace CharacterReloadingModel

    namespace CharacterReloadingModelUpdater { // "Game.Battle.EntityModel.BattleCharacter.Reloading.CharacterReloadingModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t weaponReload = 0x10; // "WeaponReloadModel"
            inline constexpr std::uintptr_t reloadingModel = 0x18; // "CharacterReloadingModel"
            inline constexpr std::uintptr_t weaponModel = 0x20; // "IWeaponModel"
            inline constexpr std::uintptr_t isBackgroundReload = 0x28; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t stateModel = 0x30; // "IBattleCharacterStateModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xCD0C10; // "public void Update()"
        }
    } // namespace CharacterReloadingModelUpdater

    namespace CharacterReloadingProgressModelUpdater { // "Game.Battle.EntityModel.BattleCharacter.Reloading.CharacterReloadingProgressModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t weaponReload = 0x10; // "WeaponReloadModel"
            inline constexpr std::uintptr_t reloadingModel = 0x18; // "CharacterReloadingModel"
            inline constexpr std::uintptr_t now = 0x20; // "INow"
            inline constexpr std::uintptr_t endTs = 0x28; // "long"
            inline constexpr std::uintptr_t isPrecast = 0x30; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xCD0EA0; // "public void Update()"
        }
    } // namespace CharacterReloadingProgressModelUpdater

    namespace CharacterRenderersRules { // "Game.Battle.Entities.BattleCharacter.Weapon.CharacterRenderersRules (Battle.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t GetRenderVisibleMode = 0xBC8020; // "public static RendersVisibleView.Mode GetRenderVisibleMode(CharacterClientModel characterClientModel, IBattleCharacterStateModel battleCharacterStateModel)"
            inline constexpr std::uintptr_t GetRenderVisibleMode_2 = 0xBC7DB0; // "public static RendersVisibleView.Mode GetRenderVisibleMode(CharacterClientModel clientModel, BattleCharacterModel serverModel, WeaponViewDescriptions weaponViewDescriptions)"
        }
    } // namespace CharacterRenderersRules

    namespace CharacterReplicatedTransformModel { // "Models.Models.CharacterReplicatedTransform.CharacterReplicatedTransformModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t position = 0x10; // "IPrimitiveData<Vector3>"
            inline constexpr std::uintptr_t rx = 0x18; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t ry = 0x20; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t rz = 0x28; // "IPrimitiveData<float>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Position = 0x497C1B0; // "public Vector3 get_Position()"
            inline constexpr std::uintptr_t set_Position = 0x497C370; // "public void set_Position(Vector3 value)"
            inline constexpr std::uintptr_t get_Rx = 0x497C280; // "public float get_Rx()"
            inline constexpr std::uintptr_t get_Ry = 0x497C2D0; // "public float get_Ry()"
            inline constexpr std::uintptr_t get_Rz = 0x497C320; // "public float get_Rz()"
            inline constexpr std::uintptr_t SetRotation = 0x497C140; // "public void SetRotation(float rx, float ry, float rz)"
        }
    } // namespace CharacterReplicatedTransformModel

    namespace CharacterRotationModel { // "Game.Global.Character.CharacterRotationModel (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t LookRotation = 0x10; // "Quaternion"
            inline constexpr std::uintptr_t LookYaw = 0x20; // "float"
            inline constexpr std::uintptr_t Yaw = 0x24; // "float"
            inline constexpr std::uintptr_t Pitch = 0x28; // "float"
            inline constexpr std::uintptr_t Roll = 0x2C; // "float"
        }
    } // namespace CharacterRotationModel

    namespace CharacterRotationModel_2 { // "Game.Global.CustomizeScene.CharacterRotationModel (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t rotationModel = 0x10; // "CustomizeSceneRotationModel"
            inline constexpr std::uintptr_t rotationView = 0x18; // "ICustomizeSceneRotationView"
        }
        namespace Methods {
            inline constexpr std::uintptr_t TryGetCharacterRotation = 0x35F31A0; // "public bool TryGetCharacterRotation(out CustomizeSceneRotationModel rotationModel, out ICustomizeSceneRotationView rotationView)"
            inline constexpr std::uintptr_t SetCharacterRotation = 0xBFBA40; // "public void SetCharacterRotation(CustomizeSceneRotationModel rotationModel, ICustomizeSceneRotationView rotationView)"
        }
    } // namespace CharacterRotationModel_2

    namespace CharacterRouletteRewardModel { // "Models.Models.Roulette.CharacterRouletteRewardModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t CharacterRouletteReward = 0x10; // "IPrimitiveModel<int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_HasReward = 0x48D0DF0; // "public bool get_HasReward()"
        }
    } // namespace CharacterRouletteRewardModel

    namespace CharacterSelectedItemIndexAnimationUpdater { // "Game.Battle.EntityModel.BattleCharacter.Equipment.CharacterSelectedItemIndexAnimationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t animationView = 0x18; // "CharacterAnimationView"
            inline constexpr std::uintptr_t viewDescriptions = 0x20; // "InventoryItemViewDescriptions"
            inline constexpr std::uintptr_t selectedItemModel = 0x28; // "SelectedItemModel"
            inline constexpr std::uintptr_t item = 0x30; // "InventoryItemDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t InnerUpdate = 0xCD14F0; // "protected override void InnerUpdate()"
            inline constexpr std::uintptr_t InnerStart = 0xCD14B0; // "protected override void InnerStart()"
            inline constexpr std::uintptr_t InnerStop = 0x7B3360; // "protected override void InnerStop()"
            inline constexpr std::uintptr_t GetIndex = 0xCD1430; // "private int GetIndex(InventoryItemDescription item)"
        }
    } // namespace CharacterSelectedItemIndexAnimationUpdater

    namespace CharacterSelectedItemModelUpdater { // "Game.Battle.Entities.BattleCharacter.Updaters.CharacterSelectedItemModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t itemInHands = 0x10; // "IInventoryItemModel"
            inline constexpr std::uintptr_t quickSlotSelectProgress = 0x18; // "QuickSlotSelectProgressModel"
            inline constexpr std::uintptr_t selectedItem = 0x20; // "SelectedItemModel"
            inline constexpr std::uintptr_t now = 0x28; // "INow"
            inline constexpr std::uintptr_t stateModel = 0x30; // "IBattleCharacterStateModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xBC8340; // "public void Update()"
            inline constexpr std::uintptr_t TakeInTime = 0xBC8130; // "private long TakeInTime(InventoryItemDescription itemDescription)"
        }
    } // namespace CharacterSelectedItemModelUpdater

    namespace CharacterSetArrestedAnimationUpdater { // "Game.Battle.EntityModel.BattleCharacter.CharacterSetArrestedAnimationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t viewAnimationView = 0x10; // "CharacterAnimationView"
            inline constexpr std::uintptr_t battleCharacterModel = 0x18; // "BattleCharacterModel"
            inline constexpr std::uintptr_t arrestTargetModel = 0x20; // "ArrestTargetModel"
            inline constexpr std::uintptr_t now = 0x28; // "INow"
            inline constexpr std::uintptr_t isArrestingActive = 0x30; // "bool"
            inline constexpr std::uintptr_t isGettingArrestedActive = 0x31; // "bool"
            inline constexpr std::uintptr_t isGettingUpActive = 0x32; // "bool"
            inline constexpr std::uintptr_t isKnockedOut = 0x33; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xCC2DB0; // "public void Update()"
            inline constexpr std::uintptr_t ResolveGettingUp = 0xCC2CA0; // "private void ResolveGettingUp()"
            inline constexpr std::uintptr_t ResolveArresting = 0xCC2AA0; // "private void ResolveArresting()"
            inline constexpr std::uintptr_t ResolveGettingArrested = 0xCC2B10; // "private void ResolveGettingArrested()"
        }
    } // namespace CharacterSetArrestedAnimationUpdater

    namespace CharacterSexDescription { // "Models.References.Character.Customizer.CharacterSexDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x81C4800; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t enum_id = 0x0; // "Enum<CharacterSexDescription>"
            inline constexpr std::uintptr_t Male = 0x8; // "CharacterSexDescription"
            inline constexpr std::uintptr_t Female = 0x10; // "CharacterSexDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Enum = 0x44709E0; // "public static ReadOnlyEnum<CharacterSexDescription> get_Enum()"
        }
    } // namespace CharacterSexDescription

    namespace CharacterSexModel { // "Game.Battle.EntityModel.BattleCharacter.Customize.CharacterSexModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t customizationModel = 0x10; // "ICustomizationModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Sex = 0xCE3170; // "public CharacterSexDescription get_Sex()"
        }
    } // namespace CharacterSexModel

    namespace CharacterShadowModel { // "Game.Global.SkinCenter.CharacterShadow.CharacterShadowModel (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ShadowCastingMode = 0x10; // "ShadowCastingMode"
        }
    } // namespace CharacterShadowModel

    namespace CharacterShowGlassBreakerUpdater { // "Game.Battle.Entities.BattleCharacter.Weapon.CharacterShowGlassBreakerUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t animationStateAssistant = 0x10; // "AnimationStateAssistant"
            inline constexpr std::uintptr_t glassBreakerTemplate = 0x18; // "IComponentInstantiateContent<Transform>"
            inline constexpr std::uintptr_t parent = 0x20; // "Transform"
            inline constexpr std::uintptr_t glassBreaker = 0x28; // "IDisposableContent<Transform>"
            inline constexpr std::uintptr_t isVisible = 0x30; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xBCAAC0; // "public void Update()"
        }
    } // namespace CharacterShowGlassBreakerUpdater

    namespace CharacterSlotsModelUpdater { // "ClientCore.CharacterSlotsModel.CharacterSlotsModelUpdater (Client.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleCharacterSlotsModel = 0x10; // "BattleCharacterSlotsModel"
            inline constexpr std::uintptr_t characterSlotsModel = 0x18; // "ClientCharacterSlotsModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xE80100; // "public void Update()"
        }
    } // namespace CharacterSlotsModelUpdater

    namespace CharacterSpeed { // "Models.References.Character.CharacterSpeed (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t SprintForwardSpeed = 0x10; // "float"
            inline constexpr std::uintptr_t SprintSideSpeed = 0x14; // "float"
            inline constexpr std::uintptr_t StandForwardSpeed = 0x18; // "float"
            inline constexpr std::uintptr_t StandSideSpeed = 0x1C; // "float"
            inline constexpr std::uintptr_t StandBackSpeed = 0x20; // "float"
            inline constexpr std::uintptr_t StandAimedSpeed = 0x24; // "float"
            inline constexpr std::uintptr_t CrouchSpeed = 0x28; // "float"
            inline constexpr std::uintptr_t CrouchAimedSpeed = 0x2C; // "float"
            inline constexpr std::uintptr_t SurrenderedSpeed = 0x30; // "float"
            inline constexpr std::uintptr_t SwimmingSpeed = 0x34; // "float"
        }
    } // namespace CharacterSpeed

    namespace CharacterSpeedModel { // "Models.Models.CharacterSpeed.CharacterSpeedModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleCharacterConfig = 0x10; // "BattleCharacterConfig"
            inline constexpr std::uintptr_t weaponModel = 0x18; // "IWeaponModel"
            inline constexpr std::uintptr_t usableItemModel = 0x20; // "UsableItemModel"
            inline constexpr std::uintptr_t throwableItemModel = 0x28; // "ThrowableItemModel"
            inline constexpr std::uintptr_t itemActionProcessModel = 0x30; // "ItemActionProcessModel"
            inline constexpr std::uintptr_t characterControllerState = 0x38; // "IPrimitiveModel<CharacterControllerStateDescription>"
            inline constexpr std::uintptr_t cargoModel = 0x40; // "CharacterCargoModel"
            inline constexpr std::uintptr_t stateModel = 0x48; // "IBattleCharacterStateModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Get = 0x497CA70; // "public CharacterSpeed Get()"
        }
    } // namespace CharacterSpeedModel

    namespace CharactersRuntimeModelsExtensions { // "ClientCore.Extensions.CharactersRuntimeModelsExtensions (Client.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t UpdateCharacterByVehicleSeat = 0xE80880; // "public static void UpdateCharacterByVehicleSeat(BattleCharacterModel battleCharacterModel, Vector3 seatWorldPosition, Quaternion seatWorldOrientation)"
            inline constexpr std::uintptr_t UpdateCharacterByReplicatedData = 0xE806D0; // "public static void UpdateCharacterByReplicatedData(BattleCharacterModel battleCharacterModel)"
            inline constexpr std::uintptr_t SetPositionAndOrientation = 0xE80590; // "private static void SetPositionAndOrientation(in Vector3 position, float rx, float ry, float rz, ITransformModel transform)"
            inline constexpr std::uintptr_t SetLookDirection = 0xE804A0; // "private static void SetLookDirection(in Vector3 value, LookDirectionModel lookDirection)"
            inline constexpr std::uintptr_t UpdateCharacterEmotionByReplicatedData = 0xE808F0; // "public static void UpdateCharacterEmotionByReplicatedData(BattleCharacterModel battleCharacterModel, ContentCacheModel contentCacheModel)"
        }
    } // namespace CharactersRuntimeModelsExtensions

    namespace CharacterStateAnimationModelUpdater { // "Game.Battle.EntityModel.Player.CharacterStateAnimationModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t characterControllerState = 0x10; // "IPrimitiveModel<CharacterControllerStateDescription>"
            inline constexpr std::uintptr_t hiddenStateModel = 0x18; // "ICharacterHiddenStateModel"
            inline constexpr std::uintptr_t stateAnimationModel = 0x20; // "StateAnimationModel"
            inline constexpr std::uintptr_t skeletonDeformationConfig = 0x28; // "BattleCharacterSkeletonDeformationConfig"
            inline constexpr std::uintptr_t animatorModel = 0x30; // "BattleCharacterAnimatorModel"
            inline constexpr std::uintptr_t hitBoxAccessModel = 0x38; // "IHitBoxAccessModel"
            inline constexpr std::uintptr_t battleModeDescription = 0x40; // "BattleModeDescription"
            inline constexpr std::uintptr_t timeFalling = 0x48; // "IPrimitiveModel<long>"
            inline constexpr std::uintptr_t fallingGroup = 0x50; // "HashSet<BattleCharacterAnimatorStateDescription>"
            inline constexpr std::uintptr_t swimmingGroup = 0x58; // "HashSet<BattleCharacterAnimatorStateDescription>"
            inline constexpr std::uintptr_t jumpingGroup = 0x60; // "HashSet<BattleCharacterAnimatorStateDescription>"
            inline constexpr std::uintptr_t oldState = 0x68; // "CharacterControllerStateDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC36830; // "public void Update()"
            inline constexpr std::uintptr_t GetControllerState = 0xC36510; // "private CharacterAnimationView.State GetControllerState()"
            inline constexpr std::uintptr_t GetAnimatorState = 0xC36400; // "private CharacterAnimationView.State GetAnimatorState()"
        }
    } // namespace CharacterStateAnimationModelUpdater

    namespace CharacterStateAnimationUpdater { // "Game.Battle.EntityModel.BattleCharacter.CharacterStateAnimationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t animationView = 0x10; // "CharacterAnimationView"
            inline constexpr std::uintptr_t stateAnimationModel = 0x18; // "StateAnimationModel"
            inline constexpr std::uintptr_t state = 0x20; // "CharacterAnimationView.State"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xCD1820; // "public void Update()"
        }
    } // namespace CharacterStateAnimationUpdater

    namespace CharacterStatusRules { // "Game.Battle.Entities.BattleCharacter.Stats.CharacterStatusRules (Battle.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t GetPartyMemberStatus = 0xBDBC40; // "public static CharacterStatus GetPartyMemberStatus(IMemberBattleDataModel characterInfo, bool hasBribeOffer, out long endTs)"
            inline constexpr std::uintptr_t GetCharacterStatus = 0xBDB920; // "public static CharacterStatus GetCharacterStatus(BattleCharacterModel model, out long endTs)"
            inline constexpr std::uintptr_t IsReviveEndsFirst = 0xBDC000; // "private static bool IsReviveEndsFirst(long reviveEndTs, bool isHandcuff, bool isArresting, long arrestEndTs)"
            inline constexpr std::uintptr_t GetCharacterStatusDuration = 0xBDB6F0; // "public static long GetCharacterStatusDuration(CharacterStatus status)"
            inline constexpr std::uintptr_t UpdateStatus = 0xBDC010; // "public static void UpdateStatus(CharacterOverlayStatView view, CharacterStatus status, long duration, long endTs, INow now)"
            inline constexpr std::uintptr_t GetStatusOffset = 0xBDBEF0; // "public static float GetStatusOffset(CharacterStatus status, bool isKnockedOut, PhysicsCharacterConfig physicsCharacter, float crouch, bool isInVehicle)"
        }
    } // namespace CharacterStatusRules

    namespace CharacterSuspendedAfflictionAnimationUpdater { // "Game.Battle.Entities.BattleCharacter.Affliction.CharacterSuspendedAfflictionAnimationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t animationView = 0x18; // "CharacterAnimationView"
            inline constexpr std::uintptr_t assistant = 0x20; // "AnimationStateAssistant"
            inline constexpr std::uintptr_t reloading = 0x28; // "CharacterReloadingModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t InnerUpdate = 0xBEC190; // "protected override void InnerUpdate()"
            inline constexpr std::uintptr_t InnerStart = 0x7B3360; // "protected override void InnerStart()"
            inline constexpr std::uintptr_t InnerStop = 0xBEC160; // "protected override void InnerStop()"
        }
    } // namespace CharacterSuspendedAfflictionAnimationUpdater

    namespace CharacterTakeItemAnimationUpdater { // "Game.Battle.EntityModel.BattleCharacter.Equipment.CharacterTakeItemAnimationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t animationView = 0x18; // "CharacterAnimationView"
            inline constexpr std::uintptr_t selectedItemModel = 0x20; // "SelectedItemModel"
            inline constexpr std::uintptr_t stateModel = 0x28; // "IBattleCharacterStateModel"
            inline constexpr std::uintptr_t oldState = 0x30; // "SelectedItemModel.State"
            inline constexpr std::uintptr_t oldItem = 0x38; // "InventoryItemDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t InnerUpdate = 0xCD20B0; // "protected override void InnerUpdate()"
            inline constexpr std::uintptr_t InnerStart = 0x7B3360; // "protected override void InnerStart()"
            inline constexpr std::uintptr_t InnerStop = 0xCD2080; // "protected override void InnerStop()"
        }
    } // namespace CharacterTakeItemAnimationUpdater

    namespace CharacterTattooCustomizationModelUpdater { // "Game.Global.SkinCenter.Customization.CharacterTattooCustomizationModelUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t customizationModel = 0x10; // "ICustomizationModel"
            inline constexpr std::uintptr_t characterCustomizationModel = 0x18; // "CharacterCustomizationModel"
            inline constexpr std::uintptr_t tattooDescription = 0x20; // "TattooDescription"
            inline constexpr std::uintptr_t tattooGradeIndex = 0x28; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x3649EE0; // "public void Update()"
        }
    } // namespace CharacterTattooCustomizationModelUpdater

    namespace CharacterTemporaryModel { // "Game.Global.SkinCenter.UI.Models.CharacterTemporaryModel (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsActive = 0x10; // "bool"
            inline constexpr std::uintptr_t skinCenterModel = 0x18; // "SkinCenterModel"
            inline constexpr std::uintptr_t VersionModel = 0x20; // "CharacterTemporaryVersionModel"
            inline constexpr std::uintptr_t SexData = 0x28; // "TemporaryEnumValue<CharacterSexDescription>"
            inline constexpr std::uintptr_t BeardData = 0x30; // "TemporaryEnumValue<CharacterBeardDescription>"
            inline constexpr std::uintptr_t BodyData = 0x38; // "TemporaryEnumValue<CharacterBodyDescription>"
            inline constexpr std::uintptr_t HairData = 0x40; // "TemporaryEnumValue<CharacterHairDescription>"
            inline constexpr std::uintptr_t HeadData = 0x48; // "TemporaryEnumValue<CharacterHeadDescription>"
            inline constexpr std::uintptr_t HairColorData = 0x50; // "TemporaryEnumValue<CharacterHairColorDescription>"
            inline constexpr std::uintptr_t HairExtraColorData = 0x58; // "TemporaryEnumValue<CharacterHairColorDescription>"
            inline constexpr std::uintptr_t EyebrowsColorData = 0x60; // "TemporaryEnumValue<CharacterHairColorDescription>"
            inline constexpr std::uintptr_t BeardColorData = 0x68; // "TemporaryEnumValue<CharacterHairColorDescription>"
            inline constexpr std::uintptr_t BeardExtraColorData = 0x70; // "TemporaryEnumValue<CharacterHairColorDescription>"
            inline constexpr std::uintptr_t SkinColorData = 0x78; // "TemporaryEnumValue<CharacterSkinColorDescription>"
            inline constexpr std::uintptr_t BagData = 0x80; // "TemporaryEnumValue<CharacterBagDescription>"
            inline constexpr std::uintptr_t MaskData = 0x88; // "TemporaryEnumValue<CharacterMaskDescription>"
            inline constexpr std::uintptr_t EyeColorData = 0x90; // "TemporaryEnumValue<CharacterEyeColorDescription>"
            inline constexpr std::uintptr_t MarkData = 0x98; // "TemporaryEnumValue<CharacterMarkDescription>"
            inline constexpr std::uintptr_t KeychainData = 0xA0; // "TemporaryEnumValue<CharacterKeychainDescription>"
            inline constexpr std::uintptr_t TattooData = 0xA8; // "TemporaryEnumValue<TattooDescription>"
            inline constexpr std::uintptr_t FBodyData = 0xB0; // "TemporaryEnumValue<CharacterFBodyDescription>"
            inline constexpr std::uintptr_t FHairData = 0xB8; // "TemporaryEnumValue<CharacterFHairDescription>"
            inline constexpr std::uintptr_t FHeadData = 0xC0; // "TemporaryEnumValue<CharacterFHeadDescription>"
            inline constexpr std::uintptr_t FHairColorData = 0xC8; // "TemporaryEnumValue<CharacterHairColorDescription>"
            inline constexpr std::uintptr_t FHairExtraColorData = 0xD0; // "TemporaryEnumValue<CharacterHairColorDescription>"
            inline constexpr std::uintptr_t FEyebrowsColorData = 0xD8; // "TemporaryEnumValue<CharacterHairColorDescription>"
            inline constexpr std::uintptr_t FSkinColorData = 0xE0; // "TemporaryEnumValue<CharacterSkinColorDescription>"
            inline constexpr std::uintptr_t FBagData = 0xE8; // "TemporaryEnumValue<CharacterBagDescription>"
            inline constexpr std::uintptr_t FMaskData = 0xF0; // "TemporaryEnumValue<CharacterMaskDescription>"
            inline constexpr std::uintptr_t FEyeColorData = 0xF8; // "TemporaryEnumValue<CharacterEyeColorDescription>"
            inline constexpr std::uintptr_t FMakeupData = 0x100; // "TemporaryEnumValue<CharacterFMakeupDescription>"
            inline constexpr std::uintptr_t FMakeupEyeColorData = 0x108; // "TemporaryEnumValue<CharacterFMakeupEyeColorDescription>"
            inline constexpr std::uintptr_t FMakeupLipColorData = 0x110; // "TemporaryEnumValue<CharacterFMakeupLipColorDescription>"
            inline constexpr std::uintptr_t FMarkData = 0x118; // "TemporaryEnumValue<CharacterFMarkDescription>"
            inline constexpr std::uintptr_t FKeychainData = 0x120; // "TemporaryEnumValue<CharacterKeychainDescription>"
            inline constexpr std::uintptr_t FTattooData = 0x128; // "TemporaryEnumValue<TattooDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t GetRequiredImprisonmentYears = 0x360C1C0; // "private int GetRequiredImprisonmentYears(CharacterFBodyDescription arg)"
            inline constexpr std::uintptr_t GetRequiredImprisonmentYears_2 = 0x360C1C0; // "private int GetRequiredImprisonmentYears(CharacterKeychainDescription arg)"
            inline constexpr std::uintptr_t GetRequiredImprisonmentYears_3 = 0x360C1C0; // "private int GetRequiredImprisonmentYears(CharacterMaskDescription arg)"
            inline constexpr std::uintptr_t GetRequiredImprisonmentYears_4 = 0x360C1C0; // "private int GetRequiredImprisonmentYears(CharacterBagDescription arg)"
            inline constexpr std::uintptr_t GetRequiredImprisonmentYears_5 = 0x360C1C0; // "private int GetRequiredImprisonmentYears(CharacterBodyDescription arg)"
            inline constexpr std::uintptr_t GetCryptoPriceToBuy = 0x360B460; // "private int GetCryptoPriceToBuy(CharacterBodyDescription description)"
            inline constexpr std::uintptr_t GetCryptoPriceToBuy_2 = 0x360B340; // "private int GetCryptoPriceToBuy(CharacterFBodyDescription description)"
            inline constexpr std::uintptr_t GetCryptoPriceToBuy_3 = 0x360B2B0; // "private int GetCryptoPriceToBuy(CharacterBagDescription description)"
            inline constexpr std::uintptr_t GetCryptoPriceToBuy_4 = 0x360B3D0; // "private int GetCryptoPriceToBuy(CharacterMaskDescription description)"
            inline constexpr std::uintptr_t GetCryptoPriceToBuy_5 = 0x360B220; // "private int GetCryptoPriceToBuy(CharacterKeychainDescription description)"
            inline constexpr std::uintptr_t GetIsOwned = 0x360C080; // "private bool GetIsOwned(CharacterBodyDescription description)"
            inline constexpr std::uintptr_t GetIsOwned_2 = 0x360BF80; // "private bool GetIsOwned(CharacterFBodyDescription description)"
            inline constexpr std::uintptr_t GetIsOwned_3 = 0x360BEC0; // "private bool GetIsOwned(CharacterBagDescription description)"
            inline constexpr std::uintptr_t GetIsOwned_4 = 0x360C000; // "private bool GetIsOwned(CharacterMaskDescription description)"
            inline constexpr std::uintptr_t GetIsOwned_5 = 0x360BE40; // "private bool GetIsOwned(CharacterKeychainDescription description)"
            inline constexpr std::uintptr_t GetIsOwned_6 = 0x360BF40; // "private bool GetIsOwned(TattooDescription description)"
            inline constexpr std::uintptr_t GetParts = 0x360C100; // "private ValueTuple<int, int> GetParts(TattooDescription description)"
            inline constexpr std::uintptr_t GetEmptyCryptoPriceToBy_T_inst_1 = 0x7E3AB0; // "CharacterTemporaryModel.GetEmptyCryptoPriceToBy<object>"
            // "CharacterTemporaryModel.GetEmptyCryptoPriceToBy<__Il2CppFullySharedGenericType>"
            inline constexpr std::uintptr_t GetAlwaysOwned_T_inst_1 = 0x7D5050; // "CharacterTemporaryModel.GetAlwaysOwned<object>"
            // "CharacterTemporaryModel.GetAlwaysOwned<__Il2CppFullySharedGenericType>"
            inline constexpr std::uintptr_t GetEmptyParts_T_inst_1 = 0x156E7F0; // "CharacterTemporaryModel.GetEmptyParts<object>"
            inline constexpr std::uintptr_t GetEmptyParts_T_inst_2 = 0x156E7A0; // "CharacterTemporaryModel.GetEmptyParts<__Il2CppFullySharedGenericType>"
            inline constexpr std::uintptr_t GetNoImprisonmentRequirement_T_inst_1 = 0x7E3AB0; // "CharacterTemporaryModel.GetNoImprisonmentRequirement<object>"
            // "CharacterTemporaryModel.GetNoImprisonmentRequirement<__Il2CppFullySharedGenericType>"
            inline constexpr std::uintptr_t GetCharacterHashCode = 0x360AA30; // "public int GetCharacterHashCode()"
            inline constexpr std::uintptr_t SetDefault = 0x360C1E0; // "public void SetDefault(CharacterSexDescription sexDescription)"
            inline constexpr std::uintptr_t Set = 0x360C7B0; // "public void Set(CustomizationInfo info, TattoosModel tattoosModel)"
            inline constexpr std::uintptr_t Set_2 = 0x360C250; // "private void Set(CustomizationInfo info)"
            inline constexpr std::uintptr_t UpdateTattooGrades = 0x7B3360; // "public void UpdateTattooGrades(TattoosModel tattoosModel)"
            inline constexpr std::uintptr_t GetInfo = 0x360B4F0; // "public CustomizationInfo GetInfo()"
            inline constexpr std::uintptr_t ChangeShowMask = 0x360A9B0; // "public void ChangeShowMask()"
            inline constexpr std::uintptr_t SetTattoo = 0x360C210; // "public void SetTattoo(TattooDescription description, int grade)"
            inline constexpr std::uintptr_t Clear = 0x360A9F0; // "public void Clear()"
            inline constexpr std::uintptr_t get_Sex = 0x3610430; // "public CharacterSexDescription get_Sex()"
            inline constexpr std::uintptr_t get_Beard = 0x360FB70; // "public CharacterBeardDescription get_Beard()"
            inline constexpr std::uintptr_t get_Body = 0x360FBB0; // "public CharacterBodyDescription get_Body()"
            inline constexpr std::uintptr_t get_Hair = 0x3610260; // "public CharacterHairDescription get_Hair()"
            inline constexpr std::uintptr_t get_Head = 0x36102A0; // "public CharacterHeadDescription get_Head()"
            inline constexpr std::uintptr_t get_HairColor = 0x36101E0; // "public CharacterHairColorDescription get_HairColor()"
            inline constexpr std::uintptr_t get_HairExtraColor = 0x3610220; // "public CharacterHairColorDescription get_HairExtraColor()"
            inline constexpr std::uintptr_t get_EyebrowsColor = 0x360FC40; // "public CharacterHairColorDescription get_EyebrowsColor()"
            inline constexpr std::uintptr_t get_BeardColor = 0x360FAF0; // "public CharacterHairColorDescription get_BeardColor()"
            inline constexpr std::uintptr_t get_BeardExtraColor = 0x360FB30; // "public CharacterHairColorDescription get_BeardExtraColor()"
            inline constexpr std::uintptr_t get_SkinColor = 0x3610470; // "public CharacterSkinColorDescription get_SkinColor()"
            inline constexpr std::uintptr_t get_Bag = 0x360FAA0; // "public CharacterBagDescription get_Bag()"
            inline constexpr std::uintptr_t get_Mask = 0x36103E0; // "public CharacterMaskDescription get_Mask()"
            inline constexpr std::uintptr_t get_EyeColor = 0x360FBF0; // "public CharacterEyeColorDescription get_EyeColor()"
            inline constexpr std::uintptr_t get_Mark = 0x3610390; // "public CharacterMarkDescription get_Mark()"
            inline constexpr std::uintptr_t get_Keychain = 0x3610340; // "public CharacterKeychainDescription get_Keychain()"
            inline constexpr std::uintptr_t get_Tattoo = 0x3610510; // "public TattooDescription get_Tattoo()"
            inline constexpr std::uintptr_t get_TattooGrade = 0x36104B0; // "public int get_TattooGrade()"
            inline constexpr std::uintptr_t get_FBody = 0x360FCD0; // "public CharacterFBodyDescription get_FBody()"
            inline constexpr std::uintptr_t get_FHair = 0x360FE60; // "public CharacterFHairDescription get_FHair()"
            inline constexpr std::uintptr_t get_FHead = 0x360FEB0; // "public CharacterFHeadDescription get_FHead()"
            inline constexpr std::uintptr_t get_FHairColor = 0x360FDC0; // "public CharacterHairColorDescription get_FHairColor()"
            inline constexpr std::uintptr_t get_FHairExtraColor = 0x360FE10; // "public CharacterHairColorDescription get_FHairExtraColor()"
            inline constexpr std::uintptr_t get_FEyebrowsColor = 0x360FD70; // "public CharacterHairColorDescription get_FEyebrowsColor()"
            inline constexpr std::uintptr_t get_FSkinColor = 0x36100E0; // "public CharacterSkinColorDescription get_FSkinColor()"
            inline constexpr std::uintptr_t get_FBag = 0x360FC80; // "public CharacterBagDescription get_FBag()"
            inline constexpr std::uintptr_t get_FMask = 0x3610090; // "public CharacterMaskDescription get_FMask()"
            inline constexpr std::uintptr_t get_FEyeColor = 0x360FD20; // "public CharacterEyeColorDescription get_FEyeColor()"
            inline constexpr std::uintptr_t get_FMakeup = 0x360FFF0; // "public CharacterFMakeupDescription get_FMakeup()"
            inline constexpr std::uintptr_t get_FMakeupEyeColor = 0x360FF50; // "public CharacterFMakeupEyeColorDescription get_FMakeupEyeColor()"
            inline constexpr std::uintptr_t get_FMakeupLipColor = 0x360FFA0; // "public CharacterFMakeupLipColorDescription get_FMakeupLipColor()"
            inline constexpr std::uintptr_t get_FMark = 0x3610040; // "public CharacterFMarkDescription get_FMark()"
            inline constexpr std::uintptr_t get_FKeychain = 0x360FF00; // "public CharacterKeychainDescription get_FKeychain()"
            inline constexpr std::uintptr_t get_FTattoo = 0x3610190; // "public TattooDescription get_FTattoo()"
            inline constexpr std::uintptr_t get_FTattooGrade = 0x3610130; // "public int get_FTattooGrade()"
            inline constexpr std::uintptr_t get_IsShowMaskEnabled = 0x36102E0; // "public bool get_IsShowMaskEnabled()"
        }
    } // namespace CharacterTemporaryModel

    namespace CharacterTemporaryVersionModel { // "Game.Global.SkinCenter.UI.Models.CharacterTemporaryVersionModel (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Version = 0x10; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Inc = 0x28E2180; // "public void Inc()"
            inline constexpr std::uintptr_t Clear = 0x3610560; // "public void Clear()"
        }
    } // namespace CharacterTemporaryVersionModel

    namespace CharacterThrowableItemGripIKUpdater { // "Game.Battle.Entities.BattleCharacter.Equipment.CharacterThrowableItemGripIKUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t viewDescriptions = 0x18; // "ThrowableItemViewDescriptions"
            inline constexpr std::uintptr_t selectedItem = 0x20; // "SelectedItemModel"
            inline constexpr std::uintptr_t rightWristPose = 0x28; // "PoseIKView"
            inline constexpr std::uintptr_t sex = 0x30; // "CharacterSexModel"
            inline constexpr std::uintptr_t stateModel = 0x38; // "IBattleCharacterStateModel"
            inline constexpr std::uintptr_t knockdownModel = 0x40; // "KnockdownModel"
            inline constexpr std::uintptr_t oldItem = 0x48; // "ThrowableItemDescription"
            inline constexpr std::uintptr_t leftWristPost = 0x50; // "PoseIKView"
        }
        namespace Methods {
            inline constexpr std::uintptr_t InnerUpdate = 0xBEC4D0; // "protected override void InnerUpdate()"
            inline constexpr std::uintptr_t InnerStart = 0x7B3360; // "protected override void InnerStart()"
            inline constexpr std::uintptr_t InnerStop = 0x7B3360; // "protected override void InnerStop()"
            inline constexpr std::uintptr_t GetCurrentItem = 0xBEC450; // "private ThrowableItemDescription GetCurrentItem()"
        }
    } // namespace CharacterThrowableItemGripIKUpdater

    namespace CharacterTransformExtensions { // "Models.Utils.Extensions.CharacterTransformExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t SetPosition = 0x3940880; // "public static void SetPosition(in Vector3 position, ITransformModel transformModel, CharacterReplicatedTransformModel replicatedTransformModel, IBattleCharacterStateModel stateModel)"
            inline constexpr std::uintptr_t SetRotation = 0x3940B10; // "public static void SetRotation(float yaw, float pitch, float roll, ITransformModel transformModel, CharacterReplicatedTransformModel replicatedTransformModel, IBattleCharacterStateModel stateModel)"
            inline constexpr std::uintptr_t SetYaw = 0x3940C80; // "public static void SetYaw(float value, ITransformModel transformModel, CharacterReplicatedTransformModel replicatedTransformModel, IBattleCharacterStateModel stateModel)"
            inline constexpr std::uintptr_t SetPitch = 0x3940740; // "public static void SetPitch(float value, ITransformModel transformModel, CharacterReplicatedTransformModel replicatedTransformModel, IBattleCharacterStateModel stateModel)"
            inline constexpr std::uintptr_t SetRoll = 0x39409D0; // "public static void SetRoll(float value, ITransformModel transformModel, CharacterReplicatedTransformModel replicatedTransformModel, IBattleCharacterStateModel stateModel)"
            inline constexpr std::uintptr_t UpdateRotation = 0x3940DC0; // "private static void UpdateRotation(ITransformModel transformModel, CharacterReplicatedTransformModel replicatedTransformModel)"
            inline constexpr std::uintptr_t IsCharacterNotInVehicle = 0x39406F0; // "private static bool IsCharacterNotInVehicle(IBattleCharacterStateModel stateModel)"
        }
    } // namespace CharacterTransformExtensions

    namespace CharacterTransformModel { // "Models.Models.TransformModel.CharacterTransformModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t X = 0x10; // "float"
            inline constexpr std::uintptr_t Y = 0x14; // "float"
            inline constexpr std::uintptr_t Z = 0x18; // "float"
            inline constexpr std::uintptr_t Pitch = 0x1C; // "float"
            inline constexpr std::uintptr_t Yaw = 0x20; // "float"
            inline constexpr std::uintptr_t Roll = 0x24; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Rx = 0x91D450; // "public float get_Rx()"
            inline constexpr std::uintptr_t get_Ry = 0x98BBA0; // "public float get_Ry()"
            inline constexpr std::uintptr_t get_Rz = 0x97CF30; // "public float get_Rz()"
            inline constexpr std::uintptr_t SetPosition = 0x48AA800; // "public void SetPosition(float x, float y, float z)"
            inline constexpr std::uintptr_t SetPosition_2 = 0x48B6FD0; // "public void SetPosition(in Vector3 position)"
            inline constexpr std::uintptr_t Models_Models_TransformModel_ITransformModel_SetPosition = 0x48B6FD0; // "private void Models.Models.TransformModel.ITransformModel.SetPosition(in Vector3 position)"
        }
    } // namespace CharacterTransformModel

    namespace CharacterTurningAnimationUpdater { // "Game.Battle.EntityModel.BattleCharacter.Rotation.CharacterTurningAnimationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t turningModel = 0x10; // "TurningModel"
            inline constexpr std::uintptr_t stateModel = 0x18; // "IBattleCharacterStateModel"
            inline constexpr std::uintptr_t characterTurningModel = 0x20; // "CharacterTurningModel"
            inline constexpr std::uintptr_t animationView = 0x28; // "CharacterAnimationView"
            inline constexpr std::uintptr_t lastTurnTs = 0x30; // "long"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xCD3380; // "public void Update()"
        }
    } // namespace CharacterTurningAnimationUpdater

    namespace CharacterTurningModel { // "Game.Battle.EntityModel.BattleCharacter.Rotation.CharacterTurningModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Progress = 0x10; // "float"
        }
    } // namespace CharacterTurningModel

    namespace CharacterTurningModelUpdater { // "Game.Battle.EntityModel.BattleCharacter.Rotation.CharacterTurningModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t turningModel = 0x10; // "TurningModel"
            inline constexpr std::uintptr_t characterTurningModel = 0x18; // "CharacterTurningModel"
            inline constexpr std::uintptr_t skeletonDeformationDescription = 0x20; // "BattleCharacterSkeletonDeformationConfig"
            inline constexpr std::uintptr_t now = 0x28; // "INow"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xCD3750; // "public void Update()"
        }
    } // namespace CharacterTurningModelUpdater

    namespace CharacterUnderGasModel { // "Game.Battle.Entities.BattleCharacter.Affliction.CharacterUnderGasModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t UnderGasFrameIndex = 0x10; // "int"
        }
    } // namespace CharacterUnderGasModel

    namespace CharacterUnlockingAnimationUpdater { // "Game.Battle.Entities.BattleCharacter.Updaters.CharacterUnlockingAnimationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t animationView = 0x18; // "CharacterAnimationView"
            inline constexpr std::uintptr_t worldEntitiesModel = 0x20; // "WorldEntitiesModel"
            inline constexpr std::uintptr_t prolongedInteractionModel = 0x28; // "ProlongedInteractionModel"
            inline constexpr std::uintptr_t isActive = 0x30; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t InnerStart = 0xBDC910; // "protected override void InnerStart()"
            inline constexpr std::uintptr_t InnerUpdate = 0xBDC910; // "protected override void InnerUpdate()"
            inline constexpr std::uintptr_t InnerStop = 0xBDC960; // "protected override void InnerStop()"
            inline constexpr std::uintptr_t UpdateByActive = 0xBDC9A0; // "private void UpdateByActive(bool isActive)"
            inline constexpr std::uintptr_t IsActive = 0xBDC990; // "private bool IsActive()"
        }
    } // namespace CharacterUnlockingAnimationUpdater

    namespace CharacterUsableItemGripIKUpdater { // "Game.Battle.Entities.BattleCharacter.Equipment.CharacterUsableItemGripIKUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t viewDescriptions = 0x18; // "UsableItemViewDescriptions"
            inline constexpr std::uintptr_t selectedItem = 0x20; // "SelectedItemModel"
            inline constexpr std::uintptr_t rightWristPose = 0x28; // "PoseIKView"
            inline constexpr std::uintptr_t leftWristPost = 0x30; // "PoseIKView"
            inline constexpr std::uintptr_t sex = 0x38; // "CharacterSexModel"
            inline constexpr std::uintptr_t stateModel = 0x40; // "IBattleCharacterStateModel"
            inline constexpr std::uintptr_t knockdownModel = 0x48; // "KnockdownModel"
            inline constexpr std::uintptr_t oldItem = 0x50; // "UsableItemDescription"
            inline constexpr std::uintptr_t isEnable = 0x58; // "bool"
            inline constexpr std::uintptr_t isAvailable = 0x59; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t InnerUpdate = 0xBEC7F0; // "protected override void InnerUpdate()"
            inline constexpr std::uintptr_t InnerStart = 0x7B3360; // "protected override void InnerStart()"
            inline constexpr std::uintptr_t InnerStop = 0x7B3360; // "protected override void InnerStop()"
            inline constexpr std::uintptr_t GetCurrentItem = 0xBEC770; // "private UsableItemDescription GetCurrentItem()"
        }
    } // namespace CharacterUsableItemGripIKUpdater

    namespace CharacterUseItemModel { // "Game.Battle.Entities.BattleCharacter.Equipment.CharacterUseItemModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Progress = 0x10; // "float"
        }
    } // namespace CharacterUseItemModel

    namespace CharacterUseItemModelUpdater { // "Game.Battle.Entities.BattleCharacter.Equipment.CharacterUseItemModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t useItemModel = 0x10; // "CharacterUseItemModel"
            inline constexpr std::uintptr_t itemActionProcessModel = 0x18; // "ItemActionProcessModel"
            inline constexpr std::uintptr_t now = 0x20; // "INow"
            inline constexpr std::uintptr_t itemInHandsModel = 0x28; // "ItemInHandsModel"
            inline constexpr std::uintptr_t selectedQuickSlotModel = 0x30; // "SelectedQuickSlotModel"
            inline constexpr std::uintptr_t quickSlotsModel = 0x38; // "QuickSlotsModel"
            inline constexpr std::uintptr_t isInCast = 0x40; // "bool"
            inline constexpr std::uintptr_t startTs = 0x48; // "long"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xBECA90; // "public void Update()"
        }
    } // namespace CharacterUseItemModelUpdater

    namespace CharacterValidationModel { // "Models.Models.CharacterValidation.CharacterValidationModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t stateModel = 0x10; // "IBattleCharacterStateModel"
            inline constexpr std::uintptr_t knockdownModel = 0x18; // "KnockdownModel"
            inline constexpr std::uintptr_t revivalModel = 0x20; // "RevivalModel"
            inline constexpr std::uintptr_t knockoutModel = 0x28; // "KnockoutModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t CanPerformIdleActions = 0x497CFA0; // "public bool CanPerformIdleActions()"
            inline constexpr std::uintptr_t CanPerformKnockoutActions = 0x497D060; // "public bool CanPerformKnockoutActions(long now)"
            inline constexpr std::uintptr_t CanPerformInVehicleActions = 0x497D010; // "public bool CanPerformInVehicleActions()"
            inline constexpr std::uintptr_t CanPerformHiddenActions = 0x497CF50; // "public bool CanPerformHiddenActions()"
            inline constexpr std::uintptr_t CanPerformSwimmingActions = 0x497D110; // "public bool CanPerformSwimmingActions()"
            inline constexpr std::uintptr_t CanPerformActions = 0x497CF20; // "private bool CanPerformActions()"
        }
    } // namespace CharacterValidationModel

    namespace CharacterVelocityModel { // "Game.Battle.EntityModel.BattleCharacter.Movement.CharacterVelocityModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Velocity = 0x10; // "Vector3"
            inline constexpr std::uintptr_t VelocityLen = 0x1C; // "float"
        }
    } // namespace CharacterVelocityModel

    namespace CharacterVelocityModel_2 { // "Models.Models.CharacterVelocity.CharacterVelocityModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t X = 0x10; // "float"
            inline constexpr std::uintptr_t Y = 0x14; // "float"
            inline constexpr std::uintptr_t Z = 0x18; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Value = 0x48FDD80; // "public Vector3 get_Value()"
            inline constexpr std::uintptr_t Set = 0x48AA800; // "public void Set(float x, float y, float z)"
        }
    } // namespace CharacterVelocityModel_2

    namespace CharacterWaterEffectsUpdater { // "Game.Battle.Entities.Player.Updaters.CharacterWaterEffectsUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t characterWaterZonesModel = 0x10; // "CharacterWaterZonesModel"
            inline constexpr std::uintptr_t particleSystem = 0x18; // "ParticleSystem"
            inline constexpr std::uintptr_t defaultEmissionRate = 0x20; // "float"
            inline constexpr std::uintptr_t emissionModule = 0x28; // "ParticleSystem.EmissionModule"
            inline constexpr std::uintptr_t previousIsCharacterInWater = 0x30; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB06350; // "public void Update()"
            inline constexpr std::uintptr_t UpdateEmission = 0xB06310; // "private void UpdateEmission(bool isCharacterInWater)"
        }
    } // namespace CharacterWaterEffectsUpdater

    namespace CharacterWaterZonesModel { // "Game.Battle.Entities.BattleCharacter.Soaking.CharacterWaterZonesModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsCharacterInWater = 0x10; // "bool"
        }
    } // namespace CharacterWaterZonesModel

    namespace CharacterWristIKUpdater { // "Game.Battle.Entities.BattleCharacter.Updaters.CharacterWristIKUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t leftWristsPose = 0x10; // "PoseIKView"
            inline constexpr std::uintptr_t rightWristsPose = 0x18; // "PoseIKView"
            inline constexpr std::uintptr_t selectedItem = 0x20; // "SelectedItemModel"
            inline constexpr std::uintptr_t state = 0x28; // "IBattleCharacterStateModel"
            inline constexpr std::uintptr_t knockdownModel = 0x30; // "KnockdownModel"
            inline constexpr std::uintptr_t emotionModel = 0x38; // "EmotionModel"
            inline constexpr std::uintptr_t isEnabled = 0x40; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xBDD2E0; // "public void Update()"
        }
    } // namespace CharacterWristIKUpdater

    namespace CharacterZoneModel { // "Models.Models.CharacterZone.CharacterZoneModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsSceneModel = 0x10; // "PhysicsSceneModel"
            inline constexpr std::uintptr_t physicsBodiesModel = 0x18; // "PhysicsBodiesModel"
            inline constexpr std::uintptr_t worldEntitiesModel = 0x20; // "WorldEntitiesModel"
            inline constexpr std::uintptr_t touches = 0x28; // "List<PhysicsBodyId>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t HasCriminalsInsideZone = 0x497D180; // "public bool HasCriminalsInsideZone(PhysicsBodyId zoneTriggerBodyId, out int criminalEntityId)"
            inline constexpr std::uintptr_t IsVehicleCriminal = 0x497D640; // "private bool IsVehicleCriminal(VehicleModel vehicle, out int criminalEntityId)"
            inline constexpr std::uintptr_t IsBattleCharacterCriminal = 0x497D560; // "private bool IsBattleCharacterCriminal(BattleCharacterModel battleCharacter)"
            inline constexpr std::uintptr_t IsBattleCharacterCop = 0x497D4A0; // "private bool IsBattleCharacterCop(BattleCharacterModel battleCharacter)"
            inline constexpr std::uintptr_t TakeCharactersInsideZone = 0x497D940; // "public void TakeCharactersInsideZone(PhysicsBodyId zoneTriggerBodyId, IEventsSet<int> criminalCharacterIds, out bool hasCops)"
        }
    } // namespace CharacterZoneModel

    namespace CheatCustomizeCharacterMessage { // "Models.Messages.CheatCustomizeCharacterMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t customizeMessageData = 0x20; // "CustomizeMessageData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t GetCustomizationInfo = 0x49F2410; // "public CustomizationInfo GetCustomizationInfo()"
            inline constexpr std::uintptr_t get_Type = 0x49F25C0; // "public override string get_Type()"
        }
    } // namespace CheatCustomizeCharacterMessage

    namespace CheatDisableMovementInertiaMessage { // "Models.Messages.CheatDisableMovementInertiaMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t value = 0x20; // "IPrimitiveData<bool>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Value = 0x49F2810; // "public bool get_Value()"
            inline constexpr std::uintptr_t get_Type = 0x49F27E0; // "public override string get_Type()"
        }
    } // namespace CheatDisableMovementInertiaMessage

    namespace CheatInitiatePlayersCountCheckMessage { // "Models.Messages.CheatInitiatePlayersCountCheckMessage (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x49F30D0; // "public override string get_Type()"
        }
    } // namespace CheatInitiatePlayersCountCheckMessage

    namespace CheatSetDisconnectPlayersTimerMessage { // "Models.Messages.CheatSetDisconnectPlayersTimerMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t time = 0x20; // "IPrimitiveData<long>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Time = 0x49F8C50; // "public long get_Time()"
            inline constexpr std::uintptr_t get_Type = 0x49F8CA0; // "public override string get_Type()"
        }
    } // namespace CheatSetDisconnectPlayersTimerMessage

    namespace CheatSprintSpeedMessage { // "Models.Messages.CheatSprintSpeedMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t value = 0x20; // "IPrimitiveData<bool>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Value = 0x4A01B00; // "public bool get_Value()"
            inline constexpr std::uintptr_t get_Type = 0x4A01AD0; // "public override string get_Type()"
        }
    } // namespace CheatSprintSpeedMessage

    namespace ClanBattleCharacterPositionData { // "Models.Data.Clan.ClanBattleCharacterPositionData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t X = 0x20; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t Z = 0x28; // "IPrimitiveData<int>"
        }
    } // namespace ClanBattleCharacterPositionData

    namespace ClanBattleInputHandler { // "Game.Battle.ClanBattle.ClanBattleInputHandler (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t clanBattleDialogModel = 0x10; // "ScreenModel"
            inline constexpr std::uintptr_t characterSlotsModel = 0x18; // "ClientCharacterSlotsModel"
            inline constexpr std::uintptr_t roomConnections = 0x20; // "IRoomConnections"
            inline constexpr std::uintptr_t uiSoundModel = 0x28; // "GlobalUISoundModel"
            inline constexpr std::uintptr_t inProgress = 0x30; // "bool"
            inline constexpr std::uintptr_t inProgressLeave = 0x31; // "bool"
            inline constexpr std::uintptr_t Handlers = 0x38; // "ValueTuple<InputMask, IUpdater>[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Priority = 0x7E5DA0; // "public InputHandlerPriority get_Priority()"
            inline constexpr std::uintptr_t CloseDialog = 0x952750; // "private void CloseDialog()"
            inline constexpr std::uintptr_t LeaveGvG = 0xCF64D0; // "private void LeaveGvG()"
            inline constexpr std::uintptr_t OnKickOut = 0xCF6580; // "private void OnKickOut(BattleCharacterSlotDescription characterSlot)"
        }
    } // namespace ClanBattleInputHandler

    namespace ClearCrouchStandUpCheckResultsSystem { // "Models.Systems.ClearCrouchStandUpCheckResultsSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t crouchStandUpModel = 0x10; // "CrouchStandUpModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x40F40E0; // "public void Update(ITick tick)"
        }
    } // namespace ClearCrouchStandUpCheckResultsSystem

    namespace ClearInputSystem { // "Models.Systems.ClearInputSystem (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x40F4260; // "protected override void Tick(ITick tick)"
        }
    } // namespace ClearInputSystem

    namespace ClearLookDirectionInputSystem { // "Models.Systems.ClearLookDirectionInputSystem (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x40F4390; // "protected override void Tick(ITick tick)"
        }
    } // namespace ClearLookDirectionInputSystem

    namespace ClearMoveInputSystem { // "Models.Systems.ClearMoveInputSystem (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x40F4460; // "protected override void Tick(ITick tick)"
        }
    } // namespace ClearMoveInputSystem

    namespace ClearTimelineUpdater { // "Game.Battle.EntityModel.BattleCharacter.Movement.ClearTimelineUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t movementTimeline = 0x10; // "MovementTimeline"
            inline constexpr std::uintptr_t lookRotationTimeline = 0x18; // "RotationTimeline"
            inline constexpr std::uintptr_t rotationTimeline = 0x20; // "RotationTimeline"
            inline constexpr std::uintptr_t time = 0x28; // "TimeModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xCD4130; // "public void Update()"
        }
    } // namespace ClearTimelineUpdater

    namespace ClickBarterRecipeInputUpdater { // "Game.Battle.Entities.Trader.Dialog.ClickBarterRecipeInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t inputActions = 0x10; // "InputActions"
            inline constexpr std::uintptr_t onClickAction = 0x18; // "Action<int>"
            inline constexpr std::uintptr_t rectTransforms = 0x20; // "List<RectTransform>"
            inline constexpr std::uintptr_t viewport = 0x28; // "RectTransform"
            inline constexpr std::uintptr_t selectionAction = 0x30; // "InputAction"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xAD46B0; // "public void Update()"
        }
    } // namespace ClickBarterRecipeInputUpdater

    namespace ClickPointerHoverSectorInputUpdater { // "Game.Battle.Emotion.InputHandlers.ClickPointerHoverSectorInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t pointerHoverButtonView = 0x10; // "PointerHoverButtonView"
            inline constexpr std::uintptr_t sectorInputModel = 0x18; // "SectorInputModel"
            inline constexpr std::uintptr_t updater = 0x20; // "ActionInputsUpdater"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xCE4110; // "public void Update()"
            inline constexpr std::uintptr_t Select = 0xCE40E0; // "private void Select(int index)"
        }
    } // namespace ClickPointerHoverSectorInputUpdater

    namespace ClientCharacterSlotsModel { // "ClientCore.CharacterSlotsModel.ClientCharacterSlotsModel (Client.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t slotByPublicId = 0x10; // "Dictionary<long, BattleCharacterSlotModel>"
            inline constexpr std::uintptr_t slotByEntityId = 0x18; // "Dictionary<int, BattleCharacterSlotModel>"
            inline constexpr std::uintptr_t idsBySlots = 0x20; // "Dictionary<BattleCharacterSlotModel, ValueTuple<int, long>>"
            inline constexpr std::uintptr_t idsBySlotDescription = 0x28; // "Dictionary<BattleCharacterSlotDescription, ValueTuple<int, long>>"
            inline constexpr std::uintptr_t Count = 0x30; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Remove = 0xE80EF0; // "public void Remove(BattleCharacterSlotModel slotModel)"
            inline constexpr std::uintptr_t Add = 0xE80CD0; // "public void Add(BattleCharacterSlotModel slotModel)"
            inline constexpr std::uintptr_t ContainsSlot = 0xE80E90; // "public bool ContainsSlot(BattleCharacterSlotModel slot)"
            inline constexpr std::uintptr_t TryGetIdsBySlot = 0xE810A0; // "public bool TryGetIdsBySlot(BattleCharacterSlotModel slot, out ValueTuple<int, long> ids)"
            inline constexpr std::uintptr_t TryIdsBySlotDescription = 0xE81290; // "public bool TryIdsBySlotDescription(BattleCharacterSlotDescription slot, out ValueTuple<int, long> ids)"
            inline constexpr std::uintptr_t get_Item = 0xE81450; // "public BattleCharacterSlotModel get_Item(int id)"
            inline constexpr std::uintptr_t TryGetSlotByEntityId = 0xE811B0; // "public bool TryGetSlotByEntityId(int entityId, out BattleCharacterSlotModel model)"
            inline constexpr std::uintptr_t TryGetSlotByPublicId = 0xE81220; // "public bool TryGetSlotByPublicId(long publicId, out BattleCharacterSlotModel model)"
            inline constexpr std::uintptr_t TryGetPublicIdByEntityId = 0xE81110; // "public bool TryGetPublicIdByEntityId(int entityId, out long publicId)"
            inline constexpr std::uintptr_t TryGetEntityIdByPublicId = 0xE81000; // "public bool TryGetEntityIdByPublicId(long publicId, out int entityId)"
        }
    } // namespace ClientCharacterSlotsModel

    namespace ClientClanBattleCharacterTeamModel { // "Game.Battle.ClientClanBattleCharacterTeamModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t characterSlotsModel = 0x10; // "ICharacterSlotsModel"
            inline constexpr std::uintptr_t clanBattleTeamsCacheModel = 0x18; // "ClanBattleTeamsCacheModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t TryGetTeam = 0xA50810; // "public bool TryGetTeam(int entityId, out ClanBattleTeamDescription teamDescription)"
        }
    } // namespace ClientClanBattleCharacterTeamModel

    namespace ClientCooldownModel { // "Game.Battle.Entities.Player.Models.ClientCooldownModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t now = 0x10; // "ISetNow"
            inline constexpr std::uintptr_t cooldownOverTs = 0x18; // "long"
        }
        namespace Methods {
            inline constexpr std::uintptr_t InProcess = 0xB1BD10; // "public bool InProcess()"
            inline constexpr std::uintptr_t SetDuration = 0xB1BD80; // "public void SetDuration(long duration)"
        }
    } // namespace ClientCooldownModel

    namespace ClientImmunePopupModel { // "Game.Battle.Entities.Player.Models.ClientImmunePopupModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dictionary = 0x10; // "Dictionary<BattleCharacterModel, ValueTuple<Vector3, ClientImmunePopupModel.DamageType>>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Add = 0xB1BDF0; // "public void Add(BattleCharacterModel model, Vector3 position, ClientImmunePopupModel.DamageType damageType)"
            inline constexpr std::uintptr_t Clear = 0xB1BEC0; // "public void Clear()"
            inline constexpr std::uintptr_t GetEnumerator = 0xB1BF10; // "public Dictionary.Enumerator<BattleCharacterModel, ValueTuple<Vector3, ClientImmunePopupModel.DamageType>> GetEnumerator()"
        }
    } // namespace ClientImmunePopupModel

    namespace CloseSafeProlongedAction { // "Game.Battle.Entities.Player.ProlongedActions.CloseSafeProlongedAction (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "ProlongedInteractionModel"
            inline constexpr std::uintptr_t Label = 0x18; // "LocalizedString"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsActive = 0xB1C120; // "public bool get_IsActive()"
            inline constexpr std::uintptr_t get_EndTs = 0xB19D10; // "public long get_EndTs()"
            inline constexpr std::uintptr_t get_Duration = 0xB1C0C0; // "public long get_Duration()"
            inline constexpr std::uintptr_t Interrupt = 0xB1C010; // "public void Interrupt(BattleInputModel battleInputModel)"
        }
    } // namespace CloseSafeProlongedAction

    namespace CodexInputHandler { // "Game.Global.Codex.Updaters.CodexInputHandler (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t globalModel = 0x10; // "GlobalModel"
            inline constexpr std::uintptr_t model = 0x18; // "CodexDialogModel"
            inline constexpr std::uintptr_t Handlers = 0x20; // "ValueTuple<InputMask, IUpdater>[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t OnSelectCodexEntry = 0x35F79D0; // "private void OnSelectCodexEntry(CodexDescription codex)"
            inline constexpr std::uintptr_t OnSelectCodexBuffPage = 0x35F7940; // "private void OnSelectCodexBuffPage(CodexBuffsDescription codex)"
            inline constexpr std::uintptr_t OnExitButtonClicked = 0xD445A0; // "private void OnExitButtonClicked()"
            inline constexpr std::uintptr_t get_Priority = 0x7E5DA0; // "public InputHandlerPriority get_Priority()"
        }
    } // namespace CodexInputHandler

    namespace ColorScheme { // "Game.Battle.EntityModel.Player.Debug.ColorScheme (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Trace = 0x10; // "Color"
            inline constexpr std::uintptr_t HitMarker = 0x20; // "Color"
            inline constexpr std::uintptr_t HitBoxShapes = 0x30; // "Color"
        }
    } // namespace ColorScheme

    namespace CrouchInputDescription { // "Models.References.Input.CrouchInputDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x82261D8; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t enum_id = 0x0; // "Enum<CrouchInputDescription>"
            inline constexpr std::uintptr_t Enable = 0x8; // "CrouchInputDescription"
            inline constexpr std::uintptr_t Disable = 0x10; // "CrouchInputDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Enum = 0x4404250; // "public static ReadOnlyEnum<CrouchInputDescription> get_Enum()"
        }
    } // namespace CrouchInputDescription

    namespace CrouchInputUpdater { // "Game.Battle.Inputs.CrouchInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t crouchInputModel = 0x10; // "InputModel"
            inline constexpr std::uintptr_t battleInputModel = 0x18; // "BattleInputModel"
            inline constexpr std::uintptr_t sprintIntentionModel = 0x20; // "InputIntentionModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x28; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t notificationModel = 0x30; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t localizationKeys = 0x38; // "LocalizationKeys"
            inline constexpr std::uintptr_t crouchStandUpModel = 0x40; // "CrouchStandUpModel"
            inline constexpr std::uintptr_t crouchSitDownModel = 0x48; // "CrouchSitDownModel"
            inline constexpr std::uintptr_t inventoryDialogModel = 0x50; // "InventoryDialogModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA73670; // "public void Update()"
            inline constexpr std::uintptr_t IsDisableCrouch = 0xA735B0; // "private bool IsDisableCrouch()"
        }
    } // namespace CrouchInputUpdater

    namespace CrouchModel { // "Models.Models.Crouch.CrouchModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t isCrouching = 0x10; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t transitionEndTs = 0x18; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t transitionTime = 0x20; // "long"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsCrouching = 0x4950730; // "public bool get_IsCrouching()"
            inline constexpr std::uintptr_t SetCrouch = 0x4950600; // "public void SetCrouch(long now, bool value)"
            inline constexpr std::uintptr_t StopTransition = 0x49506A0; // "public void StopTransition()"
            inline constexpr std::uintptr_t ResetOnRespawn = 0x4950540; // "public void ResetOnRespawn()"
            inline constexpr std::uintptr_t GetValue = 0x4950470; // "public float GetValue(long now)"
            inline constexpr std::uintptr_t get_TransitionEndTs = 0x4950800; // "public long get_TransitionEndTs()"
            inline constexpr std::uintptr_t get_IsInTransition = 0x4950780; // "public bool get_IsInTransition()"
        }
    } // namespace CrouchModel

    namespace CrouchSitDownModel { // "Models.Models.CrouchSitDown.CrouchSitDownModel (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t CheckFreeSpaceToSitDown = 0x4950850; // "public bool CheckFreeSpaceToSitDown(CharacterControllerModel character)"
            inline constexpr std::uintptr_t IsNotInDeepWater = 0x4950850; // "private bool IsNotInDeepWater(CharacterControllerModel character)"
        }
    } // namespace CrouchSitDownModel

    namespace CrouchStandUpModel { // "Models.Models.CrouchStandUp.CrouchStandUpModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsSceneModel = 0x10; // "PhysicsSceneModel"
            inline constexpr std::uintptr_t sphereCastModel = 0x18; // "SphereCastModel"
            inline constexpr std::uintptr_t results = 0x20; // "Dictionary<int, bool>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t IsCrouching = 0x4950CB0; // "public bool IsCrouching(CrouchModel crouchModel)"
            inline constexpr std::uintptr_t CheckFreeSpaceToStandUp = 0x49509A0; // "public bool CheckFreeSpaceToStandUp(int id, CharacterControllerModel character)"
            inline constexpr std::uintptr_t IsFreeSpaceAbove = 0x4950D80; // "private bool IsFreeSpaceAbove(CharacterControllerModel character)"
            inline constexpr std::uintptr_t CalculateCastParams = 0x49508B0; // "private ValueTuple<float, float> CalculateCastParams(PhysicsCharacterConfig config, float capsuleLength, float capsuleRadius)"
            inline constexpr std::uintptr_t Clear = 0x4950C60; // "public void Clear()"
        }
    } // namespace CrouchStandUpModel

    namespace CrouchSystem { // "Models.Systems.CrouchSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t crouchStandUpModel = 0x38; // "CrouchStandUpModel"
            inline constexpr std::uintptr_t crouchSitDownModel = 0x40; // "CrouchSitDownModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x40F4E60; // "protected override void Tick(ITick tick)"
            inline constexpr std::uintptr_t CheckCrouch = 0x40F4D70; // "private bool CheckCrouch(SprintModel sprintModel)"
            inline constexpr std::uintptr_t StandUp = 0x40F4E00; // "private void StandUp(int id, CrouchModel crouchModel, long now, CharacterControllerModel character)"
            inline constexpr std::uintptr_t SitDown = 0x40F4DB0; // "private void SitDown(CrouchModel crouchModel, long now, CharacterControllerModel character)"
        }
    } // namespace CrouchSystem

    namespace CrouchTransitionAnklesFixer { // "CrouchTransitionAnklesFixer (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t charAnimator = 0x20; // "Animator"
            inline constexpr std::uintptr_t ankleInfluencer = 0x28; // "AnimationCurve"
            inline constexpr std::uintptr_t ankleCorrection = 0x30; // "float"
            inline constexpr std::uintptr_t ankles = 0x38; // "Transform[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t LateUpdate = 0x917030; // "private void LateUpdate()"
        }
    } // namespace CrouchTransitionAnklesFixer

    namespace CumulativeChargeProlongedAction { // "Game.Battle.Entities.Player.ProlongedActions.CumulativeChargeProlongedAction (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "ProlongedInteractionModel"
            inline constexpr std::uintptr_t entityId = 0x18; // "int"
            inline constexpr std::uintptr_t Label = 0x20; // "LocalizedString"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsActive = 0xB1C4F0; // "public bool get_IsActive()"
            inline constexpr std::uintptr_t get_EndTs = 0xB19D10; // "public long get_EndTs()"
            inline constexpr std::uintptr_t get_Duration = 0xB1C490; // "public long get_Duration()"
            inline constexpr std::uintptr_t Interrupt = 0xB1C380; // "public void Interrupt(BattleInputModel battleInputModel)"
            inline constexpr std::uintptr_t UpdateInterruptData = 0xB19E00; // "public void UpdateInterruptData()"
        }
    } // namespace CumulativeChargeProlongedAction

    namespace CustomizationComputedConfig { // "Models.References.Character.Customizer.CustomizationComputedConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t NotFreeBodyCount = 0x10; // "int"
            inline constexpr std::uintptr_t NotFreeFBodyCount = 0x14; // "int"
            inline constexpr std::uintptr_t NotFreeBagCount = 0x18; // "int"
            inline constexpr std::uintptr_t NotFreeMaskCount = 0x1C; // "int"
            inline constexpr std::uintptr_t NotFreeKeychainCount = 0x20; // "int"
        }
    } // namespace CustomizationComputedConfig

    namespace CustomizationConfig { // "Models.References.Character.Customizer.CustomizationConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t DefaultSexFunc = 0x10; // "Func<CharacterSexDescription>"
            inline constexpr std::uintptr_t DefaultBeardFunc = 0x18; // "Func<CharacterBeardDescription>"
            inline constexpr std::uintptr_t DefaultBodyFunc = 0x20; // "Func<CharacterBodyDescription>"
            inline constexpr std::uintptr_t DefaultHairFunc = 0x28; // "Func<CharacterHairDescription>"
            inline constexpr std::uintptr_t DefaultHeadFunc = 0x30; // "Func<CharacterHeadDescription>"
            inline constexpr std::uintptr_t DefaultHairColorFunc = 0x38; // "Func<CharacterHairColorDescription>"
            inline constexpr std::uintptr_t DefaultSkinColorFunc = 0x40; // "Func<CharacterSkinColorDescription>"
            inline constexpr std::uintptr_t DefaultBagFunc = 0x48; // "Func<CharacterBagDescription>"
            inline constexpr std::uintptr_t DefaultMaskFunc = 0x50; // "Func<CharacterMaskDescription>"
            inline constexpr std::uintptr_t DefaultEyeColorFunc = 0x58; // "Func<CharacterEyeColorDescription>"
            inline constexpr std::uintptr_t DefaultMarkFunc = 0x60; // "Func<CharacterMarkDescription>"
            inline constexpr std::uintptr_t DefaultKeychainFunc = 0x68; // "Func<CharacterKeychainDescription>"
            inline constexpr std::uintptr_t DefaultTattooFunc = 0x70; // "Func<TattooDescription>"
            inline constexpr std::uintptr_t DefaultFBodyFunc = 0x78; // "Func<CharacterFBodyDescription>"
            inline constexpr std::uintptr_t DefaultFHairFunc = 0x80; // "Func<CharacterFHairDescription>"
            inline constexpr std::uintptr_t DefaultFHeadFunc = 0x88; // "Func<CharacterFHeadDescription>"
            inline constexpr std::uintptr_t DefaultFHairColorFunc = 0x90; // "Func<CharacterHairColorDescription>"
            inline constexpr std::uintptr_t DefaultFSkinColorFunc = 0x98; // "Func<CharacterSkinColorDescription>"
            inline constexpr std::uintptr_t DefaultFBagFunc = 0xA0; // "Func<CharacterBagDescription>"
            inline constexpr std::uintptr_t DefaultFEyeColorFunc = 0xA8; // "Func<CharacterEyeColorDescription>"
            inline constexpr std::uintptr_t DefaultFMakeupFunc = 0xB0; // "Func<CharacterFMakeupDescription>"
            inline constexpr std::uintptr_t DefaultFMakeupEyeColorFunc = 0xB8; // "Func<CharacterFMakeupEyeColorDescription>"
            inline constexpr std::uintptr_t DefaultFMakeupLipColorFunc = 0xC0; // "Func<CharacterFMakeupLipColorDescription>"
            inline constexpr std::uintptr_t DefaultFMarkFunc = 0xC8; // "Func<CharacterFMarkDescription>"
            inline constexpr std::uintptr_t DefaultFKeychainFunc = 0xD0; // "Func<CharacterKeychainDescription>"
            inline constexpr std::uintptr_t DefaultFTattooFunc = 0xD8; // "Func<TattooDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_DefaultSex = 0x1765CB0; // "public CharacterSexDescription get_DefaultSex()"
            inline constexpr std::uintptr_t get_DefaultBeard = 0x26CF2F0; // "public CharacterBeardDescription get_DefaultBeard()"
            inline constexpr std::uintptr_t get_DefaultBody = 0x9D6230; // "public CharacterBodyDescription get_DefaultBody()"
            inline constexpr std::uintptr_t get_DefaultHair = 0x993E50; // "public CharacterHairDescription get_DefaultHair()"
            inline constexpr std::uintptr_t get_DefaultHead = 0x9AA5D0; // "public CharacterHeadDescription get_DefaultHead()"
            inline constexpr std::uintptr_t get_DefaultHairColor = 0x2AA0B60; // "public CharacterHairColorDescription get_DefaultHairColor()"
            inline constexpr std::uintptr_t get_DefaultSkinColor = 0x4048E60; // "public CharacterSkinColorDescription get_DefaultSkinColor()"
            inline constexpr std::uintptr_t get_DefaultBag = 0x4048E90; // "public CharacterBagDescription get_DefaultBag()"
            inline constexpr std::uintptr_t get_DefaultMask = 0x1CE7810; // "public CharacterMaskDescription get_DefaultMask()"
            inline constexpr std::uintptr_t get_DefaultEyeColor = 0x4048FB0; // "public CharacterEyeColorDescription get_DefaultEyeColor()"
            inline constexpr std::uintptr_t get_DefaultMark = 0x4048EC0; // "public CharacterMarkDescription get_DefaultMark()"
            inline constexpr std::uintptr_t get_DefaultKeychain = 0x4048EF0; // "public CharacterKeychainDescription get_DefaultKeychain()"
            inline constexpr std::uintptr_t get_DefaultTattoo = 0x4048F80; // "public TattooDescription get_DefaultTattoo()"
            inline constexpr std::uintptr_t get_DefaultFBody = 0x4048F20; // "public CharacterFBodyDescription get_DefaultFBody()"
            inline constexpr std::uintptr_t get_DefaultFHair = 0x4048F50; // "public CharacterFHairDescription get_DefaultFHair()"
            inline constexpr std::uintptr_t get_DefaultFHead = 0x43E8A80; // "public CharacterFHeadDescription get_DefaultFHead()"
            inline constexpr std::uintptr_t get_DefaultFHairColor = 0x440E2B0; // "public CharacterHairColorDescription get_DefaultFHairColor()"
            inline constexpr std::uintptr_t get_DefaultFSkinColor = 0x4067080; // "public CharacterSkinColorDescription get_DefaultFSkinColor()"
            inline constexpr std::uintptr_t get_DefaultFBag = 0x40671C0; // "public CharacterBagDescription get_DefaultFBag()"
            inline constexpr std::uintptr_t get_DefaultFEyeColor = 0x4067190; // "public CharacterEyeColorDescription get_DefaultFEyeColor()"
            inline constexpr std::uintptr_t get_DefaultFMakeup = 0x4067270; // "public CharacterFMakeupDescription get_DefaultFMakeup()"
            inline constexpr std::uintptr_t get_DefaultFMakeupEyeColor = 0x4067130; // "public CharacterFMakeupEyeColorDescription get_DefaultFMakeupEyeColor()"
            inline constexpr std::uintptr_t get_DefaultFMakeupLipColor = 0x43E8360; // "public CharacterFMakeupLipColorDescription get_DefaultFMakeupLipColor()"
            inline constexpr std::uintptr_t get_DefaultFMark = 0x43E8260; // "public CharacterFMarkDescription get_DefaultFMark()"
            inline constexpr std::uintptr_t get_DefaultFKeychain = 0x43E8200; // "public CharacterKeychainDescription get_DefaultFKeychain()"
            inline constexpr std::uintptr_t get_DefaultFTattoo = 0x43E81A0; // "public TattooDescription get_DefaultFTattoo()"
        }
    } // namespace CustomizationConfig

    namespace CustomizeCharacterMessage { // "Models.Messages.CustomizeCharacterMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t customizeMessageData = 0x20; // "CustomizeMessageData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t CustomizationInfo = 0x49F2410; // "public CustomizationInfo CustomizationInfo()"
            inline constexpr std::uintptr_t get_Type = 0x4A05750; // "public override string get_Type()"
        }
    } // namespace CustomizeCharacterMessage

    namespace CustomizeSceneCharacterReturnRotationModelUpdater { // "Game.Global.CustomizeScene.CustomizeSceneCharacterReturnRotationModelUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t rotationModel = 0x10; // "CustomizeSceneRotationModel"
            inline constexpr std::uintptr_t rotationView = 0x18; // "ICustomizeSceneRotationView"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x35FAEB0; // "public void Update()"
            inline constexpr std::uintptr_t UpdateAutoReturn = 0x35FAD30; // "private void UpdateAutoReturn(float deltaTime)"
        }
    } // namespace CustomizeSceneCharacterReturnRotationModelUpdater

    namespace CustomizeSceneDitheringCharacterModelUpdater { // "Game.Global.CustomizeScene.CustomizeSceneDitheringCharacterModelUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t maleDithering = 0x10; // "DitheringModel"
            inline constexpr std::uintptr_t femaleDithering = 0x18; // "DitheringModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x35FB4F0; // "public void Update()"
        }
    } // namespace CustomizeSceneDitheringCharacterModelUpdater

    namespace CustomizeSceneResetZoomOnCharacterTabUpdater { // "Game.Global.CustomizeScene.CustomizeSceneResetZoomOnCharacterTabUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dialogModel = 0x10; // "SkinCenterDialogModel"
            inline constexpr std::uintptr_t skinCenterSceneModel = 0x18; // "SkinCenterSceneModel"
            inline constexpr std::uintptr_t view = 0x20; // "SkinCenterCharacterZoomView"
            inline constexpr std::uintptr_t wasTab = 0x28; // "CharacterTabDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x35FBDD0; // "public void Update()"
            inline constexpr std::uintptr_t GetTab = 0x35FBD30; // "private static CharacterTabDescription GetTab(SkinCenterTab tab)"
        }
    } // namespace CustomizeSceneResetZoomOnCharacterTabUpdater

    namespace CustomizeSceneYawRotationInputUpdater { // "Game.Global.CustomizeScene.CustomizeSceneYawRotationInputUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t characterRotationModel = 0x10; // "CharacterRotationModel"
            inline constexpr std::uintptr_t sceneRotationInputModel = 0x18; // "SceneRotationInputModel"
            inline constexpr std::uintptr_t lastYawRotationModel = 0x20; // "CustomizeSceneRotationModel"
            inline constexpr std::uintptr_t wasDraggedLastFrame = 0x28; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x35FCCB0; // "public void Update()"
        }
    } // namespace CustomizeSceneYawRotationInputUpdater

    namespace DeathModelUpdater { // "Game.Battle.EntityModel.Player.DeathModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "BattleCharacterModel"
            inline constexpr std::uintptr_t codexModel = 0x18; // "ClientCodexModel"
            inline constexpr std::uintptr_t characterSlotsModel = 0x20; // "ClientCharacterSlotsModel"
            inline constexpr std::uintptr_t battleCharacterModels = 0x28; // "ReadOnly.Dictionary<int, BattleCharacterModel>"
            inline constexpr std::uintptr_t healthModel = 0x30; // "HealthModel"
            inline constexpr std::uintptr_t isDead = 0x38; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC37700; // "public void Update()"
        }
    } // namespace DeathModelUpdater

    namespace DeathReasonDescription { // "Models.References.Character.DeathReasonDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x824E8B8; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t enum_id = 0x0; // "Enum<DeathReasonDescription>"
            inline constexpr std::uintptr_t PlayerDamage = 0x8; // "DeathReasonDescription"
            inline constexpr std::uintptr_t FallDamage = 0x10; // "DeathReasonDescription"
            inline constexpr std::uintptr_t VelocityDamage = 0x18; // "DeathReasonDescription"
            inline constexpr std::uintptr_t Drowned = 0x20; // "DeathReasonDescription"
            inline constexpr std::uintptr_t UnderLocation = 0x28; // "DeathReasonDescription"
            inline constexpr std::uintptr_t Suicide = 0x30; // "DeathReasonDescription"
            inline constexpr std::uintptr_t DamageZone = 0x38; // "DeathReasonDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Enum = 0x4472DE0; // "public static ReadOnlyEnum<DeathReasonDescription> get_Enum()"
        }
    } // namespace DeathReasonDescription

    namespace DebugBreachEntityStateUpdater { // "Game.Battle.EntityModel.Player.Debug.DebugBreachEntityStateUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t id = 0x10; // "int"
            inline constexpr std::uintptr_t breachStateEntityModel = 0x18; // "BreachStateEntityModel"
            inline constexpr std::uintptr_t positionModel = 0x20; // "IPositionModel"
            inline constexpr std::uintptr_t dataModels = 0x28; // "IDataModels"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x30; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t style = 0x38; // "GUIStyle"
            inline constexpr std::uintptr_t serverNow = 0x40; // "INow"
            inline constexpr std::uintptr_t canUpdate = 0x48; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t OnDrawGizmos = 0xC6AF00; // "private void OnDrawGizmos()"
            inline constexpr std::uintptr_t Update = 0xAD3850; // "public void Update()"
            inline constexpr std::uintptr_t DrawLabel = 0xC6AD70; // "private void DrawLabel()"
        }
    } // namespace DebugBreachEntityStateUpdater

    namespace DebugDataUpdater { // "Game.Battle.EntityModel.Player.Debug.DebugDataUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dataModel = 0x10; // "IDataModel"
            inline constexpr std::uintptr_t dataTickIndex = 0x18; // "long"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC6B240; // "public void Update()"
        }
    } // namespace DebugDataUpdater

    namespace DebugEntityIdUpdater { // "Game.Battle.EntityModel.Player.Debug.DebugEntityIdUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t location = 0x10; // "LocationDescription"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x18; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t worldEntitiesModel = 0x20; // "WorldEntitiesModel"
            inline constexpr std::uintptr_t view = 0x28; // "DebugEntityIdView"
            inline constexpr std::uintptr_t camera = 0x30; // "Camera"
            inline constexpr std::uintptr_t board = 0x38; // "DebugEntityLabelBoard"
            inline constexpr std::uintptr_t interactTypeNames = 0x40; // "ValueTuple<string, Func<int, bool>>[]"
            inline constexpr std::uintptr_t canUpdate = 0x48; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t OnDrawGizmos = 0xC6D400; // "private void OnDrawGizmos()"
            inline constexpr std::uintptr_t DrawEntities = 0xC6C310; // "private void DrawEntities()"
            inline constexpr std::uintptr_t DrawLabels = 0xC6C460; // "private void DrawLabels()"
            inline constexpr std::uintptr_t InteractEntities = 0xC6C890; // "private void InteractEntities()"
            inline constexpr std::uintptr_t ResolveInteractTypeName = 0xC6DF90; // "private string ResolveInteractTypeName(int entityId)"
            inline constexpr std::uintptr_t MoneyWorkbenches = 0xC6D190; // "private void MoneyWorkbenches()"
            inline constexpr std::uintptr_t AccessEntities = 0xC6B3B0; // "private void AccessEntities()"
            inline constexpr std::uintptr_t CargoOpenWorkbenches = 0xC6BBC0; // "private void CargoOpenWorkbenches()"
            inline constexpr std::uintptr_t CargoOpenWorkbench = 0xC6B870; // "private void CargoOpenWorkbench(CargoOpenWorkbenchModel cargoOpenWorkbenchModel)"
            inline constexpr std::uintptr_t MoneyWorkbench = 0xC6CE30; // "private void MoneyWorkbench(IMoneyWorkbenchModel moneyWorkbenchModel)"
            inline constexpr std::uintptr_t Vehicles = 0xC6E560; // "private void Vehicles()"
            inline constexpr std::uintptr_t PlotVehicles = 0xC6DB10; // "private void PlotVehicles()"
            inline constexpr std::uintptr_t PlotVehicleGarages = 0xC6D820; // "private void PlotVehicleGarages()"
            inline constexpr std::uintptr_t DrawPlotVehicleGarage_T_inst_1 = 0x159B3F0; // "DebugEntityIdUpdater.DrawPlotVehicleGarage<object>"
            inline constexpr std::uintptr_t DrawPlotVehicleGarage_T_inst_2 = 0x159B2C0; // "DebugEntityIdUpdater.DrawPlotVehicleGarage<__Il2CppFullySharedGenericType>"
            inline constexpr std::uintptr_t FurnitureLoots = 0xC6C540; // "private void FurnitureLoots()"
            inline constexpr std::uintptr_t Storages = 0xC6E050; // "private void Storages()"
            inline constexpr std::uintptr_t PlotContainers = 0xC6D5E0; // "private void PlotContainers()"
            inline constexpr std::uintptr_t VehicleSpawners = 0xC6E300; // "private void VehicleSpawners()"
            inline constexpr std::uintptr_t Update = 0xC6E2D0; // "public void Update()"
            inline constexpr std::uintptr_t Begin = 0xC6B680; // "private DebugEntityLabel Begin(DebugEntityLabelCategory category, string title, Vector3 position)"
            inline constexpr std::uintptr_t CheckDistanceToCharacter = 0xC6C200; // "private bool CheckDistanceToCharacter(Vector3 targetPosition)"
        }
    } // namespace DebugEntityIdUpdater

    namespace DebugEntityLabel { // "Game.Battle.EntityModel.Player.Debug.DebugEntityLabel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Category = 0x10; // "DebugEntityLabelCategory"
            inline constexpr std::uintptr_t Title = 0x18; // "string"
            inline constexpr std::uintptr_t Position = 0x20; // "Vector3"
            inline constexpr std::uintptr_t Lines = 0x30; // "List<string>"
            inline constexpr std::uintptr_t Ids = 0x38; // "List<int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Id = 0xC707C0; // "public DebugEntityLabel Id(string name, int id)"
            inline constexpr std::uintptr_t Text = 0xC70920; // "public DebugEntityLabel Text(string name, string value)"
        }
    } // namespace DebugEntityLabel

    namespace DebugEntityLabelBoard { // "Game.Battle.EntityModel.Player.Debug.DebugEntityLabelBoard (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t labels = 0x10; // "List<DebugEntityLabel>"
            inline constexpr std::uintptr_t claimedIds = 0x18; // "HashSet<int>"
            inline constexpr std::uintptr_t builder = 0x20; // "StringBuilder"
            inline constexpr std::uintptr_t style = 0x28; // "GUIStyle"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Labels = 0x7EC6B0; // "public IReadOnlyList<DebugEntityLabel> get_Labels()"
            inline constexpr std::uintptr_t Clear = 0xC70070; // "public void Clear()"
            inline constexpr std::uintptr_t IsClaimed = 0xC705D0; // "public bool IsClaimed(int id)"
            inline constexpr std::uintptr_t Claim = 0xC70010; // "public void Claim(int id)"
            inline constexpr std::uintptr_t Begin = 0xC6FE60; // "public DebugEntityLabel Begin(DebugEntityLabelCategory category, string title, Vector3 position)"
            inline constexpr std::uintptr_t Flush = 0xC70190; // "public void Flush(Vector3 cameraPosition, Vector3 cameraForward, float maxDistance, float coneHalfAngle)"
            inline constexpr std::uintptr_t DrawLabel = 0xC700F0; // "private void DrawLabel(DebugEntityLabel label, float alpha)"
            inline constexpr std::uintptr_t AppendLabel = 0xC6FB70; // "private void AppendLabel(DebugEntityLabel label, float alpha)"
        }
    } // namespace DebugEntityLabelBoard

    namespace DebugLookDirectionUpdater { // "Game.Battle.EntityModel.Player.DebugLookDirectionUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t transformModel = 0x10; // "ITransformModel"
            inline constexpr std::uintptr_t lookDirectionModel = 0x18; // "LookDirectionModel"
            inline constexpr std::uintptr_t crouchModel = 0x20; // "CharacterCrouchModel"
            inline constexpr std::uintptr_t isLeftShoulderView = 0x28; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t aimingModel = 0x30; // "AimingModel"
            inline constexpr std::uintptr_t aimModeModel = 0x38; // "IPrimitiveModel<AimModeDescription>"
            inline constexpr std::uintptr_t weaponModel = 0x40; // "IWeaponModel"
            inline constexpr std::uintptr_t config = 0x48; // "BattleCharacterConfig"
            inline constexpr std::uintptr_t directionView = 0x50; // "DebugLookDirectionView"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC37A80; // "public void Update()"
        }
    } // namespace DebugLookDirectionUpdater

    namespace DebugNetStatsUpdater { // "Game.Battle.EntityModel.Player.Debug.DebugNetStatsUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t view = 0x10; // "DebugNetStatsView"
            inline constexpr std::uintptr_t debugNetModel = 0x18; // "DebugNetModel"
            inline constexpr std::uintptr_t time = 0x20; // "TimeModel"
            inline constexpr std::uintptr_t connection = 0x28; // "IRoomConnection"
            inline constexpr std::uintptr_t connectionInfo = 0x30; // "RoomConnectionInfo"
            inline constexpr std::uintptr_t packetStatsModel = 0x38; // "PacketStatsModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC83C60; // "public void Update()"
            inline constexpr std::uintptr_t CountExtrapolates = 0xC833B0; // "private void CountExtrapolates()"
            inline constexpr std::uintptr_t UpdateViewStats = 0xC83460; // "private void UpdateViewStats()"
        }
    } // namespace DebugNetStatsUpdater

    namespace DebugPlayerEquipDelayUpdater { // "Game.Battle.DebugPlayerEquipDelayUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t serverModel = 0x10; // "BattleCharacterModel"
            inline constexpr std::uintptr_t time = 0x18; // "TimeModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA54C90; // "public void Update()"
        }
    } // namespace DebugPlayerEquipDelayUpdater

    namespace DebugPlayerInventoryUpdater { // "Game.Battle.EntityModel.Player.Debug.DebugPlayerInventoryUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleCharacterModel = 0x10; // "BattleCharacterModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC851B0; // "public void Update()"
            inline constexpr std::uintptr_t DrawInventory = 0xC84410; // "private void DrawInventory()"
            inline constexpr std::uintptr_t DrawEquip = 0xC83E00; // "private void DrawEquip()"
            inline constexpr std::uintptr_t DrawPockets = 0xC84AE0; // "private void DrawPockets()"
        }
    } // namespace DebugPlayerInventoryUpdater

    namespace DebugReplicationDataBytesUpdater { // "Game.Battle.Entities.Player.Debug.ReplicationBytes.DebugReplicationDataBytesUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t percentiles = 0x10; // "float[]"
            inline constexpr std::uintptr_t debugBattleReplicationModel = 0x18; // "DebugBattleReplicationModel"
            inline constexpr std::uintptr_t view = 0x20; // "DebugReplicationDataBytesView"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB1C9F0; // "public void Update()"
            inline constexpr std::uintptr_t PrintResult = 0xB1C5A0; // "private void PrintResult(ReplicationSequencesModel sequences)"
            inline constexpr std::uintptr_t ToBytes = 0xB1C9E0; // "private int ToBytes(int bits)"
        }
    } // namespace DebugReplicationDataBytesUpdater

    namespace DebugReplicationEntitiesUpdater { // "Game.Battle.EntityModel.Player.Debug.DebugReplicationEntitiesUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dataModels = 0x10; // "IDataModels"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x18; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t style = 0x20; // "GUIStyle"
        }
        namespace Methods {
            inline constexpr std::uintptr_t OnDrawGizmos = 0xC85260; // "private void OnDrawGizmos()"
            inline constexpr std::uintptr_t Update = 0x7B3360; // "public void Update()"
            inline constexpr std::uintptr_t DrawEntity = 0x7B3360; // "private void DrawEntity(int entityId, Vector3 position, string entityType)"
            inline constexpr std::uintptr_t DrawEntity_2 = 0x7B3360; // "private void DrawEntity(int entityId, Vector3 position, string entityType)"
            inline constexpr std::uintptr_t DrawLabel = 0x7B3360; // "private void DrawLabel(Vector3 textPosition, int entityId, string entityType)"
        }
    } // namespace DebugReplicationEntitiesUpdater

    namespace DebugReplicationGridUpdater { // "Game.Battle.EntityModel.Player.Debug.DebugReplicationGridUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t drawDetailedGrid = 0x10; // "bool"
            inline constexpr std::uintptr_t transform = 0x18; // "ITransformModel"
            inline constexpr std::uintptr_t view = 0x20; // "DebugReplicationGridView"
            inline constexpr std::uintptr_t grids = 0x28; // "IRegularGrids"
            inline constexpr std::uintptr_t locationReplicationGridDescription = 0x30; // "LocationReplicationGridDescription"
            inline constexpr std::uintptr_t ts = 0x38; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC86A10; // "public void Update()"
            inline constexpr std::uintptr_t TryGetSelectedGrid = 0xC867A0; // "private bool TryGetSelectedGrid(out ReplicationGridLayer layer)"
            inline constexpr std::uintptr_t DrawGrid = 0xC864D0; // "private void DrawGrid(ReplicationGridLayer replicationGridLayer)"
            inline constexpr std::uintptr_t DrawAllGridCells = 0xC85E20; // "private void DrawAllGridCells(IRegularGrid grid)"
            inline constexpr std::uintptr_t DrawGridCellsInRadius = 0xC860D0; // "private void DrawGridCellsInRadius(IRegularGrid grid, int xIndex, int yIndex, int radius, Color color)"
        }
    } // namespace DebugReplicationGridUpdater

    namespace DebugReplicationPacketsBytesUpdater { // "Game.Battle.Entities.Player.Debug.ReplicationBytes.DebugReplicationPacketsBytesUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t percentiles = 0x10; // "float[]"
            inline constexpr std::uintptr_t debugBattleReplicationModel = 0x18; // "DebugBattleReplicationModel"
            inline constexpr std::uintptr_t view = 0x20; // "DebugReplicationPacketsBytesView"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB1CF70; // "public void Update()"
            inline constexpr std::uintptr_t PrintResult = 0xB1CB90; // "private void PrintResult(ReplicationSequencesModel sequences)"
        }
    } // namespace DebugReplicationPacketsBytesUpdater

    namespace DefaultTalkTargetActions { // "Game.Battle.EntityModel.CharacterLaunderer.DefaultTalkTargetActions (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleModel = 0x10; // "BattleModel"
            inline constexpr std::uintptr_t globalModel = 0x18; // "GlobalModel"
            inline constexpr std::uintptr_t targetName = 0x20; // "LocalizedString"
            inline constexpr std::uintptr_t entityId = 0x28; // "int"
            inline constexpr std::uintptr_t talkViewDescriptions = 0x30; // "TalkViewDescriptions"
            inline constexpr std::uintptr_t talk = 0x38; // "TalkDescription"
            inline constexpr std::uintptr_t talkDialogSceneView = 0x40; // "TalkDialogSceneView"
            inline constexpr std::uintptr_t TalkAction = 0x48; // "TargetAction"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Talk = 0xCAD3A0; // "private void Talk()"
            inline constexpr std::uintptr_t Unavailable = 0x95A620; // "private void Unavailable(LocalizedString invalidNotification, PersonalNotificationActionIds id)"
        }
    } // namespace DefaultTalkTargetActions

    namespace DefaultTalkTargetProvider { // "Game.Battle.EntityModel.CharacterLaunderer.DefaultTalkTargetProvider (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleModel = 0x20; // "BattleModel"
            inline constexpr std::uintptr_t actions = 0x28; // "DefaultTalkTargetActions"
            inline constexpr std::uintptr_t talkViewDescriptions = 0x30; // "TalkViewDescriptions"
            inline constexpr std::uintptr_t unavailableKeys = 0x38; // "UnavailableTargetActionsKeys"
            inline constexpr std::uintptr_t talk = 0x40; // "TalkDescription"
            inline constexpr std::uintptr_t talkInappropriateRoleNotify = 0x48; // "LocalizedString"
        }
        namespace Methods {
            inline constexpr std::uintptr_t FillTargetActions = 0xCAD600; // "protected internal override void FillTargetActions(List<ITargetAction> actions)"
        }
    } // namespace DefaultTalkTargetProvider

    namespace DelayedInputActionInputUpdater { // "Game.Battle.DelayedInputActionInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t delayedInputActionModel = 0x10; // "DelayedInputActionModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA55E80; // "public void Update()"
        }
    } // namespace DelayedInputActionInputUpdater

    namespace DelayedInputActionModel { // "Game.Battle.DelayedInputActionModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t inputModel = 0x10; // "InputModel"
            inline constexpr std::uintptr_t startTs = 0x18; // "float"
            inline constexpr std::uintptr_t action = 0x20; // "Action"
            inline constexpr std::uintptr_t endTs = 0x28; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Delay = 0xA55F30; // "public void Delay(Action action, float delay)"
            inline constexpr std::uintptr_t Clear = 0xA55F00; // "public void Clear()"
            inline constexpr std::uintptr_t TryInvokeAction = 0xA55FE0; // "public bool TryInvokeAction()"
            inline constexpr std::uintptr_t TryGetProgress = 0xA55F80; // "public bool TryGetProgress(out float progress)"
        }
    } // namespace DelayedInputActionModel

    namespace DeviceModel { // "Inputs.DeviceModel (Inputs.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t CurrentDeviceId = 0x10; // "DeviceId"
        }
    } // namespace DeviceModel

    namespace DisableBattleCameraUpdater { // "Game.Battle.DisableBattleCameraUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleModel = 0x10; // "BattleModel"
            inline constexpr std::uintptr_t globalModel = 0x18; // "GlobalModel"
            inline constexpr std::uintptr_t battleScreenView = 0x20; // "BattleScreenView"
            inline constexpr std::uintptr_t isEnabled = 0x28; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA56980; // "public void Update()"
        }
    } // namespace DisableBattleCameraUpdater

    namespace DisableInputsBySteamOverlayUpdater { // "Game.Steam.DisableInputsBySteamOverlayUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t steamAdapter = 0x10; // "ISteamAdapter"
            inline constexpr std::uintptr_t inputsEnabledModel = 0x18; // "InputsEnabledModel"
            inline constexpr std::uintptr_t enabled = 0x20; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x35388D0; // "public void Update()"
        }
    } // namespace DisableInputsBySteamOverlayUpdater

    namespace DiscardCinemachineOffsetUpdater { // "Game.Battle.Entities.Player.Updaters.DiscardCinemachineOffsetUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t cameraOffset = 0x10; // "CinemachineCameraOffset"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB06870; // "public void Update()"
        }
    } // namespace DiscardCinemachineOffsetUpdater

    namespace DistanceEvent { // "Game.Battle.EntityModel.BattleCharacter.DistanceEvent (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Distance = 0x10; // "float"
            inline constexpr std::uintptr_t Event = 0x18; // "Event"
        }
    } // namespace DistanceEvent

    namespace DropCargoInputUpdater { // "Game.Battle.Inputs.DropCargoInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleEntitiesModel = 0x10; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t inputModel = 0x18; // "InputModel"
            inline constexpr std::uintptr_t battleInputModel = 0x20; // "BattleInputModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA76770; // "public void Update()"
        }
    } // namespace DropCargoInputUpdater

    namespace DroppedItemAnimationHelperManualBehavior { // "Game.Battle.EntityModel.BattleCharacter.Equipment.DroppedItemAnimationHelperManualBehavior (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t root = 0x20; // "Transform"
            inline constexpr std::uintptr_t item = 0x28; // "Transform"
            inline constexpr std::uintptr_t Weight = 0x30; // "float"
            inline constexpr std::uintptr_t Position = 0x34; // "Vector3"
            inline constexpr std::uintptr_t Rotation = 0x40; // "Quaternion"
        }
        namespace Methods {
            inline constexpr std::uintptr_t ManualUpdate = 0xCEAC00; // "public override void ManualUpdate()"
        }
    } // namespace DroppedItemAnimationHelperManualBehavior

    namespace EmotionAnimationRules { // "Game.Battle.EntityModel.BattleCharacter.Emotion.EmotionAnimationRules (Battle.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t IsPlaying = 0xCEB3E0; // "public static bool IsPlaying(EmotionModel emotionModel, AnimationStateAssistant animationStateAssistant)"
        }
    } // namespace EmotionAnimationRules

    namespace EmotionBlendTreeDescription { // "Models.References.Character.EmotionBlendTreeDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t AnimationContentId = 0x20; // "int"
        }
    } // namespace EmotionBlendTreeDescription

    namespace EmotionKeyboardInputHandler { // "Game.Battle.Emotion.InputHandlers.EmotionKeyboardInputHandler (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Handlers = 0x10; // "ValueTuple<InputMask, IUpdater>[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Priority = 0x7E5D90; // "public InputHandlerPriority get_Priority()"
        }
    } // namespace EmotionKeyboardInputHandler

    namespace EmotionTouchInputHandler { // "Game.Battle.Emotion.InputHandlers.EmotionTouchInputHandler (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Handlers = 0x10; // "ValueTuple<InputMask, IUpdater>[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Priority = 0x7E5D90; // "public InputHandlerPriority get_Priority()"
        }
    } // namespace EmotionTouchInputHandler

    namespace EnableCashZoneForCharacterByRoleUpdater { // "Game.Battle.Entities.BattleCharacter.Updaters.EnableCashZoneForCharacterByRoleUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t cashZoneSoundView = 0x10; // "CashZoneSoundView"
            inline constexpr std::uintptr_t role = 0x18; // "IPrimitiveModel<PlayerRoleDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xBE5E40; // "public void Update()"
        }
    } // namespace EnableCashZoneForCharacterByRoleUpdater

    namespace EvictProlongedAction { // "Game.Battle.Entities.Player.ProlongedActions.EvictProlongedAction (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "ProlongedInteractionModel"
            inline constexpr std::uintptr_t Label = 0x18; // "LocalizedString"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsActive = 0xB1D3E0; // "public bool get_IsActive()"
            inline constexpr std::uintptr_t get_EndTs = 0xB19D10; // "public long get_EndTs()"
            inline constexpr std::uintptr_t get_Duration = 0xB1D380; // "public long get_Duration()"
            inline constexpr std::uintptr_t Interrupt = 0xB1D2D0; // "public void Interrupt(BattleInputModel battleInputModel)"
        }
    } // namespace EvictProlongedAction

    namespace FileStorageRules { // "Game.Global.PlayerPrefsFile.FileStorageRules (Global.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t DeserializeFromStorage = 0x37985A0; // "public static Task<bool> DeserializeFromStorage(ISerializedModel serializedModel, ValueFileStorage storage)"
            inline constexpr std::uintptr_t Delete = 0x3798330; // "private static void Delete(ISerializedModel serializedModel, ValueFileStorage storage)"
        }
    } // namespace FileStorageRules

    namespace FirstAidCabinetPlayerData { // "Models.Data.FirstAidCabinetPlayerData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t OutbuildingFirstAidCabinets = 0x20; // "DictionaryData<OutbuildingSlotDescription, ISetData<FirstAidCabinetSlotDescription>>"
            inline constexpr std::uintptr_t MainBuildingFirstAidCabinets = 0x28; // "SetData<FirstAidCabinetSlotDescription>"
        }
    } // namespace FirstAidCabinetPlayerData

    namespace FirstAidCabinetUseProlongedAction { // "Game.Battle.Entities.Player.ProlongedActions.FirstAidCabinetUseProlongedAction (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "ProlongedInteractionModel"
            inline constexpr std::uintptr_t Label = 0x18; // "LocalizedString"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsActive = 0xB1D500; // "public bool get_IsActive()"
            inline constexpr std::uintptr_t get_EndTs = 0xB19D10; // "public long get_EndTs()"
            inline constexpr std::uintptr_t get_Duration = 0xB1D4A0; // "public long get_Duration()"
            inline constexpr std::uintptr_t Interrupt = 0xB1D3F0; // "public void Interrupt(BattleInputModel battleInputModel)"
        }
    } // namespace FirstAidCabinetUseProlongedAction

    namespace FloatInterpolationData { // "Game.Battle.EntityModel.BattleCharacter.FloatInterpolationData (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Data = 0x0; // "float"
            inline constexpr std::uintptr_t Ts = 0x8; // "long"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Interpolate = 0xCC3F50; // "public static FloatInterpolationData Interpolate(FloatInterpolationData from, FloatInterpolationData to, long ts)"
            inline constexpr std::uintptr_t WithNewTs = 0xCC3FC0; // "public static FloatInterpolationData WithNewTs(FloatInterpolationData source, long ts)"
            inline constexpr std::uintptr_t GetDt = 0xCC3ED0; // "private static float GetDt(long start, long end, long ts)"
        }
    } // namespace FloatInterpolationData

    namespace FocusKeeperPositionUpdater { // "Game.Battle.EntityModel.Player.FocusKeeperPositionUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleEntitiesModel = 0x10; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t cinemachineBrain = 0x18; // "CinemachineBrain"
            inline constexpr std::uintptr_t cinemachineTransform = 0x20; // "Transform"
            inline constexpr std::uintptr_t layerCollision = 0x28; // "int"
            inline constexpr std::uintptr_t armedCamera = 0x30; // "CinemachineVirtualCamera"
            inline constexpr std::uintptr_t aimingCameraFollow = 0x38; // "CinemachineAimingCameraFollow"
            inline constexpr std::uintptr_t rotationInputModel = 0x40; // "PlayerRotationInputModel"
            inline constexpr std::uintptr_t mixingCameraBlendModel = 0x48; // "MixingCameraBlendModel"
            inline constexpr std::uintptr_t oldBlendWeight = 0x50; // "float"
            inline constexpr std::uintptr_t oldBlendWeight2 = 0x54; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC38170; // "public void Update()"
            inline constexpr std::uintptr_t AngleCameraTargetShoulder = 0xC37E20; // "private float AngleCameraTargetShoulder(float blendWeight, float blendWeight2, float followToTargetMagnitude)"
            inline constexpr std::uintptr_t Cross = 0xC37FE0; // "private float Cross(Vector2 a, Vector2 b)"
            inline constexpr std::uintptr_t Pitch = 0xC38010; // "private static float Pitch(Vector2 origin, float hand, Vector2 target)"
            inline constexpr std::uintptr_t VectorYZ = 0xC38D20; // "private static Vector2 VectorYZ(Vector3 vector)"
            inline constexpr std::uintptr_t VectorXZ = 0xC38D00; // "private static Vector2 VectorXZ(Vector3 vector)"
        }
    } // namespace FocusKeeperPositionUpdater

    namespace ForceEnterAnimationStateUpdater { // "Game.Battle.Entities.BattleCharacter.Animations.ForceEnterAnimationStateUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t view = 0x10; // "CharacterAnimationView"
            inline constexpr std::uintptr_t character = 0x18; // "BattleCharacterModel"
            inline constexpr std::uintptr_t inKnockedOut = 0x20; // "bool"
            inline constexpr std::uintptr_t isCrouching = 0x21; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xBEDF20; // "public void Update()"
        }
    } // namespace ForceEnterAnimationStateUpdater

    namespace ForceSendInputUpdater { // "ClientCore.Prediction.ForceSendBattleInputUpdater.ForceSendInputUpdater (Client.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleInputModel = 0x10; // "BattleInputModel"
            inline constexpr std::uintptr_t time = 0x18; // "TimeModel"
            inline constexpr std::uintptr_t inputTickIndexToGuaranteedDelivery = 0x20; // "long"
            inline constexpr std::uintptr_t needForceSendInput = 0x28; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xE84560; // "public void Update()"
        }
    } // namespace ForceSendInputUpdater

    namespace GetAccessProlongedAction { // "Game.Battle.Entities.Player.ProlongedActions.GetAccessProlongedAction (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "ProlongedInteractionModel"
            inline constexpr std::uintptr_t worldEntitiesModel = 0x18; // "WorldEntitiesModel"
            inline constexpr std::uintptr_t accessEntityViewDescriptions = 0x20; // "AccessEntityViewDescriptions"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Label = 0xB1D7B0; // "public LocalizedString get_Label()"
            inline constexpr std::uintptr_t get_IsActive = 0xB1D7A0; // "public bool get_IsActive()"
            inline constexpr std::uintptr_t get_EndTs = 0xB19D10; // "public long get_EndTs()"
            inline constexpr std::uintptr_t get_Duration = 0xB1D6E0; // "public long get_Duration()"
            inline constexpr std::uintptr_t Interrupt = 0xB1D630; // "public void Interrupt(BattleInputModel battleInputModel)"
        }
    } // namespace GetAccessProlongedAction

    namespace GetOutHiddenObjectInputUpdater { // "Game.Battle.Inputs.GetOutHiddenObjectInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleEntitiesModel = 0x10; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t getOutHideObjectInputModel = 0x18; // "InputModel"
            inline constexpr std::uintptr_t roomConnectionsBattle = 0x20; // "IRoomConnection"
            inline constexpr std::uintptr_t isRequesting = 0x28; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA76B00; // "public void Update()"
            inline constexpr std::uintptr_t StartGetOut = 0xA76A50; // "private void StartGetOut()"
        }
    } // namespace GetOutHiddenObjectInputUpdater

    namespace GlobalPlayerRoleModel { // "Game.Global.GlobalPlayerRoleModel (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t PlayerRoleModel = 0x10; // "IPrimitiveModel<PlayerRoleDescription>"
        }
    } // namespace GlobalPlayerRoleModel

    namespace HardwareWarningInputActionUpdater { // "Game.HardwareWarningDialog.HardwareWarningInputActionUpdater (Game.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "HardwareWarningDialogModel"
            inline constexpr std::uintptr_t Handlers = 0x18; // "ValueTuple<InputMask, IUpdater>[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t OnQuitButtonClicked = 0x10C3510; // "private void OnQuitButtonClicked()"
            inline constexpr std::uintptr_t OnContinueButtonClicked = 0x10C34A0; // "private void OnContinueButtonClicked()"
            inline constexpr std::uintptr_t get_Priority = 0x10B1310; // "public InputHandlerPriority get_Priority()"
        }
    } // namespace HardwareWarningInputActionUpdater

    namespace HeadCharacterHeadManualControlRule { // "Game.Battle.EntityModel.BattleCharacter.HeadManualControl.HeadCharacterHeadManualControlRule (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t skeletonAnimationModel = 0x10; // "SkeletonAnimationModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xCD4380; // "public override void Update(Transform boneTransform, Quaternion constraintRotation, Quaternion lookRotation, float weight)"
        }
    } // namespace HeadCharacterHeadManualControlRule

    namespace HideInObjectProlongedAction { // "Game.Battle.Entities.Player.ProlongedActions.HideInObjectProlongedAction (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "ProlongedInteractionModel"
            inline constexpr std::uintptr_t location = 0x18; // "LocationDescription"
            inline constexpr std::uintptr_t entityId = 0x20; // "int"
            inline constexpr std::uintptr_t Label = 0x28; // "LocalizedString"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsActive = 0xB1DD00; // "public bool get_IsActive()"
            inline constexpr std::uintptr_t get_EndTs = 0xB19D10; // "public long get_EndTs()"
            inline constexpr std::uintptr_t get_UsePredictExtraTime = 0x7D5050; // "public bool get_UsePredictExtraTime()"
            inline constexpr std::uintptr_t get_Duration = 0xB1DC20; // "public long get_Duration()"
            inline constexpr std::uintptr_t get_LocationHideObjectDescription = 0xB1DD10; // "private LocationHideObjectDescription get_LocationHideObjectDescription()"
            inline constexpr std::uintptr_t Interrupt = 0xB1DAC0; // "public void Interrupt(BattleInputModel battleInputModel)"
            inline constexpr std::uintptr_t UpdateInterruptData = 0xB1DB80; // "public void UpdateInterruptData()"
        }
    } // namespace HideInObjectProlongedAction

    namespace HideItemByStateUpdater { // "Game.Battle.Entities.BattleCharacter.Equipment.HideItemByStateUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t stateModel = 0x10; // "IBattleCharacterStateModel"
            inline constexpr std::uintptr_t emotionModel = 0x18; // "EmotionModel"
            inline constexpr std::uintptr_t animationStateAssistant = 0x20; // "AnimationStateAssistant"
            inline constexpr std::uintptr_t characterAnimationView = 0x28; // "CharacterAnimationView"
            inline constexpr std::uintptr_t views = 0x30; // "List<GameObject>"
            inline constexpr std::uintptr_t isVisible = 0x38; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t IsVisible = 0xBEE5F0; // "private bool IsVisible()"
            inline constexpr std::uintptr_t Update = 0xBEE800; // "public void Update()"
            inline constexpr std::uintptr_t UpdateViews = 0xBEE6E0; // "private void UpdateViews()"
        }
    } // namespace HideItemByStateUpdater

    namespace HitsCacheModel { // "Game.Battle.EntityModel.Player.HitsCacheModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Ticks = 0x10; // "Queue<ValueTuple<long, long>>"
            inline constexpr std::uintptr_t LastMask = 0x18; // "long"
            inline constexpr std::uintptr_t LastTick = 0x20; // "long"
        }
    } // namespace HitsCacheModel

    namespace HitsCacheModelUpdater { // "Game.Battle.EntityModel.Player.HitsCacheModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t disconnectInfoModel = 0x10; // "DisconnectInfoModel"
            inline constexpr std::uintptr_t time = 0x18; // "TimeModel"
            inline constexpr std::uintptr_t hitsCacheModel = 0x20; // "HitsCacheModel"
            inline constexpr std::uintptr_t hitsModel = 0x28; // "HitsModel"
            inline constexpr std::uintptr_t lastTs = 0x30; // "long"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC38ED0; // "public void Update()"
        }
    } // namespace HitsCacheModelUpdater

    namespace IndexRollbackInputUpdater { // "Game.Battle.Inputs.IndexRollbackInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleInputModel = 0x10; // "BattleInputModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x18; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t time = 0x20; // "TimeModel"
            inline constexpr std::uintptr_t battleMode = 0x28; // "BattleModeDescription"
            inline constexpr std::uintptr_t lastTickIndex = 0x30; // "long"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA772E0; // "public void Update()"
        }
    } // namespace IndexRollbackInputUpdater

    namespace InitializeDevelopPlayerPrefsUpdater { // "Game.Global.PlayerPrefsFile.InitializeDevelopPlayerPrefsUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t globalModel = 0x10; // "GlobalModel"
            inline constexpr std::uintptr_t connectionState = 0x18; // "ConnectionState"
            inline constexpr std::uintptr_t playerPrefsName = 0x20; // "string"
            inline constexpr std::uintptr_t updater = 0x28; // "IUpdater"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x3798EB0; // "public void Update()"
            inline constexpr std::uintptr_t LoadPrefs = 0x3798DE0; // "private void LoadPrefs(ISerializedModel playerPrefsModel, ValueFileStorage fileStorage)"
        }
    } // namespace InitializeDevelopPlayerPrefsUpdater

    namespace InitializeSteamCloudPlayerPrefsUpdater { // "Game.Steam.InitializeSteamCloudPlayerPrefsUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t globalModel = 0x10; // "GlobalModel"
            inline constexpr std::uintptr_t playerPrefsFileName = 0x18; // "string"
            inline constexpr std::uintptr_t updater = 0x20; // "IUpdater"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x353A3E0; // "public void Update()"
            inline constexpr std::uintptr_t LoadPrefs = 0x353A310; // "private void LoadPrefs(ISerializedModel playerPrefsModel, ValueFileStorage fileStorage)"
        }
    } // namespace InitializeSteamCloudPlayerPrefsUpdater

    namespace InputActionBinder { // "Game.Global.SettingsDialog.InputActionBinder (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t inputsEnabledModel = 0x10; // "InputsEnabledModel"
            inline constexpr std::uintptr_t rebindingOperation = 0x18; // "InputActionRebindingExtensions.RebindingOperation"
            inline constexpr std::uintptr_t onCompleteRebindingAction = 0x20; // "Action<bool>"
            inline constexpr std::uintptr_t isRebinding = 0x28; // "bool"
            inline constexpr std::uintptr_t inputParameters = 0x30; // "ValueTuple<InputAction, int, InputControl, Action<bool>, bool>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t StartRebinding = 0x3736920; // "public void StartRebinding(InputAction action, int bindingIndex, InputControl cancelControl, Action<bool> onCompleteRebindingAction, bool hasMouseScroll, bool excludeLMB)"
            inline constexpr std::uintptr_t RebindComplete = 0x37368B0; // "private void RebindComplete(InputActionRebindingExtensions.RebindingOperation operation)"
            inline constexpr std::uintptr_t ExcludeLMB = 0x3736760; // "public void ExcludeLMB()"
            inline constexpr std::uintptr_t IncludeLMB = 0x3736830; // "public void IncludeLMB()"
            inline constexpr std::uintptr_t CancelRebinding = 0x3736730; // "public void CancelRebinding()"
            inline constexpr std::uintptr_t ForceStopRebinding = 0x37367E0; // "public void ForceStopRebinding()"
        }
    } // namespace InputActionBinder

    namespace InputActionBinderData { // "Game.Global.SettingsDialog.InputActionBinderData (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t view = 0x0; // "ControlActionBinderButton"
            inline constexpr std::uintptr_t category = 0x8; // "short"
            inline constexpr std::uintptr_t action = 0x10; // "InputAction"
            inline constexpr std::uintptr_t binderIndex = 0x18; // "int"
            inline constexpr std::uintptr_t isHold = 0x1C; // "bool"
            inline constexpr std::uintptr_t isMouseScrollBind = 0x1D; // "bool"
        }
    } // namespace InputActionBinderData

    namespace InputActionBindingPair { // "Game.Global.SettingsDialog.InputActionBindingPair (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Action = 0x0; // "InputAction"
            inline constexpr std::uintptr_t BinderIndex1 = 0x8; // "int"
            inline constexpr std::uintptr_t BinderIndex2 = 0xC; // "int"
            inline constexpr std::uintptr_t DeleteButton = 0x10; // "CompositeButtonView"
        }
        namespace Methods {
            inline constexpr std::uintptr_t NullifyBindings = 0x3736C20; // "public void NullifyBindings()"
            inline constexpr std::uintptr_t get_AreBindingsEmpty = 0x3736CD0; // "public bool get_AreBindingsEmpty()"
        }
    } // namespace InputActionBindingPair

    namespace InputActions { // "InputActions (Inputs.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t asset = 0x10; // "InputActionAsset"
            inline constexpr std::uintptr_t m_UI = 0x18; // "InputActionMap"
            inline constexpr std::uintptr_t m_UIActionsCallbackInterfaces = 0x20; // "List<InputActions.IUIActions>"
            inline constexpr std::uintptr_t m_UI_Navigate = 0x28; // "InputAction"
            inline constexpr std::uintptr_t m_UI_Submit = 0x30; // "InputAction"
            inline constexpr std::uintptr_t m_UI_SubmitHold = 0x38; // "InputAction"
            inline constexpr std::uintptr_t m_UI_Cancel = 0x40; // "InputAction"
            inline constexpr std::uintptr_t m_UI_Point = 0x48; // "InputAction"
            inline constexpr std::uintptr_t m_UI_Click = 0x50; // "InputAction"
            inline constexpr std::uintptr_t m_UI_ClickRelease = 0x58; // "InputAction"
            inline constexpr std::uintptr_t m_UI_ScrollWheel = 0x60; // "InputAction"
            inline constexpr std::uintptr_t m_UI_MiddleClick = 0x68; // "InputAction"
            inline constexpr std::uintptr_t m_UI_RightClick = 0x70; // "InputAction"
            inline constexpr std::uintptr_t m_UI_TrackedDevicePosition = 0x78; // "InputAction"
            inline constexpr std::uintptr_t m_UI_TrackedDeviceOrientation = 0x80; // "InputAction"
            inline constexpr std::uintptr_t m_UI_AnyKey = 0x88; // "InputAction"
            inline constexpr std::uintptr_t m_UI_NextTab = 0x90; // "InputAction"
            inline constexpr std::uintptr_t m_UI_ShiftModifier = 0x98; // "InputAction"
            inline constexpr std::uintptr_t m_UI_AnyAction = 0xA0; // "InputAction"
            inline constexpr std::uintptr_t m_UI_Tap = 0xA8; // "InputAction"
            inline constexpr std::uintptr_t m_UI_ClientBuildInspector = 0xB0; // "InputAction"
            inline constexpr std::uintptr_t m_Battle = 0xB8; // "InputActionMap"
            inline constexpr std::uintptr_t m_BattleActionsCallbackInterfaces = 0xC0; // "List<InputActions.IBattleActions>"
            inline constexpr std::uintptr_t m_Battle_Back = 0xC8; // "InputAction"
            inline constexpr std::uintptr_t m_Battle_BecomeRobber = 0xD0; // "InputAction"
            inline constexpr std::uintptr_t m_Battle_CarSkinZoomInOut = 0xD8; // "InputAction"
            inline constexpr std::uintptr_t m_Battle_Clan = 0xE0; // "InputAction"
            inline constexpr std::uintptr_t m_Battle_RevokeAllBets = 0xE8; // "InputAction"
            inline constexpr std::uintptr_t m_Battle_ClanShowdown = 0xF0; // "InputAction"
            inline constexpr std::uintptr_t m_Battle_Chat = 0xF8; // "InputAction"
            inline constexpr std::uintptr_t m_Battle_VoiceChat = 0x100; // "InputAction"
            inline constexpr std::uintptr_t m_Battle_CheatUiVisual = 0x108; // "InputAction"
            inline constexpr std::uintptr_t m_Battle_ClanEdit = 0x110; // "InputAction"
            inline constexpr std::uintptr_t m_Battle_CloseLaptop = 0x118; // "InputAction"
            inline constexpr std::uintptr_t m_Battle_ClosePartyManager = 0x120; // "InputAction"
            inline constexpr std::uintptr_t m_Battle_Codex = 0x128; // "InputAction"
            inline constexpr std::uintptr_t m_Battle_OpenBuff = 0x130; // "InputAction"
            inline constexpr std::uintptr_t m_Battle_Mail = 0x138; // "InputAction"
            inline constexpr std::uintptr_t m_Battle_VendorTree = 0x140; // "InputAction"
            inline constexpr std::uintptr_t m_Battle_FastMoveInventory = 0x148; // "InputAction"
            inline constexpr std::uintptr_t m_Battle_Emotion = 0x150; // "InputAction"
            inline constexpr std::uintptr_t m_Battle_ForceKnockoutEnd = 0x158; // "InputAction"
            inline constexpr std::uintptr_t m_Battle_HintNext = 0x160; // "InputAction"
            inline constexpr std::uintptr_t m_Battle_HintPrev = 0x168; // "InputAction"
            inline constexpr std::uintptr_t m_Battle_Inventory = 0x170; // "InputAction"
            inline constexpr std::uintptr_t m_Battle_Look = 0x178; // "InputAction"
            inline constexpr std::uintptr_t m_Battle_Map = 0x180; // "InputAction"
            inline constexpr std::uintptr_t m_Battle_PartyManager = 0x188; // "InputAction"
            inline constexpr std::uintptr_t m_Battle_PointerPosition = 0x190; // "InputAction"
            inline constexpr std::uintptr_t m_Battle_PopupConfirm = 0x198; // "InputAction"
            inline constexpr std::uintptr_t m_Battle_PopupDecline = 0x1A0; // "InputAction"
            inline constexpr std::uintptr_t m_Battle_ResetSettings = 0x1A8; // "InputAction"
            inline constexpr std::uintptr_t m_Battle_Scroll = 0x1B0; // "InputAction"
            inline constexpr std::uintptr_t m_Battle_SideMenu = 0x1B8; // "InputAction"
            inline constexpr std::uintptr_t m_Battle_Slot1 = 0x1C0; // "InputAction"
            inline constexpr std::uintptr_t m_Battle_Slot2 = 0x1C8; // "InputAction"
            inline constexpr std::uintptr_t m_Battle_Slot3 = 0x1D0; // "InputAction"
            inline constexpr std::uintptr_t m_Battle_Slot4 = 0x1D8; // "InputAction"
            inline constexpr std::uintptr_t m_Battle_Slot5 = 0x1E0; // "InputAction"
            inline constexpr std::uintptr_t m_Battle_Slot6 = 0x1E8; // "InputAction"
            inline constexpr std::uintptr_t m_Battle_Slot7 = 0x1F0; // "InputAction"
            inline constexpr std::uintptr_t m_Battle_Slot8 = 0x1F8; // "InputAction"
            inline constexpr std::uintptr_t m_Battle_SplitOnDrop = 0x200; // "InputAction"
            inline constexpr std::uintptr_t m_Battle_ShowCursor = 0x208; // "InputAction"
            inline constexpr std::uintptr_t m_Battle_Submit = 0x210; // "InputAction"
            inline constexpr std::uintptr_t m_Battle_OfferBribe = 0x218; // "InputAction"
            inline constexpr std::uintptr_t m_Battle_DeleteHold = 0x220; // "InputAction"
            inline constexpr std::uintptr_t m_Battle_TransferHold = 0x228; // "InputAction"
            inline constexpr std::uintptr_t m_Battle_SurrenderArresting = 0x230; // "InputAction"
            inline constexpr std::uintptr_t m_Battle_SurrenderOrder = 0x238; // "InputAction"
            inline constexpr std::uintptr_t m_Battle_TalkDown = 0x240; // "InputAction"
            inline constexpr std::uintptr_t m_Battle_TalkSkip = 0x248; // "InputAction"
            inline constexpr std::uintptr_t m_Battle_TalkUp = 0x250; // "InputAction"
            inline constexpr std::uintptr_t m_Battle_TouchFirstPosition = 0x258; // "InputAction"
            inline constexpr std::uintptr_t m_Battle_TouchSecondContactPress = 0x260; // "InputAction"
            inline constexpr std::uintptr_t m_Battle_TouchSecondContactRelease = 0x268; // "InputAction"
            inline constexpr std::uintptr_t m_Battle_TouchSecondPosition = 0x270; // "InputAction"
            inline constexpr std::uintptr_t m_Battle_UseHold = 0x278; // "InputAction"
            inline constexpr std::uintptr_t m_Battle_Use = 0x280; // "InputAction"
            inline constexpr std::uintptr_t m_Battle_ZoomIn = 0x288; // "InputAction"
            inline constexpr std::uintptr_t m_Battle_ZoomOut = 0x290; // "InputAction"
            inline constexpr std::uintptr_t m_Observer = 0x298; // "InputActionMap"
            inline constexpr std::uintptr_t m_ObserverActionsCallbackInterfaces = 0x2A0; // "List<InputActions.IObserverActions>"
            inline constexpr std::uintptr_t m_Observer_Move = 0x2A8; // "InputAction"
            inline constexpr std::uintptr_t m_Observer_Look = 0x2B0; // "InputAction"
            inline constexpr std::uintptr_t m_Observer_MoveDown = 0x2B8; // "InputAction"
            inline constexpr std::uintptr_t m_Observer_MoveUp = 0x2C0; // "InputAction"
            inline constexpr std::uintptr_t m_Observer_MoveXZToggle = 0x2C8; // "InputAction"
            inline constexpr std::uintptr_t m_Observer_MoveAcceleration = 0x2D0; // "InputAction"
            inline constexpr std::uintptr_t m_Observer_MouseVisibleToggle = 0x2D8; // "InputAction"
            inline constexpr std::uintptr_t m_Observer_MoveSpeedUp = 0x2E0; // "InputAction"
            inline constexpr std::uintptr_t m_Observer_MoveSpeedDown = 0x2E8; // "InputAction"
            inline constexpr std::uintptr_t m_Observer_MoveAccelerationUp = 0x2F0; // "InputAction"
            inline constexpr std::uintptr_t m_Observer_MoveAccelerationDown = 0x2F8; // "InputAction"
            inline constexpr std::uintptr_t m_Observer_RotateSpeedUp = 0x300; // "InputAction"
            inline constexpr std::uintptr_t m_Observer_RotateSpeedDown = 0x308; // "InputAction"
            inline constexpr std::uintptr_t m_Observer_RotateAccelerationUp = 0x310; // "InputAction"
            inline constexpr std::uintptr_t m_Observer_RotateAccelerationDown = 0x318; // "InputAction"
            inline constexpr std::uintptr_t m_Observer_FovUp = 0x320; // "InputAction"
            inline constexpr std::uintptr_t m_Observer_FovDown = 0x328; // "InputAction"
            inline constexpr std::uintptr_t m_Observer_FovAccelerationUp = 0x330; // "InputAction"
            inline constexpr std::uintptr_t m_Observer_FovAccelerationDown = 0x338; // "InputAction"
            inline constexpr std::uintptr_t m_CharacterControl = 0x340; // "InputActionMap"
            inline constexpr std::uintptr_t m_CharacterControlActionsCallbackInterfaces = 0x348; // "List<InputActions.ICharacterControlActions>"
            inline constexpr std::uintptr_t m_CharacterControl_ActiveBollard = 0x350; // "InputAction"
            inline constexpr std::uintptr_t m_CharacterControl_Aim = 0x358; // "InputAction"
            inline constexpr std::uintptr_t m_CharacterControl_CarBurnout = 0x360; // "InputAction"
            inline constexpr std::uintptr_t m_CharacterControl_CarHandBrake = 0x368; // "InputAction"
            inline constexpr std::uintptr_t m_CharacterControl_CarHorn = 0x370; // "InputAction"
            inline constexpr std::uintptr_t m_CharacterControl_CarMove = 0x378; // "InputAction"
            inline constexpr std::uintptr_t m_CharacterControl_Crouch = 0x380; // "InputAction"
            inline constexpr std::uintptr_t m_CharacterControl_DropCargo = 0x388; // "InputAction"
            inline constexpr std::uintptr_t m_CharacterControl_HelicopterPitchRollCod = 0x390; // "InputAction"
            inline constexpr std::uintptr_t m_CharacterControl_HelicopterThrustCoD = 0x398; // "InputAction"
            inline constexpr std::uintptr_t m_CharacterControl_HelicopterPitchRollGTA = 0x3A0; // "InputAction"
            inline constexpr std::uintptr_t m_CharacterControl_HelicopterRMBCoD = 0x3A8; // "InputAction"
            inline constexpr std::uintptr_t m_CharacterControl_HelicopterThrustGTA = 0x3B0; // "InputAction"
            inline constexpr std::uintptr_t m_CharacterControl_HelicopterYawGTA = 0x3B8; // "InputAction"
            inline constexpr std::uintptr_t m_CharacterControl_HelicopterRMBGTA = 0x3C0; // "InputAction"
            inline constexpr std::uintptr_t m_CharacterControl_HelicopterDeltaMouse = 0x3C8; // "InputAction"
            inline constexpr std::uintptr_t m_CharacterControl_Jump = 0x3D0; // "InputAction"
            inline constexpr std::uintptr_t m_CharacterControl_Move = 0x3D8; // "InputAction"
            inline constexpr std::uintptr_t m_CharacterControl_MeleeAttack = 0x3E0; // "InputAction"
            inline constexpr std::uintptr_t m_CharacterControl_PingMark = 0x3E8; // "InputAction"
            inline constexpr std::uintptr_t m_CharacterControl_PocketQuickSlot0 = 0x3F0; // "InputAction"
            inline constexpr std::uintptr_t m_CharacterControl_PocketQuickSlot1 = 0x3F8; // "InputAction"
            inline constexpr std::uintptr_t m_CharacterControl_PocketQuickSlot2 = 0x400; // "InputAction"
            inline constexpr std::uintptr_t m_CharacterControl_PocketQuickSlot3 = 0x408; // "InputAction"
            inline constexpr std::uintptr_t m_CharacterControl_RadioNextStation = 0x410; // "InputAction"
            inline constexpr std::uintptr_t m_CharacterControl_Siren = 0x418; // "InputAction"
            inline constexpr std::uintptr_t m_CharacterControl_Sprint = 0x420; // "InputAction"
            inline constexpr std::uintptr_t m_CharacterControl_Shot = 0x428; // "InputAction"
            inline constexpr std::uintptr_t m_CharacterControl_Surrender = 0x430; // "InputAction"
            inline constexpr std::uintptr_t m_CharacterControl_SwitchAimShoulder = 0x438; // "InputAction"
            inline constexpr std::uintptr_t m_CharacterControl_TurnAimMode = 0x440; // "InputAction"
            inline constexpr std::uintptr_t m_CharacterControl_WeaponReload = 0x448; // "InputAction"
            inline constexpr std::uintptr_t m_CharacterControl_WeaponQuickSlot0 = 0x450; // "InputAction"
            inline constexpr std::uintptr_t m_CharacterControl_WeaponQuickSlot1 = 0x458; // "InputAction"
            inline constexpr std::uintptr_t m_CharacterControl_ToggleSelectedItem = 0x460; // "InputAction"
            inline constexpr std::uintptr_t m_CharacterControl_NextItem = 0x468; // "InputAction"
            inline constexpr std::uintptr_t m_CharacterControl_PrevItem = 0x470; // "InputAction"
            inline constexpr std::uintptr_t m_KeyboardMouseSchemeIndex = 0x478; // "int"
            inline constexpr std::uintptr_t m_TouchSchemeIndex = 0x47C; // "int"
            inline constexpr std::uintptr_t m_EditorTouchSchemeIndex = 0x480; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Dispose = 0x37EF210; // "public void Dispose()"
            inline constexpr std::uintptr_t get_bindingMask = 0x37F1B10; // "public Nullable<InputBinding> get_bindingMask()"
            inline constexpr std::uintptr_t set_bindingMask = 0x37F1C00; // "public void set_bindingMask(Nullable<InputBinding> value)"
            inline constexpr std::uintptr_t get_devices = 0x37F1BC0; // "public Nullable<ReadOnlyArray<InputDevice>> get_devices()"
            inline constexpr std::uintptr_t set_devices = 0x37F1C60; // "public void set_devices(Nullable<ReadOnlyArray<InputDevice>> value)"
            inline constexpr std::uintptr_t get_controlSchemes = 0x37F1B80; // "public ReadOnlyArray<InputControlScheme> get_controlSchemes()"
            inline constexpr std::uintptr_t Contains = 0x37EF1D0; // "public bool Contains(InputAction action)"
            inline constexpr std::uintptr_t GetEnumerator = 0x37EF340; // "public IEnumerator<InputAction> GetEnumerator()"
            inline constexpr std::uintptr_t System_Collections_IEnumerable_GetEnumerator = 0x37EF340; // "private IEnumerator System.Collections.IEnumerable.GetEnumerator()"
            inline constexpr std::uintptr_t Enable = 0x37EF260; // "public void Enable()"
            inline constexpr std::uintptr_t Disable = 0x37EF1F0; // "public void Disable()"
            inline constexpr std::uintptr_t get_bindings = 0x37F1B60; // "public IEnumerable<InputBinding> get_bindings()"
            inline constexpr std::uintptr_t FindAction = 0x37EF2C0; // "public InputAction FindAction(string actionNameOrId, bool throwIfNotFound)"
            inline constexpr std::uintptr_t FindBinding = 0x37EF2E0; // "public int FindBinding(InputBinding bindingMask, out InputAction action)"
            inline constexpr std::uintptr_t get_UI = 0x37F1880; // "public InputActions.UIActions get_UI()"
            inline constexpr std::uintptr_t get_Battle = 0x37F1880; // "public InputActions.BattleActions get_Battle()"
            inline constexpr std::uintptr_t get_Observer = 0x37F1880; // "public InputActions.ObserverActions get_Observer()"
            inline constexpr std::uintptr_t get_CharacterControl = 0x37F1880; // "public InputActions.CharacterControlActions get_CharacterControl()"
            inline constexpr std::uintptr_t get_KeyboardMouseScheme = 0x37F1970; // "public InputControlScheme get_KeyboardMouseScheme()"
            inline constexpr std::uintptr_t get_TouchScheme = 0x37F1A40; // "public InputControlScheme get_TouchScheme()"
            inline constexpr std::uintptr_t get_EditorTouchScheme = 0x37F18A0; // "public InputControlScheme get_EditorTouchScheme()"
        }
    } // namespace InputActions

    namespace InputActions_BattleActions { // "InputActions.BattleActions (Inputs.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t m_Wrapper = 0x0; // "InputActions"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Back = 0x37E6320; // "public InputAction get_Back()"
            inline constexpr std::uintptr_t get_BecomeRobber = 0x37E6340; // "public InputAction get_BecomeRobber()"
            inline constexpr std::uintptr_t get_CarSkinZoomInOut = 0x37E6360; // "public InputAction get_CarSkinZoomInOut()"
            inline constexpr std::uintptr_t get_Clan = 0x37E6400; // "public InputAction get_Clan()"
            inline constexpr std::uintptr_t get_RevokeAllBets = 0x37E66A0; // "public InputAction get_RevokeAllBets()"
            inline constexpr std::uintptr_t get_ClanShowdown = 0x37E63E0; // "public InputAction get_ClanShowdown()"
            inline constexpr std::uintptr_t get_Chat = 0x37E6380; // "public InputAction get_Chat()"
            inline constexpr std::uintptr_t get_VoiceChat = 0x37E6A00; // "public InputAction get_VoiceChat()"
            inline constexpr std::uintptr_t get_CheatUiVisual = 0x37E63A0; // "public InputAction get_CheatUiVisual()"
            inline constexpr std::uintptr_t get_ClanEdit = 0x37E63C0; // "public InputAction get_ClanEdit()"
            inline constexpr std::uintptr_t get_CloseLaptop = 0x37E6420; // "public InputAction get_CloseLaptop()"
            inline constexpr std::uintptr_t get_ClosePartyManager = 0x37E6440; // "public InputAction get_ClosePartyManager()"
            inline constexpr std::uintptr_t get_Codex = 0x37E6460; // "public InputAction get_Codex()"
            inline constexpr std::uintptr_t get_OpenBuff = 0x37E65E0; // "public InputAction get_OpenBuff()"
            inline constexpr std::uintptr_t get_Mail = 0x37E6580; // "public InputAction get_Mail()"
            inline constexpr std::uintptr_t get_VendorTree = 0x37E69E0; // "public InputAction get_VendorTree()"
            inline constexpr std::uintptr_t get_FastMoveInventory = 0x37E64C0; // "public InputAction get_FastMoveInventory()"
            inline constexpr std::uintptr_t get_Emotion = 0x37E64A0; // "public InputAction get_Emotion()"
            inline constexpr std::uintptr_t get_ForceKnockoutEnd = 0x37E64E0; // "public InputAction get_ForceKnockoutEnd()"
            inline constexpr std::uintptr_t get_HintNext = 0x37E6500; // "public InputAction get_HintNext()"
            inline constexpr std::uintptr_t get_HintPrev = 0x37E6520; // "public InputAction get_HintPrev()"
            inline constexpr std::uintptr_t get_Inventory = 0x37E6540; // "public InputAction get_Inventory()"
            inline constexpr std::uintptr_t get_Look = 0x37E6560; // "public InputAction get_Look()"
            inline constexpr std::uintptr_t get_Map = 0x37E65A0; // "public InputAction get_Map()"
            inline constexpr std::uintptr_t get_PartyManager = 0x37E6600; // "public InputAction get_PartyManager()"
            inline constexpr std::uintptr_t get_PointerPosition = 0x37E6620; // "public InputAction get_PointerPosition()"
            inline constexpr std::uintptr_t get_PopupConfirm = 0x37E6640; // "public InputAction get_PopupConfirm()"
            inline constexpr std::uintptr_t get_PopupDecline = 0x37E6660; // "public InputAction get_PopupDecline()"
            inline constexpr std::uintptr_t get_ResetSettings = 0x37E6680; // "public InputAction get_ResetSettings()"
            inline constexpr std::uintptr_t get_Scroll = 0x37E66C0; // "public InputAction get_Scroll()"
            inline constexpr std::uintptr_t get_SideMenu = 0x37E6700; // "public InputAction get_SideMenu()"
            inline constexpr std::uintptr_t get_Slot1 = 0x37E6720; // "public InputAction get_Slot1()"
            inline constexpr std::uintptr_t get_Slot2 = 0x37E6740; // "public InputAction get_Slot2()"
            inline constexpr std::uintptr_t get_Slot3 = 0x37E6760; // "public InputAction get_Slot3()"
            inline constexpr std::uintptr_t get_Slot4 = 0x37E6780; // "public InputAction get_Slot4()"
            inline constexpr std::uintptr_t get_Slot5 = 0x37E67A0; // "public InputAction get_Slot5()"
            inline constexpr std::uintptr_t get_Slot6 = 0x37E67C0; // "public InputAction get_Slot6()"
            inline constexpr std::uintptr_t get_Slot7 = 0x37E67E0; // "public InputAction get_Slot7()"
            inline constexpr std::uintptr_t get_Slot8 = 0x37E6800; // "public InputAction get_Slot8()"
            inline constexpr std::uintptr_t get_SplitOnDrop = 0x37E6820; // "public InputAction get_SplitOnDrop()"
            inline constexpr std::uintptr_t get_ShowCursor = 0x37E66E0; // "public InputAction get_ShowCursor()"
            inline constexpr std::uintptr_t get_Submit = 0x37E6840; // "public InputAction get_Submit()"
            inline constexpr std::uintptr_t get_OfferBribe = 0x37E65C0; // "public InputAction get_OfferBribe()"
            inline constexpr std::uintptr_t get_DeleteHold = 0x37E6480; // "public InputAction get_DeleteHold()"
            inline constexpr std::uintptr_t get_TransferHold = 0x37E6980; // "public InputAction get_TransferHold()"
            inline constexpr std::uintptr_t get_SurrenderArresting = 0x37E6860; // "public InputAction get_SurrenderArresting()"
            inline constexpr std::uintptr_t get_SurrenderOrder = 0x37E6880; // "public InputAction get_SurrenderOrder()"
            inline constexpr std::uintptr_t get_TalkDown = 0x37E68A0; // "public InputAction get_TalkDown()"
            inline constexpr std::uintptr_t get_TalkSkip = 0x37E68C0; // "public InputAction get_TalkSkip()"
            inline constexpr std::uintptr_t get_TalkUp = 0x37E68E0; // "public InputAction get_TalkUp()"
            inline constexpr std::uintptr_t get_TouchFirstPosition = 0x37E6900; // "public InputAction get_TouchFirstPosition()"
            inline constexpr std::uintptr_t get_TouchSecondContactPress = 0x37E6920; // "public InputAction get_TouchSecondContactPress()"
            inline constexpr std::uintptr_t get_TouchSecondContactRelease = 0x37E6940; // "public InputAction get_TouchSecondContactRelease()"
            inline constexpr std::uintptr_t get_TouchSecondPosition = 0x37E6960; // "public InputAction get_TouchSecondPosition()"
            inline constexpr std::uintptr_t get_UseHold = 0x37E69A0; // "public InputAction get_UseHold()"
            inline constexpr std::uintptr_t get_Use = 0x37E69C0; // "public InputAction get_Use()"
            inline constexpr std::uintptr_t get_ZoomIn = 0x37E6A20; // "public InputAction get_ZoomIn()"
            inline constexpr std::uintptr_t get_ZoomOut = 0x37E6A40; // "public InputAction get_ZoomOut()"
            inline constexpr std::uintptr_t Get = 0x37E0FC0; // "public InputActionMap Get()"
            inline constexpr std::uintptr_t Enable = 0x37E0F90; // "public void Enable()"
            inline constexpr std::uintptr_t Disable = 0x37E0F60; // "public void Disable()"
            inline constexpr std::uintptr_t get_enabled = 0x37E6A60; // "public bool get_enabled()"
            inline constexpr std::uintptr_t op_Implicit = 0x37E6A90; // "public static InputActionMap op_Implicit(InputActions.BattleActions set)"
            inline constexpr std::uintptr_t AddCallbacks = 0x37DBEB0; // "public void AddCallbacks(InputActions.IBattleActions instance)"
            inline constexpr std::uintptr_t UnregisterCallbacks = 0x37E1210; // "private void UnregisterCallbacks(InputActions.IBattleActions instance)"
            inline constexpr std::uintptr_t RemoveCallbacks = 0x37E0FE0; // "public void RemoveCallbacks(InputActions.IBattleActions instance)"
            inline constexpr std::uintptr_t SetCallbacks = 0x37E1060; // "public void SetCallbacks(InputActions.IBattleActions instance)"
        }
    } // namespace InputActions_BattleActions

    namespace InputActions_CharacterControlActions { // "InputActions.CharacterControlActions (Inputs.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t m_Wrapper = 0x0; // "InputActions"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_ActiveBollard = 0x37EECD0; // "public InputAction get_ActiveBollard()"
            inline constexpr std::uintptr_t get_Aim = 0x37EECF0; // "public InputAction get_Aim()"
            inline constexpr std::uintptr_t get_CarBurnout = 0x37EED10; // "public InputAction get_CarBurnout()"
            inline constexpr std::uintptr_t get_CarHandBrake = 0x37EED30; // "public InputAction get_CarHandBrake()"
            inline constexpr std::uintptr_t get_CarHorn = 0x37EED50; // "public InputAction get_CarHorn()"
            inline constexpr std::uintptr_t get_CarMove = 0x37EED70; // "public InputAction get_CarMove()"
            inline constexpr std::uintptr_t get_Crouch = 0x37EED90; // "public InputAction get_Crouch()"
            inline constexpr std::uintptr_t get_DropCargo = 0x37EEDB0; // "public InputAction get_DropCargo()"
            inline constexpr std::uintptr_t get_HelicopterPitchRollCod = 0x37EEDF0; // "public InputAction get_HelicopterPitchRollCod()"
            inline constexpr std::uintptr_t get_HelicopterThrustCoD = 0x37EEE70; // "public InputAction get_HelicopterThrustCoD()"
            inline constexpr std::uintptr_t get_HelicopterPitchRollGTA = 0x37EEE10; // "public InputAction get_HelicopterPitchRollGTA()"
            inline constexpr std::uintptr_t get_HelicopterRMBCoD = 0x37EEE30; // "public InputAction get_HelicopterRMBCoD()"
            inline constexpr std::uintptr_t get_HelicopterThrustGTA = 0x37EEE90; // "public InputAction get_HelicopterThrustGTA()"
            inline constexpr std::uintptr_t get_HelicopterYawGTA = 0x37EEEB0; // "public InputAction get_HelicopterYawGTA()"
            inline constexpr std::uintptr_t get_HelicopterRMBGTA = 0x37EEE50; // "public InputAction get_HelicopterRMBGTA()"
            inline constexpr std::uintptr_t get_HelicopterDeltaMouse = 0x37EEDD0; // "public InputAction get_HelicopterDeltaMouse()"
            inline constexpr std::uintptr_t get_Jump = 0x37EEED0; // "public InputAction get_Jump()"
            inline constexpr std::uintptr_t get_Move = 0x37EEF10; // "public InputAction get_Move()"
            inline constexpr std::uintptr_t get_MeleeAttack = 0x37EEEF0; // "public InputAction get_MeleeAttack()"
            inline constexpr std::uintptr_t get_PingMark = 0x37EEF50; // "public InputAction get_PingMark()"
            inline constexpr std::uintptr_t get_PocketQuickSlot0 = 0x37EEF70; // "public InputAction get_PocketQuickSlot0()"
            inline constexpr std::uintptr_t get_PocketQuickSlot1 = 0x37EEF90; // "public InputAction get_PocketQuickSlot1()"
            inline constexpr std::uintptr_t get_PocketQuickSlot2 = 0x37EEFB0; // "public InputAction get_PocketQuickSlot2()"
            inline constexpr std::uintptr_t get_PocketQuickSlot3 = 0x37EEFD0; // "public InputAction get_PocketQuickSlot3()"
            inline constexpr std::uintptr_t get_RadioNextStation = 0x37EF010; // "public InputAction get_RadioNextStation()"
            inline constexpr std::uintptr_t get_Siren = 0x37EF050; // "public InputAction get_Siren()"
            inline constexpr std::uintptr_t get_Sprint = 0x37EF070; // "public InputAction get_Sprint()"
            inline constexpr std::uintptr_t get_Shot = 0x37EF030; // "public InputAction get_Shot()"
            inline constexpr std::uintptr_t get_Surrender = 0x37EF090; // "public InputAction get_Surrender()"
            inline constexpr std::uintptr_t get_SwitchAimShoulder = 0x37EF0B0; // "public InputAction get_SwitchAimShoulder()"
            inline constexpr std::uintptr_t get_TurnAimMode = 0x37EF0F0; // "public InputAction get_TurnAimMode()"
            inline constexpr std::uintptr_t get_WeaponReload = 0x37EF150; // "public InputAction get_WeaponReload()"
            inline constexpr std::uintptr_t get_WeaponQuickSlot0 = 0x37EF110; // "public InputAction get_WeaponQuickSlot0()"
            inline constexpr std::uintptr_t get_WeaponQuickSlot1 = 0x37EF130; // "public InputAction get_WeaponQuickSlot1()"
            inline constexpr std::uintptr_t get_ToggleSelectedItem = 0x37EF0D0; // "public InputAction get_ToggleSelectedItem()"
            inline constexpr std::uintptr_t get_NextItem = 0x37EEF30; // "public InputAction get_NextItem()"
            inline constexpr std::uintptr_t get_PrevItem = 0x37EEFF0; // "public InputAction get_PrevItem()"
            inline constexpr std::uintptr_t Get = 0x37EAB70; // "public InputActionMap Get()"
            inline constexpr std::uintptr_t Enable = 0x37EAB40; // "public void Enable()"
            inline constexpr std::uintptr_t Disable = 0x37EAB10; // "public void Disable()"
            inline constexpr std::uintptr_t get_enabled = 0x37EF170; // "public bool get_enabled()"
            inline constexpr std::uintptr_t op_Implicit = 0x37EF1A0; // "public static InputActionMap op_Implicit(InputActions.CharacterControlActions set)"
            inline constexpr std::uintptr_t AddCallbacks = 0x37E6C70; // "public void AddCallbacks(InputActions.ICharacterControlActions instance)"
            inline constexpr std::uintptr_t UnregisterCallbacks = 0x37EADC0; // "private void UnregisterCallbacks(InputActions.ICharacterControlActions instance)"
            inline constexpr std::uintptr_t RemoveCallbacks = 0x37EAB90; // "public void RemoveCallbacks(InputActions.ICharacterControlActions instance)"
            inline constexpr std::uintptr_t SetCallbacks = 0x37EAC10; // "public void SetCallbacks(InputActions.ICharacterControlActions instance)"
        }
    } // namespace InputActions_CharacterControlActions

    namespace InputActions_ObserverActions { // "InputActions.ObserverActions (Inputs.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t m_Wrapper = 0x0; // "InputActions"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Move = 0x37F80E0; // "public InputAction get_Move()"
            inline constexpr std::uintptr_t get_Look = 0x37F7FA0; // "public InputAction get_Look()"
            inline constexpr std::uintptr_t get_MoveDown = 0x37F8040; // "public InputAction get_MoveDown()"
            inline constexpr std::uintptr_t get_MoveUp = 0x37F80A0; // "public InputAction get_MoveUp()"
            inline constexpr std::uintptr_t get_MoveXZToggle = 0x37F80C0; // "public InputAction get_MoveXZToggle()"
            inline constexpr std::uintptr_t get_MoveAcceleration = 0x37F8020; // "public InputAction get_MoveAcceleration()"
            inline constexpr std::uintptr_t get_MouseVisibleToggle = 0x37F7FC0; // "public InputAction get_MouseVisibleToggle()"
            inline constexpr std::uintptr_t get_MoveSpeedUp = 0x37F8080; // "public InputAction get_MoveSpeedUp()"
            inline constexpr std::uintptr_t get_MoveSpeedDown = 0x37F8060; // "public InputAction get_MoveSpeedDown()"
            inline constexpr std::uintptr_t get_MoveAccelerationUp = 0x37F8000; // "public InputAction get_MoveAccelerationUp()"
            inline constexpr std::uintptr_t get_MoveAccelerationDown = 0x37F7FE0; // "public InputAction get_MoveAccelerationDown()"
            inline constexpr std::uintptr_t get_RotateSpeedUp = 0x37F8160; // "public InputAction get_RotateSpeedUp()"
            inline constexpr std::uintptr_t get_RotateSpeedDown = 0x37F8140; // "public InputAction get_RotateSpeedDown()"
            inline constexpr std::uintptr_t get_RotateAccelerationUp = 0x37F8120; // "public InputAction get_RotateAccelerationUp()"
            inline constexpr std::uintptr_t get_RotateAccelerationDown = 0x37F8100; // "public InputAction get_RotateAccelerationDown()"
            inline constexpr std::uintptr_t get_FovUp = 0x37F7F80; // "public InputAction get_FovUp()"
            inline constexpr std::uintptr_t get_FovDown = 0x37F7F60; // "public InputAction get_FovDown()"
            inline constexpr std::uintptr_t get_FovAccelerationUp = 0x37F7F40; // "public InputAction get_FovAccelerationUp()"
            inline constexpr std::uintptr_t get_FovAccelerationDown = 0x37F7F20; // "public InputAction get_FovAccelerationDown()"
            inline constexpr std::uintptr_t Get = 0x37F5140; // "public InputActionMap Get()"
            inline constexpr std::uintptr_t Enable = 0x37F5110; // "public void Enable()"
            inline constexpr std::uintptr_t Disable = 0x37F50E0; // "public void Disable()"
            inline constexpr std::uintptr_t get_enabled = 0x37F8180; // "public bool get_enabled()"
            inline constexpr std::uintptr_t op_Implicit = 0x37F81B0; // "public static InputActionMap op_Implicit(InputActions.ObserverActions set)"
            inline constexpr std::uintptr_t AddCallbacks = 0x37F2480; // "public void AddCallbacks(InputActions.IObserverActions instance)"
            inline constexpr std::uintptr_t UnregisterCallbacks = 0x37F5390; // "private void UnregisterCallbacks(InputActions.IObserverActions instance)"
            inline constexpr std::uintptr_t RemoveCallbacks = 0x37F5160; // "public void RemoveCallbacks(InputActions.IObserverActions instance)"
            inline constexpr std::uintptr_t SetCallbacks = 0x37F51E0; // "public void SetCallbacks(InputActions.IObserverActions instance)"
        }
    } // namespace InputActions_ObserverActions

    namespace InputActionsContainer { // "Game.Global.Settings.InputActionsContainer (Global.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x825AA98; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t OnInputActionsBindsChanged = 0x0; // "Action"
            inline constexpr std::uintptr_t inputActionsMap = 0x8; // "Dictionary<InputActionsContainer.InputBattleActionsType, InputAction>"
            inline constexpr std::uintptr_t ignoringInputActions = 0x10; // "HashSet<InputActionsContainer.InputBattleActionsType>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t add_OnInputActionsBindsChanged = 0x3769920; // "private static void add_OnInputActionsBindsChanged(Action value)"
            inline constexpr std::uintptr_t remove_OnInputActionsBindsChanged = 0x3769A10; // "private static void remove_OnInputActionsBindsChanged(Action value)"
            inline constexpr std::uintptr_t SetupInputActions = 0x3769150; // "public static void SetupInputActions(InputActions inputActions)"
            inline constexpr std::uintptr_t GetInputActionByType = 0x37690C0; // "public static InputAction GetInputActionByType(InputActionsContainer.InputBattleActionsType actionType)"
            inline constexpr std::uintptr_t IsValidActionType = 0x3769140; // "public static bool IsValidActionType(InputActionsContainer.InputBattleActionsType actionType)"
            inline constexpr std::uintptr_t SubscribeBindingChangeEvent = 0x3769610; // "public static void SubscribeBindingChangeEvent(Action action)"
            inline constexpr std::uintptr_t UnsubscribeBindingChangeEvent = 0x3769730; // "public static void UnsubscribeBindingChangeEvent(Action action)"
            inline constexpr std::uintptr_t BindsChanged = 0x3769050; // "public static void BindsChanged()"
        }
    } // namespace InputActionsContainer

    namespace InputDeviceResolver { // "Game.Device.InputDeviceResolver (Game.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t deviceModel = 0x10; // "DeviceModel"
            inline constexpr std::uintptr_t inputActions = 0x18; // "InputActions"
            inline constexpr std::uintptr_t inputUser = 0x20; // "InputUser"
        }
        namespace Methods {
            inline constexpr std::uintptr_t HasDevice = 0x1098CA0; // "public bool HasDevice()"
            inline constexpr std::uintptr_t CheckCorrectDevices = 0x10987E0; // "private bool CheckCorrectDevices(DeviceId deviceId, out InputDevice[] devices)"
            inline constexpr std::uintptr_t GetNeedDevices = 0x10989E0; // "private InputDevice[] GetNeedDevices(DeviceId deviceId)"
            inline constexpr std::uintptr_t SetDevices = 0x10990C0; // "private void SetDevices(DeviceId deviceId, InputDevice[] devices)"
            inline constexpr std::uintptr_t OnDeviceChange = 0x1098F80; // "private void OnDeviceChange(InputDevice inputDevice, InputDeviceChange inputDeviceChange)"
            inline constexpr std::uintptr_t Clear = 0x1098910; // "public void Clear()"
        }
    } // namespace InputDeviceResolver

    namespace InputEnabledModel { // "Game.Global.Inputs.InputEnabledModel (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t actionMap = 0x10; // "InputActionMap"
            inline constexpr std::uintptr_t disableCounter = 0x18; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Enable = 0x35B1890; // "public void Enable()"
            inline constexpr std::uintptr_t Disable = 0x35B1820; // "public void Disable()"
            inline constexpr std::uintptr_t UpdateEnabled = 0x35B1900; // "private void UpdateEnabled()"
        }
    } // namespace InputEnabledModel

    namespace InputFieldAdditiveSettingUpdater { // "Game.Global.SettingsDialog.Updaters.InputFieldAdditiveSettingUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t inputField = 0x20; // "InputFieldView"
            inline constexpr std::uintptr_t inputFieldUpdater = 0x28; // "IUpdater"
            inline constexpr std::uintptr_t isInteractableFunc = 0x30; // "Func<bool>"
            inline constexpr std::uintptr_t isInteractable = 0x38; // "Nullable<bool>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0x3750700; // "public InputFieldAdditiveSettingUpdater Init(InputFieldView inputField, IChangeBufferValue<string> setting, UpdaterPool updaterPool, Func<bool> isInteractableFunc, IRegisterDisposable disposable)"
            inline constexpr std::uintptr_t Dispose = 0x37506B0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0x3750840; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace InputFieldAdditiveSettingUpdater

    namespace InputFieldSettingUpdater { // "Game.Global.SettingsDialog.Updaters.InputFieldSettingUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t setting = 0x20; // "IChangeBufferValue<string>"
            inline constexpr std::uintptr_t inputField = 0x28; // "InputFieldView"
            inline constexpr std::uintptr_t value = 0x30; // "string"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0x3750930; // "public InputFieldSettingUpdater Init(InputFieldView inputField, IChangeBufferValue<string> setting)"
            inline constexpr std::uintptr_t Dispose = 0x92B5C0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0x37509E0; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace InputFieldSettingUpdater

    namespace InputHandlersManager { // "Inputs.InputHandlersManager (Inputs.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t handlers = 0x10; // "LinkedList<IInputHandler>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Add = 0x37F1CA0; // "public void Add(IInputHandler handler)"
            inline constexpr std::uintptr_t Remove = 0x37F2080; // "public void Remove(IInputHandler handler)"
            inline constexpr std::uintptr_t HasHandlerAbove = 0x37F1EA0; // "public bool HasHandlerAbove(InputHandlerPriority priority)"
            inline constexpr std::uintptr_t IsMaskBlockedAbove = 0x37F1F50; // "public bool IsMaskBlockedAbove(InputMask mask, InputHandlerPriority priority)"
        }
    } // namespace InputHandlersManager

    namespace InputHandlersUpdater { // "Inputs.InputHandlersUpdater (Inputs.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t handlers = 0x10; // "LinkedList<IInputHandler>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x37F2180; // "public void Update()"
        }
    } // namespace InputHandlersUpdater

    namespace InputHoldModel { // "Game.Battle.Inputs.InputHoldModel (Inputs.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t progress = 0x10; // "float"
            inline constexpr std::uintptr_t IsActive = 0x14; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Progress = 0x37F2380; // "public float get_Progress()"
            inline constexpr std::uintptr_t set_Progress = 0x834220; // "public void set_Progress(float value)"
            inline constexpr std::uintptr_t Reset = 0x37F2370; // "public void Reset()"
        }
    } // namespace InputHoldModel

    namespace InputIntentionModel { // "Game.Battle.Inputs.InputIntentionModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Value = 0x10; // "bool"
        }
    } // namespace InputIntentionModel

    namespace InputManager { // "Inputs.InputManager (Inputs.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t TryRegisterBindingComposite = 0x37F2390; // "public static void TryRegisterBindingComposite()"
        }
    } // namespace InputManager

    namespace InputModel { // "Game.Battle.Inputs.InputModel (Inputs.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t isTriggered = 0x10; // "bool"
            inline constexpr std::uintptr_t frameCount = 0x14; // "int"
            inline constexpr std::uintptr_t Mode = 0x18; // "InputModel.InputMode"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsTriggered = 0x37F23D0; // "public bool get_IsTriggered()"
            inline constexpr std::uintptr_t set_IsTriggered = 0x37F2440; // "public void set_IsTriggered(bool value)"
            inline constexpr std::uintptr_t get_WasTriggeredLastFrame = 0x37F2420; // "public bool get_WasTriggeredLastFrame()"
        }
    } // namespace InputModel

    namespace InputModel_2 { // "Models.Models.Input.InputModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t inputData = 0x10; // "BattleInputData"
            inline constexpr std::uintptr_t hasInput = 0x108; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetInput = 0x4934F00; // "public void SetInput(in BattleInputData inputData)"
            inline constexpr std::uintptr_t TryGetInput = 0x4935060; // "public bool TryGetInput(out BattleInputData inputData)"
            inline constexpr std::uintptr_t Clear = 0x4934EF0; // "public void Clear()"
        }
    } // namespace InputModel_2

    namespace InputsEnabledModel { // "Game.Global.Inputs.InputsEnabledModel (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Battle = 0x10; // "InputEnabledModel"
            inline constexpr std::uintptr_t CharacterControl = 0x18; // "InputEnabledModel"
            inline constexpr std::uintptr_t Models = 0x20; // "InputEnabledModel[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t EnableAll = 0x35B2790; // "public void EnableAll()"
            inline constexpr std::uintptr_t DisableAll = 0x35B26D0; // "public void DisableAll()"
        }
    } // namespace InputsEnabledModel

    namespace InputsModel { // "Models.Models.Inputs.InputsModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t inputs = 0x10; // "Dictionary<long, BattleInputData>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Add = 0x49351C0; // "public void Add(long tickIndex, long inputTickIndex, in BattleInputData inputData)"
            inline constexpr std::uintptr_t TryGetInput = 0x4935450; // "public bool TryGetInput(long tickIndex, out BattleInputData inputData)"
            inline constexpr std::uintptr_t Remove = 0x49353F0; // "public void Remove(long tickIndex)"
            inline constexpr std::uintptr_t GetEnumerator = 0x49352E0; // "public IEnumerator<BattleInputData> GetEnumerator()"
            inline constexpr std::uintptr_t System_Collections_IEnumerable_GetEnumerator = 0x49352E0; // "private IEnumerator System.Collections.IEnumerable.GetEnumerator()"
        }
    } // namespace InputsModel

    namespace InputsStatsModel { // "Game.Battle.NetStats.InputsStats.InputsStatsModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t MaxCount = 0x10; // "int"
            inline constexpr std::uintptr_t MaxValue = 0x14; // "int"
            inline constexpr std::uintptr_t nodes = 0x18; // "IDualDictionary<long, LinkedListNode<ValueTuple<int, InputState>>>"
            inline constexpr std::uintptr_t Inputs = 0x20; // "LinkedList<ValueTuple<int, InputState>>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t AddTickInput = 0x97EDA0; // "public void AddTickInput(long tickIndex, bool hasInput)"
            inline constexpr std::uintptr_t ReceivedInput = 0x97F060; // "public void ReceivedInput(long tickIndex, int bufferTime)"
            inline constexpr std::uintptr_t Clear = 0x97EFF0; // "public void Clear()"
        }
    } // namespace InputsStatsModel

    namespace InputsStatsUpdater { // "Game.Battle.NetStats.InputsStats.InputsStatsUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "InputsStatsModel"
            inline constexpr std::uintptr_t inputDataModel = 0x18; // "IBattleInputDataModel"
            inline constexpr std::uintptr_t time = 0x20; // "TimeModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x97F2D0; // "public void Update()"
        }
    } // namespace InputsStatsUpdater

    namespace InputsUpdater { // "Game.Battle.Inputs.InputsUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleEntitiesModel = 0x10; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t updater = 0x18; // "IUpdater"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA77460; // "public void Update()"
        }
    } // namespace InputsUpdater

    namespace InputValidationModel { // "Game.Global.ModalDialog.InputValidationModel (Global.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x82600B8; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace Fields {
            inline constexpr std::uintptr_t CharactersLimit = 0x10; // "int"
            inline constexpr std::uintptr_t Validator = 0x18; // "TextValidator"
            inline constexpr std::uintptr_t Advice = 0x20; // "NotificationValidationModel"
            inline constexpr std::uintptr_t Final = 0x28; // "NotificationValidationModel"
        }
        namespace StaticFields {
            inline constexpr std::uintptr_t Empty = 0x0; // "InputValidationModel"
        }
    } // namespace InputValidationModel

    namespace InputValidatorAssets { // "Game.Global.InputValidatorAssets (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t whitespacesTrimName = 0x18; // "AssetReference"
            inline constexpr std::uintptr_t whitespacesTrimTag = 0x20; // "AssetReference"
            inline constexpr std::uintptr_t whitespacesTrimEmail = 0x28; // "AssetReference"
            inline constexpr std::uintptr_t realmId = 0x30; // "AssetReference"
            inline constexpr std::uintptr_t onlyDigit = 0x38; // "AssetReference"
            inline constexpr std::uintptr_t WhitespacesTrimName = 0x40; // "InstantiateLoadedContent<WhitespacesTrimInputValidator>"
            inline constexpr std::uintptr_t WhitespacesTrimTag = 0x48; // "InstantiateLoadedContent<NoWhitespacesTrimInputValidator>"
            inline constexpr std::uintptr_t WhitespacesTrimEmail = 0x50; // "InstantiateLoadedContent<NoWhitespacesTrimInputValidator>"
            inline constexpr std::uintptr_t RealmId = 0x58; // "InstantiateLoadedContent<RealmIdInputValidator>"
            inline constexpr std::uintptr_t OnlyDigit = 0x60; // "InstantiateLoadedContent<OnlyDigitInputValidator>"
        }
    } // namespace InputValidatorAssets

    namespace InteractAreasNearPlayerModel { // "Game.Battle.Target.InteractAreasNearPlayerModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t DynamicInteractAreaTargetEntitiesRegularGrid = 0x10; // "RegularGrid"
            inline constexpr std::uintptr_t InteractAreasNearToPlayer = 0x18; // "HashSet<InteractAreasTargetObject>"
            inline constexpr std::uintptr_t TargetByGridId = 0x20; // "Dictionary<int, InteractAreasTargetObject>"
            inline constexpr std::uintptr_t RegularGridUpdaters = 0x28; // "Dictionary<InteractAreasTargetObject, IDisposableUpdater>"
            inline constexpr std::uintptr_t GeneratorGridId = 0x30; // "int"
        }
    } // namespace InteractAreasNearPlayerModel

    namespace InterruptArrestedProlongedAction { // "Game.Battle.Entities.Player.ProlongedActions.InterruptArrestedProlongedAction (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "ProlongedInteractionModel"
            inline constexpr std::uintptr_t entityId = 0x18; // "int"
            inline constexpr std::uintptr_t Label = 0x20; // "LocalizedString"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsActive = 0xB1DEB0; // "public bool get_IsActive()"
            inline constexpr std::uintptr_t get_EndTs = 0xB19D10; // "public long get_EndTs()"
            inline constexpr std::uintptr_t get_Duration = 0xB1DE60; // "public long get_Duration()"
            inline constexpr std::uintptr_t Interrupt = 0xB1DDA0; // "public void Interrupt(BattleInputModel battleInputModel)"
            inline constexpr std::uintptr_t UpdateInterruptData = 0xB19E00; // "public void UpdateInterruptData()"
        }
    } // namespace InterruptArrestedProlongedAction

    namespace InterruptBecomeRobberUpdater { // "Game.Battle.Inputs.InterruptBecomeRobberUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleModel = 0x10; // "BattleModel"
            inline constexpr std::uintptr_t globalModel = 0x18; // "GlobalModel"
            inline constexpr std::uintptr_t modalDialogModel = 0x20; // "ModalDialogModel"
            inline constexpr std::uintptr_t reset = 0x28; // "Action"
            inline constexpr std::uintptr_t partyModel = 0x30; // "PartyModel"
            inline constexpr std::uintptr_t battleInputModel = 0x38; // "BattleInputModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA799F0; // "public void Update()"
        }
    } // namespace InterruptBecomeRobberUpdater

    namespace InterruptProgressActionInputUpdater { // "Game.Battle.Player.InterruptProgressActionInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t interruptionDotMinThreshold = 0x10; // "float"
            inline constexpr std::uintptr_t playerMovementInput = 0x18; // "PlayerMovementInputModel"
            inline constexpr std::uintptr_t battleInputModel = 0x20; // "BattleInputModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x28; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t worldEntitiesModel = 0x30; // "WorldEntitiesModel"
            inline constexpr std::uintptr_t time = 0x38; // "TimeModel"
            inline constexpr std::uintptr_t prolongedActionProcessModel = 0x40; // "ProlongedActionProcessModel"
            inline constexpr std::uintptr_t isActive = 0x48; // "bool"
            inline constexpr std::uintptr_t isProlongedActionInterrupted = 0x49; // "bool"
            inline constexpr std::uintptr_t isStopped = 0x4A; // "bool"
            inline constexpr std::uintptr_t initialMoveDirection = 0x4C; // "Vector2"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x9635E0; // "public void Update()"
            inline constexpr std::uintptr_t IsActionInProgress = 0x963400; // "private bool IsActionInProgress(bool isEmotionActive)"
            inline constexpr std::uintptr_t HasProgressActionInput = 0x962CE0; // "private bool HasProgressActionInput()"
            inline constexpr std::uintptr_t IsDirectionChanged = 0x9634A0; // "private bool IsDirectionChanged()"
            inline constexpr std::uintptr_t BecomingRobberOrChangeCopEquipInsideCar = 0x962BB0; // "private bool BecomingRobberOrChangeCopEquipInsideCar()"
            inline constexpr std::uintptr_t CheckLoot = 0x962C90; // "private bool CheckLoot()"
        }
    } // namespace InterruptProgressActionInputUpdater

    namespace InventoryContainerInputHandler { // "Game.Battle.InventoryContainer.InventoryContainerInputHandler (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t inventoryDialogModel = 0x10; // "InventoryDialogModel"
            inline constexpr std::uintptr_t Handlers = 0x18; // "ValueTuple<InputMask, IUpdater>[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t CloseDialog = 0x952750; // "private void CloseDialog()"
            inline constexpr std::uintptr_t get_Priority = 0x7E5DA0; // "public InputHandlerPriority get_Priority()"
        }
    } // namespace InventoryContainerInputHandler

    namespace InventoryItemInputDescription { // "Models.References.Input.InventoryItemInputDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x8273C10; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t enum_id = 0x0; // "Enum<InventoryItemInputDescription>"
            inline constexpr std::uintptr_t StartUse = 0x8; // "InventoryItemInputDescription"
            inline constexpr std::uintptr_t StopUse = 0x10; // "InventoryItemInputDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Enum = 0x44182A0; // "public static ReadOnlyEnum<InventoryItemInputDescription> get_Enum()"
        }
    } // namespace InventoryItemInputDescription

    namespace InventoryUseItemInputInfo { // "Models.Models.InventoryUseItem.InventoryUseItemInputInfo (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ItemActionType = 0x10; // "ItemActionTypeDescription"
            inline constexpr std::uintptr_t SourceInventorySlot = 0x18; // "InventorySlotDescription"
            inline constexpr std::uintptr_t SourcePocketSlot = 0x20; // "PocketSlotDescription"
            inline constexpr std::uintptr_t TargetInventorySlot = 0x28; // "InventorySlotDescription"
            inline constexpr std::uintptr_t TargetEquipSlot = 0x30; // "EquipSlotDescription"
        }
    } // namespace InventoryUseItemInputInfo

    namespace JumpInputUpdater { // "Game.Battle.Inputs.JumpInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t jumpInputModel = 0x10; // "InputModel"
            inline constexpr std::uintptr_t battleInputModel = 0x18; // "BattleInputModel"
            inline constexpr std::uintptr_t unavailableKeys = 0x20; // "UnavailableTargetActionsKeys"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x28; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t personalNotificationModel = 0x30; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t timeModel = 0x38; // "TimeModel"
            inline constexpr std::uintptr_t jumpBufferTs = 0x40; // "Nullable<long>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA7CE10; // "public void Update()"
        }
    } // namespace JumpInputUpdater

    namespace KeyboardActionInputUpdater { // "Game.Battle.Inputs.Keyboard.KeyboardActionInputUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t inputModel = 0x10; // "InputModel"
            inline constexpr std::uintptr_t action = 0x18; // "InputAction"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x3559A40; // "public void Update()"
        }
    } // namespace KeyboardActionInputUpdater

    namespace KeyboardInputControlBinderUpdater { // "Game.Global.SettingsDialog.KeyboardInputControlBinderUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t cacheHumanReadableBindingName = 0x20; // "Dictionary<string, string>"
            inline constexpr std::uintptr_t updaters = 0x28; // "List<IUpdater>"
            inline constexpr std::uintptr_t emptyActions = 0x30; // "HashSet<ControlActionBinderView>"
            inline constexpr std::uintptr_t inputActionBinders = 0x38; // "List<InputActionBinderData>"
            inline constexpr std::uintptr_t inputActionBindingPairs = 0x40; // "List<InputActionBindingPair>"
            inline constexpr std::uintptr_t relatedActions = 0x48; // "Dictionary<ValueTuple<InputAction, int>, ValueTuple<InputAction, int>>"
            inline constexpr std::uintptr_t controlBinderPanelView = 0x50; // "ControlBinderPanelView"
            inline constexpr std::uintptr_t modalDialogModel = 0x58; // "ModalDialogModel"
            inline constexpr std::uintptr_t gameSetting = 0x60; // "GameSetting"
            inline constexpr std::uintptr_t globalLocalizationKeys = 0x68; // "GlobalLocalizationKeys"
            inline constexpr std::uintptr_t disposable = 0x70; // "IRegisterDisposable"
            inline constexpr std::uintptr_t updaterPool = 0x78; // "UpdaterPool"
            inline constexpr std::uintptr_t inputActionBinder = 0x80; // "InputActionBinder"
            inline constexpr std::uintptr_t cancelRebindControl = 0x88; // "InputControl"
            inline constexpr std::uintptr_t cancelRebindDescription = 0x90; // "Text<string>"
            inline constexpr std::uintptr_t battleActions = 0x98; // "InputActions.BattleActions"
            inline constexpr std::uintptr_t characterControlActions = 0xA0; // "InputActions.CharacterControlActions"
            inline constexpr std::uintptr_t matchingActionFoundDialogDescription = 0xA8; // "Text<string>"
            inline constexpr std::uintptr_t isBindingNow = 0xB0; // "bool"
            inline constexpr std::uintptr_t dirtyChangeTs = 0xB4; // "float"
            inline constexpr std::uintptr_t bindingParams = 0xB8; // "InputActionBinderData"
            inline constexpr std::uintptr_t openedDialogData = 0xD8; // "ModalDialogData"
            inline constexpr std::uintptr_t bindingOldOverrideValue = 0xE0; // "string"
            inline constexpr std::uintptr_t needChangeParams = 0xE8; // "List<InputActionBinderData>"
            inline constexpr std::uintptr_t updateAllInputTextValue = 0xF0; // "Action"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0x3743B80; // "public KeyboardInputControlBinderUpdater Init(ControlBinderPanelView controlBinderPanelView, ModalDialogModel modalDialogModel, InputsEnabledModel inputsEnabledModel, InputActions inputActions, GameSetting gameSetting, GlobalLocalizationKeys globalLocalizationKeys, GlobalUISoundModel soundModel, UpdaterPool updaterPool, IRegisterDisposable disposable)"
            inline constexpr std::uintptr_t AddVoiceChatBinding = 0x3736E70; // "public void AddVoiceChatBinding(ControlActionBinderView voiceChatBinding, IChangeBufferValue<VoiceChatMode> voiceChatMode)"
            inline constexpr std::uintptr_t Dispose = 0x3737E20; // "protected override void Dispose()"
            inline constexpr std::uintptr_t CancelOpenedDialog = 0x37376D0; // "private void CancelOpenedDialog()"
            inline constexpr std::uintptr_t UpdateAllInputTextValue = 0x3744DB0; // "private void UpdateAllInputTextValue()"
            inline constexpr std::uintptr_t CheckWarningActions = 0x3737780; // "private void CheckWarningActions()"
            inline constexpr std::uintptr_t UpdateInputText = 0x3744F10; // "private void UpdateInputText(ControlActionBinderButton view, InputAction valueAction, int valueBinderIndex, bool isHold)"
            inline constexpr std::uintptr_t GetHumanReadableBindingName = 0x37387E0; // "private string GetHumanReadableBindingName(bool isEmptyAction, InputBinding binder)"
            inline constexpr std::uintptr_t OnUpdate = 0x3744660; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t OnCompleteRebindingAction = 0x37440D0; // "private void OnCompleteRebindingAction(bool complete)"
            inline constexpr std::uintptr_t FindRelativeActions = 0x37385D0; // "private void FindRelativeActions(InputAction bindingParamsAction, int bindingParamsBinderIndex)"
            inline constexpr std::uintptr_t FindMatchingKeyBindings = 0x3738130; // "private bool FindMatchingKeyBindings(InputAction valueAction, int valueBinderIndex)"
            inline constexpr std::uintptr_t ConfirmDialogAction = 0x3737A60; // "private void ConfirmDialogAction()"
            inline constexpr std::uintptr_t CancelDialogAction = 0x3737480; // "private void CancelDialogAction()"
            inline constexpr std::uintptr_t InitInputActionBindingPairs = 0x373FB40; // "private void InitInputActionBindingPairs()"
            inline constexpr std::uintptr_t InitInputActionBinders = 0x37389A0; // "private void InitInputActionBinders()"
            inline constexpr std::uintptr_t InitRelatedActions = 0x37437B0; // "private void InitRelatedActions()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace KeyboardInputControlBinderUpdater

    namespace KeyboardInputModeUpdater { // "Game.Battle.Inputs.KeyboardInputModeUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t controlsSettingsModel = 0x10; // "KeyboardMouseControlsSettingsModel"
            inline constexpr std::uintptr_t crouch = 0x18; // "InputModel"
            inline constexpr std::uintptr_t aim = 0x20; // "InputModel"
            inline constexpr std::uintptr_t sprint = 0x28; // "InputModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA7D720; // "public void Update()"
        }
    } // namespace KeyboardInputModeUpdater

    namespace KeyboardInputUpdater { // "Game.Battle.Map.KeyboardInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t mapDialogModel = 0x10; // "MapDialogModel"
            inline constexpr std::uintptr_t uiSoundModel = 0x18; // "BattleUISoundModel"
            inline constexpr std::uintptr_t centerOffset = 0x20; // "Vector2"
            inline constexpr std::uintptr_t contextActionRules = 0x28; // "GeneralContextActionRules"
            inline constexpr std::uintptr_t realmBattleStateModel = 0x30; // "RealmBattleStateModel"
            inline constexpr std::uintptr_t realmInfoModel = 0x38; // "RealmInfoModel"
            inline constexpr std::uintptr_t globalUISoundModel = 0x40; // "GlobalUISoundModel"
            inline constexpr std::uintptr_t Handlers = 0x48; // "ValueTuple<InputMask, IUpdater>[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t ReportSettlementName = 0x9B19D0; // "private void ReportSettlementName()"
            inline constexpr std::uintptr_t OnClickObjectivesPanelToggleVisibility = 0x9B1960; // "private void OnClickObjectivesPanelToggleVisibility()"
            inline constexpr std::uintptr_t BackMap = 0x9B18F0; // "private void BackMap()"
            inline constexpr std::uintptr_t CloseMap = 0x952750; // "private void CloseMap()"
            inline constexpr std::uintptr_t CloseMapObjectInfoPanel = 0x9B1930; // "private void CloseMapObjectInfoPanel()"
            inline constexpr std::uintptr_t get_Priority = 0x7E5DA0; // "public InputHandlerPriority get_Priority()"
        }
    } // namespace KeyboardInputUpdater

    namespace KeyboardMoneyLaunderingInputHandler { // "Game.Battle.Entities.Plot.Dialog.Input.KeyboardMoneyLaunderingInputHandler (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t updaters = 0x20; // "List<IUpdater>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xAEA780; // "public KeyboardMoneyLaunderingInputHandler Init(int modelEntityId, CoinsAccessModel coinsAccessModel, MoneyLaunderingDialogModel model, BattleModel battleModel, GlobalModel globalModel, GlobalScreenContent globalScreenContent, IRoomConnection battleConnection, MoneyLaunderingDialogView view, ClientMoneyWorkbenchModel clientMoneyWorkbenchModel, IMoneyWorkbenchModel moneyWorkbenchModel, BattleScreenContent content, UpdaterPool updaterPool, IRegisterDisposable registerDisposable)"
            inline constexpr std::uintptr_t Dispose = 0xAEA720; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0x94CF50; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace KeyboardMoneyLaunderingInputHandler

    namespace KeyboardMousePlayerContextMenuInputHandler { // "Game.Battle.PlayerContextMenu.InputHandlers.KeyboardMousePlayerContextMenuInputHandler (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Handlers = 0x10; // "ValueTuple<InputMask, IUpdater>[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Priority = 0x7E5D90; // "public InputHandlerPriority get_Priority()"
        }
    } // namespace KeyboardMousePlayerContextMenuInputHandler

    namespace KeyboardQuickSlotsInputUpdater { // "Game.Battle.Inputs.KeyboardQuickSlotsInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t quickSlotsInputModel = 0x10; // "QuickSlotsInputModel"
            inline constexpr std::uintptr_t unavailableKeys = 0x18; // "UnavailableTargetActionsKeys"
            inline constexpr std::uintptr_t battleInputModel = 0x20; // "BattleInputModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x28; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t personalNotificationModel = 0x30; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t triggeredSlot = 0x38; // "QuickSlotDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA7E470; // "public void Update()"
            inline constexpr std::uintptr_t UpdateToggleSelectedSlotInput = 0xA7E240; // "private void UpdateToggleSelectedSlotInput()"
            inline constexpr std::uintptr_t UpdateSelectSlotInput = 0xA7E0F0; // "private void UpdateSelectSlotInput()"
            inline constexpr std::uintptr_t LockQuickSlotsInHoldingCell = 0xA7DFB0; // "private bool LockQuickSlotsInHoldingCell(BattleCharacterModel model)"
            inline constexpr std::uintptr_t GetTriggeredSlot = 0xA7DD40; // "private QuickSlotDescription GetTriggeredSlot()"
            inline constexpr std::uintptr_t FindSuitableSlot = 0xA7D880; // "private QuickSlotDescription FindSuitableSlot(QuickSlotsModel quickSlots)"
            inline constexpr std::uintptr_t ClearInput = 0xA7D790; // "private void ClearInput()"
        }
    } // namespace KeyboardQuickSlotsInputUpdater

    namespace KeyboardShooterLookInputUpdater { // "Game.Battle.Inputs.Updaters.Keyboard.KeyboardShooterLookInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t pitchThreshold = 0x10; // "float"
            inline constexpr std::uintptr_t playerRotationInput = 0x18; // "PlayerRotationInputModel"
            inline constexpr std::uintptr_t sensitivityModel = 0x20; // "SensitivityModel"
            inline constexpr std::uintptr_t actions = 0x28; // "InputActions.BattleActions"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA95190; // "public void Update()"
        }
    } // namespace KeyboardShooterLookInputUpdater

    namespace KinematicObjectMovementDescription { // "Models.References.KinematicObject.KinematicObjectMovementDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Position1 = 0x10; // "Vector3"
            inline constexpr std::uintptr_t Orientation1 = 0x1C; // "Quaternion"
            inline constexpr std::uintptr_t Position2 = 0x2C; // "Vector3"
            inline constexpr std::uintptr_t Orientation2 = 0x38; // "Quaternion"
        }
    } // namespace KinematicObjectMovementDescription

    namespace KinematicObjectMovementStateDescription { // "Models.References.KinematicObject.KinematicObjectMovementStateDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x8187C30; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t enum_id = 0x0; // "Enum<KinematicObjectMovementStateDescription>"
            inline constexpr std::uintptr_t Point1 = 0x8; // "KinematicObjectMovementStateDescription"
            inline constexpr std::uintptr_t Point2 = 0x10; // "KinematicObjectMovementStateDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Enum = 0x43EA8A0; // "public static ReadOnlyEnum<KinematicObjectMovementStateDescription> get_Enum()"
        }
    } // namespace KinematicObjectMovementStateDescription

    namespace LandOwnershipInputHandler { // "Game.Global.LandOwnership.LandOwnershipInputHandler (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dialogModel = 0x10; // "LandOwnershipDialogModel"
            inline constexpr std::uintptr_t Handlers = 0x18; // "ValueTuple<InputMask, IUpdater>[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t CloseDialog = 0x952750; // "private void CloseDialog()"
            inline constexpr std::uintptr_t get_Priority = 0x7E5DA0; // "public InputHandlerPriority get_Priority()"
        }
    } // namespace LandOwnershipInputHandler

    namespace LaptopInputHandler { // "Game.Battle.Laptop.LaptopInputHandler (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dialogModel = 0x10; // "LaptopDialogModel"
            inline constexpr std::uintptr_t Handlers = 0x18; // "ValueTuple<InputMask, IUpdater>[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t CloseDialog = 0x952750; // "private void CloseDialog()"
            inline constexpr std::uintptr_t get_Priority = 0x7E3AB0; // "public InputHandlerPriority get_Priority()"
        }
    } // namespace LaptopInputHandler

    namespace LaptopInventoryInputUpdater { // "Game.Battle.Laptop.LaptopInventoryInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t clickableItemsUpdater = 0x10; // "IUpdater"
            inline constexpr std::uintptr_t hoverableItemsUpdater = 0x18; // "IUpdater"
            inline constexpr std::uintptr_t inventoryUIInputHandler = 0x20; // "InventoryUIInputHandler"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x9E9B40; // "public void Update()"
        }
    } // namespace LaptopInventoryInputUpdater

    namespace LerpPositionModel { // "Game.Global.Character.LerpPositionModel (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t pos = 0x10; // "Vector3"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_X = 0x8341C0; // "public float get_X()"
            inline constexpr std::uintptr_t get_Y = 0x8341D0; // "public float get_Y()"
            inline constexpr std::uintptr_t get_Z = 0x8341E0; // "public float get_Z()"
            inline constexpr std::uintptr_t SetPositionLerp = 0x36D3A20; // "public void SetPositionLerp(Vector3 newPos)"
            inline constexpr std::uintptr_t SetPosition = 0x97EA20; // "public void SetPosition(Vector3 pos)"
        }
    } // namespace LerpPositionModel

    namespace LimitCameraAngleUpdater { // "Game.Battle.Entities.Player.Rotation.Updaters.LimitCameraAngleUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t rotationInputModel = 0x10; // "PlayerRotationInputModel"
            inline constexpr std::uintptr_t playerInVehicleModel = 0x18; // "InVehicleModel"
            inline constexpr std::uintptr_t helicopterViewDescriptions = 0x20; // "HelicopterViewDescriptions"
            inline constexpr std::uintptr_t carViewDescriptions = 0x28; // "CarViewDescriptions"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x30; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t cameraFollow = 0x38; // "Cinemachine3rdPersonFollow"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB1F150; // "public void Update()"
            inline constexpr std::uintptr_t GetThresholds = 0xB1EEA0; // "private void GetThresholds(out float topThreshold, out float bottomThreshold, out float dampTime)"
        }
    } // namespace LimitCameraAngleUpdater

    namespace LocalFileStorage { // "Game.Global.PlayerPrefsFile.LocalFileStorage (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t path = 0x10; // "string"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Exist = 0xF258D0; // "public bool Exist()"
            inline constexpr std::uintptr_t Read = 0x379A100; // "public Task<IEither<Exception, byte[]>> Read()"
            inline constexpr std::uintptr_t Write = 0x379A1F0; // "public Task<Maybe<Exception>> Write(byte[] value)"
            inline constexpr std::uintptr_t Delete = 0x379A060; // "public Maybe<Exception> Delete()"
        }
    } // namespace LocalFileStorage

    namespace LookDirectionInputModel { // "Models.Models.LookDirectionInput.LookDirectionInputModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t x = 0x10; // "float"
            inline constexpr std::uintptr_t y = 0x14; // "float"
            inline constexpr std::uintptr_t contains = 0x18; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_X = 0x8341C0; // "public float get_X()"
            inline constexpr std::uintptr_t get_Y = 0x8341D0; // "public float get_Y()"
            inline constexpr std::uintptr_t get_Contains = 0xA25F30; // "public bool get_Contains()"
            inline constexpr std::uintptr_t Set = 0x48CD280; // "public void Set(float x, float y)"
            inline constexpr std::uintptr_t Clear = 0x48CD270; // "public void Clear()"
        }
    } // namespace LookDirectionInputModel

    namespace LookInputUpdater { // "Game.Battle.Inputs.Updaters.LookInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t playerRotationInput = 0x10; // "PlayerRotationInputModel"
            inline constexpr std::uintptr_t battleInputModel = 0x18; // "BattleInputModel"
            inline constexpr std::uintptr_t shotIntentionModel = 0x20; // "ShotIntentionModel"
            inline constexpr std::uintptr_t lookDirection = 0x28; // "Vector2"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA95B30; // "public void Update()"
        }
    } // namespace LookInputUpdater

    namespace LookRotationInterpolationUpdater { // "Game.Battle.EntityModel.BattleCharacter.Rotation.LookRotationInterpolationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dataTickModel = 0x10; // "IDataTickModel"
            inline constexpr std::uintptr_t lookDirection = 0x18; // "LookDirectionModel"
            inline constexpr std::uintptr_t rotation = 0x20; // "CharacterRotationModel"
            inline constexpr std::uintptr_t lookRotationTimeline = 0x28; // "RotationTimeline"
            inline constexpr std::uintptr_t timeModel = 0x30; // "TimeModel"
            inline constexpr std::uintptr_t now = 0x38; // "INow"
            inline constexpr std::uintptr_t tickIndex = 0x40; // "long"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xCD4C00; // "public void Update()"
        }
    } // namespace LookRotationInterpolationUpdater

    namespace MailInputHandler { // "Game.Global.Mail.Updaters.MailInputHandler (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t globalModel = 0x10; // "GlobalModel"
            inline constexpr std::uintptr_t model = 0x18; // "MailDialogModel"
            inline constexpr std::uintptr_t mailboxModel = 0x20; // "MailboxModel"
            inline constexpr std::uintptr_t globalScreenContent = 0x28; // "GlobalScreenContent"
            inline constexpr std::uintptr_t roomConnection = 0x30; // "IRoomConnection"
            inline constexpr std::uintptr_t claimAttachmentsStrategy = 0x38; // "IMailClaimAttachmentsStrategy"
            inline constexpr std::uintptr_t ownedSkins = 0x40; // "MailAttachmentOwnedSkins"
            inline constexpr std::uintptr_t coinsAccessModel = 0x48; // "CoinsAccessModel"
            inline constexpr std::uintptr_t actions = 0x50; // "InputActions.BattleActions"
            inline constexpr std::uintptr_t isInProgress = 0x58; // "bool"
            inline constexpr std::uintptr_t Handlers = 0x60; // "ValueTuple<InputMask, IUpdater>[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t OnExitButtonClicked = 0xD445A0; // "private void OnExitButtonClicked()"
            inline constexpr std::uintptr_t OnMailClicked = 0x35A1810; // "private void OnMailClicked(int mailId)"
            inline constexpr std::uintptr_t OnClaimButtonClicked = 0x35A1560; // "private void OnClaimButtonClicked()"
            inline constexpr std::uintptr_t ClaimMail = 0x35A1440; // "private Task<MailInputHandler.ClaimIssues> ClaimMail(MailModel mail)"
            inline constexpr std::uintptr_t ShowClaimIssuesNotifications = 0x35A1D40; // "private void ShowClaimIssuesNotifications(MailInputHandler.ClaimIssues issues)"
            inline constexpr std::uintptr_t OnRemoveButtonClicked = 0x35A1860; // "private void OnRemoveButtonClicked()"
            inline constexpr std::uintptr_t OnDeleteReadMailButtonClicked = 0x35A1610; // "private void OnDeleteReadMailButtonClicked()"
            inline constexpr std::uintptr_t RemoveMails = 0x35A1C70; // "private void RemoveMails(List<int> mailIds)"
            inline constexpr std::uintptr_t get_Priority = 0x7E5DA0; // "public InputHandlerPriority get_Priority()"
        }
    } // namespace MailInputHandler

    namespace MapCollectionInputUpdater { // "Game.Battle.Map.MapCollectionInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t mapObjectivesModel = 0x10; // "MapObjectivesModel"
            inline constexpr std::uintptr_t uiSoundModel = 0x18; // "BattleUISoundModel"
            inline constexpr std::uintptr_t slot = 0x20; // "CollectionTableSlotDescription"
            inline constexpr std::uintptr_t updater = 0x28; // "IUpdater"
        }
        namespace Methods {
            inline constexpr std::uintptr_t OnClickQuestCategoryVisible = 0x9B52A0; // "private void OnClickQuestCategoryVisible()"
            inline constexpr std::uintptr_t Update = 0x9B5360; // "public void Update()"
        }
    } // namespace MapCollectionInputUpdater

    namespace MapObjectivesPlayerPrefsUpdater { // "Game.Battle.Map.MapObjectivesPlayerPrefsUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t objectivesModel = 0x10; // "MapObjectivesModel"
            inline constexpr std::uintptr_t playerPrefsModel = 0x18; // "PlayerPrefsModel"
            inline constexpr std::uintptr_t wasObjectivesPanelVisible = 0x20; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x9BEFD0; // "public void Update()"
        }
    } // namespace MapObjectivesPlayerPrefsUpdater

    namespace MapTransformModel { // "Game.Battle.Entities.Player.Models.MapTransformModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t X = 0x10; // "float"
            inline constexpr std::uintptr_t Z = 0x14; // "float"
            inline constexpr std::uintptr_t Yaw = 0x18; // "float"
            inline constexpr std::uintptr_t Pitch = 0x1C; // "float"
            inline constexpr std::uintptr_t Roll = 0x20; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Y = 0xABFFA0; // "public float get_Y()"
            inline constexpr std::uintptr_t Set = 0xB1F300; // "public void Set(float positionX, float positionZ)"
            inline constexpr std::uintptr_t SetRotate = 0x834240; // "public void SetRotate(float deltaAngle)"
        }
    } // namespace MapTransformModel

    namespace MobileConnectionInputActionUpdater { // "Game.MobileConnectionDialog.MobileConnectionInputActionUpdater (Game.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "MobileConnectionDialogModel"
            inline constexpr std::uintptr_t Handlers = 0x18; // "ValueTuple<InputMask, IUpdater>[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t OnOkButtonClicked = 0x10B0FB0; // "private void OnOkButtonClicked()"
            inline constexpr std::uintptr_t OnCancelButtonClicked = 0x10B0F40; // "private void OnCancelButtonClicked()"
            inline constexpr std::uintptr_t get_Priority = 0x10B1310; // "public InputHandlerPriority get_Priority()"
        }
    } // namespace MobileConnectionInputActionUpdater

    namespace ModalInputFieldModel { // "Game.Global.ModalDialog.ModalInputFieldModel (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Validation = 0x10; // "InputValidationModel"
            inline constexpr std::uintptr_t Value = 0x18; // "ValueModel"
            inline constexpr std::uintptr_t Placeholder = 0x20; // "IText"
        }
        namespace Methods {
            inline constexpr std::uintptr_t WrapSubmitWithFinalValidation = 0x358A480; // "public Action WrapSubmitWithFinalValidation(Action submitInput)"
        }
    } // namespace ModalInputFieldModel

    namespace ModalInputFieldUpdater { // "Game.Global.ModalDialog.ModalInputFieldUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t view = 0x20; // "InputFieldWithErrorView"
            inline constexpr std::uintptr_t model = 0x28; // "ModalInputFieldModel"
            inline constexpr std::uintptr_t setValidator = 0x30; // "bool"
            inline constexpr std::uintptr_t prevStr = 0x38; // "string"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsFocused = 0x358AC40; // "private bool get_IsFocused()"
            inline constexpr std::uintptr_t Init = 0x358A6A0; // "public ModalInputFieldUpdater Init(ModalInputFieldModel model, InputFieldWithErrorView view)"
            inline constexpr std::uintptr_t Dispose = 0xDA1560; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0x358A850; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t RefreshValue = 0x358A8A0; // "private void RefreshValue()"
            inline constexpr std::uintptr_t Validate = 0x358AA50; // "private void Validate()"
            inline constexpr std::uintptr_t GetState = 0x358A5A0; // "private InputFieldWithErrorView.InputFieldState GetState()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace ModalInputFieldUpdater

    namespace MoneyLaunderingConversionInputUpdater { // "Game.Battle.Entities.Plot.Dialog.Input.MoneyLaunderingConversionInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t globalLocalizationKeys = 0x10; // "GlobalLocalizationKeys"
            inline constexpr std::uintptr_t personalNotificationModel = 0x18; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t uiSoundModel = 0x20; // "GlobalUISoundModel"
            inline constexpr std::uintptr_t modelEntityId = 0x28; // "int"
            inline constexpr std::uintptr_t coinsAccessModel = 0x30; // "CoinsAccessModel"
            inline constexpr std::uintptr_t clientMoneyWorkbenchModel = 0x38; // "ClientMoneyWorkbenchModel"
            inline constexpr std::uintptr_t view = 0x40; // "MoneyLaunderingConversionView"
            inline constexpr std::uintptr_t moneyWorkbenchModel = 0x48; // "IMoneyWorkbenchModel"
            inline constexpr std::uintptr_t battleConnection = 0x50; // "IRoomConnection"
            inline constexpr std::uintptr_t update = 0x58; // "IUpdater[]"
            inline constexpr std::uintptr_t isRequested = 0x60; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xAEB900; // "public void Update()"
            inline constexpr std::uintptr_t OnClickBtnHandler = 0xAEB740; // "private void OnClickBtnHandler(bool active)"
            inline constexpr std::uintptr_t TrySetLaunderingActive = 0xAEB820; // "private void TrySetLaunderingActive(bool active)"
        }
    } // namespace MoneyLaunderingConversionInputUpdater

    namespace MoneyLaunderingDepositInputUpdater { // "Game.Battle.Entities.Plot.Dialog.Input.MoneyLaunderingDepositInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t view = 0x10; // "MoneyLaunderingDepositView"
            inline constexpr std::uintptr_t clientMoneyWorkbenchModel = 0x18; // "ClientMoneyWorkbenchModel"
            inline constexpr std::uintptr_t modelEntityId = 0x20; // "int"
            inline constexpr std::uintptr_t battleConnection = 0x28; // "IRoomConnection"
            inline constexpr std::uintptr_t globalUiSoundModel = 0x30; // "GlobalUISoundModel"
            inline constexpr std::uintptr_t personalNotificationModel = 0x38; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t globalLocalizationKeys = 0x40; // "GlobalLocalizationKeys"
            inline constexpr std::uintptr_t update = 0x48; // "IUpdater[]"
            inline constexpr std::uintptr_t isRequested = 0x50; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xAEC0F0; // "public void Update()"
            inline constexpr std::uintptr_t OnChangeValueButtonClickHandler = 0xAEBF40; // "private void OnChangeValueButtonClickHandler(int delta)"
            inline constexpr std::uintptr_t OnTakeButtonClickHandler = 0xAEBF80; // "private void OnTakeButtonClickHandler()"
            inline constexpr std::uintptr_t ChangeValue = 0xAEBDA0; // "private void ChangeValue(int delta)"
            inline constexpr std::uintptr_t TakeDirtyCash = 0xAEC040; // "private void TakeDirtyCash()"
        }
    } // namespace MoneyLaunderingDepositInputUpdater

    namespace MoneyLaunderingInputHandler { // "Game.Battle.Entities.Plot.Dialog.Input.MoneyLaunderingInputHandler (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t updaters = 0x20; // "List<IUpdater>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xB0AB10; // "public MoneyLaunderingInputHandler Init(int modelEntityId, CoinsAccessModel coinsAccessModel, BattleModel battleModel, GlobalModel globalModel, GlobalScreenContent globalScreenContent, IRoomConnection battleConnection, MoneyLaunderingDialogView view, ClientMoneyWorkbenchModel clientMoneyWorkbenchModel, IMoneyWorkbenchModel moneyWorkbenchModel, BattleScreenContent content, UpdaterPool updaterPool, IRegisterDisposable registerDisposable)"
            inline constexpr std::uintptr_t Dispose = 0xB0AAB0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0x94CF50; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace MoneyLaunderingInputHandler

    namespace MovementData { // "Game.Battle.EntityModel.BattleCharacter.Movement.MovementData (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t X = 0x0; // "float"
            inline constexpr std::uintptr_t Y = 0x4; // "float"
            inline constexpr std::uintptr_t Z = 0x8; // "float"
            inline constexpr std::uintptr_t Vx = 0xC; // "float"
            inline constexpr std::uintptr_t Vz = 0x10; // "float"
            inline constexpr std::uintptr_t Dt = 0x18; // "long"
            inline constexpr std::uintptr_t Ts = 0x20; // "long"
        }
        namespace Methods {
            inline constexpr std::uintptr_t GetDt = 0xCC3ED0; // "private static float GetDt(long start, long end, long ts)"
            inline constexpr std::uintptr_t Lerp = 0xCD4F30; // "public static MovementData Lerp(MovementData from, MovementData to, long ts)"
            inline constexpr std::uintptr_t LerpInto = 0xCD4E80; // "public static MovementData LerpInto(MovementData to, long ts)"
            inline constexpr std::uintptr_t ToVector3 = 0xCD5290; // "public Vector3 ToVector3()"
        }
    } // namespace MovementData

    namespace MovementInterpolationUpdater { // "Game.Battle.EntityModel.BattleCharacter.Movement.MovementInterpolationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dataTickModel = 0x20; // "IDataTickModel"
            inline constexpr std::uintptr_t transformModel = 0x28; // "ITransformModel"
            inline constexpr std::uintptr_t setMovement = 0x30; // "SetMovementModel"
            inline constexpr std::uintptr_t timeline = 0x38; // "MovementTimeline"
            inline constexpr std::uintptr_t timeModel = 0x40; // "TimeModel"
            inline constexpr std::uintptr_t tickIndex = 0x48; // "long"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xCD52F0; // "public MovementInterpolationUpdater Init(IDataTickModel dataTickModel, ITransformModel transformModel, SetMovementModel setMovement, MovementTimeline timeline, TimeModel timeModel)"
            inline constexpr std::uintptr_t Dispose = 0xA123B0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xCD5380; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace MovementInterpolationUpdater

    namespace MovementModel { // "Game.Battle.EntityModel.BattleCharacter.Movement.MovementModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t transform = 0x10; // "ITransformModel"
            inline constexpr std::uintptr_t velocity = 0x18; // "CharacterVelocityModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_X = 0xCD5660; // "public float get_X()"
            inline constexpr std::uintptr_t get_Y = 0xCD56B0; // "public float get_Y()"
            inline constexpr std::uintptr_t get_Z = 0xCD5700; // "public float get_Z()"
            inline constexpr std::uintptr_t get_Vx = 0xCD5620; // "public float get_Vx()"
            inline constexpr std::uintptr_t get_Vz = 0xCD5640; // "public float get_Vz()"
        }
    } // namespace MovementModel

    namespace MovementTimeline { // "Game.Battle.EntityModel.BattleCharacter.Movement.MovementTimeline (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t timeline = 0x10; // "TimelineList<MovementData>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Put = 0xCD5CC0; // "public void Put(Vector3 position, long dt, long ts)"
            inline constexpr std::uintptr_t Calculate = 0xCD5750; // "public MovementData Calculate(long ts, out bool isExtrapolate)"
            inline constexpr std::uintptr_t GetSuitableInterval = 0xCD5B60; // "private void GetSuitableInterval(long ts, int count, out MovementData from, out MovementData to)"
            inline constexpr std::uintptr_t SafeClear = 0xCD5DB0; // "public void SafeClear(long relevantTs, int itemsToKeepInCollection)"
            inline constexpr std::uintptr_t get_LastTs = 0xCD5F00; // "public long get_LastTs()"
        }
    } // namespace MovementTimeline

    namespace MoveShooterKeyboardInputUpdater { // "Game.Battle.Inputs.Keyboard.MoveShooterKeyboardInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t moveAction = 0x10; // "InputAction"
            inline constexpr std::uintptr_t battleInputModel = 0x18; // "BattleInputModel"
            inline constexpr std::uintptr_t playerRotationInputModel = 0x20; // "PlayerRotationInputModel"
            inline constexpr std::uintptr_t playerMovementInputModel = 0x28; // "PlayerMovementInputModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA96550; // "public void Update()"
        }
    } // namespace MoveShooterKeyboardInputUpdater

    namespace MoveShooterTouchInputUpdater { // "Game.Battle.Inputs.MoveShooterTouchInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t moveDpadView = 0x10; // "MoveDpadView"
            inline constexpr std::uintptr_t battleInputModel = 0x18; // "BattleInputModel"
            inline constexpr std::uintptr_t playerMovementInputModel = 0x20; // "PlayerMovementInputModel"
            inline constexpr std::uintptr_t playerRotationInputModel = 0x28; // "PlayerRotationInputModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA96780; // "public void Update()"
        }
    } // namespace MoveShooterTouchInputUpdater

    namespace MultiActionInputUpdater { // "Game.Battle.Target.MultiActionInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t inputModel = 0x10; // "InputModel"
            inline constexpr std::uintptr_t button = 0x18; // "PointerButtonView"
            inline constexpr std::uintptr_t targetModel = 0x20; // "TargetModel"
            inline constexpr std::uintptr_t pointerButtonViewIndex = 0x28; // "int"
            inline constexpr std::uintptr_t triggerMode = 0x2C; // "PointerTriggerMode"
            inline constexpr std::uintptr_t isTriggered = 0x30; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x9D5830; // "public void Update()"
            inline constexpr std::uintptr_t ConsumeClicked = 0x9D5800; // "private bool ConsumeClicked()"
        }
    } // namespace MultiActionInputUpdater

    namespace NeckCharacterHeadManualControlRule { // "Game.Battle.EntityModel.BattleCharacter.HeadManualControl.NeckCharacterHeadManualControlRule (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t skeletonAnimationModel = 0x10; // "SkeletonAnimationModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xCD5F80; // "public override void Update(Transform boneTransform, Quaternion constraintRotation, Quaternion lookRotation, float weight)"
        }
    } // namespace NeckCharacterHeadManualControlRule

    namespace NullifyKeyBindingsInputUpdater { // "Game.Global.SettingsDialog.NullifyKeyBindingsInputUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t bindingPairs = 0x20; // "List<InputActionBindingPair>"
            inline constexpr std::uintptr_t relatedActions = 0x28; // "Dictionary<ValueTuple<InputAction, int>, ValueTuple<InputAction, int>>"
            inline constexpr std::uintptr_t gameSetting = 0x30; // "GameSetting"
            inline constexpr std::uintptr_t soundModel = 0x38; // "GlobalUISoundModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0x9F4C50; // "public NullifyKeyBindingsInputUpdater Init(List<InputActionBindingPair> bindingPairs, Dictionary<ValueTuple<InputAction, int>, ValueTuple<InputAction, int>> relatedActions, GameSetting gameSetting, GlobalUISoundModel soundModel)"
            inline constexpr std::uintptr_t Dispose = 0x9F4BF0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0x375A440; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t ApplyRelatedBinding = 0x375A230; // "private void ApplyRelatedBinding(InputAction action, int binderIndex)"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace NullifyKeyBindingsInputUpdater

    namespace ObserverInputModel { // "Game.Battle.Observer.ObserverInputModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t MoveSpeed = 0x10; // "float"
            inline constexpr std::uintptr_t MoveAcceleration = 0x14; // "float"
            inline constexpr std::uintptr_t RotateSpeed = 0x18; // "float"
            inline constexpr std::uintptr_t RotateAcceleration = 0x1C; // "float"
            inline constexpr std::uintptr_t Fov = 0x20; // "float"
            inline constexpr std::uintptr_t FovAcceleration = 0x24; // "float"
            inline constexpr std::uintptr_t MoveDirection = 0x28; // "Vector3"
            inline constexpr std::uintptr_t WorldPosition = 0x34; // "Vector3"
            inline constexpr std::uintptr_t Orientation = 0x40; // "Vector3"
            inline constexpr std::uintptr_t MoveXZOnly = 0x4C; // "bool"
        }
    } // namespace ObserverInputModel

    namespace OccupiedCharacterSlotsModel { // "Models.Models.OccupiedCharacterSlots.OccupiedCharacterSlotsModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleCharacterSlotsModel = 0x10; // "BattleCharacterSlotsModel"
            inline constexpr std::uintptr_t slotByEntityId = 0x18; // "Dictionary<int, BattleCharacterSlotModel>"
            inline constexpr std::uintptr_t slotByPublicId = 0x20; // "Dictionary<long, BattleCharacterSlotModel>"
            inline constexpr std::uintptr_t Count = 0x28; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Occupy = 0x4914110; // "public BattleCharacterSlotModel Occupy(BattleCharacterSlotDescription slot, int entityId, long publicId)"
            inline constexpr std::uintptr_t Release = 0x4914200; // "public BattleCharacterSlotDescription Release(int entityId)"
            inline constexpr std::uintptr_t TryGetSlotByEntityId = 0x4914410; // "public bool TryGetSlotByEntityId(int entityId, out BattleCharacterSlotModel model)"
            inline constexpr std::uintptr_t TryGetSlotByPublicId = 0x4914480; // "public bool TryGetSlotByPublicId(long publicId, out BattleCharacterSlotModel model)"
            inline constexpr std::uintptr_t TryGetPublicIdByEntityId = 0x4914370; // "public bool TryGetPublicIdByEntityId(int entityId, out long publicId)"
            inline constexpr std::uintptr_t TryGetEntityIdByPublicId = 0x49142D0; // "public bool TryGetEntityIdByPublicId(long publicId, out int entityId)"
        }
    } // namespace OccupiedCharacterSlotsModel

    namespace OfferBribeInputUpdater { // "Game.Battle.Inputs.Updaters.OfferBribeInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t offerBribeInput = 0x10; // "InputModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x18; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t roomConnectionBattle = 0x20; // "IRoomConnection"
            inline constexpr std::uintptr_t personalNotificationModel = 0x28; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t bribeLocalization = 0x30; // "BribeLocalization"
            inline constexpr std::uintptr_t isSendingMessage = 0x38; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA97020; // "public void Update()"
            inline constexpr std::uintptr_t TryOfferBribe = 0xA96D80; // "private void TryOfferBribe(BattleCharacterModel model)"
            inline constexpr std::uintptr_t SendOfferBribeMessage = 0xA96CD0; // "private void SendOfferBribeMessage()"
        }
    } // namespace OfferBribeInputUpdater

    namespace OpenCloseInputDescription { // "Models.References.Input.OpenCloseInputDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x824A730; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t Open = 0x0; // "OpenCloseInputDescription"
            inline constexpr std::uintptr_t Close = 0x8; // "OpenCloseInputDescription"
        }
    } // namespace OpenCloseInputDescription

    namespace OtherLookRotationModelUpdater { // "Game.Battle.EntityModel.BattleCharacter.Rotation.OtherLookRotationModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t rotationModel = 0x10; // "CharacterRotationModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xCD6260; // "public void Update()"
            inline constexpr std::uintptr_t GetOtherLookRotation = 0xCD6170; // "private Quaternion GetOtherLookRotation(in Quaternion interpolatedLookRotation)"
        }
    } // namespace OtherLookRotationModelUpdater

    namespace OverrideBlendUpdater { // "Game.Battle.Entities.Player.Updaters.OverrideBlendUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t assistant = 0x10; // "AnimationStateAssistant"
        }
        namespace Methods {
            inline constexpr std::uintptr_t OverrideCinemachineBlend = 0xB0B860; // "private CinemachineBlendDefinition OverrideCinemachineBlend(ICinemachineCamera from, ICinemachineCamera to, CinemachineBlendDefinition defaultBlend, MonoBehaviour owner)"
            inline constexpr std::uintptr_t Update = 0x7B3360; // "public void Update()"
        }
    } // namespace OverrideBlendUpdater

    namespace OwnedCharacterSkinsData { // "Models.Data.OwnedCharacterSkinsData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Bodies = 0x20; // "SetData<CharacterBodyDescription>"
            inline constexpr std::uintptr_t FBodies = 0x28; // "SetData<CharacterFBodyDescription>"
            inline constexpr std::uintptr_t Bags = 0x30; // "SetData<CharacterBagDescription>"
            inline constexpr std::uintptr_t Masks = 0x38; // "SetData<CharacterMaskDescription>"
            inline constexpr std::uintptr_t Keychains = 0x40; // "SetData<CharacterKeychainDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Build_T_inst_1 = 0x1711200; // "OwnedCharacterSkinsData.Build<object>"
        }
    } // namespace OwnedCharacterSkinsData

    namespace OwnerRules { // "Game.Battle.Player.OwnerRules (Battle.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t IsOwnedByPlayerOrHisPartyMember = 0x964AC0; // "public static bool IsOwnedByPlayerOrHisPartyMember(int entityId, GlobalModel globalModel, BattleModel battleModel)"
            inline constexpr std::uintptr_t IsFriendlyPublicId = 0x964910; // "public static bool IsFriendlyPublicId(long ownerPublicId, GlobalModel globalModel)"
            inline constexpr std::uintptr_t IsOwnedByPlayerOrHisPartyMemberOrNeutral = 0x964970; // "public static bool IsOwnedByPlayerOrHisPartyMemberOrNeutral(int entityId, BattleModel battleModel)"
            inline constexpr std::uintptr_t GetOwnerStatus = 0x9645D0; // "public static OwnerRules.OwnerStatus GetOwnerStatus(int entityId, BattleModel battleModel)"
            inline constexpr std::uintptr_t IsOwnedByPlayer = 0x964D50; // "public static bool IsOwnedByPlayer(int playerId, BattleModel battleModel, PlotSlotDescription plotSlotDescription)"
            inline constexpr std::uintptr_t IsClanBattleAndPlayerInSameClan = 0x964740; // "public static bool IsClanBattleAndPlayerInSameClan(int entityId, BattleModeDescription battleMode, ClanModel clanModel, WorldEntitiesModel worldEntitiesModel)"
            inline constexpr std::uintptr_t TryGetOwnerPublicId = 0x964E30; // "public static bool TryGetOwnerPublicId(int entityId, WorldEntitiesModel worldEntitiesModel, out long ownerPublicId)"
        }
    } // namespace OwnerRules

    namespace PartyManagerInputUpdater { // "Game.Global.Party.Dialog.PartyManagerInputUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t partyModel = 0x10; // "PartyModel"
            inline constexpr std::uintptr_t partyManagerDialogModel = 0x18; // "PartyManagerDialogModel"
            inline constexpr std::uintptr_t partyManagerDialogView = 0x20; // "PartyManagerDialogView"
            inline constexpr std::uintptr_t roomConnectionsRegionUser = 0x28; // "IRoomConnection"
            inline constexpr std::uintptr_t uiSoundModel = 0x30; // "GlobalUISoundModel"
            inline constexpr std::uintptr_t personalNotificationModel = 0x38; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t partyLocalization = 0x40; // "PartyLocalization"
            inline constexpr std::uintptr_t realmBattleStateModel = 0x48; // "RealmBattleStateModel"
            inline constexpr std::uintptr_t delayedResponsesModel = 0x50; // "IDelayedResponsesModel"
            inline constexpr std::uintptr_t modalDialogModel = 0x58; // "ModalDialogModel"
            inline constexpr std::uintptr_t privateChatContext = 0x60; // "PrivateChatContext"
            inline constexpr std::uintptr_t contextActionRules = 0x68; // "GeneralContextActionRules"
            inline constexpr std::uintptr_t publicIdModel = 0x70; // "PublicIdModel"
            inline constexpr std::uintptr_t Handlers = 0x78; // "ValueTuple<InputMask, IUpdater>[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t OnRemoveFromBlackListClick = 0x356CD80; // "private void OnRemoveFromBlackListClick()"
            inline constexpr std::uintptr_t OnAddToBlackListClick = 0x356C8C0; // "private void OnAddToBlackListClick()"
            inline constexpr std::uintptr_t OnWhisperClick = 0x356CE20; // "private void OnWhisperClick()"
            inline constexpr std::uintptr_t Close = 0xB1DF00; // "private void Close()"
            inline constexpr std::uintptr_t OnInvitePlayerButtonClick = 0x356C9A0; // "private void OnInvitePlayerButtonClick()"
            inline constexpr std::uintptr_t ContainMember = 0x356C5C0; // "private bool ContainMember(long publicId)"
            inline constexpr std::uintptr_t OnMakeLeaderButtonClick = 0x356CCD0; // "private void OnMakeLeaderButtonClick()"
            inline constexpr std::uintptr_t ParseChangeLeaderResponse = 0x356CF40; // "private void ParseChangeLeaderResponse(string value)"
            inline constexpr std::uintptr_t OnKickPlayerButtonClick = 0x356CB70; // "private void OnKickPlayerButtonClick()"
            inline constexpr std::uintptr_t OnLeaveButtonClick = 0x356CC20; // "private void OnLeaveButtonClick()"
            inline constexpr std::uintptr_t OnContextButtonClick = 0x356C960; // "private void OnContextButtonClick(int index)"
            inline constexpr std::uintptr_t get_Priority = 0x7E5D90; // "public InputHandlerPriority get_Priority()"
            inline constexpr std::uintptr_t Notify = 0x356C870; // "private void Notify(LocalizedString localizedString)"
        }
    } // namespace PartyManagerInputUpdater

    namespace PartyPlayerLineUpdater { // "Game.Global.Party.Dialog.PartyPlayerLineUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t index = 0x10; // "int"
            inline constexpr std::uintptr_t partyPlayerLineView = 0x18; // "PartyPlayerLineView"
            inline constexpr std::uintptr_t partyManagerDialogModel = 0x20; // "PartyManagerDialogModel"
            inline constexpr std::uintptr_t partyModel = 0x28; // "PartyModel"
            inline constexpr std::uintptr_t publicIdModel = 0x30; // "PublicIdModel"
            inline constexpr std::uintptr_t realmBattleStateModel = 0x38; // "RealmBattleStateModel"
            inline constexpr std::uintptr_t lastStatus = 0x40; // "PartyPlayerLineUpdater.Status"
            inline constexpr std::uintptr_t checkStatus = 0x44; // "PartyPlayerLineView.PartyMemberCheckStatus"
            inline constexpr std::uintptr_t nicknameState = 0x48; // "PartyPlayerLineView.NicknameState"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x3575C90; // "public void Update()"
            inline constexpr std::uintptr_t GetState = 0x35755F0; // "private PartyPlayerLineUpdater.Status GetState()"
            inline constexpr std::uintptr_t GetStateInParty = 0x3575460; // "private PartyPlayerLineView.PartyMemberCheckStatus GetStateInParty(PartyMemberModel partyMemberModel, bool isThisPlayerLine)"
            inline constexpr std::uintptr_t UpdateLeadership = 0x3575B30; // "private void UpdateLeadership(bool isLead)"
            inline constexpr std::uintptr_t UpdateInPartyState = 0x3575A20; // "private void UpdateInPartyState(PartyPlayerLineView.PartyMemberCheckStatus status)"
            inline constexpr std::uintptr_t UpdateLeaveButtonView = 0x3575B60; // "private void UpdateLeaveButtonView()"
            inline constexpr std::uintptr_t SetStatusState = 0x35759D0; // "private void SetStatusState(PartyPlayerLineView.PartyMemberCheckStatus checkStatus)"
            inline constexpr std::uintptr_t SetNicknameState = 0x35757F0; // "private void SetNicknameState(PartyPlayerLineView.NicknameState nicknameState)"
            inline constexpr std::uintptr_t UpdateNickname = 0x3575C20; // "private void UpdateNickname(string clanTag, string nickname)"
        }
    } // namespace PartyPlayerLineUpdater

    namespace PerformedActionInputUpdater { // "Game.Global.PerformedActionInputUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t action = 0x10; // "Action"
            inline constexpr std::uintptr_t input = 0x18; // "InputAction"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x365E200; // "public void Update()"
        }
    } // namespace PerformedActionInputUpdater

    namespace PlayerActiveCameraUpdater { // "Game.Battle.PlayerCameraType.PlayerActiveCameraUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleEntities = 0x10; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t blendModel = 0x18; // "MixingCameraBlendModel"
            inline constexpr std::uintptr_t armed = 0x20; // "CinemachineVirtualCamera"
            inline constexpr std::uintptr_t helicopter = 0x28; // "CinemachineVirtualCamera"
            inline constexpr std::uintptr_t emotion = 0x30; // "CinemachineVirtualCamera"
            inline constexpr std::uintptr_t hiding = 0x38; // "CinemachineVirtualCamera"
            inline constexpr std::uintptr_t sprint = 0x40; // "CinemachineVirtualCamera"
            inline constexpr std::uintptr_t closeToGround = 0x48; // "CinemachineVirtualCamera"
            inline constexpr std::uintptr_t knockout = 0x50; // "CinemachineVirtualCamera"
            inline constexpr std::uintptr_t water = 0x58; // "CinemachineVirtualCamera"
            inline constexpr std::uintptr_t carCamera = 0x60; // "CarCameraView"
            inline constexpr std::uintptr_t player = 0x68; // "BattleCharacterModel"
            inline constexpr std::uintptr_t velocity = 0x70; // "CharacterVelocityModel"
            inline constexpr std::uintptr_t selectedItemModel = 0x78; // "SelectedItemModel"
            inline constexpr std::uintptr_t usableItemViewDescriptions = 0x80; // "UsableItemViewDescriptions"
            inline constexpr std::uintptr_t throwableItemViewDescriptions = 0x88; // "ThrowableItemViewDescriptions"
            inline constexpr std::uintptr_t playerCameraTypeModel = 0x90; // "PlayerCameraTypeModel"
            inline constexpr std::uintptr_t isSprinting = 0x98; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x974280; // "public void Update()"
            inline constexpr std::uintptr_t GetTargetCamera = 0x974000; // "private CinemachineVirtualCameraBase GetTargetCamera(CameraType targetCameraType)"
            inline constexpr std::uintptr_t GetTargetCameraType = 0x973AD0; // "private CameraType GetTargetCameraType()"
        }
    } // namespace PlayerActiveCameraUpdater

    namespace PlayerAimingCameraWeightUpdater { // "Game.Battle.Entities.Player.Updaters.PlayerAimingCameraWeightUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t aimingCameraFollow = 0x10; // "CinemachineAimingCameraFollow"
            inline constexpr std::uintptr_t aimingModel = 0x18; // "CharacterAimingModel"
            inline constexpr std::uintptr_t aimState = 0x20; // "AimStateModel"
            inline constexpr std::uintptr_t maxStep = 0x28; // "float"
            inline constexpr std::uintptr_t defaultIntoDamping = 0x2C; // "float"
            inline constexpr std::uintptr_t enteringBeginWeight = 0x30; // "float"
            inline constexpr std::uintptr_t oldState = 0x38; // "AimStateDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB0BC20; // "public void Update()"
        }
    } // namespace PlayerAimingCameraWeightUpdater

    namespace PlayerAutoLootInputUpdater { // "Game.Battle.Player.PlayerAutoLootInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleInputModel = 0x10; // "BattleInputModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x18; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t wasSent = 0x20; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x974980; // "public void Update()"
            inline constexpr std::uintptr_t StartLootEntity = 0x974720; // "private void StartLootEntity(IEntityModel entityModel)"
        }
    } // namespace PlayerAutoLootInputUpdater

    namespace PlayerBattleData { // "Models.Data.PlayerBattleData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t LastKillTickIndex = 0x20; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t ReadyCheckStatus = 0x28; // "IPrimitiveData<PartyReadyCheckStatusDescription>"
            inline constexpr std::uintptr_t CopName = 0x30; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t CopClanTag = 0x38; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t CopPublicId = 0x40; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t Vehicles = 0x48; // "PlayerVehiclesData"
            inline constexpr std::uintptr_t LastKnockoutTickIndex = 0x50; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t HasMark = 0x58; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t MarkX = 0x60; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t MarkY = 0x68; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t MarkZ = 0x70; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t LastSpawnVehicleTs = 0x78; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t PingMarkX = 0x80; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t PingMarkY = 0x88; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t PingMarkZ = 0x90; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t PingMarkTs = 0x98; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t PingMarkType = 0xA0; // "IPrimitiveData<PingMarkTypeDescription>"
            inline constexpr std::uintptr_t SettlementCollectionSlots = 0xA8; // "ReferenceMapData<CollectionTableSlotDescription, CollectionTableSlotData>"
            inline constexpr std::uintptr_t SuicideTs = 0xB0; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t CryptoCoins = 0xB8; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t Coins = 0xC0; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t BankAccount = 0xC8; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t IsVehicleTrunkEmpty = 0xD0; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t IsCarUpgradesEmpty = 0xD8; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t SelectedWeaponQuickSlot = 0xE0; // "IPrimitiveData<QuickSlotDescription>"
            inline constexpr std::uintptr_t DeathTs = 0xE8; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t KillerName = 0xF0; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t KillerPublicId = 0xF8; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t KillerClanTag = 0x100; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t DeathReason = 0x108; // "IPrimitiveData<DeathReasonDescription>"
            inline constexpr std::uintptr_t MovePlotCooldownEndTs = 0x110; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t VehicleType = 0x118; // "IPrimitiveData<VehicleTypeDescription>"
            inline constexpr std::uintptr_t VehicleX = 0x120; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t VehicleZ = 0x128; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t IsChangingSpot = 0x130; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t PlotGrade = 0x138; // "IPrimitiveData<PlotGradeDescription>"
            inline constexpr std::uintptr_t GetLocationClanConquestObjectsCooldownEndTs = 0x140; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t Emotions = 0x148; // "EmotionsData"
            inline constexpr std::uintptr_t WeaponSkins = 0x150; // "WeaponSkinsData"
            inline constexpr std::uintptr_t ShopPacks = 0x158; // "SetData<ShopPackDescription>"
            inline constexpr std::uintptr_t OwnedCharacterSkins = 0x160; // "OwnedCharacterSkinsData"
            inline constexpr std::uintptr_t ChangePlotVehicleRequestTs = 0x168; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t ChangePlotVehicleRequestAmount = 0x170; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t SendMessageInChatExpiringResourceTs = 0x178; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t SendMessageInChatExpiringResourceAmount = 0x180; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t GetLockedVendorTreeNodesPriceItemsCountExpiringResourceTs = 0x188; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t GetLockedVendorTreeNodesPriceItemsCountExpiringResourceAmount = 0x190; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t GetCashItemCountExpiringResourceTs = 0x198; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t GetCashItemCountExpiringResourceAmount = 0x1A0; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t RespawnCooldownEndTs = 0x1A8; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t Tattoos = 0x1B0; // "TattoosData"
            inline constexpr std::uintptr_t Crimes = 0x1B8; // "CrimesData"
            inline constexpr std::uintptr_t ImprisonmentYears = 0x1C0; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t ClaimedImprisonmentYears = 0x1C8; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t PrisonEnterType = 0x1D0; // "IPrimitiveData<PrisonEnterTypeDescription>"
            inline constexpr std::uintptr_t RealmAssetsValues = 0x1D8; // "RealmAssetsValuesData"
            inline constexpr std::uintptr_t IsRealmSessionConvertedToYears = 0x1E0; // "PrimitiveData<bool>"
            inline constexpr std::uintptr_t BeforePrisonRealmId = 0x1E8; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t BeforePrisonRealmImprisonmentYears = 0x1F0; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t ImprisonmentYearsDailyLimit = 0x1F8; // "ImprisonmentYearsDailyLimitData"
            inline constexpr std::uintptr_t TutorialStep = 0x200; // "IPrimitiveData<TutorialStepDescription>"
            inline constexpr std::uintptr_t TutorialLastStepTs = 0x208; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t UpgradesHolderCarEntityId = 0x210; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t CarUpgradesHolderType = 0x218; // "IPrimitiveData<CarUpgradesHolderTypeDescription>"
            inline constexpr std::uintptr_t PersonalDisconnectTs = 0x220; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t SelfSector = 0x228; // "IPrimitiveData<SectorDescription>"
            inline constexpr std::uintptr_t FirstAidCabinets = 0x230; // "FirstAidCabinetPlayerData"
            inline constexpr std::uintptr_t CopSalary = 0x238; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t HoldingCellReleaseTs = 0x240; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t RobberAuthorityPoints = 0x248; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t SpawnedVehicleData = 0x250; // "CharacterSpawnedVehicleData"
            inline constexpr std::uintptr_t IsCopRewardBoxEmpty = 0x258; // "PrimitiveData<bool>"
            inline constexpr std::uintptr_t CopRewardBoxEntityId = 0x260; // "PrimitiveData<int>"
            inline constexpr std::uintptr_t CopPreset = 0x268; // "IPrimitiveData<CopPresetDescription>"
            inline constexpr std::uintptr_t BackupInventoryPoliceBadges = 0x270; // "IReferenceMapData<PoliceBadgeDescription, IPrimitiveData<int>>"
            inline constexpr std::uintptr_t WantedPoints = 0x278; // "WantedPointsData"
            inline constexpr std::uintptr_t CopCryBuffEndTs = 0x280; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t CopSirenBuffEndTs = 0x288; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t CopReinforcementBuffEndTs = 0x290; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t EOSIsRequesting = 0x298; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t EOSUpdateRoomTokenCooldownEndTs = 0x2A0; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t EOSClientBaseUrl = 0x2A8; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t EOSRoomToken = 0x2B0; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t UnlockedVendorTreeNodes = 0x2B8; // "UnlockedVendorTreeNodesData"
            inline constexpr std::uintptr_t CharacterLaundering = 0x2C0; // "CharacterLaunderingData"
            inline constexpr std::uintptr_t RouletteReward = 0x2C8; // "CashAmountData"
            inline constexpr std::uintptr_t PersonalRepositoryEntityId = 0x2D0; // "PrimitiveData<int>"
            inline constexpr std::uintptr_t PoliceBadgeRepositoryEntityId = 0x2D8; // "PrimitiveData<int>"
            inline constexpr std::uintptr_t PoliceBadgeRepositoryAmounts = 0x2E0; // "IReferenceMapData<PoliceBadgeDescription, IPrimitiveData<int>>"
            inline constexpr std::uintptr_t CurrencyExchangeExpiringResource = 0x2E8; // "CurrencyExchangeExpiringResourceData"
            inline constexpr std::uintptr_t VipEndTs = 0x2F0; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t Mailbox = 0x2F8; // "MailboxData"
            inline constexpr std::uintptr_t MailboxLastChangeTs = 0x300; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t CopRecruitingReadyCheckEndTs = 0x308; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t Achievements = 0x310; // "AchievementsData"
            inline constexpr std::uintptr_t IsDebtPaid = 0x318; // "PrimitiveData<bool>"
            inline constexpr std::uintptr_t IsDebtImprisonmentYearsBonusUsed = 0x320; // "PrimitiveData<bool>"
            inline constexpr std::uintptr_t UsedTransactions = 0x328; // "UsedTransactionsData"
            inline constexpr std::uintptr_t BattlePassPoints = 0x330; // "BattlePassPointsData"
            inline constexpr std::uintptr_t BattlePasses = 0x338; // "BattlePassesData"
        }
    } // namespace PlayerBattleData

    namespace PlayerBattleModel { // "Models.Models.PlayerBattle.PlayerBattleModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Data = 0x10; // "PlayerBattleData"
            inline constexpr std::uintptr_t ReadyCheckStatusModel = 0x18; // "IPrimitiveModel<PartyReadyCheckStatusDescription>"
            inline constexpr std::uintptr_t Vehicles = 0x20; // "PlayerVehiclesModel"
            inline constexpr std::uintptr_t LastKnockoutTickIndex = 0x28; // "IPrimitiveModel<int>"
            inline constexpr std::uintptr_t LastKillTickIndex = 0x30; // "IPrimitiveModel<int>"
            inline constexpr std::uintptr_t MapMarkModel = 0x38; // "PlayerMapMarkModel"
            inline constexpr std::uintptr_t VehiclesData = 0x40; // "PlayerVehiclesData"
            inline constexpr std::uintptr_t LastSpawnVehicleTs = 0x48; // "IPrimitiveModel<long>"
            inline constexpr std::uintptr_t PingMarkModel = 0x50; // "PlayerPingMarkModel"
            inline constexpr std::uintptr_t GatherSettlementCollectionsModel = 0x58; // "GatherSettlementCollectionsModel"
            inline constexpr std::uintptr_t IsVehicleTrunkEmpty = 0x60; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t IsCarUpgradesEmpty = 0x68; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t SuicideTs = 0x70; // "IPrimitiveModel<long>"
            inline constexpr std::uintptr_t SelectedWeaponQuickSlotModel = 0x78; // "IPrimitiveModel<QuickSlotDescription>"
            inline constexpr std::uintptr_t CryptoCoinsModel = 0x80; // "CoinsModel"
            inline constexpr std::uintptr_t CoinsModel = 0x88; // "CoinsModel"
            inline constexpr std::uintptr_t CoinsAccessModel = 0x90; // "CoinsAccessModel"
            inline constexpr std::uintptr_t VipModel = 0x98; // "VipModel"
            inline constexpr std::uintptr_t DeathModel = 0xA0; // "CharacterDeathModel"
            inline constexpr std::uintptr_t ArrestingCopModel = 0xA8; // "ArrestingCopModel"
            inline constexpr std::uintptr_t MovePlotCooldownEndTs = 0xB0; // "IPrimitiveModel<long>"
            inline constexpr std::uintptr_t VehicleMapTransformModel = 0xB8; // "VehicleMapTransformModel"
            inline constexpr std::uintptr_t IsChangingSpot = 0xC0; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t GetLocationClanConquestObjectsCooldownEndTs = 0xC8; // "IPrimitiveModel<long>"
            inline constexpr std::uintptr_t EmotionSlotsModel = 0xD0; // "EmotionSlotsModel"
            inline constexpr std::uintptr_t OwnedEmotionsModel = 0xD8; // "IOwnedItemsModel<EmotionDescription>"
            inline constexpr std::uintptr_t WeaponSkinsModel = 0xE0; // "WeaponSkinsModel"
            inline constexpr std::uintptr_t OwnedWeaponSkinsModel = 0xE8; // "IOwnedItemsModel<WeaponSkinDescription>"
            inline constexpr std::uintptr_t OwnedCharacterBodiesSkins = 0xF0; // "IOwnedItemsModel<CharacterBodyDescription>"
            inline constexpr std::uintptr_t OwnedCharacterFBodiesSkins = 0xF8; // "IOwnedItemsModel<CharacterFBodyDescription>"
            inline constexpr std::uintptr_t OwnedCharacterBagsSkins = 0x100; // "IOwnedItemsModel<CharacterBagDescription>"
            inline constexpr std::uintptr_t OwnedCharacterMasksSkins = 0x108; // "IOwnedItemsModel<CharacterMaskDescription>"
            inline constexpr std::uintptr_t OwnedCharacterKeychainsSkins = 0x110; // "IOwnedItemsModel<CharacterKeychainDescription>"
            inline constexpr std::uintptr_t OwnedShopPacks = 0x118; // "IOwnedItemsModel<ShopPackDescription>"
            inline constexpr std::uintptr_t ShopPackOwnership = 0x120; // "ShopPackOwnershipModel"
            inline constexpr std::uintptr_t BattlePassModel = 0x128; // "BattlePassModel"
            inline constexpr std::uintptr_t BattlePassAwards = 0x130; // "BattlePassAwardsModel"
            inline constexpr std::uintptr_t IsVehicleLootDroppedOnPlayerLeave = 0x138; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t ChangePlotVehicleExpiringResource = 0x140; // "ExpiringResourceModel"
            inline constexpr std::uintptr_t PartyVehicleExitModel = 0x148; // "PartyVehicleExitModel"
            inline constexpr std::uintptr_t LocationVehicleModel = 0x150; // "BattleCharacterLocationVehicleModel"
            inline constexpr std::uintptr_t SendMessageInChatExpiringResource = 0x158; // "ExpiringResourceModel"
            inline constexpr std::uintptr_t RespawnCooldownEndTs = 0x160; // "IPrimitiveModel<long>"
            inline constexpr std::uintptr_t RoleDeathStreaksModel = 0x168; // "RoleDeathStreaksModel"
            inline constexpr std::uintptr_t TattoosModel = 0x170; // "TattoosModel"
            inline constexpr std::uintptr_t CrimesModel = 0x178; // "CrimesModel"
            inline constexpr std::uintptr_t ImprisonmentYears = 0x180; // "ImprisonmentYearsModel"
            inline constexpr std::uintptr_t ClaimedImprisonmentYears = 0x188; // "ImprisonmentYearsModel"
            inline constexpr std::uintptr_t PrisonEnterType = 0x190; // "IPrimitiveModel<PrisonEnterTypeDescription>"
            inline constexpr std::uintptr_t RealmAssetsValues = 0x198; // "RealmAssetsValuesModel"
            inline constexpr std::uintptr_t IsRealmSessionConvertedToYears = 0x1A0; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t BeforePrisonRealmImprisonmentYears = 0x1A8; // "IPrimitiveModel<int>"
            inline constexpr std::uintptr_t ImprisonmentYearsDailyLimit = 0x1B0; // "ExpiringResourceModel"
            inline constexpr std::uintptr_t IsDebtPaid = 0x1B8; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t IsDebtImprisonmentYearsBonusUsed = 0x1C0; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t BattlePassPoints = 0x1C8; // "BattlePassPointsModel"
            inline constexpr std::uintptr_t TutorialStep = 0x1D0; // "IPrimitiveModel<TutorialStepDescription>"
            inline constexpr std::uintptr_t TutorialLastStepTs = 0x1D8; // "IPrimitiveModel<long>"
            inline constexpr std::uintptr_t PoliceCarBreachState = 0x1E0; // "BattleCharacterPoliceCarBreachStateModel"
            inline constexpr std::uintptr_t UpgradesHolderCarEntityId = 0x1E8; // "IPrimitiveModel<int>"
            inline constexpr std::uintptr_t CarUpgradesHolderType = 0x1F0; // "IPrimitiveModel<CarUpgradesHolderTypeDescription>"
            inline constexpr std::uintptr_t IsPlayerKickedFromClanBattle = 0x1F8; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t PersonalDisconnectTs = 0x200; // "IPrimitiveModel<long>"
            inline constexpr std::uintptr_t SelfSector = 0x208; // "IPrimitiveModel<SectorDescription>"
            inline constexpr std::uintptr_t FirstAidCabinets = 0x210; // "PlayerFirstAidCabinetModel"
            inline constexpr std::uintptr_t CopSalary = 0x218; // "CoinsModel"
            inline constexpr std::uintptr_t HoldingCell = 0x220; // "BattleCharacterHoldingCellModel"
            inline constexpr std::uintptr_t RobberAuthorityModel = 0x228; // "RobberAuthorityModel"
            inline constexpr std::uintptr_t SpawnedVehicleModel = 0x230; // "CharacterSpawnedVehicleModel"
            inline constexpr std::uintptr_t TargetBattleModel = 0x238; // "IPrimitiveModel<UserTargetBattleDescription>"
            inline constexpr std::uintptr_t IsCopRewardBoxEmpty = 0x240; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t CopRewardBoxEntityId = 0x248; // "IPrimitiveModel<int>"
            inline constexpr std::uintptr_t CopPreset = 0x250; // "IPrimitiveModel<CopPresetDescription>"
            inline constexpr std::uintptr_t CopPresetIsFree = 0x258; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t InventoryBackupModel = 0x260; // "InventoryBackupModel"
            inline constexpr std::uintptr_t BackupInventoryPoliceBadgesModel = 0x268; // "BackupInventoryPoliceBadgesModel"
            inline constexpr std::uintptr_t WantedPoints = 0x270; // "IPrimitiveModel<int>"
            inline constexpr std::uintptr_t CopCryBuffEndTs = 0x278; // "IPrimitiveModel<long>"
            inline constexpr std::uintptr_t CopSirenBuffEndTs = 0x280; // "IPrimitiveModel<long>"
            inline constexpr std::uintptr_t CopSirenBuffTargetCarId = 0x288; // "IPrimitiveModel<int>"
            inline constexpr std::uintptr_t CopReinforcementBuffEndTs = 0x290; // "IPrimitiveModel<long>"
            inline constexpr std::uintptr_t EOSModel = 0x298; // "BattleEOSModel"
            inline constexpr std::uintptr_t UnlockedVendorTreeNodes = 0x2A0; // "UnlockedVendorTreeNodesModel"
            inline constexpr std::uintptr_t GetLockedVendorTreeNodesPriceItemsCountExpiringResource = 0x2A8; // "ExpiringResourceModel"
            inline constexpr std::uintptr_t GetCashItemsCountExpiringResource = 0x2B0; // "ExpiringResourceModel"
            inline constexpr std::uintptr_t CharacterLaundering = 0x2B8; // "CharacterLaunderingModel"
            inline constexpr std::uintptr_t CharacterRouletteReward = 0x2C0; // "CharacterRouletteRewardModel"
            inline constexpr std::uintptr_t PersonalRepositoryEntityId = 0x2C8; // "IPrimitiveModel<int>"
            inline constexpr std::uintptr_t PoliceBadgeRepositoryEntityId = 0x2D0; // "IPrimitiveModel<int>"
            inline constexpr std::uintptr_t PoliceBadgeRepositoryAmountsModel = 0x2D8; // "PoliceBadgeRepositoryAmountsModel"
            inline constexpr std::uintptr_t TakenCashModel = 0x2E0; // "AnalyticsTakenCashModel"
            inline constexpr std::uintptr_t AssistingCops = 0x2E8; // "IEventsSet<FoundCopData>"
            inline constexpr std::uintptr_t SellCryptoExpiringResource = 0x2F0; // "ExpiringResourceModel"
            inline constexpr std::uintptr_t BuyCryptoExpiringResource = 0x2F8; // "ExpiringResourceModel"
            inline constexpr std::uintptr_t MailboxModel = 0x300; // "MailboxModel"
            inline constexpr std::uintptr_t CopRecruitingReadyCheckModel = 0x308; // "BattleReadyCheckModel"
            inline constexpr std::uintptr_t AchievementsModel = 0x310; // "AchievementsModel"
            inline constexpr std::uintptr_t AchievementAwardsModel = 0x318; // "AchievementAwardsModel"
            inline constexpr std::uintptr_t UsedTransactionsModel = 0x320; // "UsedTransactionsModel"
            inline constexpr std::uintptr_t LastRoleChangeDataModel = 0x328; // "LastRoleChangeDataModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_BeforePrisonRealmId = 0x4928E90; // "public int get_BeforePrisonRealmId()"
        }
    } // namespace PlayerBattleModel

    namespace PlayerBulletsWhistleUpdater { // "Game.Battle.EntityModel.Player.PlayerBulletsWhistleUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t charactersShotsModel = 0x10; // "CharactersShotsModel"
            inline constexpr std::uintptr_t movementModel = 0x18; // "IMovementModel"
            inline constexpr std::uintptr_t crouchModel = 0x20; // "CharacterCrouchModel"
            inline constexpr std::uintptr_t config = 0x28; // "BattleCharacterConfig"
            inline constexpr std::uintptr_t bulletWhistle = 0x30; // "Event"
            inline constexpr std::uintptr_t soundEmitter = 0x38; // "GameObject"
            inline constexpr std::uintptr_t tickIndex = 0x40; // "long"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC49D10; // "public void Update()"
        }
    } // namespace PlayerBulletsWhistleUpdater

    namespace PlayerCameraModel { // "Game.Battle.Entities.Player.Models.PlayerCameraModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t FollowPosition = 0x10; // "Vector3"
            inline constexpr std::uintptr_t ShoulderSwitchProgress = 0x1C; // "float"
        }
    } // namespace PlayerCameraModel

    namespace PlayerCameraModelUpdater { // "Game.Battle.Entities.Player.Updaters.PlayerCameraModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t movementModel = 0x10; // "IMovementModel"
            inline constexpr std::uintptr_t aimingModel = 0x18; // "CharacterAimingModel"
            inline constexpr std::uintptr_t crouch = 0x20; // "CharacterCrouchModel"
            inline constexpr std::uintptr_t config = 0x28; // "BattleCharacterConfig"
            inline constexpr std::uintptr_t camera = 0x30; // "PlayerCameraModel"
            inline constexpr std::uintptr_t weapon = 0x38; // "IWeaponModel"
            inline constexpr std::uintptr_t aimModeModel = 0x40; // "IPrimitiveModel<AimModeDescription>"
            inline constexpr std::uintptr_t cameraViewDescription = 0x48; // "PlayerCameraViewDescriptions"
            inline constexpr std::uintptr_t isLeftShoulderView = 0x50; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t shoulderSwitchTime = 0x58; // "float"
            inline constexpr std::uintptr_t isLeftShoulder = 0x5C; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB0C5F0; // "public void Update()"
            inline constexpr std::uintptr_t UpdateFollowPosition = 0xB0C180; // "private void UpdateFollowPosition()"
            inline constexpr std::uintptr_t UpdateShoulderSwitchProgress = 0xB0C4F0; // "private void UpdateShoulderSwitchProgress()"
        }
    } // namespace PlayerCameraModelUpdater

    namespace PlayerCameraTripodUpdater { // "Game.Battle.EntityModel.Player.PlayerCameraTripodUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t crouchModel = 0x10; // "CharacterCrouchModel"
            inline constexpr std::uintptr_t playerCameraModel = 0x18; // "PlayerCameraModel"
            inline constexpr std::uintptr_t isLeftShoulderView = 0x20; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t config = 0x28; // "BattleCharacterConfig"
            inline constexpr std::uintptr_t cameraFollows = 0x30; // "Cinemachine3rdPersonFollow[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC4A270; // "public void Update()"
        }
    } // namespace PlayerCameraTripodUpdater

    namespace PlayerCameraTypeModel { // "Game.Battle.PlayerCameraType.PlayerCameraTypeModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t CameraType = 0x10; // "CameraType"
        }
    } // namespace PlayerCameraTypeModel

    namespace PlayerCargoSellerUpdater { // "Game.Battle.EntityModel.CargoSeller.PlayerCargoSellerUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t updaters = 0x10; // "IUpdater"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xCAE490; // "public void Update()"
        }
    } // namespace PlayerCargoSellerUpdater

    namespace PlayerCityInputStateUpdater { // "Game.Battle.Inputs.PlayerCityInputStateUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleEntitiesModel = 0x10; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t inCar = 0x18; // "ValueTuple<InputMask, IUpdater>[]"
            inline constexpr std::uintptr_t inHelicopter = 0x20; // "ValueTuple<InputMask, IUpdater>[]"
            inline constexpr std::uintptr_t inHiddenObject = 0x28; // "ValueTuple<InputMask, IUpdater>[]"
            inline constexpr std::uintptr_t idle = 0x30; // "ValueTuple<InputMask, IUpdater>[]"
            inline constexpr std::uintptr_t idleKnockout = 0x38; // "ValueTuple<InputMask, IUpdater>[]"
            inline constexpr std::uintptr_t idleArrested = 0x40; // "ValueTuple<InputMask, IUpdater>[]"
            inline constexpr std::uintptr_t idleSurrender = 0x48; // "ValueTuple<InputMask, IUpdater>[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t GetHandler = 0xA7F820; // "private ValueTuple<InputMask, IUpdater>[] GetHandler(IUpdater mainAction, IUpdater mainLook, IUpdater movement, IUpdater back, IUpdater interact, IUpdater notification, IUpdater voiceChat)"
            inline constexpr std::uintptr_t get_Handlers = 0xA84210; // "public ValueTuple<InputMask, IUpdater>[] get_Handlers()"
            inline constexpr std::uintptr_t get_Priority = 0x7E3AB0; // "public InputHandlerPriority get_Priority()"
        }
    } // namespace PlayerCityInputStateUpdater

    namespace PlayerClientModel { // "Game.Battle.EntityModel.Player.PlayerClientModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t EquipContexts = 0x128; // "EquipItemMoveContext[]"
            inline constexpr std::uintptr_t PocketsContexts = 0x130; // "PocketItemMoveContext[]"
            inline constexpr std::uintptr_t InventoryContexts = 0x138; // "InventoryItemMoveContext[]"
            inline constexpr std::uintptr_t PlayerShotsModel = 0x140; // "PlayerShotsModel"
            inline constexpr std::uintptr_t HitMarkerModel = 0x148; // "HitMarkerModel"
            inline constexpr std::uintptr_t PredictHitsModel = 0x150; // "PredictHitsModel"
            inline constexpr std::uintptr_t PlayerTurningModel = 0x158; // "PlayerTurningModel"
            inline constexpr std::uintptr_t PopupDamageModel = 0x160; // "PopupDamageModel"
            inline constexpr std::uintptr_t ReceivedDamageModel = 0x168; // "ReceivedDamageModel"
            inline constexpr std::uintptr_t BusySlotsModel = 0x170; // "BusySlotsModel"
            inline constexpr std::uintptr_t BlockedSlotsModel = 0x178; // "BlockedSlotsModel"
            inline constexpr std::uintptr_t BuyBlockedSlotsModel = 0x180; // "BlockedSlotsModel"
            inline constexpr std::uintptr_t LockedTraderItemByLocationTier = 0x188; // "BlockedSlotsModel"
            inline constexpr std::uintptr_t LockedTraderItemByVendorTree = 0x190; // "BlockedSlotsModel"
            inline constexpr std::uintptr_t NewAvailableItemsByVendor = 0x198; // "NewAvailableItemsModel"
            inline constexpr std::uintptr_t BlockedEntitiesModel = 0x1A0; // "BlockedEntitiesModel"
            inline constexpr std::uintptr_t InventoryProgressItemModel = 0x1A8; // "InventoryProgressItemModel"
            inline constexpr std::uintptr_t InventoryIntention = 0x1B0; // "InventoryIntention"
            inline constexpr std::uintptr_t LootItemSoundModel = 0x1B8; // "LootItemSoundModel"
            inline constexpr std::uintptr_t GroupsInventoryItemsModel = 0x1C0; // "GroupsInventoryItemsModel"
            inline constexpr std::uintptr_t ChangedSlotsInventoryModel = 0x1C8; // "ChangedSlotsInventoryModel"
            inline constexpr std::uintptr_t DamageArmorModel = 0x1D0; // "DamageArmorModel"
            inline constexpr std::uintptr_t PlayerInVehicleModel = 0x1D8; // "PlayerInVehicleModel"
            inline constexpr std::uintptr_t LastSpawnPlotVehicleRequest = 0x1E0; // "RequestModel<string>"
            inline constexpr std::uintptr_t InventoryShadowAreaModel = 0x1E8; // "InventoryShadowAreaModel"
            inline constexpr std::uintptr_t MapVehicleTransformModel = 0x1F0; // "MapTransformModel"
            inline constexpr std::uintptr_t PlayerSurrenderArrestModel = 0x1F8; // "PlayerSurrenderArrestModel"
            inline constexpr std::uintptr_t PlayerForceKnockoutEndModel = 0x200; // "PlayerForceKnockoutEndModel"
            inline constexpr std::uintptr_t PlayerDelayInputVehicleLeaveModel = 0x208; // "PlayerDelayInputVehicleLeaveModel"
            inline constexpr std::uintptr_t KillOtherCharacterModel = 0x210; // "KillOtherCharacterModel"
            inline constexpr std::uintptr_t CameraModel = 0x218; // "PlayerCameraModel"
            inline constexpr std::uintptr_t UseItemModel = 0x220; // "UseItemModel"
            inline constexpr std::uintptr_t UseReloadWeapon = 0x228; // "UseReloadWeapon"
            inline constexpr std::uintptr_t UsePlateRule = 0x230; // "UsePlate"
            inline constexpr std::uintptr_t SingleUseItemRule = 0x238; // "SingleUseItem"
            inline constexpr std::uintptr_t UseItemsRule = 0x240; // "UseItemsRule"
            inline constexpr std::uintptr_t DirtyCashIncomeModel = 0x248; // "DirtyCashIncomeModel"
            inline constexpr std::uintptr_t PlayerCameraTypeModel = 0x250; // "PlayerCameraTypeModel"
            inline constexpr std::uintptr_t AccelerationWeightSpeed = 0x258; // "float"
            inline constexpr std::uintptr_t CharacterInSmokescreenModel = 0x260; // "CharacterInSmokescreenModel"
            inline constexpr std::uintptr_t IsInsideClanBattleFlagZone = 0x268; // "bool"
            inline constexpr std::uintptr_t SkinCenterModel = 0x270; // "SkinCenterModel"
            inline constexpr std::uintptr_t IsTeleported = 0x278; // "bool"
            inline constexpr std::uintptr_t HitsCacheModel = 0x280; // "HitsCacheModel"
            inline constexpr std::uintptr_t KinematicUseCooldownModel = 0x288; // "ClientCooldownModel"
            inline constexpr std::uintptr_t ImmunePopupModel = 0x290; // "ClientImmunePopupModel"
            inline constexpr std::uintptr_t DesiredYawModel = 0x298; // "DesiredYawModel"
            inline constexpr std::uintptr_t AimAssistModel = 0x2A0; // "AimAssistModel"
            inline constexpr std::uintptr_t AutoFireModel = 0x2A8; // "AutoFireModel"
            inline constexpr std::uintptr_t AutoLootAfterBreak = 0x2B0; // "AutoLootAfterBreakColliderModel"
            inline constexpr std::uintptr_t RecoilModel = 0x2B8; // "RecoilModel"
            inline constexpr std::uintptr_t FakeSpreadModel = 0x2C0; // "PlayerFakeSpreadModel"
            inline constexpr std::uintptr_t PlayerInsidePlotModel = 0x2C8; // "PlayerInsidePlotModel"
            inline constexpr std::uintptr_t IsActualData = 0x2D0; // "bool"
        }
    } // namespace PlayerClientModel

    namespace PlayerContextActionUpdater { // "Game.Battle.PlayerContextMenu.Updaters.PlayerContextActionUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t playerContextMenuView = 0x10; // "PlayerContextMenuView"
            inline constexpr std::uintptr_t playerContextMenuActions = 0x18; // "PlayerContextMenuActions"
            inline constexpr std::uintptr_t sectorInputModel = 0x20; // "SectorInputModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x949590; // "public void Update()"
        }
    } // namespace PlayerContextActionUpdater

    namespace PlayerContextMenuActions { // "Game.Battle.PlayerContextMenu.InputHandlers.PlayerContextMenuActions (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t playerContextMenuModel = 0x10; // "PlayerContextMenuModel"
            inline constexpr std::uintptr_t roomConnections = 0x18; // "IRoomConnections"
            inline constexpr std::uintptr_t getButtonActive = 0x20; // "Func<ContextMenuButtonType, bool>"
            inline constexpr std::uintptr_t view = 0x28; // "PlayerContextMenuView"
            inline constexpr std::uintptr_t globalLocalization = 0x30; // "GlobalLocalizationKeys"
            inline constexpr std::uintptr_t chatLocalization = 0x38; // "ChatLocalization"
            inline constexpr std::uintptr_t personalNotificationModel = 0x40; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t clanModel = 0x48; // "ClanModel"
            inline constexpr std::uintptr_t blackListModel = 0x50; // "BlackListModel"
            inline constexpr std::uintptr_t battleStateModel = 0x58; // "RealmBattleStateModel"
            inline constexpr std::uintptr_t privateChatContext = 0x60; // "PrivateChatContext"
            inline constexpr std::uintptr_t contextActionRules = 0x68; // "GeneralContextActionRules"
        }
        namespace Methods {
            inline constexpr std::uintptr_t GetActionBasedOnType = 0x974E40; // "public Action GetActionBasedOnType(ContextMenuButtonType contextMenuButtonType)"
            inline constexpr std::uintptr_t AddToGroup = 0x974BA0; // "private void AddToGroup()"
            inline constexpr std::uintptr_t AddFriend = 0x7B3360; // "private void AddFriend()"
            inline constexpr std::uintptr_t Report = 0x974FB0; // "private void Report()"
            inline constexpr std::uintptr_t Chat = 0x974CD0; // "private void Chat()"
            inline constexpr std::uintptr_t AddToClan = 0x974B00; // "private void AddToClan()"
            inline constexpr std::uintptr_t AddToOrRemoveFromBlackList = 0x974C80; // "private void AddToOrRemoveFromBlackList()"
            inline constexpr std::uintptr_t CloseDialog = 0x974DD0; // "public void CloseDialog()"
        }
    } // namespace PlayerContextMenuActions

    namespace PlayerContextMenuModel { // "Game.Battle.PlayerContextMenu.PlayerContextMenuModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Target = 0x18; // "BattleCharacterEntityModel"
        }
    } // namespace PlayerContextMenuModel

    namespace PlayerContextMenuUpdater { // "Game.Battle.PlayerContextMenu.Updaters.PlayerContextMenuUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t disposable = 0x10; // "IRegisterDisposable"
            inline constexpr std::uintptr_t updater = 0x18; // "IUpdater"
            inline constexpr std::uintptr_t sectorInputModel = 0x20; // "SectorInputModel"
            inline constexpr std::uintptr_t playerContextMenuActions = 0x28; // "PlayerContextMenuActions"
            inline constexpr std::uintptr_t battleStateModel = 0x30; // "RealmBattleStateModel"
            inline constexpr std::uintptr_t battleModel = 0x38; // "BattleModel"
            inline constexpr std::uintptr_t clanModel = 0x40; // "ClanModel"
            inline constexpr std::uintptr_t contextActionRules = 0x48; // "GeneralContextActionRules"
        }
        namespace Methods {
            inline constexpr std::uintptr_t GetButtonActive = 0x9497B0; // "private bool GetButtonActive(ContextMenuButtonType button)"
            inline constexpr std::uintptr_t GetIsPartyActive = 0x949C10; // "private bool GetIsPartyActive()"
            inline constexpr std::uintptr_t GetIsClanActive = 0x949AD0; // "private bool GetIsClanActive()"
            inline constexpr std::uintptr_t Update = 0x949E30; // "public void Update()"
        }
    } // namespace PlayerContextMenuUpdater

    namespace PlayerCrouchDitheringUpdater { // "Game.Battle.EntityModel.Player.PlayerCrouchDitheringUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t customizationView = 0x10; // "CharacterCustomizationView"
            inline constexpr std::uintptr_t crouchModel = 0x18; // "CharacterCrouchModel"
            inline constexpr std::uintptr_t rotationInput = 0x20; // "PlayerRotationInputModel"
            inline constexpr std::uintptr_t stateModel = 0x28; // "IBattleCharacterStateModel"
            inline constexpr std::uintptr_t playerCameraViewDescriptions = 0x30; // "PlayerCameraViewDescriptions"
            inline constexpr std::uintptr_t enableDithering = 0x38; // "Action<Material>"
            inline constexpr std::uintptr_t disableDithering = 0x40; // "Action<Material>"
            inline constexpr std::uintptr_t isDithering = 0x48; // "bool"
            inline constexpr std::uintptr_t alpha = 0x4C; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC4C1A0; // "public void Update()"
            inline constexpr std::uintptr_t GetAlpha = 0xC4C090; // "private float GetAlpha()"
            inline constexpr std::uintptr_t StopDithering = 0xC4C170; // "private void StopDithering()"
            inline constexpr std::uintptr_t EnableDithering = 0xC4BFF0; // "private void EnableDithering(Material material)"
            inline constexpr std::uintptr_t DisableDithering = 0xC4BF60; // "private static void DisableDithering(Material material)"
        }
    } // namespace PlayerCrouchDitheringUpdater

    namespace PlayerDepthOfFieldUpdater { // "Game.Battle.EntityModel.Player.PlayerDepthOfFieldUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t depthOfField = 0x10; // "DepthOfField"
            inline constexpr std::uintptr_t characterAimingModel = 0x18; // "CharacterAimingModel"
            inline constexpr std::uintptr_t weapon = 0x20; // "IWeaponModel"
            inline constexpr std::uintptr_t weaponViewDescriptions = 0x28; // "WeaponViewDescriptions"
            inline constexpr std::uintptr_t aimingModel = 0x30; // "AimingModel"
            inline constexpr std::uintptr_t aimModeModel = 0x38; // "IPrimitiveModel<AimModeDescription>"
            inline constexpr std::uintptr_t isInProcess = 0x40; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC4D370; // "public void Update()"
            inline constexpr std::uintptr_t UpdateAperture = 0xC4D2F0; // "private void UpdateAperture()"
        }
    } // namespace PlayerDepthOfFieldUpdater

    namespace PlayerEntityModel { // "Game.Battle.EntityModel.Player.PlayerEntityModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ClientModel = 0x18; // "PlayerClientModel"
            inline constexpr std::uintptr_t ServerModel = 0x20; // "BattleCharacterModel"
            inline constexpr std::uintptr_t PublicId = 0x28; // "long"
        }
    } // namespace PlayerEntityModel

    namespace PlayerEntityModelExtensions { // "Game.Battle.EntityModel.Player.PlayerEntityModelExtensions (Battle.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t GetMaxCashInInventory = 0xC4D7E0; // "public static int GetMaxCashInInventory(PlayerEntityModel player)"
        }
    } // namespace PlayerEntityModelExtensions

    namespace PlayerEntityModelUpdater { // "Game.Battle.EntityModel.Player.PlayerEntityModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t serverModel = 0x10; // "BattleCharacterModel"
            inline constexpr std::uintptr_t battleEntityDataModels = 0x18; // "IBattleEntityDataModels"
            inline constexpr std::uintptr_t updater = 0x20; // "IUpdater"
            inline constexpr std::uintptr_t idleUpdater = 0x28; // "IUpdater"
            inline constexpr std::uintptr_t inVehicleUpdater = 0x30; // "IUpdater"
            inline constexpr std::uintptr_t arrestingUpdater = 0x38; // "IUpdater"
            inline constexpr std::uintptr_t deathUpdater = 0x40; // "IUpdater"
            inline constexpr std::uintptr_t knockedOutUpdater = 0x48; // "IUpdater"
            inline constexpr std::uintptr_t knockedDownUpdater = 0x50; // "IUpdater"
            inline constexpr std::uintptr_t inPredictedVehicleUpdater = 0x58; // "IUpdater"
            inline constexpr std::uintptr_t inventoryUpdater = 0x60; // "IUpdater"
            inline constexpr std::uintptr_t hiddenUpdater = 0x68; // "IUpdater"
            inline constexpr std::uintptr_t beforeStatesUpdater = 0x70; // "IUpdater"
            inline constexpr std::uintptr_t marker = 0x78; // "ProfilerMarker"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC4DCF0; // "public void Update()"
        }
    } // namespace PlayerEntityModelUpdater

    namespace PlayerFakeSpreadModel { // "Game.Battle.Entities.Player.Spread.PlayerFakeSpreadModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Spread = 0x10; // "float"
            inline constexpr std::uintptr_t Air = 0x14; // "float"
            inline constexpr std::uintptr_t Move = 0x18; // "float"
        }
    } // namespace PlayerFakeSpreadModel

    namespace PlayerFakeSpreadModelUpdater { // "Game.Battle.Entities.Player.Spread.PlayerFakeSpreadModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t fakeSpreadModel = 0x10; // "PlayerFakeSpreadModel"
            inline constexpr std::uintptr_t weaponViewDescriptions = 0x18; // "WeaponViewDescriptions"
            inline constexpr std::uintptr_t characterFireModel = 0x20; // "CharacterFireModel"
            inline constexpr std::uintptr_t weaponModel = 0x28; // "IWeaponModel"
            inline constexpr std::uintptr_t controllerModel = 0x30; // "IPrimitiveModel<CharacterControllerStateDescription>"
            inline constexpr std::uintptr_t velocityModel = 0x38; // "CharacterRelativeVelocityModel"
            inline constexpr std::uintptr_t previousWeapon = 0x40; // "WeaponDescription"
            inline constexpr std::uintptr_t decayStartTs = 0x48; // "float"
            inline constexpr std::uintptr_t baseSpread = 0x4C; // "float"
            inline constexpr std::uintptr_t shotPulse = 0x50; // "float"
            inline constexpr std::uintptr_t shotPulseStartTime = 0x54; // "float"
            inline constexpr std::uintptr_t velocity = 0x58; // "float"
            inline constexpr std::uintptr_t targetSpread = 0x5C; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB1FF30; // "public void Update()"
            inline constexpr std::uintptr_t ResolveMove = 0xB1FA70; // "private void ResolveMove()"
            inline constexpr std::uintptr_t ResolveAir = 0xB1F810; // "private void ResolveAir()"
            inline constexpr std::uintptr_t ResolveSpread = 0xB1FBF0; // "private void ResolveSpread()"
            inline constexpr std::uintptr_t ResetSpread = 0xB1F7E0; // "private void ResetSpread()"
        }
    } // namespace PlayerFakeSpreadModelUpdater

    namespace PlayerFirstAidCabinetModel { // "Models.Models.PlayerFirstAidCabinet.PlayerFirstAidCabinetModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "FirstAidCabinetPlayerData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t HasFirstAidCabinets = 0x4928EF0; // "public bool HasFirstAidCabinets()"
            inline constexpr std::uintptr_t get_Data = 0x7EC6B0; // "public FirstAidCabinetPlayerData get_Data()"
        }
    } // namespace PlayerFirstAidCabinetModel

    namespace PlayerFollowCameraPositionUpdater { // "Game.Battle.EntityModel.Player.PlayerFollowCameraPositionUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t cameraFollow = 0x10; // "Transform"
            inline constexpr std::uintptr_t cameraModel = 0x18; // "PlayerCameraModel"
            inline constexpr std::uintptr_t state = 0x20; // "IBattleCharacterStateModel"
            inline constexpr std::uintptr_t oldState = 0x28; // "BattleCharacterState"
            inline constexpr std::uintptr_t oldPosition = 0x2C; // "Vector3"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC79120; // "public void Update()"
        }
    } // namespace PlayerFollowCameraPositionUpdater

    namespace PlayerHasActualDataUpdater { // "Game.Battle.Entities.Player.Updaters.PlayerHasActualDataUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dataTickModel = 0x10; // "IDataTickModel"
            inline constexpr std::uintptr_t timeModel = 0x18; // "TimeModel"
            inline constexpr std::uintptr_t playerClientModel = 0x20; // "PlayerClientModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB0D840; // "public void Update()"
        }
    } // namespace PlayerHasActualDataUpdater

    namespace PlayerHideObjectAnimationUpdater { // "Game.Battle.HideObject.PlayerHideObjectAnimationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleEntitiesModel = 0x10; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t location = 0x18; // "LocationDescription"
            inline constexpr std::uintptr_t locationHideObjectDescription = 0x20; // "LocationHideObjectDescription"
            inline constexpr std::uintptr_t view = 0x28; // "HideObjectView"
            inline constexpr std::uintptr_t isHidden = 0x30; // "bool"
            inline constexpr std::uintptr_t isInited = 0x31; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA974A0; // "public void Update()"
        }
    } // namespace PlayerHideObjectAnimationUpdater

    namespace PlayerHitClusterModel { // "Game.Battle.PlayerHitClusterModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t clusterDistanceSqr = 0x10; // "float"
            inline constexpr std::uintptr_t clusterDuration = 0x14; // "float"
            inline constexpr std::uintptr_t lastHitPosition = 0x18; // "Vector3"
            inline constexpr std::uintptr_t lastHitTime = 0x24; // "float"
            inline constexpr std::uintptr_t simplifyHitVfx = 0x28; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t ShouldSimplifyHitVfx = 0xB55130; // "public bool ShouldSimplifyHitVfx(Vector3 position, float time)"
        }
    } // namespace PlayerHitClusterModel

    namespace PlayerImmuneToCharacterPopupUpdater { // "Game.Battle.Entities.Player.Shoot.Updaters.PlayerImmuneToCharacterPopupUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t serverModel = 0x10; // "BattleCharacterModel"
            inline constexpr std::uintptr_t immuneModel = 0x18; // "ClientImmunePopupModel"
            inline constexpr std::uintptr_t popupDamageModel = 0x20; // "PopupDamageModel"
            inline constexpr std::uintptr_t cameraModel = 0x28; // "BattleCameraModel"
            inline constexpr std::uintptr_t now = 0x30; // "INow"
            inline constexpr std::uintptr_t partyModel = 0x38; // "PartyModel"
            inline constexpr std::uintptr_t clanModel = 0x40; // "ClanBattleTeamsCacheModel"
            inline constexpr std::uintptr_t slotsModel = 0x48; // "ClientCharacterSlotsModel"
            inline constexpr std::uintptr_t delayShowImmunePopups = 0x50; // "Dictionary<BattleCharacterModel, long>"
            inline constexpr std::uintptr_t removed = 0x58; // "HashSet<BattleCharacterModel>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB203D0; // "public void Update()"
            inline constexpr std::uintptr_t CanSetDamage = 0xB200D0; // "private bool CanSetDamage(BattleCharacterModel target, ClientImmunePopupModel.DamageType type)"
        }
    } // namespace PlayerImmuneToCharacterPopupUpdater

    namespace PlayerInfoReporter { // "Game.ClientBuildInspector.PlayerInfoReporter (Game.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t game = 0x10; // "Game"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Title = 0x10DD310; // "public string get_Title()"
            inline constexpr std::uintptr_t Report = 0x10DD000; // "public void Report(StringBuilder report)"
        }
    } // namespace PlayerInfoReporter

    namespace PlayerInsideFlagZoneModelUpdater { // "Game.Battle.ClanBattle.PlayerInsideFlagZoneModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleEntitiesModel = 0x10; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t location = 0x18; // "LocationDescription"
            inline constexpr std::uintptr_t clanBattleModel = 0x20; // "ClanBattleModel"
            inline constexpr std::uintptr_t conquestObjectDescription = 0x28; // "LocationClanBattleConquestObjectDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xD1F2C0; // "public void Update()"
        }
    } // namespace PlayerInsideFlagZoneModelUpdater

    namespace PlayerLeaveBattleReasonDescription { // "Models.References.PlayerLeaveBattleReasonDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x8170E48; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t BorderExit = 0x0; // "PlayerLeaveBattleReasonDescription"
            inline constexpr std::uintptr_t PersonalTimerDisconnect = 0x8; // "PlayerLeaveBattleReasonDescription"
            inline constexpr std::uintptr_t GlobalTimerDisconnect = 0x10; // "PlayerLeaveBattleReasonDescription"
            inline constexpr std::uintptr_t TimeoutDisconnect = 0x18; // "PlayerLeaveBattleReasonDescription"
            inline constexpr std::uintptr_t RealmLifeTimeEnd = 0x20; // "PlayerLeaveBattleReasonDescription"
            inline constexpr std::uintptr_t ForceExitToJoinClanBattle = 0x28; // "PlayerLeaveBattleReasonDescription"
            inline constexpr std::uintptr_t ForceExitToJoinShooter = 0x30; // "PlayerLeaveBattleReasonDescription"
            inline constexpr std::uintptr_t ForceExitToJoinHub = 0x38; // "PlayerLeaveBattleReasonDescription"
            inline constexpr std::uintptr_t ForceExitToLeaveRealm = 0x40; // "PlayerLeaveBattleReasonDescription"
            inline constexpr std::uintptr_t LeaveOnRespawn = 0x48; // "PlayerLeaveBattleReasonDescription"
            inline constexpr std::uintptr_t Arrest = 0x50; // "PlayerLeaveBattleReasonDescription"
            inline constexpr std::uintptr_t Bribe = 0x58; // "PlayerLeaveBattleReasonDescription"
            inline constexpr std::uintptr_t Death = 0x60; // "PlayerLeaveBattleReasonDescription"
            inline constexpr std::uintptr_t ClanRankChanged = 0x68; // "PlayerLeaveBattleReasonDescription"
            inline constexpr std::uintptr_t WrongClanInClanBattle = 0x70; // "PlayerLeaveBattleReasonDescription"
            inline constexpr std::uintptr_t KickFromClanBattle = 0x78; // "PlayerLeaveBattleReasonDescription"
            inline constexpr std::uintptr_t ClanBattleFinish = 0x80; // "PlayerLeaveBattleReasonDescription"
            inline constexpr std::uintptr_t ExitClanBattlePreparation = 0x88; // "PlayerLeaveBattleReasonDescription"
            inline constexpr std::uintptr_t MainMenuExitByUser = 0x90; // "PlayerLeaveBattleReasonDescription"
            inline constexpr std::uintptr_t MainMenuExitByAfk = 0x98; // "PlayerLeaveBattleReasonDescription"
            inline constexpr std::uintptr_t CheatExit = 0xA0; // "PlayerLeaveBattleReasonDescription"
            inline constexpr std::uintptr_t RemoveBot = 0xA8; // "PlayerLeaveBattleReasonDescription"
            inline constexpr std::uintptr_t Ban = 0xB0; // "PlayerLeaveBattleReasonDescription"
            inline constexpr std::uintptr_t SecurityViolation = 0xB8; // "PlayerLeaveBattleReasonDescription"
        }
    } // namespace PlayerLeaveBattleReasonDescription

    namespace PlayerLogsUpdater { // "Game.Battle.Logs.PlayerLogsUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleEntitiesModel = 0x10; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t state = 0x18; // "Nullable<BattleCharacterState>"
            inline constexpr std::uintptr_t role = 0x20; // "PlayerRoleDescription"
            inline constexpr std::uintptr_t item = 0x28; // "InventoryItemDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x9C1500; // "public void Update()"
            inline constexpr std::uintptr_t UpdateState = 0x9C1170; // "private void UpdateState(BattleCharacterState state)"
            inline constexpr std::uintptr_t UpdateRole = 0x9C0E80; // "private void UpdateRole(PlayerRoleDescription role)"
            inline constexpr std::uintptr_t UpdateItemInHands = 0x9C0B40; // "private void UpdateItemInHands(ItemInHandsModel itemInHandsModel)"
        }
    } // namespace PlayerLogsUpdater

    namespace PlayerLogUpdater { // "Game.Global.Logs.PlayerLogUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t authorizationInfo = 0x10; // "AuthorizationInfo"
            inline constexpr std::uintptr_t publicIdModel = 0x18; // "PublicIdModel"
            inline constexpr std::uintptr_t privateId = 0x20; // "string"
            inline constexpr std::uintptr_t nickname = 0x28; // "string"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x35A6660; // "public void Update()"
        }
    } // namespace PlayerLogUpdater

    namespace PlayerLookRotationUpdater { // "Game.Battle.EntityModel.Player.Rotation.PlayerLookRotationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t rotation = 0x10; // "CharacterRotationModel"
            inline constexpr std::uintptr_t rotationInputModel = 0x18; // "PlayerRotationInputModel"
            inline constexpr std::uintptr_t battleStance = 0x20; // "BattleStanceModel"
            inline constexpr std::uintptr_t skeletonDeformationDescription = 0x28; // "BattleCharacterSkeletonDeformationConfig"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC798F0; // "public void Update()"
        }
    } // namespace PlayerLookRotationUpdater

    namespace PlayerMapMarkModel { // "Models.Models.PlayerMapMark.PlayerMapMarkModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t hasMark = 0x10; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t x = 0x18; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t y = 0x20; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t z = 0x28; // "IPrimitiveData<float>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_HasMark = 0x4929170; // "public bool get_HasMark()"
            inline constexpr std::uintptr_t get_X = 0x49291C0; // "public float get_X()"
            inline constexpr std::uintptr_t get_Y = 0x4929210; // "public float get_Y()"
            inline constexpr std::uintptr_t get_Z = 0x4929260; // "public float get_Z()"
            inline constexpr std::uintptr_t Set = 0x4929110; // "public void Set(float x, float y, float z)"
            inline constexpr std::uintptr_t Unset = 0x4929140; // "public void Unset()"
            inline constexpr std::uintptr_t Set_2 = 0x4929060; // "private void Set(bool hasMark, float x, float y, float z)"
        }
    } // namespace PlayerMapMarkModel

    namespace PlayerMemberBattleDataModel { // "Game.Global.Party.PlayerMemberBattleDataModel (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleCharacterModel = 0x10; // "BattleCharacterModel"
            inline constexpr std::uintptr_t playerBattleModel = 0x18; // "PlayerBattleModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_ReadyCheckBecomeRobberStatusDescription = 0x3578760; // "public PartyReadyCheckStatusDescription get_ReadyCheckBecomeRobberStatusDescription()"
            inline constexpr std::uintptr_t get_EntityId = 0x3578000; // "public long get_EntityId()"
            inline constexpr std::uintptr_t get_Health = 0x35781F0; // "public int get_Health()"
            inline constexpr std::uintptr_t get_Armor = 0x3577F00; // "public int get_Armor()"
            inline constexpr std::uintptr_t get_Role = 0x35787F0; // "public PlayerRoleDescription get_Role()"
            inline constexpr std::uintptr_t get_EquipArmorItem = 0x3578020; // "public InventoryItemDescription get_EquipArmorItem()"
            inline constexpr std::uintptr_t get_HideObjectEntityId = 0x3578230; // "public int get_HideObjectEntityId()"
            inline constexpr std::uintptr_t get_ArrestTs = 0x3577F70; // "public long get_ArrestTs()"
            inline constexpr std::uintptr_t get_ArrestStateDescription = 0x3577F40; // "public ArrestStateDescription get_ArrestStateDescription()"
            inline constexpr std::uintptr_t get_InterruptArrestingTs = 0x3578310; // "public long get_InterruptArrestingTs()"
            inline constexpr std::uintptr_t get_KnockoutEndTs = 0x3578400; // "public long get_KnockoutEndTs()"
            inline constexpr std::uintptr_t get_KnockoutPhase = 0x3578430; // "public KnockoutPhaseDescription get_KnockoutPhase()"
            inline constexpr std::uintptr_t get_ReviveEndTs = 0x35787C0; // "public long get_ReviveEndTs()"
            inline constexpr std::uintptr_t get_IsInVehicle = 0xC80E80; // "public bool get_IsInVehicle()"
            inline constexpr std::uintptr_t get_InVehicleEntityId = 0x35782E0; // "public int get_InVehicleEntityId()"
            inline constexpr std::uintptr_t get_HasMark = 0x35781B0; // "public bool get_HasMark()"
            inline constexpr std::uintptr_t get_IsCopRewardBoxEmpty = 0x3578340; // "public bool get_IsCopRewardBoxEmpty()"
            inline constexpr std::uintptr_t get_Mark = 0x3578540; // "public Vector3 get_Mark()"
            inline constexpr std::uintptr_t get_PingMark = 0x3578690; // "public Vector3 get_PingMark()"
            inline constexpr std::uintptr_t get_PingMarkType = 0x3578650; // "public PingMarkTypeDescription get_PingMarkType()"
            inline constexpr std::uintptr_t get_PingMarkTs = 0x3578610; // "public long get_PingMarkTs()"
            inline constexpr std::uintptr_t get_CharacterControllerState = 0x3577FA0; // "public CharacterControllerStateDescription get_CharacterControllerState()"
            inline constexpr std::uintptr_t get_IsSurrendering = 0x35783D0; // "public bool get_IsSurrendering()"
            inline constexpr std::uintptr_t get_IsImmunity = 0x35783A0; // "public bool get_IsImmunity()"
            inline constexpr std::uintptr_t get_ImmuneEndTs = 0x35782B0; // "public long get_ImmuneEndTs()"
            inline constexpr std::uintptr_t get_HoldingCellReleaseTs = 0x3578270; // "public long get_HoldingCellReleaseTs()"
        }
    } // namespace PlayerMemberBattleDataModel

    namespace PlayerMovementInputModel { // "Game.Battle.EntityModel.Player.PlayerMovementInputModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Move = 0x10; // "Vector2"
        }
    } // namespace PlayerMovementInputModel

    namespace PlayerMovementIntentionDirectionUpdater { // "Game.Battle.EntityModel.Player.Movement.PlayerMovementIntentionDirectionUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t movementInput = 0x10; // "PlayerMovementInputModel"
            inline constexpr std::uintptr_t rotationInput = 0x18; // "PlayerRotationInputModel"
            inline constexpr std::uintptr_t characterRotation = 0x20; // "CharacterRotationModel"
            inline constexpr std::uintptr_t movementIntentionDirection = 0x28; // "CharacterMovementIntentionDirectionModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC79A20; // "public void Update()"
        }
    } // namespace PlayerMovementIntentionDirectionUpdater

    namespace PlayerMovementInterpolationUpdater { // "Game.Battle.EntityModel.Player.Movement.PlayerMovementInterpolationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t movementTimeline = 0x10; // "MovementTimeline"
            inline constexpr std::uintptr_t transform = 0x18; // "ITransformModel"
            inline constexpr std::uintptr_t setMovement = 0x20; // "SetMovementModel"
            inline constexpr std::uintptr_t time = 0x28; // "TimeModel"
            inline constexpr std::uintptr_t tickIndex = 0x30; // "long"
            inline constexpr std::uintptr_t oldTs = 0x38; // "long"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC79C20; // "public void Update()"
        }
    } // namespace PlayerMovementInterpolationUpdater

    namespace PlayerObserverModel { // "Models.Models.PlayerObserver.PlayerObserverModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Id = 0x10; // "int"
            inline constexpr std::uintptr_t Position = 0x18; // "PositionNoReplicationModel"
            inline constexpr std::uintptr_t SetPositionRequest = 0x20; // "RequestModel<ValueTuple<float, float, float>>"
            inline constexpr std::uintptr_t AoiModel = 0x28; // "EntityAoiModel"
        }
    } // namespace PlayerObserverModel

    namespace PlayerPartyData { // "Models.Data.Party.PlayerPartyData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t InParty = 0x20; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t Party = 0x28; // "BattlePartyData"
            inline constexpr std::uintptr_t Members = 0x30; // "BattlePartyMembersData"
        }
    } // namespace PlayerPartyData

    namespace PlayerPartyDataBuilder { // "Models.Models.PlayerPartyDataBuilder.PlayerPartyDataBuilder (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t locationBoundsModel = 0x10; // "LocationBoundsModel"
            inline constexpr std::uintptr_t locationDescription = 0x18; // "LocationDescription"
            inline constexpr std::uintptr_t enum_id = 0x20; // "ReadOnlyEnum<PartyMemberSlotDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t BuildEnum = 0x49294C0; // "private static ReadOnlyEnum<PartyMemberSlotDescription> BuildEnum()"
            inline constexpr std::uintptr_t BuildPartyData = 0x4929620; // "public PlayerPartyData BuildPartyData(int playerEntityId, BattlePartyData partyData, IEnumerable<int> partyMembers, IDictionary<int, BattleCharacterData> charactersData, IDictionary<int, PlayerBattleData> playersData, WorldEntitiesModel worldEntitiesModel)"
            inline constexpr std::uintptr_t BuildSingleMemberPartyData = 0x49299F0; // "public PlayerPartyData BuildSingleMemberPartyData(BattlePartyData partyData)"
            inline constexpr std::uintptr_t BuildNoPartyData = 0x49293B0; // "public PlayerPartyData BuildNoPartyData()"
            inline constexpr std::uintptr_t BuildClientData = 0x49293B0; // "public PlayerPartyData BuildClientData()"
            inline constexpr std::uintptr_t BuildTransformData = 0x4929AE0; // "private ValueTuple<IPrimitiveData<int>, IPrimitiveData<int>, IPrimitiveData<int>, IPrimitiveData<int>> BuildTransformData()"
        }
    } // namespace PlayerPartyDataBuilder

    namespace PlayerPingMarkModel { // "Models.Models.PlayerPingMark.PlayerPingMarkModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t x = 0x10; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t y = 0x18; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t z = 0x20; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t ts = 0x28; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t type = 0x30; // "IPrimitiveData<PingMarkTypeDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_X = 0x492A1E0; // "public float get_X()"
            inline constexpr std::uintptr_t get_Y = 0x492A230; // "public float get_Y()"
            inline constexpr std::uintptr_t get_Z = 0x492A280; // "public float get_Z()"
            inline constexpr std::uintptr_t get_Ts = 0x492A0D0; // "public long get_Ts()"
            inline constexpr std::uintptr_t get_Type = 0x492A120; // "public PingMarkTypeDescription get_Type()"
            inline constexpr std::uintptr_t Set = 0x492A000; // "public void Set(PingMarkTypeDescription type, long ts, float x, float y, float z)"
        }
    } // namespace PlayerPingMarkModel

    namespace PlayerPrefsData { // "Game.Global.PlayerPrefsFile.PlayerPrefsData (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t PresentationData = 0x20; // "PlayerPrefsPresentationData"
            inline constexpr std::uintptr_t ReputationData = 0x28; // "ReputationPrefsData"
            inline constexpr std::uintptr_t TaxCollectionPrefsData = 0x30; // "TaxCollectionPrefsData"
            inline constexpr std::uintptr_t ShowClanBattleEnter = 0x38; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t ClanRequestsLastVisitTs = 0x40; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t ClanTag = 0x48; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t EarlyBuildMenuPopup = 0x50; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t RefreshCollectionPopup = 0x58; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t MoveBuilderSlotWithLootWithoutConfirmation = 0x60; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t BuyCargoFromCargoSellerWithoutConfirmationDialog = 0x68; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t DropItemAwayFromInventoryWithoutConfirmationDialog = 0x70; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t SwitchPaidCopPresetWithoutConfirmation = 0x78; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t FinishCopJobWithoutConfirmation = 0x80; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t FinishPartyCopJobWithoutConfirmation = 0x88; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t SkipConfiscationRealmPopup = 0x90; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t LastShowConfiscationRealmPopupTs = 0x98; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t LastShowConfiscationNotificationTs = 0xA0; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t ConfiscationLastRealmId = 0xA8; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t LastRealmResidenceTs = 0xB0; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t ClanAppointmentsClickTs = 0xB8; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t ClanProtectionClickTs = 0xC0; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t RealmId = 0xC8; // "IntData"
            inline constexpr std::uintptr_t ClanRealmSectors = 0xD0; // "DictionaryData<int, IPrimitiveData<string>>"
            inline constexpr std::uintptr_t RealmSettlements = 0xD8; // "DictionaryData<int, SetData<int>>"
            inline constexpr std::uintptr_t LastRealmCameraDistance = 0xE0; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t LastRealmCameraX = 0xE8; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t LastRealmCameraZ = 0xF0; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t IsObjectivesPanelVisible = 0xF8; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t VendorNewlyUnlockedItems = 0x100; // "SetData<string>"
            inline constexpr std::uintptr_t VendorTreeNotifiedImprisonmentYears = 0x108; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t VendorTreeNewNodes = 0x110; // "SetData<string>"
            inline constexpr std::uintptr_t RevealedAchievementStickers = 0x118; // "SetData<string>"
            inline constexpr std::uintptr_t RevealContainers = 0x120; // "ListData<RevealContainerPrefsData>"
            inline constexpr std::uintptr_t UnlockedSkinsData = 0x128; // "UnlockedSkinsData"
            inline constexpr std::uintptr_t CreationTs = 0x130; // "PrimitiveData<long>"
        }
    } // namespace PlayerPrefsData

    namespace PlayerPrefsModel { // "Game.Global.PlayerPrefsFile.PlayerPrefsModel (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t UnlockedSkinsPrefsModel = 0x30; // "UnlockedSkinsPrefsModel"
            inline constexpr std::uintptr_t InitialResetCheckWasPerformed = 0x38; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Deserialize = 0x379DEA0; // "public bool Deserialize(IValue value)"
            inline constexpr std::uintptr_t Serialize = 0x29028F0; // "public IValue Serialize()"
            inline constexpr std::uintptr_t get_DebugName = 0x37A0000; // "public string get_DebugName()"
            inline constexpr std::uintptr_t HasRealm = 0x379E270; // "public bool HasRealm(int realmId)"
            inline constexpr std::uintptr_t SetRealm = 0x379F400; // "public void SetRealm(int realmId)"
            inline constexpr std::uintptr_t ClearPerRealmPrefs = 0x379DD20; // "public void ClearPerRealmPrefs()"
            inline constexpr std::uintptr_t SetSkipShowClanBattleEnter = 0x379F4D0; // "public void SetSkipShowClanBattleEnter(bool skip)"
            inline constexpr std::uintptr_t get_NeedShowClanBattleEnter = 0x37A0260; // "public bool get_NeedShowClanBattleEnter()"
            inline constexpr std::uintptr_t get_ClanRequestsClickTs = 0x379FF50; // "public long get_ClanRequestsClickTs()"
            inline constexpr std::uintptr_t set_ClanRequestsClickTs = 0x37A0460; // "public void set_ClanRequestsClickTs(long value)"
            inline constexpr std::uintptr_t get_LastClanTag = 0x37A0150; // "public string get_LastClanTag()"
            inline constexpr std::uintptr_t set_LastClanTag = 0x37A05B0; // "public void set_LastClanTag(string value)"
            inline constexpr std::uintptr_t get_IsNeedShowEarlyBuildMenuPopup = 0x37A0090; // "public bool get_IsNeedShowEarlyBuildMenuPopup()"
            inline constexpr std::uintptr_t get_RevealContainers = 0x37A02C0; // "public ListData<RevealContainerPrefsData> get_RevealContainers()"
            inline constexpr std::uintptr_t SetEarlyBuildMenuPopupShown = 0x379F160; // "public void SetEarlyBuildMenuPopupShown()"
            inline constexpr std::uintptr_t IsConfirmationAccepted = 0x379E540; // "public bool IsConfirmationAccepted(PlayerPrefsConfirmationFlag flag)"
            inline constexpr std::uintptr_t AcceptConfirmation = 0x379DA90; // "public void AcceptConfirmation(PlayerPrefsConfirmationFlag flag)"
            inline constexpr std::uintptr_t SetSkipConfiscationPopup = 0x379F460; // "public void SetSkipConfiscationPopup(bool skip)"
            inline constexpr std::uintptr_t get_CanShowConfiscationPopup = 0x379FE30; // "public bool get_CanShowConfiscationPopup()"
            inline constexpr std::uintptr_t get_LastShowConfiscationPopupTime = 0x37A0200; // "public long get_LastShowConfiscationPopupTime()"
            inline constexpr std::uintptr_t set_LastShowConfiscationPopupTime = 0x37A0690; // "public void set_LastShowConfiscationPopupTime(long value)"
            inline constexpr std::uintptr_t get_LastShowConfiscationNotificationTime = 0x37A01A0; // "public long get_LastShowConfiscationNotificationTime()"
            inline constexpr std::uintptr_t set_LastShowConfiscationNotificationTime = 0x37A0620; // "public void set_LastShowConfiscationNotificationTime(long value)"
            inline constexpr std::uintptr_t get_ConfiscationLastRealmId = 0x379FFA0; // "public int get_ConfiscationLastRealmId()"
            inline constexpr std::uintptr_t set_ConfiscationLastRealmId = 0x37A04D0; // "public void set_ConfiscationLastRealmId(int value)"
            inline constexpr std::uintptr_t get_IsObjectivesPanelVisible = 0x37A00F0; // "public bool get_IsObjectivesPanelVisible()"
            inline constexpr std::uintptr_t set_IsObjectivesPanelVisible = 0x37A0540; // "public void set_IsObjectivesPanelVisible(bool value)"
            inline constexpr std::uintptr_t SetLastRealmResidenceTime = 0x379F290; // "public void SetLastRealmResidenceTime(long time)"
            inline constexpr std::uintptr_t GetLastRealmCameraDistance = 0x379E0A0; // "public float GetLastRealmCameraDistance(float defaultDistance)"
            inline constexpr std::uintptr_t GetLastRealmCameraPosition = 0x379E140; // "public Vector3 GetLastRealmCameraPosition(Vector3 defaultPosition)"
            inline constexpr std::uintptr_t SetLastRealmCamera = 0x379F1C0; // "public void SetLastRealmCamera(float distance, Vector3 position)"
            inline constexpr std::uintptr_t HasSeenRealmSector = 0x379E3A0; // "public bool HasSeenRealmSector(SectorDescription sectorDescription)"
            inline constexpr std::uintptr_t HasSeenRealmSectorClan = 0x379E2D0; // "public bool HasSeenRealmSectorClan(SectorDescription sectorDescription, string clanId)"
            inline constexpr std::uintptr_t SetRealmSectorClan = 0x379F300; // "public void SetRealmSectorClan(SectorDescription sectorDescription, string clanId)"
            inline constexpr std::uintptr_t RemoveRealmSector = 0x379EEB0; // "public void RemoveRealmSector(SectorDescription sectorDescription)"
            inline constexpr std::uintptr_t HasSeenRealmSettlement = 0x379E420; // "public bool HasSeenRealmSettlement(SectorDescription sectorDescription, SettlementDescription settlementDescription)"
            inline constexpr std::uintptr_t AddRealmSettlement = 0x379DB60; // "public void AddRealmSettlement(SectorDescription sectorDescription, SettlementDescription settlementDescription)"
            inline constexpr std::uintptr_t RemoveRealmSettlement = 0x379EF50; // "public void RemoveRealmSettlement(SectorDescription sectorDescription, SettlementDescription settlementDescription)"
            inline constexpr std::uintptr_t TryMarkPresentedCar = 0x379F5F0; // "public bool TryMarkPresentedCar(CarSlotDescription description)"
            inline constexpr std::uintptr_t TryMarkPresentedHelicopter = 0x379F790; // "public bool TryMarkPresentedHelicopter(HelicopterSlotDescription description)"
            inline constexpr std::uintptr_t TryMarkPresentedMainBuilding = 0x379F930; // "public bool TryMarkPresentedMainBuilding(MainBuildingDescription description)"
            inline constexpr std::uintptr_t TryMarkPresentedOutbuilding = 0x379FA00; // "public bool TryMarkPresentedOutbuilding(OutbuildingDescription description)"
            inline constexpr std::uintptr_t TryMarkPresentedCompoundWall = 0x379F6C0; // "public bool TryMarkPresentedCompoundWall(CompoundWallDescription description)"
            inline constexpr std::uintptr_t TryMarkPresentedLocations = 0x379F860; // "public bool TryMarkPresentedLocations(LocationDescription description)"
            inline constexpr std::uintptr_t ShouldLoadLocationPresentation = 0x379F540; // "public bool ShouldLoadLocationPresentation(LocationDescription description)"
            inline constexpr std::uintptr_t NeedPresentLocation = 0x379EE20; // "public bool NeedPresentLocation(LocationDescription description)"
            inline constexpr std::uintptr_t MarkReputationItemSeen = 0x379EA10; // "public void MarkReputationItemSeen(ImprisonmentAwardItemDescription description)"
            inline constexpr std::uintptr_t get_ClanAppointmentClickTs = 0x379FE90; // "public long get_ClanAppointmentClickTs()"
            inline constexpr std::uintptr_t set_ClanAppointmentClickTs = 0x37A0380; // "public void set_ClanAppointmentClickTs(long value)"
            inline constexpr std::uintptr_t get_ClanProtectionClickTs = 0x379FEF0; // "public long get_ClanProtectionClickTs()"
            inline constexpr std::uintptr_t set_ClanProtectionClickTs = 0x37A03F0; // "public void set_ClanProtectionClickTs(long value)"
            inline constexpr std::uintptr_t IsNewReputationItem = 0x379E5A0; // "public bool IsNewReputationItem(ImprisonmentAwardItemDescription description)"
            inline constexpr std::uintptr_t GetConfirmationFlag = 0x379DF30; // "private IPrimitiveData<bool> GetConfirmationFlag(PlayerPrefsConfirmationFlag flag)"
            inline constexpr std::uintptr_t AddVendorNewlyUnlockedItems = 0x379DC60; // "public void AddVendorNewlyUnlockedItems(string vendorItem)"
            inline constexpr std::uintptr_t RemoveVendorNewlyUnlockedItems = 0x379F000; // "public void RemoveVendorNewlyUnlockedItems(string vendorItem)"
            inline constexpr std::uintptr_t get_VendorNewlyUnlockedItems = 0x37A0300; // "public IEnumerable<string> get_VendorNewlyUnlockedItems()"
            inline constexpr std::uintptr_t get_VendorTreeNotifiedImprisonmentYears = 0x37A0320; // "public int get_VendorTreeNotifiedImprisonmentYears()"
            inline constexpr std::uintptr_t set_VendorTreeNotifiedImprisonmentYears = 0x37A0700; // "public void set_VendorTreeNotifiedImprisonmentYears(int value)"
            inline constexpr std::uintptr_t AddVendorTreeNewNode = 0x379DCC0; // "public void AddVendorTreeNewNode(string nodeId)"
            inline constexpr std::uintptr_t IsVendorTreeNodeNew = 0x379E9B0; // "public bool IsVendorTreeNodeNew(string nodeId)"
            inline constexpr std::uintptr_t get_HasVendorTreeNewNodes = 0x37A0030; // "public bool get_HasVendorTreeNewNodes()"
            inline constexpr std::uintptr_t RemoveVendorTreeNewNode = 0x379F060; // "public void RemoveVendorTreeNewNode(string nodeId)"
            inline constexpr std::uintptr_t AddAchievementStickerRevealed = 0x379DB00; // "public void AddAchievementStickerRevealed(string key)"
            inline constexpr std::uintptr_t IsAchievementStickerRevealed = 0x379E4E0; // "public bool IsAchievementStickerRevealed(string key)"
            inline constexpr std::uintptr_t TryResetByCreationTs = 0x379FB40; // "public void TryResetByCreationTs(long creationTs)"
            inline constexpr std::uintptr_t TryMarkPresented = 0x379FAD0; // "private static bool TryMarkPresented(IPrimitiveData<bool> presented)"
            inline constexpr std::uintptr_t Reset = 0x379F0C0; // "private void Reset()"
            inline constexpr std::uintptr_t get_TaxCollectionPrefsData = 0x37A02E0; // "public TaxCollectionPrefsData get_TaxCollectionPrefsData()"
        }
    } // namespace PlayerPrefsModel

    namespace PlayerPrefsPresentationData { // "Game.Global.PlayerPrefsFile.PlayerPrefsPresentationData (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t PresentedCars = 0x20; // "ReferenceMapData<CarSlotDescription, IPrimitiveData<bool>>"
            inline constexpr std::uintptr_t PresentedHelicopters = 0x28; // "ReferenceMapData<HelicopterSlotDescription, IPrimitiveData<bool>>"
            inline constexpr std::uintptr_t PresentedMainBuildings = 0x30; // "ReferenceMapData<MainBuildingDescription, IPrimitiveData<bool>>"
            inline constexpr std::uintptr_t PresentedOutbuildings = 0x38; // "ReferenceMapData<OutbuildingDescription, IPrimitiveData<bool>>"
            inline constexpr std::uintptr_t PresentedCompoundWalls = 0x40; // "ReferenceMapData<CompoundWallDescription, IPrimitiveData<bool>>"
            inline constexpr std::uintptr_t PresentedLocations = 0x48; // "ReferenceMapData<LocationDescription, IPrimitiveData<bool>>"
        }
    } // namespace PlayerPrefsPresentationData

    namespace PlayerPrefsRealmStateUpdater { // "Game.Global.PlayerPrefsFile.PlayerPrefsRealmStateUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t regionUserModel = 0x10; // "RegionUserModel"
            inline constexpr std::uintptr_t playerPrefsModel = 0x18; // "PlayerPrefsModel"
            inline constexpr std::uintptr_t playerPrefsSerialized = 0x20; // "ISerializedModel"
            inline constexpr std::uintptr_t isRealmLoaded = 0x28; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x37A10A0; // "public void Update()"
        }
    } // namespace PlayerPrefsRealmStateUpdater

    namespace PlayerPreloadEquippedItemsUpdater { // "Game.Battle.Entities.Player.Updaters.PlayerPreloadEquippedItemsUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t scopesLoadingModel = 0x10; // "ScopesLoadingModel"
            inline constexpr std::uintptr_t equipSlotsModel = 0x18; // "IEquipSlotsModel"
            inline constexpr std::uintptr_t weaponSkinsModel = 0x20; // "WeaponSkinsModel"
            inline constexpr std::uintptr_t skinViewDescriptions = 0x28; // "BattleWeaponSkinViewDescriptions"
            inline constexpr std::uintptr_t weapon0 = 0x30; // "BattleWeaponSkinModificationDescription"
            inline constexpr std::uintptr_t weapon1 = 0x38; // "BattleWeaponSkinModificationDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB0E7C0; // "public void Update()"
            inline constexpr std::uintptr_t ResolveWeapon = 0xB0E430; // "private void ResolveWeapon(EquipSlotDescription equipSlotDescription, ref BattleWeaponSkinModificationDescription currentSkin)"
            inline constexpr std::uintptr_t GetWeapon = 0xB0E0A0; // "private BattleWeaponSkinModificationDescription GetWeapon(EquipSlotDescription equipSlot)"
            inline constexpr std::uintptr_t Load = 0xB0E2F0; // "private void Load(BattleWeaponSkinModificationDescription skin)"
            inline constexpr std::uintptr_t Unload = 0xB0E730; // "private void Unload(BattleWeaponSkinModificationDescription skin)"
        }
    } // namespace PlayerPreloadEquippedItemsUpdater

    namespace PlayerRegenerationBarUpdater { // "Game.Battle.Entities.Player.Updaters.PlayerRegenerationBarUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleEntitiesModel = 0x10; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t now = 0x18; // "INow"
            inline constexpr std::uintptr_t view = 0x20; // "RegenerationBarView"
            inline constexpr std::uintptr_t healEffectModel = 0x28; // "TimeEffectModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB0E9B0; // "public void Update()"
        }
    } // namespace PlayerRegenerationBarUpdater

    namespace PlayerReloadingModelUpdater { // "Game.Battle.EntityModel.Player.Reload.PlayerReloadingModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t weaponReload = 0x10; // "WeaponReloadModel"
            inline constexpr std::uintptr_t reloadParamsModel = 0x18; // "ReloadParamsModel"
            inline constexpr std::uintptr_t reloadingModel = 0x20; // "CharacterReloadingModel"
            inline constexpr std::uintptr_t stateModel = 0x28; // "IBattleCharacterStateModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC7A360; // "public void Update()"
        }
    } // namespace PlayerReloadingModelUpdater

    namespace PlayerRoleDescription { // "Models.References.Battle.PlayerRoleDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t DropLootOnDeath = 0x20; // "bool"
            inline constexpr std::uintptr_t BreakItemsOnDeath = 0x21; // "bool"
            inline constexpr std::uintptr_t DiesOnLeave = 0x22; // "bool"
            inline constexpr std::uintptr_t DiesOnBattleStopByPlayersCount = 0x23; // "bool"
            inline constexpr std::uintptr_t CanTakeItemInHands = 0x24; // "bool"
            inline constexpr std::uintptr_t CanDealDamage = 0x25; // "bool"
            inline constexpr std::uintptr_t CanLootEntities = 0x26; // "bool"
            inline constexpr std::uintptr_t CanTakeCharacterLoot = 0x27; // "bool"
            inline constexpr std::uintptr_t CanTakeVehicleLoot = 0x28; // "bool"
            inline constexpr std::uintptr_t CanUseTrader = 0x29; // "bool"
            inline constexpr std::uintptr_t CanBreakColliders = 0x2A; // "bool"
            inline constexpr std::uintptr_t CanUnlock = 0x2B; // "bool"
            inline constexpr std::uintptr_t OwnedVehicleTrunkBreachAvailable = 0x2C; // "bool"
            inline constexpr std::uintptr_t UseSpecialVehicle = 0x2D; // "bool"
            inline constexpr std::uintptr_t SpecialVehicleGroupType = 0x2E; // "VehicleGroupType"
            inline constexpr std::uintptr_t CanArrestLoot = 0x2F; // "bool"
            inline constexpr std::uintptr_t RestoreHealthMax = 0x30; // "float"
            inline constexpr std::uintptr_t RestoreHealthDelay = 0x38; // "long"
            inline constexpr std::uintptr_t RestoreHealthPeriod = 0x40; // "long"
            inline constexpr std::uintptr_t RestoreHealthAmount = 0x48; // "int"
            inline constexpr std::uintptr_t CanChangeInventory = 0x4C; // "bool"
            inline constexpr std::uintptr_t CanUseItemsInInventory = 0x4D; // "bool"
            inline constexpr std::uintptr_t CanVisibleSecurityAlarmMarkers = 0x4E; // "bool"
            inline constexpr std::uintptr_t TakesDamageThroughArmor = 0x4F; // "bool"
            inline constexpr std::uintptr_t CanUseHeal = 0x50; // "bool"
            inline constexpr std::uintptr_t CanUseEquippedItemsFromInventory = 0x51; // "bool"
            inline constexpr std::uintptr_t CanRespawn = 0x52; // "bool"
            inline constexpr std::uintptr_t NeedAutoRespawn = 0x53; // "bool"
            inline constexpr std::uintptr_t NicknameSameRoleVisibleThroughWall = 0x54; // "bool"
            inline constexpr std::uintptr_t UseLootBagSkin = 0x55; // "bool"
            inline constexpr std::uintptr_t CanHackSecurityPanel = 0x56; // "bool"
            inline constexpr std::uintptr_t CanRepairSecurityPanel = 0x57; // "bool"
            inline constexpr std::uintptr_t CanScannedMetalDetector = 0x58; // "bool"
            inline constexpr std::uintptr_t IsSurrenderCommandAvailable = 0x59; // "bool"
            inline constexpr std::uintptr_t CanSeeCopVehicleAlways = 0x5A; // "bool"
            inline constexpr std::uintptr_t CanSeeCopCarsWithPoliceRadio = 0x5B; // "bool"
            inline constexpr std::uintptr_t CanSeeKillLogsWithPoliceRadio = 0x5C; // "bool"
            inline constexpr std::uintptr_t AlwaysSeeKillLogs = 0x5D; // "bool"
            inline constexpr std::uintptr_t CanTakeCargo = 0x5E; // "bool"
            inline constexpr std::uintptr_t CanExchangeCargo = 0x5F; // "bool"
            inline constexpr std::uintptr_t CanRemoveDrill = 0x60; // "bool"
            inline constexpr std::uintptr_t IsMaskByCustomizationVisible = 0x61; // "bool"
            inline constexpr std::uintptr_t RemoveVehicleOnDisconnect = 0x62; // "bool"
            inline constexpr std::uintptr_t SpawnVehicleLootOnSuicide = 0x63; // "bool"
            inline constexpr std::uintptr_t MainMenuExitDelay = 0x68; // "long"
            inline constexpr std::uintptr_t RespawnCooldowns = 0x70; // "IReadOnlyList<long>"
            inline constexpr std::uintptr_t DeathStreakTimerDuration = 0x78; // "long"
            inline constexpr std::uintptr_t KillCumulativePoints = 0x80; // "int"
            inline constexpr std::uintptr_t CanChargeCumulativeItem = 0x84; // "bool"
            inline constexpr std::uintptr_t CanOpenBankAccount = 0x85; // "bool"
            inline constexpr std::uintptr_t TargetBattlesAfterDeathOrArrest = 0x88; // "IReadOnlyList<UserTargetBattleDescription>"
            inline constexpr std::uintptr_t TargetBattlesAfterDisconnect = 0x90; // "IReadOnlyList<UserTargetBattleDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsCop = 0x454EB90; // "public bool get_IsCop()"
            inline constexpr std::uintptr_t get_IsCitizen = 0x454EA90; // "public bool get_IsCitizen()"
            inline constexpr std::uintptr_t get_IsPrisoner = 0x454ECF0; // "public bool get_IsPrisoner()"
            inline constexpr std::uintptr_t get_IsRobber = 0x454ED70; // "public bool get_IsRobber()"
            inline constexpr std::uintptr_t get_IsSettler = 0x454EDF0; // "public bool get_IsSettler()"
            inline constexpr std::uintptr_t get_IsClanBattleMember = 0x454EB10; // "public bool get_IsClanBattleMember()"
            inline constexpr std::uintptr_t get_IsHubber = 0x454EC10; // "public bool get_IsHubber()"
            inline constexpr std::uintptr_t get_IsCivilian = 0x454EA10; // "public bool get_IsCivilian()"
            inline constexpr std::uintptr_t get_NeedHideCurrency = 0x454EE70; // "public bool get_NeedHideCurrency()"
            inline constexpr std::uintptr_t get_HasCopSalary = 0x454E7F0; // "public bool get_HasCopSalary()"
            inline constexpr std::uintptr_t get_CanGetAccess = 0x454E800; // "public bool get_CanGetAccess()"
            inline constexpr std::uintptr_t get_CanResetAccess = 0x454E7F0; // "public bool get_CanResetAccess()"
            inline constexpr std::uintptr_t get_CanBecomeCop = 0x454E830; // "public bool get_CanBecomeCop()"
            inline constexpr std::uintptr_t get_CanBecomeCitizen = 0x454E7F0; // "public bool get_CanBecomeCitizen()"
            inline constexpr std::uintptr_t get_HasCopPaid = 0x454E830; // "public bool get_HasCopPaid()"
            inline constexpr std::uintptr_t get_CanBecomeRobber = 0x454E830; // "public bool get_CanBecomeRobber()"
            inline constexpr std::uintptr_t get_HasWantedPoints = 0x454E800; // "public bool get_HasWantedPoints()"
            inline constexpr std::uintptr_t get_HasAuthority = 0x454E800; // "public bool get_HasAuthority()"
            inline constexpr std::uintptr_t get_UseCopRespawnPoints = 0x454E7F0; // "public bool get_UseCopRespawnPoints()"
            inline constexpr std::uintptr_t get_CanRefillCopAmmo = 0x454E7F0; // "public bool get_CanRefillCopAmmo()"
            inline constexpr std::uintptr_t get_CanSurrender = 0x454E800; // "public bool get_CanSurrender()"
            inline constexpr std::uintptr_t get_CanArrest = 0x454E7F0; // "public bool get_CanArrest()"
            inline constexpr std::uintptr_t get_CanForceArrest = 0x454E7E0; // "public bool get_CanForceArrest()"
            inline constexpr std::uintptr_t get_CanInterruptArresting = 0x454E800; // "public bool get_CanInterruptArresting()"
            inline constexpr std::uintptr_t get_CanBeArrested = 0x454E800; // "public bool get_CanBeArrested()"
            inline constexpr std::uintptr_t get_CanHitSurrendered = 0x454E800; // "public bool get_CanHitSurrendered()"
            inline constexpr std::uintptr_t get_CanHitCamera = 0x454E800; // "public bool get_CanHitCamera()"
            inline constexpr std::uintptr_t get_CanHitNpc = 0x454E800; // "public bool get_CanHitNpc()"
            inline constexpr std::uintptr_t get_CanChangeCopPreset = 0x454E7F0; // "public bool get_CanChangeCopPreset()"
            inline constexpr std::uintptr_t get_IsBagVisible = 0x454EA40; // "public bool get_IsBagVisible()"
            inline constexpr std::uintptr_t get_IsMaskVisible = 0x454EC90; // "public bool get_IsMaskVisible()"
            inline constexpr std::uintptr_t get_CanUseBollard = 0x454E7F0; // "public bool get_CanUseBollard()"
            inline constexpr std::uintptr_t get_SpawnVehicleLootOnTeleport = 0x454EE90; // "public bool get_SpawnVehicleLootOnTeleport()"
            inline constexpr std::uintptr_t get_CanJoinClanBattle = 0x454E8A0; // "public bool get_CanJoinClanBattle()"
            inline constexpr std::uintptr_t get_CanBeKnockedOut = 0x454E810; // "public bool get_CanBeKnockedOut()"
            inline constexpr std::uintptr_t get_CanUseMap = 0x454E810; // "public bool get_CanUseMap()"
            inline constexpr std::uintptr_t get_IsBlockingBuildingReset = 0x454E870; // "public bool get_IsBlockingBuildingReset()"
            inline constexpr std::uintptr_t get_HasDetentionPoints = 0x454EA10; // "public bool get_HasDetentionPoints()"
            inline constexpr std::uintptr_t get_CanRentCar = 0x454E910; // "public bool get_CanRentCar()"
            inline constexpr std::uintptr_t get_CanInteractWithBuyer = 0x454E870; // "public bool get_CanInteractWithBuyer()"
            inline constexpr std::uintptr_t get_CanLoseEverythingWhenResettingLayer = 0x454E8D0; // "public bool get_CanLoseEverythingWhenResettingLayer()"
            inline constexpr std::uintptr_t get_CanShoot = 0x454E940; // "public bool get_CanShoot()"
            inline constexpr std::uintptr_t get_CanMeleeAttack = 0x35FC280; // "public bool get_CanMeleeAttack()"
            inline constexpr std::uintptr_t get_CanAim = 0x9926D0; // "public bool get_CanAim()"
            inline constexpr std::uintptr_t get_CanReloadInHands = 0x9926D0; // "public bool get_CanReloadInHands()"
            inline constexpr std::uintptr_t get_CanReloadInInventory = 0x9813F0; // "public bool get_CanReloadInInventory()"
            inline constexpr std::uintptr_t get_CanUseItemsInHands = 0x9926D0; // "public bool get_CanUseItemsInHands()"
            inline constexpr std::uintptr_t get_CanThrow = 0x454E940; // "public bool get_CanThrow()"
            inline constexpr std::uintptr_t get_CanUseCopRewardBox = 0x454E830; // "public bool get_CanUseCopRewardBox()"
            inline constexpr std::uintptr_t get_CanShowArmor = 0x454E950; // "public bool get_CanShowArmor()"
            inline constexpr std::uintptr_t get_IsOutsideLaw = 0x454ECC0; // "public bool get_IsOutsideLaw()"
            inline constexpr std::uintptr_t get_CanUseSirenBuff = 0x454E7E0; // "public bool get_CanUseSirenBuff()"
            inline constexpr std::uintptr_t get_CanEquipCopPreset = 0x454E7E0; // "public bool get_CanEquipCopPreset()"
            inline constexpr std::uintptr_t get_CanUnlockVendorTreeNodes = 0x9813F0; // "public bool get_CanUnlockVendorTreeNodes()"
            inline constexpr std::uintptr_t get_CanWithdrawCash = 0x454E9F0; // "public bool get_CanWithdrawCash()"
            inline constexpr std::uintptr_t get_CanUseConsumableItem = 0x9813F0; // "public bool get_CanUseConsumableItem()"
            inline constexpr std::uintptr_t get_CanUsePersonalRepository = 0x9813F0; // "public bool get_CanUsePersonalRepository()"
            inline constexpr std::uintptr_t get_CanUsePoliceBadgeRepository = 0x454E830; // "public bool get_CanUsePoliceBadgeRepository()"
            inline constexpr std::uintptr_t get_CanExchangeCurrency = 0x454E830; // "public bool get_CanExchangeCurrency()"
            inline constexpr std::uintptr_t get_CanClaimInventoryItems = 0x9813F0; // "public bool get_CanClaimInventoryItems()"
            inline constexpr std::uintptr_t get_CanOfferBribe = 0x454E800; // "public bool get_CanOfferBribe()"
            inline constexpr std::uintptr_t get_CanAcceptBribe = 0x454E7E0; // "public bool get_CanAcceptBribe()"
            inline constexpr std::uintptr_t get_CanTakeBattlePassPointsForKill = 0x454E980; // "public bool get_CanTakeBattlePassPointsForKill()"
            inline constexpr std::uintptr_t get_CanTriggerSoundUponLeavingACashZone = 0x454E9B0; // "public bool get_CanTriggerSoundUponLeavingACashZone()"
        }
    } // namespace PlayerRoleDescription

    namespace PlayerRoleExtension { // "Models.Utils.Extensions.Character.PlayerRoleExtension (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t IsCop = 0x3C9B5C0; // "public static bool IsCop(PlayerRoleDescription role)"
            inline constexpr std::uintptr_t IsRobber = 0x3C9B650; // "public static bool IsRobber(PlayerRoleDescription role)"
        }
    } // namespace PlayerRoleExtension

    namespace PlayerRolesConfig { // "Models.References.Battle.PlayerRolesConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t SettlerFunc = 0x10; // "Func<PlayerRoleDescription>"
            inline constexpr std::uintptr_t CitizenFunc = 0x18; // "Func<PlayerRoleDescription>"
            inline constexpr std::uintptr_t RobberFunc = 0x20; // "Func<PlayerRoleDescription>"
            inline constexpr std::uintptr_t CopFunc = 0x28; // "Func<PlayerRoleDescription>"
            inline constexpr std::uintptr_t ClanBattleMemberFunc = 0x30; // "Func<PlayerRoleDescription>"
            inline constexpr std::uintptr_t PrisonerFunc = 0x38; // "Func<PlayerRoleDescription>"
            inline constexpr std::uintptr_t HubberFunc = 0x40; // "Func<PlayerRoleDescription>"
            inline constexpr std::uintptr_t CharacterHitRulesLazy = 0x48; // "Lazy<IReadOnlyDictionary<PlayerRoleDescription, HashSet<PlayerRoleDescription>>>"
            inline constexpr std::uintptr_t ChangeRoleRulesLazy = 0x50; // "Lazy<IReadOnlyDictionary<PlayerRoleDescription, PlayerRoleDescription>>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Settler = 0x1765CB0; // "public PlayerRoleDescription get_Settler()"
            inline constexpr std::uintptr_t get_Citizen = 0x26CF2F0; // "public PlayerRoleDescription get_Citizen()"
            inline constexpr std::uintptr_t get_Robber = 0x9D6230; // "public PlayerRoleDescription get_Robber()"
            inline constexpr std::uintptr_t get_Cop = 0x993E50; // "public PlayerRoleDescription get_Cop()"
            inline constexpr std::uintptr_t get_ClanBattleMember = 0x9AA5D0; // "public PlayerRoleDescription get_ClanBattleMember()"
            inline constexpr std::uintptr_t get_Prisoner = 0x2AA0B60; // "public PlayerRoleDescription get_Prisoner()"
            inline constexpr std::uintptr_t get_Hubber = 0x4048E60; // "public PlayerRoleDescription get_Hubber()"
            inline constexpr std::uintptr_t get_CharacterHitRules = 0x4550000; // "public IReadOnlyDictionary<PlayerRoleDescription, HashSet<PlayerRoleDescription>> get_CharacterHitRules()"
            inline constexpr std::uintptr_t get_ChangeRoleRules = 0x454FFB0; // "public IReadOnlyDictionary<PlayerRoleDescription, PlayerRoleDescription> get_ChangeRoleRules()"
            inline constexpr std::uintptr_t CheckHitCharacter = 0x454FD60; // "public bool CheckHitCharacter(PlayerRoleDescription selfRole, PlayerRoleDescription targetRole)"
            inline constexpr std::uintptr_t TryGetNewRole = 0x454FEA0; // "public bool TryGetNewRole(PlayerRoleDescription oldRole, out PlayerRoleDescription newRole)"
        }
    } // namespace PlayerRolesConfig

    namespace PlayerRotationInputModel { // "Game.Battle.EntityModel.Player.PlayerRotationInputModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t yaw = 0x10; // "float"
            inline constexpr std::uintptr_t pitch = 0x14; // "float"
            inline constexpr std::uintptr_t roll = 0x18; // "float"
            inline constexpr std::uintptr_t Rotation = 0x1C; // "Quaternion"
            inline constexpr std::uintptr_t Look = 0x2C; // "Vector2"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Pitch = 0x8341D0; // "public float get_Pitch()"
            inline constexpr std::uintptr_t get_Roll = 0x8341E0; // "public float get_Roll()"
            inline constexpr std::uintptr_t get_Yaw = 0x8341C0; // "public float get_Yaw()"
            inline constexpr std::uintptr_t Game_Global_Character_IRotationModel_get_Yaw = 0x8341C0; // "private float Game.Global.Character.IRotationModel.get_Yaw()"
            inline constexpr std::uintptr_t Game_Global_Character_IRotationModel_set_Yaw = 0xC516E0; // "private void Game.Global.Character.IRotationModel.set_Yaw(float value)"
            inline constexpr std::uintptr_t Game_Global_Character_IRotationModel_get_Pitch = 0x8341D0; // "private float Game.Global.Character.IRotationModel.get_Pitch()"
            inline constexpr std::uintptr_t Game_Global_Character_IRotationModel_set_Pitch = 0xC514E0; // "private void Game.Global.Character.IRotationModel.set_Pitch(float value)"
            inline constexpr std::uintptr_t Game_Global_Character_IRotationModel_get_Roll = 0x8341E0; // "private float Game.Global.Character.IRotationModel.get_Roll()"
            inline constexpr std::uintptr_t Game_Global_Character_IRotationModel_set_Roll = 0xC515E0; // "private void Game.Global.Character.IRotationModel.set_Roll(float value)"
            inline constexpr std::uintptr_t SetRotation = 0xC517E0; // "public void SetRotation(float yaw, float pitch, float roll)"
            inline constexpr std::uintptr_t SetRotation_2 = 0xC51850; // "public void SetRotation(Quaternion rotation)"
        }
    } // namespace PlayerRotationInputModel

    namespace PlayerRotationInterpolationUpdater { // "Game.Battle.EntityModel.Player.Rotation.PlayerRotationInterpolationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t snapshotModel = 0x10; // "IRotationModel"
            inline constexpr std::uintptr_t resultModel = 0x18; // "CharacterRotationModel"
            inline constexpr std::uintptr_t timeline = 0x20; // "RotationTimeline"
            inline constexpr std::uintptr_t time = 0x28; // "TimeModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC7A690; // "public void Update()"
            inline constexpr std::uintptr_t GetOrientationSnapshot = 0xC7A5C0; // "private void GetOrientationSnapshot(IRotationModel rotationModel, out Quaternion snapshot)"
        }
    } // namespace PlayerRotationInterpolationUpdater

    namespace PlayerRotationPitchUpdater { // "Game.Battle.EntityModel.Player.Rotation.PlayerRotationPitchUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t playerRotationInput = 0x10; // "PlayerRotationInputModel"
            inline constexpr std::uintptr_t rotationModel = 0x18; // "CharacterRotationModel"
            inline constexpr std::uintptr_t skeletonDeformationDescription = 0x20; // "BattleCharacterSkeletonDeformationConfig"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC7A9F0; // "public void Update()"
        }
    } // namespace PlayerRotationPitchUpdater

    namespace PlayerRotationYawUpdater { // "Game.Battle.EntityModel.BattleCharacter.Rotation.PlayerRotationYawUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleStanceModel = 0x10; // "BattleStanceModel"
            inline constexpr std::uintptr_t rotation = 0x18; // "CharacterRotationModel"
            inline constexpr std::uintptr_t turning = 0x20; // "PlayerTurningModel"
            inline constexpr std::uintptr_t now = 0x28; // "INow"
            inline constexpr std::uintptr_t characterConfig = 0x30; // "BattleCharacterConfig"
            inline constexpr std::uintptr_t movementInputModel = 0x38; // "PlayerMovementInputModel"
            inline constexpr std::uintptr_t characterVelocityModel = 0x40; // "CharacterVelocityModel"
            inline constexpr std::uintptr_t armedModel = 0x48; // "ArmedModel"
            inline constexpr std::uintptr_t desiredYawModel = 0x50; // "DesiredYawModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x58; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t knockdownModel = 0x60; // "KnockdownModel"
            inline constexpr std::uintptr_t knockoutModel = 0x68; // "KnockoutModel"
            inline constexpr std::uintptr_t characterValidationModel = 0x70; // "CharacterValidationModel"
            inline constexpr std::uintptr_t state = 0x78; // "IBattleCharacterStateModel"
            inline constexpr std::uintptr_t transformModel = 0x80; // "ITransformModel"
            inline constexpr std::uintptr_t yawTowardsWorldObjects = 0x88; // "YawTowardsWorldObjectsModel"
            inline constexpr std::uintptr_t itemActionProcessModel = 0x90; // "ItemActionProcessModel"
            inline constexpr std::uintptr_t characterControllerState = 0x98; // "IPrimitiveModel<CharacterControllerStateDescription>"
            inline constexpr std::uintptr_t isSprinting = 0xA0; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t autoLootAfterBreak = 0xA8; // "AutoLootAfterBreakColliderModel"
            inline constexpr std::uintptr_t prolongedInteractionHandlers = 0xB0; // "CommonProlongedInteractionHandlersModel"
            inline constexpr std::uintptr_t wasStanding = 0xB8; // "bool"
            inline constexpr std::uintptr_t affixTimeLeft = 0xBC; // "float"
            inline constexpr std::uintptr_t affixAngle = 0xC0; // "float"
            inline constexpr std::uintptr_t threwWhileAirborne = 0xC4; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xCD7760; // "public void Update()"
            inline constexpr std::uintptr_t UpdateDesiredYaw = 0xCD72B0; // "private void UpdateDesiredYaw()"
            inline constexpr std::uintptr_t GetYaw = 0xCD6C90; // "private float GetYaw(bool isStanding, bool isInputZero)"
            inline constexpr std::uintptr_t GetBattleStanceYaw = 0xCD6430; // "private float GetBattleStanceYaw(bool isStanding, bool isInputZero)"
            inline constexpr std::uintptr_t BeginTransitionToMovement = 0xCD6360; // "private void BeginTransitionToMovement()"
            inline constexpr std::uintptr_t EvaluateIntermediateRotationAffix = 0xCD6400; // "private float EvaluateIntermediateRotationAffix()"
            inline constexpr std::uintptr_t GetUnarmedYaw = 0xCD6BA0; // "private float GetUnarmedYaw()"
            inline constexpr std::uintptr_t IsMoveInputBlocked = 0xCD6FA0; // "private bool IsMoveInputBlocked()"
            inline constexpr std::uintptr_t TryGetYawTowardsBreakObjectChainedWithLoot = 0xCD70B0; // "private bool TryGetYawTowardsBreakObjectChainedWithLoot(out float yaw)"
            inline constexpr std::uintptr_t GetCharactersYawTowardsObject = 0xCD6AB0; // "private float GetCharactersYawTowardsObject(float objectX, float objectZ)"
        }
    } // namespace PlayerRotationYawUpdater

    namespace PlayerSearchFieldUpdater { // "Game.Global.Party.Dialog.PlayerSearchFieldUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t minPublicIdLength = 0x10; // "int"
            inline constexpr std::uintptr_t maxPublicIdLength = 0x14; // "int"
            inline constexpr std::uintptr_t dialogView = 0x18; // "PartyManagerDialogView"
            inline constexpr std::uintptr_t partyModel = 0x20; // "PartyModel"
            inline constexpr std::uintptr_t partyManagerDialogModel = 0x28; // "PartyManagerDialogModel"
            inline constexpr std::uintptr_t fieldValidationLocalization = 0x30; // "FieldValidationLocalization"
            inline constexpr std::uintptr_t partyLocalization = 0x38; // "PartyLocalization"
            inline constexpr std::uintptr_t nameLengthValidation = 0x40; // "Text<int>"
            inline constexpr std::uintptr_t wasFocusedOnce = 0x48; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x3578A90; // "public void Update()"
            inline constexpr std::uintptr_t IsNameValid = 0x3578930; // "private bool IsNameValid(string name, out IText errorMessage)"
            inline constexpr std::uintptr_t GetState = 0x3578850; // "private InputFieldWithErrorView.InputFieldState GetState(bool isValid, IText nameValidText, out IText tip)"
        }
    } // namespace PlayerSearchFieldUpdater

    namespace PlayerShaderGlobalPositionUpdater { // "Game.Battle.Entities.Player.Updaters.PlayerShaderGlobalPositionUpdater (Battle.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x8175138; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "IMovementModel"
        }
        namespace StaticFields {
            inline constexpr std::uintptr_t PlayerCharacterPositionWs = 0x0; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB0EE50; // "public void Update()"
        }
    } // namespace PlayerShaderGlobalPositionUpdater

    namespace PlayerSkeletonUpdater { // "Game.Battle.HitBoxes.PlayerSkeletonUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleEntitiesModel = 0x10; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t contentCache = 0x18; // "ContentCacheModel"
            inline constexpr std::uintptr_t time = 0x20; // "TimeModel"
            inline constexpr std::uintptr_t battleMode = 0x28; // "BattleModeDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA97A50; // "public void Update()"
        }
    } // namespace PlayerSkeletonUpdater

    namespace PlayerStateSwitchUpdater { // "Game.Battle.Entities.Player.Updaters.PlayerStateSwitchUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t playerServerModel = 0x10; // "BattleCharacterModel"
            inline constexpr std::uintptr_t playerStateViewDescriptions = 0x18; // "PlayerStateViewDescriptions"
            inline constexpr std::uintptr_t soundEmitter = 0x20; // "GameObject"
            inline constexpr std::uintptr_t playerState = 0x28; // "BattleCharacterState"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB0EFA0; // "public void Update()"
        }
    } // namespace PlayerStateSwitchUpdater

    namespace PlayerTeleportUpdater { // "Game.Battle.Entities.Player.Updaters.PlayerTeleportUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleEntitiesModel = 0x10; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t lastTeleportTs = 0x18; // "long"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB0F610; // "public void Update()"
        }
    } // namespace PlayerTeleportUpdater

    namespace PlayerTurnAroundAnimationUpdater { // "Game.Battle.Entities.Player.Updaters.PlayerTurnAroundAnimationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t relativeVelocity = 0x10; // "CharacterRelativeVelocityModel"
            inline constexpr std::uintptr_t movementIntentionDirection = 0x18; // "CharacterMovementIntentionDirectionModel"
            inline constexpr std::uintptr_t characterAnimationView = 0x20; // "CharacterAnimationView"
            inline constexpr std::uintptr_t character = 0x28; // "BattleCharacterModel"
            inline constexpr std::uintptr_t sprintInput = 0x30; // "InputModel"
            inline constexpr std::uintptr_t sprintIntention = 0x38; // "InputIntentionModel"
            inline constexpr std::uintptr_t movementInput = 0x40; // "PlayerMovementInputModel"
            inline constexpr std::uintptr_t turnHandled = 0x48; // "bool"
            inline constexpr std::uintptr_t isSprintTurning = 0x49; // "bool"
            inline constexpr std::uintptr_t sprintTurnTime = 0x4C; // "float"
            inline constexpr std::uintptr_t sprintTurnWeight = 0x50; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB0FBE0; // "public void Update()"
            inline constexpr std::uintptr_t UpdateSprintTurn = 0xB0FAC0; // "private void UpdateSprintTurn(float dot, float sprintWeight)"
            inline constexpr std::uintptr_t ResetSprintTurn = 0xB0FA80; // "private void ResetSprintTurn()"
            inline constexpr std::uintptr_t CanUseSprintTurn = 0xB0F700; // "private bool CanUseSprintTurn()"
        }
    } // namespace PlayerTurnAroundAnimationUpdater

    namespace PlayerTurningAnimationUpdater { // "Game.Battle.EntityModel.Player.Rotation.PlayerTurningAnimationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t turningModel = 0x10; // "PlayerTurningModel"
            inline constexpr std::uintptr_t characterTurningModel = 0x18; // "CharacterTurningModel"
            inline constexpr std::uintptr_t animationView = 0x20; // "CharacterAnimationView"
            inline constexpr std::uintptr_t lastTurnTs = 0x28; // "long"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC7C040; // "public void Update()"
        }
    } // namespace PlayerTurningAnimationUpdater

    namespace PlayerTurningModel { // "Game.Battle.EntityModel.Player.Rotation.PlayerTurningModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t StartTs = 0x10; // "long"
            inline constexpr std::uintptr_t IsLeftSide = 0x18; // "bool"
            inline constexpr std::uintptr_t OriginYaw = 0x1C; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Stop = 0xC7C120; // "public void Stop()"
        }
    } // namespace PlayerTurningModel

    namespace PlayerTurningModelUpdater { // "Game.Battle.EntityModel.BattleCharacter.Rotation.PlayerTurningModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t rotationModel = 0x10; // "CharacterRotationModel"
            inline constexpr std::uintptr_t stateModel = 0x18; // "IBattleCharacterStateModel"
            inline constexpr std::uintptr_t turningModel = 0x20; // "PlayerTurningModel"
            inline constexpr std::uintptr_t battleStanceModel = 0x28; // "BattleStanceModel"
            inline constexpr std::uintptr_t velocityModel = 0x30; // "CharacterVelocityModel"
            inline constexpr std::uintptr_t skeletonDeformationDescription = 0x38; // "BattleCharacterSkeletonDeformationConfig"
            inline constexpr std::uintptr_t now = 0x40; // "INow"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xCD8570; // "public void Update()"
        }
    } // namespace PlayerTurningModelUpdater

    namespace PlayerTurningProgressUpdater { // "Game.Battle.EntityModel.Player.Rotation.PlayerTurningProgressUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t playerTurningModel = 0x10; // "PlayerTurningModel"
            inline constexpr std::uintptr_t characterTurningModel = 0x18; // "CharacterTurningModel"
            inline constexpr std::uintptr_t skeletonDeformationDescription = 0x20; // "BattleCharacterSkeletonDeformationConfig"
            inline constexpr std::uintptr_t now = 0x28; // "INow"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC7C130; // "public void Update()"
        }
    } // namespace PlayerTurningProgressUpdater

    namespace PlayerVisibleDistanceCameraUpdater { // "Game.Battle.EntityModel.Player.PlayerVisibleDistanceCameraUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t cameraModel = 0x10; // "BattleCameraModel"
            inline constexpr std::uintptr_t battleCharacterModel = 0x18; // "BattleCharacterModel"
            inline constexpr std::uintptr_t playerCameraViewDescriptions = 0x20; // "PlayerCameraViewDescriptions"
            inline constexpr std::uintptr_t characterClientModel = 0x28; // "CharacterClientModel"
            inline constexpr std::uintptr_t followTransform = 0x30; // "Transform"
            inline constexpr std::uintptr_t weapon = 0x38; // "IWeaponModel"
            inline constexpr std::uintptr_t weaponViewDescriptions = 0x40; // "WeaponViewDescriptions"
            inline constexpr std::uintptr_t followCameraCloseToGround = 0x48; // "Transform"
            inline constexpr std::uintptr_t followCameraKnockout = 0x50; // "Transform"
            inline constexpr std::uintptr_t itemActionProcessModel = 0x58; // "ItemActionProcessModel"
            inline constexpr std::uintptr_t selectedItemModel = 0x60; // "SelectedItemModel"
            inline constexpr std::uintptr_t usableItemViewDescriptions = 0x68; // "UsableItemViewDescriptions"
            inline constexpr std::uintptr_t throwableItemViewDescriptions = 0x70; // "ThrowableItemViewDescriptions"
            inline constexpr std::uintptr_t camera = 0x78; // "Camera"
            inline constexpr std::uintptr_t stateModel = 0x80; // "IBattleCharacterStateModel"
            inline constexpr std::uintptr_t playerWeaponParent = 0x88; // "Transform"
            inline constexpr std::uintptr_t aimModeModel = 0x90; // "IPrimitiveModel<AimModeDescription>"
            inline constexpr std::uintptr_t isHidden = 0x98; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC7C740; // "public void Update()"
            inline constexpr std::uintptr_t IsHidden = 0xC7C2F0; // "private bool IsHidden()"
        }
    } // namespace PlayerVisibleDistanceCameraUpdater

    namespace PointerHoverSectorUpdater { // "Game.Battle.Emotion.InputHandlers.PointerHoverSectorUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t backgroundView = 0x10; // "PointerHoverButtonView"
            inline constexpr std::uintptr_t sectorInputModel = 0x18; // "SectorInputModel"
            inline constexpr std::uintptr_t isFirstItemInCenter = 0x20; // "bool"
            inline constexpr std::uintptr_t isClockwise = 0x21; // "bool"
            inline constexpr std::uintptr_t rect = 0x28; // "RectTransform"
            inline constexpr std::uintptr_t sectorAngle = 0x30; // "float"
            inline constexpr std::uintptr_t minDistanceSqr = 0x34; // "float"
            inline constexpr std::uintptr_t maxDistanceSqr = 0x38; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xCEE930; // "public void Update()"
            inline constexpr std::uintptr_t GetPosition = 0xCEE850; // "private Vector2 GetPosition()"
        }
    } // namespace PointerHoverSectorUpdater

    namespace PoliceReinforcementInvitePopupInputUpdater { // "Game.Global.PoliceReinforcementInvitePopup.PoliceReinforcementInvitePopupInputUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t popupModel = 0x10; // "PoliceReinforcementInvitePopupModel"
            inline constexpr std::uintptr_t uiSoundModel = 0x18; // "GlobalUISoundModel"
            inline constexpr std::uintptr_t Handlers = 0x20; // "ValueTuple<InputMask, IUpdater>[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Priority = 0x10B1310; // "public InputHandlerPriority get_Priority()"
            inline constexpr std::uintptr_t Accept = 0x35B8080; // "private void Accept()"
            inline constexpr std::uintptr_t Decline = 0x35B80E0; // "private void Decline()"
        }
    } // namespace PoliceReinforcementInvitePopupInputUpdater

    namespace PopupData { // "Game.Battle.Entities.Player.Models.PopupData (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsRight = 0x0; // "bool"
            inline constexpr std::uintptr_t IsBadPrediction = 0x1; // "bool"
            inline constexpr std::uintptr_t IsHead = 0x2; // "bool"
            inline constexpr std::uintptr_t IsArmor = 0x3; // "bool"
            inline constexpr std::uintptr_t IsImmune = 0x4; // "bool"
            inline constexpr std::uintptr_t AnimRndX = 0x8; // "float"
            inline constexpr std::uintptr_t AnimRndY = 0xC; // "float"
            inline constexpr std::uintptr_t Position = 0x10; // "Vector3"
            inline constexpr std::uintptr_t RemoveTime = 0x20; // "long"
            inline constexpr std::uintptr_t Damage = 0x28; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetDamageData = 0xB21880; // "public void SetDamageData(bool isRight, bool isBadPrediction, bool isHead, bool isArmor, bool isImmune, Vector3 position, int damage)"
        }
    } // namespace PopupData

    namespace PredictCargoProductionWorkbenchInputSystem { // "Models.Systems.PredictCargoProductionWorkbenchInputSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t worldEntitiesModel = 0x38; // "WorldEntitiesModel"
            inline constexpr std::uintptr_t settlementHelperModel = 0x40; // "ISettlementHelperModel"
            inline constexpr std::uintptr_t partyMemberAccessModel = 0x48; // "IPartyMemberAccessModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x4103C50; // "protected override void Tick(ITick tick)"
            inline constexpr std::uintptr_t SetRecipeFromCargo = 0x4103B90; // "private void SetRecipeFromCargo(int characterEntityId, CargoProductionWorkbenchModel workbench, CharacterCargoModel cargo)"
            inline constexpr std::uintptr_t UnsetRecipe = 0x7B3360; // "private void UnsetRecipe()"
        }
    } // namespace PredictCargoProductionWorkbenchInputSystem

    namespace PredictedInputsModel { // "ClientCore.Prediction.PredictedInputsModel.PredictedInputsModel (Client.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t time = 0x10; // "TimeModel"
            inline constexpr std::uintptr_t inputs = 0x18; // "Queue<BattleInputData>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t AddInput = 0xE71E00; // "public void AddInput(in BattleInputData inputData)"
            inline constexpr std::uintptr_t RemoveOldInputs = 0xE71EF0; // "public void RemoveOldInputs(long tickIndex)"
            inline constexpr std::uintptr_t get_Inputs = 0xE72080; // "public Queue.Enumerator<BattleInputData> get_Inputs()"
            inline constexpr std::uintptr_t ClientCore_Prediction_PredictedInputsModel_IPredictedInputsModel_AddInput = 0xE71E00; // "private void ClientCore.Prediction.PredictedInputsModel.IPredictedInputsModel.AddInput(in BattleInputData inputData)"
        }
    } // namespace PredictedInputsModel

    namespace PredictedInputsModelUpdater { // "ClientCore.Prediction.PredictedInputsModelUpdater.PredictedInputsModelUpdater (Client.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t inputDataModel = 0x10; // "IBattleInputDataModel"
            inline constexpr std::uintptr_t predictedInputsModel = 0x18; // "IPredictedInputsModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xE71C40; // "public void Update()"
        }
    } // namespace PredictedInputsModelUpdater

    namespace PredictHitsModel { // "Game.Battle.EntityModel.BattleCharacter.Hit.PredictHitsModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t hits = 0x10; // "LinkedList<CharacterHitData>"
            inline constexpr std::uintptr_t nodes = 0x18; // "Dictionary<long, LinkedListNode<CharacterHitData>>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Add = 0xCD8810; // "public void Add(long tickIndex, int entityId, Vector3 positionDiff)"
            inline constexpr std::uintptr_t TryGet = 0xCD8A40; // "public bool TryGet(int entityId, long tickIndex, out Vector3 positionDiff)"
            inline constexpr std::uintptr_t Clear = 0xCD8900; // "private void Clear(long tickIndex)"
        }
    } // namespace PredictHitsModel

    namespace PredictionExtraTimeModelUpdater { // "Game.Battle.Player.PredictionExtraTimeModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t time = 0x10; // "TimeModel"
            inline constexpr std::uintptr_t predictionExtraTimeModel = 0x18; // "PredictionExtraTimeModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x9752F0; // "public void Update()"
        }
    } // namespace PredictionExtraTimeModelUpdater

    namespace ProlongedActionProcessModel { // "Game.Battle.Entities.Player.ProlongedActions.ProlongedActionProcessModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Action = 0x10; // "IProlongedAction"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsActive = 0xB219B0; // "public bool get_IsActive()"
            inline constexpr std::uintptr_t TryGetInterruptAction = 0xB21940; // "public bool TryGetInterruptAction(out IInterruptAction action)"
        }
    } // namespace ProlongedActionProcessModel

    namespace ProlongedActionProcessUpdater { // "Game.Battle.EntityModel.Player.ProlongedActionProcessUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t prolongedActionProcessModel = 0x10; // "ProlongedActionProcessModel"
            inline constexpr std::uintptr_t actions = 0x18; // "List<IProlongedAction>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC7E4C0; // "public void Update()"
        }
    } // namespace ProlongedActionProcessUpdater

    namespace ProlongedInteractionInputDescription { // "Models.References.Input.ProlongedInteractionInputDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x81A1518; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t Start = 0x0; // "ProlongedInteractionInputDescription"
            inline constexpr std::uintptr_t Stop = 0x8; // "ProlongedInteractionInputDescription"
        }
    } // namespace ProlongedInteractionInputDescription

    namespace ProlongedInteractionInputHandler { // "Game.Battle.Unlock.ProlongedInteractionInputHandler (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleInputModel = 0x10; // "BattleInputModel"
            inline constexpr std::uintptr_t prolongedActionProcessModel = 0x18; // "ProlongedActionProcessModel"
            inline constexpr std::uintptr_t deferredOpenModel = 0x20; // "DeferredOpenModel"
            inline constexpr std::uintptr_t Handlers = 0x28; // "ValueTuple<InputMask, IUpdater>[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Interrupt = 0xD57160; // "private void Interrupt()"
            inline constexpr std::uintptr_t get_Priority = 0x7E2F30; // "public InputHandlerPriority get_Priority()"
        }
    } // namespace ProlongedInteractionInputHandler

    namespace PublicCharacterHiddenStateModel { // "Models.Models.CharacterHideObjectState.PublicCharacterHiddenStateModel (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t get_IsHidden = 0x7EC9F0; // "public bool get_IsHidden()"
        }
    } // namespace PublicCharacterHiddenStateModel

    namespace QuickSlotsInputModel { // "Game.Battle.Inputs.QuickSlotsInputModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t WeaponSlot0 = 0x10; // "InputModel"
            inline constexpr std::uintptr_t WeaponSlot1 = 0x18; // "InputModel"
            inline constexpr std::uintptr_t PocketSlot0 = 0x20; // "InputModel"
            inline constexpr std::uintptr_t PocketSlot1 = 0x28; // "InputModel"
            inline constexpr std::uintptr_t PocketSlot2 = 0x30; // "InputModel"
            inline constexpr std::uintptr_t PocketSlot3 = 0x38; // "InputModel"
            inline constexpr std::uintptr_t ToggleSlot = 0x40; // "InputModel"
            inline constexpr std::uintptr_t AutoSelectedQuickSlot = 0x48; // "QuickSlotDescription"
        }
    } // namespace QuickSlotsInputModel

    namespace RadioInputUpdater { // "Game.Battle.Radio.RadioInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t action = 0x10; // "InputAction"
            inline constexpr std::uintptr_t connection = 0x18; // "IRoomConnection"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x20; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t viewDescriptions = 0x28; // "RadioStationViewDescriptions"
            inline constexpr std::uintptr_t streamerMode = 0x30; // "IChangeBufferValue<bool>"
            inline constexpr std::uintptr_t isMessageSend = 0x38; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xDC8AF0; // "public void Update()"
            inline constexpr std::uintptr_t SendChangeRadioStation = 0xDC8A20; // "private void SendChangeRadioStation(RadioStationModel radioStationModel)"
        }
    } // namespace RadioInputUpdater

    namespace RaidDefenseBlockProlongedAction { // "Game.Battle.Entities.Player.ProlongedActions.RaidDefenseBlockProlongedAction (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "ProlongedInteractionModel"
            inline constexpr std::uintptr_t inventory = 0x18; // "IInventoryModel"
            inline constexpr std::uintptr_t Label = 0x20; // "LocalizedString"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsActive = 0xB21BE0; // "public bool get_IsActive()"
            inline constexpr std::uintptr_t get_EndTs = 0xB19D10; // "public long get_EndTs()"
            inline constexpr std::uintptr_t get_Duration = 0xB21AB0; // "public long get_Duration()"
            inline constexpr std::uintptr_t Interrupt = 0xB21A00; // "public void Interrupt(BattleInputModel battleInputModel)"
        }
    } // namespace RaidDefenseBlockProlongedAction

    namespace ReconnectInputActionsUpdater { // "Game.ReconnectScreen.ReconnectInputActionsUpdater (Game.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dialogModel = 0x10; // "IScreenModel"
            inline constexpr std::uintptr_t connectionState = 0x18; // "ConnectionState"
            inline constexpr std::uintptr_t uiSoundModel = 0x20; // "GlobalUISoundModel"
            inline constexpr std::uintptr_t connectGameLoggerModel = 0x28; // "ConnectGameLoggerModel"
            inline constexpr std::uintptr_t Handlers = 0x30; // "ValueTuple<InputMask, IUpdater>[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t OnReconnectButtonClicked = 0x10B1FD0; // "private void OnReconnectButtonClicked()"
            inline constexpr std::uintptr_t Reconnect = 0x10B2060; // "private void Reconnect()"
            inline constexpr std::uintptr_t get_Priority = 0x10B2420; // "public InputHandlerPriority get_Priority()"
        }
    } // namespace ReconnectInputActionsUpdater

    namespace RelativeVelocityModelUpdater { // "Game.Battle.EntityModel.BattleCharacter.Movement.RelativeVelocityModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t relativeVelocityModel = 0x10; // "CharacterRelativeVelocityModel"
            inline constexpr std::uintptr_t now = 0x18; // "INow"
            inline constexpr std::uintptr_t characterSpeedModel = 0x20; // "CharacterSpeedModel"
            inline constexpr std::uintptr_t time = 0x28; // "TimeModel"
            inline constexpr std::uintptr_t movementTimeline = 0x30; // "MovementTimeline"
            inline constexpr std::uintptr_t rotationTimeline = 0x38; // "RotationTimeline"
            inline constexpr std::uintptr_t characterRotation = 0x40; // "CharacterRotationModel"
            inline constexpr std::uintptr_t characterVelocityModel = 0x48; // "CharacterVelocityModel"
            inline constexpr std::uintptr_t characterControllerStateModel = 0x50; // "IPrimitiveModel<CharacterControllerStateDescription>"
            inline constexpr std::uintptr_t dt = 0x58; // "float"
            inline constexpr std::uintptr_t lastTs = 0x60; // "long"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xCD8C10; // "public void Update()"
        }
    } // namespace RelativeVelocityModelUpdater

    namespace ReloadAddressablesInputActionUpdater { // "Game.ReloadAddressablesDialog.ReloadAddressablesInputActionUpdater (Game.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "ReloadAddressablesDialogModel"
            inline constexpr std::uintptr_t Handlers = 0x18; // "ValueTuple<InputMask, IUpdater>[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t OnOkButtonClicked = 0x10B2B40; // "private void OnOkButtonClicked()"
            inline constexpr std::uintptr_t OnCancelButtonClicked = 0x10B2AD0; // "private void OnCancelButtonClicked()"
            inline constexpr std::uintptr_t get_Priority = 0x7E5D90; // "public InputHandlerPriority get_Priority()"
        }
    } // namespace ReloadAddressablesInputActionUpdater

    namespace RemoveDrillProlongedAction { // "Game.Battle.Entities.Player.ProlongedActions.RemoveDrillProlongedAction (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "ProlongedInteractionModel"
            inline constexpr std::uintptr_t worldEntitiesModel = 0x18; // "WorldEntitiesModel"
            inline constexpr std::uintptr_t Label = 0x20; // "LocalizedString"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsActive = 0xB225D0; // "public bool get_IsActive()"
            inline constexpr std::uintptr_t get_EndTs = 0xB19D10; // "public long get_EndTs()"
            inline constexpr std::uintptr_t get_Duration = 0xB224A0; // "public long get_Duration()"
            inline constexpr std::uintptr_t Interrupt = 0xB223F0; // "public void Interrupt(BattleInputModel battleInputModel)"
        }
    } // namespace RemoveDrillProlongedAction

    namespace RemovePoopPileProlongedAction { // "Game.Battle.Entities.Player.ProlongedActions.RemovePoopPileProlongedAction (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "ProlongedInteractionModel"
            inline constexpr std::uintptr_t Label = 0x18; // "LocalizedString"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsActive = 0xB226F0; // "public bool get_IsActive()"
            inline constexpr std::uintptr_t get_EndTs = 0xB19D10; // "public long get_EndTs()"
            inline constexpr std::uintptr_t get_Duration = 0xB22690; // "public long get_Duration()"
            inline constexpr std::uintptr_t Interrupt = 0xB225E0; // "public void Interrupt(BattleInputModel battleInputModel)"
        }
    } // namespace RemovePoopPileProlongedAction

    namespace RepairBreachProlongedAction { // "Game.Battle.Entities.Player.ProlongedActions.RepairBreachProlongedAction (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "ProlongedInteractionModel"
            inline constexpr std::uintptr_t Label = 0x18; // "LocalizedString"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsActive = 0xB22810; // "public bool get_IsActive()"
            inline constexpr std::uintptr_t get_EndTs = 0xB19D10; // "public long get_EndTs()"
            inline constexpr std::uintptr_t get_Duration = 0xB227B0; // "public long get_Duration()"
            inline constexpr std::uintptr_t Interrupt = 0xB22700; // "public void Interrupt(BattleInputModel battleInputModel)"
        }
    } // namespace RepairBreachProlongedAction

    namespace RepairDefenseBlockProlongedAction { // "Game.Battle.Entities.Player.ProlongedActions.RepairDefenseBlockProlongedAction (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "ProlongedInteractionModel"
            inline constexpr std::uintptr_t Label = 0x18; // "LocalizedString"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsActive = 0xB228E0; // "public bool get_IsActive()"
            inline constexpr std::uintptr_t get_EndTs = 0xB19D10; // "public long get_EndTs()"
            inline constexpr std::uintptr_t get_Duration = 0xB228D0; // "public long get_Duration()"
            inline constexpr std::uintptr_t Interrupt = 0xB22820; // "public void Interrupt(BattleInputModel battleInputModel)"
        }
    } // namespace RepairDefenseBlockProlongedAction

    namespace ReportedPlayersModel { // "Models.Models.ReportedPlayers.ReportedPlayersModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "DictionaryData<long, IPrimitiveData<long>>"
            inline constexpr std::uintptr_t reportedPlayers = 0x18; // "SortedSet<ReportedPlayersModel.ReportedPlayer>"
            inline constexpr std::uintptr_t reportedPlayersByPublicId = 0x20; // "Dictionary<long, ReportedPlayersModel.ReportedPlayer>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t CheckReport = 0x48E3420; // "public bool CheckReport(long publicId, long now)"
            inline constexpr std::uintptr_t Add = 0x48E3090; // "public void Add(long publicId, long now)"
            inline constexpr std::uintptr_t UpdateReportedPlayer = 0x48E3630; // "private void UpdateReportedPlayer(ReportedPlayersModel.ReportedPlayer reportedPlayer, long reportCooldownEndTs)"
            inline constexpr std::uintptr_t RemoveOldestReport = 0x48E3560; // "private void RemoveOldestReport()"
            inline constexpr std::uintptr_t AddReportedPlayer = 0x48E2F80; // "private void AddReportedPlayer(long publicId, long reportCooldownEndTs)"
            inline constexpr std::uintptr_t Clear = 0x48E34D0; // "public void Clear()"
        }
    } // namespace ReportedPlayersModel

    namespace ReportedPlayersModel_ReportedPlayer { // "Models.Models.ReportedPlayers.ReportedPlayersModel.ReportedPlayer (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t PublicId = 0x10; // "long"
            inline constexpr std::uintptr_t ReportCooldownEndTs = 0x18; // "long"
        }
    } // namespace ReportedPlayersModel_ReportedPlayer

    namespace ReportedPlayersModel_ReportedPlayerComparer { // "Models.Models.ReportedPlayers.ReportedPlayersModel.ReportedPlayerComparer (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t Compare = 0x48E2ED0; // "public override int Compare(ReportedPlayersModel.ReportedPlayer first, ReportedPlayersModel.ReportedPlayer second)"
        }
    } // namespace ReportedPlayersModel_ReportedPlayerComparer

    namespace ReputationChangeCharacterUpdater { // "Game.Global.Reputation.Updaters.ReputationChangeCharacterUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dialogModel = 0x10; // "ReputationDialogModel"
            inline constexpr std::uintptr_t reputationSceneModel = 0x18; // "ReputationSceneModel"
            inline constexpr std::uintptr_t skinCenterModel = 0x20; // "SkinCenterModel"
            inline constexpr std::uintptr_t roomConnection = 0x28; // "IRoomConnection"
            inline constexpr std::uintptr_t personalNotificationModel = 0x30; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t soundModel = 0x38; // "GlobalUISoundModel"
            inline constexpr std::uintptr_t localizationKeys = 0x40; // "GlobalLocalizationKeys"
            inline constexpr std::uintptr_t playerServerModel = 0x48; // "BattleCharacterModel"
            inline constexpr std::uintptr_t characterSex = 0x50; // "CharacterSexDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x3780B30; // "public void Update()"
            inline constexpr std::uintptr_t UpdateCustomizeCharacter = 0x3780A80; // "private void UpdateCustomizeCharacter()"
            inline constexpr std::uintptr_t SendMessage = 0x3780990; // "private Task SendMessage(CharacterSexDescription characterSex)"
        }
    } // namespace ReputationChangeCharacterUpdater

    namespace ReputationCharacterCustomizationModelUpdater { // "Game.Global.Reputation.ReputationCharacterCustomizationModelUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t viewModel = 0x10; // "ReputationViewModel"
            inline constexpr std::uintptr_t reputationSceneModel = 0x18; // "ReputationSceneModel"
            inline constexpr std::uintptr_t character = 0x20; // "CharacterTemporaryModel"
            inline constexpr std::uintptr_t customizerViewDescription = 0x28; // "CustomizerViewDescription"
            inline constexpr std::uintptr_t awardItemDescription = 0x30; // "ImprisonmentAwardItemDescription"
            inline constexpr std::uintptr_t characterSex = 0x38; // "CharacterSexDescription"
            inline constexpr std::uintptr_t isNaked = 0x40; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x37815A0; // "public void Update()"
            inline constexpr std::uintptr_t UpdateKeychain = 0x3781250; // "private void UpdateKeychain(CharacterCustomizationModel customizationModel)"
            inline constexpr std::uintptr_t UpdateMask = 0x3781420; // "private void UpdateMask(CharacterCustomizationModel customizationModel)"
            inline constexpr std::uintptr_t UpdateBag = 0x3780DE0; // "private void UpdateBag(CharacterCustomizationModel customizationModel)"
            inline constexpr std::uintptr_t UpdateBody = 0x3780EB0; // "private void UpdateBody(CharacterCustomizationModel customizationModel)"
            inline constexpr std::uintptr_t UpdateTattoo = 0x37814F0; // "private void UpdateTattoo(CharacterCustomizationModel customizationModel)"
            inline constexpr std::uintptr_t IsForceBald = 0x3780D60; // "private bool IsForceBald()"
        }
    } // namespace ReputationCharacterCustomizationModelUpdater

    namespace ReputationClothesToggleInputUpdater { // "Game.Global.Reputation.ReputationClothesToggleInputUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t soundModel = 0x10; // "GlobalUISoundModel"
            inline constexpr std::uintptr_t toggleView = 0x18; // "ToggleStateView"
            inline constexpr std::uintptr_t toggleAction = 0x20; // "Action<bool>"
            inline constexpr std::uintptr_t value = 0x28; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x3782A70; // "public void Update()"
        }
    } // namespace ReputationClothesToggleInputUpdater

    namespace ReputationPrefsData { // "Game.Global.PlayerPrefsFile.ReputationPrefsData (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Tattoo = 0x20; // "SetData<int>"
            inline constexpr std::uintptr_t BodySkin = 0x28; // "SetData<CharacterBodyDescription>"
            inline constexpr std::uintptr_t FBodySkin = 0x30; // "SetData<CharacterFBodyDescription>"
            inline constexpr std::uintptr_t BagSkin = 0x38; // "SetData<CharacterBagDescription>"
            inline constexpr std::uintptr_t MaskSkin = 0x40; // "SetData<CharacterMaskDescription>"
            inline constexpr std::uintptr_t KeychainSkin = 0x48; // "SetData<CharacterKeychainDescription>"
            inline constexpr std::uintptr_t WeaponSkin = 0x50; // "SetData<WeaponSkinDescription>"
            inline constexpr std::uintptr_t Emotion = 0x58; // "SetData<EmotionDescription>"
            inline constexpr std::uintptr_t Car = 0x60; // "SetData<CarDescription>"
            inline constexpr std::uintptr_t Helicopter = 0x68; // "SetData<HelicopterDescription>"
        }
    } // namespace ReputationPrefsData

    namespace ReputationRewardInputUpdater { // "Game.Global.Reputation.ReputationRewardInputUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t reputationViewModel = 0x10; // "ReputationViewModel"
            inline constexpr std::uintptr_t soundModel = 0x18; // "GlobalUISoundModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x378BF10; // "public void Update()"
        }
    } // namespace ReputationRewardInputUpdater

    namespace ResetAccessProlongedAction { // "Game.Battle.Entities.Player.ProlongedActions.ResetAccessProlongedAction (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "ProlongedInteractionModel"
            inline constexpr std::uintptr_t worldEntitiesModel = 0x18; // "WorldEntitiesModel"
            inline constexpr std::uintptr_t accessEntityViewDescriptions = 0x20; // "AccessEntityViewDescriptions"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Label = 0xB22BF0; // "public LocalizedString get_Label()"
            inline constexpr std::uintptr_t get_IsActive = 0xB22BE0; // "public bool get_IsActive()"
            inline constexpr std::uintptr_t get_EndTs = 0xB19D10; // "public long get_EndTs()"
            inline constexpr std::uintptr_t get_Duration = 0xB22B20; // "public long get_Duration()"
            inline constexpr std::uintptr_t Interrupt = 0xB22A70; // "public void Interrupt(BattleInputModel battleInputModel)"
        }
    } // namespace ResetAccessProlongedAction

    namespace ResetMoveDirectionUpdater { // "Game.Battle.Inputs.ResetMoveDirectionUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t playerMovementInput = 0x10; // "PlayerMovementInputModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x18; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t inputHandlersManager = 0x20; // "InputHandlersManager"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA98060; // "public void Update()"
        }
    } // namespace ResetMoveDirectionUpdater

    namespace ResetPlayerPrefsUpdater { // "Game.Global.PlayerPrefsFile.ResetPlayerPrefsUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t creationTs = 0x10; // "PrimitiveModel<long>"
            inline constexpr std::uintptr_t playerPrefsModel = 0x18; // "PlayerPrefsModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x37A9A00; // "public void Update()"
        }
    } // namespace ResetPlayerPrefsUpdater

    namespace RevealContainerPrefsData { // "Game.Global.PlayerPrefsFile.RevealContainerPrefsData (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t RevealId = 0x20; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t Snapshot = 0x28; // "DictionaryData<int, IPrimitiveData<string>>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_MaxLenght = 0x37A9EA0; // "public static int get_MaxLenght()"
        }
    } // namespace RevealContainerPrefsData

    namespace RotationData { // "Game.Battle.EntityModel.BattleCharacter.RotationData (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Rotation = 0x0; // "Quaternion"
            inline constexpr std::uintptr_t Ts = 0x10; // "long"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Interpolate = 0xCC49B0; // "public static RotationData Interpolate(RotationData from, RotationData to, long ts)"
            inline constexpr std::uintptr_t WithNewTs = 0xCC4A30; // "public static RotationData WithNewTs(RotationData source, long ts)"
            inline constexpr std::uintptr_t GetDt = 0xCC3ED0; // "private static float GetDt(long start, long end, long ts)"
        }
    } // namespace RotationData

    namespace RotationInterpolationUpdater { // "Game.Battle.EntityModel.BattleCharacter.Rotation.RotationInterpolationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dataTickModel = 0x20; // "IDataTickModel"
            inline constexpr std::uintptr_t snapshotModel = 0x28; // "ITransformModel"
            inline constexpr std::uintptr_t resultModel = 0x30; // "IRotationModel"
            inline constexpr std::uintptr_t timeline = 0x38; // "RotationTimeline"
            inline constexpr std::uintptr_t time = 0x40; // "TimeModel"
            inline constexpr std::uintptr_t interpolationNow = 0x48; // "INow"
            inline constexpr std::uintptr_t tickIndex = 0x50; // "long"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xCD92F0; // "public RotationInterpolationUpdater Init(IDataTickModel dataTickModel, ITransformModel snapshotModel, IRotationModel resultModel, RotationTimeline timeline, TimeModel time, INow interpolationNow)"
            inline constexpr std::uintptr_t Dispose = 0xA0E680; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xCD9390; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t GetOrientationSnapshot = 0xCD9210; // "private void GetOrientationSnapshot(ITransformModel transformModel, out Quaternion snapshot)"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace RotationInterpolationUpdater

    namespace RotationTimeline { // "Game.Battle.EntityModel.BattleCharacter.Rotation.RotationTimeline (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t timeline = 0x10; // "TimelineList<RotationData>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t PutLookDirection = 0xCD9CD0; // "public void PutLookDirection(Vector3 lookDirection, long ts)"
            inline constexpr std::uintptr_t PutOrientation = 0xCD9D90; // "public void PutOrientation(Quaternion orientation, long ts)"
            inline constexpr std::uintptr_t Calculate = 0xCD97D0; // "public RotationData Calculate(long ts, long snapshotTimeInterval)"
            inline constexpr std::uintptr_t GetSuitableInterval = 0xCD9B90; // "private void GetSuitableInterval(long ts, int count, out RotationData from, out RotationData to)"
            inline constexpr std::uintptr_t Clamp = 0xCD9B10; // "private static long Clamp(long ts, long min, long max)"
            inline constexpr std::uintptr_t SafeClear = 0xCD9E50; // "public void SafeClear(long relevantTs, int itemsToKeepInCollection)"
            inline constexpr std::uintptr_t get_LastTs = 0xCD9FA0; // "public long get_LastTs()"
        }
    } // namespace RotationTimeline

    namespace RouletteBarterInputUpdater { // "Game.Battle.Entities.Roulette.RouletteInventoryDialog.RouletteBarterInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t uiSoundModel = 0x10; // "GlobalUISoundModel"
            inline constexpr std::uintptr_t currentInventoryModel = 0x18; // "CurrentInventoryModel.RouletteInventory"
            inline constexpr std::uintptr_t playerInventory = 0x20; // "IInventoryModel"
            inline constexpr std::uintptr_t currentTab = 0x28; // "TabData<RouletteInventoryDialogView.RouletteTab>"
            inline constexpr std::uintptr_t barterModel = 0x30; // "RouletteBarterModel"
            inline constexpr std::uintptr_t roomConnection = 0x38; // "IRoomConnection"
            inline constexpr std::uintptr_t modalDialogModel = 0x40; // "ModalDialogModel"
            inline constexpr std::uintptr_t inputActions = 0x48; // "InputActions"
            inline constexpr std::uintptr_t inventoryKeys = 0x50; // "InventoryKeys"
            inline constexpr std::uintptr_t globalLocalizationKeys = 0x58; // "GlobalLocalizationKeys"
            inline constexpr std::uintptr_t personalNotificationModel = 0x60; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t notificationError = 0x68; // "NotificationError"
            inline constexpr std::uintptr_t updaters = 0x70; // "List<IUpdater>"
            inline constexpr std::uintptr_t exchangeButton = 0x78; // "CompositeButtonView"
            inline constexpr std::uintptr_t isRequested = 0x80; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t OnExchangeClick = 0xAF4FA0; // "private void OnExchangeClick()"
            inline constexpr std::uintptr_t OnExchangeConfirm = 0xAF57C0; // "private void OnExchangeConfirm(RouletteChipDescription chipDescription, int amount, bool isSellingChips, int recipeIndex)"
            inline constexpr std::uintptr_t OnRecipeClicked = 0xAF58C0; // "private void OnRecipeClicked(int index)"
            inline constexpr std::uintptr_t Update = 0xAF5910; // "public void Update()"
        }
    } // namespace RouletteBarterInputUpdater

    namespace RouletteTabsClickInputUpdater { // "Game.Battle.Entities.Roulette.RouletteInventoryDialog.RouletteTabsClickInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t currentTab = 0x20; // "TabData<RouletteInventoryDialogView.RouletteTab>"
            inline constexpr std::uintptr_t soundModel = 0x28; // "GlobalUISoundModel"
            inline constexpr std::uintptr_t tabsViews = 0x30; // "List<ChosenTabView<RouletteInventoryDialogView.RouletteTab>>"
            inline constexpr std::uintptr_t wasTab = 0x38; // "RouletteInventoryDialogView.RouletteTab"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xAF93A0; // "public RouletteTabsClickInputUpdater Init(TabData<RouletteInventoryDialogView.RouletteTab> currentTab, GlobalUISoundModel soundModel, List<ChosenTabView<RouletteInventoryDialogView.RouletteTab>> tabsViews)"
            inline constexpr std::uintptr_t Dispose = 0x9F6DA0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xAF9410; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t ClickTab = 0xAF9330; // "private void ClickTab(RouletteInventoryDialogView.RouletteTab tab)"
            inline constexpr std::uintptr_t SetTabActive = 0xAF95B0; // "private void SetTabActive()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace RouletteTabsClickInputUpdater

    namespace SavePlayerPrefsUpdater { // "Game.Global.PlayerPrefsFile.SavePlayerPrefsUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t playerPrefsModel = 0x10; // "ISerializedModel"
            inline constexpr std::uintptr_t localStorage = 0x18; // "ValueFileStorage"
            inline constexpr std::uintptr_t cooldownEndTs = 0x20; // "float"
            inline constexpr std::uintptr_t inProgress = 0x24; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x37A9F20; // "public void Update()"
            inline constexpr std::uintptr_t WriteIntoStorage = 0x37AA0D0; // "private void WriteIntoStorage(IValue data)"
        }
    } // namespace SavePlayerPrefsUpdater

    namespace SceneRotationInputModel { // "Game.Global.CustomizeScene.SceneRotationInputModel (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsActive = 0x10; // "bool"
            inline constexpr std::uintptr_t ClickPosition = 0x14; // "Vector2"
            inline constexpr std::uintptr_t IsClicked = 0x1C; // "bool"
            inline constexpr std::uintptr_t DragDelta = 0x20; // "Vector2"
            inline constexpr std::uintptr_t IsDragged = 0x28; // "bool"
            inline constexpr std::uintptr_t YawInertiaVelocity = 0x2C; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Reset = 0x35FF760; // "public void Reset()"
            inline constexpr std::uintptr_t SetClick = 0x35FF7C0; // "public void SetClick(Vector2 position)"
            inline constexpr std::uintptr_t SetDelta = 0x35FF7D0; // "public void SetDelta(Vector2 delta, bool isDrag, float deltaTime)"
            inline constexpr std::uintptr_t ClearClick = 0xDE97F0; // "public void ClearClick()"
            inline constexpr std::uintptr_t ClearYawDrag = 0x35FF6F0; // "public void ClearYawDrag()"
            inline constexpr std::uintptr_t ClearRollDrag = 0x35FF6E0; // "public void ClearRollDrag()"
            inline constexpr std::uintptr_t EndDrag = 0x7EA480; // "public void EndDrag()"
            inline constexpr std::uintptr_t DecreaseYawDrag = 0x35FF700; // "public void DecreaseYawDrag(float stopTimeSeconds, float deltaTime)"
        }
    } // namespace SceneRotationInputModel

    namespace SceneTattooInputModel { // "Game.Global.CustomizeScene.SceneTattooInputModel (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ShowClothesState = 0x10; // "bool"
            inline constexpr std::uintptr_t ShowFullSetState = 0x11; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetShowClothesState = 0x8BC3B0; // "public void SetShowClothesState(bool state)"
            inline constexpr std::uintptr_t SetShowFullSetState = 0xA98B50; // "public void SetShowFullSetState(bool state)"
            inline constexpr std::uintptr_t Clear = 0xD15670; // "public void Clear()"
        }
    } // namespace SceneTattooInputModel

    namespace ScrollBarterItemsInputUpdater { // "Game.Battle.Entities.Trader.Dialog.ScrollBarterItemsInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t inputActions = 0x10; // "InputActions"
            inline constexpr std::uintptr_t scrollerModel = 0x18; // "RecipeScrollerModel"
            inline constexpr std::uintptr_t recipeRectTransforms = 0x20; // "List<RectTransform>"
            inline constexpr std::uintptr_t views = 0x28; // "List<PointerButtonView>"
            inline constexpr std::uintptr_t scrollRect = 0x30; // "ScrollRect"
            inline constexpr std::uintptr_t capacity = 0x38; // "int"
            inline constexpr std::uintptr_t soundScrollCooldownEndTs = 0x3C; // "float"
            inline constexpr std::uintptr_t isSoundRequested = 0x40; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xAD5490; // "public void Update()"
            inline constexpr std::uintptr_t TrySelectIndex = 0xAD52D0; // "private void TrySelectIndex(int newIndex)"
        }
    } // namespace ScrollBarterItemsInputUpdater

    namespace ScrollInputUpdater { // "Game.Battle.ScrollInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t scroll = 0x10; // "SelectedScrollModel"
            inline constexpr std::uintptr_t lootNext = 0x18; // "InputAction"
            inline constexpr std::uintptr_t lootPrev = 0x20; // "InputAction"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC530A0; // "public void Update()"
        }
    } // namespace ScrollInputUpdater

    namespace SectorInputModel { // "Game.Battle.Emotion.Updaters.SectorInputModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t HoverIndex = 0x10; // "int"
            inline constexpr std::uintptr_t PressedIndex = 0x14; // "int"
            inline constexpr std::uintptr_t IsClicked = 0x18; // "bool"
            inline constexpr std::uintptr_t ClickedIndex = 0x1C; // "int"
            inline constexpr std::uintptr_t IsEnabled = 0x20; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsSectorPressed = 0xCEF9B0; // "public bool get_IsSectorPressed()"
        }
    } // namespace SectorInputModel

    namespace SelectAnimationControllerUpdater { // "Game.Battle.Entities.BattleCharacter.Animations.SelectAnimationControllerUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t animationView = 0x10; // "CharacterAnimationView"
            inline constexpr std::uintptr_t footstepsEventView = 0x18; // "CharacterFootstepsEventView"
            inline constexpr std::uintptr_t battleCharacterModel = 0x20; // "BattleCharacterModel"
            inline constexpr std::uintptr_t animatorControllersPool = 0x28; // "AnimatorControllersPool"
            inline constexpr std::uintptr_t unarmedOverrideController = 0x30; // "AnimatorOverrideController"
            inline constexpr std::uintptr_t currentState = 0x38; // "BattleCharacterAnimatorLayerDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xBF7BF0; // "public void Update()"
            inline constexpr std::uintptr_t UpdateState = 0xBF7880; // "private void UpdateState()"
            inline constexpr std::uintptr_t HasStartStopMovement = 0xBF74C0; // "private bool HasStartStopMovement(BattleCharacterAnimatorLayerDescription state)"
            inline constexpr std::uintptr_t GetFootstepMovementSet = 0xBF6DF0; // "private static int GetFootstepMovementSet(BattleCharacterAnimatorLayerDescription state)"
            inline constexpr std::uintptr_t GetKeepStateLayersMask = 0xBF6F80; // "private int GetKeepStateLayersMask(BattleCharacterAnimatorLayerDescription state)"
            inline constexpr std::uintptr_t StartsCargoLift = 0xBF7810; // "private bool StartsCargoLift(BattleCharacterAnimatorLayerDescription state)"
            inline constexpr std::uintptr_t IsCargo = 0xBF76D0; // "private static bool IsCargo(BattleCharacterAnimatorLayerDescription state)"
            inline constexpr std::uintptr_t GetState = 0xBF7020; // "private BattleCharacterAnimatorLayerDescription GetState()"
        }
    } // namespace SelectAnimationControllerUpdater

    namespace SelectTargetActionItemInputUpdater { // "Game.Battle.Target.SelectTargetActionItemInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t targetModel = 0x10; // "TargetModel"
            inline constexpr std::uintptr_t inputActions = 0x18; // "InputActions.BattleActions"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x9D5F90; // "public void Update()"
        }
    } // namespace SelectTargetActionItemInputUpdater

    namespace SendBattleInputUpdater { // "ClientCore.Prediction.SendBattleInputUpdater.SendBattleInputUpdater (Client.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleInputDataModel = 0x10; // "IBattleInputDataModel"
            inline constexpr std::uintptr_t dataTickModel = 0x18; // "IDataTickModel"
            inline constexpr std::uintptr_t ackSnapshotsModel = 0x20; // "AckSnapshotsModel"
            inline constexpr std::uintptr_t time = 0x28; // "TimeModel"
            inline constexpr std::uintptr_t unreliableSend = 0x30; // "Action<IMessage>"
            inline constexpr std::uintptr_t lastTickIndex = 0x38; // "long"
            inline constexpr std::uintptr_t lastSentInputIndex = 0x40; // "long"
            inline constexpr std::uintptr_t inputsCache = 0x48; // "IBattleInputCache"
            inline constexpr std::uintptr_t battleInputMessage = 0x50; // "BattleInputMessage"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xE77300; // "public void Update()"
            inline constexpr std::uintptr_t SendInput = 0xE77090; // "private void SendInput()"
        }
    } // namespace SendBattleInputUpdater

    namespace SetDrillProlongedAction { // "Game.Battle.Entities.Player.ProlongedActions.SetDrillProlongedAction (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "ProlongedInteractionModel"
            inline constexpr std::uintptr_t worldEntitiesModel = 0x18; // "WorldEntitiesModel"
            inline constexpr std::uintptr_t Label = 0x20; // "LocalizedString"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsActive = 0xB22FE0; // "public bool get_IsActive()"
            inline constexpr std::uintptr_t get_EndTs = 0xB19D10; // "public long get_EndTs()"
            inline constexpr std::uintptr_t get_Duration = 0xB22EB0; // "public long get_Duration()"
            inline constexpr std::uintptr_t Interrupt = 0xB22E00; // "public void Interrupt(BattleInputModel battleInputModel)"
        }
    } // namespace SetDrillProlongedAction

    namespace SetHandcuffToTargetProlongedAction { // "Game.Battle.Entities.Player.ProlongedActions.SetHandcuffToTargetProlongedAction (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "ArrestTargetModel"
            inline constexpr std::uintptr_t Label = 0x18; // "LocalizedString"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsActive = 0xB23010; // "public bool get_IsActive()"
            inline constexpr std::uintptr_t get_EndTs = 0xB22FF0; // "public long get_EndTs()"
            inline constexpr std::uintptr_t get_Duration = 0xB19E80; // "public long get_Duration()"
        }
    } // namespace SetHandcuffToTargetProlongedAction

    namespace SetInputSystem { // "Models.Systems.SetInputSystem (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x4360E00; // "protected override void Tick(ITick tick)"
        }
    } // namespace SetInputSystem

    namespace SetMovementModel { // "Game.Battle.EntityModel.BattleCharacter.Movement.SetMovementModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t X = 0x10; // "float"
            inline constexpr std::uintptr_t Y = 0x14; // "float"
            inline constexpr std::uintptr_t Z = 0x18; // "float"
            inline constexpr std::uintptr_t Vx = 0x1C; // "float"
            inline constexpr std::uintptr_t Vz = 0x20; // "float"
            inline constexpr std::uintptr_t Ts = 0x28; // "long"
            inline constexpr std::uintptr_t IsExtrapolate = 0x30; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Set = 0xCDA300; // "public void Set(MovementData data)"
            inline constexpr std::uintptr_t get_IsDefault = 0xCDA330; // "public bool get_IsDefault()"
        }
    } // namespace SetMovementModel

    namespace SettingsKeyboardInputActionUpdater { // "Game.Global.SettingsDialog.CompositeUpdaters.SettingsKeyboardInputActionUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t updaters = 0x20; // "List<IUpdater>"
            inline constexpr std::uintptr_t hotkeyUpdaters = 0x28; // "List<IUpdater>"
            inline constexpr std::uintptr_t playSoundUITab = 0x30; // "Action"
            inline constexpr std::uintptr_t onCopyRealmIdClicked = 0x38; // "Action"
            inline constexpr std::uintptr_t confirm = 0x40; // "Action"
            inline constexpr std::uintptr_t battleRoom = 0x48; // "string"
            inline constexpr std::uintptr_t view = 0x50; // "KeyboardMouseSettingsView"
            inline constexpr std::uintptr_t settingsModel = 0x58; // "IScreenModel"
            inline constexpr std::uintptr_t gameSetting = 0x60; // "GameSetting"
            inline constexpr std::uintptr_t globalModel = 0x68; // "GlobalModel"
            inline constexpr std::uintptr_t tabsModel = 0x70; // "SettingsTabsModel"
            inline constexpr std::uintptr_t localizationKeys = 0x78; // "GlobalLocalizationKeys"
            inline constexpr std::uintptr_t realmIdFormat = 0x80; // "Text<LocalizedString, string, int>"
            inline constexpr std::uintptr_t Handlers = 0x88; // "ValueTuple<InputMask, IUpdater>[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Priority = 0x7E5DA0; // "public InputHandlerPriority get_Priority()"
            inline constexpr std::uintptr_t Init = 0x375C8B0; // "public SettingsKeyboardInputActionUpdater Init(GlobalModel globalModel, NetworkStatusModel networkStatusModel, KeyboardMouseSettingsView view, InputActions inputActions, GlobalLocalizationKeys localizationKeys, SettingsTabsModel tabsModel, ResolutionViewDescription resolutionViewDescription, GameConfig gameConfig, UpdaterPool updaterPool, IRegisterDisposable disposable, GlobalScreenContent globalScreenContent, SettingsPreset settingsPreset)"
            inline constexpr std::uintptr_t OnUpdate = 0x375D700; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Dispose = 0x375C790; // "protected override void Dispose()"
            inline constexpr std::uintptr_t PlaySoundUITab = 0x375D740; // "private void PlaySoundUITab()"
            inline constexpr std::uintptr_t OnCopyRealmIdClicked = 0x375D4F0; // "private void OnCopyRealmIdClicked()"
            inline constexpr std::uintptr_t Confirm = 0x375C700; // "private void Confirm()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace SettingsKeyboardInputActionUpdater

    namespace SettingsTouchInputActionUpdater { // "Game.Global.SettingsDialog.CompositeUpdaters.SettingsTouchInputActionUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t updaters = 0x20; // "List<IUpdater>"
            inline constexpr std::uintptr_t playSoundUITab = 0x28; // "Action"
            inline constexpr std::uintptr_t onCopyRealmIdClicked = 0x30; // "Action"
            inline constexpr std::uintptr_t confirm = 0x38; // "Action"
            inline constexpr std::uintptr_t globalModel = 0x40; // "GlobalModel"
            inline constexpr std::uintptr_t globalScreenContent = 0x48; // "GlobalScreenContent"
            inline constexpr std::uintptr_t settingsModel = 0x50; // "IScreenModel"
            inline constexpr std::uintptr_t gameSetting = 0x58; // "GameSetting"
            inline constexpr std::uintptr_t realmIdFormat = 0x60; // "Text<LocalizedString, string, int>"
            inline constexpr std::uintptr_t Handlers = 0x68; // "ValueTuple<InputMask, IUpdater>[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0x375DC20; // "public SettingsTouchInputActionUpdater Init(GlobalModel globalModel, NetworkStatusModel networkStatusModel, TouchSettingsDialogView view, InputActions inputActions, SettingsKeys settingsKeys, SettingsTabsModel tabsModel, GlobalScreenContent globalScreenContent, SettingsPreset settingsPreset, GameConfig gameConfig, UpdaterPool updaterPool, IRegisterDisposable disposable)"
            inline constexpr std::uintptr_t Dispose = 0x375DB60; // "protected override void Dispose()"
            inline constexpr std::uintptr_t PlaySoundUITab = 0x375E800; // "private void PlaySoundUITab()"
            inline constexpr std::uintptr_t OnCopyRealmIdClicked = 0x375E5D0; // "private void OnCopyRealmIdClicked()"
            inline constexpr std::uintptr_t Confirm = 0x375DB00; // "private void Confirm()"
            inline constexpr std::uintptr_t get_Priority = 0x7E5DA0; // "public InputHandlerPriority get_Priority()"
        }
    } // namespace SettingsTouchInputActionUpdater

    namespace ShelvingKeyboardInputHandler { // "Game.Battle.Entities.Shelving.ShelvingKeyboardInputHandler (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t updater = 0x10; // "IUpdater"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xADAFB0; // "public void Update()"
        }
    } // namespace ShelvingKeyboardInputHandler

    namespace ShelvingTouchInputHandler { // "Game.Battle.Entities.Shelving.ShelvingTouchInputHandler (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t updater = 0x10; // "IUpdater"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xAFC460; // "public void Update()"
        }
    } // namespace ShelvingTouchInputHandler

    namespace ShootingDebugSettings { // "Game.Battle.EntityModel.Player.Debug.ShootingDebugSettings (Battle.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x823C928; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t Spread = 0x0; // "ShootingDebugSettings.BoolPref"
            inline constexpr std::uintptr_t ReloadTimer = 0x8; // "ShootingDebugSettings.BoolPref"
            inline constexpr std::uintptr_t AimDistance = 0x10; // "ShootingDebugSettings.BoolPref"
            inline constexpr std::uintptr_t Tracers = 0x18; // "ShootingDebugSettings.BoolPref"
            inline constexpr std::uintptr_t Recoil = 0x20; // "ShootingDebugSettings.BoolPref"
            inline constexpr std::uintptr_t ShotBlock = 0x28; // "ShootingDebugSettings.BoolPref"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_SpreadEnabled = 0xC98810; // "public static bool get_SpreadEnabled()"
            inline constexpr std::uintptr_t set_SpreadEnabled = 0xC98A60; // "public static void set_SpreadEnabled(bool value)"
            inline constexpr std::uintptr_t get_ReloadTimerEnabled = 0xC98750; // "public static bool get_ReloadTimerEnabled()"
            inline constexpr std::uintptr_t set_ReloadTimerEnabled = 0xC989A0; // "public static void set_ReloadTimerEnabled(bool value)"
            inline constexpr std::uintptr_t get_AimDistanceEnabled = 0xC98690; // "public static bool get_AimDistanceEnabled()"
            inline constexpr std::uintptr_t set_AimDistanceEnabled = 0xC988E0; // "public static void set_AimDistanceEnabled(bool value)"
            inline constexpr std::uintptr_t get_TracersEnabled = 0xC98880; // "public static bool get_TracersEnabled()"
            inline constexpr std::uintptr_t set_TracersEnabled = 0xC98AC0; // "public static void set_TracersEnabled(bool value)"
            inline constexpr std::uintptr_t get_RecoilEnabled = 0xC986F0; // "public static bool get_RecoilEnabled()"
            inline constexpr std::uintptr_t set_RecoilEnabled = 0xC98940; // "public static void set_RecoilEnabled(bool value)"
            inline constexpr std::uintptr_t get_ShotBlockEnabled = 0xC987B0; // "public static bool get_ShotBlockEnabled()"
            inline constexpr std::uintptr_t set_ShotBlockEnabled = 0xC98A00; // "public static void set_ShotBlockEnabled(bool value)"
            inline constexpr std::uintptr_t get_TracerLifetime = 0xC98870; // "public static float get_TracerLifetime()"
            inline constexpr std::uintptr_t set_TracerLifetime = 0x7B3360; // "public static void set_TracerLifetime(float value)"
        }
    } // namespace ShootingDebugSettings

    namespace ShootingDebugSettings_BoolPref { // "Game.Battle.EntityModel.Player.Debug.ShootingDebugSettings.BoolPref (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t key = 0x10; // "string"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Value = 0x7EC9F0; // "public bool get_Value()"
            inline constexpr std::uintptr_t set_Value = 0x7B3360; // "public void set_Value(bool value)"
        }
    } // namespace ShootingDebugSettings_BoolPref

    namespace SingleUseItem { // "Game.Battle.EntityModel.BattleCharacter.Equipment.SingleUseItem (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleCharacterModel = 0x10; // "BattleCharacterModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t CheckUseItemContext = 0xCDA7B0; // "public bool CheckUseItemContext(IItemMoveContext from)"
            inline constexpr std::uintptr_t CheckRequirement = 0xCDA360; // "public bool CheckRequirement(IItemMoveContext itemContext, long now)"
        }
    } // namespace SingleUseItem

    namespace SkeletonConfig { // "Models.References.Character.SkeletonConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t BonesCount = 0x10; // "int"
            inline constexpr std::uintptr_t BoneDataSize = 0x14; // "int"
            inline constexpr std::uintptr_t BoneDataLocalPositionOrientationOffset = 0x18; // "int"
            inline constexpr std::uintptr_t BoneDataModelOrientationOffset = 0x1C; // "int"
            inline constexpr std::uintptr_t BoneDataLengthOffset = 0x20; // "int"
            inline constexpr std::uintptr_t BonesHierarchyData = 0x28; // "int[]"
            inline constexpr std::uintptr_t BonesHierarchyMaxChildrenCount = 0x30; // "int"
            inline constexpr std::uintptr_t RootIndex = 0x34; // "int"
            inline constexpr std::uintptr_t LegsIndex = 0x38; // "int"
            inline constexpr std::uintptr_t Spine2Index = 0x3C; // "int"
            inline constexpr std::uintptr_t Spine3Index = 0x40; // "int"
            inline constexpr std::uintptr_t NeckIndex = 0x44; // "int"
            inline constexpr std::uintptr_t Head1Index = 0x48; // "int"
            inline constexpr std::uintptr_t Head2Index = 0x4C; // "int"
        }
    } // namespace SkeletonConfig

    namespace SkinCenterCharacterContext { // "Game.Global.SkinCenter.Context.SkinCenterCharacterContext (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t globalModel = 0x10; // "GlobalModel"
            inline constexpr std::uintptr_t dialogModel = 0x18; // "SkinCenterDialogModel"
            inline constexpr std::uintptr_t tabDescription = 0x20; // "CharacterTabDescription"
            inline constexpr std::uintptr_t enumValue = 0x28; // "ITemporaryIdentified"
            inline constexpr std::uintptr_t imprisonmentYearsModel = 0x30; // "ImprisonmentYearsModel"
            inline constexpr std::uintptr_t cellsViewDescriptions = 0x38; // "ReadOnlyDictionaryNonAlloc<string, ISkinCenterCellViewDescription>"
            inline constexpr std::uintptr_t emptyCell = 0x40; // "ISkinCenterCellViewDescription"
            inline constexpr std::uintptr_t CellDescription = 0x48; // "SkinCenterCellSizesViewDescription.CellDescription"
            inline constexpr std::uintptr_t IsClicked = 0x50; // "bool"
            inline constexpr std::uintptr_t IsBeganHover = 0x51; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Cell = 0x36512A0; // "public ISkinCenterCellViewDescription get_Cell()"
            inline constexpr std::uintptr_t get_Rarity = 0x3651370; // "public RarityItem get_Rarity()"
            inline constexpr std::uintptr_t get_Selected = 0x7EC9F0; // "public bool get_Selected()"
            inline constexpr std::uintptr_t get_Confirmed = 0x7EC9F0; // "public bool get_Confirmed()"
            inline constexpr std::uintptr_t get_IsOwned = 0x7D5050; // "public bool get_IsOwned()"
            inline constexpr std::uintptr_t get_NeedDebt = 0x7EC9F0; // "public bool get_NeedDebt()"
            inline constexpr std::uintptr_t get_Index = 0x7E3AB0; // "public int get_Index()"
            inline constexpr std::uintptr_t get_Name = 0x7E3AB0; // "public LocalizedString get_Name()"
            inline constexpr std::uintptr_t get_HasParts = 0x7EC9F0; // "public bool get_HasParts()"
            inline constexpr std::uintptr_t get_OwnedParts = 0x7E3AB0; // "public int get_OwnedParts()"
            inline constexpr std::uintptr_t get_MaxParts = 0x7E3AB0; // "public int get_MaxParts()"
            inline constexpr std::uintptr_t get_HasCoins = 0x7EC9F0; // "public bool get_HasCoins()"
            inline constexpr std::uintptr_t get_Coins = 0xACDA50; // "public Money get_Coins()"
            inline constexpr std::uintptr_t get_NeedImprisonment = 0x7EC9F0; // "public bool get_NeedImprisonment()"
            inline constexpr std::uintptr_t get_NeedAchievement = 0x7EC9F0; // "public bool get_NeedAchievement()"
            inline constexpr std::uintptr_t get_NeedPack = 0x7EC9F0; // "public bool get_NeedPack()"
            inline constexpr std::uintptr_t get_NeedBattlePass = 0x7EC9F0; // "public bool get_NeedBattlePass()"
            inline constexpr std::uintptr_t get_NewlyUnlockedCount = 0x3651320; // "public int get_NewlyUnlockedCount()"
            inline constexpr std::uintptr_t GetEmptyIconBySexData = 0x3650FA0; // "public Sprite GetEmptyIconBySexData(CharacterSexDescription sexData)"
            inline constexpr std::uintptr_t GetIconBySexData = 0x36510A0; // "public Sprite GetIconBySexData(CharacterSexDescription sexData)"
            inline constexpr std::uintptr_t OnSelect = 0x3651130; // "public void OnSelect()"
            inline constexpr std::uintptr_t OnBeginHover = 0x7B3360; // "public void OnBeginHover()"
        }
    } // namespace SkinCenterCharacterContext

    namespace SkinCenterCharacterRotationConstrainModelUpdater { // "Game.Global.SkinCenter.Scene.SkinCenterCharacterRotationConstrainModelUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t rotationModel = 0x10; // "CustomizeSceneRotationModel"
            inline constexpr std::uintptr_t constrainView = 0x18; // "SkinCenterRotationConstrainView"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x3624000; // "public void Update()"
        }
    } // namespace SkinCenterCharacterRotationConstrainModelUpdater

    namespace SkinCenterCharacterRotationResetModelUpdater { // "Game.Global.SkinCenter.Scene.SkinCenterCharacterRotationResetModelUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t rotationModel = 0x10; // "CustomizeSceneRotationModel"
            inline constexpr std::uintptr_t rotateView = 0x18; // "SkinCenterRotationView"
            inline constexpr std::uintptr_t currentViewDescription = 0x20; // "WeaponBaseViewDescription"
            inline constexpr std::uintptr_t currentSkinId = 0x28; // "string"
            inline constexpr std::uintptr_t currentBaseId = 0x30; // "string"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x3624040; // "public void Update()"
        }
    } // namespace SkinCenterCharacterRotationResetModelUpdater

    namespace SkinCenterCharacterRotationResetOnSexSwitchModelUpdater { // "Game.Global.SkinCenter.UI.ModelUpdaters.SkinCenterCharacterRotationResetOnSexSwitchModelUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dialogModel = 0x10; // "SkinCenterDialogModel"
            inline constexpr std::uintptr_t skinCenterSceneModel = 0x18; // "SkinCenterSceneModel"
            inline constexpr std::uintptr_t wasSex = 0x20; // "CharacterSexDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x3612AC0; // "public void Update()"
        }
    } // namespace SkinCenterCharacterRotationResetOnSexSwitchModelUpdater

    namespace SkinCenterCharacterSexByTabModelUpdater { // "Game.Global.SkinCenter.UI.ModelUpdaters.SkinCenterCharacterSexByTabModelUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dialogModel = 0x10; // "SkinCenterDialogModel"
            inline constexpr std::uintptr_t skinCenterSceneModel = 0x18; // "SkinCenterSceneModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x3612BA0; // "public void Update()"
        }
    } // namespace SkinCenterCharacterSexByTabModelUpdater

    namespace SkinCenterCharacterShadowModelUpdater { // "Game.Global.SkinCenter.Scene.SkinCenterCharacterShadowModelUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t skinCenterSceneModel = 0x10; // "SkinCenterSceneModel"
            inline constexpr std::uintptr_t maleShadow = 0x18; // "CharacterShadowModel"
            inline constexpr std::uintptr_t femaleShadow = 0x20; // "CharacterShadowModel"
            inline constexpr std::uintptr_t shadowModel = 0x28; // "ShadowModel"
            inline constexpr std::uintptr_t lastSex = 0x30; // "CharacterSexDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x36240B0; // "public void Update()"
        }
    } // namespace SkinCenterCharacterShadowModelUpdater

    namespace SkinCenterCharactersVisibleModelUpdater { // "Game.Global.SkinCenter.UI.ModelUpdaters.SkinCenterCharactersVisibleModelUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dialogModel = 0x10; // "SkinCenterDialogModel"
            inline constexpr std::uintptr_t skinCenterSceneModel = 0x18; // "SkinCenterSceneModel"
            inline constexpr std::uintptr_t character = 0x20; // "CharacterTemporaryModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x3612EC0; // "public void Update()"
            inline constexpr std::uintptr_t IsCharacterVisible = 0x3612CF0; // "private bool IsCharacterVisible(SkinCenterTab tab)"
        }
    } // namespace SkinCenterCharactersVisibleModelUpdater

    namespace SkinCenterCoinsInputRules { // "Game.Global.SkinCenter.UI.Inputs.SkinCenterCoinsInputRules (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t globalModel = 0x10; // "GlobalModel"
            inline constexpr std::uintptr_t localizationKeys = 0x18; // "GlobalLocalizationKeys"
            inline constexpr std::uintptr_t cryptoCoinsPackViewDescriptions = 0x20; // "CryptoCoinsPackViewDescriptions"
            inline constexpr std::uintptr_t inputActions = 0x28; // "InputActions.BattleActions"
            inline constexpr std::uintptr_t isInProgress = 0x30; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t OnCoinsPackClicked = 0x3625020; // "public void OnCoinsPackClicked(CryptoCoinsPackDescription coinsPackToBuy)"
            inline constexpr std::uintptr_t OnCoinsPackClickConfirmed = 0x3624F50; // "private void OnCoinsPackClickConfirmed(TransactionDescription transaction)"
        }
    } // namespace SkinCenterCoinsInputRules

    namespace SkinCenterRotationInputModelUpdater { // "Game.Global.SkinCenter.UI.ModelUpdaters.SkinCenterRotationInputModelUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dialogModel = 0x10; // "SkinCenterDialogModel"
            inline constexpr std::uintptr_t swipeCharacterModel = 0x18; // "SceneRotationInputModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x36329C0; // "public void Update()"
        }
    } // namespace SkinCenterRotationInputModelUpdater

    namespace SkinCenterRotationInputUpdater { // "Game.Global.SkinCenter.Scene.SkinCenterRotationInputUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t clickInputView = 0x10; // "CameraClickInputView"
            inline constexpr std::uintptr_t dragInputView = 0x18; // "CameraDragInputView"
            inline constexpr std::uintptr_t sceneRotationInputModel = 0x20; // "SceneRotationInputModel"
            inline constexpr std::uintptr_t wasDragged = 0x28; // "bool"
            inline constexpr std::uintptr_t lastDragPosition = 0x2C; // "Vector2"
            inline constexpr std::uintptr_t lastDelta = 0x34; // "Vector2"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x3632AB0; // "public void Update()"
        }
    } // namespace SkinCenterRotationInputUpdater

    namespace SkinCenterSceneInputClickUpdater { // "Game.Global.SkinCenter.Scene.SkinCenterSceneInputClickUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t sceneView = 0x10; // "SkinCenterSceneView"
            inline constexpr std::uintptr_t skinCenterDialogModel = 0x18; // "SkinCenterSceneModel"
            inline constexpr std::uintptr_t swipeCharacterModel = 0x20; // "SceneRotationInputModel"
            inline constexpr std::uintptr_t uiSoundModel = 0x28; // "GlobalUISoundModel"
            inline constexpr std::uintptr_t layerMask = 0x30; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x3634870; // "public void Update()"
        }
    } // namespace SkinCenterSceneInputClickUpdater

    namespace SkinCenterShopPacksInputRules { // "Game.Global.SkinCenter.UI.Inputs.SkinCenterShopPacksInputRules (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dialogModel = 0x10; // "SkinCenterDialogModel"
            inline constexpr std::uintptr_t shopPacksModel = 0x18; // "SkinCenterShopPacksModel"
            inline constexpr std::uintptr_t globalModel = 0x20; // "GlobalModel"
            inline constexpr std::uintptr_t shopPackOwnership = 0x28; // "ShopPackOwnershipModel"
            inline constexpr std::uintptr_t cryptoCoinsModel = 0x30; // "ICoinsReadonlyModel"
            inline constexpr std::uintptr_t coinsModel = 0x38; // "ICoinsReadonlyModel"
            inline constexpr std::uintptr_t localizationKeys = 0x40; // "GlobalLocalizationKeys"
            inline constexpr std::uintptr_t viewDescriptions = 0x48; // "SkinCenterShopPacksViewDescriptions"
            inline constexpr std::uintptr_t cryptoCoinsPackViewDescriptions = 0x50; // "CryptoCoinsPackViewDescriptions"
            inline constexpr std::uintptr_t roomConnection = 0x58; // "IRoomConnection"
            inline constexpr std::uintptr_t buyCryptoRoomConnection = 0x60; // "IRoomConnection"
            inline constexpr std::uintptr_t buyPackDescription = 0x68; // "Text<string>"
            inline constexpr std::uintptr_t buyPackPartsDescription = 0x70; // "Text<string, Money>"
            inline constexpr std::uintptr_t buyPackButtonText = 0x78; // "Text<Money>"
            inline constexpr std::uintptr_t packPurchasedDescription = 0x80; // "Text<string>"
            inline constexpr std::uintptr_t inputActions = 0x88; // "InputActions.BattleActions"
            inline constexpr std::uintptr_t isInProgress = 0x90; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t OnPackPreview = 0x363A9A0; // "public void OnPackPreview()"
            inline constexpr std::uintptr_t OnSexSwitch = 0x363ABC0; // "public void OnSexSwitch()"
            inline constexpr std::uintptr_t OnArrowRight = 0x363A1E0; // "public void OnArrowRight()"
            inline constexpr std::uintptr_t OnArrowLeft = 0x363A1D0; // "public void OnArrowLeft()"
            inline constexpr std::uintptr_t SwitchWeapon = 0x363AFC0; // "private void SwitchWeapon(int offset)"
            inline constexpr std::uintptr_t OnBuyPack = 0x363A2D0; // "public void OnBuyPack()"
            inline constexpr std::uintptr_t BuyCryptoCoins = 0x36392D0; // "private void BuyCryptoCoins(int needCryptoCoins)"
            inline constexpr std::uintptr_t GetBuyPackDescription = 0x3639B50; // "private IText GetBuyPackDescription(ShopPackDescription pack)"
            inline constexpr std::uintptr_t HasOwnedItems = 0x3639CF0; // "private bool HasOwnedItems(ShopPackDescription pack)"
            inline constexpr std::uintptr_t OnBuyPackConfirmed = 0x363A1F0; // "private void OnBuyPackConfirmed(ShopPackDescription pack, bool isFeatured)"
            inline constexpr std::uintptr_t CreateBuyMessage = 0x3639390; // "private static IMessage CreateBuyMessage(ShopPackDescription pack, bool isFeatured)"
            inline constexpr std::uintptr_t ReloadPacksIfPriceOutDated = 0x363AC30; // "private void ReloadPacksIfPriceOutDated(IValue error)"
            inline constexpr std::uintptr_t ShowPackPurchasedDialog = 0x363AD40; // "private void ShowPackPurchasedDialog(ShopPackDescription pack)"
            inline constexpr std::uintptr_t CreatePackPurchasedItems = 0x3639430; // "private List<ModalLayoutItemModel> CreatePackPurchasedItems()"
            inline constexpr std::uintptr_t OnPackPurchasedDialogClosed = 0x363AB70; // "private void OnPackPurchasedDialogClosed()"
            inline constexpr std::uintptr_t MarkPackContentsUnlocked = 0x3639E80; // "private void MarkPackContentsUnlocked(UnlockedSkinsPrefsModel unlockedSkinsPrefsModel, HashSet<ShopPackItemDescription> pack)"
            inline constexpr std::uintptr_t GatherNewContentDeliveredByPack = 0x3639900; // "private HashSet<ShopPackItemDescription> GatherNewContentDeliveredByPack(ShopPackDescription pack, ShopPackOwnershipModel ownership)"
        }
    } // namespace SkinCenterShopPacksInputRules

    namespace SkinCenterTattooToggleInputUpdater { // "Game.Global.SkinCenter.UI.Inputs.SkinCenterTattooToggleInputUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t soundModel = 0x10; // "GlobalUISoundModel"
            inline constexpr std::uintptr_t dialogModel = 0x18; // "SkinCenterDialogModel"
            inline constexpr std::uintptr_t toggleView = 0x20; // "ToggleStateView"
            inline constexpr std::uintptr_t toggleAction = 0x28; // "Action<bool>"
            inline constexpr std::uintptr_t value = 0x30; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x363D810; // "public void Update()"
        }
    } // namespace SkinCenterTattooToggleInputUpdater

    namespace SliderInputFieldModel { // "Game.Global.ModalDialog.SliderInputFieldModel (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Text = 0x28; // "LocalizedString"
            inline constexpr std::uintptr_t ThousandsSeparator = 0x30; // "bool"
            inline constexpr std::uintptr_t InputFieldChanged = 0x31; // "bool"
            inline constexpr std::uintptr_t IsFocused = 0x32; // "bool"
        }
    } // namespace SliderInputFieldModel

    namespace SliderInputFieldUpdater { // "Game.Global.ModalDialog.SliderInputFieldUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t fieldModel = 0x20; // "SliderInputFieldModel"
            inline constexpr std::uintptr_t fieldView = 0x28; // "SliderInputFieldView"
            inline constexpr std::uintptr_t previousValue = 0x30; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0x358E800; // "public SliderInputFieldUpdater Init(SliderInputFieldModel fieldModel, SliderInputFieldView fieldView)"
            inline constexpr std::uintptr_t Dispose = 0x92B5C0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0x358E950; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t ParseInputFieldValue = 0x358EAB0; // "private void ParseInputFieldValue()"
            inline constexpr std::uintptr_t SetValue = 0x358EC70; // "private void SetValue(int value)"
            inline constexpr std::uintptr_t SetValueClampMinMax = 0x358EB10; // "private void SetValueClampMinMax(int value)"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace SliderInputFieldUpdater

    namespace SliderInputUpdater { // "Game.Global.ModalDialog.SliderInputUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t sliderModel = 0x20; // "SliderModel"
            inline constexpr std::uintptr_t sliderView = 0x28; // "SliderView"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0x9F7740; // "public SliderInputUpdater Init(SliderModel sliderModel, SliderView sliderView)"
            inline constexpr std::uintptr_t Dispose = 0x92B5C0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0x358F200; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace SliderInputUpdater

    namespace SprintCameraShakeUpdater { // "Game.Battle.EntityModel.Player.SprintCameraShakeUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t sprint = 0x10; // "SprintModel"
            inline constexpr std::uintptr_t sprintCamera = 0x18; // "CinemachineVirtualCamera"
            inline constexpr std::uintptr_t character = 0x20; // "CharacterControllerModel"
            inline constexpr std::uintptr_t perlin = 0x28; // "CinemachineBasicMultiChannelPerlin"
            inline constexpr std::uintptr_t rotationInput = 0x30; // "PlayerRotationInputModel"
            inline constexpr std::uintptr_t velocityModel = 0x38; // "CharacterVelocityModel"
            inline constexpr std::uintptr_t stateModel = 0x40; // "IBattleCharacterStateModel"
            inline constexpr std::uintptr_t isSprinting = 0x48; // "bool"
            inline constexpr std::uintptr_t amplitudeFactor = 0x4C; // "float"
            inline constexpr std::uintptr_t fovFactor = 0x50; // "float"
            inline constexpr std::uintptr_t maxAmplitudeGain = 0x54; // "float"
            inline constexpr std::uintptr_t maxFov = 0x58; // "float"
            inline constexpr std::uintptr_t minFov = 0x5C; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC7FD90; // "public void Update()"
        }
    } // namespace SprintCameraShakeUpdater

    namespace SprintInputDescription { // "Models.References.Input.SprintInputDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x82609F8; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t enum_id = 0x0; // "Enum<SprintInputDescription>"
            inline constexpr std::uintptr_t Enable = 0x8; // "SprintInputDescription"
            inline constexpr std::uintptr_t Disable = 0x10; // "SprintInputDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Enum = 0x441C200; // "public static ReadOnlyEnum<SprintInputDescription> get_Enum()"
        }
    } // namespace SprintInputDescription

    namespace SprintInputRules { // "Game.Battle.Inputs.SprintInputRules (Battle.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t IsSprint = 0xA99E30; // "public static bool IsSprint(Vector2 move)"
        }
    } // namespace SprintInputRules

    namespace SprintInputUpdater { // "Game.Battle.Inputs.SprintInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t sprintInputModel = 0x10; // "InputModel"
            inline constexpr std::uintptr_t sprintIntentionModel = 0x18; // "InputIntentionModel"
            inline constexpr std::uintptr_t shotInputLockModel = 0x20; // "ShotInputLockModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x28; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t battleInputModel = 0x30; // "BattleInputModel"
            inline constexpr std::uintptr_t moveModel = 0x38; // "PlayerMovementInputModel"
            inline constexpr std::uintptr_t personalNotificationModel = 0x40; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t unavailableKeys = 0x48; // "UnavailableTargetActionsKeys"
            inline constexpr std::uintptr_t wasSprintTriggered = 0x50; // "bool"
            inline constexpr std::uintptr_t wasShotSprintTargetState = 0x51; // "bool"
            inline constexpr std::uintptr_t isSprintIntentionLocked = 0x52; // "bool"
            inline constexpr std::uintptr_t wasEmotionActive = 0x53; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA9A810; // "public void Update()"
            inline constexpr std::uintptr_t NotifySprintWithCargo = 0xA9A4E0; // "private void NotifySprintWithCargo(bool wasIntention, bool hasIntention, BattleCharacterModel server)"
            inline constexpr std::uintptr_t CanSprint = 0xA99F70; // "private bool CanSprint()"
            inline constexpr std::uintptr_t UpdateSprintIntentionLock = 0xA9A760; // "private void UpdateSprintIntentionLock(bool isEmotionActive, bool isSprintTargetState)"
            inline constexpr std::uintptr_t IsSprintCancelRequested = 0xA9A0D0; // "private bool IsSprintCancelRequested()"
            inline constexpr std::uintptr_t UpdateSprintData = 0xA9A5C0; // "private void UpdateSprintData(bool isSprintTriggered, bool isSprintTargetState)"
            inline constexpr std::uintptr_t UpdateSprintInput = 0xA9A600; // "private void UpdateSprintInput(BattleCharacterModel server, bool isSprintTargetState, bool isEmotionActive)"
            inline constexpr std::uintptr_t UpdateShotLock = 0xA9A570; // "private void UpdateShotLock(bool isShotSprintTargetState)"
            inline constexpr std::uintptr_t IsSprintTargetStateCheckDirection = 0xA9A280; // "private bool IsSprintTargetStateCheckDirection(bool isSprintTriggered, bool isSprintInterrupt)"
            inline constexpr std::uintptr_t IsTargetStatePressMode = 0xA9A490; // "private bool IsTargetStatePressMode(bool isSprintTriggered, bool isSprintInterruptActive)"
            inline constexpr std::uintptr_t IsTargetStateHoldMode = 0xA9A460; // "private bool IsTargetStateHoldMode(bool isSprintTriggered, bool isSprintInterruptActive)"
            inline constexpr std::uintptr_t IsSprintInterrupt = 0xA9A110; // "private bool IsSprintInterrupt(WeaponReloadModel weaponReload, IntentionModel reloadIntention, SurrenderModel surrenderModel, ItemActionProcessModel itemActionProcess, CrouchModel crouch)"
        }
    } // namespace SprintInputUpdater

    namespace SprintModel { // "Models.Models.Sprint.SprintModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t endTs = 0x10; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t isActive = 0x18; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t cooldownEndTs = 0x20; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t transitionTime = 0x28; // "long"
            inline constexpr std::uintptr_t cooldownTime = 0x30; // "long"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_TransitionEndTs = 0x48C5510; // "public long get_TransitionEndTs()"
            inline constexpr std::uintptr_t get_IsActive = 0x48C53C0; // "public bool get_IsActive()"
            inline constexpr std::uintptr_t Start = 0x48C5030; // "public void Start(long now)"
            inline constexpr std::uintptr_t Stop = 0x48C5240; // "public void Stop()"
            inline constexpr std::uintptr_t SetTransitionEndTs = 0x48C4F20; // "private void SetTransitionEndTs(long now)"
            inline constexpr std::uintptr_t StopTransition = 0x48C51B0; // "public void StopTransition()"
            inline constexpr std::uintptr_t get_IsCooldown = 0x48C5410; // "public bool get_IsCooldown()"
            inline constexpr std::uintptr_t get_CooldownEndTs = 0x48C5370; // "public long get_CooldownEndTs()"
            inline constexpr std::uintptr_t StartCooldown = 0x48C4FD0; // "public void StartCooldown(long now)"
            inline constexpr std::uintptr_t StopCooldown = 0x48C5120; // "public void StopCooldown()"
            inline constexpr std::uintptr_t get_IsInTransition = 0x48C5490; // "public bool get_IsInTransition()"
        }
    } // namespace SprintModel

    namespace SprintSystem { // "Models.Systems.SprintSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t worldInterruptModel = 0x38; // "IWorldInterruptModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x4362AC0; // "protected override void Tick(ITick tick)"
        }
    } // namespace SprintSystem

    namespace SprintTouchInputUpdater { // "Game.Battle.Inputs.SprintTouchInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t inputModel = 0x10; // "InputModel"
            inline constexpr std::uintptr_t moveDpadView = 0x18; // "MoveDpadView"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA9AF70; // "public void Update()"
        }
    } // namespace SprintTouchInputUpdater

    namespace SqrDistanceUpdater { // "Game.Battle.Player.SqrDistanceUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleEntitiesModel = 0x10; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t battleModel = 0x18; // "BattleModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x9753B0; // "public void Update()"
            inline constexpr std::uintptr_t SqrDistance = 0x975370; // "private float SqrDistance(float x1, float y1, float z1, float x2, float y2, float z2)"
        }
    } // namespace SqrDistanceUpdater

    namespace StateAnimationModel { // "Game.Battle.EntityModel.Player.StateAnimationModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t TimeFalling = 0x10; // "float"
            inline constexpr std::uintptr_t State = 0x14; // "CharacterAnimationView.State"
        }
    } // namespace StateAnimationModel

    namespace StateEventBehavior { // "Game.Battle.Entities.BattleCharacter.StateEventBehavior (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t state = 0x18; // "AnimatorId.State"
            inline constexpr std::uintptr_t registerStateOnlyIfWeightGreaterThanZero = 0x1C; // "bool"
            inline constexpr std::uintptr_t customEvents = 0x20; // "List<StateEventBehavior.CustomEvent>"
            inline constexpr std::uintptr_t motionTime = 0x28; // "string"
            inline constexpr std::uintptr_t assistant = 0x30; // "AnimationStateAssistant"
            inline constexpr std::uintptr_t isInited = 0x38; // "bool"
            inline constexpr std::uintptr_t isEntered = 0x39; // "bool"
            inline constexpr std::uintptr_t lastUpdateNT = 0x3C; // "float"
            inline constexpr std::uintptr_t motionTimeParam = 0x40; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t OnStateEnter = 0xBD0ED0; // "public override void OnStateEnter(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)"
            inline constexpr std::uintptr_t OnStateUpdate = 0xBD1180; // "public override void OnStateUpdate(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)"
            inline constexpr std::uintptr_t OnStateExit = 0xBD1050; // "public override void OnStateExit(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)"
            inline constexpr std::uintptr_t GetNormalizedTime = 0xBD0DF0; // "private float GetNormalizedTime(Animator animator, AnimatorStateInfo stateInfo)"
            inline constexpr std::uintptr_t Initialize = 0xBD0E30; // "private void Initialize(Animator animator)"
        }
    } // namespace StateEventBehavior

    namespace StateEventBehavior_CustomEvent { // "Game.Battle.Entities.BattleCharacter.StateEventBehavior.CustomEvent (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Event = 0x0; // "AnimatorId.Event"
            inline constexpr std::uintptr_t NormalizedTime = 0x4; // "float"
        }
    } // namespace StateEventBehavior_CustomEvent

    namespace StopCrouchTransitionSystem { // "Models.Systems.StopCrouchTransitionSystem (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x43663C0; // "protected override void Tick(ITick tick)"
        }
    } // namespace StopCrouchTransitionSystem

    namespace StopRoomByPlayersCountConfig { // "Models.References.StopRoomByPlayersCount.StopRoomByPlayersCountConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t CheckPeriod = 0x10; // "long"
            inline constexpr std::uintptr_t PlayersDisconnectTime = 0x18; // "long"
            inline constexpr std::uintptr_t MinPlayersCount = 0x20; // "int"
        }
    } // namespace StopRoomByPlayersCountConfig

    namespace StopRoomByPlayersCountPreset { // "Models.References.StopRoomByPlayersCountPreset (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x82751E0; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace Fields {
            inline constexpr std::uintptr_t CheckPeriod = 0x10; // "long"
            inline constexpr std::uintptr_t PlayersDisconnectTime = 0x18; // "long"
            inline constexpr std::uintptr_t MinPlayersCount = 0x20; // "int"
        }
        namespace StaticFields {
            inline constexpr std::uintptr_t Default = 0x0; // "StopRoomByPlayersCountPreset"
            inline constexpr std::uintptr_t Disabled = 0x8; // "StopRoomByPlayersCountPreset"
        }
    } // namespace StopRoomByPlayersCountPreset

    namespace StopSprintSystem { // "Models.Systems.StopSprintSystem (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x4366B00; // "protected override void Tick(ITick tick)"
            inline constexpr std::uintptr_t ShouldStopSprint = 0x43669A0; // "private bool ShouldStopSprint(IMoveDirectionModel moveDirectionModel, CharacterControllerModel character, BattleCharacterDamageZoneModel battleCharacterDamageZone)"
        }
    } // namespace StopSprintSystem

    namespace StopSprintTransitionSystem { // "Models.Systems.StopSprintTransitionSystem (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x4366C20; // "protected override void Tick(ITick tick)"
        }
    } // namespace StopSprintTransitionSystem

    namespace SwapInputCommandUpdater { // "Game.Battle.Inputs.SwapInputCommandUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t sprintInputModel = 0x10; // "InputModel"
            inline constexpr std::uintptr_t aimInputModel = 0x18; // "InputModel"
            inline constexpr std::uintptr_t crouchInputModel = 0x20; // "InputModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x28; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t battleInputModel = 0x30; // "BattleInputModel"
            inline constexpr std::uintptr_t sprintIntentionModel = 0x38; // "InputIntentionModel"
            inline constexpr std::uintptr_t oldSprintTriggered = 0x40; // "bool"
            inline constexpr std::uintptr_t oldSprintIntention = 0x41; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA9B120; // "public void Update()"
            inline constexpr std::uintptr_t CheckSprintAvailable = 0xA9B0E0; // "private bool CheckSprintAvailable(ItemActionProcessModel itemActionProcess)"
        }
    } // namespace SwapInputCommandUpdater

    namespace TakeCashProlongedAction { // "Game.Battle.Entities.Player.ProlongedActions.TakeCashProlongedAction (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "ProlongedInteractionModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x18; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t worldEntitiesModel = 0x20; // "WorldEntitiesModel"
            inline constexpr std::uintptr_t Label = 0x28; // "LocalizedString"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsActive = 0xB25660; // "public bool get_IsActive()"
            inline constexpr std::uintptr_t get_EndTs = 0xB19D10; // "public long get_EndTs()"
            inline constexpr std::uintptr_t get_Duration = 0xB25620; // "public long get_Duration()"
            inline constexpr std::uintptr_t Interrupt = 0xB254C0; // "public void Interrupt(BattleInputModel battleInputModel)"
            inline constexpr std::uintptr_t GetDuration = 0xB251B0; // "private long GetDuration(int entityId)"
        }
    } // namespace TakeCashProlongedAction

    namespace TalkCameraFadeUpdater { // "Game.Battle.Entities.Player.Talks.Updaters.TalkCameraFadeUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t view = 0x10; // "TalkDialogView"
            inline constexpr std::uintptr_t model = 0x18; // "TalkInternalModel"
            inline constexpr std::uintptr_t dialogModel = 0x20; // "TalkDialogModel"
            inline constexpr std::uintptr_t camera = 0x28; // "Camera"
            inline constexpr std::uintptr_t talkDialogSceneView = 0x30; // "TalkDialogSceneView"
            inline constexpr std::uintptr_t startNode = 0x38; // "RuntimeNode"
            inline constexpr std::uintptr_t now = 0x40; // "INow"
            inline constexpr std::uintptr_t startTime = 0x48; // "long"
            inline constexpr std::uintptr_t sundownStopTime = 0x50; // "long"
            inline constexpr std::uintptr_t nightStopTime = 0x58; // "long"
            inline constexpr std::uintptr_t dawnStopTime = 0x60; // "long"
            inline constexpr std::uintptr_t state = 0x68; // "TalkCameraFadeUpdater.State"
            inline constexpr std::uintptr_t isHidden = 0x6C; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB25FD0; // "public void Update()"
            inline constexpr std::uintptr_t UpdateHiddenState = 0xB25F50; // "private void UpdateHiddenState()"
            inline constexpr std::uintptr_t Dispose = 0xB25EC0; // "private void Dispose()"
        }
    } // namespace TalkCameraFadeUpdater

    namespace TalkDescription { // "Game.Battle.Entities.Player.Talks.TalkDescription (Battle.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x81838C8; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t enum_id = 0x0; // "Enum<TalkDescription>"
            inline constexpr std::uintptr_t None = 0x8; // "TalkDescription"
            inline constexpr std::uintptr_t Igla = 0x10; // "TalkDescription"
            inline constexpr std::uintptr_t Lenny = 0x18; // "TalkDescription"
            inline constexpr std::uintptr_t Officer = 0x20; // "TalkDescription"
            inline constexpr std::uintptr_t MiniMarket = 0x28; // "TalkDescription"
            inline constexpr std::uintptr_t GasStation = 0x30; // "TalkDescription"
            inline constexpr std::uintptr_t ElectronicStore = 0x38; // "TalkDescription"
            inline constexpr std::uintptr_t Pharmacy = 0x40; // "TalkDescription"
            inline constexpr std::uintptr_t Cafe = 0x48; // "TalkDescription"
            inline constexpr std::uintptr_t EquipShop = 0x50; // "TalkDescription"
            inline constexpr std::uintptr_t WeaponShop = 0x58; // "TalkDescription"
            inline constexpr std::uintptr_t Bank = 0x60; // "TalkDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Get = 0xB265C0; // "public static TalkDescription Get(string id)"
            inline constexpr std::uintptr_t get_CanTalk = 0xB26D00; // "public bool get_CanTalk()"
        }
    } // namespace TalkDescription

    namespace TalkGraphCloseUpdater { // "Game.Battle.Entities.Player.Talks.Updaters.TalkGraphCloseUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "TalkInternalModel"
            inline constexpr std::uintptr_t dialogModel = 0x18; // "TalkDialogModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB285E0; // "public void Update()"
        }
    } // namespace TalkGraphCloseUpdater

    namespace TalkGraphNodeUpdater { // "Game.Battle.Entities.Player.Talks.Updaters.TalkGraphNodeUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t globalModel = 0x10; // "GlobalModel"
            inline constexpr std::uintptr_t battleModel = 0x18; // "BattleModel"
            inline constexpr std::uintptr_t model = 0x20; // "TalkInternalModel"
            inline constexpr std::uintptr_t npcNodesFilter = 0x28; // "List<NpcContextNode>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB29AD0; // "public void Update()"
            inline constexpr std::uintptr_t TryAdd = 0xB29880; // "private void TryAdd(NpcContextNode node)"
            inline constexpr std::uintptr_t GetConditionResult = 0xB287B0; // "private bool GetConditionResult(RuntimeNode node)"
            inline constexpr std::uintptr_t GetResult = 0xB28AF0; // "private bool GetResult(BooleanNode node)"
            inline constexpr std::uintptr_t GetResult_2 = 0xB28D50; // "private bool GetResult(ComparerNode node)"
            inline constexpr std::uintptr_t GetResult_3 = 0xB29370; // "private ValueData GetResult(PlayerRefNode node)"
            inline constexpr std::uintptr_t GetResult_4 = 0xB28C40; // "private bool GetResult(RangeNode node)"
            inline constexpr std::uintptr_t GetBoolInputValue = 0xB28620; // "private bool GetBoolInputValue(RuntimeNode node)"
            inline constexpr std::uintptr_t GetCustomInputValue = 0xB28940; // "private ValueData GetCustomInputValue(RuntimeNode node)"
            inline constexpr std::uintptr_t GetInvalidCast = 0xB28A30; // "private static Exception GetInvalidCast(RuntimeNode node)"
        }
    } // namespace TalkGraphNodeUpdater

    namespace TalkGraphNpcContextUpdater { // "Game.Battle.Entities.Player.Talks.Updaters.TalkGraphNpcContextUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "TalkInternalModel"
            inline constexpr std::uintptr_t view = 0x18; // "TalkDialogView"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB2A020; // "public void Update()"
        }
    } // namespace TalkGraphNpcContextUpdater

    namespace TalkGraphPlayerContextUpdater { // "Game.Battle.Entities.Player.Talks.Updaters.TalkGraphPlayerContextUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "TalkInternalModel"
            inline constexpr std::uintptr_t view = 0x18; // "TalkDialogView"
            inline constexpr std::uintptr_t localizationKeys = 0x20; // "TalkLocalizationKeys"
            inline constexpr std::uintptr_t useHintViewDescription = 0x28; // "UseHintViewDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB2A160; // "public void Update()"
            inline constexpr std::uintptr_t GetIconHint = 0xB2A130; // "private IconHintEnum GetIconHint(PlayerContextNode playerContextNode)"
        }
    } // namespace TalkGraphPlayerContextUpdater

    namespace TalkHelper { // "Game.Battle.Entities.Player.Talks.TalkHelper (Battle.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t TalkAction = 0xB2AFB0; // "public static void TalkAction(BattleModel battleModel, TalkViewDescriptions description, TalkDescription talkDescription, LocalizedString targetName, int entityId, TalkDialogSceneView talkDialogSceneView)"
            inline constexpr std::uintptr_t ValidateTalkAction = 0xB2B520; // "public static bool ValidateTalkAction(BattleCharacterModel player, WorldEntitiesModel worldEntitiesModel, TalkViewDescriptions description, TargetAction action, UnavailableTargetActionsKeys unavailableKeys, TalkDescription talkDescription, LocalizedString talkInappropriateRole, VigilantNpcModel vigilantNpcModel)"
            inline constexpr std::uintptr_t GetAvailableForRoleDescription = 0xB2A960; // "private static LocalizedString GetAvailableForRoleDescription(UnavailableTargetActionsKeys unavailableKeys, List<IdentifiedProperty<PlayerRoleDescription>> talkRoles)"
            inline constexpr std::uintptr_t OnDrawTalkCameraGizmos = 0xB2AE50; // "public static void OnDrawTalkCameraGizmos(GameObject camera)"
            inline constexpr std::uintptr_t IsNpcBuildingInAlarm = 0xB2ADB0; // "internal static bool IsNpcBuildingInAlarm(WorldEntitiesModel worldEntitiesModel, VigilantNpcModel vigilantNpcModel)"
            inline constexpr std::uintptr_t IsTalkAvailable = 0xB2ADC0; // "internal static bool IsTalkAvailable(VigilantNpcModel model)"
            inline constexpr std::uintptr_t TriggerVariant = 0xB2B080; // "internal static void TriggerVariant(TalkInternalModel model, TalkDialogModel dialogModel, RuntimeNode node)"
            inline constexpr std::uintptr_t GetIconHint = 0xB2AB00; // "internal static string GetIconHint(UseHintViewDescription description, IconHintEnum hint)"
            inline constexpr std::uintptr_t ManualSkipTalkPhrase = 0xB2ADF0; // "internal static void ManualSkipTalkPhrase(TalkInternalModel model, TalkDialogView view)"
            inline constexpr std::uintptr_t CanVariantInput = 0xB2A920; // "internal static bool CanVariantInput(TalkInternalModel model, TalkDialogView view)"
            inline constexpr std::uintptr_t InverseLerp = 0xB2AD70; // "internal static float InverseLerp(long from, long to, long time)"
        }
    } // namespace TalkHelper

    namespace TalkHideUpdater { // "Game.Battle.Entities.Player.Talks.Updaters.TalkHideUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t talkDialogModel = 0x10; // "TalkDialogModel"
            inline constexpr std::uintptr_t talkInternalModel = 0x18; // "TalkInternalModel"
            inline constexpr std::uintptr_t view = 0x20; // "TalkDialogView"
            inline constexpr std::uintptr_t isHidden = 0x28; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB2B900; // "public void Update()"
        }
    } // namespace TalkHideUpdater

    namespace TalkInternalModel { // "Game.Battle.Entities.Player.Talks.TalkInternalModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t stack = 0x10; // "Stack<RuntimeNode>"
            inline constexpr std::uintptr_t Added = 0x18; // "HashSet<RuntimeNode>"
            inline constexpr std::uintptr_t Npc = 0x20; // "NpcContextNode"
            inline constexpr std::uintptr_t Variants = 0x28; // "List<RuntimeNode>"
            inline constexpr std::uintptr_t HasCloseIntention = 0x30; // "bool"
            inline constexpr std::uintptr_t Updated = 0x31; // "bool"
            inline constexpr std::uintptr_t Select = 0x34; // "int"
            inline constexpr std::uintptr_t NpcPhrase = 0x38; // "NpcPhrase"
            inline constexpr std::uintptr_t PrintState = 0x40; // "PrintPhraseState"
            inline constexpr std::uintptr_t Symbols = 0x44; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t MoveTo = 0xB2BAE0; // "public void MoveTo(RuntimeNode node)"
            inline constexpr std::uintptr_t MoveToBack = 0xB2B990; // "public void MoveToBack()"
            inline constexpr std::uintptr_t SetPhrase = 0xB2BBC0; // "public void SetPhrase(NpcPhrase phrase)"
        }
    } // namespace TalkInternalModel

    namespace TalkPlayerDisableUpdater { // "Game.Battle.Entities.Player.Talks.Updaters.TalkPlayerDisableUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleEntitiesModel = 0x10; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t talkDialogModel = 0x18; // "TalkDialogModel"
            inline constexpr std::uintptr_t personalNotificationModel = 0x20; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t uiSoundModel = 0x28; // "GlobalUISoundModel"
            inline constexpr std::uintptr_t unavailableKeys = 0x30; // "UnavailableTargetActionsKeys"
            inline constexpr std::uintptr_t vigilantNpcModel = 0x38; // "VigilantNpcModel"
            inline constexpr std::uintptr_t health = 0x40; // "int"
            inline constexpr std::uintptr_t closing = 0x44; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB2D0E0; // "public void Update()"
            inline constexpr std::uintptr_t NpcDisabled = 0xB2D0A0; // "private bool NpcDisabled(VigilantNpcModel vigilantNpcModel)"
            inline constexpr std::uintptr_t CloseWithNotification = 0xB2D010; // "private void CloseWithNotification(LocalizedString localizedString)"
        }
    } // namespace TalkPlayerDisableUpdater

    namespace TalkSelectMouseKeyboardVariantInputUpdater { // "Game.Battle.Entities.Player.Talks.Updaters.TalkSelectMouseKeyboardVariantInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "TalkInternalModel"
            inline constexpr std::uintptr_t view = 0x18; // "TalkDialogView"
            inline constexpr std::uintptr_t inputActions = 0x20; // "InputActions.BattleActions"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB2D480; // "public void Update()"
        }
    } // namespace TalkSelectMouseKeyboardVariantInputUpdater

    namespace TalkSelectVariantInputUpdater { // "Game.Battle.Entities.Player.Talks.Updaters.TalkSelectVariantInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t inputModel = 0x10; // "InputModel"
            inline constexpr std::uintptr_t button = 0x18; // "PointerButtonView"
            inline constexpr std::uintptr_t model = 0x20; // "TalkInternalModel"
            inline constexpr std::uintptr_t dialogModel = 0x28; // "TalkDialogModel"
            inline constexpr std::uintptr_t buttonIndex = 0x30; // "int"
            inline constexpr std::uintptr_t triggerMode = 0x34; // "PointerTriggerMode"
            inline constexpr std::uintptr_t isTriggered = 0x38; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB2D6B0; // "public void Update()"
            inline constexpr std::uintptr_t ConsumeClicked = 0xA969C0; // "private bool ConsumeClicked(PointerButtonView button)"
        }
    } // namespace TalkSelectVariantInputUpdater

    namespace TalkUseVariantInputUpdater { // "Game.Battle.Entities.Player.Talks.Updaters.TalkUseVariantInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "TalkInternalModel"
            inline constexpr std::uintptr_t dialogModel = 0x18; // "TalkDialogModel"
            inline constexpr std::uintptr_t view = 0x20; // "TalkDialogView"
            inline constexpr std::uintptr_t useInputModel = 0x28; // "InputModel"
            inline constexpr std::uintptr_t backInputModel = 0x30; // "InputModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB2DB10; // "public void Update()"
        }
    } // namespace TalkUseVariantInputUpdater

    namespace TargetCharacterRules { // "Game.Battle.Entities.Player.TargetCharacterRules (Battle.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x8185BD0; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t DefaultMask = 0x0; // "int"
            inline constexpr std::uintptr_t Mask = 0x4; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t GetTargetDistance = 0xB16390; // "public static float GetTargetDistance(IsHiddenModel hiddenModel, IWeaponModel weaponModel, WeaponViewDescriptions weaponViewDescriptions)"
            inline constexpr std::uintptr_t GetOverlayDistance = 0xB16270; // "public static float GetOverlayDistance(IsHiddenModel hiddenModel, IWeaponModel weaponModel, AimingModel aimingModel, WeaponViewDescriptions weaponViewDescriptions)"
        }
    } // namespace TargetCharacterRules

    namespace TaxCollectionPrefsData { // "Game.Global.PlayerPrefsFile.TaxCollectionPrefsData (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t TaxSettlementCooldownEndTs = 0x20; // "ReferenceMapData<SectorDescription, ReferenceMapData<SettlementDescription, TimestampData>>"
            inline constexpr std::uintptr_t TaxClanCooldownEndTs = 0x28; // "TimestampData"
        }
    } // namespace TaxCollectionPrefsData

    namespace TeleportRotationUpdater { // "Game.Battle.EntityModel.Player.TeleportRotationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleEntitiesModel = 0x10; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t playerRotationInput = 0x18; // "PlayerRotationInputModel"
            inline constexpr std::uintptr_t player = 0x20; // "PlayerEntityModel"
            inline constexpr std::uintptr_t rotationModel = 0x28; // "CharacterRotationModel"
            inline constexpr std::uintptr_t transform = 0x30; // "ITransformModel"
            inline constexpr std::uintptr_t teleportTs = 0x38; // "IPrimitiveModel<long>"
            inline constexpr std::uintptr_t desiredYawModel = 0x40; // "DesiredYawModel"
            inline constexpr std::uintptr_t desiredYawServerModel = 0x48; // "DesiredYawModel"
            inline constexpr std::uintptr_t lookDirection = 0x50; // "LookDirectionModel"
            inline constexpr std::uintptr_t stateModel = 0x58; // "IBattleCharacterStateModel"
            inline constexpr std::uintptr_t lastTeleportTs = 0x60; // "long"
            inline constexpr std::uintptr_t lastCharacterState = 0x68; // "BattleCharacterState"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC80290; // "public void Update()"
            inline constexpr std::uintptr_t InitPlayerUpdaters = 0xC800D0; // "private void InitPlayerUpdaters()"
        }
    } // namespace TeleportRotationUpdater

    namespace ThirdPersonPlayerRotationUpdater { // "Game.Battle.EntityModel.Player.Rotation.ThirdPersonPlayerRotationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t rotationTransform = 0x10; // "Transform"
            inline constexpr std::uintptr_t rotationInputModel = 0x18; // "PlayerRotationInputModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC804F0; // "public void Update()"
        }
    } // namespace ThirdPersonPlayerRotationUpdater

    namespace TouchActionHoldInputUpdater { // "Game.Battle.Inputs.TouchActionHoldInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t inputModel = 0x10; // "InputHoldModel"
            inline constexpr std::uintptr_t pointerButtonView = 0x18; // "HoldPointerButtonView"
            inline constexpr std::uintptr_t isTouch = 0x20; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA85DA0; // "public void Update()"
        }
    } // namespace TouchActionHoldInputUpdater

    namespace TouchInputUpdater { // "Game.Battle.Map.TouchInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t mapDialogModel = 0x10; // "MapDialogModel"
            inline constexpr std::uintptr_t uiSoundModel = 0x18; // "BattleUISoundModel"
            inline constexpr std::uintptr_t contextActionRules = 0x20; // "GeneralContextActionRules"
            inline constexpr std::uintptr_t realmBattleStateModel = 0x28; // "RealmBattleStateModel"
            inline constexpr std::uintptr_t realmInfoModel = 0x30; // "RealmInfoModel"
            inline constexpr std::uintptr_t globalUISoundModel = 0x38; // "GlobalUISoundModel"
            inline constexpr std::uintptr_t isRequest = 0x40; // "bool"
            inline constexpr std::uintptr_t Handlers = 0x48; // "ValueTuple<InputMask, IUpdater>[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t ReportSettlementName = 0x9C3B50; // "private void ReportSettlementName()"
            inline constexpr std::uintptr_t OnClickObjectivesPanelToggleVisibility = 0x9B1960; // "private void OnClickObjectivesPanelToggleVisibility()"
            inline constexpr std::uintptr_t CloseMap = 0x952750; // "private void CloseMap()"
            inline constexpr std::uintptr_t CloseMapObjectInfoPanel = 0x9B1930; // "private void CloseMapObjectInfoPanel()"
            inline constexpr std::uintptr_t get_Priority = 0x7E5DA0; // "public InputHandlerPriority get_Priority()"
        }
    } // namespace TouchInputUpdater

    namespace TouchMoneyLaunderingInputHandler { // "Game.Battle.Entities.Plot.Dialog.Input.TouchMoneyLaunderingInputHandler (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t updaters = 0x20; // "List<IUpdater>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xB16810; // "public TouchMoneyLaunderingInputHandler Init(int modelEntityId, CoinsAccessModel coinsAccessModel, MoneyLaunderingDialogModel model, BattleModel battleModel, GlobalModel globalModel, GlobalScreenContent globalScreenContent, IRoomConnection battleConnection, MoneyLaunderingDialogView view, ClientMoneyWorkbenchModel clientMoneyWorkbenchModel, IMoneyWorkbenchModel moneyWorkbenchModel, BattleScreenContent content, UpdaterPool updaterPool, IRegisterDisposable registerDisposable)"
            inline constexpr std::uintptr_t Dispose = 0xB167B0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0x94CF50; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace TouchMoneyLaunderingInputHandler

    namespace TouchPlayerContextMenuInputHandler { // "Game.Battle.PlayerContextMenu.InputHandlers.TouchPlayerContextMenuInputHandler (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Handlers = 0x10; // "ValueTuple<InputMask, IUpdater>[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Priority = 0x7E5D90; // "public InputHandlerPriority get_Priority()"
        }
    } // namespace TouchPlayerContextMenuInputHandler

    namespace TouchQuickSlotsInputUpdater { // "Game.Battle.Inputs.TouchQuickSlotsInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t quickSlotsInputModel = 0x10; // "QuickSlotsInputModel"
            inline constexpr std::uintptr_t battleInputModel = 0x18; // "BattleInputModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x20; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t personalNotificationModel = 0x28; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t unavailableKeys = 0x30; // "UnavailableTargetActionsKeys"
            inline constexpr std::uintptr_t triggeredSlot = 0x38; // "QuickSlotDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA9C7D0; // "public void Update()"
            inline constexpr std::uintptr_t GetTriggeredSlot = 0xA9C560; // "private QuickSlotDescription GetTriggeredSlot()"
            inline constexpr std::uintptr_t ClearInput = 0xA9C490; // "private void ClearInput()"
        }
    } // namespace TouchQuickSlotsInputUpdater

    namespace TouchResetSprintCargoUpdater { // "Game.Battle.Inputs.TouchResetSprintCargoUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t sprintInputModel = 0x10; // "InputModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x18; // "IBattleEntitiesModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA9CB90; // "public void Update()"
        }
    } // namespace TouchResetSprintCargoUpdater

    namespace TouchShooterLookInputUpdater { // "Game.Battle.Inputs.Updaters.Touch.TouchShooterLookInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t pitchThreshold = 0x10; // "float"
            inline constexpr std::uintptr_t playerRotationInput = 0x18; // "PlayerRotationInputModel"
            inline constexpr std::uintptr_t sensitivityModel = 0x20; // "SensitivityModel"
            inline constexpr std::uintptr_t lookView = 0x28; // "LookView"
            inline constexpr std::uintptr_t shotRight = 0x30; // "PointerButtonView"
            inline constexpr std::uintptr_t shotRightLookView = 0x38; // "LookView"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA9CC20; // "public void Update()"
        }
    } // namespace TouchShooterLookInputUpdater

    namespace TouchSkinCenterZoomInputUpdater { // "Game.Global.SkinCenter.UI.Inputs.TouchSkinCenterZoomInputUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t zoomModel = 0x10; // "ZoomModel"
            inline constexpr std::uintptr_t dragInputView = 0x18; // "CameraDragInputView"
            inline constexpr std::uintptr_t wasZooming = 0x20; // "bool"
            inline constexpr std::uintptr_t wasFingersDistance = 0x24; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x363E280; // "public void Update()"
        }
    } // namespace TouchSkinCenterZoomInputUpdater

    namespace TraderSplitInputUpdater { // "Game.Battle.ShopSplit.TraderSplitInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t splitModel = 0x10; // "ShopSplitModel"
            inline constexpr std::uintptr_t sliderModel = 0x18; // "SliderModel"
            inline constexpr std::uintptr_t oldValue = 0x20; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x9F3EB0; // "public void Update()"
        }
    } // namespace TraderSplitInputUpdater

    namespace UnlockedSkinsData { // "Game.Global.PlayerPrefsFile.UnlockedSkinsData (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t CarsUnlocked = 0x20; // "SetData<CarDescription>"
            inline constexpr std::uintptr_t HelicoptersUnlocked = 0x28; // "SetData<HelicopterDescription>"
            inline constexpr std::uintptr_t WeaponSkinsUnlocked = 0x30; // "SetData<WeaponSkinDescription>"
            inline constexpr std::uintptr_t EmotionsUnlocked = 0x38; // "SetData<EmotionDescription>"
            inline constexpr std::uintptr_t BodySkinsUnlocked = 0x40; // "SetData<CharacterBodyDescription>"
            inline constexpr std::uintptr_t FBodySkinsUnlocked = 0x48; // "SetData<CharacterFBodyDescription>"
            inline constexpr std::uintptr_t BagSkinsUnlocked = 0x50; // "SetData<CharacterBagDescription>"
            inline constexpr std::uintptr_t MaskSkinsUnlocked = 0x58; // "SetData<CharacterMaskDescription>"
            inline constexpr std::uintptr_t KeychainsUnlocked = 0x60; // "SetData<CharacterKeychainDescription>"
        }
    } // namespace UnlockedSkinsData

    namespace UnlockedSkinsPrefsModel { // "Game.Global.PlayerPrefsFile.UnlockedSkinsPrefsModel (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "UnlockedSkinsData"
            inline constexpr std::uintptr_t Bodies = 0x18; // "UnlockedSkinsCategoryPrefsModel<CharacterBodyDescription>"
            inline constexpr std::uintptr_t FBodies = 0x20; // "UnlockedSkinsCategoryPrefsModel<CharacterFBodyDescription>"
            inline constexpr std::uintptr_t Masks = 0x28; // "UnlockedSkinsCategoryPrefsModel<CharacterMaskDescription>"
            inline constexpr std::uintptr_t Bags = 0x30; // "UnlockedSkinsCategoryPrefsModel<CharacterBagDescription>"
            inline constexpr std::uintptr_t Keychains = 0x38; // "UnlockedSkinsCategoryPrefsModel<CharacterKeychainDescription>"
            inline constexpr std::uintptr_t Emotions = 0x40; // "UnlockedSkinsCategoryPrefsModel<EmotionDescription>"
            inline constexpr std::uintptr_t Cars = 0x48; // "UnlockedSkinsCategoryPrefsModel<CarDescription>"
            inline constexpr std::uintptr_t Helicopters = 0x50; // "UnlockedSkinsCategoryPrefsModel<HelicopterDescription>"
            inline constexpr std::uintptr_t WeaponSkins = 0x58; // "UnlockedSkinsCategoryPrefsModel<WeaponSkinDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_CountCharacterBodies = 0x37AF900; // "public int get_CountCharacterBodies()"
            inline constexpr std::uintptr_t get_CountCharacterFBodies = 0x37AF950; // "public int get_CountCharacterFBodies()"
            inline constexpr std::uintptr_t get_CountCharacterBags = 0x37AF8B0; // "public int get_CountCharacterBags()"
            inline constexpr std::uintptr_t get_CountCharacterMasks = 0x37AF9F0; // "public int get_CountCharacterMasks()"
            inline constexpr std::uintptr_t get_CountCharacterKeychains = 0x37AF9A0; // "public int get_CountCharacterKeychains()"
            inline constexpr std::uintptr_t get_CountEmotions = 0x37AFC20; // "public int get_CountEmotions()"
            inline constexpr std::uintptr_t get_CountCars = 0x37AF860; // "public int get_CountCars()"
            inline constexpr std::uintptr_t get_CountHelicopters = 0x37AFC70; // "public int get_CountHelicopters()"
            inline constexpr std::uintptr_t get_CountWeaponSkins = 0x37AFD60; // "public int get_CountWeaponSkins()"
            inline constexpr std::uintptr_t get_CountCharacterWithEmotions = 0x37AFA40; // "public int get_CountCharacterWithEmotions()"
            inline constexpr std::uintptr_t get_CountVehicles = 0x37AFCC0; // "public int get_CountVehicles()"
            inline constexpr std::uintptr_t get_CountAllSkins = 0x37AF760; // "public int get_CountAllSkins()"
        }
    } // namespace UnlockedSkinsPrefsModel

    namespace UnlockProlongedAction { // "Game.Battle.Entities.Player.ProlongedActions.UnlockProlongedAction (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "ProlongedInteractionModel"
            inline constexpr std::uintptr_t deferredOpenModel = 0x18; // "DeferredOpenModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x20; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t searchLabel = 0x28; // "LocalizedString"
            inline constexpr std::uintptr_t unlockLabel = 0x30; // "LocalizedString"
            inline constexpr std::uintptr_t entityId = 0x38; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Label = 0xB2EEB0; // "public LocalizedString get_Label()"
            inline constexpr std::uintptr_t get_IsActive = 0xB2EEA0; // "public bool get_IsActive()"
            inline constexpr std::uintptr_t get_EndTs = 0xB19D10; // "public long get_EndTs()"
            inline constexpr std::uintptr_t get_Duration = 0xB2EE60; // "public long get_Duration()"
            inline constexpr std::uintptr_t get_UsePredictExtraTime = 0x7D5050; // "public bool get_UsePredictExtraTime()"
            inline constexpr std::uintptr_t Interrupt = 0xB2ED60; // "public void Interrupt(BattleInputModel battleInputModel)"
            inline constexpr std::uintptr_t UpdateInterruptData = 0xB2EE30; // "public void UpdateInterruptData()"
            inline constexpr std::uintptr_t GetUnlockDuration = 0xB2EA60; // "private long GetUnlockDuration(int entityId)"
        }
    } // namespace UnlockProlongedAction

    namespace UpdateCharactersRuntimeModelsUpdater { // "ClientCore.Updaters.UpdateCharactersRuntimeModelsUpdater (Client.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dataModels = 0x10; // "IDataModels"
            inline constexpr std::uintptr_t updatedEntitiesModel = 0x18; // "IUpdatedEntitiesModel"
            inline constexpr std::uintptr_t playerEntityId = 0x20; // "int"
            inline constexpr std::uintptr_t time = 0x28; // "TimeModel"
            inline constexpr std::uintptr_t contentCacheModel = 0x30; // "ContentCacheModel"
            inline constexpr std::uintptr_t battleCharacters = 0x38; // "ReadOnly.Dictionary<int, BattleCharacterModel>"
            inline constexpr std::uintptr_t vehicles = 0x40; // "ReadOnly.Dictionary<int, VehicleModel>"
            inline constexpr std::uintptr_t updatedCharactersByTickIndex = 0x48; // "Dictionary<int, long>"
            inline constexpr std::uintptr_t lastServerUpdateTs = 0x50; // "long"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xE7B8C0; // "public void Update()"
            inline constexpr std::uintptr_t UpdateCharacterByVehicleSeat = 0xE7B7B0; // "private void UpdateCharacterByVehicleSeat(BattleCharacterModel battleCharacterModel)"
            inline constexpr std::uintptr_t NeedUpdateCharacter = 0xE7B580; // "private bool NeedUpdateCharacter(BattleCharacterModel battleCharacterModel, IDataModel characterDataModel, out long newDataTickIndex)"
            inline constexpr std::uintptr_t IsCharacterChanged = 0xE7B320; // "private bool IsCharacterChanged(BattleCharacterModel battleCharacterModel, IDataModel characterDataModel, out long newTickIndex)"
            inline constexpr std::uintptr_t IsCharacterVehicleChanged = 0xE7B410; // "private bool IsCharacterVehicleChanged(BattleCharacterModel battleCharacterModel, out long newTickIndex)"
        }
    } // namespace UpdateCharactersRuntimeModelsUpdater

    namespace UpdateSimulatedCharactersRuntimeModelsUpdater { // "Game.Battle.UpdateSimulatedCharactersRuntimeModelsUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleEntitiesModel = 0x10; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t time = 0x18; // "TimeModel"
            inline constexpr std::uintptr_t contentCacheModel = 0x20; // "ContentCacheModel"
            inline constexpr std::uintptr_t battleCharacters = 0x28; // "ReadOnly.Dictionary<int, BattleCharacterModel>"
            inline constexpr std::uintptr_t vehicles = 0x30; // "ReadOnly.Dictionary<int, VehicleModel>"
            inline constexpr std::uintptr_t cars = 0x38; // "ReadOnly.Dictionary<int, CarModel>"
            inline constexpr std::uintptr_t helicopters = 0x40; // "ReadOnly.Dictionary<int, HelicopterModel>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC5D950; // "public void Update()"
            inline constexpr std::uintptr_t UpdateCharacterByVehicleSeat = 0xC5D7B0; // "private void UpdateCharacterByVehicleSeat(long simulatedTickIndex, BattleCharacterModel battleCharacterModel)"
            inline constexpr std::uintptr_t TryGetCharacterSimulatedModel = 0xC5D3F0; // "private bool TryGetCharacterSimulatedModel(int entityId, out BattleCharacterModel battleCharacterModel)"
            inline constexpr std::uintptr_t TryGetVehiclePivotTransform = 0xC5D580; // "private bool TryGetVehiclePivotTransform(int vehicleEntityId, long simulatedTickIndex, out Vector3 pivotWorldPosition, out Quaternion pivotWorldOrientation)"
        }
    } // namespace UpdateSimulatedCharactersRuntimeModelsUpdater

    namespace UseEntityCommandDescription { // "Models.References.Input.UseEntityCommandDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x81E76E8; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace Fields {
            inline constexpr std::uintptr_t CheckInteract = 0x20; // "bool"
        }
        namespace StaticFields {
            inline constexpr std::uintptr_t enum_id = 0x0; // "Enum<UseEntityCommandDescription>"
            inline constexpr std::uintptr_t UnlockStart = 0x8; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t UnlockStartWithLockpick = 0x10; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t UnlockStop = 0x18; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t Open = 0x20; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t Close = 0x28; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t EnterVehicle = 0x30; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t StartLeaveVehicle = 0x38; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t StopLeaveVehicle = 0x40; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t TakeLootStart = 0x48; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t TakeLootStop = 0x50; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t ArrestStart = 0x58; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t ArrestStop = 0x60; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t InterruptArrestingStart = 0x68; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t InterruptArrestingStop = 0x70; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t TakeLootNodeStart = 0x78; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t TakeLootNodeStop = 0x80; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t ReviveCharacterStart = 0x88; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t ReviveCharacterStop = 0x90; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t BreakCollider = 0x98; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t RefillEquipStart = 0xA0; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t RefillEquipStop = 0xA8; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t ArrestLootStart = 0xB0; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t ArrestLootStop = 0xB8; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t TakeCargoStart = 0xC0; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t TakeCargoStop = 0xC8; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t SetDrillStart = 0xD0; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t SetDrillStop = 0xD8; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t RemoveDrillStart = 0xE0; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t RemoveDrillStop = 0xE8; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t GetAccessStart = 0xF0; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t GetAccessStop = 0xF8; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t ResetAccessStart = 0x100; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t ResetAccessStop = 0x108; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t CloseSafeStart = 0x110; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t CloseSafeStop = 0x118; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t UseSwitch = 0x120; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t TakeCashStart = 0x128; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t TakeCashStop = 0x130; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t PutCargoInInventory = 0x138; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t RepairBreach = 0x140; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t RepairBreachStop = 0x148; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t ChargeCumulativeItem = 0x150; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t ChargeCumulativeItemStop = 0x158; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t RaidDefenseBlock = 0x160; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t RaidDefenseBlockStop = 0x168; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t RepairDefenseBlock = 0x170; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t RepairDefenseBlockStop = 0x178; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t FirstAidCabinetUse = 0x180; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t FirstAidCabinetUseStop = 0x188; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t CargoProductionWorkbenchSetRecipeFromCargo = 0x190; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t CargoProductionWorkbenchUnsetRecipe = 0x198; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t CollectChargedCargoRewardStart = 0x1A0; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t CollectChargedCargoRewardStop = 0x1A8; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t EvictStart = 0x1B0; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t EvictStop = 0x1B8; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t RemovePoopPileStart = 0x1C0; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t RemovePoopPileStop = 0x1C8; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t UsePointOfInterestStart = 0x1D0; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t UsePointOfInterestStop = 0x1D8; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t RepairLaunderingCableStart = 0x1E0; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t RepairLaunderingCableStop = 0x1E8; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t HackSecurityPanelStart = 0x1F0; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t HackSecurityPanelStop = 0x1F8; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t RepairSecurityPanelStart = 0x200; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t RepairSecurityPanelStop = 0x208; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t UseHideObjectStart = 0x210; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t CheckHideObjectStart = 0x218; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t UseHideObjectStop = 0x220; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t ForceArrestTargetStart = 0x228; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t ForceArrestTargetStop = 0x230; // "UseEntityCommandDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Enum = 0x441FED0; // "public static ReadOnlyEnum<UseEntityCommandDescription> get_Enum()"
        }
    } // namespace UseEntityCommandDescription

    namespace UseInputUpdater { // "Game.Battle.Player.UseInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t useInputModel = 0x10; // "InputModel"
            inline constexpr std::uintptr_t targetModel = 0x18; // "TargetModel"
            inline constexpr std::uintptr_t backInputModel = 0x20; // "InputModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x976E80; // "public void Update()"
        }
    } // namespace UseInputUpdater

    namespace UseItemAnimationItemUpdater { // "Game.Battle.EntityModel.Player.Equipment.UseItemAnimationItemUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t itemActionProcessModel = 0x10; // "ItemActionProcessModel"
            inline constexpr std::uintptr_t tweenAnimation = 0x18; // "TweenAnimation"
            inline constexpr std::uintptr_t minSoundEvent = 0x20; // "int"
            inline constexpr std::uintptr_t isInCast = 0x24; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC81060; // "public void Update()"
            inline constexpr std::uintptr_t Stop = 0xC81020; // "private void Stop()"
        }
    } // namespace UseItemAnimationItemUpdater

    namespace UseItemInputUpdater { // "Game.Battle.Inputs.UseItemInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t globalModel = 0x10; // "GlobalModel"
            inline constexpr std::uintptr_t battleEntities = 0x18; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t useItemModel = 0x20; // "InputModel"
            inline constexpr std::uintptr_t battleInputModel = 0x28; // "BattleInputModel"
            inline constexpr std::uintptr_t personalNotification = 0x30; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t usableItemNotificationKeys = 0x38; // "UsableItemNotificationKeys"
            inline constexpr std::uintptr_t notificationKeys = 0x40; // "NotificationKeys"
            inline constexpr std::uintptr_t inBattleSettingsModel = 0x48; // "InBattleSettingsModel"
            inline constexpr std::uintptr_t now = 0x50; // "ISetNow"
            inline constexpr std::uintptr_t isTriggered = 0x58; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA9EBC0; // "public void Update()"
            inline constexpr std::uintptr_t UpdateWeapon = 0xA9EAC0; // "private void UpdateWeapon(BattleCharacterModel playerModel)"
            inline constexpr std::uintptr_t UpdatePocket = 0xA9E610; // "private void UpdatePocket(BattleCharacterModel playerModel, bool isTriggered, bool isPressEvent, SelectedQuickSlotModel quickSlot)"
            inline constexpr std::uintptr_t HandleUsableItemInput = 0xA9DDA0; // "private void HandleUsableItemInput(UsableItemDescription item, BattleCharacterModel playerModel)"
            inline constexpr std::uintptr_t TryUseFromInventory = 0xA9E260; // "private void TryUseFromInventory(BattleCharacterModel playerModel)"
            inline constexpr std::uintptr_t HandleThrowableItemHoldInput = 0xA9DA10; // "private void HandleThrowableItemHoldInput(BattleCharacterModel playerModel)"
            inline constexpr std::uintptr_t TryThrowFromInventory = 0xA9E120; // "private void TryThrowFromInventory(BattleCharacterModel playerModel)"
            inline constexpr std::uintptr_t HandleThrowableItemReleaseInput = 0xA9DC40; // "private void HandleThrowableItemReleaseInput(BattleCharacterModel playerModel)"
        }
    } // namespace UseItemInputUpdater

    namespace UseItemsRule { // "Game.Battle.EntityModel.BattleCharacter.Equipment.UseItemsRule (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t useItemModel = 0x10; // "UseItemModel"
            inline constexpr std::uintptr_t reload = 0x18; // "UseReloadWeapon"
            inline constexpr std::uintptr_t usePlate = 0x20; // "UsePlate"
            inline constexpr std::uintptr_t singleUseItem = 0x28; // "SingleUseItem"
            inline constexpr std::uintptr_t player = 0x30; // "BattleCharacterModel"
            inline constexpr std::uintptr_t equipSlotsDelaysModel = 0x38; // "EquipSlotsDelaysModel"
            inline constexpr std::uintptr_t now = 0x40; // "INow"
            inline constexpr std::uintptr_t vestMoveContext = 0x48; // "EquipItemMoveContext"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Use = 0xCDB190; // "public void Use(IItemMoveContext from)"
            inline constexpr std::uintptr_t Apply = 0xCDAB20; // "public bool Apply(IItemMoveContext from, IItemMoveContext to)"
            inline constexpr std::uintptr_t IsEquipSlotDelayActive = 0xCDB030; // "private bool IsEquipSlotDelayActive(IItemMoveContext to)"
            inline constexpr std::uintptr_t CheckRequirement = 0xCDAE80; // "public bool CheckRequirement(IItemMoveContext from, IItemMoveContext to)"
            inline constexpr std::uintptr_t CheckContext = 0xCDAE10; // "public bool CheckContext(IItemMoveContext from, IItemMoveContext to)"
        }
    } // namespace UseItemsRule

    namespace UsePlate { // "Game.Battle.EntityModel.BattleCharacter.Equipment.UsePlate (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t now = 0x10; // "INow"
            inline constexpr std::uintptr_t player = 0x18; // "BattleCharacterModel"
            inline constexpr std::uintptr_t vestMoveContext = 0x20; // "EquipItemMoveContext"
        }
        namespace Methods {
            inline constexpr std::uintptr_t CheckContext = 0xCDB6A0; // "public bool CheckContext(IItemMoveContext from, IItemMoveContext to)"
            inline constexpr std::uintptr_t CheckRequirement = 0xCDB860; // "public bool CheckRequirement(IItemMoveContext from, IItemMoveContext to)"
            inline constexpr std::uintptr_t CheckUseItemContext = 0xCDBA40; // "public bool CheckUseItemContext(IItemMoveContext from)"
            inline constexpr std::uintptr_t CheckRequirementForEquip = 0xCDB850; // "public bool CheckRequirementForEquip(IItemMoveContext from)"
        }
    } // namespace UsePlate

    namespace UsePointOfInterestProlongedAction { // "Game.Battle.Entities.Player.ProlongedActions.UsePointOfInterestProlongedAction (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "ProlongedInteractionModel"
            inline constexpr std::uintptr_t worldEntitiesModel = 0x18; // "WorldEntitiesModel"
            inline constexpr std::uintptr_t Label = 0x20; // "LocalizedString"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsActive = 0xB2F4C0; // "public bool get_IsActive()"
            inline constexpr std::uintptr_t get_EndTs = 0xB19D10; // "public long get_EndTs()"
            inline constexpr std::uintptr_t get_Duration = 0xB2F400; // "public long get_Duration()"
            inline constexpr std::uintptr_t Interrupt = 0xB2F350; // "public void Interrupt(BattleInputModel battleInputModel)"
            inline constexpr std::uintptr_t GetUseTime = 0xB2F2A0; // "private long GetUseTime(int entityId)"
        }
    } // namespace UsePointOfInterestProlongedAction

    namespace ValueFileStorage { // "Game.Global.PlayerPrefsFile.ValueFileStorage (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t fileStorage = 0x10; // "IFileStorage"
            inline constexpr std::uintptr_t format = 0x18; // "IFormat"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Exist = 0x37B0B90; // "public bool Exist()"
            inline constexpr std::uintptr_t Delete = 0x37B0AC0; // "public Maybe<Exception> Delete()"
            inline constexpr std::uintptr_t Read = 0x37B0BE0; // "public Task<IEither<Exception, IValue>> Read()"
            inline constexpr std::uintptr_t Write = 0x37B0CD0; // "public Task<Maybe<Exception>> Write(IValue value)"
        }
    } // namespace ValueFileStorage

    namespace Vector2WithModifier { // "Inputs.Vector2WithModifier (Inputs.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Modifier = 0x10; // "int"
            inline constexpr std::uintptr_t up = 0x14; // "int"
            inline constexpr std::uintptr_t down = 0x18; // "int"
            inline constexpr std::uintptr_t left = 0x1C; // "int"
            inline constexpr std::uintptr_t right = 0x20; // "int"
            inline constexpr std::uintptr_t mode = 0x24; // "Vector2WithModifier.Mode"
        }
        namespace Methods {
            inline constexpr std::uintptr_t ReadValue = 0x37FDB50; // "public override Vector2 ReadValue(ref InputBindingCompositeContext context)"
            inline constexpr std::uintptr_t EvaluateMagnitude = 0x37FDAC0; // "public override float EvaluateMagnitude(ref InputBindingCompositeContext context)"
            inline constexpr std::uintptr_t Init = 0x7B3360; // "private static void Init()"
        }
    } // namespace Vector2WithModifier

    namespace VectorInputModel { // "Models.Models.VectorInput.VectorInputModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t x = 0x10; // "float"
            inline constexpr std::uintptr_t y = 0x14; // "float"
            inline constexpr std::uintptr_t contains = 0x18; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_X = 0x8341C0; // "public float get_X()"
            inline constexpr std::uintptr_t get_Y = 0x8341D0; // "public float get_Y()"
            inline constexpr std::uintptr_t get_Contains = 0xA25F30; // "public bool get_Contains()"
            inline constexpr std::uintptr_t Set = 0x48CD280; // "public void Set(float x, float y)"
            inline constexpr std::uintptr_t Clear = 0x48CD270; // "public void Clear()"
        }
    } // namespace VectorInputModel

    namespace VigilantNpcBattleAssistanceTargetUpdater { // "Game.Battle.Entities.Player.BattleAssistance.VigilantNpcBattleAssistanceTargetUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t globalModel = 0x20; // "GlobalModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x28; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t battleAssistanceModel = 0x30; // "BattleAssistanceModel"
            inline constexpr std::uintptr_t battleNpc = 0x38; // "BattleNpcModel"
            inline constexpr std::uintptr_t view = 0x40; // "VigilantNpcView"
            inline constexpr std::uintptr_t isActive = 0x48; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xB43B90; // "public VigilantNpcBattleAssistanceTargetUpdater Init(GlobalModel globalModel, BattleModel battleModel, BattleNpcModel battleNpc, VigilantNpcView view)"
            inline constexpr std::uintptr_t Dispose = 0xB43AF0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xB43DA0; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t UpdateActive = 0xB43F50; // "private void UpdateActive(bool isActive)"
            inline constexpr std::uintptr_t Stop = 0xB43F10; // "public void Stop()"
            inline constexpr std::uintptr_t IsActive = 0xB43C30; // "private bool IsActive()"
            inline constexpr std::uintptr_t Core_Updater_IStoppedUpdater_Update = 0x9165B0; // "private void Core.Updater.IStoppedUpdater.Update()"
        }
    } // namespace VigilantNpcBattleAssistanceTargetUpdater

    namespace VoiceChatBattlePlayerHideObjectIdUpdater { // "Game.Battle.VoiceChat.VoiceChatBattlePlayerHideObjectIdUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t eosGlobalModel = 0x10; // "EosGlobalModel"
            inline constexpr std::uintptr_t rtcDataInterface = 0x18; // "RTCDataInterface"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x20; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t voiceChatBattleRoomModel = 0x28; // "VoiceChatBattleRoomModel"
            inline constexpr std::uintptr_t entityIdBytes = 0x30; // "byte[]"
            inline constexpr std::uintptr_t shouldSendHideObject = 0x38; // "bool"
            inline constexpr std::uintptr_t cooldownEndTime = 0x3C; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xD69890; // "public void Update()"
            inline constexpr std::uintptr_t SendHideObjectEntityId = 0xD695D0; // "private void SendHideObjectEntityId(int entityId)"
        }
    } // namespace VoiceChatBattlePlayerHideObjectIdUpdater

    namespace VoiceChatInputUpdater { // "Game.Battle.VoiceChat.VoiceChatInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t gameSettings = 0x10; // "GameSettingsModel"
            inline constexpr std::uintptr_t voiceChatInputModel = 0x18; // "InputModel"
            inline constexpr std::uintptr_t voiceChatBattleRoomModel = 0x20; // "VoiceChatBattleRoomModel"
            inline constexpr std::uintptr_t voiceChatMode = 0x28; // "Nullable<VoiceChatMode>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xD6B0A0; // "public void Update()"
        }
    } // namespace VoiceChatInputUpdater

} // namespace Offsets::Player_Character
