#pragma once
#include <cstdint>

namespace Offsets::Inventory_Cargo {

    namespace AmmoDescription { // "Models.References.Inventory.AmmoDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t BasePrice = 0x20; // "int"
            inline constexpr std::uintptr_t SellPriceModifierFunc = 0x28; // "Func<InventoryItemSellPriceModifier>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_SellPriceModifier = 0x993E50; // "public InventoryItemSellPriceModifier get_SellPriceModifier()"
            inline constexpr std::uintptr_t get_SellPrice = 0x43E2DD0; // "public int get_SellPrice()"
        }
    } // namespace AmmoDescription

    namespace ArmorConfig { // "Models.References.Inventory.ArmorConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t SegmentAmount = 0x10; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t CalculateRestoredAmount = 0x43E2E10; // "public int CalculateRestoredAmount(int segmentsToAdd, int currentAmount, int maxSegmentsCount)"
        }
    } // namespace ArmorConfig

    namespace ArmorDescription { // "Models.References.Inventory.ArmorDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t SegmentsCount = 0x20; // "int"
            inline constexpr std::uintptr_t BlockingRate = 0x24; // "float"
        }
    } // namespace ArmorDescription

    namespace BackupInventoryPoliceBadgesModel { // "Models.Models.BackupInventoryPoliceBadges.BackupInventoryPoliceBadgesModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t models = 0x10; // "Dictionary<PoliceBadgeDescription, IPrimitiveModel<int>>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Item = 0x49D50C0; // "public IPrimitiveModel<int> get_Item(PoliceBadgeDescription description)"
            inline constexpr std::uintptr_t UpdateValuesByInventory = 0x49D46D0; // "public void UpdateValuesByInventory(IInventoryModel inventoryModel)"
            inline constexpr std::uintptr_t Reset = 0x49D44F0; // "public void Reset()"
        }
    } // namespace BackupInventoryPoliceBadgesModel

    namespace BarterRecipeDescription { // "Models.References.Barter.BarterRecipeDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t LazyItems = 0x20; // "Lazy<IReadOnlyDictionary<InventoryItemDescription, int>>"
            inline constexpr std::uintptr_t ResultItemFunc = 0x28; // "Func<InventoryItemDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Items = 0x455CCA0; // "public IReadOnlyDictionary<InventoryItemDescription, int> get_Items()"
            inline constexpr std::uintptr_t get_ResultItem = 0x993E50; // "public InventoryItemDescription get_ResultItem()"
        }
    } // namespace BarterRecipeDescription

    namespace BarterRecipeUpdater { // "Game.Battle.Entities.Trader.Dialog.BarterRecipeUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t scrollerModel = 0x10; // "RecipeScrollerModel"
            inline constexpr std::uintptr_t description = 0x18; // "BarterRecipeDescription"
            inline constexpr std::uintptr_t recipeView = 0x20; // "BarterRecipeView"
            inline constexpr std::uintptr_t inventory = 0x28; // "IInventoryModel"
            inline constexpr std::uintptr_t recipeIndex = 0x30; // "int"
            inline constexpr std::uintptr_t items = 0x38; // "KeyValuePair<InventoryItemDescription, int>[]"
            inline constexpr std::uintptr_t numberSuffixViewDescriptions = 0x40; // "NumberSuffixViewDescriptions"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xAD26F0; // "public void Update()"
            inline constexpr std::uintptr_t SetProgressLabel = 0xAD24A0; // "private void SetProgressLabel(int index)"
        }
    } // namespace BarterRecipeUpdater

    namespace BarterTraderDescription { // "Models.References.Barter.BarterTraderDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t LazyBarterRecipeDescriptions = 0x20; // "Lazy<IReadOnlyList<BarterRecipeDescription>>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_BarterRecipeDescriptions = 0x455D370; // "public IReadOnlyList<BarterRecipeDescription> get_BarterRecipeDescriptions()"
        }
    } // namespace BarterTraderDescription

    namespace BarterTraderTargetActions { // "Game.Battle.Entities.Trader.BarterTraderTargetActions (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleModel = 0x10; // "BattleModel"
            inline constexpr std::uintptr_t globalModel = 0x18; // "GlobalModel"
            inline constexpr std::uintptr_t barterTraderDescription = 0x20; // "LocationBarterTraderDescription"
            inline constexpr std::uintptr_t view = 0x28; // "BarterTraderView"
            inline constexpr std::uintptr_t talkViewDescriptions = 0x30; // "TalkViewDescriptions"
            inline constexpr std::uintptr_t targetName = 0x38; // "LocalizedString"
            inline constexpr std::uintptr_t clientCodexModel = 0x40; // "ClientCodexModel"
            inline constexpr std::uintptr_t isDisposed = 0x48; // "bool"
            inline constexpr std::uintptr_t BarterAction = 0x50; // "TargetAction"
            inline constexpr std::uintptr_t TalkAction = 0x58; // "TargetAction"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Talk = 0xAD3750; // "private void Talk()"
            inline constexpr std::uintptr_t Barter = 0xAD35E0; // "private void Barter()"
            inline constexpr std::uintptr_t Unavailable = 0xAD3860; // "private void Unavailable(LocalizedString invalidNotification, PersonalNotificationActionIds id)"
        }
    } // namespace BarterTraderTargetActions

    namespace BarterTraderTargetProvider { // "Game.Battle.Entities.Trader.BarterTraderTargetProvider (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t actions = 0x20; // "BarterTraderTargetActions"
            inline constexpr std::uintptr_t battleMode = 0x28; // "BattleModeDescription"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x30; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t unavailableKeys = 0x38; // "UnavailableTargetActionsKeys"
            inline constexpr std::uintptr_t talkViewDescriptions = 0x40; // "TalkViewDescriptions"
            inline constexpr std::uintptr_t view = 0x48; // "BarterTraderView"
            inline constexpr std::uintptr_t talkInappropriateRoleNotify = 0x50; // "LocalizedString"
        }
        namespace Methods {
            inline constexpr std::uintptr_t FillTargetActions = 0xAD3E10; // "protected internal override void FillTargetActions(List<ITargetAction> actions)"
            inline constexpr std::uintptr_t ValidateBarter = 0xAD4040; // "private void ValidateBarter(BattleCharacterModel player, List<ITargetAction> actions)"
            inline constexpr std::uintptr_t ValidateTalk = 0xAD4330; // "private void ValidateTalk(BattleCharacterModel player, List<ITargetAction> actions)"
            inline constexpr std::uintptr_t GetInvalidDescription = 0xAD3FB0; // "private LocalizedString GetInvalidDescription(BattleCharacterModel player)"
        }
    } // namespace BarterTraderTargetProvider

    namespace BattleItemStatsRules { // "Game.Battle.Inventory.BattleItemStatsRules (Battle.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x8247E88; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t args = 0x0; // "List<object>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t UpdateStatsStrings = 0xA584B0; // "public static void UpdateStatsStrings(InventoryItemTypeViewDescription itemTypeViewDescription, List<ValueTuple<string, string, bool>> itemStatsStrings, InventoryItemDescription item, InventoryCellsSizeDescription cellsSizeDescription, BattleScreenContent content)"
        }
    } // namespace BattleItemStatsRules

    namespace BillOfSaleDescription { // "Models.References.Inventory.BillOfSaleDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t BillType = 0x20; // "BillOfSaleType"
            inline constexpr std::uintptr_t TierFunc = 0x28; // "Func<TierDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Tier = 0x993E50; // "public TierDescription get_Tier()"
            inline constexpr std::uintptr_t get_IsPlotBillOfSale = 0x43E2F20; // "public bool get_IsPlotBillOfSale()"
            inline constexpr std::uintptr_t get_IsSettlementBillOfSale = 0x43E2F30; // "public bool get_IsSettlementBillOfSale()"
        }
    } // namespace BillOfSaleDescription

    namespace BlockedEntitiesModel { // "Game.Battle.Inventory.BlockedEntitiesModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t entities = 0x10; // "Dictionary<int, byte>"
            inline constexpr std::uintptr_t timeline = 0x18; // "Queue<ValueTuple<long, int>>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Peek = 0x9DEB20; // "public long get_Peek()"
            inline constexpr std::uintptr_t get_Count = 0x9DEAE0; // "public int get_Count()"
            inline constexpr std::uintptr_t IsBlocked = 0x9DE840; // "public bool IsBlocked(int entityId)"
            inline constexpr std::uintptr_t AddBlock = 0x9DE640; // "public void AddBlock(int entityId)"
            inline constexpr std::uintptr_t RemoveBlock = 0x9DE940; // "public void RemoveBlock(int entityId)"
            inline constexpr std::uintptr_t RemoveBlockByTime = 0x9DE8A0; // "public void RemoveBlockByTime(long tickIndex, int entityId)"
            inline constexpr std::uintptr_t Dequeue = 0x9DE6F0; // "public void Dequeue()"
        }
    } // namespace BlockedEntitiesModel

    namespace BlockedEntitiesUpdater { // "Game.Battle.Inventory.BlockedEntitiesUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t blockedEntitesModel = 0x10; // "BlockedEntitiesModel"
            inline constexpr std::uintptr_t timeModel = 0x18; // "TimeModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x9DEB70; // "public void Update()"
        }
    } // namespace BlockedEntitiesUpdater

    namespace BlockedSlotBusyUpdater { // "Game.Battle.Inventory.BlockedSlotBusyUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t itemMoveContext = 0x20; // "IItemMoveContext"
            inline constexpr std::uintptr_t blockedSlotsModel = 0x28; // "BlockedSlotsModel"
            inline constexpr std::uintptr_t inventoryIntention = 0x30; // "InventoryIntention"
            inline constexpr std::uintptr_t isBlock = 0x38; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0x9DECB0; // "public BlockedSlotBusyUpdater Init(BattleModel battleModel, IItemMoveContext itemMoveContext)"
            inline constexpr std::uintptr_t Dispose = 0x9DEC60; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0x9DED80; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t TryDispose = 0x9DEE70; // "private void TryDispose()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace BlockedSlotBusyUpdater

    namespace BlockedSlotsModel { // "Game.Battle.Inventory.BlockedSlotsModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t inventorySlots = 0x10; // "Dictionary<IInventorySlotModel, byte>"
            inline constexpr std::uintptr_t pocketSlots = 0x18; // "Dictionary<IPocketSlotModel, byte>"
            inline constexpr std::uintptr_t equipSlots = 0x20; // "Dictionary<IEquipSlotModel, byte>"
            inline constexpr std::uintptr_t externalInventorySlots = 0x28; // "Dictionary<IInventorySlotModel, byte>"
            inline constexpr std::uintptr_t traderSlots = 0x30; // "Dictionary<IInventorySlotModel, byte>"
            inline constexpr std::uintptr_t carBenchSlots = 0x38; // "Dictionary<IVehicleBenchSlotModel, byte>"
            inline constexpr std::uintptr_t helicopterBenchSlots = 0x40; // "Dictionary<IVehicleBenchSlotModel, byte>"
            inline constexpr std::uintptr_t carUpgradeSlots = 0x48; // "Dictionary<IInventoryItemModel, byte>"
            inline constexpr std::uintptr_t builderSlots = 0x50; // "Dictionary<BuilderSlotModel, byte>"
            inline constexpr std::uintptr_t copSalarySlots = 0x58; // "Dictionary<IInventorySlotModel, byte>"
            inline constexpr std::uintptr_t timeline = 0x60; // "Queue<ValueTuple<long, IItemMoveContext>>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Peek = 0x9DFE80; // "public long get_Peek()"
            inline constexpr std::uintptr_t get_Count = 0x9DFE40; // "public int get_Count()"
            inline constexpr std::uintptr_t IsBlocked = 0x9DF2F0; // "public bool IsBlocked(IItemMoveContext context)"
            inline constexpr std::uintptr_t AddBlock = 0x9DEEB0; // "public void AddBlock(IItemMoveContext context)"
            inline constexpr std::uintptr_t RemoveBlock = 0x9DF7B0; // "public void RemoveBlock(IItemMoveContext context)"
            inline constexpr std::uintptr_t RemoveBlockByTime = 0x9DF710; // "public void RemoveBlockByTime(long tickIndex, IItemMoveContext slot)"
            inline constexpr std::uintptr_t Dequeue = 0x9DF260; // "public void Dequeue()"
            inline constexpr std::uintptr_t AddToCounter_T_inst_1 = 0x1568890; // "BlockedSlotsModel.AddToCounter<object>"
            inline constexpr std::uintptr_t AddToCounter_T_inst_2 = 0x1568630; // "BlockedSlotsModel.AddToCounter<__Il2CppFullySharedGenericType>"
            inline constexpr std::uintptr_t RemoveFromCounter_T_inst_1 = 0x1568BC0; // "BlockedSlotsModel.RemoveFromCounter<object>"
            inline constexpr std::uintptr_t RemoveFromCounter_T_inst_2 = 0x1568920; // "BlockedSlotsModel.RemoveFromCounter<__Il2CppFullySharedGenericType>"
        }
    } // namespace BlockedSlotsModel

    namespace BlockedSlotsUpdater { // "Game.Battle.Inventory.BlockedSlotsUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t blockedSlotsModel = 0x10; // "BlockedSlotsModel"
            inline constexpr std::uintptr_t timeModel = 0x18; // "TimeModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x9DFED0; // "public void Update()"
        }
    } // namespace BlockedSlotsUpdater

    namespace BreakEquipModel { // "Models.Models.BreakEquip.BreakEquipModel (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t BreakEquip = 0x49E4A30; // "public void BreakEquip(BattleCharacterModel model)"
        }
    } // namespace BreakEquipModel

    namespace BuilderItemActionModel { // "Game.Battle.Inventory.BuilderItemActionModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t slotModel = 0x10; // "BuilderSlotModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetModel = 0x7EC730; // "public void SetModel(BuilderSlotModel slotModel)"
            inline constexpr std::uintptr_t CheckSet = 0xA288E0; // "public bool CheckSet(InventoryItemDescription item, int count, int ammo, int durability, int cumulativePoints, out bool isSet)"
            inline constexpr std::uintptr_t CheckMoveFrom = 0xA28780; // "public bool CheckMoveFrom(int count, out InventoryItemDescription item, out int ammo, out int durability, out int cumulativePoints, out bool isUnset)"
            inline constexpr std::uintptr_t CheckMoveTo = 0xA28840; // "public bool CheckMoveTo(InventoryItemDescription item, int count, int ammo, int durability, int cumulativePoints, IItemActionModel fromModel, out bool isSet)"
            inline constexpr std::uintptr_t CheckUnset = 0x7D5050; // "public bool CheckUnset()"
            inline constexpr std::uintptr_t CheckSwap = 0xA28920; // "public bool CheckSwap(InventoryItemDescription item, int count, int ammo, int durability, int cumulativePoints)"
            inline constexpr std::uintptr_t TryGetContent = 0xA289D0; // "public bool TryGetContent(out InventoryItemDescription item, out int count, out int ammo, out int durability, out int cumulativePoints)"
            inline constexpr std::uintptr_t AreEqual = 0xA28680; // "public bool AreEqual(IItemActionModel other)"
            inline constexpr std::uintptr_t Set = 0xA28990; // "public void Set(long now, InventoryItemDescription item, int count, int ammo, int durability, int cumulativePoints)"
            inline constexpr std::uintptr_t Unset = 0xA28B30; // "public void Unset()"
            inline constexpr std::uintptr_t ChangeStack = 0xA28740; // "public void ChangeStack(int count)"
            inline constexpr std::uintptr_t ChangeAmmo = 0xA28700; // "public void ChangeAmmo(int ammo)"
            inline constexpr std::uintptr_t get_IsSlotBusy = 0x7EC9F0; // "public bool get_IsSlotBusy()"
            inline constexpr std::uintptr_t CheckUnloadAmmo = 0xA28950; // "public bool CheckUnloadAmmo(long now)"
        }
    } // namespace BuilderItemActionModel

    namespace BuilderItemMoveContext { // "Game.Battle.Inventory.BuilderItemMoveContext (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t SlotModel = 0x10; // "BuilderSlotModel"
            inline constexpr std::uintptr_t ItemModel = 0x18; // "IInventoryItemModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_EntityId = 0xA0AD60; // "public int get_EntityId()"
            inline constexpr std::uintptr_t get_RevealContainerModel = 0xA0AD80; // "public IRevealContainerModel get_RevealContainerModel()"
            inline constexpr std::uintptr_t get_Revealed = 0x7D5050; // "public bool get_Revealed()"
            inline constexpr std::uintptr_t get_Count = 0xA0AD00; // "public int get_Count()"
            inline constexpr std::uintptr_t get_Ammo = 0x7E3AB0; // "public int get_Ammo()"
            inline constexpr std::uintptr_t get_Durability = 0x7E3AB0; // "public int get_Durability()"
            inline constexpr std::uintptr_t get_CumulativePoints = 0x7E3AB0; // "public int get_CumulativePoints()"
        }
    } // namespace BuilderItemMoveContext

    namespace BuilderLootDescription { // "Models.References.BuilderLoot.BuilderLootDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t MaxInventoryPagesCount = 0x20; // "int"
            inline constexpr std::uintptr_t MaxCargoInventoryPagesCount = 0x24; // "int"
            inline constexpr std::uintptr_t Height = 0x28; // "float"
            inline constexpr std::uintptr_t InteractDescription = 0x30; // "InteractDescription"
        }
    } // namespace BuilderLootDescription

    namespace BuilderLootEntityInventoryData { // "Models.Data.Settlement.Loot.BuilderLootEntityInventoryData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Description = 0x20; // "BuilderLootDescription"
            inline constexpr std::uintptr_t InventoryPages = 0x28; // "DictionaryData<int, InventoryData>"
            inline constexpr std::uintptr_t CargoInventoryPages = 0x30; // "DictionaryData<int, CargoInventoryData>"
            inline constexpr std::uintptr_t StartEntityId = 0x38; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t OwnerNickname = 0x40; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t OwnerClanTag = 0x48; // "IPrimitiveData<string>"
        }
    } // namespace BuilderLootEntityInventoryData

    namespace BuilderLootEntityInventoryModel { // "Models.Models.BuildingLootEntityInventory.BuilderLootEntityInventoryModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Id = 0x10; // "int"
            inline constexpr std::uintptr_t Description = 0x18; // "BuilderLootDescription"
            inline constexpr std::uintptr_t InventoryPagesModel = 0x20; // "InventoryPagesModel"
            inline constexpr std::uintptr_t CargoInventoryPagesModel = 0x28; // "CargoInventoryPagesModel"
            inline constexpr std::uintptr_t StartEntityId = 0x30; // "IPrimitiveModel<int>"
            inline constexpr std::uintptr_t OwnerNickname = 0x38; // "IPrimitiveModel<string>"
            inline constexpr std::uintptr_t OwnerClanTag = 0x40; // "IPrimitiveModel<string>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t IsEmpty = 0x4985100; // "public bool IsEmpty()"
        }
    } // namespace BuilderLootEntityInventoryModel

    namespace BuilderLootExtensions { // "Models.Utils.Extensions.Builder.BuilderLootExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t ClearInventories = 0x3C7F300; // "public static void ClearInventories(BuilderLootEntityInventoryModel model)"
            inline constexpr std::uintptr_t GetBuilderLootInventoryPageEntityId = 0x3C7F5E0; // "public static int GetBuilderLootInventoryPageEntityId(BuilderLootEntityInventoryModel builderLootEntityInventoryModel, IInventoryModel inventoryModel)"
            inline constexpr std::uintptr_t GetBuilderLootCargoInventorySlotEntityId = 0x3C7F4A0; // "public static int GetBuilderLootCargoInventorySlotEntityId(BuilderLootEntityInventoryModel builderLootEntityInventoryModel, CargoInventoryModel cargoInventoryModel, CargoInventorySlotDescription slotDescription)"
            inline constexpr std::uintptr_t CreateInteractPositionModel = 0x3C7F340; // "public static IPositionModel CreateInteractPositionModel(BuilderLootDescription description, IPositionModel basePositionModel)"
        }
    } // namespace BuilderLootExtensions

    namespace BuilderLootInventoryEntityDataBuilder { // "Models.Replication.EntityDataBuilder.BuilderLootInventoryEntityDataBuilder (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t paramsModel = 0x10; // "EntitiesParamsModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Build = 0x44B4860; // "public IData Build(int id)"
        }
    } // namespace BuilderLootInventoryEntityDataBuilder

    namespace BuilderLootInventoryEntityModel { // "Game.Battle.Entities.BuildingLoot.BuilderLootInventoryEntityModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ServerModel = 0x18; // "BuilderLootEntityInventoryModel"
        }
    } // namespace BuilderLootInventoryEntityModel

    namespace BuilderLootInventoryEntityStreamReader { // "Models.Replication.EntityStreamReader.BuilderLootInventoryEntityStreamReader (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t paramsModel = 0x20; // "EntitiesParamsModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t TryReadParams = 0x44B4960; // "protected override bool TryReadParams(int entityId, IBinaryReadStream stream)"
        }
    } // namespace BuilderLootInventoryEntityStreamReader

    namespace BuilderRestrictedCellsModelUpdater { // "Game.Battle.Inventory.RestrictedCells.BuilderRestrictedCellsModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t slotsModel = 0x30; // "BuilderSlotsModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0x998C80; // "public BuilderRestrictedCellsModelUpdater Init(BattleCharacterModel battleCharacterModel, RestrictedCellsModel restrictedCellsModel, BuilderSlotsModel slotsModel)"
            inline constexpr std::uintptr_t Dispose = 0x9F6DA0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t GetIsActive = 0xA589B0; // "protected override bool GetIsActive(IInventoryItemModel itemModel)"
        }
    } // namespace BuilderRestrictedCellsModelUpdater

    namespace BusySlotsModel { // "Game.Battle.Inventory.BusySlotsModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t items = 0x10; // "Dictionary<IInventorySlotModel, InventoryItemCellsSize>"
            inline constexpr std::uintptr_t Items = 0x18; // "ReadOnly.Dictionary<IInventorySlotModel, InventoryItemCellsSize>"
            inline constexpr std::uintptr_t BusyCount = 0x20; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_HasBusySlots = 0xA28E10; // "public bool get_HasBusySlots()"
            inline constexpr std::uintptr_t Add = 0xA28B70; // "public void Add(IInventorySlotModel slotModel)"
            inline constexpr std::uintptr_t Remove = 0xA28CB0; // "public void Remove(IInventorySlotModel slotModel)"
            inline constexpr std::uintptr_t Clear = 0xA28C60; // "public void Clear()"
        }
    } // namespace BusySlotsModel

    namespace BusySlotsModelUpdater { // "Game.Battle.Inventory.BusySlotsModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t changedSlotsModel = 0x20; // "ChangedSlotsInventoryModel"
            inline constexpr std::uintptr_t busySlotsModel = 0x28; // "BusySlotsModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0x9DFFC0; // "public BusySlotsModelUpdater Init(ChangedSlotsInventoryModel changedSlotsModel, BusySlotsModel busySlotsModel)"
            inline constexpr std::uintptr_t Dispose = 0x92B5C0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0x9E0130; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace BusySlotsModelUpdater

    namespace BuyCargoMessage { // "Models.Messages.BuyCargoMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t entityId = 0x20; // "IPrimitiveData<int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_EntityId = 0x49E7170; // "public int get_EntityId()"
            inline constexpr std::uintptr_t get_Type = 0x49E71C0; // "public override string get_Type()"
        }
    } // namespace BuyCargoMessage

    namespace BuyerCashLootNodeEntityModel { // "Game.Battle.Entities.BuyerEntity.BuyerCashLootNodeEntityModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ServerModel = 0x18; // "CashLootNodeModel"
            inline constexpr std::uintptr_t TriggerFirstLookMarkerModel = 0x20; // "TriggerFirstLookMarkerModel"
            inline constexpr std::uintptr_t ContainsUserCash = 0x28; // "bool"
            inline constexpr std::uintptr_t LastSaleTs = 0x2C; // "float"
        }
    } // namespace BuyerCashLootNodeEntityModel

    namespace BuyerCashLootPointTargetActions { // "Game.Battle.Entities.BuyerEntity.BuyerCashLootPointTargetActions (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t soundEmitter = 0x10; // "GameObject"
            inline constexpr std::uintptr_t battleInputModel = 0x18; // "BattleInputModel"
            inline constexpr std::uintptr_t cashLootPointId = 0x20; // "int"
            inline constexpr std::uintptr_t view = 0x28; // "CashLootNodeView"
            inline constexpr std::uintptr_t personalNotificationModel = 0x30; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t uiSoundModel = 0x38; // "GlobalUISoundModel"
            inline constexpr std::uintptr_t TakeCashLootAction = 0x40; // "TargetAction"
            inline constexpr std::uintptr_t ArrestCashLootAction = 0x48; // "TargetAction"
        }
        namespace Methods {
            inline constexpr std::uintptr_t ArrestCashLoot = 0xBA75B0; // "private void ArrestCashLoot()"
            inline constexpr std::uintptr_t TakeCashLoot = 0xBA76A0; // "private void TakeCashLoot()"
            inline constexpr std::uintptr_t Unavailable = 0xA74080; // "private void Unavailable(LocalizedString invalidNotification, PersonalNotificationActionIds id)"
        }
    } // namespace BuyerCashLootPointTargetActions

    namespace BuyerCashLootPointTargetProvider { // "Game.Battle.Entities.BuyerEntity.BuyerCashLootPointTargetProvider (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t tutorialModel = 0x20; // "TutorialModel"
            inline constexpr std::uintptr_t cashLootNodeEntityModel = 0x28; // "BuyerCashLootNodeEntityModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x30; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t actions = 0x38; // "BuyerCashLootPointTargetActions"
            inline constexpr std::uintptr_t notificationKeys = 0x40; // "NotificationKeys"
            inline constexpr std::uintptr_t unavailableKeys = 0x48; // "UnavailableTargetActionsKeys"
        }
        namespace Methods {
            inline constexpr std::uintptr_t GetTargetAction = 0xBA7B80; // "protected override ITargetAction GetTargetAction()"
            inline constexpr std::uintptr_t CanTakeMoney = 0xBA7AE0; // "private bool CanTakeMoney(PlayerEntityModel player)"
        }
    } // namespace BuyerCashLootPointTargetProvider

    namespace BuyerCashLootPointUpdater { // "Game.Battle.Entities.BuyerEntity.BuyerCashLootPointUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t view = 0x10; // "CashLootNodeView"
            inline constexpr std::uintptr_t cashLootNodeEntityModel = 0x18; // "BuyerCashLootNodeEntityModel"
            inline constexpr std::uintptr_t battleModel = 0x20; // "BattleModel"
            inline constexpr std::uintptr_t updater = 0x28; // "IUpdater"
            inline constexpr std::uintptr_t targetSubsystem = 0x30; // "ITargetSubsystem"
            inline constexpr std::uintptr_t targetProvider = 0x38; // "BuyerCashLootPointTargetProvider"
            inline constexpr std::uintptr_t actions = 0x40; // "BuyerCashLootPointTargetActions"
            inline constexpr std::uintptr_t targetObject = 0x48; // "ITargetObject"
            inline constexpr std::uintptr_t currentCashAmount = 0x50; // "int"
            inline constexpr std::uintptr_t isTargetBindingAdded = 0x54; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xBA8140; // "public void Update()"
            inline constexpr std::uintptr_t AddTargetBinding = 0xBA7F20; // "private void AddTargetBinding()"
            inline constexpr std::uintptr_t RemoveTargetBinding = 0xBA8030; // "private void RemoveTargetBinding()"
        }
    } // namespace BuyerCashLootPointUpdater

    namespace BuyerEntityInventoryData { // "Models.Data.BuyerEntityInventoryData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Inventory = 0x20; // "InventoryData"
        }
    } // namespace BuyerEntityInventoryData

    namespace BuyerEntityInventoryModel { // "Models.Models.BuyerEntityInventory.BuyerEntityInventoryModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Id = 0x10; // "int"
            inline constexpr std::uintptr_t Inventory = 0x18; // "IInventoryModel"
        }
    } // namespace BuyerEntityInventoryModel

    namespace BuyerInventoryEntityModel { // "Game.Battle.Entities.BuyerEntity.BuyerInventoryEntityModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ServerModel = 0x18; // "BuyerEntityInventoryModel"
        }
    } // namespace BuyerInventoryEntityModel

    namespace BuyerInventoryEntityStreamReader { // "Models.Replication.EntityStreamReader.BuyerInventoryEntityStreamReader (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t GetEntityId = 0x39500A0; // "protected override int GetEntityId(LocationBuyerDescription description)"
        }
    } // namespace BuyerInventoryEntityStreamReader

    namespace BuyInventoryItemMessage { // "Models.Messages.Inventory.BuyInventoryItemMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t traderEntityId = 0x20; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t itemIndex = 0x28; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t slotSource = 0x30; // "IPrimitiveData<SlotSourceDescription>"
            inline constexpr std::uintptr_t inventorySlot = 0x38; // "IPrimitiveData<InventorySlotDescription>"
            inline constexpr std::uintptr_t equipSlot = 0x40; // "IPrimitiveData<EquipSlotDescription>"
            inline constexpr std::uintptr_t pocketSlot = 0x48; // "IPrimitiveData<PocketSlotDescription>"
            inline constexpr std::uintptr_t count = 0x50; // "IPrimitiveData<int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_TraderEntityId = 0x4A188D0; // "public int get_TraderEntityId()"
            inline constexpr std::uintptr_t get_ItemIndex = 0x4A187E0; // "public int get_ItemIndex()"
            inline constexpr std::uintptr_t get_SlotSource = 0x4A18880; // "public SlotSourceDescription get_SlotSource()"
            inline constexpr std::uintptr_t get_InventorySlot = 0x4A18790; // "public InventorySlotDescription get_InventorySlot()"
            inline constexpr std::uintptr_t get_EquipSlot = 0x4A18740; // "public EquipSlotDescription get_EquipSlot()"
            inline constexpr std::uintptr_t get_PocketSlot = 0x4A18830; // "public PocketSlotDescription get_PocketSlot()"
            inline constexpr std::uintptr_t get_Count = 0x4A186F0; // "public int get_Count()"
            inline constexpr std::uintptr_t get_Type = 0x4A18920; // "public override string get_Type()"
        }
    } // namespace BuyInventoryItemMessage

    namespace BuyItemAction { // "Game.Battle.Inventory.BuyItemAction (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t From = 0x0; // "TraderItemMoveContext"
            inline constexpr std::uintptr_t To = 0x8; // "IItemMoveContext"
            inline constexpr std::uintptr_t Count = 0x10; // "int"
            inline constexpr std::uintptr_t TotalPrice = 0x14; // "int"
        }
    } // namespace BuyItemAction

    namespace BuyItemSlotModel { // "Game.Battle.TraderInventory.BuyItemSlotModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t BuyItem = 0x10; // "InventoryItemDescription"
            inline constexpr std::uintptr_t BuyItemIndex = 0x18; // "int"
            inline constexpr std::uintptr_t tier = 0x20; // "TierDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t TryGetTier = 0xD80B80; // "public bool TryGetTier(out TierDescription tier)"
            inline constexpr std::uintptr_t SetBuyItem = 0xA2D3F0; // "public void SetBuyItem(InventoryItemDescription buyItem, int buyItemIndex, TierDescription tier)"
            inline constexpr std::uintptr_t ClearBuyItem = 0xD80B50; // "public void ClearBuyItem()"
        }
    } // namespace BuyItemSlotModel

    namespace CachedItemActionModel { // "Game.Battle.Inventory.CachedItemActionModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "BattleCharacterModel"
            inline constexpr std::uintptr_t inventoryPool = 0x18; // "ObjectPool<InventoryItemActionModel>"
            inline constexpr std::uintptr_t equipPool = 0x20; // "ObjectPool<EquipItemActionModel>"
            inline constexpr std::uintptr_t pocketPool = 0x28; // "ObjectPool<PocketItemActionModel>"
            inline constexpr std::uintptr_t externalInventoryPool = 0x30; // "ObjectPool<ExternalInventoryItemActionModel>"
            inline constexpr std::uintptr_t builderItemActionModel = 0x38; // "ObjectPool<BuilderItemActionModel>"
            inline constexpr std::uintptr_t hoodItemActionModel = 0x40; // "ObjectPool<HoodItemActionModel>"
            inline constexpr std::uintptr_t vehicleItemActionModel = 0x48; // "ObjectPool<VehicleBenchItemActionModel>"
            inline constexpr std::uintptr_t copSalaryItemActionModel = 0x50; // "ObjectPool<CopSalaryItemActionModel>"
            inline constexpr std::uintptr_t worldEntitiesModel = 0x58; // "WorldEntitiesModel"
            inline constexpr std::uintptr_t inventoryModels = 0x60; // "InventoryModels"
        }
        namespace Methods {
            inline constexpr std::uintptr_t TryGetItemActionModel = 0xA29670; // "public bool TryGetItemActionModel(IItemMoveContext itemMoveContext, out IItemActionModel model)"
            inline constexpr std::uintptr_t TryGetItemActionModel_2 = 0xA2A250; // "public bool TryGetItemActionModel(IItemMoveContext fromContext, out IItemActionModel fromModel, IItemMoveContext toContext, out IItemActionModel toModel)"
            inline constexpr std::uintptr_t TryGetItemActionModel_3 = 0xA295A0; // "public bool TryGetItemActionModel(IItemMoveContext firstFromContext, out IItemActionModel firstFromModel, IItemMoveContext firstToContext, out IItemActionModel firstToModel, IItemMoveContext secondFromContext, out IItemActionModel secondFromModel)"
            inline constexpr std::uintptr_t Release = 0xA29110; // "public void Release(IItemActionModel model)"
            inline constexpr std::uintptr_t Release_2 = 0xA290A0; // "public void Release(IItemActionModel[] models)"
            inline constexpr std::uintptr_t CreateInventoryItemActionModel = 0xA28FB0; // "private static InventoryItemActionModel CreateInventoryItemActionModel()"
            inline constexpr std::uintptr_t CreateEquipItemActionModel = 0xA28EC0; // "private static EquipItemActionModel CreateEquipItemActionModel()"
            inline constexpr std::uintptr_t CreatePocketItemActionModel = 0xA29000; // "private static PocketItemActionModel CreatePocketItemActionModel()"
            inline constexpr std::uintptr_t CreateExternalInventoryItemActionModel = 0xA28F10; // "private static ExternalInventoryItemActionModel CreateExternalInventoryItemActionModel()"
            inline constexpr std::uintptr_t CreateCopSalaryItemActionModel = 0xA28E70; // "private static CopSalaryItemActionModel CreateCopSalaryItemActionModel()"
            inline constexpr std::uintptr_t CreateBuilderItemActionModel = 0xA28E20; // "private static BuilderItemActionModel CreateBuilderItemActionModel()"
            inline constexpr std::uintptr_t CreateHoodItemActionModel = 0xA28F60; // "private static HoodItemActionModel CreateHoodItemActionModel()"
            inline constexpr std::uintptr_t CreateVehicleBenchItemActionModel = 0xA29050; // "private static VehicleBenchItemActionModel CreateVehicleBenchItemActionModel()"
        }
    } // namespace CachedItemActionModel

    namespace CargoChargeWorkbenchAnimationUpdater { // "Game.Battle.SettlementBuilder.CargoChargeWorkbenchAnimationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t view = 0x20; // "CargoChargeWorkbenchView"
            inline constexpr std::uintptr_t inventoryDialogModel = 0x28; // "InventoryDialogModel"
            inline constexpr std::uintptr_t entityId = 0x30; // "int"
            inline constexpr std::uintptr_t model = 0x38; // "CargoChargeWorkbenchModel"
            inline constexpr std::uintptr_t isOpened = 0x40; // "bool"
            inline constexpr std::uintptr_t isWorking = 0x41; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xDA15B0; // "public CargoChargeWorkbenchAnimationUpdater Init(CargoChargeWorkbenchView view, InventoryDialogModel inventoryDialogModel, int entityId, CargoChargeWorkbenchModel model)"
            inline constexpr std::uintptr_t Dispose = 0xDA1560; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xDA17B0; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t IsOpened = 0xDA1710; // "private bool IsOpened()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace CargoChargeWorkbenchAnimationUpdater

    namespace CargoChargeWorkbenchBuilderSlotModel { // "Game.Battle.Builder.CargoChargeWorkbenchBuilderSlotModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t plotBuildingCargoWorkbenchSlotDescription = 0x28; // "PlotBuildingCargoChargeWorkbenchSlotDescription"
            inline constexpr std::uintptr_t cargoChargeWorkbenchTypeDescription = 0x30; // "CargoChargeWorkbenchTypeDescription"
            inline constexpr std::uintptr_t cargoChargeWorkbenchesModel = 0x38; // "CargoChargeWorkbenchesModel"
            inline constexpr std::uintptr_t defenseBlockPublicModel = 0x40; // "DefenseBlockPublicModel"
            inline constexpr std::uintptr_t changeFurnitureExpiringResource = 0x48; // "ExpiringResourceModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_InventoryItemDescription = 0xD3CC00; // "public override InventoryItemDescription get_InventoryItemDescription()"
            inline constexpr std::uintptr_t CheckType = 0xD3CA70; // "public override bool CheckType(InventoryItemDescription itemDescription)"
            inline constexpr std::uintptr_t CheckCooldown = 0xD3C9C0; // "public override bool CheckCooldown(long now)"
            inline constexpr std::uintptr_t IsBlockedByBreachedObjects = 0x7EC9F0; // "public override bool IsBlockedByBreachedObjects(long now)"
            inline constexpr std::uintptr_t IsBlockedByLootObjects = 0x7EC9F0; // "public override bool IsBlockedByLootObjects(long now)"
            inline constexpr std::uintptr_t CheckShowModalOnMove = 0xD3C9F0; // "public override bool CheckShowModalOnMove(long now)"
            inline constexpr std::uintptr_t IsBlockedByRaidLock = 0xD3CAF0; // "public override bool IsBlockedByRaidLock(long now)"
            inline constexpr std::uintptr_t get_CargoChargeWorkbenchModel = 0xD3CBA0; // "public CargoChargeWorkbenchModel get_CargoChargeWorkbenchModel()"
        }
    } // namespace CargoChargeWorkbenchBuilderSlotModel

    namespace CargoChargeWorkbenchData { // "Models.Data.Settlement.CargoChargeWorkbench.CargoChargeWorkbenchData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Description = 0x20; // "IPrimitiveData<CargoChargeWorkbenchDescription>"
            inline constexpr std::uintptr_t CargoInventory = 0x28; // "CargoInventoryData"
            inline constexpr std::uintptr_t LastUpdateTs = 0x30; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t Upgrades = 0x38; // "CargoChargeWorkbenchUpgradesData"
        }
    } // namespace CargoChargeWorkbenchData

    namespace CargoChargeWorkbenchDescription { // "Models.References.CargoChargeWorkbench.CargoChargeWorkbenchDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t WorkbenchTypeFunc = 0x20; // "Func<CargoChargeWorkbenchTypeDescription>"
            inline constexpr std::uintptr_t InventoryItemFunc = 0x28; // "Func<InventoryItemDescription>"
            inline constexpr std::uintptr_t CargoInventorySlotsCount = 0x30; // "int"
            inline constexpr std::uintptr_t TickPeriod = 0x38; // "long"
            inline constexpr std::uintptr_t CanCollectChargedCargoReward = 0x40; // "bool"
            inline constexpr std::uintptr_t CollectChargedCargoRewardTime = 0x48; // "long"
            inline constexpr std::uintptr_t Colliders = 0x50; // "CollidersDescription"
            inline constexpr std::uintptr_t InteractPoint = 0x58; // "Vector3"
            inline constexpr std::uintptr_t InteractDescription = 0x68; // "InteractDescription"
            inline constexpr std::uintptr_t SpawnLootPoint = 0x70; // "Vector3"
            inline constexpr std::uintptr_t Obbs = 0x80; // "IReadOnlyList<OBB>"
            inline constexpr std::uintptr_t AvailableSpeedupUpgradeSlotsLazy = 0x88; // "Lazy<IReadOnlyList<CargoChargeWorkbenchSpeedupUpgradeSlotDescription>>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_WorkbenchType = 0x9D6230; // "public CargoChargeWorkbenchTypeDescription get_WorkbenchType()"
            inline constexpr std::uintptr_t get_InventoryItemDescription = 0x993E50; // "public InventoryItemDescription get_InventoryItemDescription()"
            inline constexpr std::uintptr_t get_AvailableSpeedupUpgradeSlots = 0x4482B20; // "public IReadOnlyList<CargoChargeWorkbenchSpeedupUpgradeSlotDescription> get_AvailableSpeedupUpgradeSlots()"
        }
    } // namespace CargoChargeWorkbenchDescription

    namespace CargoChargeWorkbenchDestroyModel { // "Models.Models.CargoChargeWorkbenchDestroy.CargoChargeWorkbenchDestroyModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "CargoChargeWorkbenchModel"
            inline constexpr std::uintptr_t interactIgnoreBodyIds = 0x18; // "HashSet<PhysicsBodyId>"
            inline constexpr std::uintptr_t collidersIdData = 0x20; // "CollidersIdData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Destroy = 0x496C7B0; // "public void Destroy(PhysicsSceneModel physicsSceneModel, WorldEntitiesModel worldEntitiesModel)"
            inline constexpr std::uintptr_t DestroyModel = 0x496C590; // "private void DestroyModel(WorldEntitiesModel worldEntitiesModel)"
            inline constexpr std::uintptr_t DestroyPhysics = 0x496C5C0; // "private void DestroyPhysics(PhysicsSceneModel physicsSceneModel)"
        }
    } // namespace CargoChargeWorkbenchDestroyModel

    namespace CargoChargeWorkbenchEntityIds { // "Models.References.Builder.CargoChargeWorkbenchEntityIds (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ModelEntityId = 0x10; // "int"
            inline constexpr std::uintptr_t CargoInventorySlotEntityIds = 0x18; // "IReadOnlyDictionary<CargoInventorySlotDescription, int>"
            inline constexpr std::uintptr_t UpgradesEntityIds = 0x20; // "CargoChargeWorkbenchUpgradesEntityIds"
        }
    } // namespace CargoChargeWorkbenchEntityIds

    namespace CargoChargeWorkbenchesModel { // "Models.Models.CargoChargeWorkbenches.CargoChargeWorkbenchesModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t models = 0x10; // "Dictionary<PlotBuildingCargoChargeWorkbenchSlotDescription, CargoChargeWorkbenchModel>"
            inline constexpr std::uintptr_t Models = 0x18; // "ReadOnly.Dictionary<PlotBuildingCargoChargeWorkbenchSlotDescription, CargoChargeWorkbenchModel>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Add = 0x496D2C0; // "public void Add(PlotBuildingCargoChargeWorkbenchSlotDescription slot, CargoChargeWorkbenchModel model)"
            inline constexpr std::uintptr_t Remove = 0x496D330; // "public void Remove(PlotBuildingCargoChargeWorkbenchSlotDescription slot)"
        }
    } // namespace CargoChargeWorkbenchesModel

    namespace CargoChargeWorkbenchExtensions { // "Models.Utils.Extensions.CargoChargeWorkbenchExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t BuildEntityIds = 0x3936B90; // "public static CargoChargeWorkbenchEntityIds BuildEntityIds(IEntityIdGenerator entityIdGenerator)"
            inline constexpr std::uintptr_t BuildUpgradesEntityIds = 0x39374A0; // "private static CargoChargeWorkbenchUpgradesEntityIds BuildUpgradesEntityIds(IEntityIdGenerator entityIdGenerator)"
            inline constexpr std::uintptr_t BuildModel = 0x3937170; // "public static CargoChargeWorkbenchModel BuildModel(CargoChargeWorkbenchData data, PlotSlotDescription plotSlotDescription, PlotBuildingCargoChargeWorkbenchSlotDescription plotBuildingCargoChargeWorkbenchSlotDescription, CargoChargeWorkbenchEntityIds cargoChargeWorkbenchEntityIds, OrientedPoint orientedPoint)"
            inline constexpr std::uintptr_t BuildLocationDescription = 0x3936E80; // "private static LocationCargoChargeWorkbenchDescription BuildLocationDescription(CargoChargeWorkbenchDescription description, OrientedPoint orientedPoint, CargoChargeWorkbenchEntityIds entityIds)"
            inline constexpr std::uintptr_t BuildPlotBuildingSlotsEnum = 0x39372D0; // "public static ReadOnlyEnum<PlotBuildingCargoChargeWorkbenchSlotDescription> BuildPlotBuildingSlotsEnum(ReadOnlyEnum<OutbuildingDescription> outbuildingDescriptions)"
            inline constexpr std::uintptr_t GetAssetsValue = 0x3937D30; // "public static int GetAssetsValue(CargoChargeWorkbenchModel model)"
            inline constexpr std::uintptr_t CanPutCargoInWorkbench = 0x39378E0; // "public static bool CanPutCargoInWorkbench(CargoDescription cargo, CargoChargeWorkbenchModel cargoChargeWorkbenchModel)"
            inline constexpr std::uintptr_t HasNotChargedCargo = 0x3938330; // "public static bool HasNotChargedCargo(CargoChargeWorkbenchModel cargoChargeWorkbenchModel)"
            inline constexpr std::uintptr_t CanCollectReward = 0x3937740; // "public static bool CanCollectReward(CargoChargeWorkbenchModel cargoChargeWorkbenchModel)"
            inline constexpr std::uintptr_t TryGetMaxPossibleCollectRewardFromCargo = 0x39383F0; // "public static bool TryGetMaxPossibleCollectRewardFromCargo(CargoDescription cargo, CargoChargeWorkbenchTypeDescription workbenchType, SettlementBonusModel settlementBonusModel, out InventoryItemDescription item, out int amount)"
            inline constexpr std::uintptr_t HasLootInside = 0x3938060; // "public static bool HasLootInside(CargoChargeWorkbenchModel cargoChargeWorkbenchModel)"
            inline constexpr std::uintptr_t HasChargedCargoCollectRewardBonus = 0x3937ED0; // "public static bool HasChargedCargoCollectRewardBonus(SettlementBonusModel settlementBonusModel, CargoChargeWorkbenchTypeDescription workbenchTypeDescription, out float bonusRewardProbability)"
            inline constexpr std::uintptr_t CheckSpawnLootOnSwap = 0x3937950; // "public static bool CheckSpawnLootOnSwap(CargoChargeWorkbenchModel cargoChargeWorkbenchModel, CargoChargeWorkbenchDescription newDescription)"
        }
    } // namespace CargoChargeWorkbenchExtensions

    namespace CargoChargeWorkbenchInitializeModel { // "Models.Models.CargoChargeWorkbenchInitialize.CargoChargeWorkbenchInitializeModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "CargoChargeWorkbenchModel"
            inline constexpr std::uintptr_t plotSlotDescription = 0x18; // "PlotSlotDescription"
            inline constexpr std::uintptr_t interactIgnoreBodyIds = 0x20; // "HashSet<PhysicsBodyId>"
            inline constexpr std::uintptr_t collidersIdData = 0x28; // "CollidersIdData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Initialize = 0x496C9F0; // "public void Initialize(PhysicsSceneModel physicsSceneModel, WorldEntitiesModel worldEntitiesModel, OutbuildingSlotDescription outbuildingSlotDescription)"
            inline constexpr std::uintptr_t InitializeModel = 0x496C800; // "private void InitializeModel(WorldEntitiesModel worldEntitiesModel, OutbuildingSlotDescription outbuildingSlotDescription)"
            inline constexpr std::uintptr_t InitializePhysics = 0x496C840; // "private void InitializePhysics(PhysicsSceneModel physicsSceneModel)"
        }
    } // namespace CargoChargeWorkbenchInitializeModel

    namespace CargoChargeWorkbenchModel { // "Models.Models.CargoChargeWorkbench.CargoChargeWorkbenchModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t PlotBuildingCargoChargeWorkbenchSlotDescription = 0x10; // "PlotBuildingCargoChargeWorkbenchSlotDescription"
            inline constexpr std::uintptr_t Description = 0x18; // "CargoChargeWorkbenchDescription"
            inline constexpr std::uintptr_t LocationCargoChargeWorkbenchDescription = 0x20; // "LocationCargoChargeWorkbenchDescription"
            inline constexpr std::uintptr_t InitializeModel = 0x28; // "CargoChargeWorkbenchInitializeModel"
            inline constexpr std::uintptr_t DestroyModel = 0x30; // "CargoChargeWorkbenchDestroyModel"
            inline constexpr std::uintptr_t InteractIgnoreRigidBodies = 0x38; // "HashSet<PhysicsBodyId>"
            inline constexpr std::uintptr_t CargoInventoryModel = 0x40; // "CargoInventoryModel"
            inline constexpr std::uintptr_t LastUpdateTsModel = 0x48; // "IPrimitiveModel<long>"
            inline constexpr std::uintptr_t Upgrades = 0x50; // "CargoChargeWorkbenchUpgradesModel"
        }
    } // namespace CargoChargeWorkbenchModel

    namespace CargoChargeWorkbenchModelUpdater { // "Game.Battle.SettlementBuilder.CargoChargeWorkbenchModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t plotSlotDescription = 0x20; // "PlotSlotDescription"
            inline constexpr std::uintptr_t outbuildingSlotDescription = 0x28; // "OutbuildingSlotDescription"
            inline constexpr std::uintptr_t slot = 0x30; // "PlotBuildingCargoChargeWorkbenchSlotDescription"
            inline constexpr std::uintptr_t data = 0x38; // "DictionaryData<PlotBuildingCargoChargeWorkbenchSlotDescription, CargoChargeWorkbenchData>"
            inline constexpr std::uintptr_t model = 0x40; // "CargoChargeWorkbenchesModel"
            inline constexpr std::uintptr_t entityIds = 0x48; // "CargoChargeWorkbenchEntityIds"
            inline constexpr std::uintptr_t orientedPoint = 0x50; // "OrientedPoint"
            inline constexpr std::uintptr_t physicsSceneModel = 0x58; // "PhysicsSceneModel"
            inline constexpr std::uintptr_t worldEntitiesModel = 0x60; // "WorldEntitiesModel"
            inline constexpr std::uintptr_t description = 0x68; // "CargoChargeWorkbenchDescription"
            inline constexpr std::uintptr_t workbenchData = 0x70; // "CargoChargeWorkbenchData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xDA28C0; // "public CargoChargeWorkbenchModelUpdater Init(PlotSlotDescription plotSlotDescription, OutbuildingSlotDescription outbuildingSlotDescription, PlotBuildingCargoChargeWorkbenchSlotDescription slot, DictionaryData<PlotBuildingCargoChargeWorkbenchSlotDescription, CargoChargeWorkbenchData> data, CargoChargeWorkbenchesModel model, CargoChargeWorkbenchEntityIds entityIds, OrientedPoint orientedPoint, PhysicsSceneModel physicsSceneModel, WorldEntitiesModel worldEntitiesModel)"
            inline constexpr std::uintptr_t Dispose = 0xDA2700; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xDA29B0; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Create = 0xDA2590; // "private void Create(CargoChargeWorkbenchDescription description, CargoChargeWorkbenchData workbenchData)"
            inline constexpr std::uintptr_t Destroy = 0xDA2650; // "private void Destroy()"
            inline constexpr std::uintptr_t GetDescription = 0xDA27C0; // "private CargoChargeWorkbenchDescription GetDescription()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace CargoChargeWorkbenchModelUpdater

    namespace CargoChargeWorkbenchSpeedupUpgradeDescription { // "Models.References.CargoChargeWorkbench.CargoChargeWorkbenchSpeedupUpgradeDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ItemFunc = 0x20; // "Func<InventoryItemDescription>"
            inline constexpr std::uintptr_t SlotTypeFunc = 0x28; // "Func<CargoChargeWorkbenchSpeedupUpgradeSlotTypeDescription>"
            inline constexpr std::uintptr_t SpeedupPercent = 0x30; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Item = 0x9D6230; // "public InventoryItemDescription get_Item()"
            inline constexpr std::uintptr_t get_SlotType = 0x993E50; // "public CargoChargeWorkbenchSpeedupUpgradeSlotTypeDescription get_SlotType()"
        }
    } // namespace CargoChargeWorkbenchSpeedupUpgradeDescription

    namespace CargoChargeWorkbenchSpeedupUpgradeModel { // "Models.Models.CargoChargeWorkbenchUpgrades.CargoChargeWorkbenchSpeedupUpgradeModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "IPrimitiveData<CargoChargeWorkbenchSpeedupUpgradeDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Value = 0x496CEA0; // "public CargoChargeWorkbenchSpeedupUpgradeDescription get_Value()"
            inline constexpr std::uintptr_t set_Value = 0x496CF60; // "public void set_Value(CargoChargeWorkbenchSpeedupUpgradeDescription value)"
        }
    } // namespace CargoChargeWorkbenchSpeedupUpgradeModel

    namespace CargoChargeWorkbenchSpeedupUpgradeSlotDescription { // "Models.References.CargoChargeWorkbench.CargoChargeWorkbenchSpeedupUpgradeSlotDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t TypeFunc = 0x20; // "Func<CargoChargeWorkbenchSpeedupUpgradeSlotTypeDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x9D6230; // "public CargoChargeWorkbenchSpeedupUpgradeSlotTypeDescription get_Type()"
        }
    } // namespace CargoChargeWorkbenchSpeedupUpgradeSlotDescription

    namespace CargoChargeWorkbenchTargetActions { // "Game.Battle.SettlementBuilder.CargoChargeWorkbenchTargetActions (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t entityId = 0x10; // "int"
            inline constexpr std::uintptr_t battleInputModel = 0x18; // "BattleInputModel"
            inline constexpr std::uintptr_t uiSoundModel = 0x20; // "GlobalUISoundModel"
            inline constexpr std::uintptr_t notificationModel = 0x28; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t inventoryDialogModel = 0x30; // "InventoryDialogModel"
            inline constexpr std::uintptr_t PutCargoAction = 0x38; // "TargetAction"
            inline constexpr std::uintptr_t InteractActionItemsList = 0x40; // "List<ITargetActionItem>"
            inline constexpr std::uintptr_t InteractAction = 0x48; // "ITargetAction"
            inline constexpr std::uintptr_t CollectChargedCargoRewardActionItem = 0x50; // "TargetActionWithNotificationItem"
            inline constexpr std::uintptr_t OpenInventoryActionItem = 0x58; // "TargetActionWithNotificationItem"
            inline constexpr std::uintptr_t OpenBuilderActionItem = 0x60; // "TargetActionWithNotificationItem"
        }
        namespace Methods {
            inline constexpr std::uintptr_t CollectChargedCargoReward = 0xDA3B10; // "private void CollectChargedCargoReward()"
            inline constexpr std::uintptr_t OpenInventory = 0xDA3C60; // "private void OpenInventory()"
            inline constexpr std::uintptr_t OpenBuilder = 0xDA3BE0; // "private void OpenBuilder()"
            inline constexpr std::uintptr_t PutCargo = 0xDA3CE0; // "private void PutCargo()"
            inline constexpr std::uintptr_t Unavailable = 0xDA3DB0; // "private void Unavailable(LocalizedString notification, PersonalNotificationActionIds id)"
        }
    } // namespace CargoChargeWorkbenchTargetActions

    namespace CargoChargeWorkbenchTargetProvider { // "Game.Battle.SettlementBuilder.CargoChargeWorkbenchTargetProvider (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t targetActions = 0x20; // "CargoChargeWorkbenchTargetActions"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x28; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t model = 0x30; // "CargoChargeWorkbenchModel"
            inline constexpr std::uintptr_t publicId = 0x38; // "long"
            inline constexpr std::uintptr_t entityId = 0x40; // "int"
            inline constexpr std::uintptr_t unavailable = 0x48; // "UnavailableTargetActionsKeys"
            inline constexpr std::uintptr_t settlementHelperModel = 0x50; // "ISettlementHelperModel"
            inline constexpr std::uintptr_t partyMemberAccessModel = 0x58; // "IPartyMemberAccessModel"
            inline constexpr std::uintptr_t settlementBonusModel = 0x60; // "SettlementBonusModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t GetTargetAction = 0xDA4810; // "protected override ITargetAction GetTargetAction()"
            inline constexpr std::uintptr_t GetCanOpenInventoryInvalidNotification = 0xDA4740; // "private LocalizedString GetCanOpenInventoryInvalidNotification(PlayerEntityModel player)"
            inline constexpr std::uintptr_t GetCanHarvestInvalidNotification = 0xDA4330; // "private LocalizedString GetCanHarvestInvalidNotification(PlayerEntityModel player)"
            inline constexpr std::uintptr_t GetCanOpenBuilderInvalidNotification = 0xDA4740; // "private LocalizedString GetCanOpenBuilderInvalidNotification(PlayerEntityModel player)"
            inline constexpr std::uintptr_t UpdatePutCargoAction = 0xDA4BD0; // "private void UpdatePutCargoAction()"
        }
    } // namespace CargoChargeWorkbenchTargetProvider

    namespace CargoChargeWorkbenchUpgradeBuilderSlotModel { // "Game.Battle.Builder.CargoChargeWorkbenchUpgradeBuilderSlotModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t defenseBlockPublicModel = 0x28; // "DefenseBlockPublicModel"
            inline constexpr std::uintptr_t slot = 0x30; // "CargoChargeWorkbenchSpeedupUpgradeSlotDescription"
            inline constexpr std::uintptr_t speedupUpgradeModel = 0x38; // "CargoChargeWorkbenchSpeedupUpgradeModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_InventoryItemDescription = 0xD3CD90; // "public override InventoryItemDescription get_InventoryItemDescription()"
            inline constexpr std::uintptr_t CheckType = 0xD3CC90; // "public override bool CheckType(InventoryItemDescription itemDescription)"
            inline constexpr std::uintptr_t CheckCooldown = 0x7D5050; // "public override bool CheckCooldown(long now)"
            inline constexpr std::uintptr_t IsBlockedByBreachedObjects = 0x7EC9F0; // "public override bool IsBlockedByBreachedObjects(long now)"
            inline constexpr std::uintptr_t IsBlockedByLootObjects = 0x7EC9F0; // "public override bool IsBlockedByLootObjects(long now)"
            inline constexpr std::uintptr_t CheckShowModalOnMove = 0x7EC9F0; // "public override bool CheckShowModalOnMove(long now)"
            inline constexpr std::uintptr_t IsBlockedByRaidLock = 0xD3CD10; // "public override bool IsBlockedByRaidLock(long now)"
        }
    } // namespace CargoChargeWorkbenchUpgradeBuilderSlotModel

    namespace CargoChargeWorkbenchUpgradesData { // "Models.Data.Settlement.CargoChargeWorkbench.CargoChargeWorkbenchUpgradesData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Speedup = 0x20; // "ReferenceMapData<CargoChargeWorkbenchSpeedupUpgradeSlotDescription, IPrimitiveData<CargoChargeWorkbenchSpeedupUpgradeDescription>>"
        }
    } // namespace CargoChargeWorkbenchUpgradesData

    namespace CargoChargeWorkbenchUpgradesEntityIds { // "Models.References.Builder.CargoChargeWorkbenchUpgradesEntityIds (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t SpeedupEntityIds = 0x10; // "IReadOnlyDictionary<CargoChargeWorkbenchSpeedupUpgradeSlotDescription, int>"
        }
    } // namespace CargoChargeWorkbenchUpgradesEntityIds

    namespace CargoChargeWorkbenchUpgradesModel { // "Models.Models.CargoChargeWorkbenchUpgrades.CargoChargeWorkbenchUpgradesModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Speedup = 0x10; // "ReadOnly.Dictionary<CargoChargeWorkbenchSpeedupUpgradeSlotDescription, CargoChargeWorkbenchSpeedupUpgradeModel>"
        }
    } // namespace CargoChargeWorkbenchUpgradesModel

    namespace CargoClientModel { // "Game.Battle.EntityModel.Cargo.Model.CargoClientModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t DataState = 0x10; // "EntityDataStateModel"
            inline constexpr std::uintptr_t MovementTimeline = 0x18; // "MovementTimeline"
            inline constexpr std::uintptr_t Position = 0x20; // "SetMovementModel"
            inline constexpr std::uintptr_t SleepState = 0x28; // "SleepStateSimpleDotPhysicsModel"
        }
    } // namespace CargoClientModel

    namespace CargoConfig { // "Models.References.Cargo.CargoConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t RotationSectorCount = 0x10; // "int"
            inline constexpr std::uintptr_t DropOffset = 0x14; // "Vector3"
            inline constexpr std::uintptr_t Gravity = 0x20; // "float"
            inline constexpr std::uintptr_t AirResistance = 0x24; // "float"
        }
    } // namespace CargoConfig

    namespace CargoData { // "Models.Data.CargoData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Description = 0x20; // "IPrimitiveData<CargoDescription>"
            inline constexpr std::uintptr_t CumulativePoints = 0x28; // "IPrimitiveData<int>"
        }
    } // namespace CargoData

    namespace CargoDescription { // "Models.References.Cargo.CargoDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Rare = 0x20; // "RarityItem"
            inline constexpr std::uintptr_t TakeTime = 0x28; // "long"
            inline constexpr std::uintptr_t ArrestCoinsReward = 0x30; // "int"
            inline constexpr std::uintptr_t ExchangeCoinsReward = 0x34; // "int"
            inline constexpr std::uintptr_t OpenWorkbenchTypeFunc = 0x38; // "Func<CargoWorkbenchTypeDescription>"
            inline constexpr std::uintptr_t OpenTime = 0x40; // "long"
            inline constexpr std::uintptr_t CarryType = 0x48; // "CargoCarryType"
            inline constexpr std::uintptr_t BreakBreakableCollidersOnFalling = 0x49; // "bool"
            inline constexpr std::uintptr_t ExchangeCumulativePoints = 0x4C; // "int"
            inline constexpr std::uintptr_t ExchangeTime = 0x50; // "long"
            inline constexpr std::uintptr_t ExchangeCargoFunc = 0x58; // "Func<CargoDescription>"
            inline constexpr std::uintptr_t ImprovedExchangeCargoFunc = 0x60; // "Func<CargoDescription>"
            inline constexpr std::uintptr_t CumulativeCargoFunc = 0x68; // "Func<CumulativeCargoDescription>"
            inline constexpr std::uintptr_t CargoProductionWorkbenchRecipeFunc = 0x70; // "Func<CargoProductionWorkbenchRecipeDescription>"
            inline constexpr std::uintptr_t CargoChargeWorkbenchTypeFunc = 0x78; // "Func<CargoChargeWorkbenchTypeDescription>"
            inline constexpr std::uintptr_t ChargedCargoCollectRewardFunc = 0x80; // "Func<ChargedCargoCollectRewardDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_OpenWorkbenchType = 0x2AA0B60; // "public CargoWorkbenchTypeDescription get_OpenWorkbenchType()"
            inline constexpr std::uintptr_t get_ExchangeCargo = 0x4048FB0; // "public CargoDescription get_ExchangeCargo()"
            inline constexpr std::uintptr_t get_ImprovedExchangeCargo = 0x4048EC0; // "public CargoDescription get_ImprovedExchangeCargo()"
            inline constexpr std::uintptr_t get_CanBeExchanged = 0x40A2200; // "public bool get_CanBeExchanged()"
            inline constexpr std::uintptr_t get_CumulativeCargo = 0x4048EF0; // "public CumulativeCargoDescription get_CumulativeCargo()"
            inline constexpr std::uintptr_t get_IsCumulative = 0x43E8630; // "public bool get_IsCumulative()"
            inline constexpr std::uintptr_t get_CargoProductionWorkbenchRecipe = 0x4048F80; // "public CargoProductionWorkbenchRecipeDescription get_CargoProductionWorkbenchRecipe()"
            inline constexpr std::uintptr_t get_ContainsRecipeForCargoProductionWorkbench = 0x4402A90; // "public bool get_ContainsRecipeForCargoProductionWorkbench()"
            inline constexpr std::uintptr_t get_CargoChargeWorkbenchType = 0x4048F20; // "public CargoChargeWorkbenchTypeDescription get_CargoChargeWorkbenchType()"
            inline constexpr std::uintptr_t get_CanPutInChargeWorkbench = 0x4402A50; // "public bool get_CanPutInChargeWorkbench()"
            inline constexpr std::uintptr_t get_ChargedCargoCollectReward = 0x4048F50; // "public ChargedCargoCollectRewardDescription get_ChargedCargoCollectReward()"
            inline constexpr std::uintptr_t get_HasChargedCargoCollectReward = 0x4484900; // "public bool get_HasChargedCargoCollectReward()"
        }
    } // namespace CargoDescription

    namespace CargoDroppedData { // "Models.Data.CargoDroppedData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Description = 0x20; // "CargoDescription"
            inline constexpr std::uintptr_t CumulativePoints = 0x28; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t SpawnTickIndex = 0x30; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t X = 0x38; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t Y = 0x40; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t Z = 0x48; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t RySector = 0x50; // "IPrimitiveData<int>"
        }
    } // namespace CargoDroppedData

    namespace CargoEntityDataBuilder { // "Models.Replication.EntityDataBuilder.CargoEntityDataBuilder (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t paramsModel = 0x10; // "EntitiesParamsModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Build = 0x44B50B0; // "public IData Build(int id)"
        }
    } // namespace CargoEntityDataBuilder

    namespace CargoEntityModel { // "Game.Battle.EntityModel.Cargo.Model.CargoEntityModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ServerModel = 0x18; // "CargoModel"
            inline constexpr std::uintptr_t ClientModel = 0x20; // "CargoClientModel"
        }
    } // namespace CargoEntityModel

    namespace CargoEntityStreamReader { // "Models.Replication.EntityStreamReader.CargoEntityStreamReader (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t paramsModel = 0x20; // "EntitiesParamsModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t TryReadParams = 0x44B51B0; // "protected override bool TryReadParams(int entityId, IBinaryReadStream stream)"
        }
    } // namespace CargoEntityStreamReader

    namespace CargoExchangerCashUpdater { // "Game.Battle.Entities.CargoExchanger.Updaters.CargoExchangerCashUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t cargoExchangerModel = 0x10; // "CargoExchangerModel"
            inline constexpr std::uintptr_t cargoExchangerView = 0x18; // "CargoExchangerView"
            inline constexpr std::uintptr_t cargoCashAmount = 0x20; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB7B350; // "public void Update()"
        }
    } // namespace CargoExchangerCashUpdater

    namespace CargoExchangerConfig { // "Models.References.Cargo.CargoExchangerConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t MaxCashAmount = 0x10; // "int"
            inline constexpr std::uintptr_t MaxCargoAmount = 0x14; // "int"
            inline constexpr std::uintptr_t MaxPutCargoQueueLength = 0x18; // "int"
        }
    } // namespace CargoExchangerConfig

    namespace CargoExchangerData { // "Models.Data.CargoExchangerData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Description = 0x20; // "LocationCargoExchangerDescription"
            inline constexpr std::uintptr_t CashAmount = 0x28; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t Cargos = 0x30; // "ReferenceMapData<CargoDescription, IPrimitiveData<int>>"
            inline constexpr std::uintptr_t PutCargoQueue = 0x38; // "ListData<IPrimitiveData<CargoDescription>>"
        }
    } // namespace CargoExchangerData

    namespace CargoExchangerDescription { // "Models.References.Cargo.CargoExchangerDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsSettlementLocked = 0x20; // "bool"
        }
    } // namespace CargoExchangerDescription

    namespace CargoExchangerEntityDataBuilder { // "Models.Replication.EntityDataBuilder.CargoExchangerEntityDataBuilder (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t location = 0x10; // "LocationDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Build = 0x44B52B0; // "public IData Build(int id)"
        }
    } // namespace CargoExchangerEntityDataBuilder

    namespace CargoExchangerEntityModel { // "Game.Battle.EntityModel.CargoExchanger.CargoExchangerEntityModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ServerModel = 0x18; // "CargoExchangerModel"
            inline constexpr std::uintptr_t TriggerFirstLookMarkerModel = 0x20; // "TriggerFirstLookMarkerModel"
        }
    } // namespace CargoExchangerEntityModel

    namespace CargoExchangerEntityStreamReader { // "Models.Replication.EntityStreamReader.CargoExchangerEntityStreamReader (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t GetEntityId = 0x391B2D0; // "protected override int GetEntityId(LocationCargoExchangerDescription description)"
        }
    } // namespace CargoExchangerEntityStreamReader

    namespace CargoExchangerExtensions { // "Models.Utils.Extensions.CargoExchangerExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t CalculateReward = 0x393ACB0; // "public static int CalculateReward(CargoExchangerModel cargoExchangerModel, RobberAuthorityModel robberAuthority, LocationDescription location)"
            inline constexpr std::uintptr_t GetCargoReward = 0x393B030; // "private static long GetCargoReward(CargoDescription cargoDescription, int count, float[] bonusModifiers)"
            inline constexpr std::uintptr_t CalculateArrestRewardCash = 0x393AC40; // "public static int CalculateArrestRewardCash(CargoExchangerModel cargoExchangerModel)"
            inline constexpr std::uintptr_t CalculateArrestRewardCargos = 0x393AAA0; // "public static int CalculateArrestRewardCargos(CargoExchangerModel cargoExchangerModel)"
        }
    } // namespace CargoExchangerExtensions

    namespace CargoExchangerModel { // "Models.Models.CargoExchanger.CargoExchangerModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "CargoExchangerData"
            inline constexpr std::uintptr_t Description = 0x18; // "LocationCargoExchangerDescription"
            inline constexpr std::uintptr_t InteractPositionModel = 0x20; // "IPositionModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_CashAmount = 0x496FB00; // "public int get_CashAmount()"
            inline constexpr std::uintptr_t GetCargoCount = 0x496F820; // "public int GetCargoCount(CargoDescription cargoDescription)"
            inline constexpr std::uintptr_t GetAllCargosCount = 0x496F630; // "public int GetAllCargosCount()"
            inline constexpr std::uintptr_t CheckAddCargo = 0x496EF60; // "public bool CheckAddCargo()"
            inline constexpr std::uintptr_t AddCargo = 0x496EDD0; // "public void AddCargo(CargoDescription cargoDescription)"
            inline constexpr std::uintptr_t CheckExchange = 0x496F2E0; // "public bool CheckExchange()"
            inline constexpr std::uintptr_t Exchange = 0x496F410; // "public void Exchange(int amount)"
            inline constexpr std::uintptr_t CheckArrest = 0x496F1C0; // "public bool CheckArrest()"
            inline constexpr std::uintptr_t Arrest = 0x496EF50; // "public void Arrest()"
            inline constexpr std::uintptr_t CheckTakeCash = 0x496F3B0; // "public bool CheckTakeCash()"
            inline constexpr std::uintptr_t TakeCash = 0x496F920; // "public void TakeCash(int amount)"
            inline constexpr std::uintptr_t get_PutCargoQueueLength = 0x496FB50; // "public int get_PutCargoQueueLength()"
            inline constexpr std::uintptr_t GetCargoFromQueue = 0x496F8A0; // "public CargoDescription GetCargoFromQueue(int index)"
        }
    } // namespace CargoExchangerModel

    namespace CargoExchangerRewardMessage { // "Models.Messages.CargoExchangerRewardMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t entityId = 0x20; // "BattleEntityIdData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_EntityId = 0x49E9880; // "public int get_EntityId()"
            inline constexpr std::uintptr_t get_Type = 0x49E98C0; // "public override string get_Type()"
        }
    } // namespace CargoExchangerRewardMessage

    namespace CargoExchangerTargetActions { // "Game.Battle.EntityModel.CargoExchanger.CargoExchangerTargetActions (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleInputModel = 0x10; // "BattleInputModel"
            inline constexpr std::uintptr_t battleScreenContent = 0x18; // "BattleScreenContent"
            inline constexpr std::uintptr_t cargoExchangerDialogModel = 0x20; // "CargoExchangerDialogModel"
            inline constexpr std::uintptr_t cargoExchangerEntityModel = 0x28; // "CargoExchangerEntityModel"
            inline constexpr std::uintptr_t personalNotificationModel = 0x30; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t soundModel = 0x38; // "GlobalUISoundModel"
            inline constexpr std::uintptr_t soundEmitter = 0x40; // "GameObject"
            inline constexpr std::uintptr_t cargoExchangerViewDescriptions = 0x48; // "CargoExchangerViewDescriptions"
            inline constexpr std::uintptr_t clientCodexModel = 0x50; // "ClientCodexModel"
            inline constexpr std::uintptr_t Put = 0x58; // "TargetAction"
            inline constexpr std::uintptr_t Open = 0x60; // "ITargetAction"
            inline constexpr std::uintptr_t Arrest = 0x68; // "TargetAction"
            inline constexpr std::uintptr_t Take = 0x70; // "TargetAction"
        }
        namespace Methods {
            inline constexpr std::uintptr_t ArrestCargoOrMoney = 0xC9E130; // "private void ArrestCargoOrMoney()"
            inline constexpr std::uintptr_t OpenDialogCargoExchanger = 0xC9E610; // "private void OpenDialogCargoExchanger()"
            inline constexpr std::uintptr_t TakeMoney = 0xC9E830; // "private void TakeMoney()"
            inline constexpr std::uintptr_t PutCargo = 0xC9E740; // "private void PutCargo()"
            inline constexpr std::uintptr_t Unavailable = 0xC9E930; // "private void Unavailable(LocalizedString invalidNotification, PersonalNotificationActionIds id)"
            inline constexpr std::uintptr_t CreateTakeMoneyTargetAction = 0xC9E510; // "private TargetAction CreateTakeMoneyTargetAction(Action action, Action<LocalizedString, PersonalNotificationActionIds> invalidAction)"
            inline constexpr std::uintptr_t CreateArrestCargoTargetAction = 0xC9E200; // "private TargetAction CreateArrestCargoTargetAction(Action action, Action<LocalizedString, PersonalNotificationActionIds> invalidAction)"
            inline constexpr std::uintptr_t CreateOpenCargoRoleTargetAction = 0xC9E320; // "private AvailableTargetAction CreateOpenCargoRoleTargetAction(Action action)"
            inline constexpr std::uintptr_t CreatePutCargoTargetAction = 0xC9E3F0; // "private TargetAction CreatePutCargoTargetAction(Action validAction, Action<LocalizedString, PersonalNotificationActionIds> invalidAction, string pictogram)"
        }
    } // namespace CargoExchangerTargetActions

    namespace CargoExchangerTargetProvider { // "Game.Battle.EntityModel.CargoExchanger.CargoExchangerTargetProvider (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t exchangerEntityModel = 0x20; // "CargoExchangerEntityModel"
            inline constexpr std::uintptr_t raycastTargetOptions = 0x28; // "UnityRaycastTargetOptions"
            inline constexpr std::uintptr_t actions = 0x30; // "CargoExchangerTargetActions"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x38; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t unavailableKeys = 0x40; // "UnavailableTargetActionsKeys"
            inline constexpr std::uintptr_t notificationKeys = 0x48; // "NotificationKeys"
            inline constexpr std::uintptr_t globalModel = 0x50; // "GlobalModel"
            inline constexpr std::uintptr_t settlementModel = 0x58; // "SettlementModel"
            inline constexpr std::uintptr_t targetAction = 0x60; // "ITargetAction"
        }
        namespace Methods {
            inline constexpr std::uintptr_t GetTargetAction = 0xC9F2C0; // "protected override ITargetAction GetTargetAction()"
            inline constexpr std::uintptr_t GetTakeTargetAction = 0xC9F1C0; // "private TargetAction GetTakeTargetAction(PlayerEntityModel player)"
            inline constexpr std::uintptr_t CanTakeMoney = 0xC9F120; // "private bool CanTakeMoney(PlayerEntityModel player)"
            inline constexpr std::uintptr_t CanPutCargo = 0xC9F0F0; // "private bool CanPutCargo()"
            inline constexpr std::uintptr_t CanArrest = 0xC9F0C0; // "private bool CanArrest()"
            inline constexpr std::uintptr_t HasCargoInCar = 0xC9F6E0; // "private bool HasCargoInCar()"
            inline constexpr std::uintptr_t HasMoneyInCar = 0xC9F710; // "private bool HasMoneyInCar()"
        }
    } // namespace CargoExchangerTargetProvider

    namespace CargoExchangeWorkbenchAdditionalSlotUpgradeBuilderSlotModel { // "Game.Battle.Builder.CargoExchangeWorkbenchAdditionalSlotUpgradeBuilderSlotModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x28; // "IPrimitiveModel<CargoExchangeWorkbenchAdditionalSlotUpgradeDescription>"
            inline constexpr std::uintptr_t defenseBlockPublicModel = 0x30; // "DefenseBlockPublicModel"
            inline constexpr std::uintptr_t CargoSlotModels = 0x38; // "IReadOnlyList<CargoExchangeWorkbenchSlotModel>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_InventoryItemDescription = 0xD3D0A0; // "public override InventoryItemDescription get_InventoryItemDescription()"
            inline constexpr std::uintptr_t CheckType = 0xD3CFC0; // "public override bool CheckType(InventoryItemDescription itemDescription)"
            inline constexpr std::uintptr_t CheckCooldown = 0x7D5050; // "public override bool CheckCooldown(long now)"
            inline constexpr std::uintptr_t IsBlockedByBreachedObjects = 0x7EC9F0; // "public override bool IsBlockedByBreachedObjects(long now)"
            inline constexpr std::uintptr_t IsBlockedByLootObjects = 0x7EC9F0; // "public override bool IsBlockedByLootObjects(long now)"
            inline constexpr std::uintptr_t CheckShowModalOnMove = 0xD3CDD0; // "public override bool CheckShowModalOnMove(long now)"
            inline constexpr std::uintptr_t IsBlockedByRaidLock = 0xD3D010; // "public override bool IsBlockedByRaidLock(long now)"
        }
    } // namespace CargoExchangeWorkbenchAdditionalSlotUpgradeBuilderSlotModel

    namespace CargoExchangeWorkbenchAdditionalSlotUpgradeDescription { // "Models.References.CargoExchangeWorkbench.CargoExchangeWorkbenchAdditionalSlotUpgradeDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t InventoryItemFunc = 0x20; // "Func<InventoryItemDescription>"
            inline constexpr std::uintptr_t AdditionalSlots = 0x28; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_InventoryItem = 0x9D6230; // "public InventoryItemDescription get_InventoryItem()"
        }
    } // namespace CargoExchangeWorkbenchAdditionalSlotUpgradeDescription

    namespace CargoExchangeWorkbenchData { // "Models.Data.Settlement.CargoExchangeWorkbench.CargoExchangeWorkbenchData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Description = 0x20; // "IPrimitiveData<CargoExchangeWorkbenchDescription>"
            inline constexpr std::uintptr_t Slots = 0x28; // "ReferenceMapData<CargoExchangeWorkbenchSlotDescription, CargoExchangeWorkbenchSlotData>"
            inline constexpr std::uintptr_t SpeedupUpgradeSlots = 0x30; // "ReferenceMapData<CargoExchangeWorkbenchSpeedupUpgradeSlotDescription, IPrimitiveData<CargoExchangeWorkbenchSpeedupUpgradeDescription>>"
            inline constexpr std::uintptr_t AdditionalSlotUpgradeSlots = 0x38; // "ReferenceMapData<CargoExchangeWorkbenchAdditionalSlotUpgradeSlotDescription, IPrimitiveData<CargoExchangeWorkbenchAdditionalSlotUpgradeDescription>>"
        }
    } // namespace CargoExchangeWorkbenchData

    namespace CargoExchangeWorkbenchDescription { // "Models.References.CargoExchangeWorkbench.CargoExchangeWorkbenchDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t InventoryItemFunc = 0x20; // "Func<InventoryItemDescription>"
            inline constexpr std::uintptr_t BaseSlotsCount = 0x28; // "int"
            inline constexpr std::uintptr_t SpeedupUpgradeSlotsCount = 0x2C; // "int"
            inline constexpr std::uintptr_t AdditionalSlotUpgradeSlotsCount = 0x30; // "int"
            inline constexpr std::uintptr_t Colliders = 0x38; // "CollidersDescription"
            inline constexpr std::uintptr_t InteractPoint = 0x40; // "Vector3"
            inline constexpr std::uintptr_t InteractDescription = 0x50; // "InteractDescription"
            inline constexpr std::uintptr_t SpawnLootPoint = 0x58; // "Vector3"
            inline constexpr std::uintptr_t Obbs = 0x68; // "IReadOnlyList<OBB>"
            inline constexpr std::uintptr_t WorkbenchTypeFunc = 0x70; // "Func<CargoWorkbenchTypeDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_InventoryItem = 0x9D6230; // "public InventoryItemDescription get_InventoryItem()"
            inline constexpr std::uintptr_t get_WorkbenchType = 0x4048F80; // "public CargoWorkbenchTypeDescription get_WorkbenchType()"
        }
    } // namespace CargoExchangeWorkbenchDescription

    namespace CargoExchangeWorkbenchDestroyModel { // "Models.Models.CargoExchangeWorkbenchDestroy.CargoExchangeWorkbenchDestroyModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "CargoExchangeWorkbenchModel"
            inline constexpr std::uintptr_t interactIgnoreBodyIds = 0x18; // "HashSet<PhysicsBodyId>"
            inline constexpr std::uintptr_t collidersIdData = 0x20; // "CollidersIdData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Destroy = 0x496D6F0; // "public void Destroy(PhysicsSceneModel physicsSceneModel, WorldEntitiesModel worldEntitiesModel)"
            inline constexpr std::uintptr_t DestroyModel = 0x496D4D0; // "private void DestroyModel(WorldEntitiesModel worldEntitiesModel)"
            inline constexpr std::uintptr_t DestroyPhysics = 0x496D500; // "private void DestroyPhysics(PhysicsSceneModel physicsSceneModel)"
        }
    } // namespace CargoExchangeWorkbenchDestroyModel

    namespace CargoExchangeWorkbenchEntityIds { // "Models.References.Builder.CargoExchangeWorkbenchEntityIds (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ModelEntityId = 0x10; // "int"
            inline constexpr std::uintptr_t SlotEntityIds = 0x18; // "IReadOnlyDictionary<CargoExchangeWorkbenchSlotDescription, int>"
            inline constexpr std::uintptr_t SpeedupUpgradeSlotEntityIds = 0x20; // "IReadOnlyDictionary<CargoExchangeWorkbenchSpeedupUpgradeSlotDescription, int>"
            inline constexpr std::uintptr_t AdditionalSlotUpgradeSlotEntityIds = 0x28; // "IReadOnlyDictionary<CargoExchangeWorkbenchAdditionalSlotUpgradeSlotDescription, int>"
        }
    } // namespace CargoExchangeWorkbenchEntityIds

    namespace CargoExchangeWorkbenchExtensions { // "Models.Utils.Extensions.CargoExchangeWorkbenchExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t BuildEntityIds = 0x3938990; // "public static CargoExchangeWorkbenchEntityIds BuildEntityIds(IEntityIdGenerator entityIdGenerator)"
            inline constexpr std::uintptr_t BuildModel = 0x3939380; // "public static CargoExchangeWorkbenchModel BuildModel(CargoExchangeWorkbenchData data, PlotBuildingCargoWorkbenchSlotDescription plotBuildingCargoWorkbenchSlotDescription, CargoExchangeWorkbenchDescription cargoExchangeWorkbenchDescription, CargoExchangeWorkbenchEntityIds cargoExchangeWorkbenchEntityIds, OrientedPoint orientedPoint)"
            inline constexpr std::uintptr_t BuildLocationDescription = 0x3939090; // "private static LocationCargoExchangeWorkbenchDescription BuildLocationDescription(CargoExchangeWorkbenchDescription description, OrientedPoint orientedPoint, CargoExchangeWorkbenchEntityIds entityIds)"
            inline constexpr std::uintptr_t GetCargoSlotModelsByUpgradeSlot = 0x393A2C0; // "public static List<CargoExchangeWorkbenchSlotModel> GetCargoSlotModelsByUpgradeSlot(CargoExchangeWorkbenchAdditionalSlotUpgradeSlotDescription upgradeSlotDescription, CargoExchangeWorkbenchDescription workbenchDescription, ReadOnly.Dictionary<CargoExchangeWorkbenchSlotDescription, CargoExchangeWorkbenchSlotModel> modelSlots)"
            inline constexpr std::uintptr_t GetAssetsValue = 0x3939E90; // "public static int GetAssetsValue(CargoExchangeWorkbenchModel cargoExchangeWorkbenchModel)"
            inline constexpr std::uintptr_t AnyWorking = 0x3938600; // "public static bool AnyWorking(CargoExchangeWorkbenchModel model, long time)"
            inline constexpr std::uintptr_t HasLootInside = 0x393A680; // "public static bool HasLootInside(CargoExchangeWorkbenchModel cargoExchangeWorkbenchModel)"
            inline constexpr std::uintptr_t GetMaxSlots = 0x393A610; // "public static int GetMaxSlots(CargoExchangeWorkbenchDescription description)"
            inline constexpr std::uintptr_t GetMaxAdditionalSlotsPerUpgrade = 0x393A500; // "public static int GetMaxAdditionalSlotsPerUpgrade(ReadOnlyEnum<CargoExchangeWorkbenchAdditionalSlotUpgradeDescription> cargoExchangeWorkbenchAdditionalSlotUpgradeDescriptions)"
            inline constexpr std::uintptr_t BuildSlotsEnum = 0x3939430; // "public static ReadOnlyEnum<CargoExchangeWorkbenchSlotDescription> BuildSlotsEnum(ReadOnlyEnum<CargoExchangeWorkbenchDescription> cargoExchangeWorkbenchDescriptions, int maxAdditionalSlots)"
            inline constexpr std::uintptr_t BuildSpeedupUpgradeSlotsEnum = 0x39395C0; // "public static ReadOnlyEnum<CargoExchangeWorkbenchSpeedupUpgradeSlotDescription> BuildSpeedupUpgradeSlotsEnum(ReadOnlyEnum<CargoExchangeWorkbenchDescription> cargoExchangeWorkbenchDescriptions)"
            inline constexpr std::uintptr_t BuildAdditionalSlotUpgradeSlotsEnum = 0x39387C0; // "public static ReadOnlyEnum<CargoExchangeWorkbenchAdditionalSlotUpgradeSlotDescription> BuildAdditionalSlotUpgradeSlotsEnum(ReadOnlyEnum<CargoExchangeWorkbenchDescription> cargoExchangeWorkbenchDescriptions)"
            inline constexpr std::uintptr_t CheckSpawnLootOnSwap = 0x3939990; // "public static bool CheckSpawnLootOnSwap(CargoExchangeWorkbenchModel model, CargoExchangeWorkbenchDescription newDescription)"
            inline constexpr std::uintptr_t CheckSpawnLootOnAdditionalSlotUpgradeSwap = 0x3939790; // "public static bool CheckSpawnLootOnAdditionalSlotUpgradeSwap(IReadOnlyList<CargoExchangeWorkbenchSlotModel> slots, CargoExchangeWorkbenchAdditionalSlotUpgradeDescription newDescription)"
        }
    } // namespace CargoExchangeWorkbenchExtensions

    namespace CargoExchangeWorkbenchInitializeModel { // "Models.Models.CargoExchangeWorkbenchInitialize.CargoExchangeWorkbenchInitializeModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "CargoExchangeWorkbenchModel"
            inline constexpr std::uintptr_t interactIgnoreBodyIds = 0x18; // "HashSet<PhysicsBodyId>"
            inline constexpr std::uintptr_t collidersIdData = 0x20; // "CollidersIdData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Initialize = 0x496D920; // "public void Initialize(PhysicsSceneModel physicsSceneModel, WorldEntitiesModel worldEntitiesModel, OutbuildingSlotDescription outbuildingSlotDescription)"
            inline constexpr std::uintptr_t InitializeModel = 0x496D740; // "private void InitializeModel(WorldEntitiesModel worldEntitiesModel, OutbuildingSlotDescription outbuildingSlotDescription)"
            inline constexpr std::uintptr_t InitializePhysics = 0x496D770; // "private void InitializePhysics(PhysicsSceneModel physicsSceneModel)"
        }
    } // namespace CargoExchangeWorkbenchInitializeModel

    namespace CargoExchangeWorkbenchModel { // "Models.Models.CargoExchangeWorkbench.CargoExchangeWorkbenchModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t PlotBuildingCargoWorkbenchSlotDescription = 0x10; // "PlotBuildingCargoWorkbenchSlotDescription"
            inline constexpr std::uintptr_t Description = 0x18; // "CargoExchangeWorkbenchDescription"
            inline constexpr std::uintptr_t LocationCargoExchangeWorkbenchDescription = 0x20; // "LocationCargoExchangeWorkbenchDescription"
            inline constexpr std::uintptr_t InitializeModel = 0x28; // "CargoExchangeWorkbenchInitializeModel"
            inline constexpr std::uintptr_t DestroyModel = 0x30; // "CargoExchangeWorkbenchDestroyModel"
            inline constexpr std::uintptr_t InteractIgnoreRigidBodies = 0x38; // "HashSet<PhysicsBodyId>"
            inline constexpr std::uintptr_t Slots = 0x40; // "ReadOnly.Dictionary<CargoExchangeWorkbenchSlotDescription, CargoExchangeWorkbenchSlotModel>"
            inline constexpr std::uintptr_t SpeedupUpgradeSlotModels = 0x48; // "ReadOnly.Dictionary<CargoExchangeWorkbenchSpeedupUpgradeSlotDescription, IPrimitiveModel<CargoExchangeWorkbenchSpeedupUpgradeDescription>>"
            inline constexpr std::uintptr_t AdditionalSlotUpgradeSlotModels = 0x50; // "ReadOnly.Dictionary<CargoExchangeWorkbenchAdditionalSlotUpgradeSlotDescription, IPrimitiveModel<CargoExchangeWorkbenchAdditionalSlotUpgradeDescription>>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t TryGetEmptySlot = 0x496DD80; // "public bool TryGetEmptySlot(out CargoExchangeWorkbenchSlotModel slotModel)"
            inline constexpr std::uintptr_t IsSlotAvailable = 0x496DB00; // "private bool IsSlotAvailable(CargoExchangeWorkbenchSlotModel slotModel)"
        }
    } // namespace CargoExchangeWorkbenchModel

    namespace CargoExchangeWorkbenchModelUpdater { // "Game.Battle.SettlementBuilder.CargoExchangeWorkbenchModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsSceneModel = 0x10; // "PhysicsSceneModel"
            inline constexpr std::uintptr_t worldEntitiesModel = 0x18; // "WorldEntitiesModel"
            inline constexpr std::uintptr_t cargoExchangeWorkbenchesData = 0x20; // "DictionaryData<PlotBuildingCargoWorkbenchSlotDescription, CargoExchangeWorkbenchData>"
            inline constexpr std::uintptr_t cargoExchangeWorkbenchesModel = 0x28; // "CargoWorkbenchesModel<CargoExchangeWorkbenchModel>"
            inline constexpr std::uintptr_t outbuildingSlotDescription = 0x30; // "OutbuildingSlotDescription"
            inline constexpr std::uintptr_t plotBuildingCargoWorkbenchSlotDescription = 0x38; // "PlotBuildingCargoWorkbenchSlotDescription"
            inline constexpr std::uintptr_t cargoWorkbenchPoint = 0x40; // "OrientedPoint"
            inline constexpr std::uintptr_t cargoExchangeWorkbenchEntityIds = 0x48; // "CargoExchangeWorkbenchEntityIds"
            inline constexpr std::uintptr_t description = 0x50; // "CargoExchangeWorkbenchDescription"
            inline constexpr std::uintptr_t workbenchData = 0x58; // "CargoExchangeWorkbenchData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xDA6610; // "public void Update()"
            inline constexpr std::uintptr_t Create = 0xDA6330; // "private void Create(CargoExchangeWorkbenchDescription description, CargoExchangeWorkbenchData workbenchData)"
            inline constexpr std::uintptr_t Destroy = 0xDA6410; // "private void Destroy()"
            inline constexpr std::uintptr_t GetCargoExchangeWorkbenchDescription = 0xDA64E0; // "private CargoExchangeWorkbenchDescription GetCargoExchangeWorkbenchDescription()"
        }
    } // namespace CargoExchangeWorkbenchModelUpdater

    namespace CargoExchangeWorkbenchSlotData { // "Models.Data.Settlement.CargoExchangeWorkbench.CargoExchangeWorkbenchSlotData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Cargo = 0x20; // "IPrimitiveData<CargoDescription>"
            inline constexpr std::uintptr_t EndTs = 0x28; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t CumulativePoints = 0x30; // "IPrimitiveData<int>"
        }
    } // namespace CargoExchangeWorkbenchSlotData

    namespace CargoExchangeWorkbenchSlotModel { // "Models.Models.CargoExchangeWorkbenchSlot.CargoExchangeWorkbenchSlotModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "CargoExchangeWorkbenchSlotData"
            inline constexpr std::uintptr_t SlotDescription = 0x18; // "CargoExchangeWorkbenchSlotDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsEmpty = 0x496ED70; // "public bool get_IsEmpty()"
            inline constexpr std::uintptr_t get_CargoDescription = 0x496EB80; // "public CargoDescription get_CargoDescription()"
            inline constexpr std::uintptr_t get_EndTs = 0x496EC20; // "public long get_EndTs()"
            inline constexpr std::uintptr_t get_CumulativePoints = 0x496EBD0; // "public int get_CumulativePoints()"
            inline constexpr std::uintptr_t Start = 0x496EAB0; // "public void Start(CargoDescription cargo, long endTs, int cumulativePoints)"
            inline constexpr std::uintptr_t ExchangeCargo = 0x496E7D0; // "public void ExchangeCargo(CargoDescription cargo, int cumulativePoints)"
            inline constexpr std::uintptr_t Reset = 0x496E9D0; // "public void Reset()"
            inline constexpr std::uintptr_t CanExchangeCargo = 0x496E610; // "public bool CanExchangeCargo(long now)"
            inline constexpr std::uintptr_t get_IsCargoExchanged = 0x496EC70; // "public bool get_IsCargoExchanged()"
            inline constexpr std::uintptr_t InProcess = 0x496E8C0; // "public bool InProcess(long time)"
        }
    } // namespace CargoExchangeWorkbenchSlotModel

    namespace CargoExchangeWorkbenchSlotTargetActions { // "Game.Battle.SettlementBuilder.CargoExchangeWorkbench.CargoExchangeWorkbenchSlotTargetActions (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t slotEntityId = 0x10; // "int"
            inline constexpr std::uintptr_t cargoExchangeWorkbenchEntityId = 0x14; // "int"
            inline constexpr std::uintptr_t slotModel = 0x18; // "CargoExchangeWorkbenchSlotModel"
            inline constexpr std::uintptr_t workbenchViewDescriptions = 0x20; // "CargoExchangeWorkbenchViewDescriptions"
            inline constexpr std::uintptr_t localizationKeys = 0x28; // "GlobalLocalizationKeys"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x30; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t notificationModel = 0x38; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t uiSoundModel = 0x40; // "GlobalUISoundModel"
            inline constexpr std::uintptr_t inputActions = 0x48; // "InputActions"
            inline constexpr std::uintptr_t battleInputModel = 0x50; // "BattleInputModel"
            inline constexpr std::uintptr_t prolongedActionProcessModel = 0x58; // "ProlongedActionProcessModel"
            inline constexpr std::uintptr_t settlementHelperModel = 0x60; // "ISettlementHelperModel"
            inline constexpr std::uintptr_t partyMemberAccessModel = 0x68; // "IPartyMemberAccessModel"
            inline constexpr std::uintptr_t settlementModel = 0x70; // "SettlementModel"
            inline constexpr std::uintptr_t modalDialogModel = 0x78; // "ModalDialogModel"
            inline constexpr std::uintptr_t clanModel = 0x80; // "ClanModel"
            inline constexpr std::uintptr_t now = 0x88; // "INow"
            inline constexpr std::uintptr_t interactRaycastModel = 0x90; // "InteractRaycastModel"
            inline constexpr std::uintptr_t updaterPool = 0x98; // "UpdaterPool"
            inline constexpr std::uintptr_t TakeAction = 0xA0; // "TargetAction"
        }
        namespace Methods {
            inline constexpr std::uintptr_t TakeCargoAction = 0xDB4FB0; // "private void TakeCargoAction()"
            inline constexpr std::uintptr_t IsClanMemberOwnerOfPlotSlot = 0xDB4D70; // "private static bool IsClanMemberOwnerOfPlotSlot(int entityId, ClanModel clanModel, WorldEntitiesModel worldEntitiesModel, SettlementModel settlementModel)"
            inline constexpr std::uintptr_t TakeCargoActionInternal = 0xDB4EE0; // "private void TakeCargoActionInternal(int slotEntityId)"
            inline constexpr std::uintptr_t Unavailable = 0xDB5800; // "private void Unavailable(LocalizedString notification, PersonalNotificationActionIds id)"
        }
    } // namespace CargoExchangeWorkbenchSlotTargetActions

    namespace CargoExchangeWorkbenchSlotTargetProvider { // "Game.Battle.SettlementBuilder.CargoExchangeWorkbench.Slot.CargoExchangeWorkbenchSlotTargetProvider (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleEntitiesModel = 0x20; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t actions = 0x28; // "CargoExchangeWorkbenchSlotTargetActions"
            inline constexpr std::uintptr_t slotModel = 0x30; // "CargoExchangeWorkbenchSlotModel"
            inline constexpr std::uintptr_t unavailable = 0x38; // "UnavailableTargetActionsKeys"
        }
        namespace Methods {
            inline constexpr std::uintptr_t GetTargetAction = 0xDB5C00; // "protected override ITargetAction GetTargetAction()"
        }
    } // namespace CargoExchangeWorkbenchSlotTargetProvider

    namespace CargoExchangeWorkbenchSlotUpdater { // "Game.Battle.SettlementBuilder.Slot.CargoExchangeWorkbenchSlotUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t cargoExchangeWorkbenchEntityId = 0x20; // "int"
            inline constexpr std::uintptr_t cargoExchangeWorkbenchSlotModel = 0x28; // "CargoExchangeWorkbenchSlotModel"
            inline constexpr std::uintptr_t cargoExchangeWorkbenchModel = 0x30; // "CargoExchangeWorkbenchModel"
            inline constexpr std::uintptr_t localizationKeys = 0x38; // "GlobalLocalizationKeys"
            inline constexpr std::uintptr_t globalModel = 0x40; // "GlobalModel"
            inline constexpr std::uintptr_t battleModel = 0x48; // "BattleModel"
            inline constexpr std::uintptr_t globalScreenContent = 0x50; // "GlobalScreenContent"
            inline constexpr std::uintptr_t battleScreenContent = 0x58; // "BattleScreenContent"
            inline constexpr std::uintptr_t parent = 0x60; // "Transform"
            inline constexpr std::uintptr_t targetSubsystem = 0x68; // "ITargetSubsystem"
            inline constexpr std::uintptr_t inputActions = 0x70; // "InputActions"
            inline constexpr std::uintptr_t now = 0x78; // "INow"
            inline constexpr std::uintptr_t scopesLoadingModel = 0x80; // "ScopesLoadingModel"
            inline constexpr std::uintptr_t interactRaycastModel = 0x88; // "InteractRaycastModel"
            inline constexpr std::uintptr_t updaterPool = 0x90; // "UpdaterPool"
            inline constexpr std::uintptr_t updater = 0x98; // "IUpdater"
            inline constexpr std::uintptr_t registerDisposable = 0xA0; // "IRegisterDisposable"
            inline constexpr std::uintptr_t cargo = 0xA8; // "CargoDescription"
            inline constexpr std::uintptr_t cargoViewDescription = 0xB0; // "CargoViewDescription"
            inline constexpr std::uintptr_t isInitialized = 0xB8; // "bool"
            inline constexpr std::uintptr_t slotContent = 0xC0; // "IDisposableContent<CargoSlotView>"
            inline constexpr std::uintptr_t content = 0xC8; // "IDisposableContent<CargoView>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xDB65F0; // "public CargoExchangeWorkbenchSlotUpdater Init(int cargoExchangeWorkbenchEntityId, GlobalModel globalModel, BattleModel battleModel, CargoExchangeWorkbenchSlotModel cargoExchangeWorkbenchSlotModel, CargoExchangeWorkbenchModel cargoExchangeWorkbenchModel, GlobalScreenContent globalScreenContent, BattleScreenContent battleScreenContent, GlobalLocalizationKeys localizationKeys, Transform parent, ITargetSubsystem targetSubsystem, InputActions inputActions, InteractRaycastModel interactRaycastModel, UpdaterPool updaterPool)"
            inline constexpr std::uintptr_t Dispose = 0xDB64D0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xDB6760; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t CreateCargo = 0xDB5E70; // "private void CreateCargo()"
            inline constexpr std::uintptr_t DestroyCargo = 0xDB63E0; // "private void DestroyCargo()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace CargoExchangeWorkbenchSlotUpdater

    namespace CargoExchangeWorkbenchSlotWithCargoUpdater { // "Game.Battle.SettlementBuilder.CargoExchangeWorkbench.Slot.CargoExchangeWorkbenchSlotWithCargoUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t updaters = 0x20; // "List<IUpdater>"
            inline constexpr std::uintptr_t targetSubsystem = 0x28; // "ITargetSubsystem"
            inline constexpr std::uintptr_t targetObject = 0x30; // "ITargetObject"
            inline constexpr std::uintptr_t targetProvider = 0x38; // "ITargetProvider"
            inline constexpr std::uintptr_t cargoSlot = 0x40; // "CargoSlotView"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xDB6AA0; // "public CargoExchangeWorkbenchSlotWithCargoUpdater Init(int cargoExchangeWorkbenchEntityId, int slotEntityId, CargoExchangeWorkbenchSlotModel slotModel, BattleModel battleModel, CargoView view, CargoSlotView cargoSlot, GlobalScreenContent globalScreenContent, BattleScreenContent battleScreenContent, GlobalLocalizationKeys localizationKeys, GlobalModel globalModel, ITargetSubsystem targetSubsystem, InputActions inputActions, InteractRaycastModel interactRaycastModel, INow now, UpdaterPool updaterPool, IRegisterDisposable disposable)"
            inline constexpr std::uintptr_t Dispose = 0xDB69B0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0x94CF50; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace CargoExchangeWorkbenchSlotWithCargoUpdater

    namespace CargoExchangeWorkbenchSpeedupUpgradeBuilderSlotModel { // "Game.Battle.Builder.CargoExchangeWorkbenchSpeedupUpgradeBuilderSlotModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x28; // "IPrimitiveModel<CargoExchangeWorkbenchSpeedupUpgradeDescription>"
            inline constexpr std::uintptr_t defenseBlockPublicModel = 0x30; // "DefenseBlockPublicModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_InventoryItemDescription = 0xD3D220; // "public override InventoryItemDescription get_InventoryItemDescription()"
            inline constexpr std::uintptr_t CheckType = 0xD3D160; // "public override bool CheckType(InventoryItemDescription itemDescription)"
            inline constexpr std::uintptr_t CheckCooldown = 0x7D5050; // "public override bool CheckCooldown(long now)"
            inline constexpr std::uintptr_t IsBlockedByBreachedObjects = 0x7EC9F0; // "public override bool IsBlockedByBreachedObjects(long now)"
            inline constexpr std::uintptr_t IsBlockedByLootObjects = 0x7EC9F0; // "public override bool IsBlockedByLootObjects(long now)"
            inline constexpr std::uintptr_t CheckShowModalOnMove = 0x7EC9F0; // "public override bool CheckShowModalOnMove(long now)"
            inline constexpr std::uintptr_t IsBlockedByRaidLock = 0xD3D010; // "public override bool IsBlockedByRaidLock(long now)"
        }
    } // namespace CargoExchangeWorkbenchSpeedupUpgradeBuilderSlotModel

    namespace CargoExchangeWorkbenchSpeedupUpgradeDescription { // "Models.References.CargoExchangeWorkbench.CargoExchangeWorkbenchSpeedupUpgradeDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t InventoryItemFunc = 0x20; // "Func<InventoryItemDescription>"
            inline constexpr std::uintptr_t SpeedupPercent = 0x28; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_InventoryItem = 0x9D6230; // "public InventoryItemDescription get_InventoryItem()"
        }
    } // namespace CargoExchangeWorkbenchSpeedupUpgradeDescription

    namespace CargoExchangeWorkbenchTargetActions { // "Game.Battle.SettlementBuilder.CargoExchangeWorkbenchTargetActions (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t entityId = 0x10; // "int"
            inline constexpr std::uintptr_t cargoExchangeWorkbenchModel = 0x18; // "CargoExchangeWorkbenchModel"
            inline constexpr std::uintptr_t notificationModel = 0x20; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t uiSoundModel = 0x28; // "GlobalUISoundModel"
            inline constexpr std::uintptr_t battleInputModel = 0x30; // "BattleInputModel"
            inline constexpr std::uintptr_t inventoryDialogModel = 0x38; // "InventoryDialogModel"
            inline constexpr std::uintptr_t PutCargo = 0x40; // "TargetActionWithNotificationItem"
            inline constexpr std::uintptr_t OpenBuilder = 0x48; // "TargetActionWithNotificationItem"
            inline constexpr std::uintptr_t PutAndBuilderActions = 0x50; // "ITargetAction"
        }
        namespace Methods {
            inline constexpr std::uintptr_t OpenBuilderAction = 0xDA6A30; // "private void OpenBuilderAction()"
            inline constexpr std::uintptr_t PutCargoAction = 0xDA6AB0; // "private void PutCargoAction()"
            inline constexpr std::uintptr_t Unavailable = 0xDA6C10; // "private void Unavailable(LocalizedString notification, PersonalNotificationActionIds id)"
        }
    } // namespace CargoExchangeWorkbenchTargetActions

    namespace CargoExchangeWorkbenchTargetHintUpdater { // "Game.Battle.SettlementBuilder.CargoExchangeWorkbenchTargetHintUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleEntitiesModel = 0x10; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t targetObject = 0x18; // "ITargetObject"
            inline constexpr std::uintptr_t targetHintObjectsModel = 0x20; // "TargetHintObjectsModel"
            inline constexpr std::uintptr_t cargoExchangeWorkbenchModel = 0x28; // "CargoExchangeWorkbenchModel"
            inline constexpr std::uintptr_t isVisible = 0x30; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xDA7140; // "public void Update()"
        }
    } // namespace CargoExchangeWorkbenchTargetHintUpdater

    namespace CargoExchangeWorkbenchTargetProvider { // "Game.Battle.SettlementBuilder.CargoExchangeWorkbenchTargetProvider (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t targetActions = 0x20; // "CargoExchangeWorkbenchTargetActions"
            inline constexpr std::uintptr_t cargoExchangeWorkbenchModel = 0x28; // "CargoExchangeWorkbenchModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x30; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t settlementHelperModel = 0x38; // "ISettlementHelperModel"
            inline constexpr std::uintptr_t publicId = 0x40; // "long"
            inline constexpr std::uintptr_t unavailable = 0x48; // "UnavailableTargetActionsKeys"
            inline constexpr std::uintptr_t options = 0x50; // "UnityRaycastTargetOptions"
            inline constexpr std::uintptr_t entityId = 0x58; // "int"
            inline constexpr std::uintptr_t partyMemberAccessModel = 0x60; // "IPartyMemberAccessModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t GetTargetAction = 0xDA7770; // "protected override ITargetAction GetTargetAction()"
            inline constexpr std::uintptr_t GetCanOpenBuilderInvalidNotification = 0xDA7320; // "private ValueTuple<LocalizedString, bool> GetCanOpenBuilderInvalidNotification()"
            inline constexpr std::uintptr_t GetPutCargoOnWorkbenchValidation = 0xDA74C0; // "private ValueTuple<LocalizedString, bool> GetPutCargoOnWorkbenchValidation()"
        }
    } // namespace CargoExchangeWorkbenchTargetProvider

    namespace CargoExchangeWorkbenchUpdater { // "Game.Battle.SettlementBuilder.CargoExchangeWorkbenchUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t plotModel = 0x10; // "PlotModel"
            inline constexpr std::uintptr_t locationScreenViewModel = 0x18; // "LocationScreenViewModel"
            inline constexpr std::uintptr_t battleModel = 0x20; // "BattleModel"
            inline constexpr std::uintptr_t inputActions = 0x28; // "InputActions"
            inline constexpr std::uintptr_t cargoExchangeWorkbenchesModel = 0x30; // "CargoWorkbenchesModel<CargoExchangeWorkbenchModel>"
            inline constexpr std::uintptr_t workbenchesData = 0x38; // "DictionaryData<PlotBuildingCargoWorkbenchSlotDescription, CargoExchangeWorkbenchData>"
            inline constexpr std::uintptr_t plotBuildingCargoWorkbenchSlotDescription = 0x40; // "PlotBuildingCargoWorkbenchSlotDescription"
            inline constexpr std::uintptr_t globalScreenContent = 0x48; // "GlobalScreenContent"
            inline constexpr std::uintptr_t globalModel = 0x50; // "GlobalModel"
            inline constexpr std::uintptr_t battleScreenContent = 0x58; // "BattleScreenContent"
            inline constexpr std::uintptr_t localizationKeys = 0x60; // "GlobalLocalizationKeys"
            inline constexpr std::uintptr_t targetSubsystem = 0x68; // "ITargetSubsystem"
            inline constexpr std::uintptr_t publicIdModel = 0x70; // "PublicIdModel"
            inline constexpr std::uintptr_t scopesLoadingModel = 0x78; // "ScopesLoadingModel"
            inline constexpr std::uintptr_t interactRaycastModel = 0x80; // "InteractRaycastModel"
            inline constexpr std::uintptr_t updaterPool = 0x88; // "UpdaterPool"
            inline constexpr std::uintptr_t buildingRooms = 0x90; // "ReadOnly.Dictionary<int, RenderersCullingRoomModel>"
            inline constexpr std::uintptr_t roomId = 0x98; // "int"
            inline constexpr std::uintptr_t updater = 0xA0; // "IUpdater"
            inline constexpr std::uintptr_t roomUpdater = 0xA8; // "IStoppedUpdater"
            inline constexpr std::uintptr_t markerUpdater = 0xB0; // "IUpdater"
            inline constexpr std::uintptr_t registerDisposable = 0xB8; // "IRegisterDisposable"
            inline constexpr std::uintptr_t description = 0xC0; // "CargoExchangeWorkbenchDescription"
            inline constexpr std::uintptr_t workbenchData = 0xC8; // "CargoExchangeWorkbenchData"
            inline constexpr std::uintptr_t view = 0xD0; // "CargoExchangeWorkbenchView"
            inline constexpr std::uintptr_t isContentLoading = 0xD8; // "bool"
            inline constexpr std::uintptr_t loadingContent = 0xE0; // "CargoExchangeWorkbenchDescription"
            inline constexpr std::uintptr_t isMarkerInitialized = 0xE8; // "bool"
            inline constexpr std::uintptr_t skipFirstLookMarker = 0xE9; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xDA8430; // "public void Update()"
            inline constexpr std::uintptr_t GetCargoExchangeWorkbenchDescription = 0xDA81C0; // "private CargoExchangeWorkbenchDescription GetCargoExchangeWorkbenchDescription()"
            inline constexpr std::uintptr_t IsContentLoaded = 0xDA8250; // "private bool IsContentLoaded(CargoExchangeWorkbenchDescription description)"
            inline constexpr std::uintptr_t LoadContent = 0xDA8360; // "private void LoadContent(CargoExchangeWorkbenchDescription description)"
            inline constexpr std::uintptr_t Create = 0xDA78F0; // "private void Create(CargoExchangeWorkbenchDescription description, CargoExchangeWorkbenchData workbenchData)"
            inline constexpr std::uintptr_t IsPlotOwner = 0xDA82F0; // "private bool IsPlotOwner()"
            inline constexpr std::uintptr_t Dispose = 0xDA80D0; // "private void Dispose()"
        }
    } // namespace CargoExchangeWorkbenchUpdater

    namespace CargoExchangeWorkbenchUpgradeDescription { // "Models.References.CargoExchangeWorkbench.CargoExchangeWorkbenchUpgradeDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t SpeedupDescriptionFunc = 0x20; // "Func<CargoExchangeWorkbenchSpeedupUpgradeDescription>"
            inline constexpr std::uintptr_t AdditionalSlotFunc = 0x28; // "Func<CargoExchangeWorkbenchAdditionalSlotUpgradeDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_SpeedupDescription = 0x9D6230; // "public CargoExchangeWorkbenchSpeedupUpgradeDescription get_SpeedupDescription()"
            inline constexpr std::uintptr_t get_AdditionalSlot = 0x993E50; // "public CargoExchangeWorkbenchAdditionalSlotUpgradeDescription get_AdditionalSlot()"
        }
    } // namespace CargoExchangeWorkbenchUpgradeDescription

    namespace CargoInventoryConfig { // "Models.References.Cargo.CargoInventoryConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t LargestCargoInventorySlots = 0x10; // "ReadOnlyEnum<CargoInventorySlotDescription>"
            inline constexpr std::uintptr_t ShelvingMaxSlots = 0x18; // "CargoInventoryDescription"
            inline constexpr std::uintptr_t VehicleLoot = 0x20; // "CargoInventoryDescription"
            inline constexpr std::uintptr_t VehicleTrunk = 0x28; // "CargoInventoryDescription"
            inline constexpr std::uintptr_t BuilderLootPage = 0x30; // "CargoInventoryDescription"
            inline constexpr std::uintptr_t ChargeWorkbench = 0x38; // "CargoInventoryDescription"
        }
    } // namespace CargoInventoryConfig

    namespace CargoInventoryData { // "Models.Data.CargoInventoryData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Description = 0x28; // "CargoInventoryDescription"
        }
    } // namespace CargoInventoryData

    namespace CargoInventoryDescription { // "Models.References.CargoInventory.CargoInventoryDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Slots = 0x10; // "ReadOnlyEnum<CargoInventorySlotDescription>"
        }
    } // namespace CargoInventoryDescription

    namespace CargoInventoryModel { // "Models.Models.CargoInventory.CargoInventoryModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t slots = 0x10; // "Dictionary<CargoInventorySlotDescription, CargoInventorySlotModel>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Item = 0x4970350; // "public CargoInventorySlotModel get_Item(CargoInventorySlotDescription slotDescription)"
            inline constexpr std::uintptr_t TryGetSlot = 0x496FFD0; // "public bool TryGetSlot(CargoInventorySlotDescription slotDescription, out CargoInventorySlotModel slot)"
            inline constexpr std::uintptr_t get_Item_2 = 0x49703B0; // "public CargoInventorySlotModel get_Item(int slotIndex)"
            inline constexpr std::uintptr_t TryGetNotEmptySlot = 0x496FDF0; // "public bool TryGetNotEmptySlot(out CargoInventorySlotModel slot)"
            inline constexpr std::uintptr_t TryGetEmptySlot = 0x496FC10; // "public bool TryGetEmptySlot(out CargoInventorySlotModel slot)"
            inline constexpr std::uintptr_t GetEnumerator = 0x496FBA0; // "public IEnumerator<CargoInventorySlotModel> GetEnumerator()"
            inline constexpr std::uintptr_t System_Collections_IEnumerable_GetEnumerator = 0x496FBA0; // "private IEnumerator System.Collections.IEnumerable.GetEnumerator()"
        }
    } // namespace CargoInventoryModel

    namespace CargoInventoryPagesModel { // "Models.Models.CargoInventoryPages.CargoInventoryPagesModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "DictionaryData<int, CargoInventoryData>"
            inline constexpr std::uintptr_t cargoInventoryDescription = 0x18; // "CargoInventoryDescription"
            inline constexpr std::uintptr_t maxPagesCount = 0x20; // "int"
            inline constexpr std::uintptr_t inventories = 0x28; // "Dictionary<int, CargoInventoryModel>"
            inline constexpr std::uintptr_t pageIndexes = 0x30; // "Dictionary<CargoInventoryModel, int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_PagesCount = 0x4970D80; // "public int get_PagesCount()"
            inline constexpr std::uintptr_t get_IsMaxPagesCount = 0x4970CD0; // "public bool get_IsMaxPagesCount()"
            inline constexpr std::uintptr_t get_Item = 0x4970D20; // "public CargoInventoryModel get_Item(int pageIndex)"
            inline constexpr std::uintptr_t IsEmpty = 0x4970740; // "public bool IsEmpty()"
            inline constexpr std::uintptr_t TryGetNotEmptySlot = 0x4970880; // "public bool TryGetNotEmptySlot(out CargoInventorySlotModel slot)"
            inline constexpr std::uintptr_t AddPage = 0x4970470; // "public CargoInventoryModel AddPage()"
            inline constexpr std::uintptr_t Add = 0x4970500; // "private CargoInventoryModel Add(int pageIndex, CargoInventoryData inventoryData)"
            inline constexpr std::uintptr_t TryGetPageIndex = 0x4970A00; // "public bool TryGetPageIndex(CargoInventoryModel inventoryModel, out int pageIndex)"
            inline constexpr std::uintptr_t Clear = 0x4970610; // "public void Clear()"
            inline constexpr std::uintptr_t GetEnumerator = 0x49706A0; // "public IEnumerator<CargoInventoryModel> GetEnumerator()"
            inline constexpr std::uintptr_t System_Collections_IEnumerable_GetEnumerator = 0x49706A0; // "private IEnumerator System.Collections.IEnumerable.GetEnumerator()"
        }
    } // namespace CargoInventoryPagesModel

    namespace CargoInventoryPaginatorModel { // "Game.Battle.Inventory.Pages.CargoInventoryPaginatorModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t pagesModel = 0x20; // "CargoInventoryPagesModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsEmpty = 0xA58E70; // "public override bool get_IsEmpty()"
            inline constexpr std::uintptr_t get_CurrentPageModel = 0xA58E40; // "public CargoInventoryModel get_CurrentPageModel()"
            inline constexpr std::uintptr_t GetPageModel = 0xA58DD0; // "public CargoInventoryModel GetPageModel(int pageIndex)"
        }
    } // namespace CargoInventoryPaginatorModel

    namespace CargoInventoryPaginatorModelUpdater { // "Game.Battle.Inventory.Pages.CargoInventoryPaginatorModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t inventoryDataModel = 0x20; // "IDataModel"
            inline constexpr std::uintptr_t model = 0x28; // "CargoInventoryPaginatorModel"
            inline constexpr std::uintptr_t tickIndex = 0x30; // "long"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0x9FBF40; // "public CargoInventoryPaginatorModelUpdater Init(IDataModel inventoryDataModel, CargoInventoryPaginatorModel model)"
            inline constexpr std::uintptr_t Dispose = 0x92B5C0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA58BA0; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Recalculate = 0xA58C30; // "private void Recalculate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace CargoInventoryPaginatorModelUpdater

    namespace CargoInventoryRules { // "Models.Models.CargoInventory.CargoInventoryRules (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t MoveCargoInventoryItems = 0x4971230; // "public static int MoveCargoInventoryItems(CargoInventoryModel fromInventory, CargoInventoryModel toInventory)"
            inline constexpr std::uintptr_t ClearInventory = 0x4970DD0; // "public static void ClearInventory(CargoInventoryModel cargoInventoryModel)"
            inline constexpr std::uintptr_t IsEmpty = 0x4971030; // "public static bool IsEmpty(CargoInventoryModel cargoInventoryModel)"
            inline constexpr std::uintptr_t TryGetSlotWithCargo = 0x4971530; // "public static bool TryGetSlotWithCargo(CargoInventoryModel cargoInventoryModel, CargoDescription cargoDescription, out CargoInventorySlotModel slotModel)"
        }
    } // namespace CargoInventoryRules

    namespace CargoInventorySlotContainerModel { // "Game.Battle.Trunk.Cargo.CargoInventorySlotContainerModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t SlotModel = 0x10; // "CargoInventorySlotModel"
        }
    } // namespace CargoInventorySlotContainerModel

    namespace CargoInventorySlotDescription { // "Models.References.CargoInventory.CargoInventorySlotDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x819B990; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t slots = 0x0; // "List<CargoInventorySlotDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Get = 0x4487500; // "public static CargoInventorySlotDescription Get(int index)"
        }
    } // namespace CargoInventorySlotDescription

    namespace CargoInventorySlotModel { // "Models.Models.CargoInventorySlot.CargoInventorySlotModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t cargo = 0x10; // "CargoData"
            inline constexpr std::uintptr_t Description = 0x18; // "CargoInventorySlotDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsEmpty = 0x4971A30; // "public bool get_IsEmpty()"
            inline constexpr std::uintptr_t get_Cargo = 0x4971990; // "public CargoDescription get_Cargo()"
            inline constexpr std::uintptr_t get_CumulativePoints = 0x49719E0; // "public int get_CumulativePoints()"
            inline constexpr std::uintptr_t set_CumulativePoints = 0x4971A90; // "public void set_CumulativePoints(int value)"
            inline constexpr std::uintptr_t Get = 0x4971790; // "public ValueTuple<CargoDescription, int> Get()"
            inline constexpr std::uintptr_t Set = 0x4971880; // "public void Set(CargoDescription cargo, int cumulativePoints)"
            inline constexpr std::uintptr_t Unset = 0x4971980; // "public void Unset()"
        }
    } // namespace CargoInventorySlotModel

    namespace CargoInventorySlotUpdater { // "Game.Battle.Trunk.Cargo.CargoInventorySlotUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleEntitiesModel = 0x20; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t slotView = 0x28; // "CargoInventorySlotView"
            inline constexpr std::uintptr_t cargoInventorySlotContainerModel = 0x30; // "CargoInventorySlotContainerModel"
            inline constexpr std::uintptr_t cargoViewDescriptions = 0x38; // "CargoViewDescriptions"
            inline constexpr std::uintptr_t emptySlotState = 0x40; // "CargoInventorySlotView.CargoSlotState"
            inline constexpr std::uintptr_t slotModel = 0x48; // "CargoInventorySlotModel"
            inline constexpr std::uintptr_t cargo = 0x50; // "CargoDescription"
            inline constexpr std::uintptr_t isInteractable = 0x58; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xD81690; // "public CargoInventorySlotUpdater Init(IBattleEntitiesModel battleEntitiesModel, CargoInventorySlotView slotView, CargoInventorySlotContainerModel cargoInventorySlotContainerModel, CargoViewDescriptions cargoViewDescriptions, CargoInventorySlotView.CargoSlotState emptySlotState)"
            inline constexpr std::uintptr_t Dispose = 0xD815D0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xD81840; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t UpdateModel = 0xD81BB0; // "private void UpdateModel()"
            inline constexpr std::uintptr_t UpdateInteractable = 0xD81B60; // "private void UpdateInteractable()"
            inline constexpr std::uintptr_t IsTakeButtonInteractable = 0xD81760; // "private bool IsTakeButtonInteractable()"
            inline constexpr std::uintptr_t UpdateCargo = 0xD81980; // "private void UpdateCargo()"
            inline constexpr std::uintptr_t UpdateState = 0xD81C70; // "private void UpdateState()"
            inline constexpr std::uintptr_t GetState = 0xD81650; // "private CargoInventorySlotView.CargoSlotState GetState()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace CargoInventorySlotUpdater

    namespace CargoInventorySlotView { // "Game.Battle.Trunk.Cargo.CargoInventorySlotView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t slotState = 0x20; // "StateElementBase"
            inline constexpr std::uintptr_t image = 0x28; // "Image"
            inline constexpr std::uintptr_t rareView = 0x30; // "LineAndBackgroundRareView"
            inline constexpr std::uintptr_t cumulativeView = 0x38; // "InventoryItemCumulativeView"
            inline constexpr std::uintptr_t ButtonTake = 0x40; // "ClickButtonView"
            inline constexpr std::uintptr_t PointerButtonView = 0x48; // "PointerButtonView"
            inline constexpr std::uintptr_t RectTransform = 0x50; // "RectTransform"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetRarity = 0xD81D40; // "public void SetRarity(RarityItem rarity)"
            inline constexpr std::uintptr_t SetImage = 0x99B9F0; // "public void SetImage(Sprite sprite)"
            inline constexpr std::uintptr_t SetIsCumulative = 0xD81CE0; // "public void SetIsCumulative(bool isCumulative)"
            inline constexpr std::uintptr_t SetCumulativeProgress = 0xD81CC0; // "public void SetCumulativeProgress(int current, int max)"
            inline constexpr std::uintptr_t SetState = 0xD81D60; // "public void SetState(CargoInventorySlotView.CargoSlotState state)"
        }
    } // namespace CargoInventorySlotView

    namespace CargoInventoryTabView { // "Game.Battle.Trunk.Cargo.CargoInventoryTabView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Slots = 0x20; // "List<CargoInventorySlotView>"
            inline constexpr std::uintptr_t scrollView = 0x28; // "ScrollRect"
            inline constexpr std::uintptr_t maxShowCellAmountOnScreen = 0x30; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetCargoSlots = 0xD81ED0; // "public void SetCargoSlots()"
            inline constexpr std::uintptr_t ForceRebindToScrollbar = 0xD81DF0; // "public void ForceRebindToScrollbar(int count)"
        }
    } // namespace CargoInventoryTabView

    namespace CargoInventoryUpdater { // "Game.Battle.Trunk.Cargo.CargoInventoryUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t slots = 0x20; // "List<CargoInventorySlotContainerModel>"
            inline constexpr std::uintptr_t updaters = 0x28; // "List<CargoInventorySlotUpdater>"
            inline constexpr std::uintptr_t cargoInventoryModel = 0x30; // "CargoInventoryModel"
            inline constexpr std::uintptr_t cargoInventoryView = 0x38; // "CargoInventoryTabView"
            inline constexpr std::uintptr_t exceedSlotsState = 0x40; // "CargoInventorySlotView.CargoSlotState"
            inline constexpr std::uintptr_t slotsCount = 0x44; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xD81FD0; // "public CargoInventoryUpdater Init(CargoInventoryModel cargoInventoryModel, CargoInventoryTabView cargoInventoryView, IBattleEntitiesModel battleEntitiesModel, CargoViewDescriptions viewDescriptions, CargoInventorySlotView.CargoSlotState exceedSlotsState, CargoInventorySlotView.CargoSlotState emptySlotState, UpdaterPool updaterPool, IRegisterDisposable disposable)"
            inline constexpr std::uintptr_t Dispose = 0xD81F10; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xD823D0; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t UpdateSlotStates = 0xD82450; // "private void UpdateSlotStates()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace CargoInventoryUpdater

    namespace CargoModel { // "Models.Models.Cargo.CargoModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t rySector = 0x10; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t Id = 0x18; // "int"
            inline constexpr std::uintptr_t SpawnTickIndex = 0x20; // "IPrimitiveModel<int>"
            inline constexpr std::uintptr_t Description = 0x28; // "CargoDescription"
            inline constexpr std::uintptr_t Transform = 0x30; // "ITransformModel"
            inline constexpr std::uintptr_t InteractPositionModel = 0x38; // "IPositionModel"
            inline constexpr std::uintptr_t PhysicsSource = 0x40; // "ISimpleDotPhysicsSourceModel"
            inline constexpr std::uintptr_t PhysicsState = 0x48; // "ISimpleDotPhysicsStateModel"
            inline constexpr std::uintptr_t PhysicsAwakeObserver = 0x50; // "PhysicsAwakeObserverModel"
            inline constexpr std::uintptr_t CumulativePoints = 0x58; // "IPrimitiveModel<int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_RySector = 0x4971DF0; // "public int get_RySector()"
            inline constexpr std::uintptr_t set_RySector = 0x4971E40; // "public void set_RySector(int value)"
        }
    } // namespace CargoModel

    namespace CargoModelUpdater { // "CargoModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t noDataUpdaters = 0x20; // "List<IUpdater>"
            inline constexpr std::uintptr_t dataUpdaters = 0x28; // "List<IUpdater>"
            inline constexpr std::uintptr_t client = 0x30; // "CargoClientModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0x916660; // "public CargoModelUpdater Init(CargoEntityModel entityModel, IDataTickModel dataTickModel, TimeModel time, UpdaterPool updaterPool, IRegisterDisposable registerDisposable)"
            inline constexpr std::uintptr_t Dispose = 0x9165C0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0x9169B0; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace CargoModelUpdater

    namespace CargoOpenWorkbenchAdditionalSlotUpgradeBuilderSlotModel { // "Game.Battle.Builder.CargoOpenWorkbenchAdditionalSlotUpgradeBuilderSlotModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x28; // "IPrimitiveModel<CargoOpenWorkbenchAdditionalSlotUpgradeDescription>"
            inline constexpr std::uintptr_t typeDescription = 0x30; // "CargoOpenWorkbenchAdditionalSlotUpgradeDescription"
            inline constexpr std::uintptr_t defenseBlockPublicModel = 0x38; // "DefenseBlockPublicModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_InventoryItemDescription = 0xD3EAA0; // "public override InventoryItemDescription get_InventoryItemDescription()"
            inline constexpr std::uintptr_t CheckType = 0xD3EA40; // "public override bool CheckType(InventoryItemDescription itemDescription)"
            inline constexpr std::uintptr_t CheckCooldown = 0x7D5050; // "public override bool CheckCooldown(long now)"
            inline constexpr std::uintptr_t IsBlockedByBreachedObjects = 0x7EC9F0; // "public override bool IsBlockedByBreachedObjects(long now)"
            inline constexpr std::uintptr_t IsBlockedByLootObjects = 0x7EC9F0; // "public override bool IsBlockedByLootObjects(long now)"
            inline constexpr std::uintptr_t CheckShowModalOnMove = 0x7EC9F0; // "public override bool CheckShowModalOnMove(long now)"
            inline constexpr std::uintptr_t IsBlockedByRaidLock = 0xD3EA80; // "public override bool IsBlockedByRaidLock(long now)"
        }
    } // namespace CargoOpenWorkbenchAdditionalSlotUpgradeBuilderSlotModel

    namespace CargoOpenWorkbenchAdditionalSlotUpgradeDescription { // "Models.References.CargoOpenWorkbench.CargoOpenWorkbenchAdditionalSlotUpgradeDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ItemFunc = 0x20; // "Func<InventoryItemDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t GetItem = 0x9D6230; // "public InventoryItemDescription GetItem()"
        }
    } // namespace CargoOpenWorkbenchAdditionalSlotUpgradeDescription

    namespace CargoOpenWorkbenchConfig { // "Models.References.CargoOpenWorkbench.CargoOpenWorkbenchConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t BaseAvailableSlotsCount = 0x10; // "int"
            inline constexpr std::uintptr_t CommonTypeFunc = 0x18; // "Func<CargoWorkbenchTypeDescription>"
            inline constexpr std::uintptr_t LaboratoryTypeFunc = 0x20; // "Func<CargoWorkbenchTypeDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_CommonType = 0x26CF2F0; // "public CargoWorkbenchTypeDescription get_CommonType()"
            inline constexpr std::uintptr_t get_LaboratoryType = 0x9D6230; // "public CargoWorkbenchTypeDescription get_LaboratoryType()"
        }
    } // namespace CargoOpenWorkbenchConfig

    namespace CargoOpenWorkbenchData { // "Models.Data.Settlement.CargoOpenWorkbench.CargoOpenWorkbenchData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Description = 0x20; // "IPrimitiveData<CargoOpenWorkbenchDescription>"
            inline constexpr std::uintptr_t Slots = 0x28; // "ReferenceMapData<CargoOpenWorkbenchSlotDescription, CargoOpenWorkbenchSlotPublicData>"
            inline constexpr std::uintptr_t UpgradesData = 0x30; // "CargoOpenWorkbenchUpgradesData"
        }
    } // namespace CargoOpenWorkbenchData

    namespace CargoOpenWorkbenchDatabaseData { // "Models.Data.Settlement.CargoOpenWorkbench.CargoOpenWorkbenchDatabaseData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Description = 0x20; // "IPrimitiveData<CargoOpenWorkbenchDescription>"
            inline constexpr std::uintptr_t Slots = 0x28; // "ReferenceMapData<CargoOpenWorkbenchSlotDescription, CargoOpenWorkbenchSlotDatabaseData>"
            inline constexpr std::uintptr_t UpgradesData = 0x30; // "CargoOpenWorkbenchUpgradesData"
        }
    } // namespace CargoOpenWorkbenchDatabaseData

    namespace CargoOpenWorkbenchDescription { // "Models.References.CargoOpenWorkbench.CargoOpenWorkbenchDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Colliders = 0x20; // "CollidersDescription"
            inline constexpr std::uintptr_t Obbs = 0x28; // "IReadOnlyList<OBB>"
            inline constexpr std::uintptr_t InventoryItemFunc = 0x30; // "Func<InventoryItemDescription>"
            inline constexpr std::uintptr_t InteractPoint = 0x38; // "Vector3"
            inline constexpr std::uintptr_t InteractDescription = 0x48; // "InteractDescription"
            inline constexpr std::uintptr_t SpawnLootPoint = 0x50; // "Vector3"
            inline constexpr std::uintptr_t SlotsCount = 0x5C; // "int"
            inline constexpr std::uintptr_t WorkbenchTypeFunc = 0x60; // "Func<CargoWorkbenchTypeDescription>"
            inline constexpr std::uintptr_t AdditionalSlotUpgradesLazy = 0x68; // "Lazy<IReadOnlyList<CargoOpenWorkbenchAdditionalSlotUpgradeDescription>>"
            inline constexpr std::uintptr_t AvailableSpeedupUpgradeSlotsLazy = 0x70; // "Lazy<IReadOnlyList<CargoOpenWorkbenchSpeedupUpgradeSlotDescription>>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t GetInventoryItem = 0x9AA5D0; // "public InventoryItemDescription GetInventoryItem()"
            inline constexpr std::uintptr_t get_WorkbenchType = 0x4048EC0; // "public CargoWorkbenchTypeDescription get_WorkbenchType()"
            inline constexpr std::uintptr_t get_AdditionalSlotUpgrades = 0x4488FB0; // "public IReadOnlyList<CargoOpenWorkbenchAdditionalSlotUpgradeDescription> get_AdditionalSlotUpgrades()"
            inline constexpr std::uintptr_t get_AvailableSpeedupUpgradeSlots = 0x4489000; // "public IReadOnlyList<CargoOpenWorkbenchSpeedupUpgradeSlotDescription> get_AvailableSpeedupUpgradeSlots()"
        }
    } // namespace CargoOpenWorkbenchDescription

    namespace CargoOpenWorkbenchDestroyModel { // "Models.Models.CargoOpenWorkbenchDestroy.CargoOpenWorkbenchDestroyModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "CargoOpenWorkbenchModel"
            inline constexpr std::uintptr_t interactIgnoreBodyIds = 0x18; // "HashSet<PhysicsBodyId>"
            inline constexpr std::uintptr_t collidersIdData = 0x20; // "CollidersIdData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Destroy = 0x49720B0; // "public void Destroy(PhysicsSceneModel physicsSceneModel, WorldEntitiesModel worldEntitiesModel)"
            inline constexpr std::uintptr_t DestroyModel = 0x4971E90; // "private void DestroyModel(WorldEntitiesModel worldEntitiesModel)"
            inline constexpr std::uintptr_t DestroyPhysics = 0x4971EC0; // "private void DestroyPhysics(PhysicsSceneModel physicsSceneModel)"
        }
    } // namespace CargoOpenWorkbenchDestroyModel

    namespace CargoOpenWorkbenchEntityIds { // "Models.References.Builder.CargoOpenWorkbenchEntityIds (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ModelEntityId = 0x10; // "int"
            inline constexpr std::uintptr_t SlotsEntityId = 0x18; // "IReadOnlyDictionary<CargoOpenWorkbenchSlotDescription, ValueTuple<int, int>>"
            inline constexpr std::uintptr_t UpgradeSlotsEntityIds = 0x20; // "CargoOpenWorkbenchUpgradeSlotsEntityIds"
        }
    } // namespace CargoOpenWorkbenchEntityIds

    namespace CargoOpenWorkbenchExtensions { // "Models.Utils.Extensions.CargoOpenWorkbenchExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t GetInteractPoint = 0x393D0C0; // "private static Vector3 GetInteractPoint(Vector3 position, Quaternion orientation, Vector3 localCenterPoint)"
            inline constexpr std::uintptr_t BuildEntityIds = 0x393B300; // "public static CargoOpenWorkbenchEntityIds BuildEntityIds(IEntityIdGenerator entityIdGenerator)"
            inline constexpr std::uintptr_t BuildUpgradesEntityIds = 0x393BA20; // "private static CargoOpenWorkbenchUpgradeSlotsEntityIds BuildUpgradesEntityIds(IEntityIdGenerator entityIdGenerator)"
            inline constexpr std::uintptr_t BuildLocationDescription = 0x393B680; // "public static LocationCargoOpenWorkbenchDescription BuildLocationDescription(CargoOpenWorkbenchDescription description, OrientedPoint orientedPoint, CargoOpenWorkbenchEntityIds entityIds)"
            inline constexpr std::uintptr_t BuildModel = 0x393B970; // "public static CargoOpenWorkbenchModel BuildModel(CargoOpenWorkbenchData data, PlotBuildingCargoWorkbenchSlotDescription plotBuildingCargoWorkbenchSlotDescription, CargoOpenWorkbenchDescription cargoOpenWorkbenchDescription, CargoOpenWorkbenchEntityIds cargoOpenWorkbenchEntityIds, OrientedPoint orientedPoint)"
            inline constexpr std::uintptr_t GetCargoSlotByUpgradeSlot = 0x393D030; // "public static CargoOpenWorkbenchSlotDescription GetCargoSlotByUpgradeSlot(CargoOpenWorkbenchAdditionalSlotUpgradeSlotDescription slot)"
            inline constexpr std::uintptr_t GetUpgradeSlotByCargoSlot = 0x393D3A0; // "public static CargoOpenWorkbenchAdditionalSlotUpgradeSlotDescription GetUpgradeSlotByCargoSlot(CargoOpenWorkbenchSlotDescription slot)"
            inline constexpr std::uintptr_t HasLootInside = 0x393D430; // "public static bool HasLootInside(CargoOpenWorkbenchModel cargoOpenWorkbenchModel)"
            inline constexpr std::uintptr_t GetAssetsValue = 0x393CA10; // "public static int GetAssetsValue(CargoOpenWorkbenchModel cargoOpenWorkbenchModel, WorldEntitiesModel worldEntitiesModel)"
            inline constexpr std::uintptr_t GetSlotsAssetsValue = 0x393D170; // "public static int GetSlotsAssetsValue(CargoOpenWorkbenchModel cargoOpenWorkbenchModel, WorldEntitiesModel worldEntitiesModel)"
            inline constexpr std::uintptr_t BuildCargoOpenWorkbenchSlotsEnum = 0x393B130; // "public static ReadOnlyEnum<CargoOpenWorkbenchSlotDescription> BuildCargoOpenWorkbenchSlotsEnum(ReadOnlyEnum<CargoOpenWorkbenchDescription> cargoOpenWorkbenchDescriptions)"
            inline constexpr std::uintptr_t BuildSlotsEnum_T_inst_1 = 0x156E590; // "CargoOpenWorkbenchExtensions.BuildSlotsEnum<object>"
            inline constexpr std::uintptr_t CanBeOpened = 0x393BEF0; // "public static bool CanBeOpened(CargoDescription cargoDescription, CargoOpenWorkbenchDescription workbenchDescription)"
            inline constexpr std::uintptr_t CheckSpawnLootOnSwap = 0x393BF70; // "public static bool CheckSpawnLootOnSwap(CargoOpenWorkbenchModel model, CargoOpenWorkbenchDescription newDescription, long now)"
            inline constexpr std::uintptr_t IsCollectionCargo = 0x393D8D0; // "public static bool IsCollectionCargo(CargoDescription cargo, out CollectionDescription collectionDescription)"
            inline constexpr std::uintptr_t IsCollectionCargo_2 = 0x393D9E0; // "public static bool IsCollectionCargo(ComputedReferences computedReferences, CargoDescription cargo, out CollectionDescription collectionDescription)"
        }
    } // namespace CargoOpenWorkbenchExtensions

    namespace CargoOpenWorkbenchInitializeModel { // "Models.Models.CargoOpenWorkbenchInitialize.CargoOpenWorkbenchInitializeModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "CargoOpenWorkbenchModel"
            inline constexpr std::uintptr_t interactIgnoreBodyIds = 0x18; // "HashSet<PhysicsBodyId>"
            inline constexpr std::uintptr_t collidersIdData = 0x20; // "CollidersIdData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Initialize = 0x49722E0; // "public void Initialize(PhysicsSceneModel physicsSceneModel, WorldEntitiesModel worldEntitiesModel, OutbuildingSlotDescription outbuildingSlotDescription)"
            inline constexpr std::uintptr_t InitializeModel = 0x4972100; // "private void InitializeModel(WorldEntitiesModel worldEntitiesModel, OutbuildingSlotDescription outbuildingSlotDescription)"
            inline constexpr std::uintptr_t InitializePhysics = 0x4972130; // "private void InitializePhysics(PhysicsSceneModel physicsSceneModel)"
        }
    } // namespace CargoOpenWorkbenchInitializeModel

    namespace CargoOpenWorkbenchModel { // "Models.Models.CargoOpenWorkbench.CargoOpenWorkbenchModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t PlotBuildingCargoWorkbenchSlotDescription = 0x10; // "PlotBuildingCargoWorkbenchSlotDescription"
            inline constexpr std::uintptr_t Description = 0x18; // "CargoOpenWorkbenchDescription"
            inline constexpr std::uintptr_t LocationCargoOpenWorkbenchDescription = 0x20; // "LocationCargoOpenWorkbenchDescription"
            inline constexpr std::uintptr_t Slots = 0x28; // "ReadOnly.Dictionary<CargoOpenWorkbenchSlotDescription, CargoOpenWorkbenchSlotModel>"
            inline constexpr std::uintptr_t InitializeModel = 0x30; // "CargoOpenWorkbenchInitializeModel"
            inline constexpr std::uintptr_t DestroyModel = 0x38; // "CargoOpenWorkbenchDestroyModel"
            inline constexpr std::uintptr_t InteractIgnoreRigidBodies = 0x40; // "HashSet<PhysicsBodyId>"
            inline constexpr std::uintptr_t UpgradesModel = 0x48; // "CargoOpenWorkbenchUpgradesModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t TryGetEmptySlot = 0x49726B0; // "public bool TryGetEmptySlot(out CargoOpenWorkbenchSlotModel slotModel)"
            inline constexpr std::uintptr_t IsSlotAvailable = 0x49724C0; // "private bool IsSlotAvailable(CargoOpenWorkbenchSlotDescription slot)"
        }
    } // namespace CargoOpenWorkbenchModel

    namespace CargoOpenWorkbenchModelUpdater { // "Game.Battle.SettlementBuilder.CargoOpenWorkbenchModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsSceneModel = 0x10; // "PhysicsSceneModel"
            inline constexpr std::uintptr_t worldEntitiesModel = 0x18; // "WorldEntitiesModel"
            inline constexpr std::uintptr_t workbenchesData = 0x20; // "DictionaryData<PlotBuildingCargoWorkbenchSlotDescription, CargoOpenWorkbenchData>"
            inline constexpr std::uintptr_t cargoOpenWorkbenchesModel = 0x28; // "CargoWorkbenchesModel<CargoOpenWorkbenchModel>"
            inline constexpr std::uintptr_t outbuildingSlotDescription = 0x30; // "OutbuildingSlotDescription"
            inline constexpr std::uintptr_t plotBuildingCargoWorkbenchSlotDescription = 0x38; // "PlotBuildingCargoWorkbenchSlotDescription"
            inline constexpr std::uintptr_t cargoWorkbenchPoint = 0x40; // "OrientedPoint"
            inline constexpr std::uintptr_t cargoOpenWorkbenchEntityIds = 0x48; // "CargoOpenWorkbenchEntityIds"
            inline constexpr std::uintptr_t description = 0x50; // "CargoOpenWorkbenchDescription"
            inline constexpr std::uintptr_t workbenchData = 0x58; // "CargoOpenWorkbenchData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xDB9440; // "public void Update()"
            inline constexpr std::uintptr_t Create = 0xDB9160; // "private void Create(CargoOpenWorkbenchDescription description, CargoOpenWorkbenchData workbenchData)"
            inline constexpr std::uintptr_t Destroy = 0xDB9240; // "private void Destroy()"
            inline constexpr std::uintptr_t GetCargoWorkbenchDescription = 0xDB9310; // "private CargoOpenWorkbenchDescription GetCargoWorkbenchDescription()"
        }
    } // namespace CargoOpenWorkbenchModelUpdater

    namespace CargoOpenWorkbenchRewardMessage { // "Models.Messages.CargoOpenWorkbenchRewardMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t entityId = 0x20; // "BattleEntityIdData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_EntityId = 0x49E9A70; // "public int get_EntityId()"
            inline constexpr std::uintptr_t get_Type = 0x49E9AB0; // "public override string get_Type()"
        }
    } // namespace CargoOpenWorkbenchRewardMessage

    namespace CargoOpenWorkbenchSlotDatabaseData { // "Models.Data.Settlement.CargoOpenWorkbench.CargoOpenWorkbenchSlotDatabaseData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Cargo = 0x20; // "IPrimitiveData<CargoDescription>"
            inline constexpr std::uintptr_t EndTs = 0x28; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t Inventory = 0x30; // "InventoryData"
            inline constexpr std::uintptr_t InventoryRevealId = 0x38; // "InventoryRevealIdData"
            inline constexpr std::uintptr_t CumulativePoints = 0x40; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t DynamicLineCount = 0x48; // "IPrimitiveData<int>"
        }
    } // namespace CargoOpenWorkbenchSlotDatabaseData

    namespace CargoOpenWorkbenchSlotEntityInventoryModel { // "Models.Models.CargoOpenWorkbenchSlotEntityInventory.CargoOpenWorkbenchSlotEntityInventoryModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Id = 0x10; // "int"
            inline constexpr std::uintptr_t Inventory = 0x18; // "IInventoryModel"
            inline constexpr std::uintptr_t InventoryRevealIdModel = 0x20; // "InventoryRevealIdModel"
        }
    } // namespace CargoOpenWorkbenchSlotEntityInventoryModel

    namespace CargoOpenWorkbenchSlotInventoryEntityModel { // "Game.Battle.EntityModel.CargoOpenWorkbenchSlot.Models.CargoOpenWorkbenchSlotInventoryEntityModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ServerModel = 0x18; // "CargoOpenWorkbenchSlotEntityInventoryModel"
        }
    } // namespace CargoOpenWorkbenchSlotInventoryEntityModel

    namespace CargoOpenWorkbenchSlotModel { // "Models.Models.CargoOpenWorkbenchSlot.CargoOpenWorkbenchSlotModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "CargoOpenWorkbenchSlotPublicData"
            inline constexpr std::uintptr_t SlotDescription = 0x18; // "CargoOpenWorkbenchSlotDescription"
            inline constexpr std::uintptr_t InteractPositionModel = 0x20; // "IPositionModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsEmpty = 0x49732E0; // "public bool get_IsEmpty()"
            inline constexpr std::uintptr_t get_EndTs = 0x4973290; // "public long get_EndTs()"
            inline constexpr std::uintptr_t get_IsOpen = 0x4973340; // "public bool get_IsOpen()"
            inline constexpr std::uintptr_t get_CargoDescription = 0x49731F0; // "public CargoDescription get_CargoDescription()"
            inline constexpr std::uintptr_t get_CumulativePoints = 0x4973240; // "public int get_CumulativePoints()"
            inline constexpr std::uintptr_t Start = 0x49730B0; // "public void Start(long endTs, CargoDescription cargoDescription, int cumulativePoints)"
            inline constexpr std::uintptr_t Open = 0x4972F40; // "public void Open()"
            inline constexpr std::uintptr_t Reset = 0x4972FD0; // "public void Reset()"
            inline constexpr std::uintptr_t InProcess = 0x4972E30; // "public bool InProcess(long time)"
        }
    } // namespace CargoOpenWorkbenchSlotModel

    namespace CargoOpenWorkbenchSlotPrivateData { // "Models.Data.Settlement.CargoOpenWorkbench.CargoOpenWorkbenchSlotPrivateData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Inventory = 0x20; // "InventoryData"
            inline constexpr std::uintptr_t InventoryRevealId = 0x28; // "InventoryRevealIdData"
            inline constexpr std::uintptr_t DynamicLineCount = 0x30; // "IPrimitiveData<int>"
        }
    } // namespace CargoOpenWorkbenchSlotPrivateData

    namespace CargoOpenWorkbenchSlotPublicData { // "Models.Data.Settlement.CargoOpenWorkbench.CargoOpenWorkbenchSlotPublicData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Cargo = 0x20; // "IPrimitiveData<CargoDescription>"
            inline constexpr std::uintptr_t CumulativePoints = 0x28; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t EndTs = 0x30; // "IPrimitiveData<long>"
        }
    } // namespace CargoOpenWorkbenchSlotPublicData

    namespace CargoOpenWorkbenchSlotTargetActions { // "Game.Battle.SettlementBuilder.CargoOpenWorkbenchSlotTargetActions (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t notification = 0x10; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t uiSoundModel = 0x18; // "GlobalUISoundModel"
            inline constexpr std::uintptr_t battleRoomConnection = 0x20; // "IRoomConnection"
            inline constexpr std::uintptr_t inputActions = 0x28; // "InputActions"
            inline constexpr std::uintptr_t localizationKeys = 0x30; // "GlobalLocalizationKeys"
            inline constexpr std::uintptr_t slotEntityId = 0x38; // "int"
            inline constexpr std::uintptr_t slotInventoryEntityId = 0x3C; // "int"
            inline constexpr std::uintptr_t slot = 0x40; // "CargoOpenWorkbenchSlotModel"
            inline constexpr std::uintptr_t battleModel = 0x48; // "BattleModel"
            inline constexpr std::uintptr_t battleEntities = 0x50; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t battleInputModel = 0x58; // "BattleInputModel"
            inline constexpr std::uintptr_t observerRequestModel = 0x60; // "ObserverRequestModel"
            inline constexpr std::uintptr_t modalDialogModel = 0x68; // "ModalDialogModel"
            inline constexpr std::uintptr_t workbenchViewDescriptions = 0x70; // "CargoOpenWorkbenchViewDescriptions"
            inline constexpr std::uintptr_t prolongedActionProcessModel = 0x78; // "ProlongedActionProcessModel"
            inline constexpr std::uintptr_t interactRaycastModel = 0x80; // "InteractRaycastModel"
            inline constexpr std::uintptr_t updaterPool = 0x88; // "UpdaterPool"
            inline constexpr std::uintptr_t isRequested = 0x90; // "bool"
            inline constexpr std::uintptr_t isDisposed = 0x91; // "bool"
            inline constexpr std::uintptr_t Open = 0x98; // "TargetAction"
            inline constexpr std::uintptr_t Take = 0xA0; // "TargetAction"
            inline constexpr std::uintptr_t TakeWithAttention = 0xA8; // "TargetAction"
            inline constexpr std::uintptr_t Loot = 0xB0; // "TargetAction"
        }
        namespace Methods {
            inline constexpr std::uintptr_t TakeWithAttentionSlot = 0xDBA360; // "private void TakeWithAttentionSlot()"
            inline constexpr std::uintptr_t OnAttentionConfirm = 0xDBA080; // "private void OnAttentionConfirm()"
            inline constexpr std::uintptr_t TakeSlot = 0xDBA250; // "private void TakeSlot()"
            inline constexpr std::uintptr_t OpenSlot = 0xDBA1A0; // "private void OpenSlot()"
            inline constexpr std::uintptr_t LootSlot = 0xDB9FD0; // "private void LootSlot()"
            inline constexpr std::uintptr_t LootInvalid = 0xA74590; // "private void LootInvalid(LocalizedString term, PersonalNotificationActionIds id)"
        }
    } // namespace CargoOpenWorkbenchSlotTargetActions

    namespace CargoOpenWorkbenchSlotTargetProvider { // "Game.Battle.SettlementBuilder.CargoOpenWorkbenchSlotTargetProvider (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t slotEntityId = 0x20; // "int"
            inline constexpr std::uintptr_t battleModel = 0x28; // "BattleModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x30; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t actions = 0x38; // "CargoOpenWorkbenchSlotTargetActions"
            inline constexpr std::uintptr_t slot = 0x40; // "CargoOpenWorkbenchSlotModel"
            inline constexpr std::uintptr_t unavailable = 0x48; // "UnavailableTargetActionsKeys"
            inline constexpr std::uintptr_t serverNow = 0x50; // "INow"
            inline constexpr std::uintptr_t settlementHelperModel = 0x58; // "ISettlementHelperModel"
            inline constexpr std::uintptr_t action = 0x60; // "ITargetAction"
        }
        namespace Methods {
            inline constexpr std::uintptr_t GetTargetAction = 0xDBB080; // "protected override ITargetAction GetTargetAction()"
        }
    } // namespace CargoOpenWorkbenchSlotTargetProvider

    namespace CargoOpenWorkbenchSlotUpdater { // "Game.Battle.SettlementBuilder.CargoOpenWorkbenchSlotUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t cargoOpenWorkbenchSlotModel = 0x20; // "CargoOpenWorkbenchSlotModel"
            inline constexpr std::uintptr_t localizationKeys = 0x28; // "GlobalLocalizationKeys"
            inline constexpr std::uintptr_t globalModel = 0x30; // "GlobalModel"
            inline constexpr std::uintptr_t battleModel = 0x38; // "BattleModel"
            inline constexpr std::uintptr_t globalScreenContent = 0x40; // "GlobalScreenContent"
            inline constexpr std::uintptr_t battleScreenContent = 0x48; // "BattleScreenContent"
            inline constexpr std::uintptr_t battleRoomConnection = 0x50; // "IRoomConnection"
            inline constexpr std::uintptr_t workbenchView = 0x58; // "CargoOpenWorkbenchView"
            inline constexpr std::uintptr_t targetSubsystem = 0x60; // "ITargetSubsystem"
            inline constexpr std::uintptr_t cargoOpenWorkbenchModel = 0x68; // "CargoOpenWorkbenchModel"
            inline constexpr std::uintptr_t inputActions = 0x70; // "InputActions"
            inline constexpr std::uintptr_t scopesLoadingModel = 0x78; // "ScopesLoadingModel"
            inline constexpr std::uintptr_t workbenchType = 0x80; // "CargoWorkbenchTypeDescription"
            inline constexpr std::uintptr_t interactRaycastModel = 0x88; // "InteractRaycastModel"
            inline constexpr std::uintptr_t updaterPool = 0x90; // "UpdaterPool"
            inline constexpr std::uintptr_t updater = 0x98; // "IUpdater"
            inline constexpr std::uintptr_t registerDisposable = 0xA0; // "IRegisterDisposable"
            inline constexpr std::uintptr_t cargo = 0xA8; // "CargoDescription"
            inline constexpr std::uintptr_t cargoViewDescription = 0xB0; // "CargoViewDescription"
            inline constexpr std::uintptr_t slotContent = 0xB8; // "IDisposableContent<CargoSlotView>"
            inline constexpr std::uintptr_t content = 0xC0; // "IDisposableContent<CargoView>"
            inline constexpr std::uintptr_t isInitialized = 0xC8; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xDBBC20; // "public CargoOpenWorkbenchSlotUpdater Init(CargoOpenWorkbenchSlotModel cargoOpenWorkbenchSlotModel, GlobalScreenContent globalScreenContent, BattleScreenContent battleScreenContent, GlobalLocalizationKeys localizationKeys, GlobalModel globalModel, BattleModel battleModel, IRoomConnection battleRoomConnection, CargoOpenWorkbenchView workbenchView, ITargetSubsystem targetSubsystem, CargoOpenWorkbenchModel cargoOpenWorkbenchModel, InputActions inputActions, CargoWorkbenchTypeDescription workbenchType, InteractRaycastModel interactRaycastModel, UpdaterPool updaterPool)"
            inline constexpr std::uintptr_t Dispose = 0xDBBAF0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xDBBD90; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t CreateCargo = 0xDBB490; // "private void CreateCargo()"
            inline constexpr std::uintptr_t DestroyCargo = 0xDBBA00; // "private void DestroyCargo()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace CargoOpenWorkbenchSlotUpdater

    namespace CargoOpenWorkbenchSlotWithCargoUpdater { // "Game.Battle.SettlementBuilder.CargoOpenWorkbenchSlotWithCargoUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t updaters = 0x20; // "List<IUpdater>"
            inline constexpr std::uintptr_t targetSubsystem = 0x28; // "ITargetSubsystem"
            inline constexpr std::uintptr_t targetObject = 0x30; // "ITargetObject"
            inline constexpr std::uintptr_t targetProvider = 0x38; // "ITargetProvider"
            inline constexpr std::uintptr_t cargoSlot = 0x40; // "CargoSlotView"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xDBC0C0; // "public CargoOpenWorkbenchSlotWithCargoUpdater Init(int slotEntityId, int slotInventoryEntityId, CargoOpenWorkbenchSlotModel slot, BattleModel battle, GlobalLocalizationKeys localizationKeys, CargoView view, CargoSlotView cargoSlot, GlobalScreenContent globalScreenContent, BattleScreenContent battleScreenContent, GlobalModel global, IRoomConnection battleRoomConnection, ITargetSubsystem targetSubsystem, InputActions inputActions, CargoWorkbenchTypeDescription workbenchType, InteractRaycastModel interactRaycastModel, UpdaterPool updaterPool, IRegisterDisposable disposable)"
            inline constexpr std::uintptr_t Dispose = 0xDBBFD0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0x94CF50; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace CargoOpenWorkbenchSlotWithCargoUpdater

    namespace CargoOpenWorkbenchSpeedupUpgradeBuilderSlotModel { // "Game.Battle.Builder.CargoOpenWorkbenchSpeedupUpgradeBuilderSlotModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t slot = 0x28; // "CargoOpenWorkbenchSpeedupUpgradeSlotDescription"
            inline constexpr std::uintptr_t model = 0x30; // "IPrimitiveModel<CargoOpenWorkbenchSpeedupUpgradeDescription>"
            inline constexpr std::uintptr_t defenseBlockPublicModel = 0x38; // "DefenseBlockPublicModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_InventoryItemDescription = 0xD3EC10; // "public override InventoryItemDescription get_InventoryItemDescription()"
            inline constexpr std::uintptr_t CheckType = 0xD3EB70; // "public override bool CheckType(InventoryItemDescription itemDescription)"
            inline constexpr std::uintptr_t CheckCooldown = 0x7D5050; // "public override bool CheckCooldown(long now)"
            inline constexpr std::uintptr_t IsBlockedByBreachedObjects = 0x7EC9F0; // "public override bool IsBlockedByBreachedObjects(long now)"
            inline constexpr std::uintptr_t IsBlockedByLootObjects = 0x7EC9F0; // "public override bool IsBlockedByLootObjects(long now)"
            inline constexpr std::uintptr_t CheckShowModalOnMove = 0x7EC9F0; // "public override bool CheckShowModalOnMove(long now)"
            inline constexpr std::uintptr_t IsBlockedByRaidLock = 0xD3EA80; // "public override bool IsBlockedByRaidLock(long now)"
        }
    } // namespace CargoOpenWorkbenchSpeedupUpgradeBuilderSlotModel

    namespace CargoOpenWorkbenchSpeedupUpgradeDescription { // "Models.References.CargoOpenWorkbench.CargoOpenWorkbenchSpeedupUpgradeDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t SpeedupPercent = 0x20; // "float"
            inline constexpr std::uintptr_t ItemFunc = 0x28; // "Func<InventoryItemDescription>"
            inline constexpr std::uintptr_t SlotTypeFunc = 0x30; // "Func<CargoOpenWorkbenchSpeedupUpgradeSlotTypeDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t GetItem = 0x993E50; // "public InventoryItemDescription GetItem()"
            inline constexpr std::uintptr_t get_SlotType = 0x9AA5D0; // "public CargoOpenWorkbenchSpeedupUpgradeSlotTypeDescription get_SlotType()"
        }
    } // namespace CargoOpenWorkbenchSpeedupUpgradeDescription

    namespace CargoOpenWorkbenchSpeedupUpgradeSlotDescription { // "Models.References.CargoOpenWorkbench.CargoOpenWorkbenchSpeedupUpgradeSlotDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t TypeFunc = 0x20; // "Func<CargoOpenWorkbenchSpeedupUpgradeSlotTypeDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x9D6230; // "public CargoOpenWorkbenchSpeedupUpgradeSlotTypeDescription get_Type()"
        }
    } // namespace CargoOpenWorkbenchSpeedupUpgradeSlotDescription

    namespace CargoOpenWorkbenchTargetActions { // "Game.Battle.SettlementBuilder.CargoOpenWorkbenchTargetActions (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t entityId = 0x10; // "int"
            inline constexpr std::uintptr_t cargoOpenWorkbenchModel = 0x18; // "CargoOpenWorkbenchModel"
            inline constexpr std::uintptr_t notificationModel = 0x20; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t uiSoundModel = 0x28; // "GlobalUISoundModel"
            inline constexpr std::uintptr_t battleInputModel = 0x30; // "BattleInputModel"
            inline constexpr std::uintptr_t inventoryDialogModel = 0x38; // "InventoryDialogModel"
            inline constexpr std::uintptr_t clientCodexModel = 0x40; // "ClientCodexModel"
            inline constexpr std::uintptr_t Interact = 0x48; // "ValueTuple<ITargetAction, TargetActionWithNotificationItem, TargetActionWithNotificationItem>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t PutCargoOnWorkbench = 0xDBCD20; // "private void PutCargoOnWorkbench()"
            inline constexpr std::uintptr_t OpenBuilder = 0xDBCCA0; // "private void OpenBuilder()"
            inline constexpr std::uintptr_t Unavailable = 0xDBCE90; // "private void Unavailable(LocalizedString notification, PersonalNotificationActionIds id)"
        }
    } // namespace CargoOpenWorkbenchTargetActions

    namespace CargoOpenWorkbenchTargetHintUpdater { // "Game.Battle.SettlementBuilder.CargoOpenWorkbenchTargetHintUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t slots = 0x10; // "ReadOnly.Dictionary<int, CargoOpenWorkbenchSlotModel>"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x18; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t targetObject = 0x20; // "ITargetObject"
            inline constexpr std::uintptr_t targetHintObjectsModel = 0x28; // "TargetHintObjectsModel"
            inline constexpr std::uintptr_t isVisible = 0x30; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xDBD790; // "public void Update()"
        }
    } // namespace CargoOpenWorkbenchTargetHintUpdater

    namespace CargoOpenWorkbenchTargetProvider { // "Game.Battle.SettlementBuilder.CargoOpenWorkbenchTargetProvider (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t targetActions = 0x20; // "CargoOpenWorkbenchTargetActions"
            inline constexpr std::uintptr_t cargoOpenWorkbenchModel = 0x28; // "CargoOpenWorkbenchModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x30; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t settlementHelperModel = 0x38; // "ISettlementHelperModel"
            inline constexpr std::uintptr_t publicId = 0x40; // "long"
            inline constexpr std::uintptr_t unavailable = 0x48; // "UnavailableTargetActionsKeys"
            inline constexpr std::uintptr_t workbenchViewDescriptions = 0x50; // "CargoOpenWorkbenchViewDescriptions"
            inline constexpr std::uintptr_t options = 0x58; // "UnityRaycastTargetOptions"
            inline constexpr std::uintptr_t entityId = 0x60; // "int"
            inline constexpr std::uintptr_t partyMemberAccessModel = 0x68; // "IPartyMemberAccessModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t GetTargetAction = 0xDBDE70; // "protected override ITargetAction GetTargetAction()"
            inline constexpr std::uintptr_t GetCanOpenBuilderInvalidNotification = 0xDBDA70; // "private LocalizedString GetCanOpenBuilderInvalidNotification()"
            inline constexpr std::uintptr_t GetPutCargoOnWorkbenchValidation = 0xDBDBD0; // "private ValueTuple<LocalizedString, bool> GetPutCargoOnWorkbenchValidation()"
        }
    } // namespace CargoOpenWorkbenchTargetProvider

    namespace CargoOpenWorkbenchUpdater { // "Game.Battle.SettlementBuilder.CargoOpenWorkbenchUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t plotModel = 0x10; // "PlotModel"
            inline constexpr std::uintptr_t locationScreenViewModel = 0x18; // "LocationScreenViewModel"
            inline constexpr std::uintptr_t inputActions = 0x20; // "InputActions"
            inline constexpr std::uintptr_t cargoOpenWorkbenchesModel = 0x28; // "CargoWorkbenchesModel<CargoOpenWorkbenchModel>"
            inline constexpr std::uintptr_t workbenchesData = 0x30; // "DictionaryData<PlotBuildingCargoWorkbenchSlotDescription, CargoOpenWorkbenchData>"
            inline constexpr std::uintptr_t plotBuildingCargoWorkbenchSlotDescription = 0x38; // "PlotBuildingCargoWorkbenchSlotDescription"
            inline constexpr std::uintptr_t globalModel = 0x40; // "GlobalModel"
            inline constexpr std::uintptr_t battleModel = 0x48; // "BattleModel"
            inline constexpr std::uintptr_t battleRoomConnection = 0x50; // "IRoomConnection"
            inline constexpr std::uintptr_t globalScreenContent = 0x58; // "GlobalScreenContent"
            inline constexpr std::uintptr_t battleScreenContent = 0x60; // "BattleScreenContent"
            inline constexpr std::uintptr_t localizationKeys = 0x68; // "GlobalLocalizationKeys"
            inline constexpr std::uintptr_t targetSubsystem = 0x70; // "ITargetSubsystem"
            inline constexpr std::uintptr_t publicIdModel = 0x78; // "PublicIdModel"
            inline constexpr std::uintptr_t scopesLoadingModel = 0x80; // "ScopesLoadingModel"
            inline constexpr std::uintptr_t interactRaycastModel = 0x88; // "InteractRaycastModel"
            inline constexpr std::uintptr_t updaterPool = 0x90; // "UpdaterPool"
            inline constexpr std::uintptr_t buildingRooms = 0x98; // "ReadOnly.Dictionary<int, RenderersCullingRoomModel>"
            inline constexpr std::uintptr_t roomId = 0xA0; // "int"
            inline constexpr std::uintptr_t updater = 0xA8; // "IUpdater"
            inline constexpr std::uintptr_t roomUpdater = 0xB0; // "IStoppedUpdater"
            inline constexpr std::uintptr_t markerUpdater = 0xB8; // "IUpdater"
            inline constexpr std::uintptr_t registerDisposable = 0xC0; // "IRegisterDisposable"
            inline constexpr std::uintptr_t description = 0xC8; // "CargoOpenWorkbenchDescription"
            inline constexpr std::uintptr_t workbenchData = 0xD0; // "CargoOpenWorkbenchData"
            inline constexpr std::uintptr_t view = 0xD8; // "CargoOpenWorkbenchView"
            inline constexpr std::uintptr_t isContentLoading = 0xE0; // "bool"
            inline constexpr std::uintptr_t loadingContent = 0xE8; // "CargoOpenWorkbenchDescription"
            inline constexpr std::uintptr_t isMarkerInitialized = 0xF0; // "bool"
            inline constexpr std::uintptr_t skipFirstLookMarker = 0xF1; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xDBEEB0; // "public void Update()"
            inline constexpr std::uintptr_t GetCargoOpenWorkbenchDescription = 0xDBEC40; // "private CargoOpenWorkbenchDescription GetCargoOpenWorkbenchDescription()"
            inline constexpr std::uintptr_t IsContentLoaded = 0xDBECD0; // "private bool IsContentLoaded(CargoOpenWorkbenchDescription description)"
            inline constexpr std::uintptr_t LoadContent = 0xDBEDE0; // "private void LoadContent(CargoOpenWorkbenchDescription description)"
            inline constexpr std::uintptr_t Create = 0xDBE120; // "private void Create(CargoOpenWorkbenchDescription description, CargoOpenWorkbenchData workbenchData)"
            inline constexpr std::uintptr_t IsPlotOwner = 0xDBED70; // "private bool IsPlotOwner()"
            inline constexpr std::uintptr_t Dispose = 0xDBEB50; // "private void Dispose()"
        }
    } // namespace CargoOpenWorkbenchUpdater

    namespace CargoOpenWorkbenchUpgradeDescription { // "Models.References.CargoOpenWorkbench.CargoOpenWorkbenchUpgradeDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t AdditionalSlotDescriptionFunc = 0x20; // "Func<CargoOpenWorkbenchAdditionalSlotUpgradeDescription>"
            inline constexpr std::uintptr_t SpeedupDescriptionFunc = 0x28; // "Func<CargoOpenWorkbenchSpeedupUpgradeDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsAdditionalSlot = 0x40A21C0; // "public bool get_IsAdditionalSlot()"
            inline constexpr std::uintptr_t get_AdditionalSlotDescription = 0x9D6230; // "public CargoOpenWorkbenchAdditionalSlotUpgradeDescription get_AdditionalSlotDescription()"
            inline constexpr std::uintptr_t get_SpeedupDescription = 0x993E50; // "public CargoOpenWorkbenchSpeedupUpgradeDescription get_SpeedupDescription()"
        }
    } // namespace CargoOpenWorkbenchUpgradeDescription

    namespace CargoOpenWorkbenchUpgradesData { // "Models.Data.Settlement.CargoOpenWorkbench.CargoOpenWorkbenchUpgradesData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t AdditionalCargoSlots = 0x20; // "ReferenceMapData<CargoOpenWorkbenchAdditionalSlotUpgradeSlotDescription, IPrimitiveData<CargoOpenWorkbenchAdditionalSlotUpgradeDescription>>"
            inline constexpr std::uintptr_t SpeedupSlots = 0x28; // "ReferenceMapData<CargoOpenWorkbenchSpeedupUpgradeSlotDescription, IPrimitiveData<CargoOpenWorkbenchSpeedupUpgradeDescription>>"
        }
    } // namespace CargoOpenWorkbenchUpgradesData

    namespace CargoOpenWorkbenchUpgradeSlotsEntityIds { // "Models.References.Builder.CargoOpenWorkbenchUpgradeSlotsEntityIds (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t AdditionalSlotsEntityIds = 0x10; // "IReadOnlyDictionary<CargoOpenWorkbenchAdditionalSlotUpgradeSlotDescription, int>"
            inline constexpr std::uintptr_t SpeedupSlotsEntityIds = 0x18; // "IReadOnlyDictionary<CargoOpenWorkbenchSpeedupUpgradeSlotDescription, int>"
        }
    } // namespace CargoOpenWorkbenchUpgradeSlotsEntityIds

    namespace CargoOpenWorkbenchUpgradesModel { // "Models.Models.CargoOpenWorkbenchUpgrades.CargoOpenWorkbenchUpgradesModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t AdditionalSlots = 0x10; // "IReadOnlyDictionary<CargoOpenWorkbenchAdditionalSlotUpgradeSlotDescription, IPrimitiveModel<CargoOpenWorkbenchAdditionalSlotUpgradeDescription>>"
            inline constexpr std::uintptr_t SpeedupSlots = 0x18; // "IReadOnlyDictionary<CargoOpenWorkbenchSpeedupUpgradeSlotDescription, IPrimitiveModel<CargoOpenWorkbenchSpeedupUpgradeDescription>>"
        }
    } // namespace CargoOpenWorkbenchUpgradesModel

    namespace CargoPagesInventoryUpdater { // "Game.Battle.Inventory.Pages.CargoPagesInventoryUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dynamicUpdater = 0x20; // "List<IUpdater>"
            inline constexpr std::uintptr_t model = 0x28; // "CargoInventoryPaginatorModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x30; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t screenContent = 0x38; // "BattleScreenContent"
            inline constexpr std::uintptr_t cargosView = 0x40; // "CargoInventoryTabView"
            inline constexpr std::uintptr_t updaterPool = 0x48; // "UpdaterPool"
            inline constexpr std::uintptr_t pageDisposable = 0x50; // "IRegisterDisposable"
            inline constexpr std::uintptr_t currentPage = 0x58; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA592C0; // "public CargoPagesInventoryUpdater Init(CargoInventoryPaginatorModel model, IBattleEntitiesModel battleEntitiesModel, BattleScreenContent screenContent, CargoInventoryTabView cargoCellsView, UpdaterPool updaterPool)"
            inline constexpr std::uintptr_t Dispose = 0xA59210; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA59360; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t CreateSlotUpdaters = 0xA58E90; // "private void CreateSlotUpdaters()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace CargoPagesInventoryUpdater

    namespace CargoProductionWorkbenchBuilderSlotModel { // "Game.Battle.Builder.CargoProductionWorkbenchBuilderSlotModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t slot = 0x28; // "CargoProductionWorkbenchSlotDescription"
            inline constexpr std::uintptr_t model = 0x30; // "Dictionary<CargoProductionWorkbenchSlotDescription, CargoProductionWorkbenchModel>"
            inline constexpr std::uintptr_t defenseBlockPublicModel = 0x38; // "DefenseBlockPublicModel"
            inline constexpr std::uintptr_t changeFurnitureExpiringResource = 0x40; // "ExpiringResourceModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_InventoryItemDescription = 0xD3EE90; // "public override InventoryItemDescription get_InventoryItemDescription()"
            inline constexpr std::uintptr_t CheckType = 0xD3ED90; // "public override bool CheckType(InventoryItemDescription itemDescription)"
            inline constexpr std::uintptr_t CheckCooldown = 0xD3ECD0; // "public override bool CheckCooldown(long now)"
            inline constexpr std::uintptr_t IsBlockedByBreachedObjects = 0x7EC9F0; // "public override bool IsBlockedByBreachedObjects(long now)"
            inline constexpr std::uintptr_t IsBlockedByLootObjects = 0x7EC9F0; // "public override bool IsBlockedByLootObjects(long now)"
            inline constexpr std::uintptr_t CheckShowModalOnMove = 0xD3ED00; // "public override bool CheckShowModalOnMove(long now)"
            inline constexpr std::uintptr_t IsBlockedByRaidLock = 0xD3EA80; // "public override bool IsBlockedByRaidLock(long now)"
            inline constexpr std::uintptr_t get_CargoProductionWorkbenchModel = 0xD3EE40; // "public CargoProductionWorkbenchModel get_CargoProductionWorkbenchModel()"
        }
    } // namespace CargoProductionWorkbenchBuilderSlotModel

    namespace CargoProductionWorkbenchData { // "Models.Data.Settlement.CargoProductionWorkbench.CargoProductionWorkbenchData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Description = 0x20; // "IPrimitiveData<CargoProductionWorkbenchDescription>"
            inline constexpr std::uintptr_t Recipe = 0x28; // "IPrimitiveData<CargoProductionWorkbenchRecipeDescription>"
            inline constexpr std::uintptr_t EndTs = 0x30; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t ResultCountLeft = 0x38; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t Upgrades = 0x40; // "CargoProductionWorkbenchUpgradesData"
            inline constexpr std::uintptr_t ResultCargoSlots = 0x48; // "ReferenceMapData<CargoProductionWorkbenchResultCargoSlotDescription, IPrimitiveData<CargoDescription>>"
        }
    } // namespace CargoProductionWorkbenchData

    namespace CargoProductionWorkbenchDescription { // "Models.References.CargoProductionWorkbench.CargoProductionWorkbenchDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t InventoryItemFunc = 0x20; // "Func<InventoryItemDescription>"
            inline constexpr std::uintptr_t Colliders = 0x28; // "CollidersDescription"
            inline constexpr std::uintptr_t InputInteractPoint = 0x30; // "Vector3"
            inline constexpr std::uintptr_t InteractDescription = 0x40; // "InteractDescription"
            inline constexpr std::uintptr_t InteractPointSlots = 0x48; // "Vector3[]"
            inline constexpr std::uintptr_t SpawnLootPoint = 0x50; // "Vector3"
            inline constexpr std::uintptr_t Obbs = 0x60; // "IReadOnlyList<OBB>"
            inline constexpr std::uintptr_t ResultTickDuration = 0x68; // "long"
            inline constexpr std::uintptr_t ResultTickCount = 0x70; // "int"
            inline constexpr std::uintptr_t AvailableResultWeightsUpgradeSlotsLazy = 0x78; // "Lazy<IReadOnlyList<CargoProductionWorkbenchResultWeightsUpgradeSlotDescription>>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_InventoryItem = 0x9D6230; // "public InventoryItemDescription get_InventoryItem()"
            inline constexpr std::uintptr_t get_AvailableResultWeightsUpgradeSlots = 0x448AB10; // "public IReadOnlyList<CargoProductionWorkbenchResultWeightsUpgradeSlotDescription> get_AvailableResultWeightsUpgradeSlots()"
            inline constexpr std::uintptr_t get_ResultCargoSlotsCount = 0xB5DA40; // "public int get_ResultCargoSlotsCount()"
        }
    } // namespace CargoProductionWorkbenchDescription

    namespace CargoProductionWorkbenchDestroyModel { // "Models.Models.CargoProductionWorkbenchDestroy.CargoProductionWorkbenchDestroyModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "CargoProductionWorkbenchModel"
            inline constexpr std::uintptr_t interactIgnoreBodyIds = 0x18; // "HashSet<PhysicsBodyId>"
            inline constexpr std::uintptr_t collidersIdData = 0x20; // "CollidersIdData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t DestroyPlot = 0x4973B70; // "public void DestroyPlot(PhysicsSceneModel physicsSceneModel, WorldEntitiesModel worldEntitiesModel)"
            inline constexpr std::uintptr_t DestroyPhysics = 0x4973980; // "private void DestroyPhysics(PhysicsSceneModel physicsSceneModel)"
        }
    } // namespace CargoProductionWorkbenchDestroyModel

    namespace CargoProductionWorkbenchEntityIds { // "Models.References.Builder.CargoProductionWorkbenchEntityIds (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ModelEntityId = 0x10; // "int"
            inline constexpr std::uintptr_t UpgradesEntityIds = 0x18; // "CargoProductionWorkbenchUpgradesEntityIds"
            inline constexpr std::uintptr_t ResultCargoSlotsEntityIds = 0x20; // "IReadOnlyDictionary<CargoProductionWorkbenchResultCargoSlotDescription, int>"
        }
    } // namespace CargoProductionWorkbenchEntityIds

    namespace CargoProductionWorkbenchExtensions { // "Models.Utils.Extensions.CargoProductionWorkbenchExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t BuildEntityIds = 0x393DE70; // "public static CargoProductionWorkbenchEntityIds BuildEntityIds(IEntityIdGenerator entityIdGenerator)"
            inline constexpr std::uintptr_t BuildUpgradesEntityIds = 0x393E680; // "private static CargoProductionWorkbenchUpgradesEntityIds BuildUpgradesEntityIds(IEntityIdGenerator entityIdGenerator)"
            inline constexpr std::uintptr_t BuildCargoProductionWorkbenchOutbuildingSlotsEnum = 0x393DAD0; // "public static ReadOnlyEnum<CargoProductionWorkbenchSlotDescription> BuildCargoProductionWorkbenchOutbuildingSlotsEnum(ReadOnlyEnum<OutbuildingDescription> outbuildingDescriptions)"
            inline constexpr std::uintptr_t BuildCargoProductionWorkbenchResultCargoSlotsEnum = 0x393DCA0; // "public static ReadOnlyEnum<CargoProductionWorkbenchResultCargoSlotDescription> BuildCargoProductionWorkbenchResultCargoSlotsEnum(ReadOnlyEnum<CargoProductionWorkbenchDescription> workbenchDescriptions)"
            inline constexpr std::uintptr_t BuildModel = 0x393E530; // "public static CargoProductionWorkbenchModel BuildModel(CargoProductionWorkbenchData data, CargoProductionWorkbenchSlotDescription slot, CargoProductionWorkbenchEntityIds entityIds, OrientedPoint orientedPoint)"
            inline constexpr std::uintptr_t BuildLocationDescription = 0x393E140; // "private static LocationCargoProductionWorkbenchDescription BuildLocationDescription(CargoProductionWorkbenchDescription description, OrientedPoint orientedPoint, CargoProductionWorkbenchEntityIds entityIds)"
            inline constexpr std::uintptr_t GetAssetsValue = 0x393EDA0; // "public static int GetAssetsValue(CargoProductionWorkbenchModel model)"
            inline constexpr std::uintptr_t IsWorking = 0x393F4D0; // "public static bool IsWorking(long endTs)"
            inline constexpr std::uintptr_t IsWorking_2 = 0x393F3D0; // "public static bool IsWorking(CargoProductionWorkbenchModel model)"
            inline constexpr std::uintptr_t IsEmpty = 0x393EFE0; // "public static bool IsEmpty(CargoProductionWorkbenchRecipeDescription recipe, IEnumerable<CargoProductionWorkbenchResultCargoSlotModel> slots)"
            inline constexpr std::uintptr_t IsEmpty_2 = 0x393F010; // "public static bool IsEmpty(CargoProductionWorkbenchModel model)"
            inline constexpr std::uintptr_t IsResultCargoSlotsEmpty = 0x393F1F0; // "public static bool IsResultCargoSlotsEmpty(IEnumerable<CargoProductionWorkbenchResultCargoSlotModel> slots)"
            inline constexpr std::uintptr_t IsResultCargoSlotEmpty = 0x393F120; // "public static bool IsResultCargoSlotEmpty(CargoProductionWorkbenchResultCargoSlotModel model)"
            inline constexpr std::uintptr_t TryGetEmptyResultCargoSlot = 0x393F530; // "public static bool TryGetEmptyResultCargoSlot(CargoProductionWorkbenchModel model, out CargoProductionWorkbenchResultCargoSlotModel result)"
            inline constexpr std::uintptr_t CheckSpawnOrLostLootOnSwap = 0x393E920; // "public static bool CheckSpawnOrLostLootOnSwap(CargoProductionWorkbenchModel model, CargoProductionWorkbenchDescription newDescription)"
        }
    } // namespace CargoProductionWorkbenchExtensions

    namespace CargoProductionWorkbenchInitializeModel { // "Models.Models.CargoProductionWorkbenchInitialize.CargoProductionWorkbenchInitializeModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "CargoProductionWorkbenchModel"
            inline constexpr std::uintptr_t interactIgnoreBodyIds = 0x18; // "HashSet<PhysicsBodyId>"
            inline constexpr std::uintptr_t collidersIdData = 0x20; // "CollidersIdData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t InitializePlot = 0x4973D70; // "public void InitializePlot(PhysicsSceneModel physicsSceneModel, WorldEntitiesModel worldEntitiesModel, PlotSlotDescription plotSlot, OutbuildingSlotDescription outbuildingSlot)"
            inline constexpr std::uintptr_t InitializePhysics = 0x4973BC0; // "private void InitializePhysics(PhysicsSceneModel physicsSceneModel)"
        }
    } // namespace CargoProductionWorkbenchInitializeModel

    namespace CargoProductionWorkbenchModel { // "Models.Models.CargoProductionWorkbench.CargoProductionWorkbenchModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t SlotDescription = 0x10; // "CargoProductionWorkbenchSlotDescription"
            inline constexpr std::uintptr_t Description = 0x18; // "CargoProductionWorkbenchDescription"
            inline constexpr std::uintptr_t LocationDescription = 0x20; // "LocationCargoProductionWorkbenchDescription"
            inline constexpr std::uintptr_t InitializeModel = 0x28; // "CargoProductionWorkbenchInitializeModel"
            inline constexpr std::uintptr_t DestroyModel = 0x30; // "CargoProductionWorkbenchDestroyModel"
            inline constexpr std::uintptr_t InteractIgnoreRigidBodies = 0x38; // "HashSet<PhysicsBodyId>"
            inline constexpr std::uintptr_t Recipe = 0x40; // "IPrimitiveModel<CargoProductionWorkbenchRecipeDescription>"
            inline constexpr std::uintptr_t EndTs = 0x48; // "IPrimitiveModel<long>"
            inline constexpr std::uintptr_t ResultCountLeft = 0x50; // "IPrimitiveModel<int>"
            inline constexpr std::uintptr_t Upgrades = 0x58; // "CargoProductionWorkbenchUpgradesModel"
            inline constexpr std::uintptr_t ResultCargoSlots = 0x60; // "ReadOnly.Dictionary<CargoProductionWorkbenchResultCargoSlotDescription, CargoProductionWorkbenchResultCargoSlotModel>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Id = 0x4974460; // "public int get_Id()"
        }
    } // namespace CargoProductionWorkbenchModel

    namespace CargoProductionWorkbenchModelUpdater { // "Game.Battle.SettlementBuilder.CargoProductionWorkbench.CargoProductionWorkbenchModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t plotSlot = 0x10; // "PlotSlotDescription"
            inline constexpr std::uintptr_t outbuildingSlot = 0x18; // "OutbuildingSlotDescription"
            inline constexpr std::uintptr_t slot = 0x20; // "CargoProductionWorkbenchSlotDescription"
            inline constexpr std::uintptr_t data = 0x28; // "DictionaryData<CargoProductionWorkbenchSlotDescription, CargoProductionWorkbenchData>"
            inline constexpr std::uintptr_t model = 0x30; // "Dictionary<CargoProductionWorkbenchSlotDescription, CargoProductionWorkbenchModel>"
            inline constexpr std::uintptr_t entityIds = 0x38; // "CargoProductionWorkbenchEntityIds"
            inline constexpr std::uintptr_t orientedPoint = 0x40; // "OrientedPoint"
            inline constexpr std::uintptr_t physicsSceneModel = 0x48; // "PhysicsSceneModel"
            inline constexpr std::uintptr_t worldEntitiesModel = 0x50; // "WorldEntitiesModel"
            inline constexpr std::uintptr_t description = 0x58; // "CargoProductionWorkbenchDescription"
            inline constexpr std::uintptr_t workbenchData = 0x60; // "CargoProductionWorkbenchData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xDC12B0; // "public void Update()"
            inline constexpr std::uintptr_t Create = 0xDC0FE0; // "private void Create(CargoProductionWorkbenchDescription description, CargoProductionWorkbenchData workbenchData)"
            inline constexpr std::uintptr_t Destroy = 0xDC10C0; // "private void Destroy()"
            inline constexpr std::uintptr_t GetDescription = 0xDC1180; // "private CargoProductionWorkbenchDescription GetDescription()"
        }
    } // namespace CargoProductionWorkbenchModelUpdater

    namespace CargoProductionWorkbenchResultCargoSlotModel { // "Models.Models.CargoProductionWorkbenchResultCargoSlot.CargoProductionWorkbenchResultCargoSlotModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Slot = 0x10; // "CargoProductionWorkbenchResultCargoSlotDescription"
            inline constexpr std::uintptr_t Cargo = 0x18; // "IPrimitiveModel<CargoDescription>"
        }
    } // namespace CargoProductionWorkbenchResultCargoSlotModel

    namespace CargoProductionWorkbenchResultWeightsUpgradeBuilderSlotModel { // "Game.Battle.Builder.CargoProductionWorkbenchResultWeightsUpgradeBuilderSlotModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t upgradeSlot = 0x28; // "CargoProductionWorkbenchResultWeightsUpgradeSlotDescription"
            inline constexpr std::uintptr_t upgrade = 0x30; // "IPrimitiveModel<CargoProductionWorkbenchResultWeightsUpgradeDescription>"
            inline constexpr std::uintptr_t defenseBlockPublicModel = 0x38; // "DefenseBlockPublicModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_InventoryItemDescription = 0xD3EF80; // "public override InventoryItemDescription get_InventoryItemDescription()"
            inline constexpr std::uintptr_t CheckType = 0xD3EF10; // "public override bool CheckType(InventoryItemDescription itemDescription)"
            inline constexpr std::uintptr_t CheckCooldown = 0x7D5050; // "public override bool CheckCooldown(long now)"
            inline constexpr std::uintptr_t IsBlockedByBreachedObjects = 0x7EC9F0; // "public override bool IsBlockedByBreachedObjects(long now)"
            inline constexpr std::uintptr_t IsBlockedByLootObjects = 0x7EC9F0; // "public override bool IsBlockedByLootObjects(long now)"
            inline constexpr std::uintptr_t CheckShowModalOnMove = 0x7EC9F0; // "public override bool CheckShowModalOnMove(long now)"
            inline constexpr std::uintptr_t IsBlockedByRaidLock = 0xD3EA80; // "public override bool IsBlockedByRaidLock(long now)"
        }
    } // namespace CargoProductionWorkbenchResultWeightsUpgradeBuilderSlotModel

    namespace CargoProductionWorkbenchResultWeightsUpgradeDescription { // "Models.References.CargoProductionWorkbench.CargoProductionWorkbenchResultWeightsUpgradeDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ItemFunc = 0x20; // "Func<InventoryItemDescription>"
            inline constexpr std::uintptr_t SlotTypeFunc = 0x28; // "Func<CargoProductionWorkbenchResultWeightsUpgradeSlotTypeDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Item = 0x9D6230; // "public InventoryItemDescription get_Item()"
            inline constexpr std::uintptr_t get_SlotType = 0x993E50; // "public CargoProductionWorkbenchResultWeightsUpgradeSlotTypeDescription get_SlotType()"
        }
    } // namespace CargoProductionWorkbenchResultWeightsUpgradeDescription

    namespace CargoProductionWorkbenchResultWeightsUpgradeSlotDescription { // "Models.References.CargoProductionWorkbench.CargoProductionWorkbenchResultWeightsUpgradeSlotDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t TypeFunc = 0x20; // "Func<CargoProductionWorkbenchResultWeightsUpgradeSlotTypeDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x9D6230; // "public CargoProductionWorkbenchResultWeightsUpgradeSlotTypeDescription get_Type()"
        }
    } // namespace CargoProductionWorkbenchResultWeightsUpgradeSlotDescription

    namespace CargoProductionWorkbenchSlotTargetActions { // "Game.Battle.SettlementBuilder.CargoProductionWorkbench.Slot.CargoProductionWorkbenchSlotTargetActions (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t notification = 0x10; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t uiSoundModel = 0x18; // "GlobalUISoundModel"
            inline constexpr std::uintptr_t slotEntityId = 0x20; // "int"
            inline constexpr std::uintptr_t battleInputModel = 0x28; // "BattleInputModel"
            inline constexpr std::uintptr_t Take = 0x30; // "TargetAction"
        }
        namespace Methods {
            inline constexpr std::uintptr_t TakeSlot = 0xDC1780; // "private void TakeSlot()"
            inline constexpr std::uintptr_t LootInvalid = 0xA74590; // "private void LootInvalid(LocalizedString term, PersonalNotificationActionIds id)"
        }
    } // namespace CargoProductionWorkbenchSlotTargetActions

    namespace CargoProductionWorkbenchSlotTargetProvider { // "Game.Battle.SettlementBuilder.CargoProductionWorkbench.Slot.CargoProductionWorkbenchSlotTargetProvider (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleEntitiesModel = 0x20; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t actions = 0x28; // "CargoProductionWorkbenchSlotTargetActions"
            inline constexpr std::uintptr_t unavailable = 0x30; // "UnavailableTargetActionsKeys"
            inline constexpr std::uintptr_t action = 0x38; // "ITargetAction"
        }
        namespace Methods {
            inline constexpr std::uintptr_t GetTargetAction = 0xDC1A40; // "protected override ITargetAction GetTargetAction()"
        }
    } // namespace CargoProductionWorkbenchSlotTargetProvider

    namespace CargoProductionWorkbenchSlotUpdater { // "Game.Battle.SettlementBuilder.CargoProductionWorkbench.Slot.CargoProductionWorkbenchSlotUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t slot = 0x10; // "CargoProductionWorkbenchResultCargoSlotModel"
            inline constexpr std::uintptr_t content = 0x18; // "BattleScreenContent"
            inline constexpr std::uintptr_t battle = 0x20; // "BattleModel"
            inline constexpr std::uintptr_t cargoSlotView = 0x28; // "CargoSlotView"
            inline constexpr std::uintptr_t global = 0x30; // "GlobalModel"
            inline constexpr std::uintptr_t targetSubsystem = 0x38; // "ITargetSubsystem"
            inline constexpr std::uintptr_t cargoProductionWorkbenchModel = 0x40; // "CargoProductionWorkbenchModel"
            inline constexpr std::uintptr_t scopesLoadingModel = 0x48; // "ScopesLoadingModel"
            inline constexpr std::uintptr_t updater = 0x50; // "IUpdater"
            inline constexpr std::uintptr_t registerDisposable = 0x58; // "IRegisterDisposable"
            inline constexpr std::uintptr_t cargo = 0x60; // "CargoDescription"
            inline constexpr std::uintptr_t cargoViewDescription = 0x68; // "CargoViewDescription"
            inline constexpr std::uintptr_t isInitialized = 0x70; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xDC2540; // "public void Update()"
            inline constexpr std::uintptr_t CreateCargoProduction = 0xDC1C00; // "private void CreateCargoProduction()"
        }
    } // namespace CargoProductionWorkbenchSlotUpdater

    namespace CargoProductionWorkbenchTargetActions { // "Game.Battle.SettlementBuilder.CargoProductionWorkbench.CargoProductionWorkbenchTargetActions (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "CargoProductionWorkbenchModel"
            inline constexpr std::uintptr_t uiSoundModel = 0x18; // "GlobalUISoundModel"
            inline constexpr std::uintptr_t notificationModel = 0x20; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t localizationKeys = 0x28; // "GlobalLocalizationKeys"
            inline constexpr std::uintptr_t modalDialogModel = 0x30; // "ModalDialogModel"
            inline constexpr std::uintptr_t viewDescriptions = 0x38; // "CargoProductionWorkbenchViewDescriptions"
            inline constexpr std::uintptr_t inputActions = 0x40; // "InputActions.BattleActions"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x48; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t battleInputModel = 0x50; // "BattleInputModel"
            inline constexpr std::uintptr_t inventoryDialogModel = 0x58; // "InventoryDialogModel"
            inline constexpr std::uintptr_t interactRaycastModel = 0x60; // "InteractRaycastModel"
            inline constexpr std::uintptr_t now = 0x68; // "INow"
            inline constexpr std::uintptr_t updaterPool = 0x70; // "UpdaterPool"
            inline constexpr std::uintptr_t PutCargoAction = 0x78; // "TargetAction"
            inline constexpr std::uintptr_t StopProcessAction = 0x80; // "TargetAction"
            inline constexpr std::uintptr_t DrainReagentsAction = 0x88; // "TargetAction"
            inline constexpr std::uintptr_t OpenBuilderAction = 0x90; // "TargetAction"
        }
        namespace Methods {
            inline constexpr std::uintptr_t StartProcess = 0xDC2B40; // "private void StartProcess()"
            inline constexpr std::uintptr_t StopProcess = 0xDC2CE0; // "private void StopProcess()"
            inline constexpr std::uintptr_t OpenBuilder = 0xDC2AB0; // "private void OpenBuilder()"
            inline constexpr std::uintptr_t StopProcessInternal = 0xDC2C10; // "private void StopProcessInternal()"
            inline constexpr std::uintptr_t Unavailable = 0xDC32C0; // "private void Unavailable(LocalizedString notification, PersonalNotificationActionIds id)"
        }
    } // namespace CargoProductionWorkbenchTargetActions

    namespace CargoProductionWorkbenchTargetProvider { // "Game.Battle.SettlementBuilder.CargoProductionWorkbench.CargoProductionWorkbenchTargetProvider (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t actions = 0x20; // "CargoProductionWorkbenchTargetActions"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x28; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t model = 0x30; // "CargoProductionWorkbenchModel"
            inline constexpr std::uintptr_t unavailable = 0x38; // "UnavailableTargetActionsKeys"
            inline constexpr std::uintptr_t settlementHelperModel = 0x40; // "ISettlementHelperModel"
            inline constexpr std::uintptr_t partyMemberAccessModel = 0x48; // "IPartyMemberAccessModel"
            inline constexpr std::uintptr_t worldEntitiesModel = 0x50; // "WorldEntitiesModel"
            inline constexpr std::uintptr_t settlementModel = 0x58; // "SettlementModel"
            inline constexpr std::uintptr_t clanModel = 0x60; // "ClanModel"
            inline constexpr std::uintptr_t entityId = 0x68; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t FillTargetActions = 0xDC3820; // "protected internal override void FillTargetActions(List<ITargetAction> actions)"
            inline constexpr std::uintptr_t ValidatePutCargo = 0xDC3EE0; // "private void ValidatePutCargo(PlayerEntityModel player, List<ITargetAction> actions)"
            inline constexpr std::uintptr_t ValidateStopProcess = 0xDC40E0; // "private void ValidateStopProcess(PlayerEntityModel player, List<ITargetAction> actions)"
            inline constexpr std::uintptr_t ValidateOpenBuilder = 0xDC3D70; // "private void ValidateOpenBuilder(PlayerEntityModel player, List<ITargetAction> actions)"
            inline constexpr std::uintptr_t InvalidCommonConditions = 0xDC3AA0; // "private bool InvalidCommonConditions(PlayerEntityModel player, bool hasAccess, out LocalizedString notify)"
            inline constexpr std::uintptr_t RequiresStopConfirmation = 0xDC3D40; // "private bool RequiresStopConfirmation(PlayerEntityModel player)"
            inline constexpr std::uintptr_t HasAccessTo = 0xDC39F0; // "private bool HasAccessTo(PlayerEntityModel player)"
            inline constexpr std::uintptr_t IsClanMemberOwnerOfPlotSlot = 0xDC3BB0; // "private bool IsClanMemberOwnerOfPlotSlot()"
        }
    } // namespace CargoProductionWorkbenchTargetProvider

    namespace CargoProductionWorkbenchUpdater { // "Game.Battle.SettlementBuilder.CargoProductionWorkbench.CargoProductionWorkbenchUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t plotModel = 0x10; // "PlotModel"
            inline constexpr std::uintptr_t slot = 0x18; // "CargoProductionWorkbenchSlotDescription"
            inline constexpr std::uintptr_t globalModel = 0x20; // "GlobalModel"
            inline constexpr std::uintptr_t battleModel = 0x28; // "BattleModel"
            inline constexpr std::uintptr_t model = 0x30; // "Dictionary<CargoProductionWorkbenchSlotDescription, CargoProductionWorkbenchModel>"
            inline constexpr std::uintptr_t workbenchesData = 0x38; // "DictionaryData<CargoProductionWorkbenchSlotDescription, CargoProductionWorkbenchData>"
            inline constexpr std::uintptr_t battleScreenContent = 0x40; // "BattleScreenContent"
            inline constexpr std::uintptr_t globalScreenContent = 0x48; // "GlobalScreenContent"
            inline constexpr std::uintptr_t inputActions = 0x50; // "InputActions"
            inline constexpr std::uintptr_t targetSubsystem = 0x58; // "ITargetSubsystem"
            inline constexpr std::uintptr_t publicIdModel = 0x60; // "PublicIdModel"
            inline constexpr std::uintptr_t scopesLoadingModel = 0x68; // "ScopesLoadingModel"
            inline constexpr std::uintptr_t interactRaycastModel = 0x70; // "InteractRaycastModel"
            inline constexpr std::uintptr_t updaterPool = 0x78; // "UpdaterPool"
            inline constexpr std::uintptr_t buildingRooms = 0x80; // "ReadOnly.Dictionary<int, RenderersCullingRoomModel>"
            inline constexpr std::uintptr_t roomId = 0x88; // "int"
            inline constexpr std::uintptr_t updater = 0x90; // "IUpdater"
            inline constexpr std::uintptr_t roomUpdater = 0x98; // "IStoppedUpdater"
            inline constexpr std::uintptr_t markerUpdater = 0xA0; // "IUpdater"
            inline constexpr std::uintptr_t description = 0xA8; // "CargoProductionWorkbenchDescription"
            inline constexpr std::uintptr_t workbenchData = 0xB0; // "CargoProductionWorkbenchData"
            inline constexpr std::uintptr_t registerDisposable = 0xB8; // "IRegisterDisposable"
            inline constexpr std::uintptr_t view = 0xC0; // "CargoProductionWorkbenchView"
            inline constexpr std::uintptr_t isContentLoading = 0xC8; // "bool"
            inline constexpr std::uintptr_t loadingContent = 0xD0; // "CargoProductionWorkbenchDescription"
            inline constexpr std::uintptr_t skipFirstLookMarker = 0xD8; // "bool"
            inline constexpr std::uintptr_t isMarkerInitialized = 0xD9; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xDC4ED0; // "public void Update()"
            inline constexpr std::uintptr_t LoadContent = 0xDC4E00; // "private void LoadContent(CargoProductionWorkbenchDescription description)"
            inline constexpr std::uintptr_t Create = 0xDC4420; // "private void Create(CargoProductionWorkbenchDescription description, CargoProductionWorkbenchData workbenchData)"
            inline constexpr std::uintptr_t IsContentLoaded = 0xDC4CF0; // "private bool IsContentLoaded(CargoProductionWorkbenchDescription description)"
            inline constexpr std::uintptr_t Dispose = 0xDC4B80; // "private void Dispose()"
            inline constexpr std::uintptr_t IsPlotOwner = 0xDC4D90; // "private bool IsPlotOwner()"
            inline constexpr std::uintptr_t GetDescription = 0xDC4C70; // "private CargoProductionWorkbenchDescription GetDescription()"
        }
    } // namespace CargoProductionWorkbenchUpdater

    namespace CargoProductionWorkbenchUpgradesData { // "Models.Data.Settlement.CargoProductionWorkbench.CargoProductionWorkbenchUpgradesData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ResultWeights = 0x20; // "ReferenceMapData<CargoProductionWorkbenchResultWeightsUpgradeSlotDescription, IPrimitiveData<CargoProductionWorkbenchResultWeightsUpgradeDescription>>"
        }
    } // namespace CargoProductionWorkbenchUpgradesData

    namespace CargoProductionWorkbenchUpgradesEntityIds { // "Models.References.Builder.CargoProductionWorkbenchUpgradesEntityIds (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ResultWeightsEntityIds = 0x10; // "IReadOnlyDictionary<CargoProductionWorkbenchResultWeightsUpgradeSlotDescription, int>"
        }
    } // namespace CargoProductionWorkbenchUpgradesEntityIds

    namespace CargoProductionWorkbenchUpgradesModel { // "Models.Models.CargoProductionWorkbenchUpgrades.CargoProductionWorkbenchUpgradesModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t resultWeights = 0x10; // "Dictionary<CargoProductionWorkbenchResultWeightsUpgradeSlotDescription, IPrimitiveModel<CargoProductionWorkbenchResultWeightsUpgradeDescription>>"
            inline constexpr std::uintptr_t ResultWeights = 0x18; // "ReadOnly.Dictionary<CargoProductionWorkbenchResultWeightsUpgradeSlotDescription, IPrimitiveModel<CargoProductionWorkbenchResultWeightsUpgradeDescription>>"
        }
    } // namespace CargoProductionWorkbenchUpgradesModel

    namespace CargoSellDescription { // "Models.References.CargoSeller.CargoSellDescription (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t GetPrice = 0x448B690; // "public static int GetPrice(CargoSellerDescription sellerDescription)"
        }
    } // namespace CargoSellDescription

    namespace CargoSellerDescription { // "Models.References.CargoSeller.CargoSellerDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t CargoDescriptionFunc = 0x20; // "Func<CargoDescription>"
            inline constexpr std::uintptr_t Price = 0x28; // "int"
            inline constexpr std::uintptr_t IsSelfSettlementLocked = 0x2C; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_CargoDescription = 0x9D6230; // "public CargoDescription get_CargoDescription()"
        }
    } // namespace CargoSellerDescription

    namespace CargoSellerTargetActions { // "Game.Battle.Entities.CargoSeller.CargoSellerTargetActions (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t roomConnections = 0x10; // "IRoomConnections"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x18; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t globalModel = 0x20; // "GlobalModel"
            inline constexpr std::uintptr_t locationCargoSellerDescription = 0x28; // "LocationCargoSellerDescription"
            inline constexpr std::uintptr_t inputActions = 0x30; // "InputActions"
            inline constexpr std::uintptr_t globalLocalizationKeys = 0x38; // "GlobalLocalizationKeys"
            inline constexpr std::uintptr_t buyCargoLocalization = 0x40; // "BuyCargoLocalization"
            inline constexpr std::uintptr_t clientCodexModel = 0x48; // "ClientCodexModel"
            inline constexpr std::uintptr_t playerPrefsModel = 0x50; // "PlayerPrefsModel"
            inline constexpr std::uintptr_t isRequesting = 0x58; // "bool"
            inline constexpr std::uintptr_t Buy = 0x60; // "TargetAction"
        }
        namespace Methods {
            inline constexpr std::uintptr_t UnavailableAction = 0xB7C3B0; // "private void UnavailableAction(LocalizedString localizedString, PersonalNotificationActionIds id)"
            inline constexpr std::uintptr_t TriggerAction = 0xB7C220; // "private void TriggerAction()"
            inline constexpr std::uintptr_t OpenDialog = 0xB7BDF0; // "private void OpenDialog()"
            inline constexpr std::uintptr_t BuyCargo = 0xB7BD10; // "private void BuyCargo()"
            inline constexpr std::uintptr_t CloseDialog = 0xB7BDC0; // "private void CloseDialog()"
        }
    } // namespace CargoSellerTargetActions

    namespace CargoTargetActions { // "Game.Battle.Entities.Building.Updaters.CargoTargetActions (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleEntitiesModel = 0x10; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t battleInputModel = 0x18; // "BattleInputModel"
            inline constexpr std::uintptr_t personalNotificationModel = 0x20; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t uiSoundModel = 0x28; // "GlobalUISoundModel"
            inline constexpr std::uintptr_t entityId = 0x30; // "int"
            inline constexpr std::uintptr_t codexModel = 0x38; // "ClientCodexModel"
            inline constexpr std::uintptr_t Take = 0x40; // "TargetAction"
            inline constexpr std::uintptr_t Arrest = 0x48; // "TargetAction"
            inline constexpr std::uintptr_t UnavailableRole = 0x50; // "UnavailableTargetAction"
            inline constexpr std::uintptr_t unavailableKeys = 0x58; // "UnavailableTargetActionsKeys"
            inline constexpr std::uintptr_t becomeRobberNotificationModel = 0x60; // "BecomeRobberNotificationModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Unavailable = 0x9CDF30; // "private void Unavailable(LocalizedString invalidNotification, PersonalNotificationActionIds id)"
            inline constexpr std::uintptr_t UnavailableRoleAction = 0xBC4300; // "private void UnavailableRoleAction()"
            inline constexpr std::uintptr_t ArrestAction = 0xBC4080; // "private void ArrestAction()"
            inline constexpr std::uintptr_t TakeAction = 0xBC4180; // "private void TakeAction()"
        }
    } // namespace CargoTargetActions

    namespace CargoTargetProvider { // "Game.Battle.Entities.Cargo.CargoTargetProvider (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t targetActions = 0x20; // "CargoTargetActions"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x28; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t crouchStandUpModel = 0x30; // "CrouchStandUpModel"
            inline constexpr std::uintptr_t unavailableKeys = 0x38; // "UnavailableTargetActionsKeys"
        }
        namespace Methods {
            inline constexpr std::uintptr_t GetTargetAction = 0xB7C860; // "protected override ITargetAction GetTargetAction()"
        }
    } // namespace CargoTargetProvider

    namespace CargoVisualAmountUpdater { // "Game.Battle.Entities.CargoExchanger.Updaters.CargoVisualAmountUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t cargoExchangerModel = 0x10; // "CargoExchangerModel"
            inline constexpr std::uintptr_t cargoExchangerView = 0x18; // "CargoExchangerView"
            inline constexpr std::uintptr_t cargoViewDescriptions = 0x20; // "CargoViewDescriptions"
            inline constexpr std::uintptr_t scopesLoadingModel = 0x28; // "ScopesLoadingModel"
            inline constexpr std::uintptr_t cargosToLoad = 0x30; // "HashSet<int>"
            inline constexpr std::uintptr_t indexedCargoDescriptions = 0x38; // "List<ValueTuple<CargoDescription, IDisposableContent<CargoView>>>"
            inline constexpr std::uintptr_t cargoAmount = 0x40; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB7E6D0; // "public void Update()"
            inline constexpr std::uintptr_t Dispose = 0xB7E390; // "private void Dispose()"
        }
    } // namespace CargoVisualAmountUpdater

    namespace CargoWorkbenchBuilderSlotModel { // "Game.Battle.Builder.CargoWorkbenchBuilderSlotModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t plotBuildingCargoWorkbenchSlotDescription = 0x28; // "PlotBuildingCargoWorkbenchSlotDescription"
            inline constexpr std::uintptr_t cargoOpenWorkbenchesModel = 0x30; // "CargoWorkbenchesModel<CargoOpenWorkbenchModel>"
            inline constexpr std::uintptr_t cargoExchangeWorkbenchesModel = 0x38; // "CargoWorkbenchesModel<CargoExchangeWorkbenchModel>"
            inline constexpr std::uintptr_t typeDescription = 0x40; // "CargoWorkbenchTypeDescription"
            inline constexpr std::uintptr_t defenseBlockPublicModel = 0x48; // "DefenseBlockPublicModel"
            inline constexpr std::uintptr_t changeFurnitureExpiringResource = 0x50; // "ExpiringResourceModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_InventoryItemDescription = 0xD3F3E0; // "public override InventoryItemDescription get_InventoryItemDescription()"
            inline constexpr std::uintptr_t CheckType = 0xD3F170; // "public override bool CheckType(InventoryItemDescription itemDescription)"
            inline constexpr std::uintptr_t CheckCooldown = 0xD3F040; // "public override bool CheckCooldown(long now)"
            inline constexpr std::uintptr_t IsBlockedByBreachedObjects = 0x7EC9F0; // "public override bool IsBlockedByBreachedObjects(long now)"
            inline constexpr std::uintptr_t IsBlockedByLootObjects = 0x7EC9F0; // "public override bool IsBlockedByLootObjects(long now)"
            inline constexpr std::uintptr_t CheckShowModalOnMove = 0xD3F070; // "public override bool CheckShowModalOnMove(long now)"
            inline constexpr std::uintptr_t IsBlockedByRaidLock = 0xD3F250; // "public override bool IsBlockedByRaidLock(long now)"
            inline constexpr std::uintptr_t get_IsCargoOpenWorkbench = 0xD3F550; // "public bool get_IsCargoOpenWorkbench()"
            inline constexpr std::uintptr_t get_IsCargoExchangeWorkbench = 0xD3F4F0; // "public bool get_IsCargoExchangeWorkbench()"
            inline constexpr std::uintptr_t get_CargoOpenWorkbenchModel = 0xD3F380; // "public CargoOpenWorkbenchModel get_CargoOpenWorkbenchModel()"
            inline constexpr std::uintptr_t get_CargoExchangeWorkbenchModel = 0xD3F320; // "public CargoExchangeWorkbenchModel get_CargoExchangeWorkbenchModel()"
        }
    } // namespace CargoWorkbenchBuilderSlotModel

    namespace CargoWorkbenchDescription { // "Models.References.CargoWorkbench.CargoWorkbenchDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t OpenWorkbenchDescription = 0x10; // "CargoOpenWorkbenchDescription"
            inline constexpr std::uintptr_t ExchangeWorkbenchDescription = 0x18; // "CargoExchangeWorkbenchDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsOpenWorkbench = 0xA734C0; // "public bool get_IsOpenWorkbench()"
            inline constexpr std::uintptr_t get_IsExchangeWorkbench = 0xBFBA80; // "public bool get_IsExchangeWorkbench()"
            inline constexpr std::uintptr_t GetInventoryItem = 0x448BB20; // "public InventoryItemDescription GetInventoryItem()"
        }
    } // namespace CargoWorkbenchDescription

    namespace CargoWorkbenchExtensions { // "Models.Utils.Extensions.CargoWorkbenchExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t IsSlotEmpty = 0x393F980; // "public static bool IsSlotEmpty(PlotBuildingCargoWorkbenchSlotDescription slotDescription, CargoWorkbenchesModel<CargoOpenWorkbenchModel> openWorkbenches, CargoWorkbenchesModel<CargoExchangeWorkbenchModel> exchangeWorkbenches)"
            inline constexpr std::uintptr_t BuildDescriptionBySlotValue = 0x393F7C0; // "public static CargoWorkbenchDescription BuildDescriptionBySlotValue(PlotBuildingCargoWorkbenchSlotDescription slotDescription, CargoWorkbenchesModel<CargoOpenWorkbenchModel> openWorkbenches, CargoWorkbenchesModel<CargoExchangeWorkbenchModel> exchangeWorkbenches)"
            inline constexpr std::uintptr_t BuildDescriptionByItem = 0x393F6D0; // "public static CargoWorkbenchDescription BuildDescriptionByItem(InventoryItemDescription item)"
            inline constexpr std::uintptr_t IsCompatible = 0x393F920; // "public static bool IsCompatible(CargoWorkbenchDescription description, CargoWorkbenchTypeDescription slotType)"
        }
    } // namespace CargoWorkbenchExtensions

    namespace CargoWorkbenchSlotHintUpdater { // "Game.Battle.SettlementBuilder.CargoWorkbenchSlotHintUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t targetHintObjectsModel = 0x20; // "TargetHintObjectsModel"
            inline constexpr std::uintptr_t slotModel = 0x28; // "ICargoWorkbenchSlotModel"
            inline constexpr std::uintptr_t targetObject = 0x30; // "ITargetObject"
            inline constexpr std::uintptr_t isVisible = 0x38; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xDC69B0; // "public CargoWorkbenchSlotHintUpdater Init(ICargoWorkbenchSlotModel slotModel, TargetHintObjectsModel targetHintObjectsModel, ITargetObject targetObject)"
            inline constexpr std::uintptr_t Dispose = 0xDC6940; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xDC6A10; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace CargoWorkbenchSlotHintUpdater

    namespace CargoWorkbenchTypeConfig { // "Models.References.CargoWorkbench.CargoWorkbenchTypeConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t CommonTypeFunc = 0x10; // "Func<CargoWorkbenchTypeDescription>"
            inline constexpr std::uintptr_t LaboratoryTypeFunc = 0x18; // "Func<CargoWorkbenchTypeDescription>"
            inline constexpr std::uintptr_t GardenBedsTypeFunc = 0x20; // "Func<CargoChargeWorkbenchTypeDescription>"
            inline constexpr std::uintptr_t MethFreezerTypeFunc = 0x28; // "Func<CargoChargeWorkbenchTypeDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_CommonType = 0x1765CB0; // "public CargoWorkbenchTypeDescription get_CommonType()"
            inline constexpr std::uintptr_t get_LaboratoryType = 0x26CF2F0; // "public CargoWorkbenchTypeDescription get_LaboratoryType()"
            inline constexpr std::uintptr_t get_GardenBedsType = 0x9D6230; // "public CargoChargeWorkbenchTypeDescription get_GardenBedsType()"
            inline constexpr std::uintptr_t get_MethFreezerType = 0x993E50; // "public CargoChargeWorkbenchTypeDescription get_MethFreezerType()"
        }
    } // namespace CargoWorkbenchTypeConfig

    namespace CarUpgradeAdapters { // "Game.Battle.Inventory.CarUpgradeAdapters (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t AlarmReadAdapter = 0x10; // "ICarUpgradeReadAdapter<AlarmCarUpgradeDescription>"
            inline constexpr std::uintptr_t PoliceRadioReadAdapter = 0x18; // "ICarUpgradeReadAdapter<PoliceRadioCarUpgradeDescription>"
            inline constexpr std::uintptr_t HornReadAdapter = 0x20; // "ICarUpgradeReadAdapter<HornCarUpgradeDescription>"
            inline constexpr std::uintptr_t EcuReadAdapter = 0x28; // "ICarUpgradeReadAdapter<EcuCarUpgradeDescription>"
            inline constexpr std::uintptr_t TurbochargerReadAdapter = 0x30; // "ICarUpgradeReadAdapter<TurbochargerCarUpgradeDescription>"
            inline constexpr std::uintptr_t EngineCoolingReadAdapter = 0x38; // "ICarUpgradeReadAdapter<EngineCoolingCarUpgradeDescription>"
            inline constexpr std::uintptr_t NitroReadAdapter = 0x40; // "ICarUpgradeReadAdapter<NitroCarUpgradeDescription>"
            inline constexpr std::uintptr_t SuspensionReadAdapter = 0x48; // "ICarUpgradeReadAdapter<SuspensionCarUpgradeDescription>"
            inline constexpr std::uintptr_t SteeringRackReadAdapter = 0x50; // "ICarUpgradeReadAdapter<SteeringRackCarUpgradeDescription>"
            inline constexpr std::uintptr_t TrunkInventoryReadAdapter = 0x58; // "ICarUpgradeReadAdapter<TrunkInventoryCarUpgradeDescription>"
            inline constexpr std::uintptr_t TrunkCargoInventoryReadAdapter = 0x60; // "ICarUpgradeReadAdapter<TrunkCargoInventoryCarUpgradeDescription>"
        }
    } // namespace CarUpgradeAdapters

    namespace CarUpgradeMoveContext { // "Game.Battle.Inventory.CarUpgradeMoveContext (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t carUpgradesSlotsModel = 0x10; // "CarUpgradesSlotsModel"
            inline constexpr std::uintptr_t dummyInventoryModel = 0x18; // "DummyInventoryItemModel"
            inline constexpr std::uintptr_t SlotIndex = 0x20; // "int"
            inline constexpr std::uintptr_t UpgradeType = 0x24; // "CarUpgradeType"
            inline constexpr std::uintptr_t CarEntityId = 0x28; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_ItemModel = 0xA0AF30; // "public IInventoryItemModel get_ItemModel()"
            inline constexpr std::uintptr_t get_RevealContainerModel = 0xA0AFA0; // "public IRevealContainerModel get_RevealContainerModel()"
            inline constexpr std::uintptr_t get_Revealed = 0x7D5050; // "public bool get_Revealed()"
            inline constexpr std::uintptr_t get_CarUpgradeDescription = 0xA0AF00; // "public CarUpgradeDescription get_CarUpgradeDescription()"
            inline constexpr std::uintptr_t get_Count = 0x7E2F30; // "public int get_Count()"
            inline constexpr std::uintptr_t get_Ammo = 0x7E3AB0; // "public int get_Ammo()"
            inline constexpr std::uintptr_t get_Durability = 0x7E3AB0; // "public int get_Durability()"
            inline constexpr std::uintptr_t get_CumulativePoints = 0x7E3AB0; // "public int get_CumulativePoints()"
        }
    } // namespace CarUpgradeMoveContext

    namespace CashLootNodeData { // "Models.Data.CashLootNodeData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Description = 0x20; // "LocationCashLootNodeDescription"
            inline constexpr std::uintptr_t CashAmount = 0x28; // "IPrimitiveData<int>"
        }
    } // namespace CashLootNodeData

    namespace CashLootNodeEntityDataBuilder { // "Models.Replication.EntityDataBuilder.CashLootNodeEntityDataBuilder (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t location = 0x10; // "LocationDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Build = 0x44B53B0; // "public IData Build(int id)"
        }
    } // namespace CashLootNodeEntityDataBuilder

    namespace CashLootNodeEntityReplicationGridLayerExtension { // "Models.Utils.CashLootNode.CashLootNodeEntityReplicationGridLayerExtension (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t IsLocationContainsLongRangeCashLootNodes = 0x3C7F850; // "public static bool IsLocationContainsLongRangeCashLootNodes(LocationDescription locationDescription)"
            inline constexpr std::uintptr_t IsLocationContainsShortRangeCashLootNodes = 0x3C7F860; // "public static bool IsLocationContainsShortRangeCashLootNodes(LocationDescription locationDescription)"
            inline constexpr std::uintptr_t IsLocationContainsCashLootNodes = 0x3C7F710; // "private static bool IsLocationContainsCashLootNodes(LocationDescription locationDescription, bool isLongRange)"
        }
    } // namespace CashLootNodeEntityReplicationGridLayerExtension

    namespace CashLootNodeEntityStreamReader { // "Models.Replication.EntityStreamReader.CashLootNodeEntityStreamReader (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t GetEntityId = 0x391B2D0; // "protected override int GetEntityId(LocationCashLootNodeDescription description)"
        }
    } // namespace CashLootNodeEntityStreamReader

    namespace CashLootNodeModel { // "Models.Models.CashLootNode.CashLootNodeModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t cashAmountData = 0x10; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t Description = 0x18; // "LocationCashLootNodeDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_CashAmount = 0x4974AD0; // "public int get_CashAmount()"
            inline constexpr std::uintptr_t TakeCash = 0x4974A00; // "public void TakeCash(int amount)"
            inline constexpr std::uintptr_t PutCash = 0x4974960; // "public void PutCash(int addAmount)"
            inline constexpr std::uintptr_t CheckArrest = 0x4974910; // "public bool CheckArrest()"
            inline constexpr std::uintptr_t Arrest = 0x49748D0; // "public void Arrest()"
        }
    } // namespace CashLootNodeModel

    namespace CashLootNodeTargetActions { // "Game.Battle.Entities.Plot.CashLootNodeTargetActions (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t UseAction = 0x10; // "TargetAction"
            inline constexpr std::uintptr_t BuilderAction = 0x18; // "TargetAction"
            inline constexpr std::uintptr_t RemovePoopPileAction = 0x20; // "TargetAction"
            inline constexpr std::uintptr_t StealAction = 0x28; // "TargetAction"
            inline constexpr std::uintptr_t PoopAction = 0x30; // "TargetAction"
            inline constexpr std::uintptr_t personalNotificationModel = 0x38; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t uiSoundModel = 0x40; // "GlobalUISoundModel"
            inline constexpr std::uintptr_t battleInputModel = 0x48; // "BattleInputModel"
            inline constexpr std::uintptr_t inventoryDialogModel = 0x50; // "InventoryDialogModel"
            inline constexpr std::uintptr_t clientCodexModel = 0x58; // "ClientCodexModel"
            inline constexpr std::uintptr_t battleConnection = 0x60; // "IRoomConnection"
            inline constexpr std::uintptr_t entityId = 0x68; // "int"
            inline constexpr std::uintptr_t isPoopRequested = 0x6C; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Unavailable = 0xAE9B20; // "private void Unavailable(LocalizedString invalidNotification, PersonalNotificationActionIds id)"
            inline constexpr std::uintptr_t Loot = 0xAE97D0; // "private void Loot()"
            inline constexpr std::uintptr_t Use = 0xAE9BA0; // "private void Use()"
            inline constexpr std::uintptr_t OpenInventory = 0xAE9910; // "private void OpenInventory()"
            inline constexpr std::uintptr_t OpenBuilder = 0xAE9890; // "private void OpenBuilder()"
            inline constexpr std::uintptr_t Poop = 0xAE99B0; // "private void Poop()"
            inline constexpr std::uintptr_t RemovePoopPile = 0xAE9A60; // "private void RemovePoopPile()"
        }
    } // namespace CashLootNodeTargetActions

    namespace CashLootNodeTargetProvider { // "Game.Battle.EntityModel.Plot.CashLootNodeTargetProvider (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t settlementHelperModel = 0x20; // "ISettlementHelperModel"
            inline constexpr std::uintptr_t targetActions = 0x28; // "CashLootNodeTargetActions"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x30; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t moneyWorkbench = 0x38; // "IMoneyWorkbenchModel"
            inline constexpr std::uintptr_t moneyWorkbenchModel = 0x40; // "ClientMoneyWorkbenchModel"
            inline constexpr std::uintptr_t partyMemberAccessModel = 0x48; // "IPartyMemberAccessModel"
            inline constexpr std::uintptr_t entityId = 0x50; // "int"
            inline constexpr std::uintptr_t localizationKeys = 0x58; // "LocalizationKeys"
        }
        namespace Methods {
            inline constexpr std::uintptr_t FillTargetActions = 0xC1EBF0; // "protected internal override void FillTargetActions(List<ITargetAction> actions)"
            inline constexpr std::uintptr_t SetKnockoutValidity = 0xC1F130; // "private void SetKnockoutValidity(TargetAction action, bool isKnockedOut)"
            inline constexpr std::uintptr_t SetTakeCashValidity = 0xC1F190; // "private void SetTakeCashValidity(TargetAction action, bool isKnockedOut, int dirtyAmount, PlayerEntityModel player)"
        }
    } // namespace CashLootNodeTargetProvider

    namespace ChangedSlotInventoryModelUpdater { // "Game.Battle.Inventory.ChangedSlotInventoryModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t slotModel = 0x20; // "IInventorySlotModel"
            inline constexpr std::uintptr_t model = 0x28; // "ChangedSlotsInventoryModel"
            inline constexpr std::uintptr_t currentItem = 0x30; // "InventoryItemDescription"
            inline constexpr std::uintptr_t amount = 0x38; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0x9F6DF0; // "public ChangedSlotInventoryModelUpdater Init(IInventorySlotModel slotModel, ChangedSlotsInventoryModel model)"
            inline constexpr std::uintptr_t Dispose = 0x9F6DA0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0x9F6F60; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace ChangedSlotInventoryModelUpdater

    namespace ChangedSlotsInventoryModel { // "Game.Battle.Inventory.ChangedSlotsInventoryModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t slotsWithAddedItems = 0x10; // "List<IInventorySlotModel>"
            inline constexpr std::uintptr_t slotsWithRemovedItems = 0x18; // "List<ValueTuple<IInventorySlotModel, InventoryItemDescription>>"
            inline constexpr std::uintptr_t SlotsWithAddedItems = 0x20; // "ReadOnly.List<IInventorySlotModel>"
            inline constexpr std::uintptr_t SlotsWithRemovedItems = 0x28; // "ReadOnly.List<ValueTuple<IInventorySlotModel, InventoryItemDescription>>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Clear = 0xA2AC20; // "public void Clear()"
            inline constexpr std::uintptr_t Add = 0xA2AB70; // "public void Add(IInventorySlotModel slot)"
            inline constexpr std::uintptr_t Remove = 0xA2ACC0; // "public void Remove(IInventorySlotModel slot, InventoryItemDescription wasValue)"
        }
    } // namespace ChangedSlotsInventoryModel

    namespace ChangedSlotsInventoryModelUpdater { // "Game.Battle.Inventory.ChangedSlotsInventoryModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t updaters = 0x20; // "List<IUpdater>"
            inline constexpr std::uintptr_t model = 0x28; // "ChangedSlotsInventoryModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0x9F7240; // "public ChangedSlotsInventoryModelUpdater Init(IInventorySlotsModel slots, ChangedSlotsInventoryModel model, UpdaterPool updaterPool, IRegisterDisposable disposable)"
            inline constexpr std::uintptr_t Dispose = 0x9F71C0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0x9F7690; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace ChangedSlotsInventoryModelUpdater

    namespace CharacterEquipPresetDescription { // "Models.References.Inventory.CharacterEquipPresetDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x81B69E8; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace Fields {
            inline constexpr std::uintptr_t StartEquip = 0x10; // "EquipDescription"
            inline constexpr std::uintptr_t RespawnEquip = 0x18; // "EquipDescription"
        }
        namespace StaticFields {
            inline constexpr std::uintptr_t Develop = 0x0; // "CharacterEquipPresetDescription"
            inline constexpr std::uintptr_t Playtest = 0x8; // "CharacterEquipPresetDescription"
            inline constexpr std::uintptr_t Production = 0x10; // "CharacterEquipPresetDescription"
            inline constexpr std::uintptr_t Performance = 0x18; // "CharacterEquipPresetDescription"
        }
    } // namespace CharacterEquipPresetDescription

    namespace ChargedCargoCollectRewardDescription { // "Models.References.Cargo.ChargedCargoCollectRewardDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t CargoForConversionFunc = 0x20; // "Func<CargoDescription>"
            inline constexpr std::uintptr_t RewardItemFunc = 0x28; // "Func<InventoryItemDescription>"
            inline constexpr std::uintptr_t MinRewardItemsCount = 0x30; // "int"
            inline constexpr std::uintptr_t MaxRewardItemsCount = 0x34; // "int"
            inline constexpr std::uintptr_t BonusRewardMinCount = 0x38; // "int"
            inline constexpr std::uintptr_t BonusRewardMaxCount = 0x3C; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_CargoForConversion = 0x9D6230; // "public CargoDescription get_CargoForConversion()"
            inline constexpr std::uintptr_t get_RewardItem = 0x993E50; // "public InventoryItemDescription get_RewardItem()"
        }
    } // namespace ChargedCargoCollectRewardDescription

    namespace CheatCargoChargeWorkbenchSkipTimeMessage { // "Models.Messages.CheatCargoChargeWorkbenchSkipTimeMessage (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x49F18B0; // "public override string get_Type()"
        }
    } // namespace CheatCargoChargeWorkbenchSkipTimeMessage

    namespace CheatClearMoneyWorkbenchPoopPileMessage { // "Models.Messages.CheatClearMoneyWorkbenchPoopPileMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t entityId = 0x20; // "IPrimitiveData<int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_EntityId = 0x49F2100; // "public int get_EntityId()"
            inline constexpr std::uintptr_t get_Type = 0x49F2150; // "public override string get_Type()"
        }
    } // namespace CheatClearMoneyWorkbenchPoopPileMessage

    namespace CheatFillExternalInventoryMessage { // "Models.Messages.Inventory.CheatFillExternalInventoryMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t externalInventoryEntityId = 0x20; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t item = 0x28; // "IPrimitiveData<InventoryItemDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_ExternalInventoryEntityId = 0x4A19970; // "public int get_ExternalInventoryEntityId()"
            inline constexpr std::uintptr_t get_Item = 0x4A199C0; // "public InventoryItemDescription get_Item()"
            inline constexpr std::uintptr_t get_Type = 0x4A19A10; // "public override string get_Type()"
        }
    } // namespace CheatFillExternalInventoryMessage

    namespace CheatFillMoneyWorkbenchMessage { // "Models.Messages.CheatFillMoneyWorkbenchMessage (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x49F28C0; // "public override string get_Type()"
        }
    } // namespace CheatFillMoneyWorkbenchMessage

    namespace CheatSetMoneyWorkbenchPoopPileCountMessage { // "Models.Messages.CheatSetMoneyWorkbenchPoopPileCountMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t entityId = 0x20; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t count = 0x28; // "IPrimitiveData<int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_EntityId = 0x49FB3C0; // "public int get_EntityId()"
            inline constexpr std::uintptr_t get_Count = 0x49FB370; // "public int get_Count()"
            inline constexpr std::uintptr_t get_Type = 0x49FB410; // "public override string get_Type()"
        }
    } // namespace CheatSetMoneyWorkbenchPoopPileCountMessage

    namespace CheatSpawnCargoMessage { // "Models.Messages.CheatSpawnCargoMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t cargo = 0x20; // "IPrimitiveData<CargoDescription>"
            inline constexpr std::uintptr_t cumulativePoints = 0x28; // "CargoCumulativePointsData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Cargo = 0x4A00FB0; // "public CargoDescription get_Cargo()"
            inline constexpr std::uintptr_t get_CumulativePoints = 0x4A01000; // "public int get_CumulativePoints()"
            inline constexpr std::uintptr_t get_Type = 0x4A01040; // "public override string get_Type()"
        }
    } // namespace CheatSpawnCargoMessage

    namespace CheatTimeSkipCargoExchangeWorkbenchMessage { // "Models.Messages.CheatTimeSkipCargoExchangeWorkbenchMessage (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x4A02BA0; // "public override string get_Type()"
        }
    } // namespace CheatTimeSkipCargoExchangeWorkbenchMessage

    namespace CheatTimeSkipCargoOpenWorkbenchMessage { // "Models.Messages.CheatTimeSkipCargoOpenWorkbenchMessage (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x4A02BD0; // "public override string get_Type()"
        }
    } // namespace CheatTimeSkipCargoOpenWorkbenchMessage

    namespace CheatTimeSkipCargoProductionWorkbenchMessage { // "Models.Messages.CheatTimeSkipCargoProductionWorkbenchMessage (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x4A02C00; // "public override string get_Type()"
        }
    } // namespace CheatTimeSkipCargoProductionWorkbenchMessage

    namespace CheckRoleUseInventoryUpdater { // "Game.Battle.Inventory.CheckRoleUseInventoryUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t inventoryDialogModel = 0x20; // "InventoryDialogModel"
            inline constexpr std::uintptr_t role = 0x28; // "IPrimitiveModel<PlayerRoleDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0x9F7740; // "public CheckRoleUseInventoryUpdater Init(InventoryDialogModel inventoryDialogModel, IPrimitiveModel<PlayerRoleDescription> role)"
            inline constexpr std::uintptr_t Dispose = 0x92B5C0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0x9F7780; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace CheckRoleUseInventoryUpdater

    namespace CheckSpawnLootOnSwapBuilderWithInventoryMessage { // "Models.Messages.Builder.CheckSpawnLootOnSwapBuilderWithInventoryMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t entityId = 0x20; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t inventorySlot = 0x28; // "IPrimitiveData<InventorySlotDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_EntityId = 0x4A1A0F0; // "public int get_EntityId()"
            inline constexpr std::uintptr_t get_InventorySlot = 0x4A1A140; // "public InventorySlotDescription get_InventorySlot()"
            inline constexpr std::uintptr_t get_Type = 0x4A1A190; // "public override string get_Type()"
        }
    } // namespace CheckSpawnLootOnSwapBuilderWithInventoryMessage

    namespace CheckTakeLootObjectModel { // "Models.Models.CheckTakeLootObject.CheckTakeLootObjectModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t location = 0x10; // "ComputedLocationDescription"
            inline constexpr std::uintptr_t accessEntities = 0x18; // "ReadOnly.Dictionary<int, AccessEntityModel>"
            inline constexpr std::uintptr_t interactEntities = 0x20; // "ReadOnly.Dictionary<int, IInteractEntityModel>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t CheckTakeStatic = 0x497ED70; // "public bool CheckTakeStatic(StaticLootObjectModel staticLootObjectModel, long now, BattleCharacterModel characterModel, IInventoryModel inventoryModel, out IInventorySlotModel costItemSlot)"
            inline constexpr std::uintptr_t CheckAccessGranted = 0x497EB40; // "private bool CheckAccessGranted(StaticLootObjectModel staticLootObjectModel)"
            inline constexpr std::uintptr_t CheckTakeRandom = 0x497ECC0; // "public bool CheckTakeRandom(RandomLootObjectModel randomLootObjectModel, long now, BattleCharacterModel characterModel, IInventoryModel inventoryModel, out IInventorySlotModel costItemSlot)"
            inline constexpr std::uintptr_t CheckTake = 0x497EE40; // "private bool CheckTake(ILootObjectModel lootObjectModel, int entityId, long now, BattleCharacterModel characterModel, IInventoryModel inventoryModel, out IInventorySlotModel costItemSlot)"
            inline constexpr std::uintptr_t CheckCanPayCost = 0x497EBA0; // "private bool CheckCanPayCost(IInventoryModel inventoryModel, ILootObjectModel lootObjectModel, out IInventorySlotModel costItemSlot)"
        }
    } // namespace CheckTakeLootObjectModel

    namespace ChipsInventoryModel { // "Game.Battle.CollectionDialog.ChipsInventoryModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Model = 0x10; // "CharacterRouletteRewardModel"
            inline constexpr std::uintptr_t Slots = 0x18; // "IInventorySlotsModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t TryGetSlot = 0xCF1B40; // "public bool TryGetSlot(InventorySlotDescription slot, out IInventorySlotModel slotModel)"
            inline constexpr std::uintptr_t get_Description = 0xCF1D90; // "public InventoryCellsSizeDescription get_Description()"
            inline constexpr std::uintptr_t get_LinesCount = 0xCF1DF0; // "public int get_LinesCount()"
            inline constexpr std::uintptr_t get_TakeOnlyLinesCount = 0x7E3AB0; // "public int get_TakeOnlyLinesCount()"
        }
    } // namespace ChipsInventoryModel

    namespace ChipsInventoryModelUpdater { // "Game.Battle.CollectionDialog.ChipsInventoryModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t inventoryModel = 0x20; // "ChipsInventoryModel"
            inline constexpr std::uintptr_t previousValue = 0x28; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xCF15E0; // "public ChipsInventoryModelUpdater Init(ChipsInventoryModel inventoryModel)"
            inline constexpr std::uintptr_t Dispose = 0xA12060; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xCF1610; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace ChipsInventoryModelUpdater

    namespace ChipsItemMoveContext { // "Game.Battle.Inventory.ChipsItemMoveContext (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t EntityId = 0x10; // "int"
            inline constexpr std::uintptr_t ChipsInventory = 0x18; // "ChipsInventoryModel"
            inline constexpr std::uintptr_t Slot = 0x20; // "IInventorySlotModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Inventory = 0x7E7130; // "public IInventoryModel get_Inventory()"
            inline constexpr std::uintptr_t get_ItemModel = 0xA0B2A0; // "public IInventoryItemModel get_ItemModel()"
            inline constexpr std::uintptr_t get_RevealContainerModel = 0xA0B2F0; // "public IRevealContainerModel get_RevealContainerModel()"
            inline constexpr std::uintptr_t get_Revealed = 0x7D5050; // "public bool get_Revealed()"
            inline constexpr std::uintptr_t get_Count = 0xA0B150; // "public int get_Count()"
            inline constexpr std::uintptr_t get_Ammo = 0xA0B0E0; // "public int get_Ammo()"
            inline constexpr std::uintptr_t get_Durability = 0xA0B230; // "public int get_Durability()"
            inline constexpr std::uintptr_t get_CumulativePoints = 0xA0B1C0; // "public int get_CumulativePoints()"
        }
    } // namespace ChipsItemMoveContext

    namespace ClanBattleLootObjectUpdater { // "Game.Battle.Entities.Building.Updaters.ClanBattleLootObjectUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t location = 0x10; // "LocationDescription"
            inline constexpr std::uintptr_t randomLootObjectItems = 0x18; // "RandomLootObjectItemsData"
            inline constexpr std::uintptr_t physicsSceneModel = 0x20; // "PhysicsSceneModel"
            inline constexpr std::uintptr_t battleScreenContent = 0x28; // "BattleScreenContent"
            inline constexpr std::uintptr_t locationScreenViewModel = 0x30; // "LocationScreenViewModel"
            inline constexpr std::uintptr_t scopesLoadingModel = 0x38; // "ScopesLoadingModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x40; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t regularGrid = 0x48; // "RegularGrid"
            inline constexpr std::uintptr_t views = 0x50; // "Dictionary<int, IDisposableContent<LootObjectView>>"
            inline constexpr std::uintptr_t deactivatedIds = 0x58; // "HashSet<int>"
            inline constexpr std::uintptr_t foundIds = 0x60; // "List<int>"
            inline constexpr std::uintptr_t requestedViews = 0x68; // "List<LootObjectViewDescription>"
            inline constexpr std::uintptr_t pendingViews = 0x70; // "List<ValueTuple<RandomLootObjectDescription, LootObjectViewDescription>>"
            inline constexpr std::uintptr_t id = 0x78; // "int"
            inline constexpr std::uintptr_t cellX = 0x7C; // "int"
            inline constexpr std::uintptr_t cellY = 0x80; // "int"
            inline constexpr std::uintptr_t isRandomLootObjectsInited = 0x84; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t InitRandomLootObjects = 0xBAE150; // "public void InitRandomLootObjects()"
            inline constexpr std::uintptr_t RequestRandomColliderView = 0xBAE410; // "private void RequestRandomColliderView(RandomLootObjectDescription randomLootObjectDescription, LootObjectItemDescription lootObjectItemDescription)"
            inline constexpr std::uintptr_t CreateLoadedRandomColliderViews = 0xBADDB0; // "private void CreateLoadedRandomColliderViews()"
            inline constexpr std::uintptr_t CreateRandomColliderView = 0xBADF00; // "private void CreateRandomColliderView(RandomLootObjectDescription randomLootObjectDescription, LootObjectViewDescription lootObjectViewDescription)"
            inline constexpr std::uintptr_t Update = 0xBAE8D0; // "public void Update()"
        }
    } // namespace ClanBattleLootObjectUpdater

    namespace ClickableItemsModel { // "Game.Battle.Inventory.ClickableItemsModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t items = 0x10; // "Dictionary<IItemMoveContext, PointerButtonView>"
            inline constexpr std::uintptr_t Items = 0x18; // "ReadOnlyDictionaryNonAlloc<IItemMoveContext, PointerButtonView>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Add = 0xA2AF40; // "public void Add(IItemMoveContext model, PointerButtonView view)"
            inline constexpr std::uintptr_t Remove = 0xA2AFB0; // "public void Remove(IItemMoveContext model)"
        }
    } // namespace ClickableItemsModel

    namespace ClientDropCargoModel { // "Models.Models.DropCargoModel.ClientDropCargoModel (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t Drop = 0x4949780; // "public override void Drop(CharacterCargoModel characterCargoModel, ITransformModel transformModel, CharacterControllerModel characterControllerModel)"
            inline constexpr std::uintptr_t DropForward = 0x4949780; // "public override void DropForward(CharacterCargoModel characterCargoModel, ITransformModel transformModel, CharacterControllerModel characterControllerModel)"
        }
    } // namespace ClientDropCargoModel

    namespace ClientMoneyWorkbenchModel { // "Game.Battle.EntityModel.Plot.ClientMoneyWorkbenchModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t LaunderingState = 0x10; // "LaunderingState"
            inline constexpr std::uintptr_t MaxDirtyCashAmount = 0x20; // "int"
            inline constexpr std::uintptr_t TakeDirtyCashLimit = 0x24; // "int"
            inline constexpr std::uintptr_t TabsState = 0x28; // "MoneyLaunderingDialogView.TabsState"
        }
    } // namespace ClientMoneyWorkbenchModel

    namespace ClientNotification_InventoryItemUsed { // "Models.ClientNotification.ClientNotification.InventoryItemUsed (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Item = 0x10; // "InventoryItemDescription"
            inline constexpr std::uintptr_t Amount = 0x18; // "int"
        }
    } // namespace ClientNotification_InventoryItemUsed

    namespace ClientNotification_LootInfo { // "Models.ClientNotification.ClientNotification.LootInfo (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Items = 0x10; // "IReadOnlyCollection<ValueTuple<InventoryItemDescription, int, bool>>"
        }
    } // namespace ClientNotification_LootInfo

    namespace CloseDialogOnCopRoleChangedUpdater { // "Game.Battle.Inventory.CloseDialogOnCopRoleChangedUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t characterModel = 0x10; // "BattleCharacterModel"
            inline constexpr std::uintptr_t screenModel = 0x18; // "IScreenModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x9F77F0; // "public void Update()"
        }
    } // namespace CloseDialogOnCopRoleChangedUpdater

    namespace CloseInventoryDialogUpdater { // "Game.Battle.Inventory.CloseInventoryDialogUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t inventoryDialogModel = 0x10; // "IScreenModel"
            inline constexpr std::uintptr_t dialogs = 0x18; // "List<IScreenModel>"
            inline constexpr std::uintptr_t isAnotherDialogActive = 0x20; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x9F7A00; // "public void Update()"
            inline constexpr std::uintptr_t IsAnotherDialogActive = 0x9F7890; // "private bool IsAnotherDialogActive()"
        }
    } // namespace CloseInventoryDialogUpdater

    namespace CollectChargedCargoRewardModel { // "Models.Models.ProlongedInteractionHandler.Handlers.CollectChargedCargoRewardModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t cargoChargeWorkbenches = 0x10; // "ReadOnly.Dictionary<int, CargoChargeWorkbenchModel>"
            inline constexpr std::uintptr_t worldInterruptModel = 0x18; // "IWorldInterruptModel"
            inline constexpr std::uintptr_t itemActionsController = 0x20; // "IItemActionsController"
            inline constexpr std::uintptr_t settlementBonusModel = 0x28; // "SettlementBonusModel"
            inline constexpr std::uintptr_t pickupLootResult = 0x30; // "PickupLootResult"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Process = 0x48D32D0; // "public override MutuallyExclusiveProcessesDescription get_Process()"
            inline constexpr std::uintptr_t get_StartCommand = 0x48D3360; // "internal override UseEntityCommandDescription get_StartCommand()"
            inline constexpr std::uintptr_t get_StopCommand = 0x48D33F0; // "internal override UseEntityCommandDescription get_StopCommand()"
            inline constexpr std::uintptr_t CheckInteractionStart = 0x48D29A0; // "public override bool CheckInteractionStart(UseEntityCommandDescription command, int useEntityId, PlayerRoleDescription playerRole)"
            inline constexpr std::uintptr_t HandelRequest = 0x48D2D60; // "public override void HandelRequest(long now, int entityId, ProlongedInteractionInputDescription prolongedInteractionInput, BattleCharacterModel characterModel)"
            inline constexpr std::uintptr_t TryFinishPrediction = 0x48D3060; // "public override bool TryFinishPrediction(long now, BattleCharacterModel characterModel)"
            inline constexpr std::uintptr_t TryGetTargetPosition = 0x48D3140; // "public override bool TryGetTargetPosition(int entityId, out Vector3 position)"
            inline constexpr std::uintptr_t CheckTakeRewardFromNextCargo = 0x48D2A50; // "private bool CheckTakeRewardFromNextCargo(IInventoryModel inventory, IEquipSlotsModel equipSlots, IPocketsModel pockets, CargoChargeWorkbenchModel cargoChargeWorkbenchModel)"
        }
    } // namespace CollectChargedCargoRewardModel

    namespace CollectChargedCargoRewardProlongedAction { // "Game.Battle.Entities.Player.ProlongedActions.CollectChargedCargoRewardProlongedAction (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "ProlongedInteractionModel"
            inline constexpr std::uintptr_t worldEntitiesModel = 0x18; // "WorldEntitiesModel"
            inline constexpr std::uintptr_t cargoChargeWorkbenchViewDescriptions = 0x20; // "CargoChargeWorkbenchViewDescriptions"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Label = 0xB1C2B0; // "public LocalizedString get_Label()"
            inline constexpr std::uintptr_t get_IsActive = 0xB1C2A0; // "public bool get_IsActive()"
            inline constexpr std::uintptr_t get_EndTs = 0xB19D10; // "public long get_EndTs()"
            inline constexpr std::uintptr_t get_Duration = 0xB1C1E0; // "public long get_Duration()"
            inline constexpr std::uintptr_t Interrupt = 0xB1C130; // "public void Interrupt(BattleInputModel battleInputModel)"
        }
    } // namespace CollectChargedCargoRewardProlongedAction

    namespace CollectionInventoryModel { // "Game.Battle.CollectionDialog.CollectionInventoryModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t collectionModel = 0x10; // "ICollectionTableModel"
            inline constexpr std::uintptr_t slots = 0x18; // "CollectionSlotsModel"
            inline constexpr std::uintptr_t Id = 0x20; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t TryGetSlot = 0xCFD910; // "public bool TryGetSlot(InventorySlotDescription slot, out IInventorySlotModel slotModel)"
            inline constexpr std::uintptr_t GetSlot = 0xCFD2C0; // "public CollectionInventorySlotModel GetSlot(InventorySlotDescription description)"
            inline constexpr std::uintptr_t CollectionDescription = 0xCFD230; // "public CollectionDescription CollectionDescription(CollectionTableSlotDescription tableSlotDescription)"
            inline constexpr std::uintptr_t get_Description = 0xCFDBA0; // "public InventoryCellsSizeDescription get_Description()"
            inline constexpr std::uintptr_t get_LinesCount = 0xCFDC00; // "public int get_LinesCount()"
            inline constexpr std::uintptr_t get_TakeOnlyLinesCount = 0x7E3AB0; // "public int get_TakeOnlyLinesCount()"
            inline constexpr std::uintptr_t get_Slots = 0x7E7130; // "public IInventorySlotsModel get_Slots()"
            inline constexpr std::uintptr_t SetCollectionTableSlot = 0xCFD380; // "public void SetCollectionTableSlot(CollectionTableSlotDescription collectionTableSlot)"
        }
    } // namespace CollectionInventoryModel

    namespace CollectionInventorySlotModel { // "Game.Battle.CollectionDialog.CollectionInventorySlotModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Description = 0x10; // "InventorySlotDescription"
            inline constexpr std::uintptr_t ItemModel = 0x18; // "IInventoryItemModel"
            inline constexpr std::uintptr_t StackModel = 0x20; // "IInventoryStackModel"
            inline constexpr std::uintptr_t AmmoModel = 0x28; // "IAmmoModel"
            inline constexpr std::uintptr_t DurabilityModel = 0x30; // "IDurabilityModel"
            inline constexpr std::uintptr_t CumulativePointsModel = 0x38; // "ICumulativePointsModel"
            inline constexpr std::uintptr_t CollectionStackModel = 0x40; // "CollectionInventoryStackModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Set = 0xCFDC60; // "public void Set(InventoryItemDescription item, int count, int ammo, int durability, int cumulativePoints)"
            inline constexpr std::uintptr_t Unset = 0xCFDF10; // "public void Unset()"
        }
    } // namespace CollectionInventorySlotModel

    namespace CollectionInventorySlotStackModel { // "Models.Models.InventoryStackModel.CollectionInventorySlotStackModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "InventorySlotData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Value = 0x492D740; // "public int get_Value()"
            inline constexpr std::uintptr_t set_Value = 0x492D800; // "public void set_Value(int value)"
        }
    } // namespace CollectionInventorySlotStackModel

    namespace CollectionInventoryStackModel { // "Game.Battle.CollectionDialog.CollectionInventoryStackModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t CollectionItemSlotDescription = 0x10; // "CollectionItemSlotDescription"
            inline constexpr std::uintptr_t HasCount = 0x18; // "int"
            inline constexpr std::uintptr_t NeedCount = 0x1C; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Unset = 0xCFE1A0; // "public void Unset()"
        }
    } // namespace CollectionInventoryStackModel

    namespace CollectionItemMoveContext { // "Game.Battle.Inventory.CollectionItemMoveContext (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t collectionTableSlot = 0x10; // "EnumValue<CollectionTableSlotDescription>"
            inline constexpr std::uintptr_t EntityId = 0x18; // "int"
            inline constexpr std::uintptr_t Inventory = 0x20; // "IInventoryModel"
            inline constexpr std::uintptr_t Slot = 0x28; // "IInventorySlotModel"
            inline constexpr std::uintptr_t collectionInventoryStackModel = 0x30; // "CollectionInventoryStackModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_CollectionTableSlotDescription = 0xA0B4C0; // "public CollectionTableSlotDescription get_CollectionTableSlotDescription()"
            inline constexpr std::uintptr_t get_ItemModel = 0xA0B630; // "public IInventoryItemModel get_ItemModel()"
            inline constexpr std::uintptr_t get_RevealContainerModel = 0xA0B6A0; // "public IRevealContainerModel get_RevealContainerModel()"
            inline constexpr std::uintptr_t get_Revealed = 0x7D5050; // "public bool get_Revealed()"
            inline constexpr std::uintptr_t get_CollectionSlotDescription = 0xA0B4A0; // "public CollectionItemSlotDescription get_CollectionSlotDescription()"
            inline constexpr std::uintptr_t get_Count = 0xA0B500; // "public int get_Count()"
            inline constexpr std::uintptr_t get_NeedCount = 0xA0B680; // "public int get_NeedCount()"
            inline constexpr std::uintptr_t get_Ammo = 0xA0B430; // "public int get_Ammo()"
            inline constexpr std::uintptr_t get_Durability = 0xA0B590; // "public int get_Durability()"
            inline constexpr std::uintptr_t get_CumulativePoints = 0xA0B520; // "public int get_CumulativePoints()"
            inline constexpr std::uintptr_t get_IsFull = 0xA0B600; // "public bool get_IsFull()"
        }
    } // namespace CollectionItemMoveContext

    namespace CollectionTableRestrictedCellsModelUpdater { // "Game.Battle.Inventory.RestrictedCells.CollectionTableRestrictedCellsModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t gatherSettlementCollectionsModel = 0x30; // "GatherSettlementCollectionsModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0x998C80; // "public CollectionTableRestrictedCellsModelUpdater Init(BattleCharacterModel battleCharacterModel, RestrictedCellsModel restrictedCellsModel, GatherSettlementCollectionsModel gatherSettlementCollectionsModel)"
            inline constexpr std::uintptr_t Dispose = 0x9F6DA0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t GetIsActive = 0xA59440; // "protected override bool GetIsActive(IInventoryItemModel itemModel)"
        }
    } // namespace CollectionTableRestrictedCellsModelUpdater

    namespace ContainerEntityInventoryData { // "Models.Data.ContainerEntityInventoryData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Inventory = 0x20; // "InventoryData"
            inline constexpr std::uintptr_t InventoryRevealId = 0x28; // "InventoryRevealIdData"
            inline constexpr std::uintptr_t DynamicLineCount = 0x30; // "IPrimitiveData<int>"
        }
    } // namespace ContainerEntityInventoryData

    namespace ContainerEntityInventoryModel { // "Models.Models.ContainerEntityInventory.ContainerEntityInventoryModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Id = 0x10; // "int"
            inline constexpr std::uintptr_t Inventory = 0x18; // "IInventoryModel"
            inline constexpr std::uintptr_t InventoryRevealIdModel = 0x20; // "InventoryRevealIdModel"
        }
    } // namespace ContainerEntityInventoryModel

    namespace ContainerInventoryEntityModel { // "Game.Battle.EntityModel.Container.ContainerInventoryEntityModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ServerModel = 0x18; // "ContainerEntityInventoryModel"
        }
    } // namespace ContainerInventoryEntityModel

    namespace ContainerInventoryEntityStreamReader { // "Models.Replication.EntityStreamReader.ContainerInventoryEntityStreamReader (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t GetEntityId = 0x3970080; // "protected override int GetEntityId(LocationContainerDescription description)"
        }
    } // namespace ContainerInventoryEntityStreamReader

    namespace CooldownInventoryItemQuickSlotUpdater { // "Game.Battle.Inventory.CooldownInventoryItemQuickSlotUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t usableItemCooldownModel = 0x10; // "UsableItemCooldownModel"
            inline constexpr std::uintptr_t throwableItemCooldownModel = 0x18; // "ThrowableItemCooldownModel"
            inline constexpr std::uintptr_t inventoryItemModel = 0x20; // "IInventoryItemModel"
            inline constexpr std::uintptr_t now = 0x28; // "INow"
            inline constexpr std::uintptr_t view = 0x30; // "CooldownInventoryItemView"
            inline constexpr std::uintptr_t loadedContent = 0x38; // "IComponentInstantiateContent<CooldownInventoryItemView>"
            inline constexpr std::uintptr_t viewItemParent = 0x40; // "Transform"
            inline constexpr std::uintptr_t needShowCooldown = 0x48; // "Nullable<bool>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x9F8570; // "public void Update()"
        }
    } // namespace CooldownInventoryItemQuickSlotUpdater

    namespace CooldownInventoryItemUpdater { // "Game.Battle.Inventory.CooldownInventoryItemUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleModel = 0x20; // "BattleModel"
            inline constexpr std::uintptr_t loadedContent = 0x28; // "IComponentInstantiateContent<CooldownInventoryItemView>"
            inline constexpr std::uintptr_t usableItemCooldownModel = 0x30; // "UsableItemCooldownModel"
            inline constexpr std::uintptr_t throwableItemCooldownModel = 0x38; // "ThrowableItemCooldownModel"
            inline constexpr std::uintptr_t now = 0x40; // "INow"
            inline constexpr std::uintptr_t inventoryItemModel = 0x48; // "IInventoryItemModel"
            inline constexpr std::uintptr_t viewItemParent = 0x50; // "Transform"
            inline constexpr std::uintptr_t content = 0x58; // "IDisposableContent<CooldownInventoryItemView>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0x9F8980; // "public CooldownInventoryItemUpdater Init(BattleModel battleModel, InventoryScreenContent inventoryScreenContent, IInventoryItemModel inventoryItemModel, Transform viewItemParent)"
            inline constexpr std::uintptr_t Dispose = 0x9F8900; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0x9F8AE0; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t DisposeContent = 0x9F88A0; // "private void DisposeContent()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace CooldownInventoryItemUpdater

    namespace CooldownInventoryItemView { // "Game.Battle.Inventory.CooldownInventoryItemView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t cooldown = 0x20; // "MinSecTimerView"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetTime = 0x9F8F60; // "public void SetTime(TimeSpan timeSpan)"
        }
    } // namespace CooldownInventoryItemView

    namespace CooldownSettings { // "Game.Battle.Inventory.CooldownSettings (Battle.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t IsCooldownSignificant = 0x9F8F90; // "public static bool IsCooldownSignificant(UsableItemDescription item)"
            inline constexpr std::uintptr_t IsCooldownSignificant_2 = 0x9F8F90; // "public static bool IsCooldownSignificant(ThrowableItemDescription item)"
        }
    } // namespace CooldownSettings

    namespace CopEquipBoxesModel { // "Models.Models.CopEquipBoxes.CopEquipBoxesModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t models = 0x10; // "Dictionary<LocationCopEquipBoxDescription, CopEquipBoxModel>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Item = 0x494EFB0; // "public CopEquipBoxModel get_Item(LocationCopEquipBoxDescription description)"
        }
    } // namespace CopEquipBoxesModel

    namespace CopEquipBoxModel { // "Models.Models.CopEquipBox.CopEquipBoxModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Description = 0x10; // "LocationCopEquipBoxDescription"
            inline constexpr std::uintptr_t OpenedModel = 0x18; // "InteractableObjectOpenedModel"
        }
    } // namespace CopEquipBoxModel

    namespace CopEquipDescription { // "Models.References.Cop.CopEquipDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t PrimaryWeaponFunc = 0x10; // "Func<InventoryItemDescription>"
            inline constexpr std::uintptr_t SecondaryWeaponFunc = 0x18; // "Func<InventoryItemDescription>"
            inline constexpr std::uintptr_t BackpackFunc = 0x20; // "Func<InventoryItemDescription>"
            inline constexpr std::uintptr_t VestFunc = 0x28; // "Func<InventoryItemDescription>"
            inline constexpr std::uintptr_t BeltFunc = 0x30; // "Func<InventoryItemDescription>"
            inline constexpr std::uintptr_t InventoryItems = 0x38; // "IReadOnlyList<InventoryItemWithAmount>"
            inline constexpr std::uintptr_t PocketItemsLazy = 0x40; // "Lazy<IReadOnlyDictionary<PocketSlotDescription, InventoryItemWithAmount>>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_PrimaryWeapon = 0x1765CB0; // "public InventoryItemDescription get_PrimaryWeapon()"
            inline constexpr std::uintptr_t get_SecondaryWeapon = 0x26CF2F0; // "public InventoryItemDescription get_SecondaryWeapon()"
            inline constexpr std::uintptr_t get_Backpack = 0x9D6230; // "public InventoryItemDescription get_Backpack()"
            inline constexpr std::uintptr_t get_Vest = 0x993E50; // "public InventoryItemDescription get_Vest()"
            inline constexpr std::uintptr_t get_Belt = 0x9AA5D0; // "public InventoryItemDescription get_Belt()"
            inline constexpr std::uintptr_t get_PocketItems = 0x4429520; // "public IReadOnlyDictionary<PocketSlotDescription, InventoryItemWithAmount> get_PocketItems()"
            inline constexpr std::uintptr_t New = 0x44292C0; // "public static CopEquipDescription New(InventoryItemDescription primaryWeapon, InventoryItemDescription secondaryWeapon, InventoryItemDescription backpack, InventoryItemDescription vest, InventoryItemDescription belt, IReadOnlyList<InventoryItemWithAmount> inventoryItems, IReadOnlyDictionary<PocketSlotDescription, InventoryItemWithAmount> pocketItems)"
        }
    } // namespace CopEquipDescription

    namespace CopRewardBoxInventoryData { // "Models.Data.CopRewardBoxInventoryData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Inventory = 0x20; // "InventoryData"
            inline constexpr std::uintptr_t InventoryRevealId = 0x28; // "InventoryRevealIdData"
            inline constexpr std::uintptr_t DynamicLineCount = 0x30; // "IPrimitiveData<int>"
        }
    } // namespace CopRewardBoxInventoryData

    namespace CopSalaryItemActionModel { // "Game.Battle.Inventory.CopSalaryItemActionModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t inventoryModel = 0x10; // "IInventoryModel"
            inline constexpr std::uintptr_t slotModel = 0x18; // "IInventorySlotModel"
            inline constexpr std::uintptr_t isTakeOnly = 0x20; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_SlotModel = 0x7E7130; // "public IInventorySlotModel get_SlotModel()"
            inline constexpr std::uintptr_t get_InventoryModel = 0x7EC6B0; // "public IInventoryModel get_InventoryModel()"
            inline constexpr std::uintptr_t get_IsTakeOnly = 0x858ED0; // "public bool get_IsTakeOnly()"
            inline constexpr std::uintptr_t TrySet = 0xA2B990; // "public bool TrySet(IInventoryModel inventoryModel, InventorySlotDescription slot, bool isTakeOnly)"
            inline constexpr std::uintptr_t CheckSet = 0xA2B5B0; // "public bool CheckSet(InventoryItemDescription item, int count, int ammo, int durability, int cumulativePoints, out bool isSet)"
            inline constexpr std::uintptr_t CheckMoveTo = 0xA2B420; // "public bool CheckMoveTo(InventoryItemDescription item, int count, int ammo, int durability, int cumulativePoints, IItemActionModel fromModel, out bool isSet)"
            inline constexpr std::uintptr_t CheckMoveFrom = 0xA2B260; // "public bool CheckMoveFrom(int count, out InventoryItemDescription item, out int ammo, out int durability, out int cumulativePoints, out bool isUnset)"
            inline constexpr std::uintptr_t CheckUnset = 0xA2B680; // "public bool CheckUnset()"
            inline constexpr std::uintptr_t CheckSwap = 0x7EC9F0; // "public bool CheckSwap(InventoryItemDescription item, int count, int ammo, int durability, int cumulativePoints)"
            inline constexpr std::uintptr_t TryGetContent = 0xA2B790; // "public bool TryGetContent(out InventoryItemDescription item, out int count, out int ammo, out int durability, out int cumulativePoints)"
            inline constexpr std::uintptr_t AreEqual = 0xA2B0E0; // "public bool AreEqual(IItemActionModel other)"
            inline constexpr std::uintptr_t Set = 0xA2B700; // "public void Set(long now, InventoryItemDescription item, int count, int ammo, int durability, int cumulativePoints)"
            inline constexpr std::uintptr_t Unset = 0xA2BBF0; // "public void Unset()"
            inline constexpr std::uintptr_t ChangeStack = 0xA2B1C0; // "public void ChangeStack(int count)"
            inline constexpr std::uintptr_t ChangeAmmo = 0xA2B180; // "public void ChangeAmmo(int ammo)"
            inline constexpr std::uintptr_t get_IsSlotBusy = 0x7EC9F0; // "public bool get_IsSlotBusy()"
            inline constexpr std::uintptr_t CheckUnloadAmmo = 0x7EC9F0; // "public bool CheckUnloadAmmo(long now)"
        }
    } // namespace CopSalaryItemActionModel

    namespace CopSalaryItemMoveContext { // "Game.Battle.Inventory.CopSalaryItemMoveContext (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t EntityId = 0x10; // "int"
            inline constexpr std::uintptr_t Inventory = 0x18; // "IInventoryModel"
            inline constexpr std::uintptr_t Slot = 0x20; // "IInventorySlotModel"
            inline constexpr std::uintptr_t RevealContainerModel = 0x28; // "IRevealContainerModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_ItemModel = 0xA0B960; // "public IInventoryItemModel get_ItemModel()"
            inline constexpr std::uintptr_t get_Revealed = 0xA0B9B0; // "public bool get_Revealed()"
            inline constexpr std::uintptr_t get_Count = 0xA0B810; // "public int get_Count()"
            inline constexpr std::uintptr_t get_Ammo = 0xA0B7A0; // "public int get_Ammo()"
            inline constexpr std::uintptr_t get_Durability = 0xA0B8F0; // "public int get_Durability()"
            inline constexpr std::uintptr_t get_CumulativePoints = 0xA0B880; // "public int get_CumulativePoints()"
        }
    } // namespace CopSalaryItemMoveContext

    namespace CryptoWorkbenchConfig { // "Models.References.CryptoFarm.CryptoWorkbenchConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t OutputItemFunc = 0x10; // "Func<InventoryItemDescription>"
            inline constexpr std::uintptr_t BrokenCardFunc = 0x18; // "Func<InventoryItemDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_OutputItemStackSize = 0x4429CA0; // "public int get_OutputItemStackSize()"
            inline constexpr std::uintptr_t get_OutputItem = 0x1765CB0; // "public InventoryItemDescription get_OutputItem()"
            inline constexpr std::uintptr_t get_BrokenCard = 0x26CF2F0; // "public InventoryItemDescription get_BrokenCard()"
        }
    } // namespace CryptoWorkbenchConfig

    namespace CryptoWorkbenchDatabaseData { // "Models.Data.Settlement.CryptoWorkbench.CryptoWorkbenchDatabaseData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Description = 0x20; // "IPrimitiveData<CryptoWorkbenchDescription>"
            inline constexpr std::uintptr_t OutputCountData = 0x28; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t VideoCardsData = 0x30; // "ReferenceMapData<CryptoWorkbenchVideoCardSlotDescription, CryptoWorkbenchVideoCardData>"
            inline constexpr std::uintptr_t EfficiencyUpgrades = 0x38; // "ReferenceMapData<CryptoWorkbenchEfficiencyUpgradeSlotDescription, IPrimitiveData<CryptoWorkbenchEfficiencyUpgradeDescription>>"
            inline constexpr std::uintptr_t SpeedupUpgrades = 0x40; // "ReferenceMapData<CryptoWorkbenchSpeedupUpgradeSlotDescription, IPrimitiveData<CryptoWorkbenchSpeedupUpgradeDescription>>"
            inline constexpr std::uintptr_t LastUpdateTs = 0x48; // "IPrimitiveData<long>"
        }
    } // namespace CryptoWorkbenchDatabaseData

    namespace CryptoWorkbenchDescription { // "Models.References.CryptoFarm.CryptoWorkbenchDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t InventoryItemFunc = 0x20; // "Func<InventoryItemDescription>"
            inline constexpr std::uintptr_t Colliders = 0x28; // "CollidersDescription"
            inline constexpr std::uintptr_t InteractPoint = 0x30; // "Vector3"
            inline constexpr std::uintptr_t InteractDescription = 0x40; // "InteractDescription"
            inline constexpr std::uintptr_t SpawnLootPoint = 0x48; // "Vector3"
            inline constexpr std::uintptr_t Obbs = 0x58; // "IReadOnlyList<OBB>"
            inline constexpr std::uintptr_t VideoCardSlotsCount = 0x60; // "int"
            inline constexpr std::uintptr_t SpeedupSlotsCount = 0x64; // "int"
            inline constexpr std::uintptr_t CoolingSlotsCount = 0x68; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_InventoryItem = 0x9D6230; // "public InventoryItemDescription get_InventoryItem()"
        }
    } // namespace CryptoWorkbenchDescription

    namespace CryptoWorkbenchDestroyModel { // "Models.Models.CryptoWorkbenchDestroy.CryptoWorkbenchDestroyModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "CryptoWorkbenchPublicModel"
            inline constexpr std::uintptr_t interactIgnoreBodyIds = 0x18; // "HashSet<PhysicsBodyId>"
            inline constexpr std::uintptr_t collidersIdData = 0x20; // "CollidersIdData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Destroy = 0x4951240; // "public void Destroy(PhysicsSceneModel physicsSceneModel, WorldEntitiesModel worldEntitiesModel)"
            inline constexpr std::uintptr_t DestroyPhysics = 0x4951050; // "private void DestroyPhysics(PhysicsSceneModel physicsSceneModel)"
        }
    } // namespace CryptoWorkbenchDestroyModel

    namespace CryptoWorkbenchEfficiencyUpgradeDescription { // "Models.References.CryptoFarm.CryptoWorkbenchEfficiencyUpgradeDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ResourceDecreaseModifier = 0x20; // "float"
            inline constexpr std::uintptr_t ItemFunc = 0x28; // "Func<InventoryItemDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Item = 0x993E50; // "public InventoryItemDescription get_Item()"
        }
    } // namespace CryptoWorkbenchEfficiencyUpgradeDescription

    namespace CryptoWorkbenchEntityIds { // "Models.References.Builder.CryptoWorkbenchEntityIds (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t PublicModelEntityId = 0x10; // "int"
            inline constexpr std::uintptr_t PrivateModelEntityId = 0x14; // "int"
            inline constexpr std::uintptr_t VideoCardSlotsEntityIds = 0x18; // "IReadOnlyDictionary<CryptoWorkbenchVideoCardSlotDescription, int>"
            inline constexpr std::uintptr_t CoolingSlotsEntityIds = 0x20; // "IReadOnlyDictionary<CryptoWorkbenchEfficiencyUpgradeSlotDescription, int>"
            inline constexpr std::uintptr_t SpeedupSlotsEntityIds = 0x28; // "IReadOnlyDictionary<CryptoWorkbenchSpeedupUpgradeSlotDescription, int>"
        }
    } // namespace CryptoWorkbenchEntityIds

    namespace CryptoWorkbenchEntityModel { // "Game.Battle.EntityModel.CryptoWorkbench.CryptoWorkbenchEntityModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t CryptoWorkbenchPrivateModel = 0x18; // "CryptoWorkbenchPrivateModel"
        }
    } // namespace CryptoWorkbenchEntityModel

    namespace CryptoWorkbenchExtensions { // "Models.Utils.Extensions.CryptoWorkbenchExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t BuildEntityIds = 0x394A190; // "public static CryptoWorkbenchEntityIds BuildEntityIds(IEntityIdGenerator entityIdGenerator)"
            inline constexpr std::uintptr_t BuildLocationDescription = 0x394A8C0; // "public static LocationCryptoWorkbenchDescription BuildLocationDescription(CryptoWorkbenchDescription description, OrientedPoint orientedPoint, CryptoWorkbenchEntityIds entityIds)"
            inline constexpr std::uintptr_t UpdateFlags = 0x7B3360; // "public static void UpdateFlags(CryptoWorkbenchPublicModel publicModel, CryptoWorkbenchPrivateModel privateModel)"
            inline constexpr std::uintptr_t BuildPlotBuildingCryptoWorkbenchSlotsEnum = 0x394AB80; // "public static ReadOnlyEnum<PlotBuildingCryptoWorkbenchSlotDescription> BuildPlotBuildingCryptoWorkbenchSlotsEnum(ReadOnlyEnum<OutbuildingDescription> outbuildingDescriptions)"
            inline constexpr std::uintptr_t BuildCryptoWorkbenchVideoCardSlotsEnum = 0x3949FC0; // "public static ReadOnlyEnum<CryptoWorkbenchVideoCardSlotDescription> BuildCryptoWorkbenchVideoCardSlotsEnum(ReadOnlyEnum<CryptoWorkbenchDescription> cryptoWorkbenchDescriptions)"
            inline constexpr std::uintptr_t BuildCryptoWorkbenchEfficiencyUpgradeSlotsEnum = 0x3949C20; // "public static ReadOnlyEnum<CryptoWorkbenchEfficiencyUpgradeSlotDescription> BuildCryptoWorkbenchEfficiencyUpgradeSlotsEnum(ReadOnlyEnum<CryptoWorkbenchDescription> cryptoWorkbenchDescriptions)"
            inline constexpr std::uintptr_t BuildCryptoWorkbenchSpeedupUpgradeSlotsEnum = 0x3949DF0; // "public static ReadOnlyEnum<CryptoWorkbenchSpeedupUpgradeSlotDescription> BuildCryptoWorkbenchSpeedupUpgradeSlotsEnum(ReadOnlyEnum<CryptoWorkbenchDescription> cryptoWorkbenchDescriptions)"
        }
    } // namespace CryptoWorkbenchExtensions

    namespace CryptoWorkbenchInitializeModel { // "Models.Models.CryptoWorkbenchInitialize.CryptoWorkbenchInitializeModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "CryptoWorkbenchPublicModel"
            inline constexpr std::uintptr_t interactIgnoreBodyIds = 0x18; // "HashSet<PhysicsBodyId>"
            inline constexpr std::uintptr_t collidersIdData = 0x20; // "CollidersIdData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Initialize = 0x4951450; // "public void Initialize(PhysicsSceneModel physicsSceneModel, WorldEntitiesModel worldEntitiesModel, OutbuildingSlotDescription outbuildingSlotDescription)"
            inline constexpr std::uintptr_t InitializePhysics = 0x49512A0; // "private void InitializePhysics(PhysicsSceneModel physicsSceneModel)"
        }
    } // namespace CryptoWorkbenchInitializeModel

    namespace CryptoWorkbenchPrivateModel { // "Models.Models.CryptoWorkbenchModel.CryptoWorkbenchPrivateModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "CryptoWorkbenchDatabaseData"
            inline constexpr std::uintptr_t Id = 0x18; // "int"
        }
    } // namespace CryptoWorkbenchPrivateModel

    namespace CryptoWorkbenchPublicData { // "Models.Data.Settlement.CryptoWorkbench.CryptoWorkbenchPublicData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Description = 0x20; // "IPrimitiveData<CryptoWorkbenchDescription>"
            inline constexpr std::uintptr_t IsActive = 0x28; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t IsSlotsEmpty = 0x30; // "IPrimitiveData<bool>"
        }
    } // namespace CryptoWorkbenchPublicData

    namespace CryptoWorkbenchPublicModel { // "Models.Models.CryptoWorkbenchModel.CryptoWorkbenchPublicModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t PlotBuildingCryptoWorkbenchSlotDescription = 0x10; // "PlotBuildingCryptoWorkbenchSlotDescription"
            inline constexpr std::uintptr_t Description = 0x18; // "CryptoWorkbenchDescription"
            inline constexpr std::uintptr_t IsActive = 0x20; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t IsSlotsEmpty = 0x28; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t LocationCryptoWorkbenchDescription = 0x30; // "LocationCryptoWorkbenchDescription"
            inline constexpr std::uintptr_t InitializeModel = 0x38; // "CryptoWorkbenchInitializeModel"
            inline constexpr std::uintptr_t DestroyModel = 0x40; // "CryptoWorkbenchDestroyModel"
            inline constexpr std::uintptr_t InteractIgnoreRigidBodies = 0x48; // "HashSet<PhysicsBodyId>"
        }
    } // namespace CryptoWorkbenchPublicModel

    namespace CryptoWorkbenchSpeedupUpgradeDescription { // "Models.References.CryptoFarm.CryptoWorkbenchSpeedupUpgradeDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t SpeedupModifier = 0x20; // "float"
            inline constexpr std::uintptr_t ItemFunc = 0x28; // "Func<InventoryItemDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Item = 0x993E50; // "public InventoryItemDescription get_Item()"
        }
    } // namespace CryptoWorkbenchSpeedupUpgradeDescription

    namespace CryptoWorkbenchVideoCardData { // "Models.Data.Settlement.CryptoWorkbench.CryptoWorkbenchVideoCardData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Description = 0x20; // "ReferenceData<VideoCardDescription>"
            inline constexpr std::uintptr_t Durability = 0x28; // "IPrimitiveData<int>"
        }
    } // namespace CryptoWorkbenchVideoCardData

    namespace CumulativeCargoDescription { // "Models.References.Inventory.CumulativeCargoDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t MaxPointsAmount = 0x20; // "int"
            inline constexpr std::uintptr_t CargoForConversionFunc = 0x28; // "Func<CargoDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_CargoForConversion = 0x993E50; // "public CargoDescription get_CargoForConversion()"
        }
    } // namespace CumulativeCargoDescription

    namespace CumulativeItemDescription { // "Models.References.Inventory.CumulativeItemDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t TypeFunc = 0x20; // "Func<CumulativeItemTypeDescription>"
            inline constexpr std::uintptr_t MaxPointsAmount = 0x28; // "int"
            inline constexpr std::uintptr_t ItemForConversionFunc = 0x30; // "Func<InventoryItemDescription>"
            inline constexpr std::uintptr_t RequiredAuthorityLevelFunc = 0x38; // "Func<RobberAuthorityLevelDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x9D6230; // "public CumulativeItemTypeDescription get_Type()"
            inline constexpr std::uintptr_t get_ItemForConversion = 0x9AA5D0; // "public InventoryItemDescription get_ItemForConversion()"
            inline constexpr std::uintptr_t get_RequiredAuthorityLevel = 0x2AA0B60; // "public RobberAuthorityLevelDescription get_RequiredAuthorityLevel()"
        }
    } // namespace CumulativeItemDescription

    namespace CumulativeItemRules { // "Models.Inventory.CumulativeItemRules (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x822BBD8; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t ExchangeCargoCumulativePointsItemType = 0x0; // "CumulativeItemTypeDescription"
            inline constexpr std::uintptr_t CriminalActionCumulativePointsItemType = 0x8; // "CumulativeItemTypeDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t TryGetInventoryItemWithMaxCumulativePoints = 0x4A33810; // "public static bool TryGetInventoryItemWithMaxCumulativePoints(IInventoryModel inventoryModel, CumulativeItemDescription cumulativeItemDescription, out IInventorySlotModel slot)"
            inline constexpr std::uintptr_t TryGetInventoryItemWithMaxCumulativePoints_2 = 0x4A336F0; // "public static bool TryGetInventoryItemWithMaxCumulativePoints(IInventoryModel inventoryModel, CumulativeItemTypeDescription cumulativeItemTypeDescription, RobberAuthorityModel authorityModel, out IInventorySlotModel slot)"
            inline constexpr std::uintptr_t TryGetInventoryItemWithMaxCumulativePoints_3 = 0x4A33900; // "private static bool TryGetInventoryItemWithMaxCumulativePoints(IInventoryModel inventoryModel, Func<CumulativeItemDescription, bool> cumulativeItemFilter, out IInventorySlotModel resultInventorySlotModel)"
            inline constexpr std::uintptr_t AddPoints = 0x4A333D0; // "public static void AddPoints(IInventorySlotModel inventorySlotModel, int points, IClientNotificationsCollection clientNotifications)"
        }
    } // namespace CumulativeItemRules

    namespace CumulativeItemTypeDescription { // "Models.References.Inventory.CumulativeItemTypeDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t RequiresAuthority = 0x20; // "bool"
        }
    } // namespace CumulativeItemTypeDescription

    namespace CurrentInventoryModel { // "Game.Battle.Inventory.CurrentInventoryModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Type = 0x10; // "InventoryDialogType"
            inline constexpr std::uintptr_t RevealContainerModel = 0x18; // "IRevealContainerModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetRevealContainerModel = 0x7EC720; // "public void SetRevealContainerModel(IRevealContainerModel revealContainerModel)"
        }
    } // namespace CurrentInventoryModel

    namespace CurrentInventoryModel_Builder { // "Game.Battle.Inventory.CurrentInventoryModel.Builder (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t EntityId = 0x20; // "int"
        }
    } // namespace CurrentInventoryModel_Builder

    namespace CurrentInventoryModel_Buyer { // "Game.Battle.Inventory.CurrentInventoryModel.Buyer (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t EntityId = 0x20; // "int"
            inline constexpr std::uintptr_t InventoryEntityId = 0x24; // "int"
            inline constexpr std::uintptr_t InventoryModel = 0x28; // "IInventoryModel"
        }
    } // namespace CurrentInventoryModel_Buyer

    namespace CurrentInventoryModel_CarBench { // "Game.Battle.Inventory.CurrentInventoryModel.CarBench (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t EntityId = 0x20; // "int"
        }
    } // namespace CurrentInventoryModel_CarBench

    namespace CurrentInventoryModel_CollectionTable { // "Game.Battle.Inventory.CurrentInventoryModel.CollectionTable (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t CollectionModel = 0x20; // "CollectionInventoryModel"
            inline constexpr std::uintptr_t EntityId = 0x28; // "int"
            inline constexpr std::uintptr_t CollectionTableSlot = 0x30; // "EnumValue<CollectionTableSlotDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_InventoryModel = 0x7AB150; // "public IInventoryModel get_InventoryModel()"
        }
    } // namespace CurrentInventoryModel_CollectionTable

    namespace CurrentInventoryModel_CopSalary { // "Game.Battle.Inventory.CurrentInventoryModel.CopSalary (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t EntityId = 0x20; // "int"
            inline constexpr std::uintptr_t RevealIdModel = 0x28; // "InventoryRevealIdModel"
            inline constexpr std::uintptr_t InventoryModel = 0x30; // "IInventoryModel"
        }
    } // namespace CurrentInventoryModel_CopSalary

    namespace CurrentInventoryModel_HelicopterBench { // "Game.Battle.Inventory.CurrentInventoryModel.HelicopterBench (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t EntityId = 0x20; // "int"
        }
    } // namespace CurrentInventoryModel_HelicopterBench

    namespace CurrentInventoryModel_Hood { // "Game.Battle.Inventory.CurrentInventoryModel.Hood (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t EntityId = 0x20; // "int"
        }
    } // namespace CurrentInventoryModel_Hood

    namespace CurrentInventoryModel_Inventory { // "Game.Battle.Inventory.CurrentInventoryModel.Inventory (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t InventoryModel = 0x20; // "IInventoryModel"
        }
    } // namespace CurrentInventoryModel_Inventory

    namespace CurrentInventoryModel_Loot { // "Game.Battle.Inventory.CurrentInventoryModel.Loot (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t EntityId = 0x20; // "int"
            inline constexpr std::uintptr_t RevealIdModel = 0x28; // "InventoryRevealIdModel"
            inline constexpr std::uintptr_t InventoryModel = 0x30; // "IInventoryModel"
        }
    } // namespace CurrentInventoryModel_Loot

    namespace CurrentInventoryModel_MoneyWorkbench { // "Game.Battle.Inventory.CurrentInventoryModel.MoneyWorkbench (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t EntityId = 0x20; // "int"
        }
    } // namespace CurrentInventoryModel_MoneyWorkbench

    namespace CurrentInventoryModel_PersonalRepository { // "Game.Battle.Inventory.CurrentInventoryModel.PersonalRepository (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t EntityId = 0x20; // "int"
            inline constexpr std::uintptr_t InventoryModel = 0x28; // "IInventoryModel"
        }
    } // namespace CurrentInventoryModel_PersonalRepository

    namespace CurrentInventoryModel_PlotContainer { // "Game.Battle.Inventory.CurrentInventoryModel.PlotContainer (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t EntityId = 0x20; // "int"
            inline constexpr std::uintptr_t RevealIdModel = 0x28; // "InventoryRevealIdModel"
            inline constexpr std::uintptr_t InventoryModel = 0x30; // "IInventoryModel"
        }
    } // namespace CurrentInventoryModel_PlotContainer

    namespace CurrentInventoryModel_PlotLoot { // "Game.Battle.Inventory.CurrentInventoryModel.PlotLoot (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t EntityId = 0x20; // "int"
            inline constexpr std::uintptr_t PlotLootDialogModel = 0x28; // "PlotLootDialogModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t TryGetCurrentPage = 0xA05360; // "public bool TryGetCurrentPage(out IInventoryModel inventoryModel, out int entityId)"
        }
    } // namespace CurrentInventoryModel_PlotLoot

    namespace CurrentInventoryModel_PoliceBadgeRepository { // "Game.Battle.Inventory.CurrentInventoryModel.PoliceBadgeRepository (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t EntityId = 0x20; // "int"
            inline constexpr std::uintptr_t InventoryModel = 0x28; // "IInventoryModel"
        }
    } // namespace CurrentInventoryModel_PoliceBadgeRepository

    namespace CurrentInventoryModel_RouletteInventory { // "Game.Battle.Inventory.CurrentInventoryModel.RouletteInventory (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t EntityId = 0x20; // "int"
        }
    } // namespace CurrentInventoryModel_RouletteInventory

    namespace CurrentInventoryModel_Shelving { // "Game.Battle.Inventory.CurrentInventoryModel.Shelving (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t EntityId = 0x20; // "int"
        }
    } // namespace CurrentInventoryModel_Shelving

    namespace CurrentInventoryModel_StorageBox { // "Game.Battle.Inventory.CurrentInventoryModel.StorageBox (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t EntityId = 0x20; // "int"
            inline constexpr std::uintptr_t RevealIdModel = 0x28; // "InventoryRevealIdModel"
            inline constexpr std::uintptr_t InventoryModel = 0x30; // "IInventoryModel"
        }
    } // namespace CurrentInventoryModel_StorageBox

    namespace CurrentInventoryModel_Trader { // "Game.Battle.Inventory.CurrentInventoryModel.Trader (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t TraderModel = 0x20; // "TraderInventoryModel"
            inline constexpr std::uintptr_t Type = 0x28; // "LaptopDialogView.DialogType"
            inline constexpr std::uintptr_t EntityId = 0x2C; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_InventoryModel = 0x7AB150; // "public IInventoryModel get_InventoryModel()"
        }
    } // namespace CurrentInventoryModel_Trader

    namespace CurrentInventoryModel_Trunk { // "Game.Battle.Inventory.CurrentInventoryModel.Trunk (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t EntityId = 0x20; // "int"
            inline constexpr std::uintptr_t RevealIdModel = 0x28; // "InventoryRevealIdModel"
            inline constexpr std::uintptr_t InventoryModel = 0x30; // "IInventoryModel"
            inline constexpr std::uintptr_t TrunkModel = 0x38; // "TrunkModel"
        }
    } // namespace CurrentInventoryModel_Trunk

    namespace CurrentInventoryModel_TrunkUpgrades { // "Game.Battle.Inventory.CurrentInventoryModel.TrunkUpgrades (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t EntityId = 0x20; // "int"
        }
    } // namespace CurrentInventoryModel_TrunkUpgrades

    namespace CurrentInventoryModel_Undercarriage { // "Game.Battle.Inventory.CurrentInventoryModel.Undercarriage (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t EntityId = 0x20; // "int"
        }
    } // namespace CurrentInventoryModel_Undercarriage

    namespace CurrentInventoryModel_VehicleLoot { // "Game.Battle.Inventory.CurrentInventoryModel.VehicleLoot (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t EntityId = 0x20; // "int"
            inline constexpr std::uintptr_t RevealIdModel = 0x28; // "InventoryRevealIdModel"
            inline constexpr std::uintptr_t InventoryModel = 0x30; // "IInventoryModel"
        }
    } // namespace CurrentInventoryModel_VehicleLoot

    namespace DatabaseBuilderLootData { // "Models.Data.Settlement.Loot.DatabaseBuilderLootData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Description = 0x20; // "BuilderLootDescription"
            inline constexpr std::uintptr_t RemoveTs = 0x28; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t InventoryPages = 0x30; // "DictionaryData<int, InventoryData>"
            inline constexpr std::uintptr_t CargoInventoryPages = 0x38; // "DictionaryData<int, CargoInventoryData>"
            inline constexpr std::uintptr_t OwnerNickname = 0x40; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t OwnerClanTag = 0x48; // "IPrimitiveData<string>"
        }
    } // namespace DatabaseBuilderLootData

    namespace DebugInventoryUpdater { // "Game.Battle.EntityModel.Container.Debug.DebugInventoryUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t id = 0x10; // "int"
            inline constexpr std::uintptr_t inventorySlots = 0x18; // "IInventorySlotsModel"
            inline constexpr std::uintptr_t positionModel = 0x20; // "IPositionModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xCAD2F0; // "public void Update()"
            inline constexpr std::uintptr_t DrawInventory = 0xCACB00; // "private void DrawInventory()"
        }
    } // namespace DebugInventoryUpdater

    namespace DefenseBlockSlotInventoryMessage { // "Models.Messages.PlotBuildingDefenseSlot.DefenseBlockSlotInventoryMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t inventorySlot = 0x20; // "IPrimitiveData<InventorySlotDescription>"
            inline constexpr std::uintptr_t entityId = 0x28; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t defenseBlockSlot = 0x30; // "IPrimitiveData<DefenseBlockModuleSlotDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_InventorySlot = 0x4A05D10; // "public InventorySlotDescription get_InventorySlot()"
            inline constexpr std::uintptr_t get_EntityId = 0x4A05CC0; // "public int get_EntityId()"
            inline constexpr std::uintptr_t get_DefenseBlockSlot = 0x4A05C70; // "public DefenseBlockModuleSlotDescription get_DefenseBlockSlot()"
        }
    } // namespace DefenseBlockSlotInventoryMessage

    namespace DirtyCashIncomeModel { // "Game.Battle.Inventory.DirtyCashIncome.DirtyCashIncomeModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t newInventoryItems = 0x10; // "Dictionary<IInventorySlotModel, ValueTuple<int, long>>"
            inline constexpr std::uintptr_t itemsToAdd = 0x18; // "Queue<ValueTuple<long, IInventorySlotModel, int>>"
            inline constexpr std::uintptr_t NewInventoryItems = 0x20; // "ReadOnlyDictionaryNonAlloc<IInventorySlotModel, ValueTuple<int, long>>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Add = 0xA75A90; // "public void Add(long endTickIndex, IInventorySlotModel slot, int amount)"
            inline constexpr std::uintptr_t ReleaseByTime = 0xA75B60; // "public void ReleaseByTime(long tsToCanShow)"
            inline constexpr std::uintptr_t RemoveNewInventoryItem = 0xA75C20; // "public void RemoveNewInventoryItem(IInventorySlotModel slotModel)"
            inline constexpr std::uintptr_t get_Peek = 0xA75DE0; // "public long get_Peek()"
            inline constexpr std::uintptr_t get_Count = 0xA75DA0; // "public int get_Count()"
        }
    } // namespace DirtyCashIncomeModel

    namespace DirtyCashIncomeModelUpdater { // "Game.Battle.Inventory.DirtyCashIncome.DirtyCashIncomeModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dirtyCashIncomeModel = 0x10; // "DirtyCashIncomeModel"
            inline constexpr std::uintptr_t timeModel = 0x18; // "TimeModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA758A0; // "public void Update()"
        }
    } // namespace DirtyCashIncomeModelUpdater

    namespace DirtyCashIncomeUpdater { // "Game.Battle.Inventory.DirtyCashIncome.DirtyCashIncomeUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dirtyCashIncomeModel = 0x20; // "DirtyCashIncomeModel"
            inline constexpr std::uintptr_t resourcePopupViewPool = 0x28; // "PooledLoadedComponentContent<ResourcePopupView>"
            inline constexpr std::uintptr_t inventorySlotModel = 0x30; // "IInventorySlotModel"
            inline constexpr std::uintptr_t parent = 0x38; // "RectTransform"
            inline constexpr std::uintptr_t spawnPosition = 0x40; // "Vector2"
            inline constexpr std::uintptr_t now = 0x48; // "INow"
            inline constexpr std::uintptr_t contents = 0x50; // "HashSet<IDisposableContent<ResourcePopupView>>"
            inline constexpr std::uintptr_t removed = 0x58; // "List<IDisposableContent<ResourcePopupView>>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA76040; // "public DirtyCashIncomeUpdater Init(BattleModel battleModel, InventoryScreenContent inventoryScreenContent, IInventorySlotModel inventorySlotModel, RectTransform parent, Vector2 itemPosition, float cellSize, InventoryItemCellsSize inventoryItemCellsSize)"
            inline constexpr std::uintptr_t Dispose = 0xA75E30; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA76180; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace DirtyCashIncomeUpdater

    namespace DiscardAutoLootUpdater { // "Game.Battle.EntityModel.BreakableColliderSet.DiscardAutoLootUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleEntitiesModel = 0x10; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t autoLootAfterBreak = 0x18; // "AutoLootAfterBreakColliderModel"
            inline constexpr std::uintptr_t character = 0x20; // "BattleCharacterModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xCC3AA0; // "public void Update()"
        }
    } // namespace DiscardAutoLootUpdater

    namespace DraggableItemsModel { // "Game.Battle.Inventory.DraggableItemsModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t items = 0x10; // "Dictionary<IItemMoveContext, DraggableItemView>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Add = 0xA0C2D0; // "public void Add(IItemMoveContext model, DraggableItemView view)"
            inline constexpr std::uintptr_t Remove = 0xA0C340; // "public void Remove(IItemMoveContext model)"
            inline constexpr std::uintptr_t TryGetValue = 0xA0C3A0; // "public bool TryGetValue(IItemMoveContext model, out DraggableItemView item)"
            inline constexpr std::uintptr_t get_Items = 0x7EC6B0; // "public Dictionary<IItemMoveContext, DraggableItemView> get_Items()"
        }
    } // namespace DraggableItemsModel

    namespace DragItemInputUpdater { // "Game.Battle.Inventory.DragItemInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t draggableItemsModel = 0x10; // "DraggableItemsModel"
            inline constexpr std::uintptr_t inventoryDragModel = 0x18; // "InventoryDragAndDropModel"
            inline constexpr std::uintptr_t scrollableItemsModel = 0x20; // "ScrollableItemsModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x28; // "IBattleEntitiesModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x9FA3C0; // "public void Update()"
            inline constexpr std::uintptr_t OnEndDrag = 0x9FA2C0; // "private void OnEndDrag(DraggableItemView view, IItemMoveContext draggableModel)"
            inline constexpr std::uintptr_t OnDrag = 0x9FA1C0; // "private void OnDrag(DraggableItemView view, IItemMoveContext draggableModel)"
            inline constexpr std::uintptr_t OnBeginDrag = 0x9F9DF0; // "private void OnBeginDrag(IItemMoveContext draggableModel, DraggableItemView view)"
            inline constexpr std::uintptr_t CheckIsBlocked = 0x9F9C40; // "private bool CheckIsBlocked(IItemMoveContext draggableModel)"
            inline constexpr std::uintptr_t IsVerticalMove = 0x9F9CF0; // "private bool IsVerticalMove(PointerEventData eventData, float scrollSectorSize)"
        }
    } // namespace DragItemInputUpdater

    namespace DragItemView { // "Game.Battle.Inventory.DragItemView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t transform = 0x20; // "RectTransform"
            inline constexpr std::uintptr_t icon = 0x28; // "ImageExtend"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetSize = 0xA0BA40; // "public void SetSize(Vector2 size)"
            inline constexpr std::uintptr_t SetIcon = 0xA0BA20; // "public void SetIcon(Sprite sprite)"
            inline constexpr std::uintptr_t SetPosition = 0x9AA100; // "public void SetPosition(Vector3 position)"
        }
    } // namespace DragItemView

    namespace DragShadowModelUpdater { // "Game.Battle.Inventory.DragShadowModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t itemMoveContexts = 0x20; // "List<IInventoryItemMoveContext>"
            inline constexpr std::uintptr_t inventoryModel = 0x28; // "IInventoryModel"
            inline constexpr std::uintptr_t shadowAreaModel = 0x30; // "InventoryShadowAreaModel"
            inline constexpr std::uintptr_t model = 0x38; // "InventoryDragAndDropModel"
            inline constexpr std::uintptr_t cellSize = 0x40; // "float"
            inline constexpr std::uintptr_t areaTransform = 0x48; // "RectTransform"
            inline constexpr std::uintptr_t useItemsRule = 0x50; // "UseItemsRule"
            inline constexpr std::uintptr_t uiCamera = 0x58; // "Camera"
            inline constexpr std::uintptr_t lastX = 0x60; // "int"
            inline constexpr std::uintptr_t lastY = 0x64; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA0BAF0; // "public DragShadowModelUpdater Init(List<IInventoryItemMoveContext> itemMoveContexts, IInventoryModel inventoryModel, InventoryShadowAreaModel shadowAreaModel, InventoryDragAndDropModel model, float cellSize, RectTransform areaTransform, UseItemsRule useItemsRule, Camera uiCamera)"
            inline constexpr std::uintptr_t Dispose = 0xA0BA60; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA0BDA0; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t UpdateDragShadow = 0xA0BE60; // "private void UpdateDragShadow()"
            inline constexpr std::uintptr_t IsSlotsOccupiedByItemWithCoordinates = 0xA0BBB0; // "private bool IsSlotsOccupiedByItemWithCoordinates(int x, int y, out IItemMoveContext toContext)"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace DragShadowModelUpdater

    namespace DragShadowView { // "Game.Battle.Inventory.DragShadowView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t color = 0x20; // "ColorStyleViewDescription"
            inline constexpr std::uintptr_t transform = 0x28; // "RectTransform"
            inline constexpr std::uintptr_t palette = 0x30; // "GraphicsPalette"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetSize = 0xA0C270; // "public void SetSize(Vector2 value)"
            inline constexpr std::uintptr_t SetState = 0xA0C290; // "public void SetState(bool isValid)"
            inline constexpr std::uintptr_t SetPosition = 0xA0C250; // "public void SetPosition(Vector2 position)"
        }
    } // namespace DragShadowView

    namespace DropAreaInputUpdater { // "Game.Battle.Inventory.DropAreaInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t inventoryCellsUiView = 0x20; // "ScrolledCellsUiView"
            inline constexpr std::uintptr_t inventoryDragModel = 0x28; // "InventoryDragAndDropModel"
            inline constexpr std::uintptr_t playerClientModel = 0x30; // "PlayerClientModel"
            inline constexpr std::uintptr_t itemMoveContexts = 0x38; // "List<IInventoryItemMoveContext>"
            inline constexpr std::uintptr_t inventoryModel = 0x40; // "IInventoryModel"
            inline constexpr std::uintptr_t battleActions = 0x48; // "InputActions.BattleActions"
            inline constexpr std::uintptr_t inventorySelectedModel = 0x50; // "InventorySelectedModel"
            inline constexpr std::uintptr_t itemSplitModel = 0x58; // "ItemSplitModel"
            inline constexpr std::uintptr_t useItemsRule = 0x60; // "UseItemsRule"
            inline constexpr std::uintptr_t personalNotificationModel = 0x68; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t notificationError = 0x70; // "NotificationError"
            inline constexpr std::uintptr_t tooltipModel = 0x78; // "TooltipModel"
            inline constexpr std::uintptr_t tooltipMiniModel = 0x80; // "TooltipMiniModel"
            inline constexpr std::uintptr_t uiCamera = 0x88; // "Camera"
            inline constexpr std::uintptr_t shopSplitModel = 0x90; // "ShopSplitModel"
            inline constexpr std::uintptr_t itemMoveModel = 0x98; // "ItemMoveModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA0C6B0; // "public DropAreaInputUpdater Init(InventoryModels inventoryModels, PlayerClientModel playerClientModel, List<IInventoryItemMoveContext> itemMoveContexts, IInventoryModel inventoryModel, ScrolledCellsUiView inventoryCellsUiView, InputActions.BattleActions battleActions, PersonalNotificationModel personalNotificationModel, NotificationError notificationError, TooltipModel tooltipModel, TooltipMiniModel tooltipMiniModel, Camera uiCamera)"
            inline constexpr std::uintptr_t Dispose = 0xA0C490; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA0CB10; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t IsSplitAction = 0xA0CA20; // "private bool IsSplitAction(IItemMoveContext toContext)"
            inline constexpr std::uintptr_t GetSlotCoordinates = 0xA0C5B0; // "private ValueTuple<int, int> GetSlotCoordinates(DropAreaView dropAreaView)"
            inline constexpr std::uintptr_t IsSlotsOccupiedByItemWithCoordinates = 0xA0C840; // "private bool IsSlotsOccupiedByItemWithCoordinates(int x, int y, out IItemMoveContext toContext)"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace DropAreaInputUpdater

    namespace DropAreaView { // "Game.Battle.Inventory.DropAreaView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsDropped = 0x20; // "bool"
            inline constexpr std::uintptr_t StartPosition = 0x24; // "Vector3"
            inline constexpr std::uintptr_t Position = 0x30; // "Vector2"
            inline constexpr std::uintptr_t PointerId = 0x38; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t OnDrop = 0xA0D2A0; // "public void OnDrop(PointerEventData eventData)"
            inline constexpr std::uintptr_t ResetDrop = 0xA0D300; // "public void ResetDrop()"
        }
    } // namespace DropAreaView

    namespace DropCargoModel { // "Models.Models.DropCargoModel.DropCargoModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleCharacters = 0x10; // "ReadOnly.Dictionary<int, BattleCharacterModel>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Drop = 0x49605D0; // "public void Drop(int characterId)"
            inline constexpr std::uintptr_t Drop_2 = 0x4960680; // "public void Drop(BattleCharacterModel battleCharacterModel)"
        }
    } // namespace DropCargoModel

    namespace DropCargoSystem { // "Models.Systems.DropCargoSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dropCargoModel = 0x38; // "IDropCargoModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x40F5380; // "protected override void Tick(ITick tick)"
        }
    } // namespace DropCargoSystem

    namespace DummyAmmoModel { // "Game.Battle.Inventory.DummyInventory.DummyAmmoModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Value = 0x10; // "int"
        }
    } // namespace DummyAmmoModel

    namespace DummyCumulativePointsModel { // "Game.Battle.Inventory.DummyInventory.DummyCumulativePointsModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Value = 0x10; // "int"
        }
    } // namespace DummyCumulativePointsModel

    namespace DummyDurabilityModel { // "Game.Battle.Inventory.DummyInventory.DummyDurabilityModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Value = 0x10; // "int"
        }
    } // namespace DummyDurabilityModel

    namespace DummyEquipSlotModel { // "Game.Battle.Inventory.DummyInventory.DummyEquipSlotModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Description = 0x10; // "EquipSlotDescription"
            inline constexpr std::uintptr_t ItemModel = 0x18; // "IInventoryItemModel"
            inline constexpr std::uintptr_t DurabilityModel = 0x20; // "IDurabilityModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsBroken = 0x7EC9F0; // "public bool get_IsBroken()"
        }
    } // namespace DummyEquipSlotModel

    namespace DummyEquipSlotsModel { // "Game.Battle.Inventory.DummyInventory.DummyEquipSlotsModel (Battle.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t Set = 0xA59680; // "public void Set(IEquipSlotsModel equipSlots)"
        }
    } // namespace DummyEquipSlotsModel

    namespace DummyInventoryItemModel { // "Game.Battle.Inventory.DummyInventory.DummyInventoryItemModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Value = 0x10; // "InventoryItemDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsEmpty = 0xA59D00; // "public bool get_IsEmpty()"
        }
    } // namespace DummyInventoryItemModel

    namespace DummyInventoryModel { // "Game.Battle.Inventory.DummyInventory.DummyInventoryModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Description = 0x10; // "InventoryCellsSizeDescription"
            inline constexpr std::uintptr_t LinesCount = 0x18; // "int"
            inline constexpr std::uintptr_t Slots = 0x20; // "IInventorySlotsModel"
            inline constexpr std::uintptr_t Groups = 0x28; // "GroupsInventoryItemsModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t TryGetSlot = 0xA5A920; // "public bool TryGetSlot(InventorySlotDescription slot, out IInventorySlotModel slotModel)"
            inline constexpr std::uintptr_t get_TakeOnlyLinesCount = 0x7E3AB0; // "public int get_TakeOnlyLinesCount()"
            inline constexpr std::uintptr_t Set = 0xA59D10; // "public void Set(IInventoryModel inventory)"
        }
    } // namespace DummyInventoryModel

    namespace DummyInventorySlotModel { // "Game.Battle.Inventory.DummyInventory.DummyInventorySlotModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Description = 0x10; // "InventorySlotDescription"
            inline constexpr std::uintptr_t ItemModel = 0x18; // "IInventoryItemModel"
            inline constexpr std::uintptr_t StackModel = 0x20; // "IInventoryStackModel"
            inline constexpr std::uintptr_t AmmoModel = 0x28; // "IAmmoModel"
            inline constexpr std::uintptr_t DurabilityModel = 0x30; // "IDurabilityModel"
            inline constexpr std::uintptr_t CumulativePointsModel = 0x38; // "ICumulativePointsModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Set = 0xA5ABE0; // "public void Set(InventoryItemDescription item, int count, int ammo, int durability, int cumulativePoints)"
            inline constexpr std::uintptr_t Unset = 0xA5AD10; // "public void Unset()"
        }
    } // namespace DummyInventorySlotModel

    namespace DummyInventorySlotsModel { // "Game.Battle.Inventory.DummyInventory.DummyInventorySlotsModel (Battle.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t get_Item = 0xA5B0E0; // "public IInventorySlotModel get_Item(int index)"
        }
    } // namespace DummyInventorySlotsModel

    namespace DummyInventoryStackModel { // "Game.Battle.Inventory.DummyInventory.DummyInventoryStackModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Value = 0x10; // "int"
        }
    } // namespace DummyInventoryStackModel

    namespace DummyPocketSlotModel { // "Game.Battle.Inventory.DummyInventory.DummyPocketSlotModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Description = 0x10; // "PocketSlotDescription"
            inline constexpr std::uintptr_t ItemModel = 0x18; // "IInventoryItemModel"
            inline constexpr std::uintptr_t StackModel = 0x20; // "IInventoryStackModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Set = 0xA5B160; // "public void Set(InventoryItemDescription item, int count)"
            inline constexpr std::uintptr_t Unset = 0xA5B1F0; // "public void Unset()"
        }
    } // namespace DummyPocketSlotModel

    namespace DummyPocketSlotsModel { // "Game.Battle.Inventory.DummyInventory.DummyPocketSlotsModel (Battle.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t get_Item = 0xA5B490; // "public IPocketSlotModel get_Item(int index)"
        }
    } // namespace DummyPocketSlotsModel

    namespace DummyPocketsModel { // "Game.Battle.Inventory.DummyInventory.DummyPocketsModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t StartPocketsCount = 0x10; // "int"
            inline constexpr std::uintptr_t Count = 0x14; // "int"
            inline constexpr std::uintptr_t Slots = 0x18; // "IPocketSlotsModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Set = 0xA5B570; // "public void Set(IPocketsModel pockets)"
            inline constexpr std::uintptr_t TryGetSlot = 0xA5BC80; // "public bool TryGetSlot(PocketSlotDescription slot, out IPocketSlotModel model)"
            inline constexpr std::uintptr_t IsSlotInBelt = 0xA5B550; // "private bool IsSlotInBelt(PocketSlotDescription slot)"
        }
    } // namespace DummyPocketsModel

    namespace DummyRevealContainerModel { // "Game.Global.Inventory.Reveal.Models.DummyRevealContainerModel (Global.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x827D148; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t Empty = 0x0; // "Dictionary<int, string>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Slot = 0x7E3AB0; // "public int get_Slot()"
            inline constexpr std::uintptr_t get_RevealingCount = 0x7E3AB0; // "public int get_RevealingCount()"
            inline constexpr std::uintptr_t set_RevealingCount = 0x7B3360; // "public void set_RevealingCount(int value)"
            inline constexpr std::uintptr_t get_Item = 0xACDB00; // "public string get_Item(int key)"
            inline constexpr std::uintptr_t set_Item = 0x7B3360; // "public void set_Item(int key, string value)"
            inline constexpr std::uintptr_t IncrementSlot = 0x7B3360; // "public void IncrementSlot()"
            inline constexpr std::uintptr_t ContainsKey = 0x7EC9F0; // "public bool ContainsKey(int key)"
            inline constexpr std::uintptr_t Remove = 0x7EC9F0; // "public bool Remove(int key)"
            inline constexpr std::uintptr_t Clear = 0x7B3360; // "public void Clear()"
            inline constexpr std::uintptr_t GetEnumerator = 0x35AE9E0; // "public Dictionary.Enumerator<int, string> GetEnumerator()"
        }
    } // namespace DummyRevealContainerModel

    namespace DynamicLineCountInventoryExtension { // "Models.Inventory.DynamicLineCountInventoryExtension (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t ResetLineCount = 0x4A33F50; // "public static void ResetLineCount(IInventoryModel inventory)"
            inline constexpr std::uintptr_t RestrictLineCount = 0x4A34000; // "public static void RestrictLineCount(IInventoryModel inventory)"
            inline constexpr std::uintptr_t SetLineCount = 0x4A34140; // "private static void SetLineCount(IInventoryModel inventory, int lineCount)"
            inline constexpr std::uintptr_t GetNotEmptyLineCount = 0x4A33E80; // "private static int GetNotEmptyLineCount(IInventoryModel inventory)"
        }
    } // namespace DynamicLineCountInventoryExtension

    namespace DynamicLinesCountInventoryModel { // "Models.Models.InventoryModel.DynamicLinesCountInventoryModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t lineCount = 0x20; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t takeOnlyLinesCount = 0x28; // "IPrimitiveData<int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_LinesCount = 0x492D900; // "public override int get_LinesCount()"
            inline constexpr std::uintptr_t get_TakeOnlyLinesCount = 0x492D950; // "public override int get_TakeOnlyLinesCount()"
            inline constexpr std::uintptr_t SetLineCount = 0x492D810; // "public void SetLineCount(int lineCount)"
            inline constexpr std::uintptr_t SetTakeOnlyLinesCount = 0x492D860; // "public void SetTakeOnlyLinesCount(int takeOnlyLinesCount)"
        }
    } // namespace DynamicLinesCountInventoryModel

    namespace EquipAmmoOrArmorSlotDescription { // "Models.References.Inventory.EquipAmmoOrArmorSlotDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x8183BF0; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace Fields {
            inline constexpr std::uintptr_t HasAmmo = 0x20; // "bool"
            inline constexpr std::uintptr_t HasArmor = 0x21; // "bool"
        }
        namespace StaticFields {
            inline constexpr std::uintptr_t enum_id = 0x0; // "Enum<EquipAmmoOrArmorSlotDescription>"
            inline constexpr std::uintptr_t VestArmor = 0x8; // "EquipAmmoOrArmorSlotDescription"
            inline constexpr std::uintptr_t Weapon0Ammo = 0x10; // "EquipAmmoOrArmorSlotDescription"
            inline constexpr std::uintptr_t Weapon1Ammo = 0x18; // "EquipAmmoOrArmorSlotDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Enum = 0x43E3920; // "public static ReadOnlyEnum<EquipAmmoOrArmorSlotDescription> get_Enum()"
        }
    } // namespace EquipAmmoOrArmorSlotDescription

    namespace EquipDescription { // "Models.References.Inventory.EquipDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x8183D88; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace Fields {
            inline constexpr std::uintptr_t PrimaryWeaponFunc = 0x10; // "Func<WeaponPreset>"
            inline constexpr std::uintptr_t SecondaryWeaponFunc = 0x18; // "Func<WeaponPreset>"
            inline constexpr std::uintptr_t EquipPreset = 0x20; // "EquipPresetDescription"
        }
        namespace StaticFields {
            inline constexpr std::uintptr_t Items = 0x0; // "List<EquipDescription>"
            inline constexpr std::uintptr_t DevelopStart = 0x8; // "EquipDescription"
            inline constexpr std::uintptr_t DevelopRespawn = 0x10; // "EquipDescription"
            inline constexpr std::uintptr_t PlaytestStart = 0x18; // "EquipDescription"
            inline constexpr std::uintptr_t PlaytestRespawn = 0x20; // "EquipDescription"
            inline constexpr std::uintptr_t ProductionStart = 0x28; // "EquipDescription"
            inline constexpr std::uintptr_t ProductionRespawn = 0x30; // "EquipDescription"
            inline constexpr std::uintptr_t PerformanceStart = 0x38; // "EquipDescription"
            inline constexpr std::uintptr_t PerformanceRespawn = 0x40; // "EquipDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_PrimaryWeapon = 0x1765CB0; // "public WeaponPreset get_PrimaryWeapon()"
            inline constexpr std::uintptr_t get_SecondaryWeapon = 0x26CF2F0; // "public WeaponPreset get_SecondaryWeapon()"
        }
    } // namespace EquipDescription

    namespace EquipDropAreaInputUpdater { // "Game.Battle.Inventory.EquipDropAreaInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t equipsUiView = 0x10; // "EquipsUiView"
            inline constexpr std::uintptr_t dragAndDropModel = 0x18; // "InventoryDragAndDropModel"
            inline constexpr std::uintptr_t useItemsRule = 0x20; // "UseItemsRule"
            inline constexpr std::uintptr_t playerEntityModel = 0x28; // "PlayerEntityModel"
            inline constexpr std::uintptr_t personalNotificationModel = 0x30; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t notificationError = 0x38; // "NotificationError"
            inline constexpr std::uintptr_t itemMoveModel = 0x40; // "ItemMoveModel"
            inline constexpr std::uintptr_t shopSplitModel = 0x48; // "ShopSplitModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA0D460; // "public void Update()"
            inline constexpr std::uintptr_t CanMoveOrSwap = 0xA0D340; // "private bool CanMoveOrSwap(EquipItemMoveContext equipContext, out NotificationError.Type errorType)"
        }
    } // namespace EquipDropAreaInputUpdater

    namespace EquipDurabilityModel { // "Models.Models.DurabilityModel.EquipDurabilityModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "IPrimitiveData<int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Value = 0x4961000; // "public int get_Value()"
            inline constexpr std::uintptr_t set_Value = 0x4961050; // "public void set_Value(int value)"
        }
    } // namespace EquipDurabilityModel

    namespace EquipExtensions { // "Models.Utils.Extensions.EquipExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t ValidateItem = 0x3956750; // "public static bool ValidateItem(EquipSlotDescription equipSlot, InventoryItemDescription item)"
            inline constexpr std::uintptr_t TryFindEquipSlot = 0x39564C0; // "public static bool TryFindEquipSlot(IEquipSlotsModel equipSlotsModel, InventoryItemDescription item, PickupLootResult pickupLootResult)"
        }
    } // namespace EquipExtensions

    namespace EquipItemActionModel { // "Models.Inventory.ItemActionModel.EquipItemActionModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t slot = 0x10; // "EquipSlotDescription"
            inline constexpr std::uintptr_t ammoModel = 0x18; // "IAmmoModel"
            inline constexpr std::uintptr_t slotModel = 0x20; // "IEquipSlotModel"
            inline constexpr std::uintptr_t equipSlotsDelays = 0x28; // "EquipSlotsDelaysModel"
            inline constexpr std::uintptr_t quickSlots = 0x30; // "QuickSlotsModel"
            inline constexpr std::uintptr_t selectedQuickSlot = 0x38; // "SelectedQuickSlotModel"
            inline constexpr std::uintptr_t quickSlotSelectProgress = 0x40; // "QuickSlotSelectProgressModel"
            inline constexpr std::uintptr_t prolongedInteractionModel = 0x48; // "ProlongedInteractionModel"
            inline constexpr std::uintptr_t inventory = 0x50; // "IInventoryModel"
            inline constexpr std::uintptr_t pockets = 0x58; // "IPocketsModel"
            inline constexpr std::uintptr_t contextMenuUseItemModel = 0x60; // "ContextMenuUseItemModel"
            inline constexpr std::uintptr_t inventoryUseItemModel = 0x68; // "InventoryUseItemModel"
            inline constexpr std::uintptr_t weaponReloadModel = 0x70; // "WeaponReloadModel"
            inline constexpr std::uintptr_t reloadParamsModel = 0x78; // "ReloadParamsModel"
            inline constexpr std::uintptr_t itemInHandsModel = 0x80; // "ItemInHandsModel"
            inline constexpr std::uintptr_t itemActionProcessModel = 0x88; // "ItemActionProcessModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_SlotModel = 0x7AB150; // "public IEquipSlotModel get_SlotModel()"
            inline constexpr std::uintptr_t get_InventoryModel = 0x8B1A30; // "public IInventoryModel get_InventoryModel()"
            inline constexpr std::uintptr_t get_PocketsModel = 0x8B1A20; // "public IPocketsModel get_PocketsModel()"
            inline constexpr std::uintptr_t TrySet = 0x4A46AF0; // "public bool TrySet(IEquipSlotsModel equipSlotsModel, IEquipAmmoModel equipAmmoModel, EquipSlotDescription slot, QuickSlotsModel quickSlots, SelectedQuickSlotModel selectedQuickSlot, QuickSlotSelectProgressModel quickSlotSelectProgress, ProlongedInteractionModel prolongedInteractionModel, IInventoryModel inventory, IPocketsModel pockets, ContextMenuUseItemModel contextMenuUseItemModel, InventoryUseItemModel inventoryUseItemModel, WeaponReloadModel weaponReloadModel, ReloadParamsModel reloadParamsModel, ItemInHandsModel itemInHandsModel, ItemActionProcessModel itemActionProcessModel, EquipSlotsDelaysModel equipSlotsDelays)"
            inline constexpr std::uintptr_t CheckSet = 0x4A45FF0; // "public bool CheckSet(InventoryItemDescription item, int count, int ammo, int durability, int cumulativePoints, out bool isSet)"
            inline constexpr std::uintptr_t CheckMoveTo = 0x4A45F50; // "public bool CheckMoveTo(InventoryItemDescription item, int count, int ammo, int durability, int cumulativePoints, IItemActionModel fromModel, out bool isSet)"
            inline constexpr std::uintptr_t CheckMoveFrom = 0x4A45D70; // "public bool CheckMoveFrom(int count, out InventoryItemDescription item, out int ammo, out int durability, out int cumulativePoints, out bool isUnset)"
            inline constexpr std::uintptr_t CheckUnset = 0x4A463A0; // "public bool CheckUnset()"
            inline constexpr std::uintptr_t CheckUnequipBackpack = 0x4A46150; // "private bool CheckUnequipBackpack()"
            inline constexpr std::uintptr_t CheckUnequipBelt = 0x4A46260; // "private bool CheckUnequipBelt()"
            inline constexpr std::uintptr_t CheckSwap = 0x4A46090; // "public bool CheckSwap(InventoryItemDescription item, int count, int ammo, int durability, int cumulativePoints)"
            inline constexpr std::uintptr_t TryGetContent = 0x4A467F0; // "public bool TryGetContent(out InventoryItemDescription item, out int count, out int ammo, out int durability, out int cumulativePoints)"
            inline constexpr std::uintptr_t AreEqual = 0x4A45C40; // "public bool AreEqual(IItemActionModel other)"
            inline constexpr std::uintptr_t Set = 0x4A465E0; // "public void Set(long now, InventoryItemDescription item, int count, int ammo, int durability, int cumulativePoints)"
            inline constexpr std::uintptr_t Unset = 0x4A46CF0; // "public void Unset()"
            inline constexpr std::uintptr_t ChangeStack = 0x4A45D30; // "public void ChangeStack(int count)"
            inline constexpr std::uintptr_t ChangeAmmo = 0x4A45CC0; // "public void ChangeAmmo(int ammo)"
            inline constexpr std::uintptr_t MarkSelectedQuickSlotItemChanged = 0x4A465B0; // "private void MarkSelectedQuickSlotItemChanged()"
            inline constexpr std::uintptr_t IsSelectedSlot = 0x4A46520; // "private bool IsSelectedSlot()"
            inline constexpr std::uintptr_t IsRememberedSlot = 0x4A46480; // "private bool IsRememberedSlot()"
            inline constexpr std::uintptr_t StopReload = 0x4A46780; // "private void StopReload()"
            inline constexpr std::uintptr_t get_IsInventoryItemUsing = 0x4A46E80; // "private bool get_IsInventoryItemUsing()"
            inline constexpr std::uintptr_t get_IsRepairingVest = 0x4A46F10; // "private bool get_IsRepairingVest()"
            inline constexpr std::uintptr_t TryGetUsedItem = 0x4A469A0; // "private bool TryGetUsedItem(out InventoryItemDescription item)"
            inline constexpr std::uintptr_t get_IsSlotBusy = 0x4A47140; // "public bool get_IsSlotBusy()"
            inline constexpr std::uintptr_t CheckUnloadAmmo = 0x4A46350; // "public bool CheckUnloadAmmo(long now)"
        }
    } // namespace EquipItemActionModel

    namespace EquipItemModel { // "Models.Models.InventoryItemModel.EquipItemModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "IPrimitiveData<InventoryItemDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Value = 0x492DA00; // "public InventoryItemDescription get_Value()"
            inline constexpr std::uintptr_t set_Value = 0x492DA50; // "public void set_Value(InventoryItemDescription value)"
            inline constexpr std::uintptr_t get_IsEmpty = 0x492D9A0; // "public bool get_IsEmpty()"
        }
    } // namespace EquipItemModel

    namespace EquipItemMoveContext { // "Game.Battle.Inventory.EquipItemMoveContext (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t AmmoModel = 0x10; // "IEquipAmmoModel"
            inline constexpr std::uintptr_t Slot = 0x18; // "IEquipSlotModel"
            inline constexpr std::uintptr_t EmptyInventorySlotDescription = 0x20; // "InventorySlotDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_ItemModel = 0xA0DC20; // "public IInventoryItemModel get_ItemModel()"
            inline constexpr std::uintptr_t get_RevealContainerModel = 0xA0DC70; // "public IRevealContainerModel get_RevealContainerModel()"
            inline constexpr std::uintptr_t get_Revealed = 0x7D5050; // "public bool get_Revealed()"
            inline constexpr std::uintptr_t get_Count = 0x7E2F30; // "public int get_Count()"
            inline constexpr std::uintptr_t get_Ammo = 0xA0DAD0; // "public int get_Ammo()"
            inline constexpr std::uintptr_t get_Durability = 0xA0DBB0; // "public int get_Durability()"
            inline constexpr std::uintptr_t get_CumulativePoints = 0x7E3AB0; // "public int get_CumulativePoints()"
        }
    } // namespace EquipItemMoveContext

    namespace EquipmentDelayLockUpdater { // "Game.Battle.Inventory.EquipmentDelayLockUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t updater = 0x10; // "IUpdater"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA0DD80; // "public void Update()"
        }
    } // namespace EquipmentDelayLockUpdater

    namespace EquipmentDragAndDropHoverUpdater { // "Game.Battle.Inventory.EquipmentDragAndDropHoverUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x20; // "InventoryDragAndDropModel"
            inline constexpr std::uintptr_t equipsUiView = 0x28; // "EquipsUiView"
            inline constexpr std::uintptr_t equipItemContexts = 0x30; // "EquipItemMoveContext[]"
            inline constexpr std::uintptr_t hover = 0x38; // "IItemMoveContext"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0x9FA8F0; // "public EquipmentDragAndDropHoverUpdater Init(InventoryDragAndDropModel model, EquipsUiView equipsUiView, EquipItemMoveContext[] equipItemContexts)"
            inline constexpr std::uintptr_t Dispose = 0x9F4BF0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0x9FA960; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace EquipmentDragAndDropHoverUpdater

    namespace EquipmentSlotGlowUpdater { // "Game.Battle.Inventory.EquipmentSlotGlowUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t slotModel = 0x20; // "IEquipSlotModel"
            inline constexpr std::uintptr_t view = 0x28; // "InventoryItemView"
            inline constexpr std::uintptr_t inventoryDragAndDropModel = 0x30; // "InventoryDragAndDropModel"
            inline constexpr std::uintptr_t equipItemMoveContext = 0x38; // "IItemMoveContext"
            inline constexpr std::uintptr_t useItemsRule = 0x40; // "UseItemsRule"
            inline constexpr std::uintptr_t blockedSlotsModel = 0x48; // "BlockedSlotsModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA0E700; // "public EquipmentSlotGlowUpdater Init(IEquipSlotModel slotModel, InventoryItemView view, InventoryDragAndDropModel inventoryDragAndDropModel, IItemMoveContext equipItemMoveContext, UseItemsRule useItemsRule, BlockedSlotsModel blockedSlotsModel)"
            inline constexpr std::uintptr_t Dispose = 0xA0E680; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA0E7E0; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t CanSetEquip = 0xA0E520; // "private bool CanSetEquip(IItemMoveContext fromContext)"
            inline constexpr std::uintptr_t IsPassedAllRequirements = 0xA0E790; // "private bool IsPassedAllRequirements(IItemMoveContext fromContext)"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace EquipmentSlotGlowUpdater

    namespace EquipmentSlotModelUpdater { // "Game.Battle.Inventory.EquipmentSlotModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t slotModel = 0x20; // "IEquipSlotModel"
            inline constexpr std::uintptr_t inventoryModels = 0x28; // "InventoryModels"
            inline constexpr std::uintptr_t itemMoveContext = 0x30; // "IItemMoveContext"
            inline constexpr std::uintptr_t view = 0x38; // "InventoryItemView"
            inline constexpr std::uintptr_t isEmpty = 0x40; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA0EAD0; // "public EquipmentSlotModelUpdater Init(IEquipSlotModel slotModel, InventoryModels inventoryModels, InventoryItemView view, IItemMoveContext itemMoveContext)"
            inline constexpr std::uintptr_t Dispose = 0xA0E9E0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA0EBF0; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace EquipmentSlotModelUpdater

    namespace EquipmentSlotViewDescription { // "Game.Battle.Inventory.EquipmentSlotViewDescription (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Identified = 0x10; // "IdentifiedProperty<EquipSlotDescription>"
            inline constexpr std::uintptr_t MiniTooltipTitle = 0x18; // "LocalizedString"
            inline constexpr std::uintptr_t MiniTooltipDescription = 0x20; // "LocalizedString"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Id = 0xA0EDE0; // "public string get_Id()"
        }
    } // namespace EquipmentSlotViewDescription

    namespace EquipPresetDescription { // "Models.References.Inventory.EquipPresetDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x8184710; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace Fields {
            inline constexpr std::uintptr_t Backpack = 0x10; // "InventoryItemDescription"
            inline constexpr std::uintptr_t Vest = 0x18; // "InventoryItemDescription"
            inline constexpr std::uintptr_t Belt = 0x20; // "InventoryItemDescription"
            inline constexpr std::uintptr_t Pockets = 0x28; // "IReadOnlyDictionary<PocketSlotDescription, InventoryItemWithAmount>"
            inline constexpr std::uintptr_t InventoryItems = 0x30; // "IReadOnlyList<InventoryItemWithAmount>"
        }
        namespace StaticFields {
            inline constexpr std::uintptr_t Items = 0x0; // "List<EquipPresetDescription>"
            inline constexpr std::uintptr_t DevelopStartEquip = 0x8; // "EquipPresetDescription"
            inline constexpr std::uintptr_t RespawnEquip = 0x10; // "EquipPresetDescription"
            inline constexpr std::uintptr_t PlaytestStartEquip = 0x18; // "EquipPresetDescription"
            inline constexpr std::uintptr_t PlaytestRespawnEquip = 0x20; // "EquipPresetDescription"
            inline constexpr std::uintptr_t ProductionStartEquip = 0x28; // "EquipPresetDescription"
            inline constexpr std::uintptr_t ProductionRespawnEquip = 0x30; // "EquipPresetDescription"
            inline constexpr std::uintptr_t PerformanceStartEquip = 0x38; // "EquipPresetDescription"
            inline constexpr std::uintptr_t PerformanceRespawnEquip = 0x40; // "EquipPresetDescription"
        }
    } // namespace EquipPresetDescription

    namespace EquipRestrictedShadowUpdater { // "Game.Battle.Inventory.RestrictedCells.EquipRestrictedShadowUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t restrictedCellsModel = 0x20; // "RestrictedCellsModel"
            inline constexpr std::uintptr_t equipSlotModel = 0x28; // "IEquipSlotModel"
            inline constexpr std::uintptr_t restrictedShadowPool = 0x30; // "PooledLoadedComponentContent<Transform>"
            inline constexpr std::uintptr_t parent = 0x38; // "Transform"
            inline constexpr std::uintptr_t restrictedShadowContent = 0x40; // "IDisposableContent<Transform>"
            inline constexpr std::uintptr_t isActive = 0x48; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA5C040; // "public EquipRestrictedShadowUpdater Init(RestrictedCellsModel restrictedCellsModel, IEquipSlotModel equipSlotModel, PooledLoadedComponentContent<Transform> restrictedShadowPool, Transform parent)"
            inline constexpr std::uintptr_t Dispose = 0xA5BF40; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA5C160; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t GenerateRestrictedShadow = 0xA5BFE0; // "private void GenerateRestrictedShadow()"
            inline constexpr std::uintptr_t DisposeRestrictedShadow = 0xA5BEE0; // "private void DisposeRestrictedShadow()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace EquipRestrictedShadowUpdater

    namespace EquipSellItemMessage { // "Models.Messages.Inventory.Sell.EquipSellItemMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t entityId = 0x20; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t slot = 0x28; // "IPrimitiveData<EquipSlotDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_TraderEntityId = 0x4A1EDB0; // "public override int get_TraderEntityId()"
            inline constexpr std::uintptr_t get_Slot = 0x4A1ED60; // "public EquipSlotDescription get_Slot()"
            inline constexpr std::uintptr_t get_Type = 0x4A1EE00; // "public override string get_Type()"
        }
    } // namespace EquipSellItemMessage

    namespace EquipSlotData { // "Models.Data.EquipSlotData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Item = 0x20; // "IPrimitiveData<InventoryItemDescription>"
            inline constexpr std::uintptr_t Durability = 0x28; // "IPrimitiveData<int>"
        }
    } // namespace EquipSlotData

    namespace EquipSlotDelayDescription { // "Models.References.Inventory.EquipSlotDelayDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x8184A40; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace Fields {
            inline constexpr std::uintptr_t DelayTime = 0x20; // "long"
        }
        namespace StaticFields {
            inline constexpr std::uintptr_t NoDelayValue = 0x0; // "long"
            inline constexpr std::uintptr_t enum_id = 0x8; // "Enum<EquipSlotDelayDescription>"
            inline constexpr std::uintptr_t PrimaryWeapon = 0x10; // "EquipSlotDelayDescription"
            inline constexpr std::uintptr_t SecondaryWeapon = 0x18; // "EquipSlotDelayDescription"
            inline constexpr std::uintptr_t Vest = 0x20; // "EquipSlotDelayDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Enum = 0x43E6230; // "public static ReadOnlyEnum<EquipSlotDelayDescription> get_Enum()"
        }
    } // namespace EquipSlotDelayDescription

    namespace EquipSlotDescription { // "Models.References.Inventory.EquipSlotDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x8184BD8; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace Fields {
            inline constexpr std::uintptr_t EquipSlotType = 0x20; // "EquipSlotType"
            inline constexpr std::uintptr_t WeaponsFilterLazy = 0x28; // "Lazy<HashSet<AmmoDescription>>"
            inline constexpr std::uintptr_t EquipAmmoOrArmorSlot = 0x30; // "EquipAmmoOrArmorSlotDescription"
            inline constexpr std::uintptr_t DelayDescription = 0x38; // "EquipSlotDelayDescription"
            inline constexpr std::uintptr_t HasEquipDelay = 0x40; // "bool"
            inline constexpr std::uintptr_t HasAmmo = 0x41; // "bool"
            inline constexpr std::uintptr_t HasArmor = 0x42; // "bool"
            inline constexpr std::uintptr_t HasArmorOrAmmo = 0x43; // "bool"
        }
        namespace StaticFields {
            inline constexpr std::uintptr_t enum_id = 0x0; // "Enum<EquipSlotDescription>"
            inline constexpr std::uintptr_t Vest = 0x8; // "EquipSlotDescription"
            inline constexpr std::uintptr_t Backpack = 0x10; // "EquipSlotDescription"
            inline constexpr std::uintptr_t Belt = 0x18; // "EquipSlotDescription"
            inline constexpr std::uintptr_t Weapon0 = 0x20; // "EquipSlotDescription"
            inline constexpr std::uintptr_t Weapon1 = 0x28; // "EquipSlotDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Enum = 0x43E6DF0; // "public static ReadOnlyEnum<EquipSlotDescription> get_Enum()"
            inline constexpr std::uintptr_t get_WeaponsFilter = 0x43E6F40; // "public HashSet<AmmoDescription> get_WeaponsFilter()"
        }
    } // namespace EquipSlotDescription

    namespace EquipSlotModel { // "Models.Models.EquipSlotModel.EquipSlotModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Description = 0x10; // "EquipSlotDescription"
            inline constexpr std::uintptr_t ItemModel = 0x18; // "IInventoryItemModel"
            inline constexpr std::uintptr_t DurabilityModel = 0x20; // "IDurabilityModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsBroken = 0x49611A0; // "public bool get_IsBroken()"
        }
    } // namespace EquipSlotModel

    namespace EquipSlotsDelaysModel { // "Models.Models.EquipSlotsDelays.EquipSlotsDelaysModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "EquipSlotsDelaysData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Set = 0x49612F0; // "public void Set(long now, EquipSlotDelayDescription description)"
            inline constexpr std::uintptr_t Unset = 0x4961380; // "public void Unset(EquipSlotDelayDescription description)"
            inline constexpr std::uintptr_t IsDelayActive = 0x4961270; // "public bool IsDelayActive(long now, EquipSlotDelayDescription description)"
            inline constexpr std::uintptr_t GetDelayEndTs = 0x4961200; // "public long GetDelayEndTs(EquipSlotDelayDescription description)"
        }
    } // namespace EquipSlotsDelaysModel

    namespace EquipSlotsUtils { // "Models.Models.EquipSlots.EquipSlotsUtils (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t IsEquipSlotDelayActive = 0x4961580; // "public static bool IsEquipSlotDelayActive(long now, EquipSlotDescription equipSlotDescription, EquipSlotsDelaysModel equipSlotsDelays)"
        }
    } // namespace EquipSlotsUtils

    namespace EquipSlotType { // "Models.References.Inventory.EquipSlotType (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x8184F08; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t Vest = 0x0; // "EquipSlotType"
            inline constexpr std::uintptr_t Backpack = 0x8; // "EquipSlotType"
            inline constexpr std::uintptr_t Belt = 0x10; // "EquipSlotType"
            inline constexpr std::uintptr_t Weapon = 0x18; // "EquipSlotType"
        }
    } // namespace EquipSlotType

    namespace EquipSlotView { // "Game.Battle.Inventory.Slot.EquipSlotView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t emptyIcon = 0x20; // "ImageExtend"
            inline constexpr std::uintptr_t emptyBack = 0x28; // "Image"
            inline constexpr std::uintptr_t lockIcon = 0x30; // "ImageExtend"
            inline constexpr std::uintptr_t emptyIconEnabled = 0x38; // "Nullable<bool>"
            inline constexpr std::uintptr_t emptyBackEnabled = 0x3A; // "Nullable<bool>"
            inline constexpr std::uintptr_t lockIconEnabled = 0x3C; // "Nullable<bool>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetIcon = 0xA768A0; // "public void SetIcon()"
            inline constexpr std::uintptr_t SetEmpty = 0xA76880; // "public void SetEmpty()"
            inline constexpr std::uintptr_t SetLock = 0xA768C0; // "public void SetLock()"
            inline constexpr std::uintptr_t UpdateEnabled = 0xA768E0; // "private void UpdateEnabled(bool emptyIconEnabled, bool emptyBackEnabled, bool lockIconEnabled)"
        }
    } // namespace EquipSlotView

    namespace EquipsUiView { // "Game.Battle.Inventory.EquipsUiView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t weaponFirstView = 0x20; // "InventoryItemView"
            inline constexpr std::uintptr_t weaponSecondView = 0x28; // "InventoryItemView"
            inline constexpr std::uintptr_t tacticalVestView = 0x30; // "InventoryItemView"
            inline constexpr std::uintptr_t backpackView = 0x38; // "InventoryItemView"
            inline constexpr std::uintptr_t beltView = 0x40; // "InventoryItemView"
            inline constexpr std::uintptr_t weaponFirstDropAreaView = 0x48; // "DropAreaView"
            inline constexpr std::uintptr_t weaponSecondDropAreaView = 0x50; // "DropAreaView"
            inline constexpr std::uintptr_t tacticalVestDropAreaView = 0x58; // "DropAreaView"
            inline constexpr std::uintptr_t backpackDropAreaView = 0x60; // "DropAreaView"
            inline constexpr std::uintptr_t beltDropAreaView = 0x68; // "DropAreaView"
            inline constexpr std::uintptr_t slots = 0x70; // "Dictionary<EquipSlotDescription, ValueTuple<InventoryItemView, DropAreaView>>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t GetView = 0xA0EE80; // "public InventoryItemView GetView(EquipSlotDescription description)"
            inline constexpr std::uintptr_t GetDropAreaView = 0xA0EE20; // "public DropAreaView GetDropAreaView(EquipSlotDescription description)"
        }
    } // namespace EquipsUiView

    namespace EquipUnloadAmmoMessage { // "Models.Messages.Inventory.UnloadAmmo.EquipUnloadAmmoMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t slot = 0x20; // "IPrimitiveData<EquipSlotDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Slot = 0x4A1F0C0; // "public EquipSlotDescription get_Slot()"
            inline constexpr std::uintptr_t get_Type = 0x4A1F110; // "public override string get_Type()"
        }
    } // namespace EquipUnloadAmmoMessage

    namespace ExternalInventoryCloseOnEmptyUpdater { // "Game.Battle.Inventory.ExternalInventoryCloseOnEmptyUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t busySlotsModel = 0x20; // "BusySlotsModel"
            inline constexpr std::uintptr_t dialogModel = 0x28; // "InventoryDialogModel"
            inline constexpr std::uintptr_t wasEmptyWhenOpened = 0x30; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0x9FABD0; // "public ExternalInventoryCloseOnEmptyUpdater Init(InventoryDialogModel dialogModel, BusySlotsModel busySlotsModel)"
            inline constexpr std::uintptr_t Dispose = 0x92B5C0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0x9FAC30; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace ExternalInventoryCloseOnEmptyUpdater

    namespace ExternalInventoryCloseOnLostBattleEntityUpdater { // "Game.Battle.Inventory.ExternalInventoryCloseOnLostBattleEntityUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleEntitiesModel = 0x20; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t dialogModel = 0x28; // "IScreenModel"
            inline constexpr std::uintptr_t entityId = 0x30; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0x9FAC70; // "public ExternalInventoryCloseOnLostBattleEntityUpdater Init(IBattleEntitiesModel battleEntitiesModel, IScreenModel dialogModel, int entityId)"
            inline constexpr std::uintptr_t Dispose = 0x92B5C0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0x9FACC0; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace ExternalInventoryCloseOnLostBattleEntityUpdater

    namespace ExternalInventoryExtension { // "Game.Battle.Inventory.ExternalInventoryExtension (Battle.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x818F658; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t defaultAllowed = 0x0; // "Func<InventoryItemDescription, bool>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t GetIsItemAllowedFunc = 0xA2BC40; // "public static Func<InventoryItemDescription, bool> GetIsItemAllowedFunc(WorldEntitiesModel worldEntitiesModel, ExternalItemMoveContext context)"
            inline constexpr std::uintptr_t GetIsItemAllowedFunc_2 = 0xA2BCB0; // "public static Func<InventoryItemDescription, bool> GetIsItemAllowedFunc(WorldEntitiesModel worldEntitiesModel, CurrentInventoryModel inventoryModel)"
            inline constexpr std::uintptr_t GetIsItemAllowedFunc_3 = 0xA2BE10; // "private static Func<InventoryItemDescription, bool> GetIsItemAllowedFunc(WorldEntitiesModel worldEntitiesModel, int entityId)"
            inline constexpr std::uintptr_t DefaultIsItemAllowed = 0x7D5050; // "public static bool DefaultIsItemAllowed(InventoryItemDescription itemDescription)"
        }
    } // namespace ExternalInventoryExtension

    namespace ExternalInventoryItemActionModel { // "Models.Inventory.ItemActionModel.ExternalInventoryItemActionModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t inventoryModel = 0x10; // "IInventoryModel"
            inline constexpr std::uintptr_t slotModel = 0x18; // "IInventorySlotModel"
            inline constexpr std::uintptr_t isTakeOnly = 0x20; // "bool"
            inline constexpr std::uintptr_t isItemAllowedFunc = 0x28; // "Func<InventoryItemDescription, bool>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_SlotModel = 0x7E7130; // "public IInventorySlotModel get_SlotModel()"
            inline constexpr std::uintptr_t get_InventoryModel = 0x7EC6B0; // "public IInventoryModel get_InventoryModel()"
            inline constexpr std::uintptr_t get_IsTakeOnly = 0x858ED0; // "public bool get_IsTakeOnly()"
            inline constexpr std::uintptr_t TrySet = 0x4A47C60; // "public bool TrySet(IInventoryModel inventoryModel, InventorySlotDescription slot, bool isTakeOnly, Func<InventoryItemDescription, bool> isItemAllowedFunc)"
            inline constexpr std::uintptr_t CheckSet = 0x4A477B0; // "public bool CheckSet(InventoryItemDescription item, int count, int ammo, int durability, int cumulativePoints, out bool isSet)"
            inline constexpr std::uintptr_t CheckMoveTo = 0x4A475F0; // "public bool CheckMoveTo(InventoryItemDescription item, int count, int ammo, int durability, int cumulativePoints, IItemActionModel fromModel, out bool isSet)"
            inline constexpr std::uintptr_t CheckMoveFrom = 0x4A47430; // "public bool CheckMoveFrom(int count, out InventoryItemDescription item, out int ammo, out int durability, out int cumulativePoints, out bool isUnset)"
            inline constexpr std::uintptr_t CheckUnset = 0x4A478F0; // "public bool CheckUnset()"
            inline constexpr std::uintptr_t CheckSwap = 0x4A478B0; // "public bool CheckSwap(InventoryItemDescription item, int count, int ammo, int durability, int cumulativePoints)"
            inline constexpr std::uintptr_t TryGetContent = 0x4A47A60; // "public bool TryGetContent(out InventoryItemDescription item, out int count, out int ammo, out int durability, out int cumulativePoints)"
            inline constexpr std::uintptr_t AreEqual = 0x4A472B0; // "public bool AreEqual(IItemActionModel other)"
            inline constexpr std::uintptr_t Set = 0x4A479D0; // "public void Set(long now, InventoryItemDescription item, int count, int ammo, int durability, int cumulativePoints)"
            inline constexpr std::uintptr_t Unset = 0x4A47E80; // "public void Unset()"
            inline constexpr std::uintptr_t ChangeStack = 0x4A47390; // "public void ChangeStack(int count)"
            inline constexpr std::uintptr_t ChangeAmmo = 0x4A47350; // "public void ChangeAmmo(int ammo)"
            inline constexpr std::uintptr_t get_IsSlotBusy = 0x7EC9F0; // "public bool get_IsSlotBusy()"
            inline constexpr std::uintptr_t CheckUnloadAmmo = 0x7EC9F0; // "public bool CheckUnloadAmmo(long now)"
            inline constexpr std::uintptr_t IsItemAllowed = 0x4A479A0; // "public bool IsItemAllowed(InventoryItemDescription item)"
        }
    } // namespace ExternalInventoryItemActionModel

    namespace ExternalItemMoveContext { // "Game.Battle.Inventory.ExternalItemMoveContext (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t EntityId = 0x10; // "int"
            inline constexpr std::uintptr_t Inventory = 0x18; // "IInventoryModel"
            inline constexpr std::uintptr_t Slot = 0x20; // "IInventorySlotModel"
            inline constexpr std::uintptr_t RevealContainerModel = 0x28; // "IRevealContainerModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_ItemModel = 0xA0F410; // "public IInventoryItemModel get_ItemModel()"
            inline constexpr std::uintptr_t get_Revealed = 0xA0B9B0; // "public bool get_Revealed()"
            inline constexpr std::uintptr_t get_Count = 0xA0F2C0; // "public int get_Count()"
            inline constexpr std::uintptr_t get_Ammo = 0xA0F250; // "public int get_Ammo()"
            inline constexpr std::uintptr_t get_Durability = 0xA0F3A0; // "public int get_Durability()"
            inline constexpr std::uintptr_t get_CumulativePoints = 0xA0F330; // "public int get_CumulativePoints()"
        }
    } // namespace ExternalItemMoveContext

    namespace ExternalRestrictedCellsModelUpdater { // "Game.Battle.Inventory.RestrictedCells.ExternalRestrictedCellsModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t worldEntitiesModel = 0x30; // "WorldEntitiesModel"
            inline constexpr std::uintptr_t currentInventoryModel = 0x38; // "CurrentInventoryModel"
            inline constexpr std::uintptr_t isItemAllowed = 0x40; // "Func<InventoryItemDescription, bool>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA5C2F0; // "public ExternalRestrictedCellsModelUpdater Init(BattleCharacterModel battleCharacterModel, WorldEntitiesModel worldEntitiesModel, RestrictedCellsModel restrictedCellsModel, CurrentInventoryModel currentInventoryModel)"
            inline constexpr std::uintptr_t Dispose = 0x9F4BF0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t GetIsActive = 0xA5C250; // "protected override bool GetIsActive(IInventoryItemModel itemModel)"
        }
    } // namespace ExternalRestrictedCellsModelUpdater

    namespace ExternalRestrictedItemViewUpdater { // "Game.Battle.Inventory.RestrictedCells.ExternalRestrictedItemViewUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t messageView = 0x20; // "InventoryDropMessageView"
            inline constexpr std::uintptr_t dragAndDropModel = 0x28; // "InventoryDragAndDropModel"
            inline constexpr std::uintptr_t worldEntitiesModel = 0x30; // "WorldEntitiesModel"
            inline constexpr std::uintptr_t currentInventoryModel = 0x38; // "CurrentInventoryModel"
            inline constexpr std::uintptr_t battleCharacterModel = 0x40; // "BattleCharacterModel"
            inline constexpr std::uintptr_t isMessageActive = 0x48; // "Nullable<bool>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA5C3D0; // "public ExternalRestrictedItemViewUpdater Init(InventoryDropMessageView messageView, InventoryDragAndDropModel dragAndDropModel, WorldEntitiesModel worldEntitiesModel, CurrentInventoryModel currentInventoryModel, BattleCharacterModel battleCharacterModel)"
            inline constexpr std::uintptr_t Dispose = 0xA123B0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA5C460; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace ExternalRestrictedItemViewUpdater

    namespace FastMoveOnClick { // "Game.Battle.Inventory.FastMoveOnClick (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleEntitiesModel = 0x10; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t currentInventoryModel = 0x18; // "CurrentInventoryModel"
            inline constexpr std::uintptr_t inventoryModels = 0x20; // "InventoryModels"
            inline constexpr std::uintptr_t personalNotificationModel = 0x28; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t notificationError = 0x30; // "NotificationError"
            inline constexpr std::uintptr_t localization = 0x38; // "LocalizationKeys"
            inline constexpr std::uintptr_t tooltipModel = 0x40; // "TooltipModel"
            inline constexpr std::uintptr_t lastSentContext = 0x48; // "IItemMoveContext"
            inline constexpr std::uintptr_t lastSentItem = 0x50; // "InventoryItemDescription"
            inline constexpr std::uintptr_t lastSentItemCount = 0x58; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_HasLastSentContext = 0xA10610; // "public bool get_HasLastSentContext()"
            inline constexpr std::uintptr_t Init = 0xA10390; // "public void Init(IBattleEntitiesModel battleEntitiesModel, CurrentInventoryModel currentInventoryModel, InventoryModels inventoryModels, PersonalNotificationModel personalNotificationModel, NotificationError notificationError, LocalizationKeys localization, TooltipModel tooltipModel)"
            inline constexpr std::uintptr_t Clear = 0xA0F460; // "public void Clear()"
            inline constexpr std::uintptr_t IsLastSent = 0xA10430; // "public bool IsLastSent(IItemMoveContext context)"
            inline constexpr std::uintptr_t TryRepeatLastFastMove = 0xA104A0; // "public void TryRepeatLastFastMove(BlockedSlotsModel blockedSlotsModel)"
            inline constexpr std::uintptr_t FastMove = 0xA0F550; // "public void FastMove(IItemMoveContext context)"
            inline constexpr std::uintptr_t ShowNotification = 0xA10440; // "private void ShowNotification(NotificationError.Type errorType)"
            inline constexpr std::uintptr_t DiscardTooltip = 0xA0F510; // "private void DiscardTooltip()"
        }
    } // namespace FastMoveOnClick

    namespace FinalizeSellDealMessage { // "Models.Messages.Inventory.Sell.FinalizeSellDealMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t entityId = 0x20; // "IPrimitiveData<int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_BuyerEntityId = 0x4A1F810; // "public int get_BuyerEntityId()"
            inline constexpr std::uintptr_t get_Type = 0x4A1F860; // "public override string get_Type()"
        }
    } // namespace FinalizeSellDealMessage

    namespace FinishEquipDelaySystem { // "Models.Systems.FinishEquipDelaySystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t characters = 0x38; // "ReadOnly.Dictionary<int, BattleCharacterModel>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x40F62C0; // "protected override void Tick(ITick tick)"
            inline constexpr std::uintptr_t TryGetEquipSlotWithFinishedDelay = 0x40F64B0; // "private static bool TryGetEquipSlotWithFinishedDelay(EquipSlotsDelaysModel equipSlotsDelaysModel, long now, long nextTickTs, out EquipSlotDescription resultEquipSlotDescription)"
        }
    } // namespace FinishEquipDelaySystem

    namespace FinishInventoryUseItemSystem { // "Models.Systems.FinishInventoryUseItemSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t analyticsModel = 0x38; // "IBattleSystemsAnalyticsModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x40F6A60; // "protected override void Tick(ITick tick)"
            inline constexpr std::uintptr_t RestoreArmor = 0x40F6740; // "private void RestoreArmor(UsableItemDescription usableItem, InventoryUseItemModel inventoryUseItem, IInventoryModel inventory, IEquipSlotsModel equipSlots, IEquipAmmoModel equipAmmo)"
        }
    } // namespace FinishInventoryUseItemSystem

    namespace FinishQuickSlotSelectionSystem { // "Models.Systems.FinishQuickSlotSelectionSystem (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x40F7290; // "protected override void Tick(ITick tick)"
        }
    } // namespace FinishQuickSlotSelectionSystem

    namespace FromBuilderToInventoryMessage { // "Models.Messages.Builder.FromBuilderToInventoryMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t entityId = 0x20; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t slot = 0x28; // "IPrimitiveData<InventorySlotDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_EntityId = 0x4A1FE00; // "public int get_EntityId()"
            inline constexpr std::uintptr_t get_InventorySlotDescription = 0x4A1FE50; // "public InventorySlotDescription get_InventorySlotDescription()"
            inline constexpr std::uintptr_t get_Type = 0x4A1FEA0; // "public override string get_Type()"
        }
    } // namespace FromBuilderToInventoryMessage

    namespace FromDefenseModuleSlotToInventoryMessage { // "Models.Messages.PlotBuildingDefenseSlot.FromDefenseModuleSlotToInventoryMessage (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x4A07C40; // "public override string get_Type()"
        }
    } // namespace FromDefenseModuleSlotToInventoryMessage

    namespace FromEquipUnsetMessage { // "Models.Messages.Inventory.Unset.FromEquipUnsetMessage (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x4A203E0; // "public override string get_Type()"
        }
    } // namespace FromEquipUnsetMessage

    namespace FromExternalInventoryUnsetMessage { // "Models.Messages.Inventory.Unset.FromExternalInventoryUnsetMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t entityId = 0x28; // "BattleEntityIdData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t AddProperties = 0x4A20920; // "private void AddProperties()"
            inline constexpr std::uintptr_t get_EntityId = 0x4A20BC0; // "public int get_EntityId()"
            inline constexpr std::uintptr_t get_Type = 0x4A20C00; // "public override string get_Type()"
        }
    } // namespace FromExternalInventoryUnsetMessage

    namespace FromInventoryToBuilderMessage { // "Models.Messages.Builder.FromInventoryToBuilderMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t entityId = 0x20; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t slot = 0x28; // "IPrimitiveData<InventorySlotDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_EntityId = 0x4A20F90; // "public int get_EntityId()"
            inline constexpr std::uintptr_t get_InventorySlotDescription = 0x4A20FE0; // "public InventorySlotDescription get_InventorySlotDescription()"
            inline constexpr std::uintptr_t get_Type = 0x4A21030; // "public override string get_Type()"
        }
    } // namespace FromInventoryToBuilderMessage

    namespace FromInventoryToDefenseModuleSlotMessage { // "Models.Messages.PlotBuildingDefenseSlot.FromInventoryToDefenseModuleSlotMessage (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x4A08140; // "public override string get_Type()"
        }
    } // namespace FromInventoryToDefenseModuleSlotMessage

    namespace FromInventoryToSpecialModuleSlotMessage { // "Models.Messages.PlotBuildingDefenseSlot.FromInventoryToSpecialModuleSlotMessage (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x4A08260; // "public override string get_Type()"
        }
    } // namespace FromInventoryToSpecialModuleSlotMessage

    namespace FromInventoryUnsetMessage { // "Models.Messages.Inventory.Unset.FromInventoryUnsetMessage (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x4A21670; // "public override string get_Type()"
        }
    } // namespace FromInventoryUnsetMessage

    namespace FromPocketUnsetMessage { // "Models.Messages.Inventory.Unset.FromPocketUnsetMessage (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x4A21B70; // "public override string get_Type()"
        }
    } // namespace FromPocketUnsetMessage

    namespace FromSpecialModuleSlotToInventoryMessage { // "Models.Messages.PlotBuildingDefenseSlot.FromSpecialModuleSlotToInventoryMessage (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x4A08290; // "public override string get_Type()"
        }
    } // namespace FromSpecialModuleSlotToInventoryMessage

    namespace FurnitureLootData { // "Models.Data.FurnitureLoot.FurnitureLootData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t X = 0x20; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t Y = 0x28; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t Z = 0x30; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t SpawnTickIndex = 0x38; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t HasCargo = 0x40; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t OwnerPublicId = 0x48; // "IPrimitiveData<long>"
        }
    } // namespace FurnitureLootData

    namespace FurnitureLootDescription { // "Models.References.FurnitureLoot.FurnitureLootDescription (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t get_PageInventoryDescription = 0x4409240; // "public static InventoryCellsSizeDescription get_PageInventoryDescription()"
            inline constexpr std::uintptr_t get_PageCargoInventoryDescription = 0x44091E0; // "public static CargoInventoryDescription get_PageCargoInventoryDescription()"
            inline constexpr std::uintptr_t get_InteractDescription = 0x44090B0; // "public static InteractDescription get_InteractDescription()"
            inline constexpr std::uintptr_t get_InteractPosition = 0x4409140; // "public static Vector3 get_InteractPosition()"
            inline constexpr std::uintptr_t GetFurnitureLootInventoryPageEntityId = 0x4409070; // "public static int GetFurnitureLootInventoryPageEntityId(FurnitureLootEntityInventoryModel furnitureLootEntityInventoryModel, IInventoryModel inventoryModel)"
            inline constexpr std::uintptr_t GetFurnitureLootCargoInventorySlotEntityId = 0x4408F50; // "public static int GetFurnitureLootCargoInventorySlotEntityId(FurnitureLootEntityInventoryModel furnitureLootEntityInventoryModel, CargoInventoryModel cargoInventoryModel, CargoInventorySlotDescription slotDescription)"
        }
    } // namespace FurnitureLootDescription

    namespace FurnitureLootEntityInventoryData { // "Models.Data.FurnitureLoot.FurnitureLootEntityInventoryData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Name = 0x20; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t ClanTag = 0x28; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t InventoryPages = 0x30; // "DictionaryData<int, InventoryData>"
            inline constexpr std::uintptr_t CargoInventoryPages = 0x38; // "DictionaryData<int, CargoInventoryData>"
        }
    } // namespace FurnitureLootEntityInventoryData

    namespace FurnitureLootEntityInventoryModel { // "Models.Models.FurnitureLootEntityInventory.FurnitureLootEntityInventoryModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Id = 0x10; // "int"
            inline constexpr std::uintptr_t Name = 0x18; // "IPrimitiveModel<string>"
            inline constexpr std::uintptr_t ClanTag = 0x20; // "IPrimitiveModel<string>"
            inline constexpr std::uintptr_t InventoryPagesModel = 0x28; // "InventoryPagesModel"
            inline constexpr std::uintptr_t CargoInventoryPagesModel = 0x30; // "CargoInventoryPagesModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t IsEmpty = 0x49628C0; // "public bool IsEmpty()"
        }
    } // namespace FurnitureLootEntityInventoryModel

    namespace FurnitureLootEntityModel { // "Game.Battle.EntityModel.FurnitureLoot.FurnitureLootEntityModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ServerModel = 0x18; // "FurnitureLootModel"
        }
    } // namespace FurnitureLootEntityModel

    namespace FurnitureLootInventoryEntityModel { // "Game.Battle.EntityModel.FurnitureLoot.FurnitureLootInventoryEntityModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ServerModel = 0x18; // "FurnitureLootEntityInventoryModel"
        }
    } // namespace FurnitureLootInventoryEntityModel

    namespace FurnitureLootModel { // "Models.Models.FurnitureLoot.FurnitureLootModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Id = 0x10; // "int"
            inline constexpr std::uintptr_t PositionModel = 0x18; // "SetPositionModel"
            inline constexpr std::uintptr_t InteractPositionModel = 0x20; // "IPositionModel"
            inline constexpr std::uintptr_t SpawnTickIndex = 0x28; // "IPrimitiveModel<int>"
            inline constexpr std::uintptr_t HasCargo = 0x30; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t OwnerPublicId = 0x38; // "IPrimitiveModel<long>"
            inline constexpr std::uintptr_t LootChanged = 0x40; // "bool"
            inline constexpr std::uintptr_t FurnitureType = 0x48; // "IPrimitiveModel<FurnitureTypeDescription>"
            inline constexpr std::uintptr_t FurnitureId = 0x50; // "IPrimitiveModel<IIdentified>"
        }
    } // namespace FurnitureLootModel

    namespace FurnitureLootTargetActions { // "Game.Battle.Entities.FurnitureLoot.FurnitureLootTargetActions (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t inventoryEntityId = 0x10; // "int"
            inline constexpr std::uintptr_t observerRequestModel = 0x18; // "ObserverRequestModel"
            inline constexpr std::uintptr_t personalNotificationModel = 0x20; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t uiSoundModel = 0x28; // "GlobalUISoundModel"
            inline constexpr std::uintptr_t battleInputModel = 0x30; // "BattleInputModel"
            inline constexpr std::uintptr_t OpenInventoryAction = 0x38; // "TargetActionWithNotificationItem"
            inline constexpr std::uintptr_t TakeCargoAction = 0x40; // "TargetActionWithNotificationItem"
            inline constexpr std::uintptr_t MultiAction = 0x48; // "MultiTargetAction"
        }
        namespace Methods {
            inline constexpr std::uintptr_t OpenInventoryDialog = 0xB84CA0; // "private void OpenInventoryDialog()"
            inline constexpr std::uintptr_t TakeCargo = 0xB84CF0; // "private void TakeCargo()"
            inline constexpr std::uintptr_t UnavailableAction = 0x9CDF30; // "private void UnavailableAction(LocalizedString localizedString, PersonalNotificationActionIds id)"
        }
    } // namespace FurnitureLootTargetActions

    namespace FurnitureLootTargetProvider { // "Game.Battle.Entities.FurnitureLoot.FurnitureLootTargetProvider (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t targetActions = 0x20; // "FurnitureLootTargetActions"
            inline constexpr std::uintptr_t lootEntityModel = 0x28; // "FurnitureLootEntityModel"
            inline constexpr std::uintptr_t unavailableKeys = 0x30; // "UnavailableTargetActionsKeys"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x38; // "IBattleEntitiesModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t GetTargetAction = 0xB851F0; // "protected override ITargetAction GetTargetAction()"
        }
    } // namespace FurnitureLootTargetProvider

    namespace GetCashItemsCountMessage { // "Models.Messages.Inventory.GetCashItemsCountMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t traderEntityId = 0x20; // "IPrimitiveData<int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_TraderEntityId = 0x4A25220; // "public int get_TraderEntityId()"
            inline constexpr std::uintptr_t get_Type = 0x4A25270; // "public override string get_Type()"
        }
    } // namespace GetCashItemsCountMessage

    namespace GlobalItemStatsRules { // "Game.Battle.Inventory.GlobalItemStatsRules (Global.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x81BF6E8; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t args = 0x0; // "List<object>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t UpdateStatsStrings = 0x3538AB0; // "public static void UpdateStatsStrings(InventoryItemTypeViewDescription itemTypeViewDescription, List<ValueTuple<string, string, bool>> itemStatsStrings, InventoryItemDescription item, InventoryCellsSizeDescription cellsSizeDescription)"
        }
    } // namespace GlobalItemStatsRules

    namespace GroupsInventoryItemsModel { // "Game.Battle.Inventory.GroupsInventoryItemsModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ammoItemsModel = 0x10; // "AmmoItemsModel"
            inline constexpr std::uintptr_t inventoryItemCount = 0x18; // "Dictionary<InventoryItemDescription, int>"
            inline constexpr std::uintptr_t inventoryItemAmount = 0x20; // "Dictionary<InventoryItemDescription, int>"
            inline constexpr std::uintptr_t inventoryTypeCount = 0x28; // "Dictionary<InventoryItemType, int>"
            inline constexpr std::uintptr_t inventorySlotData = 0x30; // "Dictionary<IInventorySlotModel, ValueTuple<InventoryItemDescription, int>>"
            inline constexpr std::uintptr_t InventoryItemAmount = 0x38; // "ReadOnly.Dictionary<InventoryItemDescription, int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Add = 0xA2C310; // "public void Add(IInventorySlotModel slot)"
            inline constexpr std::uintptr_t AddItem = 0xA2C1F0; // "private void AddItem(InventoryItemDescription item, int amount)"
            inline constexpr std::uintptr_t AddAmountItem = 0xA2C040; // "private void AddAmountItem(InventoryItemDescription item, int amount)"
            inline constexpr std::uintptr_t AddCountItem = 0xA2C0D0; // "private void AddCountItem(InventoryItemDescription item)"
            inline constexpr std::uintptr_t AddCountType = 0xA2C160; // "private void AddCountType(InventoryItemType type)"
            inline constexpr std::uintptr_t Remove = 0xA2CA70; // "public void Remove(IInventorySlotModel slot)"
            inline constexpr std::uintptr_t RemoveItem = 0xA2C8E0; // "private void RemoveItem(InventoryItemDescription item, int amount)"
            inline constexpr std::uintptr_t RemoveAmountItem = 0xA2C690; // "private void RemoveAmountItem(InventoryItemDescription item, int amount)"
            inline constexpr std::uintptr_t RemoveCountItem = 0xA2C760; // "private void RemoveCountItem(InventoryItemDescription item)"
            inline constexpr std::uintptr_t RemoveCountType = 0xA2C820; // "private void RemoveCountType(InventoryItemType type)"
            inline constexpr std::uintptr_t HasItem = 0xA2C630; // "public bool HasItem(InventoryItemDescription item)"
            inline constexpr std::uintptr_t GetItemAmount = 0xA2C570; // "public int GetItemAmount(InventoryItemDescription item)"
            inline constexpr std::uintptr_t GetItemAmount_2 = 0xA2C5C0; // "public int GetItemAmount(AmmoDescription ammo)"
        }
    } // namespace GroupsInventoryItemsModel

    namespace GroupsInventoryItemsModelUpdater { // "Game.Battle.Inventory.GroupsInventoryItemsModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t changedSlotsModel = 0x10; // "ChangedSlotsInventoryModel"
            inline constexpr std::uintptr_t groupsInventoryItemsModel = 0x18; // "GroupsInventoryItemsModel"
            inline constexpr std::uintptr_t currentItem = 0x20; // "InventoryItemDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x9FADD0; // "public void Update()"
        }
    } // namespace GroupsInventoryItemsModelUpdater

    namespace HealItemDescription { // "Models.References.Inventory.HealItemDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Health = 0x20; // "int"
        }
    } // namespace HealItemDescription

    namespace HideObjectTargetActions { // "Game.Battle.EntityModel.Loot.HideObjectTargetActions (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t personalNotificationModel = 0x10; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x18; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t battleInputModel = 0x20; // "BattleInputModel"
            inline constexpr std::uintptr_t hideObjectDescription = 0x28; // "LocationHideObjectDescription"
            inline constexpr std::uintptr_t uiSoundModel = 0x30; // "GlobalUISoundModel"
            inline constexpr std::uintptr_t isRequesting = 0x38; // "bool"
            inline constexpr std::uintptr_t HideAndSearch = 0x40; // "ValueTuple<MultiTargetAction, TargetActionWithNotificationItem, TargetActionWithNotificationItem>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Hide = 0xC91C30; // "private void Hide()"
            inline constexpr std::uintptr_t SearchObject = 0xC91D60; // "private void SearchObject()"
            inline constexpr std::uintptr_t Unavailable = 0xC91E90; // "private void Unavailable(LocalizedString invalidNotification, PersonalNotificationActionIds id)"
        }
    } // namespace HideObjectTargetActions

    namespace HighlightedItemsModel { // "Game.Battle.Inventory.HighlightedItems.HighlightedItemsModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Slots = 0x10; // "HashSet<IInventorySlotModel>"
        }
    } // namespace HighlightedItemsModel

    namespace HighlightedItemsUpdater { // "Game.Battle.Inventory.HighlightedItems.HighlightedItemsUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t inventoryDragAndDropModel = 0x20; // "InventoryDragAndDropModel"
            inline constexpr std::uintptr_t useItemsRule = 0x28; // "UseItemsRule"
            inline constexpr std::uintptr_t itemMoveContexts = 0x30; // "List<IInventoryItemMoveContext>"
            inline constexpr std::uintptr_t highlightedItemsModel = 0x38; // "HighlightedItemsModel"
            inline constexpr std::uintptr_t isDragStarted = 0x40; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA77020; // "public HighlightedItemsUpdater Init(InventoryDragAndDropModel inventoryDragAndDropModel, UseItemsRule useItemsRule, List<IInventoryItemMoveContext> itemMoveContexts, HighlightedItemsModel highlightedItemsModel)"
            inline constexpr std::uintptr_t Dispose = 0xA76F80; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA77090; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace HighlightedItemsUpdater

    namespace HighlightedItemUpdater { // "Game.Battle.Inventory.HighlightedItems.HighlightedItemUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t highlightedItemsModel = 0x20; // "HighlightedItemsModel"
            inline constexpr std::uintptr_t pool = 0x28; // "PooledLoadedComponentContent<InventorySelectedView>"
            inline constexpr std::uintptr_t inventorySlotModel = 0x30; // "IInventorySlotModel"
            inline constexpr std::uintptr_t parent = 0x38; // "Transform"
            inline constexpr std::uintptr_t selectedView = 0x40; // "IDisposableContent<InventorySelectedView>"
            inline constexpr std::uintptr_t isHighlighted = 0x48; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA76CC0; // "public HighlightedItemUpdater Init(BattleModel battleModel, BattleScreenContent battleScreenContent, IInventorySlotModel inventorySlotModel, Transform parent)"
            inline constexpr std::uintptr_t Dispose = 0xA76C50; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA76D50; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace HighlightedItemUpdater

    namespace HoodItemActionModel { // "Game.Battle.Inventory.HoodItemActionModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t itemModel = 0x10; // "IInventoryItemModel"
            inline constexpr std::uintptr_t slotUpgradeType = 0x18; // "CarUpgradeType"
            inline constexpr std::uintptr_t carUpgradesSlotModel = 0x20; // "CarUpgradesSlotModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Initialize = 0xA2D3F0; // "public void Initialize(IInventoryItemModel itemModel, CarUpgradeType slotUpgradeType, CarUpgradesSlotModel carUpgradesSlotModel)"
            inline constexpr std::uintptr_t CheckSet = 0xA2D220; // "public bool CheckSet(InventoryItemDescription item, int count, int ammo, int durability, int cumulativePoints, out bool isSet)"
            inline constexpr std::uintptr_t CheckMoveFrom = 0xA2D050; // "public bool CheckMoveFrom(int count, out InventoryItemDescription item, out int ammo, out int durability, out int cumulativePoints, out bool isUnset)"
            inline constexpr std::uintptr_t CheckHoodModelBackpack = 0xA2CDB0; // "private bool CheckHoodModelBackpack(InventoryItemDescription takeItem, InventoryItemDescription putItem)"
            inline constexpr std::uintptr_t CheckReduceInventory = 0xA2D190; // "private bool CheckReduceInventory(CargoInventoryModel cargoInventoryModel, int startSlotIndex)"
            inline constexpr std::uintptr_t CheckMoveTo = 0xA2D0F0; // "public bool CheckMoveTo(InventoryItemDescription item, int count, int ammo, int durability, int cumulativePoints, IItemActionModel fromModel, out bool isSet)"
            inline constexpr std::uintptr_t CheckUnset = 0xA2D350; // "public bool CheckUnset()"
            inline constexpr std::uintptr_t CheckSwap = 0xA2D260; // "public bool CheckSwap(InventoryItemDescription item, int count, int ammo, int durability, int cumulativePoints)"
            inline constexpr std::uintptr_t IsSameType = 0xA2D440; // "private static bool IsSameType(CarUpgradeType upgradeType, InventoryItemDescription putItem)"
            inline constexpr std::uintptr_t TryGetContent = 0xA2D4C0; // "public bool TryGetContent(out InventoryItemDescription item, out int count, out int ammo, out int durability, out int cumulativePoints)"
            inline constexpr std::uintptr_t AreEqual = 0xA2CCB0; // "public bool AreEqual(IItemActionModel other)"
            inline constexpr std::uintptr_t Set = 0xA2D480; // "public void Set(long now, InventoryItemDescription item, int count, int ammo, int durability, int cumulativePoints)"
            inline constexpr std::uintptr_t Unset = 0xA2D5E0; // "public void Unset()"
            inline constexpr std::uintptr_t ChangeStack = 0xA2CD70; // "public void ChangeStack(int count)"
            inline constexpr std::uintptr_t ChangeAmmo = 0xA2CD30; // "public void ChangeAmmo(int ammo)"
            inline constexpr std::uintptr_t get_IsSlotBusy = 0x7EC9F0; // "public bool get_IsSlotBusy()"
            inline constexpr std::uintptr_t CheckUnloadAmmo = 0xA2D310; // "public bool CheckUnloadAmmo(long now)"
        }
    } // namespace HoodItemActionModel

    namespace HoverableSlotsModel { // "Game.Battle.Inventory.HoverableSlotsModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t items = 0x10; // "Dictionary<IItemMoveContext, PointerButtonView>"
            inline constexpr std::uintptr_t Items = 0x18; // "ReadOnlyDictionaryNonAlloc<IItemMoveContext, PointerButtonView>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Add = 0xA2D620; // "public void Add(IItemMoveContext model, PointerButtonView view)"
            inline constexpr std::uintptr_t Remove = 0xA2D690; // "public void Remove(IItemMoveContext model)"
        }
    } // namespace HoverableSlotsModel

    namespace InventoryAddItemsExtension { // "Models.Utils.Extensions.InventoryAddItemsExtension (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t TryAddItems = 0x395ED80; // "public static bool TryAddItems(IInventoryModel inventoryModel, IReadOnlyList<InventoryItemWithAmount> items)"
            inline constexpr std::uintptr_t CompareItemsSize = 0x395ECD0; // "private static int CompareItemsSize(InventoryItemWithAmount x, InventoryItemWithAmount y)"
        }
    } // namespace InventoryAddItemsExtension

    namespace InventoryBackupModel { // "Models.Models.InventoryBackup.InventoryBackupModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "InventoryItemsData"
            inline constexpr std::uintptr_t dataSerializer = 0x18; // "IReplicateDataSerializer"
            inline constexpr std::uintptr_t HasBackup = 0x20; // "bool"
            inline constexpr std::uintptr_t InventoryModel = 0x28; // "IInventoryModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t GetData = 0x49364F0; // "public byte[] GetData()"
            inline constexpr std::uintptr_t Set = 0x49365B0; // "public void Set(byte[] data)"
            inline constexpr std::uintptr_t Unset = 0xA0D300; // "public void Unset()"
        }
    } // namespace InventoryBackupModel

    namespace InventoryBadgesModel { // "Game.Battle.Entities.Building.InventoryBadgesModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Dictionary = 0x10; // "Dictionary<PoliceBadgeDescription, int>"
        }
    } // namespace InventoryBadgesModel

    namespace InventoryBadgesUpdater { // "Game.Battle.Entities.Building.InventoryBadgesUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t backupInventoryPoliceBadges = 0x10; // "BackupInventoryPoliceBadgesModel"
            inline constexpr std::uintptr_t policeBadgeRepositoryAmounts = 0x18; // "PoliceBadgeRepositoryAmountsModel"
            inline constexpr std::uintptr_t inventoryModel = 0x20; // "IInventoryModel"
            inline constexpr std::uintptr_t role = 0x28; // "IPrimitiveModel<PlayerRoleDescription>"
            inline constexpr std::uintptr_t inventoryBadgesModel = 0x30; // "InventoryBadgesModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xBB4F20; // "public void Update()"
        }
    } // namespace InventoryBadgesUpdater

    namespace InventoryCellArmorBarUpdater { // "Game.Battle.Inventory.InventoryCellArmorBarUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t inventoryItemArmorView = 0x20; // "PooledLoadedComponentContent<SegmentedHealthBarView>"
            inline constexpr std::uintptr_t inventoryItemModel = 0x28; // "IInventoryItemModel"
            inline constexpr std::uintptr_t ammoModel = 0x30; // "IAmmoModel"
            inline constexpr std::uintptr_t armorBarContent = 0x38; // "IDisposableContent<SegmentedHealthBarView>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0x9FBA50; // "public InventoryCellArmorBarUpdater Init(InventoryScreenContent inventoryScreenContent, IInventoryItemModel inventoryItemModel, IAmmoModel ammoModel, RectTransform compositeParent)"
            inline constexpr std::uintptr_t Dispose = 0x9FB9D0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0x9FBB10; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace InventoryCellArmorBarUpdater

    namespace InventoryCellCollectableUpdater { // "Game.Battle.Inventory.InventoryCellCollectableUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t gatherSettlementCollectionsModel = 0x20; // "GatherSettlementCollectionsModel"
            inline constexpr std::uintptr_t template_id = 0x28; // "PooledLoadedComponentContent<Transform>"
            inline constexpr std::uintptr_t inventoryItemModel = 0x30; // "IInventoryItemModel"
            inline constexpr std::uintptr_t compositeParent = 0x38; // "Transform"
            inline constexpr std::uintptr_t disposableContent = 0x40; // "IDisposableContent<Transform>"
            inline constexpr std::uintptr_t needShow = 0x48; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0x9FBD80; // "public InventoryCellCollectableUpdater Init(BattleModel battleModel, InventoryScreenContent inventoryScreenContent, IInventoryItemModel inventoryItemModel, Transform compositeParent)"
            inline constexpr std::uintptr_t Dispose = 0x9FBD00; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0x9FBE20; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace InventoryCellCollectableUpdater

    namespace InventoryCellsBackgroundUpdater { // "Game.Battle.Inventory.InventoryCellsBackgroundUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x20; // "IInventoryModel"
            inline constexpr std::uintptr_t view = 0x28; // "ScrolledCellsUiView"
            inline constexpr std::uintptr_t unlockedLines = 0x30; // "int"
            inline constexpr std::uintptr_t takeOnlyLines = 0x34; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0x9FBF40; // "public InventoryCellsBackgroundUpdater Init(IInventoryModel model, ScrolledCellsUiView view)"
            inline constexpr std::uintptr_t Dispose = 0x92B5C0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0x9FBF90; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace InventoryCellsBackgroundUpdater

    namespace InventoryCellsItemView { // "Game.Battle.Inventory.InventoryCellsItemView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t SlotBlockedView = 0x20; // "SlotBlockedView"
            inline constexpr std::uintptr_t SlotLockedView = 0x28; // "SlotLockedView"
            inline constexpr std::uintptr_t InventorySlotView = 0x30; // "InventoryIconView"
            inline constexpr std::uintptr_t RareView = 0x38; // "LineAndBackgroundRareView"
            inline constexpr std::uintptr_t DraggableItemView = 0x40; // "DraggableItemView"
            inline constexpr std::uintptr_t PointerButtonView = 0x48; // "PointerButtonView"
            inline constexpr std::uintptr_t NewContentIndicatorView = 0x50; // "NewContentIndicatorView"
            inline constexpr std::uintptr_t transform = 0x58; // "RectTransform"
            inline constexpr std::uintptr_t compositeTransform = 0x60; // "RectTransform"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_BackgroundParent = 0x8B1A20; // "public RectTransform get_BackgroundParent()"
            inline constexpr std::uintptr_t get_CompositeParent = 0x8E1B30; // "public RectTransform get_CompositeParent()"
            inline constexpr std::uintptr_t SetSize = 0x9FC170; // "public void SetSize(Vector2 size)"
            inline constexpr std::uintptr_t SetPosition = 0x9FC150; // "public void SetPosition(Vector2 position)"
            inline constexpr std::uintptr_t ResetView = 0x9FC070; // "public void ResetView()"
            inline constexpr std::uintptr_t SetBroken = 0x9FC130; // "public void SetBroken(bool value)"
        }
    } // namespace InventoryCellsItemView

    namespace InventoryCellsRevealSlotUpdater { // "Game.Battle.Inventory.Reveal.InventoryCellsRevealSlotUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x20; // "IRevealContainerModel"
            inline constexpr std::uintptr_t viewDescriptions = 0x28; // "InventoryRevealViewDescriptions"
            inline constexpr std::uintptr_t inventoryView = 0x30; // "ScrolledCellsUiView"
            inline constexpr std::uintptr_t uiSoundObject = 0x38; // "GameObject"
            inline constexpr std::uintptr_t templateContent = 0x40; // "PooledLoadedComponentContent<InventoryCellsRevealView>"
            inline constexpr std::uintptr_t context = 0x48; // "IInventoryItemMoveContext"
            inline constexpr std::uintptr_t inventorySlotModel = 0x50; // "IInventoryItemModel"
            inline constexpr std::uintptr_t slotIndex = 0x58; // "int"
            inline constexpr std::uintptr_t inventoryCellsSizeDescription = 0x60; // "InventoryCellsSizeDescription"
            inline constexpr std::uintptr_t inventoryItemViewDescriptions = 0x68; // "InventoryItemViewDescriptions"
            inline constexpr std::uintptr_t content = 0x70; // "IDisposableContent<InventoryCellsRevealView>"
            inline constexpr std::uintptr_t currentItem = 0x78; // "InventoryItemDescription"
            inline constexpr std::uintptr_t state = 0x80; // "InventoryCellsRevealSlotUpdater.RevealState"
            inline constexpr std::uintptr_t scanDuration = 0x84; // "float"
            inline constexpr std::uintptr_t shineDuration = 0x88; // "Nullable<float>"
            inline constexpr std::uintptr_t iconRevealDuration = 0x90; // "Nullable<float>"
            inline constexpr std::uintptr_t scanEndTime = 0x98; // "float"
            inline constexpr std::uintptr_t shineEndTime = 0x9C; // "float"
            inline constexpr std::uintptr_t iconRevealEndTime = 0xA0; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA5CB70; // "public InventoryCellsRevealSlotUpdater Init(IRevealContainerModel model, IInventoryItemMoveContext context, BattleScreenContent battleScreenContent, GlobalScreenContent globalScreenContent, InventoryScreenContent inventoryScreenContent, ScrolledCellsUiView inventoryView)"
            inline constexpr std::uintptr_t Dispose = 0xA5CAB0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA5CE40; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t CreateView = 0xA5C880; // "private void CreateView()"
            inline constexpr std::uintptr_t SetCorrectSize = 0xA5D710; // "private void SetCorrectSize(InventoryCellsRevealView item)"
            inline constexpr std::uintptr_t CheckOpenState = 0xA5C7F0; // "private bool CheckOpenState()"
            inline constexpr std::uintptr_t CheckCurrentItemChanged = 0xA5C600; // "private bool CheckCurrentItemChanged()"
            inline constexpr std::uintptr_t ResetViewContent = 0xA5D630; // "private void ResetViewContent()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace InventoryCellsRevealSlotUpdater

    namespace InventoryCellsRevealUpdater { // "Game.Battle.Inventory.Reveal.InventoryCellsRevealUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t updaters = 0x20; // "List<IUpdater>"
            inline constexpr std::uintptr_t revealContainerModel = 0x28; // "IRevealContainerModel"
            inline constexpr std::uintptr_t viewDescriptions = 0x30; // "InventoryRevealViewDescriptions"
            inline constexpr std::uintptr_t uiSoundObject = 0x38; // "GameObject"
            inline constexpr std::uintptr_t isActive = 0x40; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA5D960; // "public InventoryCellsRevealUpdater Init(IRevealContainerModel revealContainerModel, List<IInventoryItemMoveContext> moveContexts, ScrolledCellsUiView view, BattleScreenContent battleScreenContent, GlobalScreenContent globalScreenContent, InventoryScreenContent inventoryScreenContent, UpdaterPool updaterPool, IRegisterDisposable disposable)"
            inline constexpr std::uintptr_t Dispose = 0xA5D890; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA5DC90; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t StopSound = 0xA5DD30; // "private void StopSound()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace InventoryCellsRevealUpdater

    namespace InventoryCellsRevealView { // "Game.Battle.Inventory.Reveal.Views.InventoryCellsRevealView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t selfRectTransform = 0x20; // "RectTransform"
            inline constexpr std::uintptr_t background = 0x28; // "Image"
            inline constexpr std::uintptr_t ScanFxView = 0x30; // "InventoryItemScanFxView"
            inline constexpr std::uintptr_t IconRevealFxView = 0x38; // "InventoryItemIconRevealFxView"
            inline constexpr std::uintptr_t ShineFxView = 0x40; // "InventoryItemCellShineFxView"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetTransform = 0xA5DF30; // "public void SetTransform(Vector2 position, Vector2 size)"
            inline constexpr std::uintptr_t ShowBackground = 0xA5E040; // "public void ShowBackground(Sprite sprite, PaletteColor color)"
            inline constexpr std::uintptr_t HideBackground = 0xA5DE00; // "public void HideBackground()"
            inline constexpr std::uintptr_t PreparePreview = 0xA5DE40; // "public void PreparePreview(InventoryRevealViewDescriptions viewDescriptions, InventoryRevealViewDescriptions.RevealViewDescription viewDescription)"
        }
    } // namespace InventoryCellsRevealView

    namespace InventoryCellsSizeDescription { // "Models.References.Inventory.InventoryCellsSizeDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t LineLength = 0x20; // "int"
            inline constexpr std::uintptr_t LinesCount = 0x24; // "int"
            inline constexpr std::uintptr_t IsClient = 0x28; // "bool"
            inline constexpr std::uintptr_t Slots = 0x30; // "ReadOnlyEnum<InventorySlotDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t IndexToCoordinates = 0x43E7220; // "public ValueTuple<int, int> IndexToCoordinates(int index)"
            inline constexpr std::uintptr_t CoordinatesToIndex = 0x43E7210; // "public int CoordinatesToIndex(int x, int y)"
        }
    } // namespace InventoryCellsSizeDescription

    namespace InventoryCellsSlotsUpdater { // "Game.Battle.Inventory.InventoryCellsSlotsUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t updaters = 0x20; // "List<IUpdater>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0x9FF330; // "public InventoryCellsSlotsUpdater Init(BattleModel battleModel, BattleScreenContent battleScreenContent, GlobalScreenContent globalScreenContent, InventoryScreenContent inventoryScreenContent, UpdaterPool updaterPool, List<IInventoryItemMoveContext> itemMoveContexts, ScrolledCellsUiView view, CurrentInventoryModel currentInventoryModel, int inventoryEntityId, IScreenModel screenModel, IRegisterDisposable disposable)"
            inline constexpr std::uintptr_t Dispose = 0x9FF2D0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0x94CF50; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace InventoryCellsSlotsUpdater

    namespace InventoryCellsSlotUpdater { // "Game.Battle.Inventory.InventoryCellsSlotUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t description = 0x20; // "InventorySlotDescription"
            inline constexpr std::uintptr_t countOrAmmoUpdater = 0x28; // "List<IUpdater>"
            inline constexpr std::uintptr_t durabilityUpdater = 0x30; // "List<IUpdater>"
            inline constexpr std::uintptr_t battleModel = 0x38; // "BattleModel"
            inline constexpr std::uintptr_t inventoryScreenContent = 0x40; // "InventoryScreenContent"
            inline constexpr std::uintptr_t battleScreenContent = 0x48; // "BattleScreenContent"
            inline constexpr std::uintptr_t draggableItemsModel = 0x50; // "DraggableItemsModel"
            inline constexpr std::uintptr_t clickableItemsModel = 0x58; // "ClickableItemsModel"
            inline constexpr std::uintptr_t globalScreenContent = 0x60; // "GlobalScreenContent"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x68; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t updaterPool = 0x70; // "UpdaterPool"
            inline constexpr std::uintptr_t iconUpdater = 0x78; // "IUpdater"
            inline constexpr std::uintptr_t costUpdater = 0x80; // "IUpdater"
            inline constexpr std::uintptr_t blockedUpdater = 0x88; // "IUpdater"
            inline constexpr std::uintptr_t cumulativeUpdater = 0x90; // "IUpdater"
            inline constexpr std::uintptr_t progressViewUpdater = 0x98; // "IUpdater"
            inline constexpr std::uintptr_t selectedViewUpdater = 0xA0; // "IUpdater"
            inline constexpr std::uintptr_t rareViewUpdater = 0xA8; // "IUpdater"
            inline constexpr std::uintptr_t highlightedItemUpdater = 0xB0; // "IUpdater"
            inline constexpr std::uintptr_t inventoryCellNeedShowArmorBarStateUpdater = 0xB8; // "IUpdater"
            inline constexpr std::uintptr_t inventoryCellArmorBarUpdater = 0xC0; // "IUpdater"
            inline constexpr std::uintptr_t collectionUpdater = 0xC8; // "IUpdater"
            inline constexpr std::uintptr_t inventoryRestrictedShadowUpdater = 0xD0; // "IUpdater"
            inline constexpr std::uintptr_t dirtyCashIncomeUpdater = 0xD8; // "IUpdater"
            inline constexpr std::uintptr_t cooldownUpdater = 0xE0; // "IUpdater"
            inline constexpr std::uintptr_t scrollToInventorySlotUpdater = 0xE8; // "IUpdater"
            inline constexpr std::uintptr_t traderNewNotificationUpdater = 0xF0; // "IUpdater"
            inline constexpr std::uintptr_t inventoryEntityId = 0xF8; // "int"
            inline constexpr std::uintptr_t view = 0x100; // "ScrolledCellsUiView"
            inline constexpr std::uintptr_t inventoryDescription = 0x108; // "InventoryCellsSizeDescription"
            inline constexpr std::uintptr_t currentInventoryModel = 0x110; // "CurrentInventoryModel"
            inline constexpr std::uintptr_t itemMoveContext = 0x118; // "IItemMoveContext"
            inline constexpr std::uintptr_t inventory = 0x120; // "IInventoryModel"
            inline constexpr std::uintptr_t slotModel = 0x128; // "IInventorySlotModel"
            inline constexpr std::uintptr_t currentItem = 0x130; // "InventoryItemDescription"
            inline constexpr std::uintptr_t disposableContent = 0x138; // "IDisposableContent<InventoryCellsItemView>"
            inline constexpr std::uintptr_t player = 0x140; // "PlayerEntityModel"
            inline constexpr std::uintptr_t screenModel = 0x148; // "IScreenModel"
            inline constexpr std::uintptr_t disposable = 0x150; // "RegisterDisposable"
            inline constexpr std::uintptr_t slotDisposable = 0x158; // "RegisterDisposable"
            inline constexpr std::uintptr_t init = 0x160; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0x9FC4F0; // "public InventoryCellsSlotUpdater Init(BattleModel battleModel, BattleScreenContent battleScreenContent, GlobalScreenContent globalScreenContent, InventoryScreenContent inventoryScreenContent, UpdaterPool updaterPool, ScrolledCellsUiView view, IInventoryItemMoveContext itemMoveContext, CurrentInventoryModel currentInventoryModel, int inventoryEntityId, IScreenModel screenModel)"
            inline constexpr std::uintptr_t Dispose = 0x9FC190; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0x9FC7B0; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t SetEmptyState = 0x9FCA90; // "private void SetEmptyState()"
            inline constexpr std::uintptr_t SetFilledState = 0x9FCCE0; // "private void SetFilledState()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace InventoryCellsSlotUpdater

    namespace InventoryCloseOnInteractableObjectUpdater { // "Game.Battle.Inventory.InventoryCloseOnInteractableObjectUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x20; // "InteractableObjectOpenedModel"
            inline constexpr std::uintptr_t dialogModel = 0x28; // "ScreenModel"
            inline constexpr std::uintptr_t isOpened = 0x30; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0x9FF810; // "public InventoryCloseOnInteractableObjectUpdater Init(InteractableObjectOpenedModel model, ScreenModel dialogModel)"
            inline constexpr std::uintptr_t Dispose = 0x92B5C0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0x9FF850; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace InventoryCloseOnInteractableObjectUpdater

    namespace InventoryCollectionRules { // "Game.Battle.Inventory.InventoryCollectionRules (Battle.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t GetIsItemRequiredForCollection = 0xA10D10; // "public static bool GetIsItemRequiredForCollection(IInventoryItemModel itemModel, GatherSettlementCollectionsModel gatherSettlementCollectionsModel, CollectionTableSlotDescription collectionTableSlot)"
        }
    } // namespace InventoryCollectionRules

    namespace InventoryComputedConfig { // "Models.References.Inventory.InventoryComputedConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ServerLargestInventorySlots = 0x10; // "ReadOnlyEnum<InventorySlotDescription>"
            inline constexpr std::uintptr_t MaxInventoryLineCount = 0x18; // "int"
        }
    } // namespace InventoryComputedConfig

    namespace InventoryCostDescription { // "Models.References.InventoryCostDescription (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t CharacterInventoryCost = 0x4046900; // "public static int CharacterInventoryCost(IInventoryModel inventoryModel, IEquipSlotsModel equipSlotsModel, IEquipAmmoModel equipAmmoModel, IPocketsModel pocketsModel)"
            inline constexpr std::uintptr_t EquipCost = 0x4046950; // "public static int EquipCost(IEquipSlotsModel equipSlotsModel, IEquipAmmoModel equipAmmoModel, IPocketsModel pocketsModel)"
            inline constexpr std::uintptr_t InventoryCost = 0x4047230; // "public static int InventoryCost(IInventoryModel inventoryModel)"
            inline constexpr std::uintptr_t InventoryCashCost = 0x4047220; // "public static int InventoryCashCost(IInventoryModel inventoryModel)"
            inline constexpr std::uintptr_t InventoryItemsCost = 0x4047BD0; // "public static int InventoryItemsCost(IInventoryModel inventoryModel)"
            inline constexpr std::uintptr_t InventoryCost_2 = 0x40476E0; // "private static int InventoryCost(IInventoryModel inventoryModel, bool isCash)"
            inline constexpr std::uintptr_t ItemCost = 0x4047BE0; // "private static int ItemCost(InventoryItemDescription item, int count, int ammo, int durability)"
        }
    } // namespace InventoryCostDescription

    namespace InventoryCostViewUpdater { // "Game.Battle.Inventory.Cost.InventoryCostViewUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t inventoryModel = 0x20; // "IInventoryModel"
            inline constexpr std::uintptr_t totalCostView = 0x28; // "TextLabel<Money>"
            inline constexpr std::uintptr_t revealContainerModel = 0x30; // "IRevealContainerModel"
            inline constexpr std::uintptr_t getIsVisible = 0x38; // "Func<bool>"
            inline constexpr std::uintptr_t isVisible = 0x40; // "bool"
            inline constexpr std::uintptr_t slotSnapshots = 0x48; // "InventoryCostViewUpdater.SlotSnapshot[]"
            inline constexpr std::uintptr_t totalCost = 0x50; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA7A360; // "public InventoryCostViewUpdater Init(IInventoryModel inventoryModel, TextLabel<Money> totalCostView, IRevealContainerModel revealContainerModel, Func<bool> getIsVisible)"
            inline constexpr std::uintptr_t Dispose = 0xA79FA0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA7A4F0; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t InitSnapshots = 0xA7A010; // "private void InitSnapshots()"
            inline constexpr std::uintptr_t RefreshSnapshots = 0xA7A650; // "private bool RefreshSnapshots()"
            inline constexpr std::uintptr_t BuildSnapshot = 0xA79E10; // "private InventoryCostViewUpdater.SlotSnapshot BuildSnapshot(IInventorySlotModel slot)"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace InventoryCostViewUpdater

    namespace InventoryCostViewUpdater_SlotSnapshot { // "Game.Battle.Inventory.Cost.InventoryCostViewUpdater.SlotSnapshot (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Item = 0x0; // "InventoryItemDescription"
            inline constexpr std::uintptr_t Stack = 0x8; // "int"
            inline constexpr std::uintptr_t Ammo = 0xC; // "int"
            inline constexpr std::uintptr_t Durability = 0x10; // "int"
            inline constexpr std::uintptr_t Revealed = 0x14; // "bool"
            inline constexpr std::uintptr_t Cost = 0x18; // "int"
        }
    } // namespace InventoryCostViewUpdater_SlotSnapshot

    namespace InventoryData { // "Models.Data.InventoryData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Description = 0x28; // "InventoryCellsSizeDescription"
        }
    } // namespace InventoryData

    namespace InventoryDialogFooterView { // "Game.Battle.Inventory.InventoryDialogFooterView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t owner = 0x20; // "TextLabel<string, string>"
            inline constexpr std::uintptr_t CompositeButton = 0x28; // "CompositeButtonView"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetOwner = 0x9FF8F0; // "public void SetOwner(string tag, string playerName)"
            inline constexpr std::uintptr_t OnEnable = 0x9FF8A0; // "private void OnEnable()"
        }
    } // namespace InventoryDialogFooterView

    namespace InventoryDialogHeaderView { // "Game.Battle.Inventory.InventoryDialogHeaderView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t mainHeader = 0x20; // "LocalizeStringEvent"
            inline constexpr std::uintptr_t Timer = 0x28; // "MinSecTimerView"
            inline constexpr std::uintptr_t TotalCost = 0x30; // "TextLabel<Money>"
            inline constexpr std::uintptr_t TooltipButtonView = 0x38; // "PointerButtonView"
            inline constexpr std::uintptr_t TooltipParent = 0x40; // "RectTransform"
            inline constexpr std::uintptr_t additionalHeader = 0x48; // "LocalizeStringEvent"
        }
        namespace Methods {
            inline constexpr std::uintptr_t OnEnable = 0x9FF980; // "private void OnEnable()"
            inline constexpr std::uintptr_t SetHeader = 0x9A9AE0; // "public void SetHeader(LocalizedString mainHeader)"
            inline constexpr std::uintptr_t SetAdditionalHeader = 0x9FFA20; // "public void SetAdditionalHeader(LocalizedString additionalHeader)"
        }
    } // namespace InventoryDialogHeaderView

    namespace InventoryDialogKeyboardInputHandler { // "Game.Battle.Inventory.InventoryDialogKeyboardInputHandler (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dialogModel = 0x10; // "InventoryDialogModel"
            inline constexpr std::uintptr_t updater = 0x18; // "IUpdater"
        }
        namespace Methods {
            inline constexpr std::uintptr_t OnCloseDialog = 0x952750; // "private void OnCloseDialog()"
            inline constexpr std::uintptr_t Update = 0xA10DE0; // "public void Update()"
        }
    } // namespace InventoryDialogKeyboardInputHandler

    namespace InventoryDialogModel { // "Game.Battle.Inventory.InventoryDialogModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t CurrentInventoryModel = 0x18; // "CurrentInventoryModel"
            inline constexpr std::uintptr_t NeedReopenInventory = 0x20; // "bool"
            inline constexpr std::uintptr_t NeedSoundOnClose = 0x21; // "bool"
            inline constexpr std::uintptr_t TotalMoneyInfoInputModel = 0x28; // "InputModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Open = 0x9FFAA0; // "public void Open(CurrentInventoryModel inventoryModel)"
        }
    } // namespace InventoryDialogModel

    namespace InventoryDialogTabsModel { // "Game.Battle.Inventory.InventoryDialogTabsModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "Dictionary<int, int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Add = 0xA2D7C0; // "public void Add(int entityId, int tabIndex)"
            inline constexpr std::uintptr_t Remove = 0xA2D8E0; // "public void Remove(int entityId)"
            inline constexpr std::uintptr_t Clear = 0xA2D830; // "public void Clear()"
            inline constexpr std::uintptr_t Contains = 0xA2D880; // "public bool Contains(int tabIndex)"
            inline constexpr std::uintptr_t TryGet = 0xA2D940; // "public bool TryGet(int entityId, out int tabIndex)"
            inline constexpr std::uintptr_t get_Item = 0xA2DA30; // "public int get_Item(int entityId)"
        }
    } // namespace InventoryDialogTabsModel

    namespace InventoryDialogTouchInputHandler { // "Game.Battle.Inventory.InventoryDialogTouchInputHandler (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dialogModel = 0x10; // "InventoryDialogModel"
            inline constexpr std::uintptr_t updater = 0x18; // "IUpdater"
        }
        namespace Methods {
            inline constexpr std::uintptr_t OnCloseDialog = 0x952750; // "private void OnCloseDialog()"
            inline constexpr std::uintptr_t Update = 0xA11820; // "public void Update()"
        }
    } // namespace InventoryDialogTouchInputHandler

    namespace InventoryDialogUpdater { // "Game.Battle.Inventory.InventoryDialogUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t updaters = 0x20; // "List<IUpdater>"
            inline constexpr std::uintptr_t disposableContent = 0x28; // "IDisposable"
            inline constexpr std::uintptr_t battleModel = 0x30; // "BattleModel"
            inline constexpr std::uintptr_t inventoryDialogModel = 0x38; // "InventoryDialogModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0x9FFC90; // "public InventoryDialogUpdater Init(GlobalModel globalModel, BattleModel battleModel, Camera uiCamera, InputActions inputActions, Transform canvasParent, BattleScreenContent battleScreenContent, GlobalScreenContent globalScreenContent, List<IUpdater> mainInputUpdaters, ItemTooltipView tooltipView, UpdaterPool updaterPool, IRegisterDisposable disposable)"
            inline constexpr std::uintptr_t Dispose = 0x9FFB30; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0x94CF50; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace InventoryDialogUpdater

    namespace InventoryDialogView { // "Game.Battle.Inventory.InventoryDialogView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t UIView = 0x20; // "InventoryUiView"
            inline constexpr std::uintptr_t InventoryBorder = 0x28; // "RectTransform"
            inline constexpr std::uintptr_t DialogState = 0x30; // "EnumStateElement<InventoryDialogType>"
            inline constexpr std::uintptr_t Header = 0x38; // "InventoryDialogHeaderView"
        }
    } // namespace InventoryDialogView

    namespace InventoryDragAndDropEmptyResetUpdater { // "Game.Battle.Inventory.InventoryDragAndDropEmptyResetUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x20; // "InventoryDragAndDropModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA12080; // "public InventoryDragAndDropEmptyResetUpdater Init(InventoryDragAndDropModel model)"
            inline constexpr std::uintptr_t Dispose = 0xA12060; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA120A0; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace InventoryDragAndDropEmptyResetUpdater

    namespace InventoryDragAndDropModel { // "Game.Battle.Inventory.InventoryDragAndDropModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t PointerId = 0x10; // "int"
            inline constexpr std::uintptr_t IsDragStarted = 0x14; // "bool"
            inline constexpr std::uintptr_t IsDragged = 0x15; // "bool"
            inline constexpr std::uintptr_t StartPosition = 0x18; // "Vector3"
            inline constexpr std::uintptr_t MovePosition = 0x24; // "Vector3"
            inline constexpr std::uintptr_t From = 0x30; // "IItemMoveContext"
            inline constexpr std::uintptr_t ItemPosition = 0x38; // "Vector2"
            inline constexpr std::uintptr_t ItemSize = 0x40; // "Vector2"
            inline constexpr std::uintptr_t Hover = 0x48; // "IItemMoveContext"
            inline constexpr std::uintptr_t HoverRectTransform = 0x50; // "RectTransform"
            inline constexpr std::uintptr_t IsScrollStarted = 0x58; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetHover = 0xA121E0; // "public void SetHover(IItemMoveContext hover, RectTransform rectTransform)"
            inline constexpr std::uintptr_t ClearHover = 0xA12140; // "public void ClearHover()"
            inline constexpr std::uintptr_t StartDrag = 0xA12220; // "public void StartDrag(Vector3 viewPosition, int pointerId, Vector2 itemPosition, Vector2 itemSize, IItemMoveContext from)"
            inline constexpr std::uintptr_t StopDrag = 0xA122A0; // "public void StopDrag()"
            inline constexpr std::uintptr_t StartScroll = 0xA12290; // "public void StartScroll(int pointerId)"
            inline constexpr std::uintptr_t StopScroll = 0xA122B0; // "public void StopScroll()"
            inline constexpr std::uintptr_t Clear = 0xA12180; // "public void Clear()"
        }
    } // namespace InventoryDragAndDropModel

    namespace InventoryDragAndDropModelUpdater { // "Game.Battle.Storage.InventoryDragAndDropModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x20; // "InventoryDragAndDropModel"
            inline constexpr std::uintptr_t inventoryCellsUiView = 0x28; // "ScrolledCellsUiView"
            inline constexpr std::uintptr_t itemMoveContexts = 0x30; // "List<IInventoryItemMoveContext>"
            inline constexpr std::uintptr_t inventoryModel = 0x38; // "IInventoryModel"
            inline constexpr std::uintptr_t clickableItemsModel = 0x40; // "ClickableItemsModel"
            inline constexpr std::uintptr_t uiCamera = 0x48; // "Camera"
            inline constexpr std::uintptr_t cellSize = 0x50; // "float"
            inline constexpr std::uintptr_t lastX = 0x54; // "int"
            inline constexpr std::uintptr_t lastY = 0x58; // "int"
            inline constexpr std::uintptr_t hover = 0x60; // "IInventoryItemMoveContext"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0x9E2DE0; // "public InventoryDragAndDropModelUpdater Init(InventoryDragAndDropModel model, ScrolledCellsUiView inventoryCellsUiView, List<IInventoryItemMoveContext> itemMoveContexts, IInventoryModel inventoryModel, ClickableItemsModel clickableItemsModel, Camera uiCamera)"
            inline constexpr std::uintptr_t Dispose = 0x9E2D50; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0x9E2EA0; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace InventoryDragAndDropModelUpdater

    namespace InventoryDragAndDropUpdater { // "Game.Battle.Inventory.InventoryDragAndDropUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x20; // "InventoryDragAndDropModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA12080; // "public InventoryDragAndDropUpdater Init(InventoryDragAndDropModel model)"
            inline constexpr std::uintptr_t Dispose = 0xA12060; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA12300; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace InventoryDragAndDropUpdater

    namespace InventoryDraggedItemViewUpdater { // "Game.Battle.Inventory.InventoryDraggedItemViewUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x20; // "InventoryDragAndDropModel"
            inline constexpr std::uintptr_t viewDescriptions = 0x28; // "InventoryItemViewDescriptions"
            inline constexpr std::uintptr_t itemTypeViewDescriptions = 0x30; // "InventoryItemTypeViewDescriptions"
            inline constexpr std::uintptr_t cellSize = 0x38; // "float"
            inline constexpr std::uintptr_t cellPadding = 0x3C; // "Vector2"
            inline constexpr std::uintptr_t tooltipModel = 0x48; // "TooltipModel"
            inline constexpr std::uintptr_t tooltipMiniModel = 0x50; // "TooltipMiniModel"
            inline constexpr std::uintptr_t itemContent = 0x58; // "IComponentInstantiateContent<DragItemView>"
            inline constexpr std::uintptr_t canvasParent = 0x60; // "Transform"
            inline constexpr std::uintptr_t inventorySelectedModel = 0x68; // "InventorySelectedModel"
            inline constexpr std::uintptr_t uiCamera = 0x70; // "Camera"
            inline constexpr std::uintptr_t uiEmitter = 0x78; // "GameObject"
            inline constexpr std::uintptr_t disposableContent = 0x80; // "IDisposableContent<DragItemView>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA12900; // "public InventoryDraggedItemViewUpdater Init(InventoryModels inventoryModels, GlobalScreenContent globalScreenContent, IComponentInstantiateContent<DragItemView> itemContent, Transform canvasParent, InventoryUiView inventoryUiView, BattleModel battleModel, TooltipMiniModel tooltipMiniModel, Camera uiCamera, GameObject uiEmitter)"
            inline constexpr std::uintptr_t Dispose = 0xA12800; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA12A60; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t SetItemPosition = 0xA12EB0; // "private void SetItemPosition(DragItemView item, Vector3 movePosition)"
            inline constexpr std::uintptr_t DisposeContent = 0xA127A0; // "private void DisposeContent()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace InventoryDraggedItemViewUpdater

    namespace InventoryDragShadowValidModelUpdater { // "Game.Battle.Inventory.InventoryDragShadowValidModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t itemMoveContexts = 0x20; // "List<IInventoryItemMoveContext>"
            inline constexpr std::uintptr_t inventoryModel = 0x28; // "IInventoryModel"
            inline constexpr std::uintptr_t inventoryIntention = 0x30; // "InventoryIntention"
            inline constexpr std::uintptr_t shadowAreaModel = 0x38; // "InventoryShadowAreaModel"
            inline constexpr std::uintptr_t model = 0x40; // "InventoryDragAndDropModel"
            inline constexpr std::uintptr_t slotPosition = 0x48; // "Vector2Int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA12420; // "public InventoryDragShadowValidModelUpdater Init(List<IInventoryItemMoveContext> itemMoveContexts, IInventoryModel inventoryModel, InventoryIntention inventoryIntention, InventoryShadowAreaModel shadowAreaModel, InventoryDragAndDropModel model)"
            inline constexpr std::uintptr_t Dispose = 0xA123B0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA124F0; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t UpdateState = 0xA125D0; // "private bool UpdateState(Vector2Int slotPosition)"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace InventoryDragShadowValidModelUpdater

    namespace InventoryDropAreaViewUpdater { // "Game.Battle.Inventory.InventoryDropAreaViewUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dropAreaView = 0x20; // "DropAreaView"
            inline constexpr std::uintptr_t model = 0x28; // "InventoryDragAndDropModel"
            inline constexpr std::uintptr_t wasDragStarted = 0x30; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA12FC0; // "public InventoryDropAreaViewUpdater Init(DropAreaView dropAreaView, InventoryDragAndDropModel model)"
            inline constexpr std::uintptr_t Dispose = 0x92B5C0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA13060; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace InventoryDropAreaViewUpdater

    namespace InventoryDropMessageView { // "Game.Battle.Inventory.InventoryDropMessageView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t MessageText = 0x20; // "LocalizeStringEvent"
        }
    } // namespace InventoryDropMessageView

    namespace InventoryEntityIds { // "Models.Inventory.InventoryEntityIds (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t GetInventoryEntityId = 0x40808C0; // "public static int GetInventoryEntityId(int ownerEntityId)"
            inline constexpr std::uintptr_t GetInventoryOwnerEntityId = 0x40808B0; // "public static int GetInventoryOwnerEntityId(int inventoryEntityId)"
        }
    } // namespace InventoryEntityIds

    namespace InventoryEquipViewUpdater { // "Game.Battle.Inventory.InventoryEquipViewUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t updaters = 0x20; // "List<IUpdater>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA13140; // "public InventoryEquipViewUpdater Init(InventoryModels inventoryModels, BattleModel battleModel, IInventoryModel inventoryModel, CurrentInventoryModel currentInventoryModel, InventoryUiView inventoryUiView, GlobalScreenContent globalScreenContent, BattleScreenContent battleScreenContent, UpdaterPool updaterPool, InventoryScreenContent inventoryScreenContent, IRegisterDisposable registerDisposable)"
            inline constexpr std::uintptr_t Dispose = 0xA130E0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0x94CF50; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace InventoryEquipViewUpdater

    namespace InventoryHeaderKeys { // "Game.Battle.BattleScreenContentDirectory.Localization.InventoryHeaderKeys (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t InventoryHeader = 0x10; // "LocalizedString"
            inline constexpr std::uintptr_t EquipmentHeader = 0x18; // "LocalizedString"
            inline constexpr std::uintptr_t TemporaryStorageHeader = 0x20; // "LocalizedString"
            inline constexpr std::uintptr_t CopSalaryBoxHeader = 0x28; // "LocalizedString"
            inline constexpr std::uintptr_t CarBenchHeader = 0x30; // "LocalizedString"
            inline constexpr std::uintptr_t HelicopterBenchHeader = 0x38; // "LocalizedString"
            inline constexpr std::uintptr_t MoneyWorkbenchHeader = 0x40; // "LocalizedString"
            inline constexpr std::uintptr_t CollectionTableHeader = 0x48; // "LocalizedString"
            inline constexpr std::uintptr_t ShelvingHeader = 0x50; // "LocalizedString"
        }
    } // namespace InventoryHeaderKeys

    namespace InventoryIntention { // "Game.Battle.Inventory.InventoryIntention (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t cachedItemActionModel = 0x10; // "CachedItemActionModel"
            inline constexpr std::uintptr_t battleCharacterModel = 0x18; // "BattleCharacterModel"
            inline constexpr std::uintptr_t lootItemSoundModel = 0x20; // "LootItemSoundModel"
            inline constexpr std::uintptr_t playerPublicId = 0x28; // "long"
            inline constexpr std::uintptr_t settlementBonusModel = 0x30; // "SettlementBonusModel"
            inline constexpr std::uintptr_t equipSlots = 0x38; // "IEquipSlotsModel"
            inline constexpr std::uintptr_t equipAmmo = 0x40; // "IEquipAmmoModel"
            inline constexpr std::uintptr_t pocketsModel = 0x48; // "IPocketsModel"
            inline constexpr std::uintptr_t inventory = 0x50; // "IInventoryModel"
            inline constexpr std::uintptr_t cargoModel = 0x58; // "CharacterCargoModel"
            inline constexpr std::uintptr_t laptopDirtyCashModel = 0x60; // "DirtyCashModel"
            inline constexpr std::uintptr_t commands = 0x68; // "List<InventoryTakeCommand>"
            inline constexpr std::uintptr_t commandsEntityIds = 0x70; // "List<int>"
            inline constexpr std::uintptr_t dummyInventory = 0x78; // "DummyInventoryModel"
            inline constexpr std::uintptr_t dummyEquipSlots = 0x80; // "DummyEquipSlotsModel"
            inline constexpr std::uintptr_t dummyPockets = 0x88; // "DummyPocketsModel"
            inline constexpr std::uintptr_t itemActionsController = 0x90; // "ItemActionsController"
            inline constexpr std::uintptr_t pickupLootResult = 0x98; // "PickupLootResult"
            inline constexpr std::uintptr_t now = 0xA0; // "INow"
            inline constexpr std::uintptr_t locationDescription = 0xA8; // "LocationDescription"
            inline constexpr std::uintptr_t battleModeDescription = 0xB0; // "BattleModeDescription"
            inline constexpr std::uintptr_t equipContexts = 0xB8; // "EquipItemMoveContext[]"
            inline constexpr std::uintptr_t pocketsContexts = 0xC0; // "PocketItemMoveContext[]"
            inline constexpr std::uintptr_t inventoryContexts = 0xC8; // "IInventoryItemMoveContext[]"
            inline constexpr std::uintptr_t worldEntitiesModel = 0xD0; // "WorldEntitiesModel"
            inline constexpr std::uintptr_t settlementModel = 0xD8; // "RegionUserSettlementModel"
            inline constexpr std::uintptr_t realmVersion = 0xE0; // "RealmVersion"
            inline constexpr std::uintptr_t carUpgradeAdapters = 0xE8; // "CarUpgradeAdapters"
            inline constexpr std::uintptr_t plotBuildingDefenseModuleAdapter = 0xF0; // "IPlotBuildingDefenseBlockModuleAdapter<DefenseBlockDefenseModuleDescription>"
            inline constexpr std::uintptr_t plotBuildingSpecialModuleAdapter = 0xF8; // "IPlotBuildingDefenseBlockModuleAdapter<DefenseBlockSpecialModuleDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_CachedItemActionModel = 0x7EC6B0; // "public CachedItemActionModel get_CachedItemActionModel()"
            inline constexpr std::uintptr_t get_RealmVersion = 0xA3E650; // "public RealmVersion get_RealmVersion()"
            inline constexpr std::uintptr_t CanEquipOrUnequip = 0xA2E160; // "public bool CanEquipOrUnequip(IItemMoveContext fromContext, out IItemMoveContext toContext, out int count)"
            inline constexpr std::uintptr_t CanMoveOrSwap = 0xA31B70; // "public ValueTuple<bool, bool, IInventorySlotModel, IInventorySlotModel, IInventorySlotModel, int, NotificationError.Type> CanMoveOrSwap(IItemMoveContext fromContext, IItemMoveContext toContext, int count)"
            inline constexpr std::uintptr_t TakeItems = 0xA3B7C0; // "public bool TakeItems(List<ExternalItemMoveContext> fromContexts, out TakeItemAction action, out NotificationError.Type errorType)"
            inline constexpr std::uintptr_t TryGetSlotToSplit = 0xA3D0A0; // "public bool TryGetSlotToSplit(IItemMoveContext fromContext, int count, out IItemMoveContext toContext, out NotificationError.Type errorType)"
            inline constexpr std::uintptr_t CanSplit = 0xA34270; // "public bool CanSplit(IItemMoveContext fromContext, int count, IItemMoveContext toContext)"
            inline constexpr std::uintptr_t IsSplitAllowedFrom = 0xA3ADC0; // "private static bool IsSplitAllowedFrom(IItemMoveContext fromContext)"
            inline constexpr std::uintptr_t CheckMoveToInventoryForSwapBackpackAndBelt = 0xA35C60; // "private bool CheckMoveToInventoryForSwapBackpackAndBelt(InventoryItemDescription currentItem, InventoryItemDescription newItem, IInventorySlotModel inventorySlotModel, IInventoryModel inventory)"
            inline constexpr std::uintptr_t FindInventorySlotForSwapEquip = 0xA39110; // "private bool FindInventorySlotForSwapEquip(EquipItemMoveContext fromContext, IItemMoveContext newItemContext, out IInventorySlotModel foundSlot)"
            inline constexpr std::uintptr_t FindInventorySlotForMove = 0xA39040; // "private bool FindInventorySlotForMove(IItemMoveContext fromContext, int startX, int startY, out IInventorySlotModel slot, out int count)"
            inline constexpr std::uintptr_t FindInventorySlotForMove_2 = 0xA389F0; // "private bool FindInventorySlotForMove(IItemMoveContext fromContext, int startX, int startY, CurrentInventoryModel.IInventory currentInventoryModel, out IInventorySlotModel slot, out int count)"
            inline constexpr std::uintptr_t FindPlotLootSlotForMove = 0xA39780; // "private bool FindPlotLootSlotForMove(IItemMoveContext fromContext, int startX, int startY, IInventoryModel inventoryModel, int entityId, out IInventorySlotModel slot, out int count)"
            inline constexpr std::uintptr_t FindInventorySlotForMove_3 = 0xA384A0; // "private bool FindInventorySlotForMove(IItemMoveContext fromContext, out IInventorySlotModel slot, out int count, IInventoryItemMoveContext startContext, IInventoryItemMoveContext[] toContexts)"
            inline constexpr std::uintptr_t CanPickUp = 0xA341D0; // "public bool CanPickUp(LootObjectItemDescription lootObject, out NotificationError.Type errorType)"
            inline constexpr std::uintptr_t CanPickUp_2 = 0xA34160; // "public bool CanPickUp(InventoryItemDescription inventoryItemDescription, int count, out NotificationError.Type errorType)"
            inline constexpr std::uintptr_t CanUnloadAmmo = 0xA35180; // "public bool CanUnloadAmmo(IItemMoveContext moveContext)"
            inline constexpr std::uintptr_t CanUnset = 0xA35380; // "public bool CanUnset(IItemMoveContext moveContext)"
            inline constexpr std::uintptr_t EnoughMoneyToBuy = 0xA36830; // "public bool EnoughMoneyToBuy(TraderInventoryDescription traderInventoryDescription, InventoryItemDescription itemDescription, int count)"
            inline constexpr std::uintptr_t TryGetMoveToSlot = 0xA3CA20; // "public bool TryGetMoveToSlot(InventoryItemDescription item, int count, out IItemMoveContext toContext, bool checkEquip, bool checkPockets, bool checkInventory, Nullable<bool> checkOnlyEmptySlots)"
            inline constexpr std::uintptr_t CanMoveInCollect = 0xA302A0; // "public bool CanMoveInCollect(IItemMoveContext from, CollectionInventoryModel inventory, EnumValue<CollectionTableSlotDescription> collectionTableSlot, out IItemAction itemInput)"
            inline constexpr std::uintptr_t CanMoveInRoulette = 0xA30F10; // "private bool CanMoveInRoulette(ChipsItemMoveContext from, out IItemAction itemInput, out NotificationError.Type errorType)"
            inline constexpr std::uintptr_t TryFastMoveInCollect = 0xA3C780; // "public bool TryFastMoveInCollect(IItemMoveContext from, ItemMoveModel itemMoveModel, CollectionInventoryModel inventory, EnumValue<CollectionTableSlotDescription> collectionTableSlot)"
            inline constexpr std::uintptr_t TryFastMoveInRoulette = 0xA3C9D0; // "public bool TryFastMoveInRoulette(ChipsItemMoveContext from, ItemMoveModel itemMoveModel, out NotificationError.Type errorType)"
            inline constexpr std::uintptr_t CanMoveItem = 0xA31510; // "public bool CanMoveItem(IItemMoveContext context, CurrentInventoryModel currentInventoryModel, InventoryModels inventoryModels, IBattleEntitiesModel battleEntitiesModel)"
            inline constexpr std::uintptr_t CanFastMoveInDefenseBlock = 0xA2F240; // "private bool CanFastMoveInDefenseBlock(IItemMoveContext from, BuilderSlotsModel builderSlots, out IItemAction itemAction, out NotificationError.Type errorType)"
            inline constexpr std::uintptr_t TryFastMoveInIInventory = 0xA3C8A0; // "public bool TryFastMoveInIInventory(IItemMoveContext from, ItemMoveModel itemMoveModel, CurrentInventoryModel.IInventory currentInventoryModel, out NotificationError.Type errorType)"
            inline constexpr std::uintptr_t TryFastMoveInPlotLoot = 0xA3C960; // "public bool TryFastMoveInPlotLoot(IItemMoveContext from, ItemMoveModel itemMoveModel, IInventoryModel inventoryModel, int entityId, out NotificationError.Type errorType)"
            inline constexpr std::uintptr_t CanMoveInIInventory = 0xA30710; // "private bool CanMoveInIInventory(IItemMoveContext from, CurrentInventoryModel.IInventory currentInventoryModel, out IItemAction itemInput, out NotificationError.Type errorType)"
            inline constexpr std::uintptr_t CanMoveInPlotLoot = 0xA30BB0; // "private bool CanMoveInPlotLoot(IItemMoveContext from, IInventoryModel inventoryModel, int entityId, out IItemAction itemInput, out NotificationError.Type errorType)"
            inline constexpr std::uintptr_t CanFastMoveInCarUpgrades = 0xA2EDC0; // "private bool CanFastMoveInCarUpgrades(IItemMoveContext from, CarUpgradesSlotModel carUpgradesSlotModel, CarUpgradesHolderTypeDescription holderType, out IItemAction itemAction, out NotificationError.Type errorType)"
            inline constexpr std::uintptr_t CanMoveItemToEmptyCarUpgradeSlot = 0xA31140; // "private bool CanMoveItemToEmptyCarUpgradeSlot(IItemMoveContext from, CarUpgradesSlotModel carUpgradesSlotModel, out IItemAction itemAction)"
            inline constexpr std::uintptr_t FindCarUpgradeSlotForMove = 0xA37CC0; // "private bool FindCarUpgradeSlotForMove(IItemMoveContext from, CarUpgradesSlotModel carUpgradesSlotModel, CarUpgradeType carUpgradeType, out int slotIndex)"
            inline constexpr std::uintptr_t CanFastMoveInBuilder = 0xA2E570; // "private bool CanFastMoveInBuilder(IItemMoveContext from, BuilderSlotsModel inventoryModelsBuilderSlotsModel, out IItemAction itemAction, out NotificationError.Type errorType)"
            inline constexpr std::uintptr_t IsPerfectFit_T_inst_1 = 0x16D1240; // "InventoryIntention.IsPerfectFit<object>"
            inline constexpr std::uintptr_t IsPerfectFit = 0xA3AC30; // "private bool IsPerfectFit(IItemMoveContext from, InventoryItemDescription itemDescription, ref InventoryItemDescription fitItemDescription, out bool isChangeFitItem)"
            inline constexpr std::uintptr_t TryFastMoveInBuilder = 0xA3C650; // "public bool TryFastMoveInBuilder(IItemMoveContext from, ItemMoveModel itemMoveModel, BuilderSlotsModel inventoryModelsBuilderSlotsModel, out NotificationError.Type errorType)"
            inline constexpr std::uintptr_t TryFastMoveInDefenseBlock = 0xA3C7E0; // "public bool TryFastMoveInDefenseBlock(IItemMoveContext from, ItemMoveModel itemMoveModel, BuilderSlotsModel inventoryModelsBuilderSlotsModel, out NotificationError.Type errorType)"
            inline constexpr std::uintptr_t TryFastMoveInCarUpgrades = 0xA3C710; // "public bool TryFastMoveInCarUpgrades(IItemMoveContext from, ItemMoveModel itemMoveModel, CarUpgradesSlotModel carUpgradesSlotModel, CarUpgradesHolderTypeDescription holderType, out NotificationError.Type errorType)"
            inline constexpr std::uintptr_t CanFastMoveInCarBuilder = 0xA2EA60; // "private bool CanFastMoveInCarBuilder(IItemMoveContext from, CarBenchSlotsModel carBenchSlotsModel, out IItemAction itemAction, out NotificationError.Type errorType)"
            inline constexpr std::uintptr_t TryFastMoveInCarBuilder = 0xA3C6B0; // "public bool TryFastMoveInCarBuilder(IItemMoveContext from, ItemMoveModel itemMoveModel, CarBenchSlotsModel carBenchSlotsModel, out NotificationError.Type errorType)"
            inline constexpr std::uintptr_t CanFastMoveInHelicopterBuilder = 0xA2F790; // "private bool CanFastMoveInHelicopterBuilder(IItemMoveContext from, HelicopterBenchSlotsModel helicopterBenchSlotsModel, out IItemAction itemAction, out NotificationError.Type errorType)"
            inline constexpr std::uintptr_t CanFastMoveFromRewardBox = 0xA2E460; // "private bool CanFastMoveFromRewardBox(IItemMoveContext from, out IItemAction itemAction, out NotificationError.Type errorType)"
            inline constexpr std::uintptr_t TryFastMoveInHelicopterBuilder = 0xA3C840; // "public bool TryFastMoveInHelicopterBuilder(IItemMoveContext from, ItemMoveModel itemMoveModel, HelicopterBenchSlotsModel helicopterBenchSlotsModel, out NotificationError.Type errorType)"
            inline constexpr std::uintptr_t CanMoveInLaunderingMoneyWorkbench = 0xA309F0; // "private bool CanMoveInLaunderingMoneyWorkbench(IItemMoveContext from, int entityId, out IItemAction itemAction, out NotificationError.Type errorType)"
            inline constexpr std::uintptr_t TryFastMoveFromCopRewardBox = 0xA3C530; // "public bool TryFastMoveFromCopRewardBox(IItemMoveContext from, ItemMoveModel itemMoveModel, out NotificationError.Type errorType)"
            inline constexpr std::uintptr_t TryFastMoveInLaunderingMoneyWorkbench = 0xA3C900; // "public bool TryFastMoveInLaunderingMoneyWorkbench(IItemMoveContext from, ItemMoveModel itemMoveModel, int entityId, out NotificationError.Type errorType)"
            inline constexpr std::uintptr_t CanMoveUsableOrEquipItem = 0xA33C70; // "private bool CanMoveUsableOrEquipItem(IItemMoveContext from, IInventoryItemModel fromModel, out IItemAction itemAction)"
            inline constexpr std::uintptr_t CanMoveItemToEmptyInventorySlot = 0xA31330; // "private bool CanMoveItemToEmptyInventorySlot(IItemMoveContext from, out IItemAction itemAction)"
            inline constexpr std::uintptr_t TryBuyerSell = 0xA3C320; // "public bool TryBuyerSell(IItemMoveContext from, CurrentInventoryModel.Buyer buyer, ItemMoveModel itemMoveModel, out NotificationError.Type errorType)"
            inline constexpr std::uintptr_t CheckBuyerSell = 0xA358F0; // "public bool CheckBuyerSell(IItemMoveContext from, out NotificationError.Type errorType)"
            inline constexpr std::uintptr_t TryTraderBuy = 0xA3DD20; // "public bool TryTraderBuy(BattleCharacterModel battleCharacterModel, TraderItemMoveContext from, int buyCount, ItemMoveModel itemMoveModel, ShopSplitModel shopSplitModel, bool instantly, out NotificationError.Type errorType)"
            inline constexpr std::uintptr_t IsTraderCanBuyItemCategoryOnLocation = 0xA3AE80; // "private bool IsTraderCanBuyItemCategoryOnLocation(LocationNpcDescription trader, BuyItemSlotModel item)"
            inline constexpr std::uintptr_t TraderHasSlotToBuy = 0xA3BC10; // "private bool TraderHasSlotToBuy(InventoryItemDescription inventoryItemDescription, out IItemMoveContext toContext)"
            inline constexpr std::uintptr_t TryTraderBuy_2 = 0xA3D820; // "public bool TryTraderBuy(TraderItemMoveContext from, int buyCount, IItemMoveContext toContext, ItemMoveModel itemMoveModel, ShopSplitModel shopSplitModel, bool instantly, out NotificationError.Type errorType)"
            inline constexpr std::uintptr_t ApplyTakeCommands = 0xA2E0C0; // "private void ApplyTakeCommands(int startIndex, ExternalItemMoveContext fromContext)"
            inline constexpr std::uintptr_t TryTakeItem = 0xA3D500; // "private bool TryTakeItem(ExternalItemMoveContext fromContext, out int addedCommandsCount)"
            inline constexpr std::uintptr_t FillCommandsForEquip = 0xA36C80; // "private int FillCommandsForEquip(int entityId, IItemActionModel fromModel, InventorySlotDescription fromSlot, InventoryItemDescription item, int durability)"
            inline constexpr std::uintptr_t FillCommandsForPocket = 0xA37730; // "private int FillCommandsForPocket(int entityId, IItemActionModel fromModel, InventorySlotDescription fromSlot, InventoryItemDescription item, int count)"
            inline constexpr std::uintptr_t FillCommandsForInventoryStackable = 0xA36EB0; // "private int FillCommandsForInventoryStackable(int entityId, IItemActionModel fromModel, InventorySlotDescription fromSlot, InventoryItemDescription item, int count)"
            inline constexpr std::uintptr_t FillCommandsForInventory = 0xA37360; // "private void FillCommandsForInventory(int entityId, IItemActionModel fromModel, InventorySlotDescription fromSlot, int count)"
            inline constexpr std::uintptr_t ApplyTakeCommand = 0xA2DA90; // "private void ApplyTakeCommand(InventoryTakeCommand command, ExternalItemMoveContext context)"
            inline constexpr std::uintptr_t UnequipSlotToInventory = 0xA3DFE0; // "private bool UnequipSlotToInventory(IItemMoveContext fromContext, out IItemMoveContext toContext, out int count)"
            inline constexpr std::uintptr_t EquipInventoryToEquip = 0xA368A0; // "private bool EquipInventoryToEquip(IItemMoveContext fromContext, out IItemMoveContext toContext, out int count)"
            inline constexpr std::uintptr_t EquipInventoryToPocket = 0xA36B60; // "private bool EquipInventoryToPocket(IItemMoveContext fromContext, out IItemMoveContext toContext, out int count)"
            inline constexpr std::uintptr_t GetEmptyEquipSlotForEquip = 0xA39F10; // "private IEquipSlotModel GetEmptyEquipSlotForEquip(IEquipSlotsModel equipSlots, InventoryItemDescription item, int durability)"
            inline constexpr std::uintptr_t FindPocketSlotForMove = 0xA39CF0; // "private bool FindPocketSlotForMove(IItemMoveContext fromContext, out IItemMoveContext resultContext, out int count)"
            inline constexpr std::uintptr_t CanSwapWithIInventory = 0xA34B70; // "private bool CanSwapWithIInventory(IInventoryItemMoveContext firstFromContext, IItemMoveContext firstToContext, IItemMoveContext secondFromContext, out IInventorySlotModel outSlot, Func<IItemActionModel, IItemActionModel, IItemActionModel, IItemActionModel, bool> canSwap)"
            inline constexpr std::uintptr_t SlotToSlot = 0xA3B4D0; // "private ValueTuple<bool, bool, IInventorySlotModel, IInventorySlotModel, IInventorySlotModel, int, NotificationError.Type> SlotToSlot(IItemMoveContext from, IItemMoveContext to, int count)"
            inline constexpr std::uintptr_t SlotToIInventory = 0xA3B0B0; // "private ValueTuple<bool, bool, IInventorySlotModel, IInventorySlotModel, IInventorySlotModel, int, NotificationError.Type> SlotToIInventory(IItemMoveContext fromContext, IInventoryItemMoveContext toContext, int count)"
            inline constexpr std::uintptr_t IInventoryToSlot = 0xA3A640; // "private ValueTuple<bool, bool, IInventorySlotModel, IInventorySlotModel, IInventorySlotModel, int, NotificationError.Type> IInventoryToSlot(IInventoryItemMoveContext fromContext, IItemMoveContext toContext, int count)"
            inline constexpr std::uintptr_t IInventoryToIInventory = 0xA3A160; // "private ValueTuple<bool, bool, IInventorySlotModel, IInventorySlotModel, IInventorySlotModel, int, NotificationError.Type> IInventoryToIInventory(IInventoryItemMoveContext fromContext, IInventoryItemMoveContext toContext, int count)"
            inline constexpr std::uintptr_t TraderToSlot = 0xA3BE00; // "private ValueTuple<bool, bool, IInventorySlotModel, IInventorySlotModel, IInventorySlotModel, int, NotificationError.Type> TraderToSlot(TraderItemMoveContext fromContext, IItemMoveContext toContext, int count)"
            inline constexpr std::uintptr_t SlotToCollection = 0xA3AF30; // "private ValueTuple<bool, bool, IInventorySlotModel, IInventorySlotModel, IInventorySlotModel, int, NotificationError.Type> SlotToCollection(IItemMoveContext fromContext, CollectionItemMoveContext toContext)"
            inline constexpr std::uintptr_t CanMoveToIInventory = 0xA33370; // "private ValueTuple<bool, bool, IInventoryItemMoveContext, int, IInventoryItemMoveContext> CanMoveToIInventory(IItemMoveContext fromContext, IInventoryItemMoveContext toContext, int count, IInventorySlotModel ignoreSlot, Func<IItemActionModel, IItemActionModel, int, bool> checkMove)"
            inline constexpr std::uintptr_t FindItemInRectangle = 0xA39660; // "private ValueTuple<bool, int> FindItemInRectangle(IInventoryModel inventory, InventoryItemDescription item, int slotX, int slotY, IInventorySlotModel ignoreSlot)"
            inline constexpr std::uintptr_t CanMoveToSlot = 0xA33B30; // "private bool CanMoveToSlot(IItemMoveContext fromContext, IItemMoveContext toContext, int count, out int canMoveCount)"
            inline constexpr std::uintptr_t CanMoveToNotEmptySlot = 0xA339F0; // "private bool CanMoveToNotEmptySlot(InventoryItemDescription item, IItemMoveContext toContext, int count, out int canMoveCount)"
            inline constexpr std::uintptr_t CanFillStack = 0xA2FAF0; // "private bool CanFillStack(InventoryItemDescription from, InventoryItemDescription to, int stackCount)"
            inline constexpr std::uintptr_t CountForFullStack = 0xA36530; // "private int CountForFullStack(int moveCount, int haveCount, int stackSize)"
            inline constexpr std::uintptr_t CheckMove = 0xA35E50; // "private bool CheckMove(IItemActionModel fromModel, IItemActionModel toModel, int count)"
            inline constexpr std::uintptr_t CheckSwap = 0xA362D0; // "private bool CheckSwap(IItemActionModel firstModel, IItemActionModel secondModelDestination, IItemActionModel secondModel, IItemActionModel firstModelDestination)"
            inline constexpr std::uintptr_t CreateIInventoryItemMoveContext = 0xA36540; // "private IInventoryItemMoveContext CreateIInventoryItemMoveContext(IInventoryItemMoveContext context, IInventorySlotModel slot)"
            inline constexpr std::uintptr_t IsBusySlot = 0xA3AB80; // "public bool IsBusySlot(IItemMoveContext context)"
            inline constexpr std::uintptr_t CarUpgradeSlotToCarUpgradeSlot = 0xA354D0; // "private ValueTuple<bool, bool, IInventorySlotModel, IInventorySlotModel, IInventorySlotModel, int, NotificationError.Type> CarUpgradeSlotToCarUpgradeSlot(CarUpgradeMoveContext from, CarUpgradeMoveContext to)"
            inline constexpr std::uintptr_t InventoryToCarUpgradeSlot = 0xA3A980; // "private ValueTuple<bool, bool, IInventorySlotModel, IInventorySlotModel, IInventorySlotModel, int, NotificationError.Type> InventoryToCarUpgradeSlot(IInventoryItemMoveContext from, CarUpgradeMoveContext to)"
            inline constexpr std::uintptr_t CarUpgradeSlotToInventory = 0xA356E0; // "private ValueTuple<bool, bool, IInventorySlotModel, IInventorySlotModel, IInventorySlotModel, int, NotificationError.Type> CarUpgradeSlotToInventory(CarUpgradeMoveContext from, IInventoryItemMoveContext to)"
            inline constexpr std::uintptr_t CanMoveFromInventoryToCarUpgrade = 0xA2FF10; // "private bool CanMoveFromInventoryToCarUpgrade(CarUpgradesSlotsModel upgradesSlotsModel, CarDescription carDescription, IItemMoveContext from, CarUpgradeMoveContext to)"
            inline constexpr std::uintptr_t CanSwapInventoryItemWithCarUpgrade = 0xA34780; // "private bool CanSwapInventoryItemWithCarUpgrade(CarUpgradesSlotsModel upgradesSlotsModel, CarDescription carDescription, IInventoryItemMoveContext from, CarUpgradeMoveContext to, out IInventorySlotModel toSlot)"
            inline constexpr std::uintptr_t CanMoveFromCarUpgradeToInventory = 0xA2FB50; // "private bool CanMoveFromCarUpgradeToInventory(CarUpgradesSlotsModel upgradesSlotsModel, CarDescription carDescription, CarUpgradeMoveContext from, IItemMoveContext to)"
            inline constexpr std::uintptr_t CanSwapCarUpgradeWithInventoryItem = 0xA342F0; // "private bool CanSwapCarUpgradeWithInventoryItem(CarUpgradesSlotsModel upgradesSlotsModel, CarDescription carDescription, CarUpgradeMoveContext from, IInventoryItemMoveContext to, out IInventorySlotModel firstTo, out IInventorySlotModel fromSlot)"
            inline constexpr std::uintptr_t CanMoveFromInventoryToCarUpgrade_T_inst_1 = 0x16CF070; // "InventoryIntention.CanMoveFromInventoryToCarUpgrade<object>"
            inline constexpr std::uintptr_t CanSwapInventoryWithCarUpgrade_T_inst_1 = 0x16D0440; // "InventoryIntention.CanSwapInventoryWithCarUpgrade<object>"
            inline constexpr std::uintptr_t CanMoveFromCarUpgradeToInventory_T_inst_1 = 0x16CEAF0; // "InventoryIntention.CanMoveFromCarUpgradeToInventory<object>"
            inline constexpr std::uintptr_t CanSwapCarUpgradeWithInventory_T_inst_1 = 0x16CFA50; // "InventoryIntention.CanSwapCarUpgradeWithInventory<object>"
            inline constexpr std::uintptr_t CheckSwapCarUpgradesWithInventory = 0xA35F90; // "private bool CheckSwapCarUpgradesWithInventory(IItemActionModel firstModel, IItemActionModel secondModelDestination, IItemActionModel secondModel, IItemActionModel firstModelDestination)"
            inline constexpr std::uintptr_t CheckMoveCarUpgradeToInventory = 0xA35A60; // "private bool CheckMoveCarUpgradeToInventory(IItemActionModel from, IItemActionModel to, int count)"
            inline constexpr std::uintptr_t CheckUnsetInventorySlot = 0xA36390; // "private bool CheckUnsetInventorySlot(IItemMoveContext from, out InventoryItemDescription item)"
            inline constexpr std::uintptr_t CheckSetItemInInventorySlot = 0xA35ED0; // "private bool CheckSetItemInInventorySlot(IItemMoveContext toSlot, InventoryItemDescription itemDescription)"
            inline constexpr std::uintptr_t CheckUpgradeSlotsExist_T_inst_1 = 0x16D0770; // "InventoryIntention.CheckUpgradeSlotsExist<object>"
            // "InventoryIntention.CheckUpgradeSlotsExist<__Il2CppFullySharedGenericType>"
            inline constexpr std::uintptr_t DefenseBlockSlotToInventory_T_inst_1 = 0x16D0DB0; // "InventoryIntention.DefenseBlockSlotToInventory<object>"
            inline constexpr std::uintptr_t DefenseBlockSlotToInventory_T_inst_2 = 0x16D0C40; // "InventoryIntention.DefenseBlockSlotToInventory<__Il2CppFullySharedGenericType>"
            inline constexpr std::uintptr_t CanMoveFromDefenseBlockToInventory_T_inst_1 = 0x16CEFA0; // "InventoryIntention.CanMoveFromDefenseBlockToInventory<object>"
            inline constexpr std::uintptr_t CanMoveFromDefenseBlockToInventory_T_inst_2 = 0x16CEED0; // "InventoryIntention.CanMoveFromDefenseBlockToInventory<__Il2CppFullySharedGenericType>"
            inline constexpr std::uintptr_t CanSwapDefenseBlockWithInventoryItem_T_inst_1 = 0x16D0300; // "InventoryIntention.CanSwapDefenseBlockWithInventoryItem<object>"
            inline constexpr std::uintptr_t CanSwapDefenseBlockWithInventoryItem_T_inst_2 = 0x16D01C0; // "InventoryIntention.CanSwapDefenseBlockWithInventoryItem<__Il2CppFullySharedGenericType>"
            inline constexpr std::uintptr_t InventoryToDefenseBlockSlot_T_inst_1 = 0x16D1120; // "InventoryIntention.InventoryToDefenseBlockSlot<object>"
            inline constexpr std::uintptr_t InventoryToDefenseBlockSlot_T_inst_2 = 0x16D1000; // "InventoryIntention.InventoryToDefenseBlockSlot<__Il2CppFullySharedGenericType>"
            inline constexpr std::uintptr_t CanMoveOrSwapFromInventoryToDefenseBlock_T_inst_1 = 0x16CF6F0; // "InventoryIntention.CanMoveOrSwapFromInventoryToDefenseBlock<object>"
            inline constexpr std::uintptr_t CanMoveOrSwapFromInventoryToDefenseBlock_T_inst_2 = 0x16CF390; // "InventoryIntention.CanMoveOrSwapFromInventoryToDefenseBlock<__Il2CppFullySharedGenericType>"
            inline constexpr std::uintptr_t DefenseBlockSlotToDefenseBlockSlot_T_inst_1 = 0x16D0AC0; // "InventoryIntention.DefenseBlockSlotToDefenseBlockSlot<object>"
            inline constexpr std::uintptr_t DefenseBlockSlotToDefenseBlockSlot_T_inst_2 = 0x16D0930; // "InventoryIntention.DefenseBlockSlotToDefenseBlockSlot<__Il2CppFullySharedGenericType>"
        }
    } // namespace InventoryIntention

    namespace InventoryItem { // "Models.References.Inventory.InventoryItem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Description = 0x10; // "InventoryItemDescription"
            inline constexpr std::uintptr_t Count = 0x18; // "int"
            inline constexpr std::uintptr_t Ammo = 0x1C; // "int"
            inline constexpr std::uintptr_t Durability = 0x20; // "int"
            inline constexpr std::uintptr_t CumulativePoints = 0x24; // "int"
        }
    } // namespace InventoryItem

    namespace InventoryItemActionModel { // "Models.Inventory.ItemActionModel.InventoryItemActionModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t inventoryModel = 0x10; // "IInventoryModel"
            inline constexpr std::uintptr_t slotModel = 0x18; // "IInventorySlotModel"
            inline constexpr std::uintptr_t reloadModel = 0x20; // "WeaponReloadModel"
            inline constexpr std::uintptr_t selectedQuickSlot = 0x28; // "SelectedQuickSlotModel"
            inline constexpr std::uintptr_t contextMenuUseItemModel = 0x30; // "ContextMenuUseItemModel"
            inline constexpr std::uintptr_t quickSlotSelectProgress = 0x38; // "QuickSlotSelectProgressModel"
            inline constexpr std::uintptr_t inventoryUseItemModel = 0x40; // "InventoryUseItemModel"
            inline constexpr std::uintptr_t reloadParamsModel = 0x48; // "ReloadParamsModel"
            inline constexpr std::uintptr_t worldEntitiesModel = 0x50; // "WorldEntitiesModel"
            inline constexpr std::uintptr_t prolongedInteractionModel = 0x58; // "ProlongedInteractionModel"
            inline constexpr std::uintptr_t unlockSafeDoorConfig = 0x60; // "UnlockSafeDoorConfig"
            inline constexpr std::uintptr_t evictPriceItem = 0x68; // "InventoryItemDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_SlotModel = 0x7E7130; // "public IInventorySlotModel get_SlotModel()"
            inline constexpr std::uintptr_t get_InventoryModel = 0x7EC6B0; // "public IInventoryModel get_InventoryModel()"
            inline constexpr std::uintptr_t TrySet = 0x4A521B0; // "public bool TrySet(IInventoryModel inventoryModel, InventorySlotDescription slot, WeaponReloadModel reloadModel, SelectedQuickSlotModel selectedQuickSlot, ContextMenuUseItemModel contextMenuUseItemModel, QuickSlotSelectProgressModel quickSlotSelectProgress, InventoryUseItemModel inventoryUseItemModel, ReloadParamsModel reloadParamsModel, WorldEntitiesModel worldEntitiesModel, ProlongedInteractionModel prolongedInteractionModel)"
            inline constexpr std::uintptr_t CheckSet = 0x4A51590; // "public bool CheckSet(InventoryItemDescription item, int count, int ammo, int durability, int cumulativePoints, out bool isSet)"
            inline constexpr std::uintptr_t CheckMoveTo = 0x4A51310; // "public bool CheckMoveTo(InventoryItemDescription item, int count, int ammo, int durability, int cumulativePoints, IItemActionModel fromModel, out bool isSet)"
            inline constexpr std::uintptr_t CheckMoveFrom = 0x4A51150; // "public bool CheckMoveFrom(int count, out InventoryItemDescription item, out int ammo, out int durability, out int cumulativePoints, out bool isUnset)"
            inline constexpr std::uintptr_t CheckUnset = 0x4A516A0; // "public bool CheckUnset()"
            inline constexpr std::uintptr_t CheckSwap = 0x4A51660; // "public bool CheckSwap(InventoryItemDescription item, int count, int ammo, int durability, int cumulativePoints)"
            inline constexpr std::uintptr_t TryGetContent = 0x4A51FB0; // "public bool TryGetContent(out InventoryItemDescription item, out int count, out int ammo, out int durability, out int cumulativePoints)"
            inline constexpr std::uintptr_t AreEqual = 0x4A50F90; // "public bool AreEqual(IItemActionModel other)"
            inline constexpr std::uintptr_t Set = 0x4A51E40; // "public void Set(long now, InventoryItemDescription item, int count, int ammo, int durability, int cumulativePoints)"
            inline constexpr std::uintptr_t Unset = 0x4A52350; // "public void Unset()"
            inline constexpr std::uintptr_t ChangeStack = 0x4A510B0; // "public void ChangeStack(int count)"
            inline constexpr std::uintptr_t ChangeAmmo = 0x4A51010; // "public void ChangeAmmo(int ammo)"
            inline constexpr std::uintptr_t MarkSelectedQuickSlotItemChanged = 0x4A51E10; // "private void MarkSelectedQuickSlotItemChanged()"
            inline constexpr std::uintptr_t StopReload = 0x4A51F40; // "private void StopReload()"
            inline constexpr std::uintptr_t IsSelectedSlot = 0x4A51D70; // "private bool IsSelectedSlot()"
            inline constexpr std::uintptr_t get_IsUsed = 0x4A52800; // "private bool get_IsUsed()"
            inline constexpr std::uintptr_t get_IsSlotBusy = 0x4A524D0; // "public bool get_IsSlotBusy()"
            inline constexpr std::uintptr_t IsLockedByUnlockModel = 0x4A51BF0; // "private bool IsLockedByUnlockModel()"
            inline constexpr std::uintptr_t IsLockedBySetDrillModel = 0x4A519A0; // "private bool IsLockedBySetDrillModel()"
            inline constexpr std::uintptr_t IsLockedByRaidDefenseModel = 0x4A51910; // "private bool IsLockedByRaidDefenseModel()"
            inline constexpr std::uintptr_t IsDrillInProgress = 0x4A51750; // "private bool IsDrillInProgress()"
            inline constexpr std::uintptr_t IsMiniDrillInProgress = 0x4A51C80; // "private bool IsMiniDrillInProgress()"
            inline constexpr std::uintptr_t IsLockedByEvictModel = 0x4A51840; // "private bool IsLockedByEvictModel()"
            inline constexpr std::uintptr_t CheckUnloadAmmo = 0x7D5050; // "public bool CheckUnloadAmmo(long now)"
        }
    } // namespace InventoryItemActionModel

    namespace InventoryItemAmmoMaxUpdater { // "Game.Battle.Inventory.Slot.InventoryItemAmmoMaxUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "IInventoryItemModel"
            inline constexpr std::uintptr_t ammoModel = 0x18; // "IAmmoModel"
            inline constexpr std::uintptr_t groupsInventoryItemsModel = 0x20; // "GroupsInventoryItemsModel"
            inline constexpr std::uintptr_t view = 0x28; // "InventoryItemAmmoMaxView"
            inline constexpr std::uintptr_t ammoCount = 0x30; // "Nullable<int>"
            inline constexpr std::uintptr_t ammoCountMax = 0x38; // "Nullable<int>"
            inline constexpr std::uintptr_t isActive = 0x40; // "Nullable<bool>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA7AE20; // "public void Update()"
        }
    } // namespace InventoryItemAmmoMaxUpdater

    namespace InventoryItemAmmoMaxView { // "Game.Battle.Inventory.Slot.InventoryItemAmmoMaxView (Battle.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x82730E8; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace Fields {
            inline constexpr std::uintptr_t ammoTmp = 0x20; // "TextMeshProUGUI"
            inline constexpr std::uintptr_t colorStyle = 0x28; // "ColorStyleViewDescription"
            inline constexpr std::uintptr_t ammoCountValue = 0x30; // "int"
            inline constexpr std::uintptr_t ammoCountMaxValue = 0x34; // "int"
            inline constexpr std::uintptr_t isShow = 0x38; // "Nullable<bool>"
            inline constexpr std::uintptr_t renderedAmmoCount = 0x3C; // "Nullable<int>"
            inline constexpr std::uintptr_t renderedAmmoCountMax = 0x44; // "Nullable<int>"
            inline constexpr std::uintptr_t renderedAmmoColor = 0x50; // "string"
            inline constexpr std::uintptr_t renderedAmmoMaxColor = 0x58; // "string"
        }
        namespace StaticFields {
            inline constexpr std::uintptr_t stringBuilder = 0x0; // "StringBuilder"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetAmmoCount = 0xA7B1F0; // "public void SetAmmoCount(int currentAmmo, int maxAmmo)"
            inline constexpr std::uintptr_t Hide = 0xA7B160; // "public void Hide()"
            inline constexpr std::uintptr_t SetSelected = 0xA7B270; // "public void SetSelected(bool value)"
            inline constexpr std::uintptr_t UpdateColorsAndEnabled = 0xA7B280; // "private void UpdateColorsAndEnabled()"
        }
    } // namespace InventoryItemAmmoMaxView

    namespace InventoryItemAmmoView { // "Game.Battle.Inventory.Slot.InventoryItemAmmoView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ammoCount = 0x20; // "TextMeshProUGUI"
            inline constexpr std::uintptr_t ammoPalette = 0x28; // "GraphicsPalette"
            inline constexpr std::uintptr_t colorStyle = 0x30; // "ColorStyleViewDescription"
            inline constexpr std::uintptr_t notEnoughMoneyStyle = 0x38; // "ColorStyleViewDescription"
            inline constexpr std::uintptr_t isEnoughMoney = 0x40; // "bool"
            inline constexpr std::uintptr_t ammoCountValue = 0x44; // "int"
            inline constexpr std::uintptr_t isShow = 0x48; // "Nullable<bool>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Reset = 0xA7B6D0; // "public void Reset()"
            inline constexpr std::uintptr_t SetAmmoCount = 0xA7B6E0; // "public void SetAmmoCount(int value, string ammoSymbol, ItemAmmoType itemAmmoType)"
            inline constexpr std::uintptr_t Hide = 0xA7B640; // "public void Hide()"
            inline constexpr std::uintptr_t SetEnoughMoney = 0xA7B7D0; // "public void SetEnoughMoney(bool enable)"
            inline constexpr std::uintptr_t UpdateColorsAndEnabled = 0xA7B7E0; // "private void UpdateColorsAndEnabled()"
        }
    } // namespace InventoryItemAmmoView

    namespace InventoryItemCellsSize { // "Models.References.Inventory.InventoryItemCellsSize (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t CountX = 0x0; // "int"
            inline constexpr std::uintptr_t CountY = 0x4; // "int"
        }
    } // namespace InventoryItemCellsSize

    namespace InventoryItemCollectionView { // "Game.Battle.Inventory.Slot.InventoryItemCollectionView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t text = 0x20; // "TextMeshProUGUI"
            inline constexpr std::uintptr_t progressState = 0x28; // "StateGroup"
            inline constexpr std::uintptr_t count = 0x30; // "int"
            inline constexpr std::uintptr_t needCount = 0x34; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetCount = 0xA7B8A0; // "public void SetCount(int count, int needCount)"
        }
    } // namespace InventoryItemCollectionView

    namespace InventoryItemCostView { // "Game.Battle.Inventory.InventoryItemCostView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t currentAmountPalette = 0x20; // "GraphicsPalette"
            inline constexpr std::uintptr_t currentMoney = 0x28; // "TextLabel<Money>"
            inline constexpr std::uintptr_t moneyState = 0x30; // "EnumStateElement<MoneyType>"
            inline constexpr std::uintptr_t moneyColor = 0x38; // "ColorStyleViewDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t ClearView = 0xA5E180; // "public void ClearView()"
            inline constexpr std::uintptr_t SetMonetState = 0xA5E290; // "public void SetMonetState(MoneyType moneyType)"
            inline constexpr std::uintptr_t ShowCurrency = 0xA5E2F0; // "public void ShowCurrency(bool value)"
            inline constexpr std::uintptr_t SetCurrentCount = 0xA5E1E0; // "public void SetCurrentCount(Money amount)"
            inline constexpr std::uintptr_t SetEnoughMoney = 0xA5E250; // "public void SetEnoughMoney(bool enough)"
            inline constexpr std::uintptr_t Content_ContentWrappers_IComponentContent_ResetOnDisposeContent = 0xA5E1B0; // "private void Content.ContentWrappers.IComponentContent.ResetOnDisposeContent()"
        }
    } // namespace InventoryItemCostView

    namespace InventoryItemCountUpdater { // "Game.Battle.Inventory.Slot.InventoryItemCountUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t view = 0x20; // "InventoryItemCountView"
            inline constexpr std::uintptr_t itemModel = 0x28; // "IInventoryItemModel"
            inline constexpr std::uintptr_t stackModel = 0x30; // "IInventoryStackModel"
            inline constexpr std::uintptr_t count = 0x38; // "Nullable<int>"
            inline constexpr std::uintptr_t isActive = 0x40; // "Nullable<bool>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA7BB60; // "public InventoryItemCountUpdater Init(IInventoryItemModel itemModel, IInventoryStackModel stackModel, InventoryItemCountView view)"
            inline constexpr std::uintptr_t Dispose = 0xA7B9B0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA7BBD0; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t GetTextValue = 0xA7BA00; // "private string GetTextValue(InventoryItemDescription itemDescription, IInventoryStackModel stackModel)"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace InventoryItemCountUpdater

    namespace InventoryItemCountView { // "Game.Battle.Inventory.Slot.InventoryItemCountView (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t count = 0x20; // "TextMeshProUGUI"
            inline constexpr std::uintptr_t countPalette = 0x28; // "GraphicsPalette"
            inline constexpr std::uintptr_t colorStyle = 0x30; // "ColorStyleViewDescription"
            inline constexpr std::uintptr_t isEnoughMoney = 0x38; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetCount = 0x3559900; // "public void SetCount(string textValue)"
            inline constexpr std::uintptr_t ClearCount = 0x35598B0; // "public void ClearCount()"
            inline constexpr std::uintptr_t SetEnoughMoney = 0x3559950; // "public void SetEnoughMoney(bool enable)"
            inline constexpr std::uintptr_t UpdateColors = 0x3559990; // "private void UpdateColors()"
        }
    } // namespace InventoryItemCountView

    namespace InventoryItemCumulativeView { // "Game.Battle.Inventory.Slot.InventoryItemCumulativeView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t progressBar = 0x20; // "SlicedFilledImage"
            inline constexpr std::uintptr_t stateGroup = 0x28; // "StateGroup"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetProgress = 0xA7BF30; // "public void SetProgress(int current, int max)"
        }
    } // namespace InventoryItemCumulativeView

    namespace InventoryItemDelayLockUpdater { // "Game.Battle.Inventory.Slot.InventoryItemDelayLockUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t equipSlotModel = 0x20; // "IEquipSlotModel"
            inline constexpr std::uintptr_t equipSlotsDelaysModel = 0x28; // "EquipSlotsDelaysModel"
            inline constexpr std::uintptr_t now = 0x30; // "INow"
            inline constexpr std::uintptr_t view = 0x38; // "InventoryItemDelayLockView"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA7BFD0; // "public InventoryItemDelayLockUpdater Init(IEquipSlotModel equipSlotModel, EquipSlotsDelaysModel equipSlotsDelaysModel, INow now, InventoryItemDelayLockView view)"
            inline constexpr std::uintptr_t Dispose = 0x9F4BF0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA7C090; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace InventoryItemDelayLockUpdater

    namespace InventoryItemDelayLockView { // "Game.Battle.Inventory.Slot.InventoryItemDelayLockView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t canvasGroup = 0x20; // "CanvasGroup"
            inline constexpr std::uintptr_t loopAnimation = 0x28; // "AlphaCanvasGroupTweenAnimation"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsPlaying = 0xA7C2E0; // "public bool get_IsPlaying()"
            inline constexpr std::uintptr_t Play = 0xA7C2C0; // "public void Play()"
            inline constexpr std::uintptr_t Stop = 0xA7C280; // "public void Stop()"
            inline constexpr std::uintptr_t OnDisable = 0xA7C280; // "private void OnDisable()"
        }
    } // namespace InventoryItemDelayLockView

    namespace InventoryItemDescription { // "Models.References.Inventory.InventoryItemDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Type = 0x20; // "InventoryItemType"
            inline constexpr std::uintptr_t CellsSize = 0x24; // "InventoryItemCellsSize"
            inline constexpr std::uintptr_t StackSize = 0x2C; // "int"
            inline constexpr std::uintptr_t Rarity = 0x30; // "RarityItem"
            inline constexpr std::uintptr_t IsStackable = 0x34; // "bool"
            inline constexpr std::uintptr_t UsableItemFunc = 0x38; // "Func<UsableItemDescription>"
            inline constexpr std::uintptr_t ThrowableItemFunc = 0x40; // "Func<ThrowableItemDescription>"
            inline constexpr std::uintptr_t ArmorFunc = 0x48; // "Func<ArmorDescription>"
            inline constexpr std::uintptr_t WeaponFunc = 0x50; // "Func<WeaponDescription>"
            inline constexpr std::uintptr_t InventoryLines = 0x58; // "int"
            inline constexpr std::uintptr_t IsBackpack = 0x5C; // "bool"
            inline constexpr std::uintptr_t PocketCount = 0x60; // "int"
            inline constexpr std::uintptr_t IsBelt = 0x64; // "bool"
            inline constexpr std::uintptr_t AmmoFunc = 0x68; // "Func<AmmoDescription>"
            inline constexpr std::uintptr_t IsKey = 0x70; // "bool"
            inline constexpr std::uintptr_t BasePriceFunc = 0x78; // "Func<int>"
            inline constexpr std::uintptr_t SellPriceModifierFunc = 0x80; // "Func<InventoryItemSellPriceModifier>"
            inline constexpr std::uintptr_t SellPriceFunc = 0x88; // "Func<int>"
            inline constexpr std::uintptr_t Durability = 0x90; // "int"
            inline constexpr std::uintptr_t HasDurability = 0x94; // "bool"
            inline constexpr std::uintptr_t IsSellAvailable = 0x95; // "bool"
            inline constexpr std::uintptr_t CarFunc = 0x98; // "Func<CarSlotDescription>"
            inline constexpr std::uintptr_t HelicopterFunc = 0xA0; // "Func<HelicopterSlotDescription>"
            inline constexpr std::uintptr_t MainBuildingDescriptionFunc = 0xA8; // "Func<MainBuildingDescription>"
            inline constexpr std::uintptr_t CompoundWallDescriptionFunc = 0xB0; // "Func<CompoundWallDescription>"
            inline constexpr std::uintptr_t OutbuildingDescriptionFunc = 0xB8; // "Func<OutbuildingDescription>"
            inline constexpr std::uintptr_t CollectionTableFunc = 0xC0; // "Func<CollectionTableDescription>"
            inline constexpr std::uintptr_t CargoOpenWorkbenchDescriptionFunc = 0xC8; // "Func<CargoOpenWorkbenchDescription>"
            inline constexpr std::uintptr_t CargoExchangeWorkbenchDescriptionFunc = 0xD0; // "Func<CargoExchangeWorkbenchDescription>"
            inline constexpr std::uintptr_t CargoChargeWorkbenchDescriptionFunc = 0xD8; // "Func<CargoChargeWorkbenchDescription>"
            inline constexpr std::uintptr_t StorageDescriptionFunc = 0xE0; // "Func<StorageDescription>"
            inline constexpr std::uintptr_t ShelvingDescriptionFunc = 0xE8; // "Func<ShelvingDescription>"
            inline constexpr std::uintptr_t CargoOpenWorkbenchUpgradeDescriptionFunc = 0xF0; // "Func<CargoOpenWorkbenchUpgradeDescription>"
            inline constexpr std::uintptr_t CargoExchangeWorkbenchUpgradeDescriptionFunc = 0xF8; // "Func<CargoExchangeWorkbenchUpgradeDescription>"
            inline constexpr std::uintptr_t CollectionTableUpgradeSlotDescriptionFunc = 0x100; // "Func<CollectionTableUpgradeSlotDescription>"
            inline constexpr std::uintptr_t MoneyWorkbenchUpgradeDescriptionFunc = 0x108; // "Func<MoneyWorkbenchUpgradeDescription>"
            inline constexpr std::uintptr_t AlarmCarUpgradeDescriptionFunc = 0x110; // "Func<AlarmCarUpgradeDescription>"
            inline constexpr std::uintptr_t PoliceRadioCarUpgradeDescriptionFunc = 0x118; // "Func<PoliceRadioCarUpgradeDescription>"
            inline constexpr std::uintptr_t HornCarUpgradeDescriptionFunc = 0x120; // "Func<HornCarUpgradeDescription>"
            inline constexpr std::uintptr_t EcuCarUpgradeDescriptionFunc = 0x128; // "Func<EcuCarUpgradeDescription>"
            inline constexpr std::uintptr_t TurbochargerCarUpgradeDescriptionFunc = 0x130; // "Func<TurbochargerCarUpgradeDescription>"
            inline constexpr std::uintptr_t EngineCoolingCarUpgradeDescriptionFunc = 0x138; // "Func<EngineCoolingCarUpgradeDescription>"
            inline constexpr std::uintptr_t NitroCarUpgradeDescriptionFunc = 0x140; // "Func<NitroCarUpgradeDescription>"
            inline constexpr std::uintptr_t SuspensionCarUpgradeDescriptionFunc = 0x148; // "Func<SuspensionCarUpgradeDescription>"
            inline constexpr std::uintptr_t SteeringRackCarUpgradeDescriptionFunc = 0x150; // "Func<SteeringRackCarUpgradeDescription>"
            inline constexpr std::uintptr_t TrunkInventoryCarUpgradeDescriptionFunc = 0x158; // "Func<TrunkInventoryCarUpgradeDescription>"
            inline constexpr std::uintptr_t TrunkCargoInventoryCarUpgradeDescriptionFunc = 0x160; // "Func<TrunkCargoInventoryCarUpgradeDescription>"
            inline constexpr std::uintptr_t CumulativeItemDescriptionFunc = 0x168; // "Func<CumulativeItemDescription>"
            inline constexpr std::uintptr_t DefenseBlockDefenseModuleDescriptionFunc = 0x170; // "Func<DefenseBlockDefenseModuleDescription>"
            inline constexpr std::uintptr_t DefenseBlockSpecialModuleDescriptionFunc = 0x178; // "Func<DefenseBlockSpecialModuleDescription>"
            inline constexpr std::uintptr_t PlotBuildingDecoderDescriptionFunc = 0x180; // "Func<PlotBuildingDecoderDescription>"
            inline constexpr std::uintptr_t FirstAidCabinetDescriptionFunc = 0x188; // "Func<FirstAidCabinetDescription>"
            inline constexpr std::uintptr_t BillOfSaleDescriptionFunc = 0x190; // "Func<BillOfSaleDescription>"
            inline constexpr std::uintptr_t PoliceBadgeDescriptionFunc = 0x198; // "Func<PoliceBadgeDescription>"
            inline constexpr std::uintptr_t CargoProductionWorkbenchDescriptionFunc = 0x1A0; // "Func<CargoProductionWorkbenchDescription>"
            inline constexpr std::uintptr_t CargoProductionWorkbenchResultWeightsUpgradeDescriptionFunc = 0x1A8; // "Func<CargoProductionWorkbenchResultWeightsUpgradeDescription>"
            inline constexpr std::uintptr_t CargoChargeWorkbenchSpeedupUpgradeDescriptionFunc = 0x1B0; // "Func<CargoChargeWorkbenchSpeedupUpgradeDescription>"
            inline constexpr std::uintptr_t CryptoWorkbenchDescriptionFunc = 0x1B8; // "Func<CryptoWorkbenchDescription>"
            inline constexpr std::uintptr_t VideoCardDescriptionFunc = 0x1C0; // "Func<VideoCardDescription>"
            inline constexpr std::uintptr_t CryptoWorkbenchEfficiencyUpgradeDescriptionFunc = 0x1C8; // "Func<CryptoWorkbenchEfficiencyUpgradeDescription>"
            inline constexpr std::uintptr_t CryptoWorkbenchSpeedupUpgradeDescriptionFunc = 0x1D0; // "Func<CryptoWorkbenchSpeedupUpgradeDescription>"
            inline constexpr std::uintptr_t RouletteChipDescriptionFunc = 0x1D8; // "Func<RouletteChipDescription>"
            inline constexpr std::uintptr_t BoltCutterDescriptionFunc = 0x1E0; // "Func<BoltCutterDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsConsumable = 0x43E8700; // "public bool get_IsConsumable()"
            inline constexpr std::uintptr_t get_UsableItem = 0x2AA0B60; // "public UsableItemDescription get_UsableItem()"
            inline constexpr std::uintptr_t get_IsUsable = 0x40A2240; // "public bool get_IsUsable()"
            inline constexpr std::uintptr_t get_ThrowableItem = 0x4048E60; // "public ThrowableItemDescription get_ThrowableItem()"
            inline constexpr std::uintptr_t get_IsThrowable = 0x40A22C0; // "public bool get_IsThrowable()"
            inline constexpr std::uintptr_t get_IsPocketItem = 0x43E8860; // "public bool get_IsPocketItem()"
            inline constexpr std::uintptr_t get_Armor = 0x4048E90; // "public ArmorDescription get_Armor()"
            inline constexpr std::uintptr_t get_IsVest = 0x40A2180; // "public bool get_IsVest()"
            inline constexpr std::uintptr_t get_Weapon = 0x1CE7810; // "public WeaponDescription get_Weapon()"
            inline constexpr std::uintptr_t get_IsWeapon = 0x40A2140; // "public bool get_IsWeapon()"
            inline constexpr std::uintptr_t get_IsEquip = 0x43E87A0; // "public bool get_IsEquip()"
            inline constexpr std::uintptr_t get_IsEquipNotWeapon = 0x43E8750; // "public bool get_IsEquipNotWeapon()"
            inline constexpr std::uintptr_t get_Ammo = 0x4048EF0; // "public AmmoDescription get_Ammo()"
            inline constexpr std::uintptr_t get_IsAmmo = 0x43E8630; // "public bool get_IsAmmo()"
            inline constexpr std::uintptr_t get_BasePrice = 0x4048F20; // "public int get_BasePrice()"
            inline constexpr std::uintptr_t get_SellPriceModifier = 0x4048F50; // "public InventoryItemSellPriceModifier get_SellPriceModifier()"
            inline constexpr std::uintptr_t get_SellPrice = 0x43E8A80; // "public int get_SellPrice()"
            inline constexpr std::uintptr_t get_IsCar = 0x43E86C0; // "public bool get_IsCar()"
            inline constexpr std::uintptr_t get_IsHelicopter = 0x43E8820; // "public bool get_IsHelicopter()"
            inline constexpr std::uintptr_t get_Car = 0x4067080; // "public CarSlotDescription get_Car()"
            inline constexpr std::uintptr_t get_Helicopter = 0x40671C0; // "public HelicopterSlotDescription get_Helicopter()"
            inline constexpr std::uintptr_t get_MainBuildingDescription = 0x4067190; // "public MainBuildingDescription get_MainBuildingDescription()"
            inline constexpr std::uintptr_t get_CompoundWallDescription = 0x4067270; // "public CompoundWallDescription get_CompoundWallDescription()"
            inline constexpr std::uintptr_t get_OutbuildingDescription = 0x4067130; // "public OutbuildingDescription get_OutbuildingDescription()"
            inline constexpr std::uintptr_t get_CollectionTable = 0x43E8360; // "public CollectionTableDescription get_CollectionTable()"
            inline constexpr std::uintptr_t get_CargoOpenWorkbenchDescription = 0x43E8260; // "public CargoOpenWorkbenchDescription get_CargoOpenWorkbenchDescription()"
            inline constexpr std::uintptr_t get_CargoExchangeWorkbenchDescription = 0x43E8200; // "public CargoExchangeWorkbenchDescription get_CargoExchangeWorkbenchDescription()"
            inline constexpr std::uintptr_t get_CargoChargeWorkbenchDescription = 0x43E81A0; // "public CargoChargeWorkbenchDescription get_CargoChargeWorkbenchDescription()"
            inline constexpr std::uintptr_t get_StorageDescription = 0x43E8B10; // "public StorageDescription get_StorageDescription()"
            inline constexpr std::uintptr_t get_ShelvingDescription = 0x43E8AB0; // "public ShelvingDescription get_ShelvingDescription()"
            inline constexpr std::uintptr_t get_CargoOpenWorkbenchUpgradeDescription = 0x43E8290; // "public CargoOpenWorkbenchUpgradeDescription get_CargoOpenWorkbenchUpgradeDescription()"
            inline constexpr std::uintptr_t get_CargoExchangeWorkbenchUpgradeDescription = 0x43E8230; // "public CargoExchangeWorkbenchUpgradeDescription get_CargoExchangeWorkbenchUpgradeDescription()"
            inline constexpr std::uintptr_t get_CollectionTableUpgradeSlotDescription = 0x43E8330; // "public CollectionTableUpgradeSlotDescription get_CollectionTableUpgradeSlotDescription()"
            inline constexpr std::uintptr_t get_MoneyWorkbenchUpgradeDescription = 0x43E8960; // "public MoneyWorkbenchUpgradeDescription get_MoneyWorkbenchUpgradeDescription()"
            inline constexpr std::uintptr_t get_AlarmCarUpgradeDescription = 0x43E7DD0; // "public AlarmCarUpgradeDescription get_AlarmCarUpgradeDescription()"
            inline constexpr std::uintptr_t get_PoliceRadioCarUpgradeDescription = 0x43E8A20; // "public PoliceRadioCarUpgradeDescription get_PoliceRadioCarUpgradeDescription()"
            inline constexpr std::uintptr_t get_HornCarUpgradeDescription = 0x43E8600; // "public HornCarUpgradeDescription get_HornCarUpgradeDescription()"
            inline constexpr std::uintptr_t get_EcuCarUpgradeDescription = 0x43E84B0; // "public EcuCarUpgradeDescription get_EcuCarUpgradeDescription()"
            inline constexpr std::uintptr_t get_TurbochargerCarUpgradeDescription = 0x43E8BD0; // "public TurbochargerCarUpgradeDescription get_TurbochargerCarUpgradeDescription()"
            inline constexpr std::uintptr_t get_EngineCoolingCarUpgradeDescription = 0x43E84E0; // "public EngineCoolingCarUpgradeDescription get_EngineCoolingCarUpgradeDescription()"
            inline constexpr std::uintptr_t get_NitroCarUpgradeDescription = 0x43E8990; // "public NitroCarUpgradeDescription get_NitroCarUpgradeDescription()"
            inline constexpr std::uintptr_t get_SuspensionCarUpgradeDescription = 0x43E8B40; // "public SuspensionCarUpgradeDescription get_SuspensionCarUpgradeDescription()"
            inline constexpr std::uintptr_t get_SteeringRackCarUpgradeDescription = 0x43E8AE0; // "public SteeringRackCarUpgradeDescription get_SteeringRackCarUpgradeDescription()"
            inline constexpr std::uintptr_t get_TrunkInventoryCarUpgradeDescription = 0x43E8BA0; // "public TrunkInventoryCarUpgradeDescription get_TrunkInventoryCarUpgradeDescription()"
            inline constexpr std::uintptr_t get_TrunkCargoInventoryCarUpgradeDescription = 0x43E8B70; // "public TrunkCargoInventoryCarUpgradeDescription get_TrunkCargoInventoryCarUpgradeDescription()"
            inline constexpr std::uintptr_t get_HasArmorOrAmmo = 0x43E8540; // "public bool get_HasArmorOrAmmo()"
            inline constexpr std::uintptr_t get_CumulativeItemDescription = 0x43E8420; // "public CumulativeItemDescription get_CumulativeItemDescription()"
            inline constexpr std::uintptr_t get_HasCumulativePoints = 0x43E85B0; // "public bool get_HasCumulativePoints()"
            inline constexpr std::uintptr_t get_DefenseBlockDefenseModuleDescription = 0x43E8450; // "public DefenseBlockDefenseModuleDescription get_DefenseBlockDefenseModuleDescription()"
            inline constexpr std::uintptr_t get_DefenseBlockSpecialModuleDescription = 0x43E8480; // "public DefenseBlockSpecialModuleDescription get_DefenseBlockSpecialModuleDescription()"
            inline constexpr std::uintptr_t get_PlotBuildingDecoderDescription = 0x43E89C0; // "public PlotBuildingDecoderDescription get_PlotBuildingDecoderDescription()"
            inline constexpr std::uintptr_t get_IsDecoder = 0x43E8710; // "public bool get_IsDecoder()"
            inline constexpr std::uintptr_t get_FirstAidCabinetDescription = 0x43E8510; // "public FirstAidCabinetDescription get_FirstAidCabinetDescription()"
            inline constexpr std::uintptr_t get_BillOfSaleDescription = 0x43E7E00; // "public BillOfSaleDescription get_BillOfSaleDescription()"
            inline constexpr std::uintptr_t get_PoliceBadgeDescription = 0x43E89F0; // "public PoliceBadgeDescription get_PoliceBadgeDescription()"
            inline constexpr std::uintptr_t get_IsPoliceBadge = 0x43E88D0; // "public bool get_IsPoliceBadge()"
            inline constexpr std::uintptr_t get_CargoProductionWorkbenchDescription = 0x43E82C0; // "public CargoProductionWorkbenchDescription get_CargoProductionWorkbenchDescription()"
            inline constexpr std::uintptr_t get_CargoProductionWorkbenchResultWeightsUpgradeDescription = 0x43E82F0; // "public CargoProductionWorkbenchResultWeightsUpgradeDescription get_CargoProductionWorkbenchResultWeightsUpgradeDescription()"
            inline constexpr std::uintptr_t get_CargoChargeWorkbenchSpeedupUpgradeDescription = 0x43E81D0; // "public CargoChargeWorkbenchSpeedupUpgradeDescription get_CargoChargeWorkbenchSpeedupUpgradeDescription()"
            inline constexpr std::uintptr_t get_CryptoWorkbenchDescription = 0x43E8390; // "public CryptoWorkbenchDescription get_CryptoWorkbenchDescription()"
            inline constexpr std::uintptr_t get_VideoCardDescription = 0x43E8C00; // "public VideoCardDescription get_VideoCardDescription()"
            inline constexpr std::uintptr_t get_CryptoWorkbenchEfficiencyUpgradeDescription = 0x43E83C0; // "public CryptoWorkbenchEfficiencyUpgradeDescription get_CryptoWorkbenchEfficiencyUpgradeDescription()"
            inline constexpr std::uintptr_t get_CryptoWorkbenchSpeedupUpgradeDescription = 0x43E83F0; // "public CryptoWorkbenchSpeedupUpgradeDescription get_CryptoWorkbenchSpeedupUpgradeDescription()"
            inline constexpr std::uintptr_t get_RouletteChipDescription = 0x43E8A50; // "public RouletteChipDescription get_RouletteChipDescription()"
            inline constexpr std::uintptr_t get_IsRouletteChip = 0x43E8910; // "public bool get_IsRouletteChip()"
            inline constexpr std::uintptr_t get_BoltCutterDescription = 0x43E7E30; // "public BoltCutterDescription get_BoltCutterDescription()"
            inline constexpr std::uintptr_t get_IsBoltCutter = 0x43E8680; // "public bool get_IsBoltCutter()"
            inline constexpr std::uintptr_t get_CarUpgradeDescription = 0x43E7E60; // "public ICarUpgradeDescription get_CarUpgradeDescription()"
            inline constexpr std::uintptr_t get_CarUpgradesHolderTypeDescription = 0x43E80D0; // "public CarUpgradesHolderTypeDescription get_CarUpgradesHolderTypeDescription()"
        }
    } // namespace InventoryItemDescription

    namespace InventoryItemDurabilityView { // "Game.Battle.Inventory.InventoryItemDurabilityView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t brokenIcons = 0x20; // "ImageExtend[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetBroken = 0xA5E320; // "public void SetBroken(bool value)"
        }
    } // namespace InventoryItemDurabilityView

    namespace InventoryItemExtensions { // "Models.Utils.Extensions.InventoryItemExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t IsItemBroken = 0x395F2F0; // "public static bool IsItemBroken(InventoryItemDescription item, IDurabilityModel durabilityModel)"
            inline constexpr std::uintptr_t IsSelectedWeaponBroken = 0x395F460; // "public static bool IsSelectedWeaponBroken(SelectedQuickSlotModel selectedQuickSlot, IEquipSlotsModel equipSlots)"
            inline constexpr std::uintptr_t IsItemBroken_2 = 0x395F370; // "public static bool IsItemBroken(IEquipSlotModel equipSlotModel)"
            inline constexpr std::uintptr_t IsCash = 0x395F280; // "public static bool IsCash(InventoryItemDescription item)"
            inline constexpr std::uintptr_t IsCash_2 = 0x395F240; // "public static bool IsCash(InventoryItemDescription item, CashConfig cashConfig)"
            inline constexpr std::uintptr_t GetAmmoOrArmor = 0x395F190; // "public static int GetAmmoOrArmor(InventoryItemDescription item)"
        }
    } // namespace InventoryItemExtensions

    namespace InventoryItemIconRevealFxView { // "Game.Battle.Inventory.Reveal.Views.InventoryItemIconRevealFxView (Battle.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x82738E0; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace Fields {
            inline constexpr std::uintptr_t iconImage = 0x20; // "Image"
            inline constexpr std::uintptr_t settings = 0x28; // "IconRevealFxSettings"
            inline constexpr std::uintptr_t materialInstance = 0x50; // "Material"
        }
        namespace StaticFields {
            inline constexpr std::uintptr_t revealColorId = 0x0; // "int"
            inline constexpr std::uintptr_t glowColorId = 0x4; // "int"
            inline constexpr std::uintptr_t progressId = 0x8; // "int"
            inline constexpr std::uintptr_t glowIntensityId = 0xC; // "int"
            inline constexpr std::uintptr_t glowPowerId = 0x10; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t ApplySettings = 0xA5E530; // "public void ApplySettings(IconRevealFxSettings settings, Material materialTemplate)"
            inline constexpr std::uintptr_t SetProgress = 0xA5EA20; // "public void SetProgress(float progress)"
            inline constexpr std::uintptr_t EnableIconShine = 0xA5E7A0; // "public void EnableIconShine(Sprite sprite, PaletteColor color)"
            inline constexpr std::uintptr_t DisableIconShine = 0x929300; // "public void DisableIconShine()"
            inline constexpr std::uintptr_t OnDestroy = 0xA5E950; // "private void OnDestroy()"
            inline constexpr std::uintptr_t ApplyMaterialProperties = 0xA5E3B0; // "private void ApplyMaterialProperties()"
            inline constexpr std::uintptr_t EnsureMaterialInstance = 0xA5E860; // "private void EnsureMaterialInstance(Material material)"
            inline constexpr std::uintptr_t ReleaseMaterialInstance = 0xA5E960; // "private void ReleaseMaterialInstance()"
        }
    } // namespace InventoryItemIconRevealFxView

    namespace InventoryItemInputAction { // "Game.Battle.Inventory.InventoryItemInputAction (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t From = 0x10; // "IItemMoveContext"
            inline constexpr std::uintptr_t To = 0x18; // "IItemMoveContext"
        }
    } // namespace InventoryItemInputAction

    namespace InventoryItemMoveContext { // "Game.Battle.Inventory.InventoryItemMoveContext (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Inventory = 0x10; // "IInventoryModel"
            inline constexpr std::uintptr_t Slot = 0x18; // "IInventorySlotModel"
            inline constexpr std::uintptr_t RevealContainerModel = 0x20; // "IRevealContainerModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_ItemModel = 0xA144B0; // "public IInventoryItemModel get_ItemModel()"
            inline constexpr std::uintptr_t get_Revealed = 0xA14500; // "public bool get_Revealed()"
            inline constexpr std::uintptr_t get_Count = 0xA14360; // "public int get_Count()"
            inline constexpr std::uintptr_t get_Ammo = 0xA142F0; // "public int get_Ammo()"
            inline constexpr std::uintptr_t get_Durability = 0xA14440; // "public int get_Durability()"
            inline constexpr std::uintptr_t get_CumulativePoints = 0xA143D0; // "public int get_CumulativePoints()"
        }
    } // namespace InventoryItemMoveContext

    namespace InventoryItemRareView { // "Game.Battle.Inventory.Slot.InventoryItemRareView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t rareViews = 0x20; // "RareView[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetRarity = 0xA7C300; // "public void SetRarity(RarityItem rarity)"
        }
    } // namespace InventoryItemRareView

    namespace InventoryItemRule { // "Game.Battle.Inventory.InventoryItemRule (Battle.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t CalculateItemCellSize = 0xA145F0; // "public static Vector2 CalculateItemCellSize(InventoryItemCellsSize cellSize, Vector2 padding, float viewSize)"
            inline constexpr std::uintptr_t CalculateItemCellPosition = 0xA14510; // "public static Vector2 CalculateItemCellPosition(InventoryCellsSizeDescription sizeDesc, int slotIndex, float viewSize, float padding)"
            inline constexpr std::uintptr_t RemoveActivities = 0xA15A10; // "public static void RemoveActivities(IItemMoveContext context, InventoryModels inventoryModels)"
            inline constexpr std::uintptr_t SetEmptyItemActivities = 0xA15AB0; // "public static void SetEmptyItemActivities(IItemMoveContext context, PointerButtonView pointerButtonView, InventoryModels inventoryModels)"
            inline constexpr std::uintptr_t SetFilledItemActivities = 0xA15B60; // "public static void SetFilledItemActivities(IItemMoveContext context, DraggableItemView draggableItemView, PointerButtonView pointerButtonView, InventoryModels inventoryModels)"
            inline constexpr std::uintptr_t IsMoveActive = 0xA14D20; // "public static bool IsMoveActive(CurrentInventoryModel currentInventoryModel, IItemMoveContext context)"
            inline constexpr std::uintptr_t IsDropActive = 0xA14870; // "public static bool IsDropActive(IItemMoveContext context)"
            inline constexpr std::uintptr_t IsSplitActive = 0xA15660; // "public static bool IsSplitActive(IItemMoveContext context)"
            inline constexpr std::uintptr_t IsEquipActive = 0xA14970; // "public static bool IsEquipActive(IItemMoveContext context)"
            inline constexpr std::uintptr_t IsUnequipActive = 0xA157A0; // "public static bool IsUnequipActive(IItemMoveContext context)"
            inline constexpr std::uintptr_t IsReloadActive = 0xA153A0; // "public static bool IsReloadActive(IItemMoveContext context)"
            inline constexpr std::uintptr_t IsUnloadActive = 0xA158F0; // "public static bool IsUnloadActive(IItemMoveContext context)"
            inline constexpr std::uintptr_t IsInstallActive = 0xA14A80; // "public static bool IsInstallActive(CurrentInventoryModel currentInventoryModel, IItemMoveContext context)"
            inline constexpr std::uintptr_t IsCollectActive = 0xA14700; // "public static bool IsCollectActive(CurrentInventoryModel currentInventoryModel, IItemMoveContext context)"
            inline constexpr std::uintptr_t IsSellActive = 0xA154C0; // "public static bool IsSellActive(CurrentInventoryModel currentInventoryModel, IItemMoveContext context)"
            inline constexpr std::uintptr_t IsBuyActive = 0xA14630; // "public static bool IsBuyActive(CurrentInventoryModel currentInventoryModel, IItemMoveContext context)"
        }
    } // namespace InventoryItemRule

    namespace InventoryItemScanFxView { // "Game.Battle.Inventory.Reveal.Views.InventoryItemScanFxView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t root = 0x20; // "RectTransform"
            inline constexpr std::uintptr_t scanFrame = 0x28; // "ProceduralFrame"
            inline constexpr std::uintptr_t progressCurve = 0x30; // "AnimationCurve"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetProgress = 0xA5EC00; // "public void SetProgress(float progress)"
            inline constexpr std::uintptr_t SetSize = 0xA5EC60; // "public void SetSize(Vector2 size)"
        }
    } // namespace InventoryItemScanFxView

    namespace InventoryItemsData { // "Models.Data.InventoryItemsData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Inventory = 0x20; // "InventoryData"
            inline constexpr std::uintptr_t EquipSlots = 0x28; // "ReferenceMapData<EquipSlotDescription, EquipSlotData>"
            inline constexpr std::uintptr_t EquipAmmo = 0x30; // "ReferenceMapData<EquipAmmoOrArmorSlotDescription, IPrimitiveData<int>>"
            inline constexpr std::uintptr_t Pockets = 0x38; // "PocketsData"
        }
    } // namespace InventoryItemsData

    namespace InventoryItemSellPriceModifier { // "Models.References.Inventory.InventoryItemSellPriceModifier (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Modifier = 0x20; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t GetSellPrice = 0x43E8C30; // "public int GetSellPrice(int basePrice)"
        }
    } // namespace InventoryItemSellPriceModifier

    namespace InventoryItemsPrice { // "Models.References.InventoryItemsPrice (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Items = 0x10; // "IReadOnlyList<InventoryItemWithAmount>"
        }
    } // namespace InventoryItemsPrice

    namespace InventoryItemsPriceDescription { // "Models.References.InventoryItemsPriceDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ItemsPrice = 0x20; // "InventoryItemsPrice"
        }
    } // namespace InventoryItemsPriceDescription

    namespace InventoryItemsSearchExtensions { // "Models.Inventory.InventoryItemsSearch.InventoryItemsSearchExtensions (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x82750C8; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t inventoryItemsSearchResult = 0x0; // "InventoryItemsSearchResult"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SearchItemsForPrice = 0x4A53920; // "public static bool SearchItemsForPrice(InventoryItemsSearchSources searchSources, InventoryItemsPrice inventoryItemsPrice, InventoryItemsSearchResult searchResult)"
            inline constexpr std::uintptr_t SearchItemForPrice = 0x4A52C40; // "public static bool SearchItemForPrice(InventoryItemsSearchSources searchSources, InventoryItemDescription item, int amount, InventoryItemsSearchResult searchResult)"
            inline constexpr std::uintptr_t CountItems = 0x4A529A0; // "public static void CountItems(InventoryItemsSearchSources searchSources, IReadOnlyCollection<InventoryItemDescription> items, Dictionary<InventoryItemDescription, int> countResult)"
            inline constexpr std::uintptr_t CountItem = 0x4A528F0; // "public static int CountItem(InventoryItemsSearchSources searchSources, InventoryItemDescription item)"
            inline constexpr std::uintptr_t SearchItem = 0x4A53800; // "private static int SearchItem(InventoryItemsSearchSources searchSources, InventoryItemDescription item, int amount, InventoryItemsSearchResult searchResult)"
            inline constexpr std::uintptr_t SearchItemInInventories = 0x4A53030; // "private static int SearchItemInInventories(IReadOnlyList<InventoryModelInventoryItemsSearchSource> inventories, InventoryItemDescription item, int amount, InventoryItemsSearchResult searchResult)"
            inline constexpr std::uintptr_t SearchItemInMoneyWorkbenches = 0x4A534B0; // "private static int SearchItemInMoneyWorkbenches(IReadOnlyList<MoneyWorkbenchInventoryItemsSearchSource> moneyWorkbenches, InventoryItemDescription item, int amount, InventoryItemsSearchResult searchResult)"
            inline constexpr std::uintptr_t SearchItemInCharacterLaunderings = 0x4A52CE0; // "private static int SearchItemInCharacterLaunderings(IReadOnlyList<CharacterLaunderingInventoryItemsSearchSource> characterLaunderings, InventoryItemDescription item, int amount, InventoryItemsSearchResult searchResult)"
        }
    } // namespace InventoryItemsSearchExtensions

    namespace InventoryItemsSearchResult { // "Models.Inventory.InventoryItemsSearch.InventoryItemsSearchResult (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t InventorySourceSlotToIndex = 0x10; // "Dictionary<IInventorySlotModel, int>"
            inline constexpr std::uintptr_t InventorySourceSlot = 0x18; // "IInventorySlotModel[]"
            inline constexpr std::uintptr_t InventorySourceEntityId = 0x20; // "int[]"
            inline constexpr std::uintptr_t InventorySourceItemAmount = 0x28; // "int[]"
            inline constexpr std::uintptr_t MoneyWorkbenchSourceToIndex = 0x30; // "Dictionary<IMoneyWorkbenchModel, int>"
            inline constexpr std::uintptr_t MoneyWorkbenchSource = 0x38; // "IMoneyWorkbenchModel[]"
            inline constexpr std::uintptr_t MoneyWorkbenchSourceState = 0x40; // "LaunderingState[]"
            inline constexpr std::uintptr_t MoneyWorkbenchSourceDirtyCashAmount = 0x48; // "int[]"
            inline constexpr std::uintptr_t CharacterLaunderingSourceToIndex = 0x50; // "Dictionary<CharacterLaunderingModel, int>"
            inline constexpr std::uintptr_t CharacterLaunderingSource = 0x58; // "CharacterLaunderingModel[]"
            inline constexpr std::uintptr_t CharacterLaunderingSourceState = 0x60; // "LaunderingState[]"
            inline constexpr std::uintptr_t CharacterLaunderingSourceDirtyCashAmount = 0x68; // "int[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Clear = 0x4A54080; // "public void Clear()"
            inline constexpr std::uintptr_t AddInventorySource = 0x4A53D50; // "public void AddInventorySource(IInventorySlotModel inventorySourceSlot, int inventorySourceEntityId, int itemAmount)"
            inline constexpr std::uintptr_t AddMoneyWorkbenchSource = 0x4A53EE0; // "public void AddMoneyWorkbenchSource(IMoneyWorkbenchModel moneyWorkbenchSource, LaunderingState state, int dirtyCashAmount)"
            inline constexpr std::uintptr_t AddCharacterLaunderingSource = 0x4A53BB0; // "public void AddCharacterLaunderingSource(CharacterLaunderingModel characterLaunderingSource, LaunderingState state, int dirtyCashAmount)"
        }
    } // namespace InventoryItemsSearchResult

    namespace InventoryItemsSearchSources { // "Models.Inventory.InventoryItemsSearch.InventoryItemsSearchSources (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Inventories = 0x10; // "List<InventoryModelInventoryItemsSearchSource>"
            inline constexpr std::uintptr_t MoneyWorkbenches = 0x18; // "List<MoneyWorkbenchInventoryItemsSearchSource>"
            inline constexpr std::uintptr_t CharacterLaunderings = 0x20; // "List<CharacterLaunderingInventoryItemsSearchSource>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Clear = 0x4A54450; // "public void Clear()"
        }
    } // namespace InventoryItemsSearchSources

    namespace InventoryItemStackIconUpdater { // "Game.Battle.Inventory.Slot.InventoryItemStackIconUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t itemMoveContext = 0x20; // "IItemMoveContext"
            inline constexpr std::uintptr_t view = 0x28; // "InventoryIconView"
            inline constexpr std::uintptr_t inventoryItemViewDescriptions = 0x30; // "InventoryItemViewDescriptions"
            inline constexpr std::uintptr_t item = 0x38; // "InventoryItemDescription"
            inline constexpr std::uintptr_t count = 0x40; // "Nullable<int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA7C3D0; // "public InventoryItemStackIconUpdater Init(IItemMoveContext itemMoveContext, InventoryIconView view, InventoryItemViewDescriptions inventoryItemViewDescriptions)"
            inline constexpr std::uintptr_t Dispose = 0xA7C370; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA7C450; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace InventoryItemStackIconUpdater

    namespace InventoryItemStackSprite { // "Game.Global.Inventory.InventoryItemStackSprite (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t MinCount = 0x10; // "int"
            inline constexpr std::uintptr_t Sprite = 0x18; // "Sprite"
        }
    } // namespace InventoryItemStackSprite

    namespace InventoryItemUsedClientNotificationData { // "Models.ClientNotification.ClientNotificationData.InventoryItemUsedClientNotificationData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t item = 0x20; // "IPrimitiveData<InventoryItemDescription>"
            inline constexpr std::uintptr_t amount = 0x28; // "IPrimitiveData<int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Value = 0x4ADD850; // "public ClientNotification.InventoryItemUsed get_Value()"
            inline constexpr std::uintptr_t set_Value = 0x4ADD910; // "public void set_Value(ClientNotification.InventoryItemUsed value)"
        }
    } // namespace InventoryItemUsedClientNotificationData

    namespace InventoryItemView { // "Game.Battle.Inventory.InventoryItemView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t DraggableItemView = 0x20; // "DraggableItemView"
            inline constexpr std::uintptr_t PointerButtonView = 0x28; // "PointerButtonView"
            inline constexpr std::uintptr_t InventorySlotGlowView = 0x30; // "InventorySlotGlowView"
            inline constexpr std::uintptr_t SlotBlockedView = 0x38; // "SlotBlockedView"
            inline constexpr std::uintptr_t SlotLockedView = 0x40; // "SlotLockedView"
            inline constexpr std::uintptr_t InventorySlotView = 0x48; // "InventoryIconView"
            inline constexpr std::uintptr_t RareView = 0x50; // "LineAndBackgroundRareView"
            inline constexpr std::uintptr_t EquipSlotView = 0x58; // "EquipSlotView"
            inline constexpr std::uintptr_t PointerMoveView = 0x60; // "PointerMoveView"
            inline constexpr std::uintptr_t BackgroundParent = 0x68; // "RectTransform"
            inline constexpr std::uintptr_t CompositeParent = 0x70; // "RectTransform"
            inline constexpr std::uintptr_t DelayLockView = 0x78; // "InventoryItemDelayLockView"
            inline constexpr std::uintptr_t backgroundPalette = 0x80; // "GraphicsPalette"
            inline constexpr std::uintptr_t colorStyle = 0x88; // "ColorStyleViewDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t ResetView = 0xA15C30; // "public void ResetView()"
            inline constexpr std::uintptr_t SetBroken = 0xA15D60; // "public void SetBroken(bool value)"
        }
    } // namespace InventoryItemView

    namespace InventoryItemWithAmount { // "Models.References.Inventory.InventoryItemWithAmount (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Amount = 0x10; // "int"
            inline constexpr std::uintptr_t DescriptionFunc = 0x18; // "Func<InventoryItemDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Description = 0x26CF2F0; // "public InventoryItemDescription get_Description()"
            inline constexpr std::uintptr_t New = 0x43E8E80; // "public static InventoryItemWithAmount New(InventoryItemDescription description, int amount)"
            inline constexpr std::uintptr_t New_2 = 0x43E8F70; // "public static InventoryItemWithAmount New(InventoryItemDescription description)"
        }
    } // namespace InventoryItemWithAmount

    namespace InventoryKeys { // "Game.Battle.BattleScreenContentDirectory.Localization.InventoryKeys (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t SliderItemMinMaxValueText = 0x10; // "LocalizedString"
            inline constexpr std::uintptr_t SliderCashMinMaxValueText = 0x18; // "LocalizedString"
            inline constexpr std::uintptr_t SliderSimpleMinMaxValueText = 0x20; // "LocalizedString"
            inline constexpr std::uintptr_t CanNotOpenInventory = 0x28; // "LocalizedString"
            inline constexpr std::uintptr_t UnsetItemTitle = 0x30; // "LocalizedString"
            inline constexpr std::uintptr_t UnsetItemDescription = 0x38; // "LocalizedString"
            inline constexpr std::uintptr_t ToolTipTitle = 0x40; // "LocalizedString"
            inline constexpr std::uintptr_t ToolTipDescription = 0x48; // "LocalizedString"
            inline constexpr std::uintptr_t TooltipMiniImprovementsTitle = 0x50; // "LocalizedString"
            inline constexpr std::uintptr_t TooltipMiniImprovementsDescription = 0x58; // "LocalizedString"
            inline constexpr std::uintptr_t TooltipMiniImprovementsAdditionalRewardChance = 0x60; // "LocalizedString"
            inline constexpr std::uintptr_t TooltipMiniImprovementsSpeedUp = 0x68; // "LocalizedString"
            inline constexpr std::uintptr_t TooltipMiniBonusValue = 0x70; // "Text<float>"
            inline constexpr std::uintptr_t CashWithdrawalModalDialogConfirm = 0x78; // "LocalizedString"
            inline constexpr std::uintptr_t CashWithdrawalModalDialogTitle = 0x80; // "LocalizedString"
            inline constexpr std::uintptr_t CashWithdrawalModalDialogDescription = 0x88; // "LocalizedString"
            inline constexpr std::uintptr_t RouletteExchangeChipsDialogBuyTitle = 0x90; // "LocalizedString"
            inline constexpr std::uintptr_t RouletteExchangeChipsDialogSellTitle = 0x98; // "LocalizedString"
            inline constexpr std::uintptr_t RouletteExchangeChipsDialogDescription = 0xA0; // "LocalizedString"
        }
    } // namespace InventoryKeys

    namespace InventoryLootBuffer { // "Models.Models.InventoryLootBuffer.InventoryLootBuffer (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x82753F8; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace Fields {
            inline constexpr std::uintptr_t stackableItems = 0x10; // "Dictionary<InventoryItemDescription, LootInventoryItem>"
            inline constexpr std::uintptr_t allItems = 0x18; // "List<LootInventoryItem>"
            inline constexpr std::uintptr_t result = 0x20; // "ReadOnly.List<LootInventoryItem>"
        }
        namespace StaticFields {
            inline constexpr std::uintptr_t random = 0x0; // "Random"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Add = 0x4936880; // "public void Add(InventoryItemDescription item, int stackAmount, int ammoOrArmor, int durability, int cumulativePoints)"
            inline constexpr std::uintptr_t GetLoot = 0x4936A10; // "public ReadOnly.List<LootInventoryItem> GetLoot()"
            inline constexpr std::uintptr_t Shuffle = 0x4936EA0; // "private void Shuffle(List<LootInventoryItem> allItems)"
            inline constexpr std::uintptr_t Reset = 0x4936E10; // "public void Reset()"
        }
    } // namespace InventoryLootBuffer

    namespace InventoryMaskModel { // "Models.Inventory.InventoryMask.InventoryMaskModel (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t Build = 0x4A54630; // "public static bool[] Build()"
            inline constexpr std::uintptr_t Clear = 0x4A546D0; // "public static void Clear(bool[] mask)"
            inline constexpr std::uintptr_t UpdateMaskByInventory = 0x4A547D0; // "public static void UpdateMaskByInventory(bool[] mask, IInventorySlotsModel inventorySlotsModel, int slotsCount, InventoryCellsSizeDescription inventoryCellsSizeDescription)"
            inline constexpr std::uintptr_t SetItemInMask = 0x4A54710; // "private static void SetItemInMask(bool[] mask, int itemIndex, InventoryItemCellsSize itemCellsSize, InventoryCellsSizeDescription inventoryCellsSizeDescription)"
        }
    } // namespace InventoryMaskModel

    namespace InventoryModel { // "Models.Models.InventoryModel.InventoryModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Description = 0x10; // "InventoryCellsSizeDescription"
            inline constexpr std::uintptr_t Slots = 0x18; // "IInventorySlotsModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_TakeOnlyLinesCount = 0x7E3AB0; // "public virtual int get_TakeOnlyLinesCount()"
            inline constexpr std::uintptr_t TryGetSlot = 0x4937220; // "public bool TryGetSlot(InventorySlotDescription slot, out IInventorySlotModel slotModel)"
        }
    } // namespace InventoryModel

    namespace InventoryModelInventoryItemsSearchSource { // "Models.Inventory.InventoryItemsSearch.Sources.InventoryModelInventoryItemsSearchSource (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Inventory = 0x0; // "IInventoryModel"
            inline constexpr std::uintptr_t InventoryEntityId = 0x8; // "int"
        }
    } // namespace InventoryModelInventoryItemsSearchSource

    namespace InventoryModels { // "Game.Battle.Inventory.InventoryModels (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t InventoryDragAndDropModel = 0x10; // "InventoryDragAndDropModel"
            inline constexpr std::uintptr_t UseItemDragAndDropViewModel = 0x18; // "UseItemDragAndDropModel"
            inline constexpr std::uintptr_t HighlightedItemsModel = 0x20; // "HighlightedItemsModel"
            inline constexpr std::uintptr_t InventorySelectedModel = 0x28; // "InventorySelectedModel"
            inline constexpr std::uintptr_t ItemMoveModel = 0x30; // "ItemMoveModel"
            inline constexpr std::uintptr_t ConsumableItemSoundModel = 0x38; // "ConsumableItemSoundModel"
            inline constexpr std::uintptr_t UnsetItemMoveModel = 0x40; // "UnsetItemMoveModel"
            inline constexpr std::uintptr_t RestrictedCellsModel = 0x48; // "RestrictedCellsModel"
            inline constexpr std::uintptr_t ItemSplitModel = 0x50; // "ItemSplitModel"
            inline constexpr std::uintptr_t ShopSplitModel = 0x58; // "ShopSplitModel"
            inline constexpr std::uintptr_t DraggableItemsModel = 0x60; // "DraggableItemsModel"
            inline constexpr std::uintptr_t ClickableItemsModel = 0x68; // "ClickableItemsModel"
            inline constexpr std::uintptr_t HoverableSlotsModel = 0x70; // "HoverableSlotsModel"
            inline constexpr std::uintptr_t ItemMoveContext = 0x78; // "IItemMoveContext"
            inline constexpr std::uintptr_t ScrollableItemsModel = 0x80; // "ScrollableItemsModel"
            inline constexpr std::uintptr_t InventoryDialogTabsModel = 0x88; // "InventoryDialogTabsModel"
            inline constexpr std::uintptr_t BuilderSlotsModel = 0x90; // "BuilderSlotsModel"
            inline constexpr std::uintptr_t CarUpgradesSlotModel = 0x98; // "CarUpgradesSlotModel"
            inline constexpr std::uintptr_t CarBenchSlotsModel = 0xA0; // "CarBenchSlotsModel"
            inline constexpr std::uintptr_t HelicopterBenchSlotsModel = 0xA8; // "HelicopterBenchSlotsModel"
            inline constexpr std::uintptr_t Now = 0xB0; // "INow"
        }
    } // namespace InventoryModels

    namespace InventoryMoveMessage { // "Models.Messages.Inventory.Move.InventoryMoveMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t fromSource = 0x20; // "IPrimitiveData<SlotSourceDescription>"
            inline constexpr std::uintptr_t fromInventorySlot = 0x28; // "IPrimitiveData<InventorySlotDescription>"
            inline constexpr std::uintptr_t fromEquipSlot = 0x30; // "IPrimitiveData<EquipSlotDescription>"
            inline constexpr std::uintptr_t fromPocketSlot = 0x38; // "IPrimitiveData<PocketSlotDescription>"
            inline constexpr std::uintptr_t fromEntityId = 0x40; // "BattleEntityIdData"
            inline constexpr std::uintptr_t count = 0x48; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t toSource = 0x50; // "IPrimitiveData<SlotSourceDescription>"
            inline constexpr std::uintptr_t toInventorySlot = 0x58; // "IPrimitiveData<InventorySlotDescription>"
            inline constexpr std::uintptr_t toEquipSlot = 0x60; // "IPrimitiveData<EquipSlotDescription>"
            inline constexpr std::uintptr_t toPocketSlot = 0x68; // "IPrimitiveData<PocketSlotDescription>"
            inline constexpr std::uintptr_t toEntityId = 0x70; // "BattleEntityIdData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_FromSource = 0x4A28810; // "public SlotSourceDescription get_FromSource()"
            inline constexpr std::uintptr_t get_FromInventorySlot = 0x4A28770; // "public InventorySlotDescription get_FromInventorySlot()"
            inline constexpr std::uintptr_t get_FromEquipSlot = 0x4A28720; // "public EquipSlotDescription get_FromEquipSlot()"
            inline constexpr std::uintptr_t get_FromPocketSlot = 0x4A287C0; // "public PocketSlotDescription get_FromPocketSlot()"
            inline constexpr std::uintptr_t get_FromEntityId = 0x4A286E0; // "public int get_FromEntityId()"
            inline constexpr std::uintptr_t get_Count = 0x4A28690; // "public int get_Count()"
            inline constexpr std::uintptr_t get_ToSource = 0x4A28990; // "public SlotSourceDescription get_ToSource()"
            inline constexpr std::uintptr_t get_ToInventorySlot = 0x4A288F0; // "public InventorySlotDescription get_ToInventorySlot()"
            inline constexpr std::uintptr_t get_ToEquipSlot = 0x4A288A0; // "public EquipSlotDescription get_ToEquipSlot()"
            inline constexpr std::uintptr_t get_ToPocketSlot = 0x4A28940; // "public PocketSlotDescription get_ToPocketSlot()"
            inline constexpr std::uintptr_t get_ToEntityId = 0x4A28860; // "public int get_ToEntityId()"
            inline constexpr std::uintptr_t get_Type = 0x4A289E0; // "public override string get_Type()"
        }
    } // namespace InventoryMoveMessage

    namespace InventoryPackRules { // "Game.Battle.Inventory.InventoryPackRules (Battle.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x8275728; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t result = 0x0; // "List<InventorySlotDescription>"
            inline constexpr std::uintptr_t slots = 0x8; // "bool[,]"
            inline constexpr std::uintptr_t size = 0x10; // "ValueTuple<int, int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Pack = 0xA16190; // "public static IReadOnlyList<InventorySlotDescription> Pack(IEnumerable<InventoryItemCellsSize> items, InventoryCellsSizeDescription size, int startLine, out int lastLine)"
            inline constexpr std::uintptr_t CanAdd = 0xA15E80; // "private static bool CanAdd(InventoryItemCellsSize itemSize, int startX, int startY, InventoryCellsSizeDescription size, bool[,] slots)"
            inline constexpr std::uintptr_t Add = 0xA15DD0; // "private static void Add(InventoryItemCellsSize itemSize, int startX, int startY, bool[,] slots)"
            inline constexpr std::uintptr_t CheckAndClearSlotLength = 0xA15F40; // "private static void CheckAndClearSlotLength(int x, int y)"
        }
    } // namespace InventoryPackRules

    namespace InventoryPageIndicatorInputUpdater { // "Game.Battle.Inventory.Pages.InventoryPageIndicatorInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x20; // "InventoryPaginatorModel"
            inline constexpr std::uintptr_t view = 0x28; // "PaginatorView"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0x9F7740; // "public InventoryPageIndicatorInputUpdater Init(InventoryPaginatorModel model, PaginatorView view)"
            inline constexpr std::uintptr_t Dispose = 0x92B5C0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA5F240; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace InventoryPageIndicatorInputUpdater

    namespace InventoryPagesModel { // "Models.Models.InventoryPages.InventoryPagesModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "DictionaryData<int, InventoryData>"
            inline constexpr std::uintptr_t maxPagesCount = 0x18; // "int"
            inline constexpr std::uintptr_t inventories = 0x20; // "Dictionary<int, IInventoryModel>"
            inline constexpr std::uintptr_t pageIndexes = 0x28; // "Dictionary<IInventoryModel, int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_PagesCount = 0x4937D70; // "public int get_PagesCount()"
            inline constexpr std::uintptr_t get_IsMaxPagesCount = 0x4937CC0; // "public bool get_IsMaxPagesCount()"
            inline constexpr std::uintptr_t get_Item = 0x4937D10; // "public IInventoryModel get_Item(int pageIndex)"
            inline constexpr std::uintptr_t IsEmpty = 0x49377B0; // "public bool IsEmpty()"
            inline constexpr std::uintptr_t AddPage = 0x4937510; // "public IInventoryModel AddPage()"
            inline constexpr std::uintptr_t AddPage_2 = 0x49375A0; // "private IInventoryModel AddPage(int pageIndex, InventoryData inventoryData)"
            inline constexpr std::uintptr_t TryGetPageIndex = 0x4937960; // "public bool TryGetPageIndex(IInventoryModel inventoryModel, out int pageIndex)"
            inline constexpr std::uintptr_t Clear = 0x4937680; // "public void Clear()"
            inline constexpr std::uintptr_t GetEnumerator = 0x4937710; // "public IEnumerator<IInventoryModel> GetEnumerator()"
            inline constexpr std::uintptr_t System_Collections_IEnumerable_GetEnumerator = 0x4937710; // "private IEnumerator System.Collections.IEnumerable.GetEnumerator()"
        }
    } // namespace InventoryPagesModel

    namespace InventoryPaginatorModel { // "Game.Battle.Inventory.Pages.InventoryPaginatorModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t PageIndex = 0x10; // "int"
            inline constexpr std::uintptr_t TotalPages = 0x14; // "int"
            inline constexpr std::uintptr_t FilledPages = 0x18; // "List<int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Next = 0xA5F640; // "public void Next()"
            inline constexpr std::uintptr_t Previous = 0xA5F6B0; // "public void Previous()"
            inline constexpr std::uintptr_t GoTo = 0xA5F420; // "public void GoTo(int pageIndex)"
            inline constexpr std::uintptr_t HasItemsOnPage = 0xA5F510; // "public bool HasItemsOnPage(int pageIndex)"
        }
    } // namespace InventoryPaginatorModel

    namespace InventoryPlacement { // "Models.Inventory.InventoryPlacement (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x8275A58; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t items = 0x0; // "List<InventoryItem>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t TryPlaceItemsToInventory = 0x4A35A70; // "public static bool TryPlaceItemsToInventory(List<InventoryItem> items, IInventoryModel inventoryModelTo, List<ValueTuple<InventoryItem, ValueTuple<int, int>>> movedItems, List<InventoryItem> skipItems)"
            inline constexpr std::uintptr_t ConvertSlotModelToItem = 0x4A34C50; // "private static InventoryItem ConvertSlotModelToItem(IInventorySlotModel slotModel)"
            inline constexpr std::uintptr_t TryPlaceItemsPartly = 0x4A354C0; // "public static bool TryPlaceItemsPartly(int width, int height, IInventoryModel inventoryModel, List<ValueTuple<InventoryItem, ValueTuple<int, int>>> movedItems, List<InventoryItem> skipItems)"
            inline constexpr std::uintptr_t CompareItemsSize = 0x4A34BC0; // "private static int CompareItemsSize(InventoryItem x, InventoryItem y)"
            inline constexpr std::uintptr_t PlaceItemsGreedy = 0x4A34F90; // "public static bool PlaceItemsGreedy(int width, int height, List<InventoryItem> items, List<ValueTuple<InventoryItem, ValueTuple<int, int>>> movedItems, List<InventoryItem> skipItems, InventoryItem[,] gridDefault)"
            inline constexpr std::uintptr_t PlaceFit = 0x4A34E30; // "private static bool PlaceFit(InventoryItem item, int width, int height, InventoryItem[,] grid, List<ValueTuple<InventoryItem, ValueTuple<int, int>>> movedItems, List<InventoryItem> skipItems)"
            inline constexpr std::uintptr_t CanPlace = 0x4A34A20; // "private static bool CanPlace(int x, int y, InventoryItem item, InventoryItem[,] grid)"
            inline constexpr std::uintptr_t SetItem = 0x4A352E0; // "private static void SetItem(int x, int y, InventoryItem item, InventoryItem[,] grid, List<ValueTuple<InventoryItem, ValueTuple<int, int>>> movedItems)"
        }
    } // namespace InventoryPlacement

    namespace InventoryPocketSlotIconUpdater { // "Game.Battle.Inventory.InventoryPocketSlotIconUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t slotModel = 0x20; // "IPocketSlotModel"
            inline constexpr std::uintptr_t pocketsModel = 0x28; // "IPocketsModel"
            inline constexpr std::uintptr_t view = 0x30; // "InventoryIconView"
            inline constexpr std::uintptr_t slotIconView = 0x38; // "ISlotIconView"
            inline constexpr std::uintptr_t inventoryItemViewDescriptions = 0x40; // "InventoryItemViewDescriptions"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA5F7A0; // "public InventoryPocketSlotIconUpdater Init(IPocketSlotModel slotModel, IPocketsModel pocketsModel, InventoryIconView view, ISlotIconView slotIconView, InventoryItemViewDescriptions inventoryItemViewDescriptions)"
            inline constexpr std::uintptr_t Dispose = 0x9F4BF0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA5F820; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace InventoryPocketSlotIconUpdater

    namespace InventoryPocketViewUpdater { // "Game.Battle.Inventory.InventoryPocketViewUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t updaters = 0x20; // "List<IUpdater>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA5FAB0; // "public InventoryPocketViewUpdater Init(BattleModel battleModel, InventoryModels inventoryModels, IInventoryModel inventoryModel, CurrentInventoryModel currentInventoryModel, InventoryUiView inventoryUiView, GlobalScreenContent globalScreenContent, BattleScreenContent battleScreenContent, InventoryScreenContent inventoryScreenContent, UpdaterPool updaterPool, IRegisterDisposable disposable)"
            inline constexpr std::uintptr_t Dispose = 0xA5FA50; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0x94CF50; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace InventoryPocketViewUpdater

    namespace InventoryProgressItemModel { // "Game.Battle.Inventory.Progress.InventoryProgressItemModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Progress = 0x10; // "float"
            inline constexpr std::uintptr_t ReloadEndTs = 0x18; // "long"
            inline constexpr std::uintptr_t SourceItemContext = 0x20; // "IItemMoveContext"
            inline constexpr std::uintptr_t TargetItemContext = 0x28; // "IItemMoveContext"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsUsing = 0xA612F0; // "public bool get_IsUsing()"
            inline constexpr std::uintptr_t SetProgress = 0x834220; // "public void SetProgress(float progress)"
            inline constexpr std::uintptr_t SetSource = 0x7AB190; // "public void SetSource(IItemMoveContext itemMoveContext)"
            inline constexpr std::uintptr_t SetTarget = 0x83A410; // "public void SetTarget(IItemMoveContext target)"
            inline constexpr std::uintptr_t Clear = 0xA611D0; // "public void Clear()"
            inline constexpr std::uintptr_t IsEqualsSource = 0xA61260; // "public bool IsEqualsSource(IItemMoveContext context)"
        }
    } // namespace InventoryProgressItemModel

    namespace InventoryProgressItemModelUpdater { // "Game.Battle.Inventory.Progress.InventoryProgressItemModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleEntitiesModel = 0x10; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t progressWeaponUpdater = 0x18; // "InventoryProgressWeaponUpdater"
            inline constexpr std::uintptr_t progressQuickSlotUpdater = 0x20; // "InventoryProgressQuickSlotUpdater"
            inline constexpr std::uintptr_t progressUseFromInventoryUpdater = 0x28; // "InventoryProgressUseFromInventoryUpdater"
            inline constexpr std::uintptr_t type = 0x30; // "InventoryProgressItemModelUpdater.ProgressType"
            inline constexpr std::uintptr_t updaterByState = 0x38; // "IUpdater"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA60E00; // "public void Update()"
            inline constexpr std::uintptr_t GetProgressType = 0xA60C70; // "private InventoryProgressItemModelUpdater.ProgressType GetProgressType(BattleCharacterModel battleCharacterModel)"
        }
    } // namespace InventoryProgressItemModelUpdater

    namespace InventoryProgressQuickSlotUpdater { // "Game.Battle.Inventory.Progress.InventoryProgressQuickSlotUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t now = 0x10; // "INow"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x18; // "IBattleEntitiesModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA61B70; // "public void Update()"
            inline constexpr std::uintptr_t UpdateProgress = 0xA613D0; // "private void UpdateProgress(PlayerEntityModel player)"
            inline constexpr std::uintptr_t SwitchToTargetSlotProgress = 0xA61380; // "private static long SwitchToTargetSlotProgress(BattleCharacterModel characterModel, long now, long firstStep)"
            inline constexpr std::uintptr_t UsingItemProgress = 0xA61E40; // "private static long UsingItemProgress(BattleCharacterModel characterModel, long now, long firstStep, long castDuration, long postCastDuration)"
            inline constexpr std::uintptr_t UpdateSource = 0xA618E0; // "private static void UpdateSource(PlayerEntityModel player)"
            inline constexpr std::uintptr_t UpdateTarget = 0xA61A10; // "private static void UpdateTarget(PlayerEntityModel player)"
            inline constexpr std::uintptr_t GetQuickSlotState = 0xA61300; // "private static InventoryProgressQuickSlotUpdater.QuickSlotUseState GetQuickSlotState(BattleCharacterModel characterModel)"
        }
    } // namespace InventoryProgressQuickSlotUpdater

    namespace InventoryProgressUseFromInventoryUpdater { // "Game.Battle.Inventory.Progress.InventoryProgressUseFromInventoryUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t now = 0x10; // "INow"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x18; // "IBattleEntitiesModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA62580; // "public void Update()"
            inline constexpr std::uintptr_t UpdateProgress = 0xA61ED0; // "private void UpdateProgress(PlayerEntityModel player)"
            inline constexpr std::uintptr_t UpdateSource = 0xA62290; // "private void UpdateSource(PlayerEntityModel player)"
            inline constexpr std::uintptr_t UpdateTarget = 0xA62390; // "private void UpdateTarget(PlayerEntityModel player)"
        }
    } // namespace InventoryProgressUseFromInventoryUpdater

    namespace InventoryProgressView { // "Game.Battle.Inventory.Progress.InventoryProgressView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t transformProgress = 0x20; // "RectTransform"
            inline constexpr std::uintptr_t transform = 0x28; // "RectTransform"
            inline constexpr std::uintptr_t progress = 0x30; // "float"
            inline constexpr std::uintptr_t size = 0x34; // "Vector2"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetSize = 0xA627A0; // "public void SetSize(Vector2 value)"
            inline constexpr std::uintptr_t SetPosition = 0xA62700; // "public void SetPosition(Vector2 position)"
            inline constexpr std::uintptr_t SetProgress = 0xA62750; // "public void SetProgress(float progress)"
        }
    } // namespace InventoryProgressView

    namespace InventoryProgressWeaponUpdater { // "Game.Battle.Inventory.Progress.InventoryProgressWeaponUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t now = 0x10; // "INow"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x18; // "IBattleEntitiesModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA62E80; // "public void Update()"
            inline constexpr std::uintptr_t UpdateProgress = 0xA62880; // "private void UpdateProgress(PlayerEntityModel player)"
            inline constexpr std::uintptr_t UpdateSource = 0xA62CB0; // "private void UpdateSource(PlayerEntityModel player)"
            inline constexpr std::uintptr_t UpdateTarget = 0xA62DB0; // "private void UpdateTarget(PlayerEntityModel player)"
        }
    } // namespace InventoryProgressWeaponUpdater

    namespace InventoryReopenUpdater { // "Game.Battle.Inventory.InventoryReopenUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t inventoryDialogModel = 0x10; // "InventoryDialogModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x18; // "IBattleEntitiesModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA00CA0; // "public void Update()"
        }
    } // namespace InventoryReopenUpdater

    namespace InventoryRestrictedShadowUpdater { // "Game.Battle.Inventory.RestrictedCells.InventoryRestrictedShadowUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t restrictedCellsModel = 0x20; // "RestrictedCellsModel"
            inline constexpr std::uintptr_t restrictedShadowPool = 0x28; // "PooledLoadedComponentContent<Transform>"
            inline constexpr std::uintptr_t inventorySlotModel = 0x30; // "IInventorySlotModel"
            inline constexpr std::uintptr_t restrictedShadowContent = 0x38; // "IDisposableContent<Transform>"
            inline constexpr std::uintptr_t parent = 0x40; // "Transform"
            inline constexpr std::uintptr_t isActive = 0x48; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA631B0; // "public InventoryRestrictedShadowUpdater Init(BattleModel battleModel, InventoryScreenContent inventoryScreenContent, IInventorySlotModel inventorySlotModel, Transform parent)"
            inline constexpr std::uintptr_t Dispose = 0xA630D0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA63300; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t GenerateRestrictedShadow = 0xA63150; // "private void GenerateRestrictedShadow()"
            inline constexpr std::uintptr_t DisposeRestrictedShadow = 0xA63070; // "private void DisposeRestrictedShadow()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace InventoryRestrictedShadowUpdater

    namespace InventoryRevealExtensions { // "Game.Battle.Inventory.Reveal.InventoryRevealExtensions (Battle.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t IsRevealed = 0xA63A90; // "public static bool IsRevealed(IInventorySlotModel slot, IRevealContainerModel revealContainerModel)"
            inline constexpr std::uintptr_t IsRevealed_2 = 0xA63B30; // "public static bool IsRevealed(InventorySlotDescription slot, IRevealContainerModel revealContainerModel)"
            inline constexpr std::uintptr_t HasRevealedSlots = 0xA63840; // "public static bool HasRevealedSlots(BusySlotsModel busySlotsModel, IRevealContainerModel revealContainerModel)"
            inline constexpr std::uintptr_t TryAddInventoryRevealUpdaters = 0xA63BA0; // "public static void TryAddInventoryRevealUpdaters(List<IUpdater> updaters, IRevealContainerModel revealContainerModel, BattleScreenContent battleScreenContent, GlobalScreenContent globalScreenContent, InventoryScreenContent inventoryScreenContent, List<IInventoryItemMoveContext> itemMoveContexts, ExternalInventoryDialogView uiView, UpdaterPool updaterPool, IRegisterDisposable registerDisposable)"
            inline constexpr std::uintptr_t GetRevealModel = 0xA633F0; // "public static IRevealContainerModel GetRevealModel(InventoryRevealModel model, IInventoryModel inventoryModel, InventoryRevealIdModel revealIdModel)"
        }
    } // namespace InventoryRevealExtensions

    namespace InventoryRevealIdModel { // "Models.Models.InventoryRevealId.InventoryRevealIdModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "InventoryRevealIdData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Value = 0x4937EE0; // "public long get_Value()"
            inline constexpr std::uintptr_t Set = 0x4937E10; // "public void Set()"
            inline constexpr std::uintptr_t Unset = 0x4937EA0; // "public void Unset()"
            inline constexpr std::uintptr_t Set_2 = 0x4937DC0; // "public void Set(long value)"
        }
    } // namespace InventoryRevealIdModel

    namespace InventoryRevealIdUtils { // "Models.Models.InventoryRevealId.InventoryRevealIdUtils (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x82768B0; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t random = 0x0; // "Random"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Generate = 0x4937F20; // "public static long Generate()"
        }
    } // namespace InventoryRevealIdUtils

    namespace InventoryRevealModel { // "Game.Global.Inventory.Reveal.Models.InventoryRevealModel (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t capacity = 0x10; // "int"
            inline constexpr std::uintptr_t queue = 0x18; // "Queue<long>"
            inline constexpr std::uintptr_t dictionary = 0x20; // "Dictionary<long, IRevealContainerModel>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t TryGetRevealModel = 0x35B2F80; // "public bool TryGetRevealModel(InventoryRevealIdModel revealIdModel, out IRevealContainerModel model)"
            inline constexpr std::uintptr_t SetOpenedRevealModel = 0x35B2D40; // "public IRevealContainerModel SetOpenedRevealModel(InventoryRevealIdModel revealIdModel)"
            inline constexpr std::uintptr_t CreateRevealModel = 0x35B2BE0; // "public IRevealContainerModel CreateRevealModel(Dictionary<int, string> snapshot, InventoryRevealIdModel revealIdModel)"
        }
    } // namespace InventoryRevealModel

    namespace InventoryRevealModels { // "Game.Global.Inventory.Reveal.Models.InventoryRevealModels (Global.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x8276BE0; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace Fields {
            inline constexpr std::uintptr_t Permanent = 0x10; // "InventoryRevealModel"
            inline constexpr std::uintptr_t Temporary = 0x18; // "InventoryRevealModel"
            inline constexpr std::uintptr_t IsLoaded = 0x20; // "bool"
        }
        namespace StaticFields {
            inline constexpr std::uintptr_t Dummy = 0x0; // "IRevealContainerModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Save = 0x35B30E0; // "public void Save(ListData<RevealContainerPrefsData> listData)"
            inline constexpr std::uintptr_t TryLoad = 0x35B3570; // "public void TryLoad(ListData<RevealContainerPrefsData> listData)"
        }
    } // namespace InventoryRevealModels

    namespace InventoryRevealViewDescriptions { // "Game.Battle.Inventory.Reveal.InventoryRevealViewDescriptions (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t list = 0x18; // "List<InventoryRevealViewDescriptions.Pair>"
            inline constexpr std::uintptr_t dictionary = 0x20; // "ReadOnly.Dictionary<RarityItem, InventoryRevealViewDescriptions.RevealViewDescription>"
            inline constexpr std::uintptr_t HideBackgroundSprite = 0x28; // "Sprite"
            inline constexpr std::uintptr_t ScanBackgroundColor = 0x30; // "PaletteColor"
            inline constexpr std::uintptr_t PreviewBackgroundColor = 0x38; // "PaletteColor"
            inline constexpr std::uintptr_t RevealShineFxMaterial = 0x40; // "Material"
            inline constexpr std::uintptr_t RevealIconFxMaterial = 0x48; // "Material"
            inline constexpr std::uintptr_t RevealingEvent = 0x50; // "Event"
            inline constexpr std::uintptr_t TimeToOneCellBorder = 0x58; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Item = 0xA63F30; // "public InventoryRevealViewDescriptions.RevealViewDescription get_Item(RarityItem rarity)"
        }
    } // namespace InventoryRevealViewDescriptions

    namespace InventoryRevealViewDescriptions_Pair { // "Game.Battle.Inventory.Reveal.InventoryRevealViewDescriptions.Pair (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t id = 0x0; // "string"
            inline constexpr std::uintptr_t Rarity = 0x8; // "RarityItem"
            inline constexpr std::uintptr_t Description = 0x10; // "InventoryRevealViewDescriptions.RevealViewDescription"
        }
    } // namespace InventoryRevealViewDescriptions_Pair

    namespace InventoryRevealViewDescriptions_RevealViewDescription { // "Game.Battle.Inventory.Reveal.InventoryRevealViewDescriptions.RevealViewDescription (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Sound = 0x10; // "Event"
            inline constexpr std::uintptr_t ShineSettings = 0x18; // "RevealShineFxSettings"
            inline constexpr std::uintptr_t IconRevealSettings = 0x50; // "IconRevealFxSettings"
        }
    } // namespace InventoryRevealViewDescriptions_RevealViewDescription

    namespace InventoryRules { // "Models.Inventory.InventoryRules (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x8276D78; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t inventorySearchResult = 0x0; // "InventorySearchResult"
        }
        namespace Methods {
            inline constexpr std::uintptr_t CheckInventorySpaceToSet = 0x4A56AD0; // "public static bool CheckInventorySpaceToSet(IInventoryModel inventoryModel, InventoryItemDescription item, int index, IInventorySlotModel ignoredSlotModel1, IInventorySlotModel ignoredSlotModel2, int linesDiff)"
            inline constexpr std::uintptr_t CheckInventorySpaceToSet_2 = 0x4A56740; // "public static bool CheckInventorySpaceToSet(IInventoryModel inventoryModel, InventoryItemDescription item, int index, HashSet<IInventorySlotModel> ignoredSlotModels, int linesDiff)"
            inline constexpr std::uintptr_t CheckInventoryBoundaries = 0x4A55CC0; // "public static bool CheckInventoryBoundaries(IInventoryModel inventory, InventoryItemDescription item, int x, int y, int linesDiff)"
            inline constexpr std::uintptr_t CheckInventoryBoundaries_2 = 0x4A55E10; // "public static bool CheckInventoryBoundaries(IInventoryModel inventory, IInventoryModel sourceItems, int linesDiff)"
            inline constexpr std::uintptr_t CheckPointInventoryBoundaries = 0x4A58630; // "public static bool CheckPointInventoryBoundaries(IInventoryModel inventory, int x, int y, int linesDiff)"
            inline constexpr std::uintptr_t CheckInRect = 0x4A55CA0; // "private static bool CheckInRect(int minX, int minY, int maxX, int maxY, int x, int y)"
            inline constexpr std::uintptr_t CheckSquare = 0x4A58A30; // "public static bool CheckSquare(IInventorySlotsModel inventorySlotsModel, int square)"
            inline constexpr std::uintptr_t CheckItemRectangle = 0x4A57120; // "public static bool CheckItemRectangle(InventoryItemDescription item, int x, int y, IInventoryModel inventoryModel, IInventorySlotModel ignoredSlotModel1, IInventorySlotModel ignoredSlotModel2, out int occupiedSlotIndex)"
            inline constexpr std::uintptr_t CheckItemRectangle_2 = 0x4A57260; // "public static bool CheckItemRectangle(InventoryItemDescription item, int x, int y, IInventoryModel inventoryModel, HashSet<IInventorySlotModel> ignoredSlotModels, out int occupiedSlotIndex)"
            inline constexpr std::uintptr_t CheckItemRectangle_3 = 0x4A56ED0; // "private static bool CheckItemRectangle(InventoryItemDescription item, int x, int y, IInventoryModel inventoryModel, Func<IInventorySlotModel, bool> isIgnoredFunc, out int occupiedSlotIndex)"
            inline constexpr std::uintptr_t CheckInventoryGroupUpperLeftRectangle = 0x4A56120; // "public static bool CheckInventoryGroupUpperLeftRectangle(InventoryItemDescription item, int x, int y, IInventoryModel inventoryModel, IInventorySlotModel ignoredSlotModel1, IInventorySlotModel ignoredSlotModel2, out int occupiedSlotIndex)"
            inline constexpr std::uintptr_t CheckInventoryGroupUpperLeftRectangle_2 = 0x4A56310; // "public static bool CheckInventoryGroupUpperLeftRectangle(InventoryItemDescription item, int x, int y, IInventoryModel inventoryModel, HashSet<IInventorySlotModel> ignoredSlotModels, out int occupiedSlotIndex)"
            inline constexpr std::uintptr_t CheckInventoryRectangleForIntersectedItems = 0x4A564F0; // "private static bool CheckInventoryRectangleForIntersectedItems(int startX, int endX, int startY, int endY, int x, int y, IInventoryModel inventoryModel, Func<IInventorySlotModel, bool> isIgnoredFunc, out int occupiedSlotIndex)"
            inline constexpr std::uintptr_t CheckItemsNotIntersect = 0x4A57A70; // "public static bool CheckItemsNotIntersect(InventoryCellsSizeDescription inventoryCellsSizeDescription, InventoryItemCellsSize firstItemCellsSize, int firstIndex, InventoryItemCellsSize secondItemCellsSize, int secondIndex)"
            inline constexpr std::uintptr_t CheckRectanglesNotIntersect = 0x4A58700; // "private static bool CheckRectanglesNotIntersect(int firstMinX, int firstMinY, int firstMaxX, int firstMaxY, int secondMinX, int secondMinY, int secondMaxX, int secondMaxY)"
            inline constexpr std::uintptr_t IsIgnored = 0x4A5B610; // "private static bool IsIgnored(IInventorySlotModel slotModel, IInventorySlotModel ignoredSlotModel1, IInventorySlotModel ignoredSlotModel2)"
            inline constexpr std::uintptr_t IsIgnored_2 = 0x4A5B620; // "private static bool IsIgnored(IInventorySlotModel slotModel, HashSet<IInventorySlotModel> ignoredSlotModels)"
            inline constexpr std::uintptr_t CanMoveFromInventorySlot = 0x4A54C70; // "public static bool CanMoveFromInventorySlot(IInventorySlotModel slotModel, int count, out bool isUnset)"
            inline constexpr std::uintptr_t CanMoveToInventory = 0x4A54FA0; // "public static bool CanMoveToInventory(IInventoryModel inventoryModel, IInventorySlotModel slotModel, InventoryItemDescription item, int count, int ammo, int durability, int cumulativePoints, IInventorySlotModel ignoredSlotModel, int linesDiff, out bool isSet)"
            inline constexpr std::uintptr_t CheckStackMergeBoundaries = 0x4A58E20; // "private static bool CheckStackMergeBoundaries(IInventoryModel inventoryModel, InventoryItemDescription item, int index, int linesDiff)"
            inline constexpr std::uintptr_t CanSwapInventorySlot = 0x4A55880; // "public static bool CanSwapInventorySlot(IInventoryModel inventoryModel, IInventorySlotModel slotModel, IInventorySlotModel ignoredSlotModel, InventoryItemDescription item, int count, int ammo, int durability, int cumulativePoints, int linesDiff)"
            inline constexpr std::uintptr_t CanSetToLootInventory = 0x4A555A0; // "public static bool CanSetToLootInventory(IInventorySlotModel slotModel, InventoryItemDescription item, int count, int ammo, int durability, int cumulativePoits, out bool isSet)"
            inline constexpr std::uintptr_t CanEquip = 0x4A54B80; // "public static bool CanEquip(IEquipSlotModel equipSlotModel, InventoryItemDescription itemDescription, int count, int ammo, int durability, int cumulativePoints)"
            inline constexpr std::uintptr_t CanSwapEquip = 0x4A557F0; // "public static bool CanSwapEquip(IEquipSlotModel equipSlotModel, InventoryItemDescription itemDescription, int count, int ammo, int durability, int cumulativePoints)"
            inline constexpr std::uintptr_t CheckSetEquip = 0x4A58900; // "public static bool CheckSetEquip(IEquipSlotModel equipSlotModel, InventoryItemDescription itemDescription, int count, int ammo, int durability, int cumulativePoints)"
            inline constexpr std::uintptr_t CanUnequip = 0x4A55A80; // "public static bool CanUnequip(IEquipSlotModel equipSlotModel)"
            inline constexpr std::uintptr_t CanMoveToPockets = 0x4A55330; // "public static bool CanMoveToPockets(IPocketSlotModel pocketSlotModel, InventoryItemDescription item, int count, int ammo, int durability, int cumulativePoints, out bool isSet)"
            inline constexpr std::uintptr_t CanSwapPocket = 0x4A55A40; // "public static bool CanSwapPocket(InventoryItemDescription item, int count, int ammo, int durability, int cumulativePoints)"
            inline constexpr std::uintptr_t CanMoveFromPockets = 0x4A54DA0; // "public static bool CanMoveFromPockets(IPocketSlotModel pocketSlotModel, int count, out bool isUnset)"
            inline constexpr std::uintptr_t CheckUnset = 0x4A59600; // "public static bool CheckUnset(IInventoryItemModel itemModel)"
            inline constexpr std::uintptr_t CanMoveToSlot = 0x4A554B0; // "private static bool CanMoveToSlot(IInventoryItemModel itemModel, IInventoryStackModel stackModel, InventoryItemDescription item, int count, out bool isSet)"
            inline constexpr std::uintptr_t CanMoveFromSlot = 0x4A54ED0; // "private static bool CanMoveFromSlot(IInventoryItemModel itemModel, IInventoryStackModel stackModel, int count, out bool isUnset)"
            inline constexpr std::uintptr_t CheckAmmo = 0x4A55B00; // "private static bool CheckAmmo(bool isSet, InventoryItemDescription itemDescription, int ammo)"
            inline constexpr std::uintptr_t CheckSetAmmo = 0x4A58870; // "private static bool CheckSetAmmo(InventoryItemDescription itemDescription, int ammo)"
            inline constexpr std::uintptr_t CheckDurability = 0x4A55C60; // "private static bool CheckDurability(InventoryItemDescription itemDescription, int durability)"
            inline constexpr std::uintptr_t CheckCumulativePoints = 0x4A55BE0; // "private static bool CheckCumulativePoints(InventoryItemDescription itemDescription, int cumulativePoints)"
            inline constexpr std::uintptr_t CheckPocketsBoundaries = 0x4A584B0; // "public static bool CheckPocketsBoundaries(IPocketsModel pocketsModel, int index)"
            inline constexpr std::uintptr_t CheckItemsUnderLine = 0x4A57B50; // "public static bool CheckItemsUnderLine(IInventoryModel inventory, int line)"
            inline constexpr std::uintptr_t CheckItemBetweenLines = 0x4A56E80; // "private static bool CheckItemBetweenLines(InventoryItemDescription item, int y, int line0, int line1)"
            inline constexpr std::uintptr_t GetNotEmptyLineCount = 0x4A5AF80; // "public static int GetNotEmptyLineCount(IInventoryModel inventory)"
            inline constexpr std::uintptr_t CheckPocketsEmpty = 0x4A58510; // "public static bool CheckPocketsEmpty(IPocketsModel pocketsModel, int startIndex)"
            inline constexpr std::uintptr_t CheckResizeInventory = 0x4A58720; // "public static bool CheckResizeInventory(IInventoryModel inventoryModel, int linesDiff)"
            inline constexpr std::uintptr_t CheckResizePockets = 0x4A587D0; // "public static bool CheckResizePockets(IPocketsModel pocketsModel, int pocketsDiff)"
            inline constexpr std::uintptr_t CheckSwapInSameInventory = 0x4A59050; // "public static bool CheckSwapInSameInventory(IInventoryModel inventoryModel, IInventorySlotModel selfModel, InventoryItemDescription selfItem, IInventorySlotModel newSelfModel, InventoryItemDescription otherItem, IInventorySlotModel otherModel, IInventorySlotModel newOtherModel)"
            inline constexpr std::uintptr_t CheckSwapInDifferentInventories = 0x4A58F00; // "public static bool CheckSwapInDifferentInventories(IInventoryModel inventoryModel, IInventorySlotModel slotModel, IInventoryModel storageInventoryModel, InventoryItemDescription selfItem, IInventorySlotModel newSelfSlotModel, InventoryItemDescription otherItem, IInventorySlotModel otherSlotModel, IInventorySlotModel newOtherSlotModel)"
            inline constexpr std::uintptr_t CheckSwapWithEquip = 0x4A59370; // "public static bool CheckSwapWithEquip(IInventoryModel inventoryModel, IInventorySlotModel slotModel, InventoryItemDescription otherItem, int otherCount, int otherAmmo, int otherDurability, int otherCumulativePoints, IInventorySlotModel otherDestinationSlotModel, IInventoryModel characterInventory, IPocketsModel pocketsModel)"
            inline constexpr std::uintptr_t CheckSwapInventoryWithOther = 0x4A592C0; // "public static bool CheckSwapInventoryWithOther(IInventoryModel inventoryModel, IInventorySlotModel slotModel, InventoryItemDescription otherItem, int otherCount, int otherAmmo, int otherDurability, int otherCumulativePoints, IInventorySlotModel otherSlotModelDestination)"
            inline constexpr std::uintptr_t MoveInventoryItems = 0x4A5B680; // "public static void MoveInventoryItems(IInventoryModel fromInventory, IInventoryModel toInventory)"
            inline constexpr std::uintptr_t CollectItemsFromInventory = 0x4A5A5B0; // "public static void CollectItemsFromInventory(IInventoryModel inventory, List<InventoryItem> items)"
            inline constexpr std::uintptr_t MoveItemsToInventory = 0x4A5BBA0; // "public static bool MoveItemsToInventory(IInventoryModel inventoryModel, List<InventoryItem> items)"
            inline constexpr std::uintptr_t TryAddItemToInventory = 0x4A5C700; // "public static bool TryAddItemToInventory(IInventoryModel inventory, InventoryItemDescription item, int stackAmount, int ammo, int durability, int cumulativePoints)"
            inline constexpr std::uintptr_t ClearInventory = 0x4A59FA0; // "public static void ClearInventory(IInventoryModel inventoryModel)"
            inline constexpr std::uintptr_t ClearInventorySlots = 0x4A59D20; // "public static void ClearInventorySlots(IInventorySlotsModel slots)"
            inline constexpr std::uintptr_t ClearInventorySlot = 0x4A59C90; // "private static void ClearInventorySlot(IInventorySlotModel slotModel)"
            inline constexpr std::uintptr_t IsEmptySlots = 0x4A5B430; // "public static bool IsEmptySlots(IInventorySlotsModel slots)"
            inline constexpr std::uintptr_t TryFindSlotForItem = 0x4A5C8F0; // "public static bool TryFindSlotForItem(IInventoryModel inventoryModel, InventoryItemDescription item, out IInventorySlotModel slot)"
            inline constexpr std::uintptr_t TryFindSlotForItem_2 = 0x4A5C970; // "public static bool TryFindSlotForItem(IInventoryModel inventoryModel, InventoryItemDescription item, HashSet<IInventorySlotModel> ignoredSlots, out IInventorySlotModel slot)"
            inline constexpr std::uintptr_t ClearEquip = 0x4A598D0; // "public static void ClearEquip(IEquipSlotsModel equipSlotsModel)"
            inline constexpr std::uintptr_t ClearEquipAmmo = 0x4A59650; // "public static void ClearEquipAmmo(IEquipAmmoModel equipAmmoModel)"
            inline constexpr std::uintptr_t ClearPockets = 0x4A5A230; // "public static void ClearPockets(IPocketsModel pocketsModel)"
            inline constexpr std::uintptr_t GetCellSizeFactor = 0x4A5AED0; // "public static int GetCellSizeFactor(InventoryItemDescription item)"
            inline constexpr std::uintptr_t CanClaimItemsHere = 0x4A549E0; // "public static bool CanClaimItemsHere(BattleModeDescription battleMode, BattleCharacterModel battleCharacterModel, PlotModel selfPlotModel)"
            inline constexpr std::uintptr_t IsClaimItemsAvailableByCharacterRole = 0x4A5B340; // "private static bool IsClaimItemsAvailableByCharacterRole(BattleCharacterModel battleCharacterModel)"
            inline constexpr std::uintptr_t IsClaimItemsAvailableOnLocation = 0x4A5B410; // "private static bool IsClaimItemsAvailableOnLocation(BattleModeDescription battleMode)"
            inline constexpr std::uintptr_t CanClaimItemsByCharacterPosition = 0x3973C50; // "private static bool CanClaimItemsByCharacterPosition(BattleModeDescription battleMode, BattleCharacterModel battleCharacterModel, PlotModel selfPlotModel)"
            inline constexpr std::uintptr_t CheckItemsForRecipe = 0x4A57380; // "public static bool CheckItemsForRecipe(IInventoryModel inventory, BarterRecipeDescription recipe, HashSet<IInventorySlotModel> slotsToUnset, Dictionary<IInventorySlotModel, int> slotsToReduceStack)"
            inline constexpr std::uintptr_t CountItemsInInventory = 0x4A5AAD0; // "public static int CountItemsInInventory(IInventoryModel inventory, InventoryItemDescription description)"
            inline constexpr std::uintptr_t CheckPayItemsPrice = 0x4A582A0; // "public static bool CheckPayItemsPrice(IInventoryModel inventory, InventoryItemsPrice inventoryItemsPrice)"
            inline constexpr std::uintptr_t CheckPayItemPrice = 0x4A58200; // "public static bool CheckPayItemPrice(IInventoryModel inventory, InventoryItemWithAmount itemWithAmount, out InventorySearchResult searchResult)"
            inline constexpr std::uintptr_t CheckPayItemPrice_2 = 0x4A57D80; // "public static bool CheckPayItemPrice(IInventoryModel inventory, InventoryItemDescription item, int amount, out InventorySearchResult searchResult)"
            inline constexpr std::uintptr_t PayItemPrice = 0x4A5C2A0; // "public static void PayItemPrice(IInventoryModel inventory, InventorySearchResult searchResult)"
            inline constexpr std::uintptr_t PayItemsPrice = 0x4A5C4B0; // "public static void PayItemsPrice(IInventoryModel inventory, InventoryItemsPrice inventoryItemsPrice)"
            inline constexpr std::uintptr_t PayItemPrice_2 = 0x4A5C210; // "public static void PayItemPrice(IInventoryModel inventory, InventoryItemWithAmount itemWithAmount)"
            inline constexpr std::uintptr_t PayItemPrice_3 = 0x4A5BF50; // "public static void PayItemPrice(IInventoryModel inventory, InventoryItemDescription item, int amount)"
            inline constexpr std::uintptr_t GetDefaultAmmo = 0x4A5AF10; // "public static int GetDefaultAmmo(InventoryItemDescription item)"
        }
    } // namespace InventoryRules

    namespace InventorySearchResult { // "Models.Inventory.InventorySearchResult (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Slots = 0x10; // "InventorySlotDescription[]"
            inline constexpr std::uintptr_t AmountPerSlot = 0x18; // "int[]"
            inline constexpr std::uintptr_t SlotsCount = 0x20; // "int"
            inline constexpr std::uintptr_t Amount = 0x24; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Reset = 0x48B2030; // "public void Reset()"
        }
    } // namespace InventorySearchResult

    namespace InventorySearchRules { // "Models.Inventory.InventorySearchRules (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t FindItem = 0x4A5D290; // "public static bool FindItem(IInventoryModel inventoryModel, InventoryItemDescription itemDescription, out IInventorySlotModel slot)"
            inline constexpr std::uintptr_t FindItemByType = 0x4A5D0C0; // "public static bool FindItemByType(IInventoryModel inventoryModel, InventoryItemType type, out IInventorySlotModel slot)"
            inline constexpr std::uintptr_t FindItemByCondition = 0x4A5CEE0; // "public static bool FindItemByCondition(IInventoryModel inventoryModel, Func<InventoryItemDescription, bool> predicate, out IInventorySlotModel slot)"
        }
    } // namespace InventorySearchRules

    namespace InventorySelectedModel { // "Game.Battle.Inventory.InventorySelectedModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ItemContext = 0x10; // "IItemMoveContext"
            inline constexpr std::uintptr_t NeedHighlightItem = 0x18; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_HasItemContext = 0xA18FC0; // "public bool get_HasItemContext()"
            inline constexpr std::uintptr_t SetItemContext = 0x7EC730; // "public void SetItemContext(IItemMoveContext item)"
            inline constexpr std::uintptr_t ClearItemContext = 0xA63F90; // "public void ClearItemContext()"
        }
    } // namespace InventorySelectedModel

    namespace InventorySelectedView { // "Game.Battle.Inventory.InventorySelectedView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t transform = 0x20; // "RectTransform"
            inline constexpr std::uintptr_t offset = 0x28; // "Vector2"
        }
        namespace Methods {
            inline constexpr std::uintptr_t ResetAnchorPosition = 0xA63FC0; // "public void ResetAnchorPosition()"
        }
    } // namespace InventorySelectedView

    namespace InventorySellItemMessage { // "Models.Messages.Inventory.Sell.InventorySellItemMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t entityId = 0x20; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t slot = 0x28; // "IPrimitiveData<InventorySlotDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Slot = 0x4A28D70; // "public InventorySlotDescription get_Slot()"
            inline constexpr std::uintptr_t get_Type = 0x4A28E10; // "public override string get_Type()"
            inline constexpr std::uintptr_t get_TraderEntityId = 0x4A28DC0; // "public override int get_TraderEntityId()"
        }
    } // namespace InventorySellItemMessage

    namespace InventoryShadowAreaModel { // "Game.Battle.Entities.Player.Models.InventoryShadowAreaModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsItemInBound = 0x10; // "bool"
            inline constexpr std::uintptr_t Position = 0x14; // "Vector2Int"
            inline constexpr std::uintptr_t Size = 0x1C; // "Vector2Int"
            inline constexpr std::uintptr_t IsValid = 0x24; // "bool"
            inline constexpr std::uintptr_t SlotPosition = 0x28; // "Vector2Int"
            inline constexpr std::uintptr_t IsVisible = 0x30; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Clear = 0xB1DEC0; // "public void Clear()"
        }
    } // namespace InventoryShadowAreaModel

    namespace InventorySizeConfig { // "Models.References.InventorySizeConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t TrunkLineLength = 0x10; // "int"
            inline constexpr std::uintptr_t MinDynamicLineCount = 0x14; // "int"
            inline constexpr std::uintptr_t BattleCharacterFunc = 0x18; // "Func<InventoryCellsSizeDescription>"
            inline constexpr std::uintptr_t StorageMaxFunc = 0x20; // "Func<InventoryCellsSizeDescription>"
            inline constexpr std::uintptr_t PlotContainerMaxFunc = 0x28; // "Func<InventoryCellsSizeDescription>"
            inline constexpr std::uintptr_t BattleCharacterLootFunc = 0x30; // "Func<InventoryCellsSizeDescription>"
            inline constexpr std::uintptr_t ContainerLootMaxFunc = 0x38; // "Func<InventoryCellsSizeDescription>"
            inline constexpr std::uintptr_t BuyerLootFunc = 0x40; // "Func<InventoryCellsSizeDescription>"
            inline constexpr std::uintptr_t CargoOpenWorkbenchSlotMaxFunc = 0x48; // "Func<InventoryCellsSizeDescription>"
            inline constexpr std::uintptr_t BuilderLootPageFunc = 0x50; // "Func<InventoryCellsSizeDescription>"
            inline constexpr std::uintptr_t TraderFunc = 0x58; // "Func<InventoryCellsSizeDescription>"
            inline constexpr std::uintptr_t CollectionTableFunc = 0x60; // "Func<InventoryCellsSizeDescription>"
            inline constexpr std::uintptr_t CopRewardBoxFunc = 0x68; // "Func<InventoryCellsSizeDescription>"
            inline constexpr std::uintptr_t RouletteFunc = 0x70; // "Func<InventoryCellsSizeDescription>"
            inline constexpr std::uintptr_t PersonalRepositoryMaxFunc = 0x78; // "Func<InventoryCellsSizeDescription>"
            inline constexpr std::uintptr_t PoliceBadgeRepositoryFunc = 0x80; // "Func<InventoryCellsSizeDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_BattleCharacter = 0x26CF2F0; // "public InventoryCellsSizeDescription get_BattleCharacter()"
            inline constexpr std::uintptr_t get_StorageMax = 0x9D6230; // "public InventoryCellsSizeDescription get_StorageMax()"
            inline constexpr std::uintptr_t get_PlotContainerMax = 0x993E50; // "public InventoryCellsSizeDescription get_PlotContainerMax()"
            inline constexpr std::uintptr_t get_BattleCharacterLoot = 0x9AA5D0; // "public InventoryCellsSizeDescription get_BattleCharacterLoot()"
            inline constexpr std::uintptr_t get_ContainerLootMax = 0x2AA0B60; // "public InventoryCellsSizeDescription get_ContainerLootMax()"
            inline constexpr std::uintptr_t get_BuyerLoot = 0x4048E60; // "public InventoryCellsSizeDescription get_BuyerLoot()"
            inline constexpr std::uintptr_t get_CargoOpenWorkbenchSlotMax = 0x4048E90; // "public InventoryCellsSizeDescription get_CargoOpenWorkbenchSlotMax()"
            inline constexpr std::uintptr_t get_BuilderLootPage = 0x1CE7810; // "public InventoryCellsSizeDescription get_BuilderLootPage()"
            inline constexpr std::uintptr_t get_Trader = 0x4048FB0; // "public InventoryCellsSizeDescription get_Trader()"
            inline constexpr std::uintptr_t get_CollectionTable = 0x4048EC0; // "public InventoryCellsSizeDescription get_CollectionTable()"
            inline constexpr std::uintptr_t get_CopRewardBox = 0x4048EF0; // "public InventoryCellsSizeDescription get_CopRewardBox()"
            inline constexpr std::uintptr_t get_Roulette = 0x4048F80; // "public InventoryCellsSizeDescription get_Roulette()"
            inline constexpr std::uintptr_t get_PersonalRepositoryMax = 0x4048F20; // "public InventoryCellsSizeDescription get_PersonalRepositoryMax()"
            inline constexpr std::uintptr_t get_PoliceBadgeRepository = 0x4048F50; // "public InventoryCellsSizeDescription get_PoliceBadgeRepository()"
        }
    } // namespace InventorySizeConfig

    namespace InventorySlot { // "Models.Models.InventorySlot.InventorySlot (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x8277570; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace Fields {
            inline constexpr std::uintptr_t raw = 0x0; // "int"
        }
        namespace StaticFields {
            inline constexpr std::uintptr_t DurabilityBits = 0x0; // "int"
            inline constexpr std::uintptr_t PayloadBits = 0x4; // "int"
            inline constexpr std::uintptr_t ItemBits = 0x8; // "int"
            inline constexpr std::uintptr_t DurabilityShift = 0xC; // "int"
            inline constexpr std::uintptr_t PayloadShift = 0x10; // "int"
            inline constexpr std::uintptr_t ItemShift = 0x14; // "int"
            inline constexpr std::uintptr_t DurabilityMask = 0x18; // "int"
            inline constexpr std::uintptr_t PayloadMask = 0x1C; // "int"
            inline constexpr std::uintptr_t ItemMask = 0x20; // "int"
            inline constexpr std::uintptr_t ExceptDurabilityMask = 0x24; // "int"
            inline constexpr std::uintptr_t ExceptPayloadMask = 0x28; // "int"
            inline constexpr std::uintptr_t ExceptItemMask = 0x2C; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Durability = 0x4939A70; // "public int get_Durability()"
            inline constexpr std::uintptr_t get_Payload = 0x4939BB0; // "public int get_Payload()"
            inline constexpr std::uintptr_t get_Item = 0x4939AE0; // "public InventoryItemDescription get_Item()"
            inline constexpr std::uintptr_t WithDurability = 0x49395D0; // "public InventorySlot WithDurability(int durability)"
            inline constexpr std::uintptr_t WithPayload = 0x49396F0; // "public InventorySlot WithPayload(int payload)"
            inline constexpr std::uintptr_t WithItem = 0x4939640; // "public InventorySlot WithItem(InventoryItemDescription item)"
            inline constexpr std::uintptr_t get_Raw = 0x9CAFB0; // "public int get_Raw()"
            inline constexpr std::uintptr_t FromRaw = 0xEE4B90; // "public static InventorySlot FromRaw(int raw)"
            inline constexpr std::uintptr_t ValidatePayload = 0x49394A0; // "private static void ValidatePayload(int payload)"
            inline constexpr std::uintptr_t ValidateDurability = 0x4939370; // "private static void ValidateDurability(int durability)"
        }
    } // namespace InventorySlot

    namespace InventorySlotAmmoModel { // "Models.Models.AmmoModel.InventorySlotAmmoModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "InventorySlotData"
            inline constexpr std::uintptr_t itemModel = 0x18; // "IInventoryItemModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Value = 0x49ECEF0; // "public int get_Value()"
            inline constexpr std::uintptr_t set_Value = 0x49ED010; // "public void set_Value(int value)"
        }
    } // namespace InventorySlotAmmoModel

    namespace InventorySlotBlockedUpdater { // "Game.Battle.Inventory.InventorySlotBlockedUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleModel = 0x20; // "BattleModel"
            inline constexpr std::uintptr_t blockedView = 0x28; // "SlotBlockedView"
            inline constexpr std::uintptr_t lockedView = 0x30; // "SlotLockedView"
            inline constexpr std::uintptr_t draggableItemView = 0x38; // "DraggableItemView"
            inline constexpr std::uintptr_t pointerButtonView = 0x40; // "PointerButtonView"
            inline constexpr std::uintptr_t itemMoveContext = 0x48; // "IItemMoveContext"
            inline constexpr std::uintptr_t pocketsModel = 0x50; // "IPocketsModel"
            inline constexpr std::uintptr_t blockedSlotsModel = 0x58; // "BlockedSlotsModel"
            inline constexpr std::uintptr_t inventoryDragAndDropModel = 0x60; // "InventoryDragAndDropModel"
            inline constexpr std::uintptr_t buyBlockedSlotsModel = 0x68; // "BlockedSlotsModel"
            inline constexpr std::uintptr_t lockedTraderItemByLocationTier = 0x70; // "BlockedSlotsModel"
            inline constexpr std::uintptr_t lockedTraderItemByVendorTree = 0x78; // "BlockedSlotsModel"
            inline constexpr std::uintptr_t isInteractable = 0x80; // "Nullable<bool>"
            inline constexpr std::uintptr_t isDraggable = 0x82; // "Nullable<bool>"
            inline constexpr std::uintptr_t showBlocked = 0x84; // "Nullable<bool>"
            inline constexpr std::uintptr_t isLocked = 0x86; // "Nullable<bool>"
            inline constexpr std::uintptr_t isBeltEquipped = 0x88; // "Nullable<bool>"
            inline constexpr std::uintptr_t lockType = 0x8C; // "SlotLockedView.LockType"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA640F0; // "public InventorySlotBlockedUpdater Init(BattleModel battleModel, IItemMoveContext itemMoveContext, SlotBlockedView blockedView, SlotLockedView lockedView, DraggableItemView draggableItemView, PointerButtonView pointerButtonView)"
            inline constexpr std::uintptr_t Dispose = 0xA64080; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA642D0; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace InventorySlotBlockedUpdater

    namespace InventorySlotCumulativeUpdater { // "Game.Battle.Inventory.InventorySlotCumulativeUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t inventoryItemCumulativeView = 0x20; // "PooledLoadedComponentContent<InventoryItemCumulativeView>"
            inline constexpr std::uintptr_t itemModel = 0x28; // "IInventoryItemModel"
            inline constexpr std::uintptr_t slotModelCumulativePointsModel = 0x30; // "ICumulativePointsModel"
            inline constexpr std::uintptr_t itemSlotCumulativeViewContent = 0x38; // "IDisposableContent<InventoryItemCumulativeView>"
            inline constexpr std::uintptr_t data = 0x40; // "ValueTuple<int, int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA00E30; // "public InventorySlotCumulativeUpdater Init(InventoryScreenContent inventoryScreenContent, IInventoryItemModel itemModel, ICumulativePointsModel slotModelCumulativePointsModel, RectTransform compositeParent)"
            inline constexpr std::uintptr_t Dispose = 0xA00DB0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA00F30; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace InventorySlotCumulativeUpdater

    namespace InventorySlotData { // "Models.Data.InventorySlotData (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x82778A0; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace Fields {
            inline constexpr std::uintptr_t serializer = 0x10; // "IPrimitiveSerializer<InventorySlot>"
            inline constexpr std::uintptr_t value = 0x18; // "InventorySlot"
            inline constexpr std::uintptr_t Changed = 0x20; // "PrimitiveDataProviderChangedHandler"
            inline constexpr std::uintptr_t defaultValue = 0x28; // "InventorySlot"
        }
        namespace StaticFields {
            inline constexpr std::uintptr_t inventorySlotserializer = 0x0; // "IPrimitiveSerializer<InventorySlot>"
        }
    } // namespace InventorySlotData

    namespace InventorySlotDataExtensions { // "Models.Utils.Extensions.InventorySlotDataExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t SetItem = 0x395F760; // "public static void SetItem(InventorySlotData data, InventoryItemDescription item)"
            inline constexpr std::uintptr_t SetPayload = 0x395F870; // "public static void SetPayload(InventorySlotData data, int payload)"
            inline constexpr std::uintptr_t SetDurability = 0x395F670; // "public static void SetDurability(InventorySlotData data, int durability)"
        }
    } // namespace InventorySlotDataExtensions

    namespace InventorySlotDescription { // "Models.References.Inventory.InventorySlotDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x8277A38; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t slots = 0x0; // "List<InventorySlotDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Get = 0x43E99A0; // "public static InventorySlotDescription Get(int index)"
        }
    } // namespace InventorySlotDescription

    namespace InventorySlotDurabilityModel { // "Models.Models.DurabilityModel.InventorySlotDurabilityModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "InventorySlotData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Value = 0x4965170; // "public int get_Value()"
            inline constexpr std::uintptr_t set_Value = 0x4965230; // "public void set_Value(int value)"
        }
    } // namespace InventorySlotDurabilityModel

    namespace InventorySlotDurabilityUpdater { // "Game.Battle.Inventory.InventorySlotDurabilityUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t itemModel = 0x20; // "IInventoryItemModel"
            inline constexpr std::uintptr_t durabilityModel = 0x28; // "IDurabilityModel"
            inline constexpr std::uintptr_t view = 0x30; // "IItemDurabilityView"
            inline constexpr std::uintptr_t visible = 0x38; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA010C0; // "public InventorySlotDurabilityUpdater Init(IInventoryItemModel itemModel, IDurabilityModel durabilityModel, IItemDurabilityView view)"
            inline constexpr std::uintptr_t Dispose = 0x9F6DA0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA01170; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace InventorySlotDurabilityUpdater

    namespace InventorySlotExtension { // "Models.Utils.Extensions.InventorySlotExtension (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t Dec = 0x395F970; // "public static void Dec(IInventorySlotModel model, int amount)"
        }
    } // namespace InventorySlotExtension

    namespace InventorySlotGlowView { // "Game.Battle.Inventory.InventorySlotGlowView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t glow = 0x20; // "Image"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetGlow = 0xA16760; // "public void SetGlow(bool value)"
        }
    } // namespace InventorySlotGlowView

    namespace InventorySlotIconUpdater { // "Game.Battle.Inventory.InventorySlotIconUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x20; // "IInventoryItemModel"
            inline constexpr std::uintptr_t view = 0x28; // "InventoryIconView"
            inline constexpr std::uintptr_t iconView = 0x30; // "ISlotIconView"
            inline constexpr std::uintptr_t inventoryItemViewDescriptions = 0x38; // "InventoryItemViewDescriptions"
            inline constexpr std::uintptr_t itemMoveContext = 0x40; // "IItemMoveContext"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA64980; // "public InventorySlotIconUpdater Init(IInventoryItemModel model, InventoryIconView view, ISlotIconView iconView, InventoryItemViewDescriptions inventoryItemViewDescriptions, IItemMoveContext itemMoveContext)"
            inline constexpr std::uintptr_t Dispose = 0xA123B0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA64A60; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace InventorySlotIconUpdater

    namespace InventorySlotItemModel { // "Models.Models.InventoryItemModel.InventorySlotItemModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "InventorySlotData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Value = 0x4938140; // "public InventoryItemDescription get_Value()"
            inline constexpr std::uintptr_t set_Value = 0x49381B0; // "public void set_Value(InventoryItemDescription value)"
            inline constexpr std::uintptr_t get_IsEmpty = 0x49380C0; // "public bool get_IsEmpty()"
        }
    } // namespace InventorySlotItemModel

    namespace InventorySlotModel { // "Models.Models.InventorySlotModel.InventorySlotModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Description = 0x10; // "InventorySlotDescription"
            inline constexpr std::uintptr_t ItemModel = 0x18; // "IInventoryItemModel"
            inline constexpr std::uintptr_t StackModel = 0x20; // "IInventoryStackModel"
            inline constexpr std::uintptr_t AmmoModel = 0x28; // "IAmmoModel"
            inline constexpr std::uintptr_t DurabilityModel = 0x30; // "IDurabilityModel"
            inline constexpr std::uintptr_t CumulativePointsModel = 0x38; // "ICumulativePointsModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Set = 0x49381C0; // "public void Set(InventoryItemDescription item, int count, int ammo, int durability, int cumulativePoints)"
            inline constexpr std::uintptr_t Unset = 0x4938390; // "public void Unset()"
        }
    } // namespace InventorySlotModel

    namespace InventorySlotNewNotificationUpdater { // "Game.Battle.Inventory.InventorySlotNewNotificationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleModel = 0x20; // "BattleModel"
            inline constexpr std::uintptr_t itemMoveContext = 0x28; // "IItemMoveContext"
            inline constexpr std::uintptr_t newAvailableItemsModel = 0x30; // "NewAvailableItemsModel"
            inline constexpr std::uintptr_t slotModel = 0x38; // "IInventorySlotModel"
            inline constexpr std::uintptr_t inventorySelectedModel = 0x40; // "InventorySelectedModel"
            inline constexpr std::uintptr_t newContentIndicatorView = 0x48; // "NewContentIndicatorView"
            inline constexpr std::uintptr_t pointerButtonView = 0x50; // "PointerButtonView"
            inline constexpr std::uintptr_t inventoryItemDescription = 0x58; // "InventoryItemDescription"
            inline constexpr std::uintptr_t hasNewNotification = 0x60; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA01280; // "public InventorySlotNewNotificationUpdater Init(BattleModel battleModel, IItemMoveContext itemMoveContext, IInventorySlotModel slotModel, NewContentIndicatorView newContentIndicatorView, PointerButtonView pointerButtonView)"
            inline constexpr std::uintptr_t Dispose = 0xA01220; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA013B0; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace InventorySlotNewNotificationUpdater

    namespace InventorySlotRareUpdater { // "Game.Battle.Inventory.InventorySlotRareUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t itemModel = 0x20; // "IInventoryItemModel"
            inline constexpr std::uintptr_t view = 0x28; // "IItemRareView"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0x9F7740; // "public InventorySlotRareUpdater Init(IInventoryItemModel itemModel, IItemRareView view)"
            inline constexpr std::uintptr_t Dispose = 0x92B5C0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA015F0; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace InventorySlotRareUpdater

    namespace InventorySlotReparentProgressBackgroundsViewUpdater { // "Game.Battle.Inventory.InventorySlotReparentProgressBackgroundsViewUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t inventoryProgressItemModel = 0x20; // "InventoryProgressItemModel"
            inline constexpr std::uintptr_t itemMoveContext = 0x28; // "IItemMoveContext"
            inline constexpr std::uintptr_t progressView = 0x30; // "InventoryProgressView"
            inline constexpr std::uintptr_t progressParent = 0x38; // "RectTransform"
            inline constexpr std::uintptr_t parentView = 0x40; // "Transform"
            inline constexpr std::uintptr_t rectTransform = 0x48; // "RectTransform"
            inline constexpr std::uintptr_t isVisible = 0x50; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA01710; // "public InventorySlotReparentProgressBackgroundsViewUpdater Init(BattleModel battleModel, IItemMoveContext itemMoveContext, InventoryProgressView progressView, RectTransform progressParent, PointerButtonView pointerButtonView, Transform parentView)"
            inline constexpr std::uintptr_t Dispose = 0xA016A0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA01880; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t ReleaseProgressBg = 0xA01A00; // "private void ReleaseProgressBg()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace InventorySlotReparentProgressBackgroundsViewUpdater

    namespace InventorySlotReparentSelectedBackgroundsViewUpdater { // "Game.Battle.Inventory.InventorySlotReparentSelectedBackgroundsViewUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t inventorySelectedModel = 0x20; // "InventorySelectedModel"
            inline constexpr std::uintptr_t pool = 0x28; // "IComponentInstantiateContent<InventorySelectedView>"
            inline constexpr std::uintptr_t itemMoveContext = 0x30; // "IItemMoveContext"
            inline constexpr std::uintptr_t inventoryModel = 0x38; // "IInventoryModel"
            inline constexpr std::uintptr_t progressParent = 0x40; // "RectTransform"
            inline constexpr std::uintptr_t parentView = 0x48; // "Transform"
            inline constexpr std::uintptr_t selectedView = 0x50; // "IDisposableContent<InventorySelectedView>"
            inline constexpr std::uintptr_t isVisible = 0x58; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA01C10; // "public InventorySlotReparentSelectedBackgroundsViewUpdater Init(BattleModel battleModel, BattleScreenContent battleScreenContent, IItemMoveContext itemMoveContext, IInventoryModel inventoryModel, RectTransform progressParent, Transform parentView)"
            inline constexpr std::uintptr_t Dispose = 0xA01B10; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA01CD0; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t GetInventory = 0xA01BB0; // "private IInventoryModel GetInventory(IItemMoveContext itemMoveContext)"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace InventorySlotReparentSelectedBackgroundsViewUpdater

    namespace InventorySlotsModel { // "Models.Models.InventorySlotsModel.InventorySlotsModel (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t get_Item = 0x4939D00; // "public IInventorySlotModel get_Item(int index)"
        }
    } // namespace InventorySlotsModel

    namespace InventorySlotStackModel { // "Models.Models.InventoryStackModel.InventorySlotStackModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "InventorySlotData"
            inline constexpr std::uintptr_t itemModel = 0x18; // "IInventoryItemModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Value = 0x4938F60; // "public int get_Value()"
            inline constexpr std::uintptr_t set_Value = 0x4939080; // "public void set_Value(int value)"
        }
    } // namespace InventorySlotStackModel

    namespace InventorySlotUseViewUpdater { // "Game.Battle.Inventory.InventorySlotUseViewUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dragModel = 0x20; // "InventoryDragAndDropModel"
            inline constexpr std::uintptr_t slotDropInfoView = 0x28; // "SlotDropInfoView"
            inline constexpr std::uintptr_t useItemDragAndDropModel = 0x30; // "UseItemDragAndDropModel"
            inline constexpr std::uintptr_t visible = 0x38; // "bool"
            inline constexpr std::uintptr_t currentHover = 0x40; // "IItemMoveContext"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA16810; // "public InventorySlotUseViewUpdater Init(InventoryDragAndDropModel dragModel, SlotDropInfoView slotDropInfoView, UseItemDragAndDropModel useItemDragAndDropModel)"
            inline constexpr std::uintptr_t Dispose = 0xA167B0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA168E0; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace InventorySlotUseViewUpdater

    namespace InventorySwapMessage { // "Models.Messages.Inventory.Swap.InventorySwapMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t fromSource = 0x20; // "IPrimitiveData<SlotSourceDescription>"
            inline constexpr std::uintptr_t fromInventorySourceSlot = 0x28; // "IPrimitiveData<InventorySlotDescription>"
            inline constexpr std::uintptr_t fromInventoryDestinationSlot = 0x30; // "IPrimitiveData<InventorySlotDescription>"
            inline constexpr std::uintptr_t fromEquipSlot = 0x38; // "IPrimitiveData<EquipSlotDescription>"
            inline constexpr std::uintptr_t fromPocketSlot = 0x40; // "IPrimitiveData<PocketSlotDescription>"
            inline constexpr std::uintptr_t fromEntityId = 0x48; // "BattleEntityIdData"
            inline constexpr std::uintptr_t toSource = 0x50; // "IPrimitiveData<SlotSourceDescription>"
            inline constexpr std::uintptr_t toInventorySourceSlot = 0x58; // "IPrimitiveData<InventorySlotDescription>"
            inline constexpr std::uintptr_t toInventoryDestinationSlot = 0x60; // "IPrimitiveData<InventorySlotDescription>"
            inline constexpr std::uintptr_t toEquipSlot = 0x68; // "IPrimitiveData<EquipSlotDescription>"
            inline constexpr std::uintptr_t toPocketSlot = 0x70; // "IPrimitiveData<PocketSlotDescription>"
            inline constexpr std::uintptr_t toEntityId = 0x78; // "BattleEntityIdData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_FromSource = 0x4A299C0; // "public SlotSourceDescription get_FromSource()"
            inline constexpr std::uintptr_t get_FromInventorySourceSlot = 0x4A29920; // "public InventorySlotDescription get_FromInventorySourceSlot()"
            inline constexpr std::uintptr_t get_FromInventoryDestinationSlot = 0x4A298D0; // "public InventorySlotDescription get_FromInventoryDestinationSlot()"
            inline constexpr std::uintptr_t get_FromEquipSlot = 0x4A29880; // "public EquipSlotDescription get_FromEquipSlot()"
            inline constexpr std::uintptr_t get_FromPocketSlot = 0x4A29970; // "public PocketSlotDescription get_FromPocketSlot()"
            inline constexpr std::uintptr_t get_FromEntityId = 0x4A29840; // "public int get_FromEntityId()"
            inline constexpr std::uintptr_t get_ToSource = 0x4A29B90; // "public SlotSourceDescription get_ToSource()"
            inline constexpr std::uintptr_t get_ToInventorySourceSlot = 0x4A29AF0; // "public InventorySlotDescription get_ToInventorySourceSlot()"
            inline constexpr std::uintptr_t get_ToInventoryDestinationSlot = 0x4A29AA0; // "public InventorySlotDescription get_ToInventoryDestinationSlot()"
            inline constexpr std::uintptr_t get_ToEquipSlot = 0x4A29A50; // "public EquipSlotDescription get_ToEquipSlot()"
            inline constexpr std::uintptr_t get_ToPocketSlot = 0x4A29B40; // "public PocketSlotDescription get_ToPocketSlot()"
            inline constexpr std::uintptr_t get_ToEntityId = 0x4A29A10; // "public int get_ToEntityId()"
            inline constexpr std::uintptr_t get_Type = 0x4A29BE0; // "public override string get_Type()"
        }
    } // namespace InventorySwapMessage

    namespace InventoryTakeCommand { // "Models.Messages.Inventory.Take.InventoryTakeCommand (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t EntityIdIndex = 0x10; // "int"
            inline constexpr std::uintptr_t Type = 0x18; // "InventoryTakeCommandTypeDescription"
            inline constexpr std::uintptr_t FromSlot = 0x20; // "InventorySlotDescription"
            inline constexpr std::uintptr_t ToSlotIndex = 0x28; // "int"
            inline constexpr std::uintptr_t Count = 0x2C; // "int"
        }
    } // namespace InventoryTakeCommand

    namespace InventoryTakeCommandData { // "Models.Messages.Inventory.Take.InventoryTakeCommandData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t entityIdIndex = 0x20; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t type = 0x28; // "IPrimitiveData<InventoryTakeCommandTypeDescription>"
            inline constexpr std::uintptr_t fromSlot = 0x30; // "IPrimitiveData<InventorySlotDescription>"
            inline constexpr std::uintptr_t toSlotIndex = 0x38; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t count = 0x40; // "IPrimitiveData<int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Set = 0x4A29DE0; // "public void Set(InventoryTakeCommand command)"
            inline constexpr std::uintptr_t Get = 0x4A29C10; // "public InventoryTakeCommand Get()"
        }
    } // namespace InventoryTakeCommandData

    namespace InventoryTakeCommandTypeDescription { // "Models.References.InventoryTakeCommandTypeDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x8278890; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t enum_id = 0x0; // "Enum<InventoryTakeCommandTypeDescription>"
            inline constexpr std::uintptr_t Inventory = 0x8; // "InventoryTakeCommandTypeDescription"
            inline constexpr std::uintptr_t Equip = 0x10; // "InventoryTakeCommandTypeDescription"
            inline constexpr std::uintptr_t Pocket = 0x18; // "InventoryTakeCommandTypeDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Enum = 0x4049240; // "public static ReadOnlyEnum<InventoryTakeCommandTypeDescription> get_Enum()"
        }
    } // namespace InventoryTakeCommandTypeDescription

    namespace InventoryTakeCommandTypeExtensions { // "Models.Utils.Extensions.InventoryTakeCommandTypeExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t TryBuildItemActionModel = 0x395FA50; // "public static bool TryBuildItemActionModel(IItemActionModels itemActionModels, BattleCharacterModel model, InventoryTakeCommandTypeDescription type, int slotIndex, out IItemActionModel itemActionModel)"
        }
    } // namespace InventoryTakeCommandTypeExtensions

    namespace InventoryTakeExtensions { // "Models.Utils.Extensions.InventoryTakeExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t SingleCommandMessage = 0x395FEA0; // "public static InventoryTakeMessage SingleCommandMessage(int entityId, InventoryTakeCommandTypeDescription type, InventorySlotDescription fromSlot, int toSlotIndex, int count)"
            inline constexpr std::uintptr_t SinglePageMessage = 0x39600B0; // "public static InventoryTakeMessage SinglePageMessage(int entityId, List<InventoryTakeCommand> commands)"
        }
    } // namespace InventoryTakeExtensions

    namespace InventoryTakeMessage { // "Models.Messages.Inventory.Take.InventoryTakeMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t entityIds = 0x20; // "ListData<IPrimitiveData<int>>"
            inline constexpr std::uintptr_t commands = 0x28; // "ListData<InventoryTakeCommandData>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t AddProperties = 0x4A2A3A0; // "private void AddProperties()"
            inline constexpr std::uintptr_t GetCommands = 0x4A2A430; // "public IEnumerable<InventoryTakeCommand> GetCommands()"
            inline constexpr std::uintptr_t get_EntityIdsCount = 0x4A2ACC0; // "public int get_EntityIdsCount()"
            inline constexpr std::uintptr_t GetFirstEntityId = 0x4A2A5D0; // "public int GetFirstEntityId()"
            inline constexpr std::uintptr_t GetEntityId = 0x4A2A550; // "public int GetEntityId(int entityIdIndex)"
            inline constexpr std::uintptr_t get_Type = 0x4A2AD10; // "public override string get_Type()"
        }
    } // namespace InventoryTakeMessage

    namespace InventoryTooltipButtonsUpdater { // "Game.Battle.Inventory.InventoryTooltipButtonsUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t itemSplitModel = 0x10; // "ItemSplitModel"
            inline constexpr std::uintptr_t itemMoveModel = 0x18; // "ItemMoveModel"
            inline constexpr std::uintptr_t inventorySelectedModel = 0x20; // "InventorySelectedModel"
            inline constexpr std::uintptr_t currentInventoryModel = 0x28; // "CurrentInventoryModel"
            inline constexpr std::uintptr_t useItemsRule = 0x30; // "UseItemsRule"
            inline constexpr std::uintptr_t shopSplitModel = 0x38; // "ShopSplitModel"
            inline constexpr std::uintptr_t updater = 0x40; // "IUpdater"
            inline constexpr std::uintptr_t personalNotificationModel = 0x48; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t uiSoundModel = 0x50; // "BattleUISoundModel"
            inline constexpr std::uintptr_t inventoryScreenModel = 0x58; // "IScreenModel"
            inline constexpr std::uintptr_t tooltipModel = 0x60; // "TooltipModel"
            inline constexpr std::uintptr_t player = 0x68; // "PlayerEntityModel"
            inline constexpr std::uintptr_t unlockRequirementItemPositionModel = 0x70; // "UnlockRequirementItemPositionModel"
            inline constexpr std::uintptr_t localizationKeys = 0x78; // "LocalizationKeys"
            inline constexpr std::uintptr_t unsetItemMoveModel = 0x80; // "UnsetItemMoveModel"
            inline constexpr std::uintptr_t mapDialogModel = 0x88; // "MapDialogModel"
            inline constexpr std::uintptr_t vendorTreeDialogModel = 0x90; // "VendorTreeDialogModel"
            inline constexpr std::uintptr_t inventoryModels = 0x98; // "InventoryModels"
            inline constexpr std::uintptr_t battleEntitiesModel = 0xA0; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t realmVersion = 0xA8; // "RealmVersion"
        }
        namespace Methods {
            inline constexpr std::uintptr_t OnMoveButtonClicked = 0xA17340; // "private void OnMoveButtonClicked()"
            inline constexpr std::uintptr_t OnFindMapClicked = 0xA17120; // "private void OnFindMapClicked()"
            inline constexpr std::uintptr_t Update = 0xA17A00; // "public void Update()"
            inline constexpr std::uintptr_t OnUseButtonClicked = 0xA176C0; // "private void OnUseButtonClicked()"
            inline constexpr std::uintptr_t OnEquipUnequipButtonClicked = 0xA16EA0; // "private void OnEquipUnequipButtonClicked()"
            inline constexpr std::uintptr_t OnSplitButtonClicked = 0xA17570; // "private void OnSplitButtonClicked()"
            inline constexpr std::uintptr_t OnDropButtonClicked = 0xA16D80; // "private void OnDropButtonClicked()"
            inline constexpr std::uintptr_t OnSellButtonClicked = 0xA17410; // "private void OnSellButtonClicked()"
            inline constexpr std::uintptr_t OnBuyButtonClicked = 0xA16BB0; // "private void OnBuyButtonClicked()"
            inline constexpr std::uintptr_t OnUnloadButtonClicked = 0xA17620; // "private void OnUnloadButtonClicked()"
            inline constexpr std::uintptr_t OnReloadButtonClicked = 0xA17380; // "private void OnReloadButtonClicked()"
            inline constexpr std::uintptr_t OnFindInVendorClicked = 0xA17010; // "private void OnFindInVendorClicked()"
            inline constexpr std::uintptr_t OnUseConsumableItemClicked = 0xA17710; // "private void OnUseConsumableItemClicked()"
        }
    } // namespace InventoryTooltipButtonsUpdater

    namespace InventoryTraderAmmoStackCountUpdater { // "Game.Battle.Inventory.Slot.InventoryTraderAmmoStackCountUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleModel = 0x20; // "BattleModel"
            inline constexpr std::uintptr_t settlementBonusModel = 0x28; // "SettlementBonusModel"
            inline constexpr std::uintptr_t coinsModel = 0x30; // "CoinsModel"
            inline constexpr std::uintptr_t traderItemMoveContext = 0x38; // "TraderItemMoveContext"
            inline constexpr std::uintptr_t stackModel = 0x40; // "DummyInventoryStackModel"
            inline constexpr std::uintptr_t playerPublicId = 0x48; // "long"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA7C630; // "public InventoryTraderAmmoStackCountUpdater Init(BattleModel battleModel, TraderItemMoveContext traderItemMoveContext, DummyInventoryStackModel stackModel, long playerPublicId)"
            inline constexpr std::uintptr_t Dispose = 0xA7C5E0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA7C740; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace InventoryTraderAmmoStackCountUpdater

    namespace InventoryUIInputHandler { // "Game.Battle.Inventory.InventoryUIInputHandler (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t updater = 0x10; // "IUpdater"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA187C0; // "public void Update()"
        }
    } // namespace InventoryUIInputHandler

    namespace InventoryUIUpdater { // "Game.Battle.Inventory.InventoryUIUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t updaters = 0x20; // "List<IUpdater>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA01FC0; // "public InventoryUIUpdater Init(GlobalModel globalModel, BattleModel battleModel, int inventoryEntityId, CurrentInventoryModel currentInventoryModel, List<IInventoryItemMoveContext> itemMoveContexts, IInventoryModel inventoryModel, BattleScreenContent battleScreenContent, GlobalScreenContent globalScreenContent, UpdaterPool updaterPool, InventoryUiView inventoryUiView, ItemTooltipView tooltipView, Transform canvasParent, InputActions inputActions, Camera uiCamera, IRegisterDisposable disposable)"
            inline constexpr std::uintptr_t Dispose = 0xA01F60; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0x94CF50; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace InventoryUIUpdater

    namespace InventoryUiView { // "Game.Battle.Inventory.InventoryUiView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t PocketsUiView = 0x20; // "PocketsUiView"
            inline constexpr std::uintptr_t EquipsUiView = 0x28; // "EquipsUiView"
            inline constexpr std::uintptr_t InventoryCellsUiView = 0x30; // "ScrolledCellsUiView"
            inline constexpr std::uintptr_t SlotDropInfoView = 0x38; // "SlotDropInfoView"
        }
    } // namespace InventoryUiView

    namespace InventoryUnloadAmmoMessage { // "Models.Messages.Inventory.UnloadAmmo.InventoryUnloadAmmoMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t slot = 0x20; // "IPrimitiveData<InventorySlotDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Slot = 0x4A2AF90; // "public InventorySlotDescription get_Slot()"
            inline constexpr std::uintptr_t get_Type = 0x4A2AFE0; // "public override string get_Type()"
        }
    } // namespace InventoryUnloadAmmoMessage

    namespace InventoryUseItemModel { // "Models.Models.InventoryUseItem.InventoryUseItemModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t endTs = 0x10; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t itemActionType = 0x18; // "IPrimitiveData<ItemActionTypeDescription>"
            inline constexpr std::uintptr_t sourceInventorySlot = 0x20; // "IPrimitiveData<InventorySlotDescription>"
            inline constexpr std::uintptr_t sourcePocketSlot = 0x28; // "IPrimitiveData<PocketSlotDescription>"
            inline constexpr std::uintptr_t targetInventorySlot = 0x30; // "IPrimitiveData<InventorySlotDescription>"
            inline constexpr std::uintptr_t targetEquipSlot = 0x38; // "IPrimitiveData<EquipSlotDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsStarted = 0x493A070; // "public bool get_IsStarted()"
            inline constexpr std::uintptr_t get_EndTs = 0x493A020; // "public long get_EndTs()"
            inline constexpr std::uintptr_t get_ItemActionType = 0x493A0F0; // "public ItemActionTypeDescription get_ItemActionType()"
            inline constexpr std::uintptr_t get_SourceInventorySlot = 0x493A140; // "public InventorySlotDescription get_SourceInventorySlot()"
            inline constexpr std::uintptr_t get_SourcePocketSlot = 0x493A190; // "public PocketSlotDescription get_SourcePocketSlot()"
            inline constexpr std::uintptr_t get_TargetInventorySlot = 0x493A310; // "public InventorySlotDescription get_TargetInventorySlot()"
            inline constexpr std::uintptr_t get_TargetEquipSlot = 0x493A250; // "public EquipSlotDescription get_TargetEquipSlot()"
            inline constexpr std::uintptr_t Start = 0x4939D80; // "public void Start(ItemActionTypeDescription itemActionType, InventorySlotDescription sourceInventorySlot, PocketSlotDescription sourcePocketSlot, InventorySlotDescription targetInventorySlot, EquipSlotDescription targetEquipSlot, long endUseTs)"
            inline constexpr std::uintptr_t Stop = 0x4939ED0; // "public void Stop()"
        }
    } // namespace InventoryUseItemModel

    namespace InventoryUtils { // "Game.Battle.Inventory.InventoryUtils (Battle.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t GetSlotPositionByPointerPosition = 0xA64C10; // "public static ValueTuple<int, int> GetSlotPositionByPointerPosition(float cellSize, InventoryItemCellsSize itemSize, Vector2 pointerPosition, RectTransform areaTransform, Camera camera)"
            inline constexpr std::uintptr_t TrySplit = 0xA65680; // "public static void TrySplit(ItemSplitModel splitModel, IItemMoveContext from, IItemMoveContext to)"
            inline constexpr std::uintptr_t GetMaxBuyCount = 0xA64BB0; // "public static int GetMaxBuyCount(TraderInventoryDescription traderInventoryDescription, InventoryItemDescription buyItem, DirtyCashModel dirtyCashModel, int count, long playerPublicId, SettlementBonusModel settlementBonusModel)"
            inline constexpr std::uintptr_t IsItemLockedByLocationTier = 0xA65340; // "public static bool IsItemLockedByLocationTier(TraderItemMoveContext traderItemMoveContext, SectorDescription sectorDescription, BattleModeDescription battleMode, RealmVersion realmVersion)"
            inline constexpr std::uintptr_t IsItemLockedByVendorTree = 0xA65410; // "public static bool IsItemLockedByVendorTree(TraderItemMoveContext traderItemMoveContext, UnlockedVendorTreeNodesModel unlockedVendorTreeNodesModel, RealmVersion realmVersion)"
            inline constexpr std::uintptr_t ItemCost = 0xA654E0; // "public static int ItemCost(IInventorySlotModel slotModel)"
            inline constexpr std::uintptr_t GetSumItemsCost = 0xA64FA0; // "public static int GetSumItemsCost(IInventorySlotsModel inventorySlotsModel)"
        }
    } // namespace InventoryUtils

    namespace ItemActionModels { // "Models.Inventory.ItemActionModels.ItemActionModels (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t worldEntitiesModel = 0x10; // "WorldEntitiesModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t TryBuildModel = 0x4A5D460; // "public bool TryBuildModel(BattleCharacterModel model, InventorySlotDescription slot, out IItemActionModel itemActionModel)"
            inline constexpr std::uintptr_t TryBuildModel_2 = 0x4A5D970; // "public bool TryBuildModel(BattleCharacterModel model, EquipSlotDescription slot, out IItemActionModel itemActionModel)"
            inline constexpr std::uintptr_t TryBuildModel_3 = 0x4A5D750; // "public bool TryBuildModel(BattleCharacterModel model, PocketSlotDescription slot, out IItemActionModel itemActionModel)"
            inline constexpr std::uintptr_t TryBuildModel_4 = 0x4A5DB00; // "public bool TryBuildModel(IInventoryModel inventoryModel, InventorySlotDescription slot, bool isTakeOnly, Func<InventoryItemDescription, bool> isItemAllowedFunc, out IItemActionModel itemActionModel)"
        }
    } // namespace ItemActionModels

    namespace ItemActionsController { // "Models.Inventory.ItemActionsController.ItemActionsController (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t unloadAmmoModel = 0x10; // "UnloadAmmoModel"
            inline constexpr std::uintptr_t pickupLootModel = 0x18; // "PickupLootModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t CheckSet = 0x4A5DEB0; // "public bool CheckSet(IItemActionModel model, InventoryItemDescription item, int count, int ammo, int durability, int cumulativePoints, out bool isSet)"
            inline constexpr std::uintptr_t Set = 0x4A604E0; // "public void Set(long now, IItemActionModel model, InventoryItemDescription item, int count, int ammo, int durability, int cumulativePoints, bool isSet)"
            inline constexpr std::uintptr_t TryMove = 0x4A605C0; // "public bool TryMove(long now, IItemActionModel fromModel, IItemActionModel toModel, int count)"
            inline constexpr std::uintptr_t CheckUnset = 0x4A5F360; // "public bool CheckUnset(IItemActionModel model)"
            inline constexpr std::uintptr_t Unset = 0x4A60C30; // "public void Unset(IItemActionModel model)"
            inline constexpr std::uintptr_t TrySwap = 0x4A60740; // "public bool TrySwap(long now, IItemActionModel firstModel, IItemActionModel secondModelDestination, IItemActionModel secondModel, IItemActionModel firstModelDestination)"
            inline constexpr std::uintptr_t CheckSwap = 0x4A5E000; // "public bool CheckSwap(IItemActionModel firstModel, IItemActionModel secondModelDestination, IItemActionModel secondModel, IItemActionModel firstModelDestination, out InventoryItemDescription firstItem, out int firstCount, out int firstAmmo, out int firstDurability, out int firstCumulativePoints, out InventoryItemDescription secondItem, out int secondCount, out int secondAmmo, out int secondDurability, out int secondCumulativePoints)"
            inline constexpr std::uintptr_t CheckMove = 0x4A5DBA0; // "public bool CheckMove(IItemActionModel fromModel, IItemActionModel toModel, int count, out InventoryItemDescription item, out int ammo, out int durability, out int cumulativePoints, out bool isFromUnset, out bool isToSet)"
            inline constexpr std::uintptr_t CheckUnloadAmmo = 0x4A5F050; // "public bool CheckUnloadAmmo(long now, IInventoryModel inventoryModel, IItemActionModel model, out InventoryItemDescription ammoItem, out int ammo, out int refilledSlotsCount, out int[] refilledSlots, out int freeSlotsCount, out int[] freeSlots)"
            inline constexpr std::uintptr_t UnloadAmmo = 0x4A60910; // "public void UnloadAmmo(IInventoryModel inventoryModel, IItemActionModel model, InventoryItemDescription ammoItem, int ammo, int refilledSlotsCount, int[] refilledSlots, int freeSlotsCount, int[] freeSlots)"
            inline constexpr std::uintptr_t CheckPickupItem = 0x4A5DE60; // "public bool CheckPickupItem(InventoryItemDescription item, int count, IInventoryModel inventory, IPocketsModel pockets, IEquipSlotsModel equip, PickupLootResult pickupLootResult)"
            inline constexpr std::uintptr_t GetPickupItemAmount = 0x4A5F3D0; // "public int GetPickupItemAmount(InventoryItemDescription item, int count, IInventoryModel inventory, IPocketsModel pockets, IEquipSlotsModel equip, PickupLootResult pickupLootResult)"
            inline constexpr std::uintptr_t PickupItem = 0x4A5F620; // "public void PickupItem(long now, InventoryItemDescription item, int count, int ammo, int durability, int cumulativePoints, IInventoryModel inventory, IPocketsModel pockets, IEquipSlotsModel equip, IEquipAmmoModel equipAmmo, EquipSlotsDelaysModel equipSlotsDelays, PickupLootResult pickupLootResult)"
        }
    } // namespace ItemActionsController

    namespace ItemActionTypeDescription { // "Models.References.Inventory.ItemActionTypeDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x827C378; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t enum_id = 0x0; // "Enum<ItemActionTypeDescription>"
            inline constexpr std::uintptr_t Use = 0x8; // "ItemActionTypeDescription"
            inline constexpr std::uintptr_t UseAutoRepeat = 0x10; // "ItemActionTypeDescription"
            inline constexpr std::uintptr_t ThrowHold = 0x18; // "ItemActionTypeDescription"
            inline constexpr std::uintptr_t Throw = 0x20; // "ItemActionTypeDescription"
            inline constexpr std::uintptr_t ResetThrow = 0x28; // "ItemActionTypeDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Enum = 0x43E9F40; // "public static ReadOnlyEnum<ItemActionTypeDescription> get_Enum()"
            inline constexpr std::uintptr_t get_IsUseAction = 0x43EA0D0; // "public bool get_IsUseAction()"
            inline constexpr std::uintptr_t get_IsThrowAction = 0x43E9F90; // "public bool get_IsThrowAction()"
        }
    } // namespace ItemActionTypeDescription

    namespace ItemInHandsModel { // "Models.Models.ItemInHands.ItemInHandsModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Current = 0x10; // "IInventoryItemModel"
        }
    } // namespace ItemInHandsModel

    namespace ItemInventoryPaginatorModel { // "Game.Battle.Inventory.Pages.ItemInventoryPaginatorModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t pagesModel = 0x20; // "InventoryPagesModel"
            inline constexpr std::uintptr_t PagesEntitiesIds = 0x28; // "int[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsEmpty = 0xA65C60; // "public override bool get_IsEmpty()"
            inline constexpr std::uintptr_t TryGetCurrentPage = 0xA65B50; // "public bool TryGetCurrentPage(out IInventoryModel inventoryModel, out int entityId)"
            inline constexpr std::uintptr_t GetPageModel = 0xA65B30; // "public IInventoryModel GetPageModel(int pageIndex)"
        }
    } // namespace ItemInventoryPaginatorModel

    namespace ItemInventoryPaginatorModelUpdater { // "Game.Battle.Inventory.Pages.ItemInventoryPaginatorModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t inventoryDataModel = 0x20; // "IDataModel"
            inline constexpr std::uintptr_t model = 0x28; // "ItemInventoryPaginatorModel"
            inline constexpr std::uintptr_t tickIndex = 0x30; // "long"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0x9FBF40; // "public ItemInventoryPaginatorModelUpdater Init(IDataModel inventoryDataModel, ItemInventoryPaginatorModel model)"
            inline constexpr std::uintptr_t Dispose = 0x92B5C0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA65830; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Recalculate = 0xA658C0; // "private void Recalculate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace ItemInventoryPaginatorModelUpdater

    namespace ItemMoveModel { // "Game.Battle.Inventory.ItemMoveModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t NewInput = 0x10; // "IItemAction"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_HasNewInput = 0xA18FC0; // "public bool get_HasNewInput()"
            inline constexpr std::uintptr_t Clear = 0xA18FA0; // "public void Clear()"
        }
    } // namespace ItemMoveModel

    namespace ItemQuickSlotPocketView { // "Game.Battle.Inventory.ItemQuickSlotPocketView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ItemSlotCountView = 0x20; // "InventoryItemCountView"
            inline constexpr std::uintptr_t QuickSlotItemView = 0x28; // "QuickSlotItemView"
            inline constexpr std::uintptr_t CooldownView = 0x30; // "CooldownInventoryItemView"
        }
    } // namespace ItemQuickSlotPocketView

    namespace ItemQuickSlotWeaponView { // "Game.Battle.Inventory.ItemQuickSlotWeaponView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ItemSlotDurabilityView = 0x20; // "InventoryItemDurabilityView"
            inline constexpr std::uintptr_t ItemSlotAmmoMaxView = 0x28; // "InventoryItemAmmoMaxView"
            inline constexpr std::uintptr_t QuickSlotItemView = 0x30; // "QuickSlotItemView"
            inline constexpr std::uintptr_t DelayLockView = 0x38; // "InventoryItemDelayLockView"
        }
    } // namespace ItemQuickSlotWeaponView

    namespace ItemSendMessageUpdater { // "Game.Battle.Inventory.ItemSendMessageUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t globalModel = 0x10; // "GlobalModel"
            inline constexpr std::uintptr_t battleModel = 0x18; // "BattleModel"
            inline constexpr std::uintptr_t battleScreenContent = 0x20; // "BattleScreenContent"
            inline constexpr std::uintptr_t globalScreenContent = 0x28; // "GlobalScreenContent"
            inline constexpr std::uintptr_t model = 0x30; // "ItemMoveModel"
            inline constexpr std::uintptr_t roomConnection = 0x38; // "IRoomConnection"
            inline constexpr std::uintptr_t inputActions = 0x40; // "InputActions"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x48; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t uiSoundModel = 0x50; // "BattleUISoundModel"
            inline constexpr std::uintptr_t vehicleOwnersModel = 0x58; // "VehicleOwnersModel"
            inline constexpr std::uintptr_t now = 0x60; // "INow"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA21420; // "public void Update()"
            inline constexpr std::uintptr_t PlayDropSound = 0xA1F430; // "private void PlayDropSound(IItemMoveContext from)"
            inline constexpr std::uintptr_t UseConsumableItem = 0xA235C0; // "private void UseConsumableItem(IInventoryItemMoveContext from, int inventoryEntityId)"
            inline constexpr std::uintptr_t CarBenchToInventory = 0xA19880; // "private void CarBenchToInventory(CarBenchItemMoveContext from, InventoryItemMoveContext to)"
            inline constexpr std::uintptr_t InventoryToCarBench = 0xA1DBB0; // "private void InventoryToCarBench(InventoryItemMoveContext from, CarBenchItemMoveContext to)"
            inline constexpr std::uintptr_t HelicopterBenchToInventory = 0xA1D110; // "private void HelicopterBenchToInventory(HelicopterBenchItemMoveContext from, InventoryItemMoveContext to)"
            inline constexpr std::uintptr_t InventoryToHelicopterBench = 0xA1E890; // "private void InventoryToHelicopterBench(InventoryItemMoveContext from, HelicopterBenchItemMoveContext to)"
            inline constexpr std::uintptr_t CarBenchToCarBench = 0xA195B0; // "private void CarBenchToCarBench(CarBenchItemMoveContext from, CarBenchItemMoveContext to)"
            inline constexpr std::uintptr_t HelicopterBenchToHelicopterBench = 0xA1CED0; // "private void HelicopterBenchToHelicopterBench(HelicopterBenchItemMoveContext from, HelicopterBenchItemMoveContext to)"
            inline constexpr std::uintptr_t TryShowAttentionForUnsetCarBench = 0xA20DA0; // "private bool TryShowAttentionForUnsetCarBench(CarBenchItemMoveContext from)"
            inline constexpr std::uintptr_t CheckShowAttentionRemoveVehicle = 0xA19FF0; // "private void CheckShowAttentionRemoveVehicle(IPlotVehicleModel plotVehicleModel, IMessage message, IItemMoveContext from, IItemMoveContext to, int benchEntityId)"
            inline constexpr std::uintptr_t CheckShowAttentionReuseVehicle = 0xA1A8E0; // "private void CheckShowAttentionReuseVehicle(IPlotVehicleModel plotVehicleModel, IMessage message, IItemMoveContext from, IItemMoveContext to, int benchEntityId)"
            inline constexpr std::uintptr_t CheckShowAttentionReplaceVehicle = 0xA1A230; // "private void CheckShowAttentionReplaceVehicle(IPlotVehicleModel plotVehicleModel, CarSlotDescription newCar, IMessage message, IItemMoveContext from, IItemMoveContext to, int benchEntityId)"
            inline constexpr std::uintptr_t CheckShowAttentionReuseAndReplaceVehicle = 0xA1A4E0; // "private void CheckShowAttentionReuseAndReplaceVehicle(IPlotVehicleModel fromPlotVehicleModel, IPlotVehicleModel toPlotVehicleModel, CarSlotDescription fromCar, CarSlotDescription toCar, IMessage message, IItemMoveContext from, IItemMoveContext to, int fromEntityId, int toEntityId)"
            inline constexpr std::uintptr_t InventoryToCollection = 0xA1E120; // "private void InventoryToCollection(InventoryItemMoveContext from, CollectionItemMoveContext to)"
            inline constexpr std::uintptr_t EquipToCollection = 0xA1B860; // "private void EquipToCollection(EquipItemMoveContext from, CollectionItemMoveContext to)"
            inline constexpr std::uintptr_t PocketToCollection = 0xA1F4B0; // "private void PocketToCollection(PocketItemMoveContext from, CollectionItemMoveContext to)"
            inline constexpr std::uintptr_t InventoryToLaunderingMoneyWorkbench = 0xA1EEA0; // "private void InventoryToLaunderingMoneyWorkbench(InventoryItemMoveContext from, int entityTo)"
            inline constexpr std::uintptr_t TraderToInventory = 0xA20B80; // "private void TraderToInventory(TraderItemMoveContext from, InventoryItemMoveContext to, int count, int totalPrice)"
            inline constexpr std::uintptr_t TraderToEquip = 0xA20A70; // "private void TraderToEquip(TraderItemMoveContext from, EquipItemMoveContext to, int count, int totalPrice)"
            inline constexpr std::uintptr_t TraderToPocket = 0xA20C90; // "private void TraderToPocket(TraderItemMoveContext from, PocketItemMoveContext to, int count, int totalPrice)"
            inline constexpr std::uintptr_t UnsetInventoryItem = 0xA21350; // "private void UnsetInventoryItem(InventoryItemMoveContext from)"
            inline constexpr std::uintptr_t OnTraderBuyResult = 0xA1F320; // "private void OnTraderBuyResult(IEither<IValue, IValue> result, TraderItemMoveContext from, int totalPrice)"
            inline constexpr std::uintptr_t InventoryToInventory = 0xA1EB40; // "private void InventoryToInventory(InventoryItemMoveContext from, InventoryItemMoveContext to, int count)"
            inline constexpr std::uintptr_t InventoryToEquip = 0xA1E310; // "private void InventoryToEquip(InventoryItemMoveContext from, EquipItemMoveContext to, int count)"
            inline constexpr std::uintptr_t InventoryToPocket = 0xA1EF60; // "private void InventoryToPocket(InventoryItemMoveContext from, PocketItemMoveContext to, int count)"
            inline constexpr std::uintptr_t InventoryToCarUpgrades = 0xA1DED0; // "private void InventoryToCarUpgrades(InventoryItemMoveContext from, CarUpgradeMoveContext to)"
            inline constexpr std::uintptr_t CarUpgradesToInventory = 0xA19D90; // "private void CarUpgradesToInventory(CarUpgradeMoveContext from, InventoryItemMoveContext to)"
            inline constexpr std::uintptr_t EquipToInventory = 0xA1BF20; // "private void EquipToInventory(EquipItemMoveContext from, InventoryItemMoveContext to, int count)"
            inline constexpr std::uintptr_t PocketToInventory = 0xA1F940; // "private void PocketToInventory(PocketItemMoveContext from, InventoryItemMoveContext to, int count)"
            inline constexpr std::uintptr_t EquipToEquip = 0xA1BA50; // "private void EquipToEquip(EquipItemMoveContext from, EquipItemMoveContext to, int count)"
            inline constexpr std::uintptr_t PocketToPocket = 0xA1FC70; // "private void PocketToPocket(PocketItemMoveContext from, PocketItemMoveContext to, int count)"
            inline constexpr std::uintptr_t ExternalToInventory = 0xA1C7E0; // "private void ExternalToInventory(ExternalItemMoveContext from, InventoryItemMoveContext to, int count)"
            inline constexpr std::uintptr_t InventoryToExternal = 0xA1E5A0; // "private void InventoryToExternal(InventoryItemMoveContext from, ExternalItemMoveContext to, int count)"
            inline constexpr std::uintptr_t CopSalaryToInventory = 0xA1AE40; // "private void CopSalaryToInventory(CopSalaryItemMoveContext from, InventoryItemMoveContext to, int count)"
            inline constexpr std::uintptr_t CopSalaryToEquip = 0xA1AB90; // "private void CopSalaryToEquip(CopSalaryItemMoveContext from, EquipItemMoveContext to, int count)"
            inline constexpr std::uintptr_t CopSalaryToPocket = 0xA1B140; // "private void CopSalaryToPocket(CopSalaryItemMoveContext from, PocketItemMoveContext to, int count)"
            inline constexpr std::uintptr_t RouletteInventoryToInventory = 0xA1FEA0; // "private void RouletteInventoryToInventory(ChipsItemMoveContext from, InventoryItemMoveContext to, int count)"
            inline constexpr std::uintptr_t ExternalToExternal = 0xA1C4F0; // "private void ExternalToExternal(ExternalItemMoveContext from, ExternalItemMoveContext to, int count)"
            inline constexpr std::uintptr_t ExternalToEquip = 0xA1C240; // "private void ExternalToEquip(ExternalItemMoveContext from, EquipItemMoveContext to, int count)"
            inline constexpr std::uintptr_t ExternalToPocket = 0xA1CAE0; // "private void ExternalToPocket(ExternalItemMoveContext from, PocketItemMoveContext to, int count)"
            inline constexpr std::uintptr_t PocketToExternal = 0xA1F6A0; // "private void PocketToExternal(PocketItemMoveContext from, ExternalItemMoveContext to, int count)"
            inline constexpr std::uintptr_t EquipToExternal = 0xA1BC80; // "private void EquipToExternal(EquipItemMoveContext from, ExternalItemMoveContext to, int count)"
            inline constexpr std::uintptr_t UnsetBuilder = 0xA21150; // "private void UnsetBuilder(BuilderItemMoveContext from)"
            inline constexpr std::uintptr_t InventoryToBuilder = 0xA1D890; // "private void InventoryToBuilder(InventoryItemMoveContext from, BuilderItemMoveContext to, int count)"
            inline constexpr std::uintptr_t BuilderToInventory = 0xA19290; // "private void BuilderToInventory(BuilderItemMoveContext from, InventoryItemMoveContext to, int count)"
            inline constexpr std::uintptr_t BuilderToBuilder = 0xA18FD0; // "private void BuilderToBuilder(BuilderItemMoveContext from, BuilderItemMoveContext to, int count)"
            inline constexpr std::uintptr_t CarUpgradeToCarUpgrade = 0xA19BC0; // "private void CarUpgradeToCarUpgrade(CarUpgradeMoveContext from, CarUpgradeMoveContext to, int count)"
            inline constexpr std::uintptr_t HasMoveBuilderSlotModalDialog = 0xA1CD80; // "private bool HasMoveBuilderSlotModalDialog(BuilderItemMoveContext builderMoveContext, Action confirmAction)"
            inline constexpr std::uintptr_t SwapBuilderWithInventory = 0xA20950; // "private void SwapBuilderWithInventory(BuilderItemMoveContext builderMoveContext, InventoryItemMoveContext inventoryMoveContext, IInventorySlotModel replacedInventoryItemSlot)"
            inline constexpr std::uintptr_t NeedShowModalOnBuilderSwap = 0xA1F1F0; // "private IAwaiter<IEither<Unit, bool>> NeedShowModalOnBuilderSwap(BuilderItemMoveContext builderMoveContext, InventoryItemMoveContext inventoryMoveContext, IInventorySlotModel replacedInventoryItemSlot)"
            inline constexpr std::uintptr_t SendCheckSpawnLootOnBuilderSwap = 0xA200A0; // "private IAwaiter<IEither<Unit, bool>> SendCheckSpawnLootOnBuilderSwap(BuilderItemMoveContext builderMoveContext, InventoryItemMoveContext inventoryMoveContext, IInventorySlotModel replacedInventoryItemSlot)"
            inline constexpr std::uintptr_t ClientSideCheck = 0xA1AB20; // "private IEither<Unit, bool> ClientSideCheck(bool result)"
            inline constexpr std::uintptr_t TryShowPlotVehicleRequestExceededLimitNotification = 0xA20FE0; // "private bool TryShowPlotVehicleRequestExceededLimitNotification()"
            inline constexpr std::uintptr_t InventoryItemToDefenseBlockModule = 0xA1D3F0; // "private void InventoryItemToDefenseBlockModule(InventoryItemMoveContext from, DefenseBlockModuleItemMoveContext to)"
            inline constexpr std::uintptr_t DefenseBlockModuleToInventoryItem = 0xA1B610; // "private void DefenseBlockModuleToInventoryItem(DefenseBlockModuleItemMoveContext from, InventoryItemMoveContext to)"
            inline constexpr std::uintptr_t DefenseBlockModuleToDefenseBlockModule = 0xA1B3E0; // "private void DefenseBlockModuleToDefenseBlockModule(DefenseBlockModuleItemMoveContext from, DefenseBlockModuleItemMoveContext to)"
            inline constexpr std::uintptr_t InventoryItemToSpecialModule = 0xA1D640; // "private void InventoryItemToSpecialModule(InventoryItemMoveContext from, SpecialModuleItemMoveContext to)"
            inline constexpr std::uintptr_t SpecialModuleToInventoryItem = 0xA204D0; // "private void SpecialModuleToInventoryItem(SpecialModuleItemMoveContext from, InventoryItemMoveContext to)"
            inline constexpr std::uintptr_t SpecialModuleToSpecialModule = 0xA20720; // "private void SpecialModuleToSpecialModule(SpecialModuleItemMoveContext from, SpecialModuleItemMoveContext to)"
            inline constexpr std::uintptr_t SendMessage = 0xA202E0; // "private IAwaiter<IEither<IValue, IValue>> SendMessage(IMessage message, IItemMoveContext slot)"
            inline constexpr std::uintptr_t SendMessage_2 = 0xA201C0; // "private IAwaiter<IEither<IValue, IValue>> SendMessage(IMessage message, IItemMoveContext slot1, IItemMoveContext slot2)"
            inline constexpr std::uintptr_t SendMessage_3 = 0xA203E0; // "private void SendMessage(IMessage message, IReadOnlyList<IItemMoveContext> slots)"
        }
    } // namespace ItemSendMessageUpdater

    namespace ItemSlotAmmoUpdater { // "Game.Battle.Inventory.Slot.ItemSlotAmmoUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t inventoryItemTypeViewDescriptions = 0x20; // "InventoryItemTypeViewDescriptions"
            inline constexpr std::uintptr_t model = 0x28; // "IInventoryItemModel"
            inline constexpr std::uintptr_t ammoModel = 0x30; // "IAmmoModel"
            inline constexpr std::uintptr_t view = 0x38; // "InventoryItemAmmoView"
            inline constexpr std::uintptr_t itemAmmoType = 0x40; // "ItemAmmoType"
            inline constexpr std::uintptr_t isActive = 0x44; // "Nullable<bool>"
            inline constexpr std::uintptr_t ammoCount = 0x48; // "Nullable<int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA7C960; // "public ItemSlotAmmoUpdater Init(GlobalScreenContent globalScreenContent, IInventoryItemModel model, IAmmoModel ammoModel, InventoryItemAmmoView view, ItemAmmoType itemAmmoType)"
            inline constexpr std::uintptr_t Dispose = 0xA7C820; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA7C9F0; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t GetAmmoSymbol = 0xA7C870; // "private string GetAmmoSymbol()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace ItemSlotAmmoUpdater

    namespace ItemSlotCostUpdater { // "Game.Battle.Inventory.ItemSlotCostUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleModel = 0x20; // "BattleModel"
            inline constexpr std::uintptr_t inventoryItemCostView = 0x28; // "PooledLoadedComponentContent<InventoryItemCostView>"
            inline constexpr std::uintptr_t settlementBonusModel = 0x30; // "SettlementBonusModel"
            inline constexpr std::uintptr_t dirtyCashModel = 0x38; // "DirtyCashModel"
            inline constexpr std::uintptr_t itemMoveContext = 0x40; // "IItemMoveContext"
            inline constexpr std::uintptr_t isBuyer = 0x48; // "bool"
            inline constexpr std::uintptr_t playerPublicId = 0x50; // "long"
            inline constexpr std::uintptr_t viewContent = 0x58; // "IDisposableContent<InventoryItemCostView>"
            inline constexpr std::uintptr_t view = 0x60; // "InventoryItemCostView"
            inline constexpr std::uintptr_t coinsModel = 0x68; // "CoinsModel"
            inline constexpr std::uintptr_t buyBlockedSlotsModel = 0x70; // "BlockedSlotsModel"
            inline constexpr std::uintptr_t lockedTraderItemByVendorTree = 0x78; // "BlockedSlotsModel"
            inline constexpr std::uintptr_t isShow = 0x80; // "bool"
            inline constexpr std::uintptr_t cost = 0x84; // "int"
            inline constexpr std::uintptr_t enough = 0x88; // "Nullable<bool>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA65DA0; // "public ItemSlotCostUpdater Init(BattleModel battleModel, InventoryScreenContent inventoryScreenContent, IItemMoveContext itemMoveContext, bool isBuyer, long playerPublicId, RectTransform compositeParent)"
            inline constexpr std::uintptr_t Dispose = 0xA65C80; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA66080; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace ItemSlotCostUpdater

    namespace ItemSplitInputUpdater { // "Game.Battle.Inventory.ItemSplitInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t itemSplitModel = 0x10; // "ItemSplitModel"
            inline constexpr std::uintptr_t sliderModel = 0x18; // "SliderModel"
            inline constexpr std::uintptr_t oldValue = 0x20; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA66620; // "public void Update()"
        }
    } // namespace ItemSplitInputUpdater

    namespace ItemSplitModel { // "Game.Battle.Inventory.ItemSplitModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Intention = 0x10; // "ItemSplitModel.SplitIntention"
            inline constexpr std::uintptr_t Count = 0x14; // "int"
            inline constexpr std::uintptr_t ToContext = 0x18; // "IItemMoveContext"
            inline constexpr std::uintptr_t FromContext = 0x20; // "IItemMoveContext"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetOpen = 0xA666F0; // "public void SetOpen(IItemMoveContext from, IItemMoveContext to)"
            inline constexpr std::uintptr_t SetAuto = 0xA66650; // "public void SetAuto(IItemMoveContext from, IItemMoveContext to)"
            inline constexpr std::uintptr_t SetClose = 0xA666A0; // "public void SetClose()"
        }
    } // namespace ItemSplitModel

    namespace ItemSplitSliderDialogRules { // "Game.Battle.Inventory.ItemSplitSliderDialogRules (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t modalDialogModel = 0x10; // "ModalDialogModel"
            inline constexpr std::uintptr_t inventoryModels = 0x18; // "InventoryModels"
            inline constexpr std::uintptr_t itemSplitModel = 0x20; // "ItemSplitModel"
            inline constexpr std::uintptr_t itemMoveModel = 0x28; // "ItemMoveModel"
            inline constexpr std::uintptr_t battleScreenContent = 0x30; // "BattleScreenContent"
            inline constexpr std::uintptr_t globalScreenContent = 0x38; // "GlobalScreenContent"
            inline constexpr std::uintptr_t inventorySelectedModel = 0x40; // "InventorySelectedModel"
            inline constexpr std::uintptr_t playerEntityModel = 0x48; // "PlayerEntityModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t OpenInputSliderDialog = 0xA667C0; // "public void OpenInputSliderDialog(int minSliderValue, int maxSliderValue, int currentSliderValue, InventoryItemDescription itemDescription, InputActions inputActions)"
            inline constexpr std::uintptr_t OnClosedModalDialog = 0xA66740; // "private void OnClosedModalDialog()"
            inline constexpr std::uintptr_t Split = 0xA66BA0; // "private void Split(SliderInputFieldModel model)"
        }
    } // namespace ItemSplitSliderDialogRules

    namespace ItemSplitUpdater { // "Game.Battle.Inventory.ItemSplitUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t modalDialogModel = 0x20; // "ModalDialogModel"
            inline constexpr std::uintptr_t inputActions = 0x28; // "InputActions"
            inline constexpr std::uintptr_t itemSplitModel = 0x30; // "ItemSplitModel"
            inline constexpr std::uintptr_t itemMoveModel = 0x38; // "ItemMoveModel"
            inline constexpr std::uintptr_t inventorySelectedModel = 0x40; // "InventorySelectedModel"
            inline constexpr std::uintptr_t itemSplitSliderDialogRules = 0x48; // "ItemSplitSliderDialogRules"
            inline constexpr std::uintptr_t intention = 0x50; // "ItemSplitModel.SplitIntention"
            inline constexpr std::uintptr_t currentItemDescription = 0x58; // "InventoryItemDescription"
            inline constexpr std::uintptr_t itemCount = 0x60; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA67110; // "public ItemSplitUpdater Init(ModalDialogModel modalDialogModel, InventoryModels inventoryModels, PlayerEntityModel playerEntityModel, BattleScreenContent battleScreenContent, GlobalScreenContent globalScreenContent, InputActions inputActions)"
            inline constexpr std::uintptr_t Dispose = 0xA66EC0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA672A0; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t GetMaxModelCount = 0xA66F50; // "private int GetMaxModelCount()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace ItemSplitUpdater

    namespace ItemTooltipButtonsUpdater { // "Game.Battle.Inventory.ItemTooltipButtonsUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t updaters = 0x20; // "List<IUpdater>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA677B0; // "public ItemTooltipButtonsUpdater Init(BattleModeDescription battleModeDescription, CurrentInventoryModel currentInventoryModel, BattleModel battleModel, ItemTooltipView tooltipView, InventoryItemViewDescriptions inventoryItemViewDescriptions, UpdaterPool updaterPool, IRegisterDisposable disposable)"
            inline constexpr std::uintptr_t Dispose = 0xA67750; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0x94CF50; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace ItemTooltipButtonsUpdater

    namespace ItemUseAction { // "Game.Battle.Inventory.ItemUseAction (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t From = 0x10; // "IItemMoveContext"
        }
    } // namespace ItemUseAction

    namespace KeyboardCargoInputUpdater { // "Game.Battle.Trunk.Cargo.KeyboardCargoInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t updaters = 0x20; // "List<IUpdater>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xD877E0; // "public KeyboardCargoInputUpdater Init(CargoInventoryModel cargoInventoryModel, CargoInventoryTabView cargoInventoryView, GlobalUISoundModel uiSoundModel, InventoryDialogModel inventoryDialogModel, BecomeRobberNotificationModel becomeRobberNotificationModel, UnavailableTargetActionsKeys unavailableKeys, PersonalNotificationModel personalNotificationModel, BattleModel battleModel, UpdaterPool updaterPool, IRegisterDisposable disposable)"
            inline constexpr std::uintptr_t Dispose = 0xD87780; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0x94CF50; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace KeyboardCargoInputUpdater

    namespace KeyboardCargoSlotInputUpdater { // "Game.Battle.Trunk.Cargo.KeyboardCargoSlotInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t slotView = 0x20; // "CargoInventorySlotView"
            inline constexpr std::uintptr_t slotModel = 0x28; // "CargoInventorySlotModel"
            inline constexpr std::uintptr_t uiSoundModel = 0x30; // "GlobalUISoundModel"
            inline constexpr std::uintptr_t inventoryDialogModel = 0x38; // "InventoryDialogModel"
            inline constexpr std::uintptr_t becomeRobberNotificationModel = 0x40; // "BecomeRobberNotificationModel"
            inline constexpr std::uintptr_t unavailableKeys = 0x48; // "UnavailableTargetActionsKeys"
            inline constexpr std::uintptr_t personalNotificationModel = 0x50; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t battleModel = 0x58; // "BattleModel"
            inline constexpr std::uintptr_t cargo = 0x60; // "CargoDescription"
            inline constexpr std::uintptr_t isSelectedForTooltip = 0x68; // "bool"
            inline constexpr std::uintptr_t tooltipModel = 0x70; // "TooltipModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xD87BA0; // "public KeyboardCargoSlotInputUpdater Init(CargoInventorySlotView slotView, CargoInventorySlotModel slotModel, GlobalUISoundModel uiSoundModel, InventoryDialogModel inventoryDialogModel, BecomeRobberNotificationModel becomeRobberNotificationModel, UnavailableTargetActionsKeys unavailableKeys, PersonalNotificationModel personalNotificationModel, BattleModel battleModel)"
            inline constexpr std::uintptr_t Dispose = 0xD87AF0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xD87C90; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t UpdateCargoTakeButton = 0xD87E70; // "private void UpdateCargoTakeButton()"
            inline constexpr std::uintptr_t TakeCargo = 0xD87D00; // "private void TakeCargo()"
            inline constexpr std::uintptr_t UpdateCargoTooltipOpen = 0xD88290; // "private void UpdateCargoTooltipOpen()"
            inline constexpr std::uintptr_t UpdateCargoTooltipClose = 0xD88230; // "private void UpdateCargoTooltipClose()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace KeyboardCargoSlotInputUpdater

    namespace KeyboardClickableItemsUpdater { // "Game.Battle.Inventory.KeyboardClickableItemsUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t fastMoveOnClick = 0x20; // "FastMoveOnClick"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x28; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t battleActions = 0x30; // "InputActions.BattleActions"
            inline constexpr std::uintptr_t personalNotificationModel = 0x38; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t notificationError = 0x40; // "NotificationError"
            inline constexpr std::uintptr_t tooltipModel = 0x48; // "TooltipModel"
            inline constexpr std::uintptr_t inventoryModels = 0x50; // "InventoryModels"
            inline constexpr std::uintptr_t currentInventoryModel = 0x58; // "CurrentInventoryModel"
            inline constexpr std::uintptr_t lastClickTime = 0x60; // "float"
            inline constexpr std::uintptr_t transferHoldContext = 0x68; // "IItemMoveContext"
            inline constexpr std::uintptr_t lastTransferItemCount = 0x70; // "int"
            inline constexpr std::uintptr_t contextQueue = 0x78; // "Queue<IItemMoveContext>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA23930; // "public KeyboardClickableItemsUpdater Init(InventoryModels inventoryModels, CurrentInventoryModel currentInventoryModel, BattleModel battleModel, InputActions.BattleActions battleActions, PersonalNotificationModel personalNotificationModel, NotificationError notificationError, BattleScreenContent content)"
            inline constexpr std::uintptr_t Dispose = 0xA23860; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA23FD0; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t TryFastMove = 0xA251E0; // "private void TryFastMove(PlayerEntityModel player)"
            inline constexpr std::uintptr_t TryCloseTooltip = 0xA25140; // "private void TryCloseTooltip(IItemMoveContext context)"
            inline constexpr std::uintptr_t IsDoubleClick = 0xA23BC0; // "private bool IsDoubleClick(PointerButtonView view)"
            inline constexpr std::uintptr_t IsFastMoveInventoryClick = 0xA23BF0; // "private bool IsFastMoveInventoryClick(PointerButtonView view)"
            inline constexpr std::uintptr_t IsTransferHoldHover = 0xA23C30; // "private bool IsTransferHoldHover(IItemMoveContext context, PointerButtonView view)"
            inline constexpr std::uintptr_t AddFastMoveQueue = 0xA237D0; // "private void AddFastMoveQueue(IItemMoveContext context)"
            inline constexpr std::uintptr_t IsDeleteHoldClick = 0xA23A80; // "private bool IsDeleteHoldClick(IItemMoveContext context, PointerButtonView view)"
            inline constexpr std::uintptr_t TryUnsetOnClick = 0xA25410; // "private void TryUnsetOnClick(PlayerEntityModel player, IItemMoveContext context)"
            inline constexpr std::uintptr_t ShowNotification = 0xA250E0; // "private void ShowNotification(NotificationError.Type errorType)"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace KeyboardClickableItemsUpdater

    namespace KeyboardHoverableSlotsUpdater { // "Game.Battle.Inventory.KeyboardHoverableSlotsUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleEntitiesModel = 0x20; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t tooltipModel = 0x28; // "TooltipMiniModel"
            inline constexpr std::uintptr_t inventoryModels = 0x30; // "InventoryModels"
            inline constexpr std::uintptr_t hoveredContext = 0x38; // "IItemMoveContext"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA25660; // "public KeyboardHoverableSlotsUpdater Init(InventoryModels inventoryModels, BattleModel battleModel, TooltipMiniModel tooltipModel)"
            inline constexpr std::uintptr_t Dispose = 0xA255E0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA256E0; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t ClearHoveredTooltip = 0xA25580; // "private void ClearHoveredTooltip()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace KeyboardHoverableSlotsUpdater

    namespace KeyboardMouseInventoryDialogFooterView { // "Game.Battle.Inventory.KeyboardMouseInventoryDialogFooterView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Button = 0x30; // "HoldPointerButtonView"
            inline constexpr std::uintptr_t InputTextView = 0x38; // "InputTextView"
        }
    } // namespace KeyboardMouseInventoryDialogFooterView

    namespace KeyboardMouseInventoryDialogView { // "Game.Battle.Inventory.KeyboardMouseInventoryDialogView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Footer = 0x40; // "KeyboardMouseInventoryDialogFooterView"
            inline constexpr std::uintptr_t FastMoveHint = 0x48; // "InputTextView"
        }
    } // namespace KeyboardMouseInventoryDialogView

    namespace KeyboardMouseTakeAllButtonDisableUpdater { // "Game.Battle.Inventory.KeyboardMouseTakeAllButtonDisableUpdater (Battle.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x8182960; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace Fields {
            inline constexpr std::uintptr_t busySlotsModel = 0x20; // "BusySlotsModel"
            inline constexpr std::uintptr_t takeAllButton = 0x28; // "HoldPointerButtonView"
            inline constexpr std::uintptr_t revealContainerModel = 0x30; // "IRevealContainerModel"
            inline constexpr std::uintptr_t takeAllCompositeButton = 0x38; // "CompositeButtonView"
            inline constexpr std::uintptr_t isCorrectTab = 0x40; // "Func<bool>"
            inline constexpr std::uintptr_t isEnabled = 0x48; // "bool"
        }
        namespace StaticFields {
            inline constexpr std::uintptr_t emptyFunc = 0x0; // "Func<bool>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA68790; // "public KeyboardMouseTakeAllButtonDisableUpdater Init(BusySlotsModel busySlotsModel, HoldPointerButtonView takeAllButton, IRevealContainerModel revealContainerModel, CompositeButtonView takeAllCompositeButton, Func<bool> isCorrectTab)"
            inline constexpr std::uintptr_t Dispose = 0xA123B0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA688D0; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t SetEnabled = 0xA68960; // "private void SetEnabled(bool isEnabled)"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace KeyboardMouseTakeAllButtonDisableUpdater

    namespace LastQuickSlotModel { // "Models.Models.LastQuickSlot.LastQuickSlotModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t slot = 0x10; // "IPrimitiveData<QuickSlotDescription>"
            inline constexpr std::uintptr_t isEmptyHands = 0x18; // "IPrimitiveData<bool>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsSet = 0x493DF30; // "public bool get_IsSet()"
            inline constexpr std::uintptr_t get_IsEmptyHands = 0x493DEE0; // "public bool get_IsEmptyHands()"
            inline constexpr std::uintptr_t get_Slot = 0x493E020; // "public QuickSlotDescription get_Slot()"
            inline constexpr std::uintptr_t Set = 0x493DE00; // "public void Set(QuickSlotDescription slot, bool isEmptyHands)"
            inline constexpr std::uintptr_t Unset = 0x493DE80; // "public void Unset()"
        }
    } // namespace LastQuickSlotModel

    namespace LastSelectedQuickSlotUpdater { // "Game.Battle.Inputs.LastSelectedQuickSlotUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t selected = 0x10; // "SelectedQuickSlotModel"
            inline constexpr std::uintptr_t quickSlotsInput = 0x18; // "QuickSlotsInputModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA7EB50; // "public void Update()"
        }
    } // namespace LastSelectedQuickSlotUpdater

    namespace LaunderingItemAction { // "Game.Battle.Inventory.LaunderingItemAction (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t From = 0x10; // "IItemMoveContext"
            inline constexpr std::uintptr_t ToEntityId = 0x18; // "int"
        }
    } // namespace LaunderingItemAction

    namespace LockedTraderCardClickUpdater { // "Game.Battle.Laptop.ShopBuy.LockedTraderCardClickUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t globalModel = 0x10; // "GlobalModel"
            inline constexpr std::uintptr_t battleModel = 0x18; // "BattleModel"
            inline constexpr std::uintptr_t inventoryModels = 0x20; // "InventoryModels"
            inline constexpr std::uintptr_t vendorTreeDialogModel = 0x28; // "VendorTreeDialogModel"
            inline constexpr std::uintptr_t modalDialogModel = 0x30; // "ModalDialogModel"
            inline constexpr std::uintptr_t tooltipModel = 0x38; // "TooltipModel"
            inline constexpr std::uintptr_t roomConnection = 0x40; // "IRoomConnection"
            inline constexpr std::uintptr_t inputActions = 0x48; // "InputActions"
            inline constexpr std::uintptr_t dirtyCashModel = 0x50; // "DirtyCashModel"
            inline constexpr std::uintptr_t settlementModel = 0x58; // "RegionUserSettlementModel"
            inline constexpr std::uintptr_t battleMode = 0x60; // "BattleModeDescription"
            inline constexpr std::uintptr_t now = 0x68; // "INow"
            inline constexpr std::uintptr_t itemViewDescriptions = 0x70; // "InventoryItemViewDescriptions"
            inline constexpr std::uintptr_t globalLocalizationKeys = 0x78; // "GlobalLocalizationKeys"
            inline constexpr std::uintptr_t localizationKeys = 0x80; // "LocalizationKeys"
            inline constexpr std::uintptr_t lockOnLocationHint = 0x88; // "Text<int>"
            inline constexpr std::uintptr_t unlockDescription = 0x90; // "Text<Money>"
            inline constexpr std::uintptr_t unlockButton = 0x98; // "Text<Money>"
            inline constexpr std::uintptr_t unlockIcon = 0xA0; // "LaptopViewDescriptions.UnlockCardIconDescription"
            inline constexpr std::uintptr_t realmVersion = 0xA8; // "RealmVersion"
            inline constexpr std::uintptr_t isDisposed = 0xAC; // "bool"
            inline constexpr std::uintptr_t isUnlockInProgress = 0xAD; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x9ECB30; // "public void Update()"
            inline constexpr std::uintptr_t CloseTooltip = 0x9EBFB0; // "private void CloseTooltip()"
            inline constexpr std::uintptr_t OnLockedCardClick = 0x9EBFE0; // "private void OnLockedCardClick(TraderItemMoveContext context, TraderCardState state)"
            inline constexpr std::uintptr_t OpenUnlockDialog = 0x9EC410; // "private void OpenUnlockDialog(VendorTreeNodeDescription node, InventoryItemDescription item)"
            inline constexpr std::uintptr_t OnUnlockConfirmed = 0x9EC310; // "private void OnUnlockConfirmed(VendorTreeNodeDescription node)"
            inline constexpr std::uintptr_t CanConfirmUnlock = 0x9EBE70; // "private bool CanConfirmUnlock(VendorTreeNodeDescription node)"
            inline constexpr std::uintptr_t Unlock = 0x9ECA60; // "private void Unlock(VendorTreeNodeDescription node)"
        }
    } // namespace LockedTraderCardClickUpdater

    namespace LootClientModel { // "Game.Battle.EntityModel.Loot.LootClientModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t DataState = 0x10; // "EntityDataStateModel"
            inline constexpr std::uintptr_t MovementTimeline = 0x18; // "MovementTimeline"
            inline constexpr std::uintptr_t Position = 0x20; // "SetMovementModel"
            inline constexpr std::uintptr_t SleepState = 0x28; // "SleepStateSimpleDotPhysicsModel"
        }
    } // namespace LootClientModel

    namespace LootConfig { // "Models.References.Container.LootConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t InteractDescription = 0x10; // "InteractDescription"
            inline constexpr std::uintptr_t CharacterLootRemoveDelay = 0x18; // "long"
            inline constexpr std::uintptr_t MaxCount = 0x20; // "int"
            inline constexpr std::uintptr_t Height = 0x24; // "float"
            inline constexpr std::uintptr_t Gravity = 0x28; // "float"
            inline constexpr std::uintptr_t AirResistance = 0x2C; // "float"
        }
    } // namespace LootConfig

    namespace LootContainerTargetActions { // "Game.Battle.Target.LootContainerTargetActions (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t inventoryEntityId = 0x10; // "int"
            inline constexpr std::uintptr_t personalNotificationModel = 0x18; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t uiSoundModel = 0x20; // "GlobalUISoundModel"
            inline constexpr std::uintptr_t battleInputModel = 0x28; // "BattleInputModel"
            inline constexpr std::uintptr_t observerRequestModel = 0x30; // "ObserverRequestModel"
            inline constexpr std::uintptr_t OpenInventoryAction = 0x38; // "TargetActionWithNotificationItem"
            inline constexpr std::uintptr_t TakeCargoAction = 0x40; // "TargetActionWithNotificationItem"
            inline constexpr std::uintptr_t MultiAction = 0x48; // "MultiTargetAction"
        }
        namespace Methods {
            inline constexpr std::uintptr_t OpenInventoryDialog = 0x9D4EC0; // "private void OpenInventoryDialog()"
            inline constexpr std::uintptr_t TakeCargo = 0x9D4F10; // "private void TakeCargo()"
            inline constexpr std::uintptr_t UnavailableAction = 0x9D4FE0; // "private void UnavailableAction(LocalizedString localizedString, PersonalNotificationActionIds id)"
        }
    } // namespace LootContainerTargetActions

    namespace LootContainerTargetProvider { // "Game.Battle.Target.LootContainerTargetProvider (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t targetActions = 0x20; // "LootContainerTargetActions"
            inline constexpr std::uintptr_t hasCargo = 0x28; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t unavailableKeys = 0x30; // "UnavailableTargetActionsKeys"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x38; // "IBattleEntitiesModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t FillTargetActions = 0x9D54A0; // "protected internal override void FillTargetActions(List<ITargetAction> actions)"
        }
    } // namespace LootContainerTargetProvider

    namespace LootData { // "Models.Data.LootData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t SpawnTickIndex = 0x20; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t X = 0x28; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t Y = 0x30; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t Z = 0x38; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t BagDescription = 0x40; // "IPrimitiveData<CharacterBagDescription>"
            inline constexpr std::uintptr_t Role = 0x48; // "IPrimitiveData<PlayerRoleDescription>"
        }
    } // namespace LootData

    namespace LootEntityInventoryData { // "Models.Data.LootEntityInventoryData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Name = 0x20; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t ClanTag = 0x28; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t PublicId = 0x30; // "PublicIdData"
            inline constexpr std::uintptr_t Inventory = 0x38; // "InventoryData"
            inline constexpr std::uintptr_t InventoryRevealId = 0x40; // "InventoryRevealIdData"
            inline constexpr std::uintptr_t DynamicLineCount = 0x48; // "IPrimitiveData<int>"
        }
    } // namespace LootEntityInventoryData

    namespace LootEntityInventoryModel { // "Models.Models.LootEntityInventory.LootEntityInventoryModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Id = 0x10; // "int"
            inline constexpr std::uintptr_t Name = 0x18; // "IPrimitiveModel<string>"
            inline constexpr std::uintptr_t ClanTag = 0x20; // "IPrimitiveModel<string>"
            inline constexpr std::uintptr_t PublicId = 0x28; // "IPrimitiveModel<long>"
            inline constexpr std::uintptr_t Inventory = 0x30; // "IInventoryModel"
            inline constexpr std::uintptr_t InventoryRevealIdModel = 0x38; // "InventoryRevealIdModel"
        }
    } // namespace LootEntityInventoryModel

    namespace LootEntityModel { // "Game.Battle.EntityModel.Loot.LootEntityModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ServerModel = 0x18; // "ILootModel"
            inline constexpr std::uintptr_t ClientModel = 0x20; // "LootClientModel"
        }
    } // namespace LootEntityModel

    namespace LootEntityModelUpdater { // "Game.Battle.EntityModel.Loot.LootEntityModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t client = 0x10; // "LootClientModel"
            inline constexpr std::uintptr_t noDataUpdater = 0x18; // "IUpdater"
            inline constexpr std::uintptr_t updater = 0x20; // "IUpdater"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC934E0; // "public void Update()"
        }
    } // namespace LootEntityModelUpdater

    namespace LootInfoClientNotificationData { // "Models.ClientNotification.ClientNotificationData.LootInfoClientNotificationData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t items = 0x20; // "ListData<LootInfoItemData>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Value = 0x4ADEDF0; // "public ClientNotification.LootInfo get_Value()"
            inline constexpr std::uintptr_t set_Value = 0x4ADEF50; // "public void set_Value(ClientNotification.LootInfo value)"
        }
    } // namespace LootInfoClientNotificationData

    namespace LootInfoItemData { // "Models.ClientNotification.ClientNotificationData.LootInfoItemData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t item = 0x20; // "IPrimitiveData<InventoryItemDescription>"
            inline constexpr std::uintptr_t amount = 0x28; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t isLost = 0x30; // "IPrimitiveData<bool>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Item = 0x4ADF5E0; // "public InventoryItemDescription get_Item()"
            inline constexpr std::uintptr_t get_Amount = 0x4ADF540; // "public int get_Amount()"
            inline constexpr std::uintptr_t get_IsLost = 0x4ADF590; // "public bool get_IsLost()"
            inline constexpr std::uintptr_t Set = 0x4ADF250; // "public void Set(InventoryItemDescription item, int amount, bool isLost)"
        }
    } // namespace LootInfoItemData

    namespace LootInventoryEntityModel { // "Game.Battle.EntityModel.Loot.LootInventoryEntityModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ServerModel = 0x18; // "LootEntityInventoryModel"
        }
    } // namespace LootInventoryEntityModel

    namespace LootInventoryItem { // "Models.Models.InventoryLootBuffer.LootInventoryItem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Item = 0x10; // "InventoryItemDescription"
            inline constexpr std::uintptr_t StackAmount = 0x18; // "int"
            inline constexpr std::uintptr_t AmmoOrArmor = 0x1C; // "int"
            inline constexpr std::uintptr_t Durability = 0x20; // "int"
            inline constexpr std::uintptr_t CumulativePoints = 0x24; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t ChangeStackAmount = 0x394DF90; // "public void ChangeStackAmount(int amount)"
            inline constexpr std::uintptr_t Swap = 0x49423D0; // "public void Swap(LootInventoryItem inventoryItem)"
        }
    } // namespace LootInventoryItem

    namespace LootModel { // "Models.Models.LootModel.LootModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Id = 0x10; // "int"
            inline constexpr std::uintptr_t SpawnTickIndex = 0x18; // "IPrimitiveModel<int>"
            inline constexpr std::uintptr_t Transform = 0x20; // "ITransformModel"
            inline constexpr std::uintptr_t InteractPositionModel = 0x28; // "IPositionModel"
            inline constexpr std::uintptr_t BagDescription = 0x30; // "IPrimitiveModel<CharacterBagDescription>"
            inline constexpr std::uintptr_t Role = 0x38; // "IPrimitiveModel<PlayerRoleDescription>"
            inline constexpr std::uintptr_t LootChanged = 0x40; // "bool"
            inline constexpr std::uintptr_t PhysicsSource = 0x48; // "ISimpleDotPhysicsSourceModel"
            inline constexpr std::uintptr_t PhysicsState = 0x50; // "ISimpleDotPhysicsStateModel"
            inline constexpr std::uintptr_t PhysicsAwakeObserver = 0x58; // "PhysicsAwakeObserverModel"
        }
    } // namespace LootModel

    namespace LootNodeAfterUnlockUpdater { // "Game.Battle.Entities.Building.LootNodeAfterUnlockUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleEntitiesModel = 0x20; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t battleInputModel = 0x28; // "BattleInputModel"
            inline constexpr std::uintptr_t lootNodeModel = 0x30; // "LootNodeModel"
            inline constexpr std::uintptr_t soundEmitter = 0x38; // "SoundEmitter"
            inline constexpr std::uintptr_t afterUnlockEventTransform = 0x40; // "Transform"
            inline constexpr std::uintptr_t openAfterUnlockEvent = 0x48; // "Event"
            inline constexpr std::uintptr_t isInProcess = 0x50; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xBB5310; // "public LootNodeAfterUnlockUpdater Init(IBattleEntitiesModel battleEntitiesModel, BattleInputModel battleInputModel, LootNodeModel lootNodeModel, SoundEmitter soundEmitter, Event openAfterUnlockEvent, Transform afterUnlockEventTransform)"
            inline constexpr std::uintptr_t Dispose = 0xA0E680; // "protected override void Dispose()"
            inline constexpr std::uintptr_t Stop = 0x7B3360; // "public void Stop()"
            inline constexpr std::uintptr_t OnUpdate = 0xBB53B0; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IStoppedUpdater_Update = 0x9165B0; // "private void Core.Updater.IStoppedUpdater.Update()"
        }
    } // namespace LootNodeAfterUnlockUpdater

    namespace LootNodeConfig { // "Models.References.LootNode.LootNodeConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t MaxSteps = 0x10; // "int"
            inline constexpr std::uintptr_t TakeTime = 0x18; // "long"
            inline constexpr std::uintptr_t UnlockTime = 0x20; // "long"
        }
    } // namespace LootNodeConfig

    namespace LootNodeData { // "Models.Data.LootNodeData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Steps = 0x20; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t UnlockState = 0x28; // "IPrimitiveData<UnlockStateDescription>"
            inline constexpr std::uintptr_t IsEmpty = 0x30; // "IPrimitiveData<bool>"
        }
    } // namespace LootNodeData

    namespace LootNodeDescription { // "Models.References.LootNode.LootNodeDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsLocked = 0x20; // "bool"
            inline constexpr std::uintptr_t CompletelyLootedCumulativePoints = 0x24; // "int"
        }
    } // namespace LootNodeDescription

    namespace LootNodeEntityModel { // "Game.Battle.Entities.Building.LootNodeEntityModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ServerModel = 0x18; // "LootNodeModel"
        }
    } // namespace LootNodeEntityModel

    namespace LootNodeLootDescription { // "Models.References.LootNode.LootNodeLootDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t StepsAmountFrom = 0x20; // "int"
            inline constexpr std::uintptr_t StepsAmountTo = 0x24; // "int"
            inline constexpr std::uintptr_t StepItemAmountFrom = 0x28; // "int"
            inline constexpr std::uintptr_t StepItemAmountTo = 0x2C; // "int"
            inline constexpr std::uintptr_t ItemFunc = 0x30; // "Func<InventoryItemDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Item = 0x9AA5D0; // "public InventoryItemDescription get_Item()"
        }
    } // namespace LootNodeLootDescription

    namespace LootNodeModel { // "Models.Models.LootNode.LootNodeModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Description = 0x10; // "LocationLootNodeDescription"
            inline constexpr std::uintptr_t StepsModel = 0x18; // "LootNodeStepsModel"
            inline constexpr std::uintptr_t UnlockState = 0x20; // "IPrimitiveModel<UnlockStateDescription>"
            inline constexpr std::uintptr_t ResetModel = 0x28; // "LootNodeResetModel"
            inline constexpr std::uintptr_t IsEmptyModel = 0x30; // "IPrimitiveModel<bool>"
        }
    } // namespace LootNodeModel

    namespace LootNodeResetModel { // "Models.Models.LootNodeReset.LootNodeResetModel (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x81C2DC0; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace Fields {
            inline constexpr std::uintptr_t steps = 0x10; // "LootNodeStepsModel"
            inline constexpr std::uintptr_t unlockState = 0x18; // "IPrimitiveModel<UnlockStateDescription>"
            inline constexpr std::uintptr_t isEmpty = 0x20; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t lootNodeDescription = 0x28; // "LocationLootNodeDescription"
        }
        namespace StaticFields {
            inline constexpr std::uintptr_t lockedState = 0x0; // "UnlockStateDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Reset = 0x4942B30; // "public void Reset(Random random)"
            inline constexpr std::uintptr_t GetEmptyState = 0x4942AD0; // "private bool GetEmptyState(Random random)"
        }
    } // namespace LootNodeResetModel

    namespace LootNodesModel { // "Models.Models.LootNodes.LootNodesModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t models = 0x10; // "Dictionary<LocationLootNodeDescription, LootNodeModel>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Item = 0x4943470; // "public LootNodeModel get_Item(LocationLootNodeDescription description)"
            inline constexpr std::uintptr_t Reset = 0x4943100; // "public void Reset(Random random)"
        }
    } // namespace LootNodesModel

    namespace LootNodesTargetActions { // "Game.Battle.Entities.Building.LootNodesTargetActions (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t notificationError = 0x10; // "NotificationError"
            inline constexpr std::uintptr_t personalNotificationModel = 0x18; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x20; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t battleInputModel = 0x28; // "BattleInputModel"
            inline constexpr std::uintptr_t locationLootNodeDescription = 0x30; // "LocationLootNodeDescription"
            inline constexpr std::uintptr_t uiSoundModel = 0x38; // "GlobalUISoundModel"
            inline constexpr std::uintptr_t lootNodeEntityId = 0x40; // "int"
            inline constexpr std::uintptr_t lootNodeDescription = 0x48; // "LootNodeDescription"
            inline constexpr std::uintptr_t lootNodeLootDescription = 0x50; // "LootNodeLootDescription"
            inline constexpr std::uintptr_t becomeRobberNotificationModel = 0x58; // "BecomeRobberNotificationModel"
            inline constexpr std::uintptr_t useHints = 0x60; // "UseHintViewDescription"
            inline constexpr std::uintptr_t isRequesting = 0x68; // "bool"
            inline constexpr std::uintptr_t isAlarmEnabled = 0x69; // "bool"
            inline constexpr std::uintptr_t Variants = 0x70; // "List<ITargetActionItem>"
            inline constexpr std::uintptr_t Action = 0x78; // "MultiTargetAction"
            inline constexpr std::uintptr_t LootingAction = 0x80; // "TargetActionWithNotificationItem"
            inline constexpr std::uintptr_t UnlockAction = 0x88; // "TargetActionWithNotificationItem"
            inline constexpr std::uintptr_t UnlockWithLockpickAction = 0x90; // "TargetActionWithNotificationItem"
            inline constexpr std::uintptr_t UnlockWithoutLockpickAction = 0x98; // "TargetActionWithNotificationItem"
        }
        namespace Methods {
            inline constexpr std::uintptr_t AlarmEnabled = 0xBB6C80; // "public bool AlarmEnabled()"
            inline constexpr std::uintptr_t UnlockWithLockpick = 0xBB7210; // "private void UnlockWithLockpick()"
            inline constexpr std::uintptr_t Unlock = 0xBB72D0; // "private void Unlock()"
            inline constexpr std::uintptr_t BeginNodeLooting = 0xBB6CC0; // "private void BeginNodeLooting()"
            inline constexpr std::uintptr_t UnavailableUnlock = 0xBB7070; // "private void UnavailableUnlock(LocalizedString notification, PersonalNotificationActionIds id)"
            inline constexpr std::uintptr_t UnavailableLooting = 0xBB6F50; // "private void UnavailableLooting(LocalizedString notification, PersonalNotificationActionIds id)"
            inline constexpr std::uintptr_t Unavailable = 0xBB7190; // "private void Unavailable(LocalizedString invalidNotification, PersonalNotificationActionIds id)"
            inline constexpr std::uintptr_t UpdateAlarmEnabled = 0xBB7440; // "public void UpdateAlarmEnabled()"
            inline constexpr std::uintptr_t SetAlarmPictogram = 0xBB6ED0; // "private void SetAlarmPictogram(bool isAlarmEnabled)"
        }
    } // namespace LootNodesTargetActions

    namespace LootNodeStateUpdater { // "Game.Battle.Entities.Building.LootNodeStateUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t view = 0x20; // "LootNodeView"
            inline constexpr std::uintptr_t lootNode = 0x28; // "LootNodeModel"
            inline constexpr std::uintptr_t small = 0x30; // "int"
            inline constexpr std::uintptr_t half = 0x34; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xBB5840; // "public LootNodeStateUpdater Init(LootNodeView view, LootNodeModel lootNode)"
            inline constexpr std::uintptr_t Dispose = 0x92B5C0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xBB58C0; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Stop = 0x7B3360; // "public void Stop()"
            inline constexpr std::uintptr_t GetState = 0xBB57A0; // "private LootNodeState GetState()"
            inline constexpr std::uintptr_t Core_Updater_IStoppedUpdater_Update = 0x9165B0; // "private void Core.Updater.IStoppedUpdater.Update()"
        }
    } // namespace LootNodeStateUpdater

    namespace LootNodeStepsModel { // "Models.Models.LootNodeSteps.LootNodeStepsModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t stepsData = 0x10; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t description = 0x18; // "LocationLootNodeDescription"
            inline constexpr std::uintptr_t totalSteps = 0x20; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Steps = 0x49430B0; // "public int get_Steps()"
            inline constexpr std::uintptr_t get_TotalSteps = 0x7E8CD0; // "public int get_TotalSteps()"
            inline constexpr std::uintptr_t get_IsEmpty = 0x4943060; // "public bool get_IsEmpty()"
            inline constexpr std::uintptr_t Take = 0x4942FF0; // "public void Take()"
            inline constexpr std::uintptr_t Reset = 0x4942F20; // "public void Reset(Random random)"
        }
    } // namespace LootNodeStepsModel

    namespace LootNodesUpdater { // "Game.Battle.Entities.Building.LootNodesUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t updaters = 0x20; // "List<IStoppedUpdater>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xBB7AA0; // "public LootNodesUpdater Init(LocationBuildingDescription locationBuildingDescription, LootNodesModel lootNodes, LocationScreenViewModel locationScreenViewModel, SoundEmitter soundEmitter, LocalizationKeys keys, BattleModel battleModel, PersonalNotificationModel notificationModel, ITargetSubsystem targetSubsystem, GlobalUISoundModel uiSoundModel, UpdaterPool updaterPool, IRegisterDisposable registerDisposable, BattleScreenContent content)"
            inline constexpr std::uintptr_t Dispose = 0xBB7A40; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xB3B570; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Stop = 0xB3B580; // "public void Stop()"
            inline constexpr std::uintptr_t Core_Updater_IStoppedUpdater_Update = 0x9165B0; // "private void Core.Updater.IStoppedUpdater.Update()"
        }
    } // namespace LootNodesUpdater

    namespace LootNodeTargetHintUpdater { // "Game.Battle.EntityModel.LootNodeTargetHintUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t targetObject = 0x20; // "ITargetObject"
            inline constexpr std::uintptr_t targetHintObjectsModel = 0x28; // "TargetHintObjectsModel"
            inline constexpr std::uintptr_t lootNodeModel = 0x30; // "LootNodeModel"
            inline constexpr std::uintptr_t isVisible = 0x38; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xAEE950; // "public LootNodeTargetHintUpdater Init(ITargetObject targetObject, TargetHintObjectsModel targetHintObjectsModel, LootNodeModel lootNodeModel)"
            inline constexpr std::uintptr_t Dispose = 0xB3E920; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xBF3120; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t UpdateVisible = 0xB3EA50; // "private void UpdateVisible(bool isVisible)"
            inline constexpr std::uintptr_t Stop = 0xB3EA10; // "public void Stop()"
            inline constexpr std::uintptr_t Core_Updater_IStoppedUpdater_Update = 0x9165B0; // "private void Core.Updater.IStoppedUpdater.Update()"
        }
    } // namespace LootNodeTargetHintUpdater

    namespace LootNodeTargetProvider { // "Game.Battle.Entities.Building.LootNodeTargetProvider (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t priority = 0x20; // "TargetPriorityViewDescription"
            inline constexpr std::uintptr_t targetActions = 0x28; // "LootNodesTargetActions"
            inline constexpr std::uintptr_t hintTipKeys = 0x30; // "HintTipKeys"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x38; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t lootNode = 0x40; // "LootNodeModel"
            inline constexpr std::uintptr_t unavailableKeys = 0x48; // "UnavailableTargetActionsKeys"
        }
        namespace Methods {
            inline constexpr std::uintptr_t GetTargetAction = 0xBB5960; // "protected override ITargetAction GetTargetAction()"
        }
    } // namespace LootNodeTargetProvider

    namespace LootNotificationConfig { // "Models.References.Loot.LootNotificationConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t MaxCount = 0x10; // "int"
        }
    } // namespace LootNotificationConfig

    namespace LootObjectExtensions { // "Models.Utils.Extensions.LootObjectExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t TryGetTakeTime = 0x3960BC0; // "public static bool TryGetTakeTime(WorldEntitiesModel worldEntitiesModel, int lootObjectEntityId, out long time)"
        }
    } // namespace LootObjectExtensions

    namespace LootObjectItemDescription { // "Models.References.LootObject.LootObjectItemDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ItemDescriptionFunc = 0x20; // "Func<InventoryItemDescription>"
            inline constexpr std::uintptr_t Count = 0x28; // "int"
            inline constexpr std::uintptr_t Durability = 0x2C; // "int"
            inline constexpr std::uintptr_t TakeTime = 0x30; // "int"
            inline constexpr std::uintptr_t LootObjectCollidersFunc = 0x38; // "Func<LootObjectCollidersDescription>"
            inline constexpr std::uintptr_t CostItemDescriptionFunc = 0x40; // "Func<InventoryItemDescription>"
            inline constexpr std::uintptr_t GrandHeistDescriptionFunc = 0x48; // "Func<GrandHeistDescription>"
            inline constexpr std::uintptr_t StealingAchievementDescriptionFunc = 0x50; // "Func<AchievementDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_ItemDescription = 0x9D6230; // "public InventoryItemDescription get_ItemDescription()"
            inline constexpr std::uintptr_t get_Ammo = 0x40B98B0; // "public int get_Ammo()"
            inline constexpr std::uintptr_t get_LootObjectColliders = 0x2AA0B60; // "public LootObjectCollidersDescription get_LootObjectColliders()"
            inline constexpr std::uintptr_t get_CostItemDescription = 0x4048E60; // "public InventoryItemDescription get_CostItemDescription()"
            inline constexpr std::uintptr_t get_GrandHeistDescription = 0x4048E90; // "public GrandHeistDescription get_GrandHeistDescription()"
            inline constexpr std::uintptr_t get_AchievementDescription = 0x1CE7810; // "public AchievementDescription get_AchievementDescription()"
        }
    } // namespace LootObjectItemDescription

    namespace LootObjectModel { // "Models.Models.LootObjectModel.LootObjectModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t isTaken = 0x10; // "IPrimitiveData<bool>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsTaken = 0x4943570; // "public bool get_IsTaken()"
            inline constexpr std::uintptr_t Take = 0x4943520; // "public void Take()"
            inline constexpr std::uintptr_t Reset = 0x49434D0; // "public virtual void Reset()"
        }
    } // namespace LootObjectModel

    namespace LootObjectTargetActions { // "Game.Battle.Entities.Building.LootObjectTargetActions (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t entityId = 0x10; // "int"
            inline constexpr std::uintptr_t battleInputModel = 0x18; // "BattleInputModel"
            inline constexpr std::uintptr_t personalNotificationModel = 0x20; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x28; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t notificationError = 0x30; // "NotificationError"
            inline constexpr std::uintptr_t unavailableKeys = 0x38; // "UnavailableTargetActionsKeys"
            inline constexpr std::uintptr_t lootObjectItemDescription = 0x40; // "LootObjectItemDescription"
            inline constexpr std::uintptr_t useEntityCommandDescription = 0x48; // "UseEntityCommandDescription"
            inline constexpr std::uintptr_t uiSoundModel = 0x50; // "GlobalUISoundModel"
            inline constexpr std::uintptr_t intention = 0x58; // "InventoryIntention"
            inline constexpr std::uintptr_t becomeRobberNotificationModel = 0x60; // "BecomeRobberNotificationModel"
            inline constexpr std::uintptr_t Take = 0x68; // "TargetAction"
            inline constexpr std::uintptr_t TakeUnavailableRole = 0x70; // "UnavailableTargetAction"
        }
        namespace Methods {
            inline constexpr std::uintptr_t GetLootItemNames = 0xBB7F00; // "public static void GetLootItemNames(InventoryItemViewDescriptions inventoryItemViewDescriptions, BattleScreenContent battleScreenContent, LootObjectItemDescription lootObjectItemDescription, out TargetItemWithRarity nameWhenRequired, out TargetItemWithRarity nameWhenNotRequired)"
            inline constexpr std::uintptr_t TakeLootObject = 0xBB80E0; // "private void TakeLootObject()"
            inline constexpr std::uintptr_t UnavailableTake = 0xBB8200; // "private void UnavailableTake()"
            inline constexpr std::uintptr_t Unavailable = 0xBB8310; // "private void Unavailable(LocalizedString invalidNotification, PersonalNotificationActionIds id)"
        }
    } // namespace LootObjectTargetActions

    namespace LootObjectTargetProvider { // "Game.Battle.Entities.Building.Updaters.LootObjectTargetProvider (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t gatherSettlementCollectionsModel = 0x20; // "GatherSettlementCollectionsModel"
            inline constexpr std::uintptr_t lootObjectModel = 0x28; // "ILootObjectModel"
            inline constexpr std::uintptr_t actions = 0x30; // "LootObjectTargetActions"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x38; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t unavailableKeys = 0x40; // "UnavailableTargetActionsKeys"
            inline constexpr std::uintptr_t securityAlarmDescription = 0x48; // "LocationSecurityAlarmDescription"
            inline constexpr std::uintptr_t useHintViewDescription = 0x50; // "UseHintViewDescription"
            inline constexpr std::uintptr_t targetObject = 0x58; // "ITargetObject"
            inline constexpr std::uintptr_t nameWhenRequired = 0x60; // "TargetItemWithRarity"
            inline constexpr std::uintptr_t nameWhenNotRequired = 0x68; // "TargetItemWithRarity"
            inline constexpr std::uintptr_t location = 0x70; // "ComputedLocationDescription"
            inline constexpr std::uintptr_t accessEntities = 0x78; // "ReadOnly.Dictionary<int, AccessEntityModel>"
            inline constexpr std::uintptr_t requiredItem = 0x80; // "Text<LocalizedString>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t GetTargetAction = 0xBB87C0; // "protected override ITargetAction GetTargetAction()"
            inline constexpr std::uintptr_t GetLockingAccessEntity = 0xBB8730; // "private AccessEntityModel GetLockingAccessEntity()"
            inline constexpr std::uintptr_t SetAlarmPictogram = 0xBB8CC0; // "private void SetAlarmPictogram()"
        }
    } // namespace LootObjectTargetProvider

    namespace LootTargetActions { // "Game.Battle.EntityModel.Loot.LootTargetActions (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleModel = 0x10; // "BattleModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x18; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t battleInputModel = 0x20; // "BattleInputModel"
            inline constexpr std::uintptr_t serverModel = 0x28; // "ILootModel"
            inline constexpr std::uintptr_t personalNotificationModel = 0x30; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t uiSoundModel = 0x38; // "GlobalUISoundModel"
            inline constexpr std::uintptr_t unavailableKeys = 0x40; // "UnavailableTargetActionsKeys"
            inline constexpr std::uintptr_t becomeRobberNotificationModel = 0x48; // "BecomeRobberNotificationModel"
            inline constexpr std::uintptr_t observerRequestModel = 0x50; // "ObserverRequestModel"
            inline constexpr std::uintptr_t Loot = 0x58; // "TargetAction"
            inline constexpr std::uintptr_t Arrest = 0x60; // "TargetAction"
            inline constexpr std::uintptr_t UnavailableRoleTargetAction = 0x68; // "ITargetAction"
        }
        namespace Methods {
            inline constexpr std::uintptr_t ArrestLoot = 0xC94880; // "private void ArrestLoot()"
            inline constexpr std::uintptr_t OpenLoot = 0xC949C0; // "private void OpenLoot()"
            inline constexpr std::uintptr_t UnavailableWithHighlightBecomeRobber = 0xC94AB0; // "private void UnavailableWithHighlightBecomeRobber()"
            inline constexpr std::uintptr_t Unavailable = 0xA74080; // "private void Unavailable(LocalizedString invalidNotification, PersonalNotificationActionIds id)"
        }
    } // namespace LootTargetActions

    namespace LootTargetHintObjectUpdater { // "Game.Battle.Entities.Building.Updaters.LootTargetHintObjectUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t targetHintObjectsModel = 0x20; // "TargetHintObjectsModel"
            inline constexpr std::uintptr_t lootObjectModel = 0x28; // "ILootObjectModel"
            inline constexpr std::uintptr_t targetObject = 0x30; // "ITargetObject"
            inline constexpr std::uintptr_t isVisible = 0x38; // "bool"
            inline constexpr std::uintptr_t location = 0x40; // "ComputedLocationDescription"
            inline constexpr std::uintptr_t accessEntities = 0x48; // "ReadOnly.Dictionary<int, AccessEntityModel>"
            inline constexpr std::uintptr_t accessEntityDescription = 0x50; // "LocationAccessEntityDescription"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x58; // "IBattleEntitiesModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xBCC300; // "public LootTargetHintObjectUpdater Init(ITargetObject targetObject, BattleModel battleModel, ILootObjectModel lootObjectModel)"
            inline constexpr std::uintptr_t Dispose = 0xBCC110; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xBCC470; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t GetIsVisible = 0xBCC1C0; // "private bool GetIsVisible()"
            inline constexpr std::uintptr_t UpdateVisible = 0xBA3180; // "private void UpdateVisible(bool isVisible)"
            inline constexpr std::uintptr_t Stop = 0xBA3140; // "public void Stop()"
            inline constexpr std::uintptr_t Core_Updater_IStoppedUpdater_Update = 0x9165B0; // "private void Core.Updater.IStoppedUpdater.Update()"
        }
    } // namespace LootTargetHintObjectUpdater

    namespace LootTargetProvider { // "Game.Battle.EntityModel.Loot.LootTargetProvider (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t lootActions = 0x20; // "LootTargetActions"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x28; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t unavailableKeys = 0x30; // "UnavailableTargetActionsKeys"
        }
        namespace Methods {
            inline constexpr std::uintptr_t GetTargetAction = 0xC94FF0; // "protected override ITargetAction GetTargetAction()"
        }
    } // namespace LootTargetProvider

    namespace LootTriggerConfig { // "Models.References.Container.LootTriggerConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t MaxTriggersPerLoot = 0x10; // "int"
        }
    } // namespace LootTriggerConfig

    namespace LootTriggerDescription { // "Models.References.Container.LootTriggerDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t CheckSolo = 0x18; // "bool"
            inline constexpr std::uintptr_t AuthorityLevelFunc = 0x20; // "Func<RobberAuthorityLevelDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_AuthorityLevel = 0x9D6230; // "public RobberAuthorityLevelDescription get_AuthorityLevel()"
        }
    } // namespace LootTriggerDescription

    namespace MakeBarterDealMessage { // "Models.Messages.MakeBarterDealMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t entityId = 0x20; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t recipeIndex = 0x28; // "IPrimitiveData<int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_TraderEntityId = 0x4A0AD80; // "public int get_TraderEntityId()"
            inline constexpr std::uintptr_t get_RecipeIndex = 0x4A0AD30; // "public int get_RecipeIndex()"
            inline constexpr std::uintptr_t get_Type = 0x4A0ADD0; // "public override string get_Type()"
        }
    } // namespace MakeBarterDealMessage

    namespace MaxModelCount { // "Game.Battle.Inventory.MaxModelCount (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Value = 0x10; // "int"
        }
    } // namespace MaxModelCount

    namespace MoneyLaunderingRestrictedCellsModelUpdater { // "Game.Battle.Inventory.RestrictedCells.MoneyLaunderingRestrictedCellsModelUpdater (Battle.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0x9F7740; // "public MoneyLaunderingRestrictedCellsModelUpdater Init(BattleCharacterModel battleCharacterModel, RestrictedCellsModel restrictedCellsModel)"
            inline constexpr std::uintptr_t GetIsActive = 0xA68A80; // "protected override bool GetIsActive(IInventoryItemModel itemModel)"
        }
    } // namespace MoneyLaunderingRestrictedCellsModelUpdater

    namespace MoneyWorkbenchBonusConfig { // "Models.References.MoneyWorkbench.MoneyWorkbenchBonusConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t BonusPerAmount = 0x10; // "MoneyWorkbenchBonusEntry[]"
            inline constexpr std::uintptr_t BrokenCablePenaltyPercent = 0x18; // "int"
            inline constexpr std::uintptr_t RepairBrokenCableDuration = 0x20; // "long"
        }
    } // namespace MoneyWorkbenchBonusConfig

    namespace MoneyWorkbenchBonusEntry { // "Models.References.MoneyWorkbench.MoneyWorkbenchBonusEntry (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Amount = 0x10; // "int"
            inline constexpr std::uintptr_t Bonus = 0x14; // "int"
        }
    } // namespace MoneyWorkbenchBonusEntry

    namespace MoneyWorkbenchData { // "Models.Data.Settlement.MoneyWorkbench.MoneyWorkbenchData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t DirtyAmount = 0x20; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t CleanAmount = 0x28; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t LastTickTs = 0x30; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t IsLaunderingActive = 0x38; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t Upgrades = 0x40; // "MoneyWorkbenchUpgradesData"
            inline constexpr std::uintptr_t PoopPilePlacers = 0x48; // "ListData<PublicIdData>"
        }
    } // namespace MoneyWorkbenchData

    namespace MoneyWorkbenchDescription { // "Models.References.MoneyWorkbench.MoneyWorkbenchDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t MaxDirtyCashAmount = 0x20; // "int"
            inline constexpr std::uintptr_t SpeedupUpgradesCount = 0x24; // "int"
            inline constexpr std::uintptr_t AnalyticsSource = 0x28; // "LaunderingAnalyticsDescription"
        }
    } // namespace MoneyWorkbenchDescription

    namespace MoneyWorkbenchDestroyModel { // "Models.Models.MoneyWorkbenchDestroy.MoneyWorkbenchDestroyModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "IMoneyWorkbenchModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Destroy = 0x4912F80; // "public void Destroy(WorldEntitiesModel worldEntitiesModel)"
            inline constexpr std::uintptr_t DestroyModel = 0x4912F50; // "private void DestroyModel(WorldEntitiesModel worldEntitiesModel)"
        }
    } // namespace MoneyWorkbenchDestroyModel

    namespace MoneyWorkbenchEntityIds { // "Models.References.Builder.MoneyWorkbenchEntityIds (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ModelEntityId = 0x10; // "int"
            inline constexpr std::uintptr_t UpgradeSpeedupSlotEntityIds = 0x18; // "IReadOnlyDictionary<MoneyWorkbenchSpeedupUpgradeSlotDescription, int>"
        }
    } // namespace MoneyWorkbenchEntityIds

    namespace MoneyWorkbenchExtensions { // "Models.Utils.Extensions.MoneyWorkbenchExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t BuildEntityIds = 0x3963CC0; // "public static MoneyWorkbenchEntityIds BuildEntityIds(IEntityIdGenerator entityIdGenerator)"
            inline constexpr std::uintptr_t BuildLocationDescription = 0x3963F70; // "public static LocationMoneyWorkbenchDescription BuildLocationDescription(PlotMoneyWorkbenchDescription plotMoneyWorkbenchDescription, MoneyWorkbenchEntityIds entityIds, Vector3 worldPosition, Quaternion worldOrientation)"
            inline constexpr std::uintptr_t GetLaunderingBonuses = 0x3964A60; // "public static MoneyWorkbenchLaunderingBonuses GetLaunderingBonuses(PlotModel plotModel)"
            inline constexpr std::uintptr_t GetClanLaunderingDirtyCashPerPeriodModifier = 0x3964830; // "public static float GetClanLaunderingDirtyCashPerPeriodModifier(IOwnedClanConquestItemsModel<ClanConquestObjectTypeDescription> ownedObjects, IOwnedClanConquestItemsModel<SectorDescription> ownedSectors, RealmVersion realmVersion)"
            inline constexpr std::uintptr_t GetTotalClearCash = 0x3964AE0; // "public static int GetTotalClearCash(IMoneyWorkbenchModel moneyWorkbenchModel)"
            inline constexpr std::uintptr_t GetAssetsValue = 0x3964460; // "public static int GetAssetsValue(IMoneyWorkbenchModel moneyWorkbenchModel)"
            inline constexpr std::uintptr_t BuildSpeedupUpgradeSlotEnum = 0x3964290; // "public static ReadOnlyEnum<MoneyWorkbenchSpeedupUpgradeSlotDescription> BuildSpeedupUpgradeSlotEnum(ReadOnlyEnum<MoneyWorkbenchDescription> moneyWorkbenchDescriptions)"
        }
    } // namespace MoneyWorkbenchExtensions

    namespace MoneyWorkbenchInitializeModel { // "Models.Models.MoneyWorkbenchInitialize.MoneyWorkbenchInitializeModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "IMoneyWorkbenchModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Initialize = 0x4913010; // "public void Initialize(WorldEntitiesModel worldEntitiesModel, LocationMoneyWorkbenchDescription locationMoneyWorkbenchDescription)"
        }
    } // namespace MoneyWorkbenchInitializeModel

    namespace MoneyWorkbenchInventoryItemsSearchSource { // "Models.Inventory.InventoryItemsSearch.Sources.MoneyWorkbenchInventoryItemsSearchSource (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t MoneyWorkbench = 0x0; // "IMoneyWorkbenchModel"
            inline constexpr std::uintptr_t State = 0x8; // "LaunderingState"
        }
    } // namespace MoneyWorkbenchInventoryItemsSearchSource

    namespace MoneyWorkbenchLaunderingBonuses { // "Models.Models.LaunderingRules.MoneyWorkbenchLaunderingBonuses (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t DirtyCashPerPeriodModifier = 0x0; // "float"
            inline constexpr std::uintptr_t VipEndTs = 0x8; // "long"
        }
    } // namespace MoneyWorkbenchLaunderingBonuses

    namespace MoneyWorkbenchLaunderingDescription { // "Models.References.MoneyWorkbench.MoneyWorkbenchLaunderingDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x81F4CF8; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t cashItem = 0x0; // "InventoryItemDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_DirtyCashPerPeriodBase = 0x40BC080; // "public static int get_DirtyCashPerPeriodBase()"
            inline constexpr std::uintptr_t get_Period = 0x40BC1E0; // "public static long get_Period()"
            inline constexpr std::uintptr_t get_DirtyToCleanCashModifier = 0x40BC130; // "public static float get_DirtyToCleanCashModifier()"
            inline constexpr std::uintptr_t TryGetRecyclableItemDirtyCashValue = 0x40BBF70; // "public static bool TryGetRecyclableItemDirtyCashValue(InventoryItemDescription item, out int value)"
            inline constexpr std::uintptr_t GetCashPileIndexByAmount = 0x40BBF20; // "public static int GetCashPileIndexByAmount(int amount, int[] moneyWorkbenchCashPileSizeIntervals)"
        }
    } // namespace MoneyWorkbenchLaunderingDescription

    namespace MoneyWorkbenchLaunderingPresetDescription { // "Models.References.MoneyWorkbench.MoneyWorkbenchLaunderingPresetDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x81F4E90; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace Fields {
            inline constexpr std::uintptr_t Period = 0x10; // "long"
            inline constexpr std::uintptr_t DirtyCashPerPeriodBase = 0x18; // "int"
            inline constexpr std::uintptr_t DirtyToCleanCashModifier = 0x1C; // "float"
        }
        namespace StaticFields {
            inline constexpr std::uintptr_t Develop = 0x0; // "MoneyWorkbenchLaunderingPresetDescription"
        }
    } // namespace MoneyWorkbenchLaunderingPresetDescription

    namespace MoneyWorkbenchModel { // "Models.Models.MoneyWorkbenchModel.MoneyWorkbenchModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "MoneyWorkbenchData"
            inline constexpr std::uintptr_t isLaunderingCableBroken = 0x18; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t DescriptionModel = 0x20; // "DescriptionModel<LocationMoneyWorkbenchDescription>"
            inline constexpr std::uintptr_t DestroyModel = 0x28; // "MoneyWorkbenchDestroyModel"
            inline constexpr std::uintptr_t InitializeModel = 0x30; // "MoneyWorkbenchInitializeModel"
            inline constexpr std::uintptr_t UpgradesModel = 0x38; // "MoneyWorkbenchUpgradesModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_DirtyAmount = 0x4913960; // "public int get_DirtyAmount()"
            inline constexpr std::uintptr_t get_CleanAmount = 0x4913910; // "public int get_CleanAmount()"
            inline constexpr std::uintptr_t get_LastTickTs = 0x4913AB0; // "public long get_LastTickTs()"
            inline constexpr std::uintptr_t get_IsLaunderingActive = 0x4913A10; // "public bool get_IsLaunderingActive()"
            inline constexpr std::uintptr_t get_PoopPileCount = 0x4913B00; // "public int get_PoopPileCount()"
            inline constexpr std::uintptr_t get_HasPoopPile = 0x49139B0; // "public bool get_HasPoopPile()"
            inline constexpr std::uintptr_t get_IsLaunderingCableBroken = 0x4913A60; // "public bool get_IsLaunderingCableBroken()"
            inline constexpr std::uintptr_t Set = 0x4913510; // "public void Set(int dirtyAmount, int cleanAmount, long lastTickTs)"
            inline constexpr std::uintptr_t Clear = 0x4913160; // "public void Clear()"
            inline constexpr std::uintptr_t CheckTakeDirty = 0x49130B0; // "public bool CheckTakeDirty()"
            inline constexpr std::uintptr_t TakeDirty = 0x4913710; // "public void TakeDirty(int amount)"
            inline constexpr std::uintptr_t StartLaundering = 0x49135D0; // "public void StartLaundering(long now)"
            inline constexpr std::uintptr_t StopLaundering = 0x4913670; // "public void StopLaundering(int dirtyAmount, int cleanAmount, long lastTickTs)"
            inline constexpr std::uintptr_t HasPooped = 0x4913240; // "public bool HasPooped(long publicId)"
            inline constexpr std::uintptr_t Poop = 0x4913320; // "public void Poop(long publicId)"
            inline constexpr std::uintptr_t ClearPoopPile = 0x4913110; // "public void ClearPoopPile()"
        }
    } // namespace MoneyWorkbenchModel

    namespace MoneyWorkbenchRules { // "Models.Models.LaunderingRules.MoneyWorkbenchRules (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t GetState = 0x4946980; // "public static LaunderingState GetState(long now, IMoneyWorkbenchModel model, MoneyWorkbenchLaunderingBonuses bonuses)"
            inline constexpr std::uintptr_t GetState_2 = 0x4946660; // "public static LaunderingState GetState(long now, IMoneyWorkbenchModel model, MoneyWorkbenchLaunderingBonuses bonuses, int modifierPercentOffset)"
            inline constexpr std::uintptr_t GetStateInternal = 0x4946580; // "private static LaunderingState GetStateInternal(long toTs, LaunderingState state, int dirtyByPeriodModifier)"
            inline constexpr std::uintptr_t AddDirtyAmount = 0x4945E30; // "public static LaunderingState AddDirtyAmount(long now, int amount, IMoneyWorkbenchModel model, MoneyWorkbenchLaunderingBonuses launderingBonuses)"
            inline constexpr std::uintptr_t LimitCalcClearCash = 0x4946D70; // "public static int LimitCalcClearCash(int dirtyAmount, int limit)"
            inline constexpr std::uintptr_t GetTotalModifierPercent = 0x4946C90; // "public static int GetTotalModifierPercent(IMoneyWorkbenchModel model, MoneyWorkbenchLaunderingBonuses bonuses, long now)"
            inline constexpr std::uintptr_t GetCurrentDirtyCashPerTick = 0x4945FA0; // "public static int GetCurrentDirtyCashPerTick(int dirtyAmount, IMoneyWorkbenchModel model, MoneyWorkbenchLaunderingBonuses bonuses, long now)"
            inline constexpr std::uintptr_t GetTimeToFullyLaunder = 0x49469C0; // "public static long GetTimeToFullyLaunder(int dirtyAmount, IMoneyWorkbenchModel model, MoneyWorkbenchLaunderingBonuses bonuses, long now)"
            inline constexpr std::uintptr_t GetDirtyCashPerPeriodUpgradesModifier = 0x4946120; // "public static float GetDirtyCashPerPeriodUpgradesModifier(IMoneyWorkbenchModel model)"
            inline constexpr std::uintptr_t GetLaunderingCablePenalty = 0x49464E0; // "public static int GetLaunderingCablePenalty(IMoneyWorkbenchModel model)"
            inline constexpr std::uintptr_t CutLaunderingCable = 0x4945F50; // "public static void CutLaunderingCable(long now, PlotModel plotModel, LaunderingCableModel cableModel)"
            inline constexpr std::uintptr_t RepairLaunderingCable = 0x4946F60; // "public static void RepairLaunderingCable(long now, PlotModel plotModel, LaunderingCableModel cableModel)"
            inline constexpr std::uintptr_t TrySyncVip = 0x4946FB0; // "public static bool TrySyncVip(long now, PlotModel plotModel, long vipEndTs)"
            inline constexpr std::uintptr_t RefreshMoneyWorkbenchState = 0x4946DD0; // "public static void RefreshMoneyWorkbenchState(long now, PlotModel plotModel)"
        }
    } // namespace MoneyWorkbenchRules

    namespace MoneyWorkbenchSpeedupUpgradeDescription { // "Models.References.MoneyWorkbench.MoneyWorkbenchSpeedupUpgradeDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t DirtyCashPerPeriodModifier = 0x20; // "float"
            inline constexpr std::uintptr_t ItemFunc = 0x28; // "Func<InventoryItemDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t GetItem = 0x993E50; // "public InventoryItemDescription GetItem()"
        }
    } // namespace MoneyWorkbenchSpeedupUpgradeDescription

    namespace MoneyWorkbenchUpgradeDescription { // "Models.References.MoneyWorkbench.MoneyWorkbenchUpgradeDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t SpeedupDescriptionFunc = 0x20; // "Func<MoneyWorkbenchSpeedupUpgradeDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_SpeedupDescription = 0x9D6230; // "public MoneyWorkbenchSpeedupUpgradeDescription get_SpeedupDescription()"
        }
    } // namespace MoneyWorkbenchUpgradeDescription

    namespace MoneyWorkbenchUpgradesData { // "Models.Data.Settlement.MoneyWorkbench.MoneyWorkbenchUpgradesData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t SpeedupSlots = 0x20; // "ReferenceMapData<MoneyWorkbenchSpeedupUpgradeSlotDescription, IPrimitiveData<MoneyWorkbenchSpeedupUpgradeDescription>>"
        }
    } // namespace MoneyWorkbenchUpgradesData

    namespace MoneyWorkbenchUpgradesModel { // "Models.Models.MoneyWorkbenchUpgrades.MoneyWorkbenchUpgradesModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t SpeedupSlots = 0x10; // "IReadOnlyDictionary<MoneyWorkbenchSpeedupUpgradeSlotDescription, IPrimitiveModel<MoneyWorkbenchSpeedupUpgradeDescription>>"
        }
    } // namespace MoneyWorkbenchUpgradesModel

    namespace MoneyWorkbenchUpgradeSpeedupBuilderSlotModel { // "Game.Battle.Builder.MoneyWorkbenchUpgradeSpeedupBuilderSlotModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x28; // "IPrimitiveModel<MoneyWorkbenchSpeedupUpgradeDescription>"
            inline constexpr std::uintptr_t defenseBlockPublicModel = 0x30; // "DefenseBlockPublicModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_InventoryItemDescription = 0xD40320; // "public override InventoryItemDescription get_InventoryItemDescription()"
            inline constexpr std::uintptr_t CheckType = 0xD402D0; // "public override bool CheckType(InventoryItemDescription itemDescription)"
            inline constexpr std::uintptr_t CheckCooldown = 0x7D5050; // "public override bool CheckCooldown(long now)"
            inline constexpr std::uintptr_t IsBlockedByBreachedObjects = 0x7EC9F0; // "public override bool IsBlockedByBreachedObjects(long now)"
            inline constexpr std::uintptr_t IsBlockedByLootObjects = 0x7EC9F0; // "public override bool IsBlockedByLootObjects(long now)"
            inline constexpr std::uintptr_t CheckShowModalOnMove = 0x7EC9F0; // "public override bool CheckShowModalOnMove(long now)"
            inline constexpr std::uintptr_t IsBlockedByRaidLock = 0xD3D010; // "public override bool IsBlockedByRaidLock(long now)"
        }
    } // namespace MoneyWorkbenchUpgradeSpeedupBuilderSlotModel

    namespace MoveItemAction { // "Game.Battle.Inventory.MoveItemAction (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t From = 0x0; // "IItemMoveContext"
            inline constexpr std::uintptr_t To = 0x8; // "IItemMoveContext"
            inline constexpr std::uintptr_t Count = 0x10; // "int"
        }
    } // namespace MoveItemAction

    namespace NewAvailableItemsModel { // "Game.Battle.Inventory.NewAvailableItemsModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Items = 0x10; // "HashSet<InventoryItemDescription>"
            inline constexpr std::uintptr_t ItemsToRemove = 0x18; // "HashSet<InventoryItemDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Add = 0xA68B00; // "public void Add(InventoryItemDescription itemDescription)"
            inline constexpr std::uintptr_t Contains = 0xA68B80; // "public bool Contains(InventoryItemDescription itemDescription)"
            inline constexpr std::uintptr_t Remove = 0xA68C00; // "public void Remove(InventoryItemDescription itemDescription)"
        }
    } // namespace NewAvailableItemsModel

    namespace OpenInventoryModel { // "Game.Battle.Inventory.OpenInventoryModel (Battle.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t OpenInventory = 0xA68D30; // "public static void OpenInventory(BattleModel battleModel, GlobalModel globalModel, BattleScreenContent battleScreenContent)"
        }
    } // namespace OpenInventoryModel

    namespace PagedInventoryCostViewUpdater { // "Game.Battle.Inventory.Cost.PagedInventoryCostViewUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t inventoryPagesModel = 0x20; // "ItemInventoryPaginatorModel"
            inline constexpr std::uintptr_t totalCostView = 0x28; // "TextLabel<Money>"
            inline constexpr std::uintptr_t dialogModel = 0x30; // "PlotLootDialogModel"
            inline constexpr std::uintptr_t isVisible = 0x38; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA7F670; // "public PagedInventoryCostViewUpdater Init(PlotLootDialogModel dialogModel, ItemInventoryPaginatorModel inventoryPagesModel, TextLabel<Money> totalCostView)"
            inline constexpr std::uintptr_t Dispose = 0x92B5C0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA7F6D0; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t CountCost = 0xA7F3A0; // "private int CountCost()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace PagedInventoryCostViewUpdater

    namespace PickupLootModel { // "Models.Inventory.PickupLootObject.PickupLootObjectModel.PickupLootModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t inventoryMask = 0x10; // "bool[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t TryFindInventorySlotForSingleItem = 0x4A61530; // "public bool TryFindInventorySlotForSingleItem(InventoryItemDescription item, IInventoryModel inventoryModel, PickupLootResult pickupLootResult)"
            inline constexpr std::uintptr_t FindInventorySlotForSingleItem = 0x4A60EC0; // "private bool FindInventorySlotForSingleItem(bool[] inventoryMask, InventoryItemDescription item, int slotsCount, IInventoryModel inventoryModel, PickupLootResult pickupLootResult)"
            inline constexpr std::uintptr_t CheckMaskForItem = 0x4A60DE0; // "private bool CheckMaskForItem(bool[] inventoryMask, int x, int y, InventoryItemDescription item, InventoryCellsSizeDescription inventoryCellsSizeDescription)"
            inline constexpr std::uintptr_t TryFindPocketsForItem = 0x4A61800; // "public int TryFindPocketsForItem(InventoryItemDescription item, int amount, IPocketsModel pockets, PickupLootResult pickupLootResult)"
            inline constexpr std::uintptr_t TryFindSlotsForStackableItem = 0x4A61AA0; // "public int TryFindSlotsForStackableItem(InventoryItemDescription item, int amount, IInventoryModel inventoryModel, PickupLootResult pickupLootResult)"
            inline constexpr std::uintptr_t FindSlotsForStackableItem = 0x4A610C0; // "private int FindSlotsForStackableItem(InventoryItemDescription item, int amount, IInventoryModel inventoryModel, bool[] inventoryMask, PickupLootResult pickupLootResult)"
        }
    } // namespace PickupLootModel

    namespace PickupLootResult { // "Models.Inventory.PickupLootObject.PickupLootResult (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t RefilledInventorySlots = 0x10; // "IEventsSet<int>"
            inline constexpr std::uintptr_t RefilledPockets = 0x18; // "IEventsSet<int>"
            inline constexpr std::uintptr_t InventorySlot = 0x20; // "int"
            inline constexpr std::uintptr_t PocketSlot = 0x24; // "int"
            inline constexpr std::uintptr_t EquipSlotDescription = 0x28; // "EquipSlotDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Clear = 0x4A61CE0; // "public void Clear()"
        }
    } // namespace PickupLootResult

    namespace PocketDragAndDropHoverUpdater { // "Game.Battle.Inventory.PocketDragAndDropHoverUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x20; // "InventoryDragAndDropModel"
            inline constexpr std::uintptr_t pocketsUiView = 0x28; // "PocketsUiView"
            inline constexpr std::uintptr_t pocketsContexts = 0x30; // "PocketItemMoveContext[]"
            inline constexpr std::uintptr_t hover = 0x38; // "IItemMoveContext"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0x9FA8F0; // "public PocketDragAndDropHoverUpdater Init(InventoryDragAndDropModel model, PocketsUiView pocketsUiView, PocketItemMoveContext[] pocketsContexts)"
            inline constexpr std::uintptr_t Dispose = 0x9F4BF0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA054C0; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace PocketDragAndDropHoverUpdater

    namespace PocketDropAreaInputUpdater { // "Game.Battle.Inventory.PocketDropAreaInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t playerEntityModel = 0x10; // "PlayerEntityModel"
            inline constexpr std::uintptr_t pocketsUiView = 0x18; // "PocketsUiView"
            inline constexpr std::uintptr_t inventoryDragModel = 0x20; // "InventoryDragAndDropModel"
            inline constexpr std::uintptr_t battleActions = 0x28; // "InputActions.BattleActions"
            inline constexpr std::uintptr_t itemSplitModel = 0x30; // "ItemSplitModel"
            inline constexpr std::uintptr_t inventorySelectedModel = 0x38; // "InventorySelectedModel"
            inline constexpr std::uintptr_t itemMoveModel = 0x40; // "ItemMoveModel"
            inline constexpr std::uintptr_t shopSplitModel = 0x48; // "ShopSplitModel"
            inline constexpr std::uintptr_t personalNotificationModel = 0x50; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t notificationError = 0x58; // "NotificationError"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA26360; // "public void Update()"
        }
    } // namespace PocketDropAreaInputUpdater

    namespace PocketItemActionModel { // "Models.Inventory.ItemActionModel.PocketItemActionModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t slotModel = 0x10; // "IPocketSlotModel"
            inline constexpr std::uintptr_t selectedQuickSlot = 0x18; // "SelectedQuickSlotModel"
            inline constexpr std::uintptr_t quickSlotSelectProgress = 0x20; // "QuickSlotSelectProgressModel"
            inline constexpr std::uintptr_t contextMenuUseItemModel = 0x28; // "ContextMenuUseItemModel"
            inline constexpr std::uintptr_t itemActionProcessModel = 0x30; // "ItemActionProcessModel"
            inline constexpr std::uintptr_t inventoryUseItemModel = 0x38; // "InventoryUseItemModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_SlotModel = 0x7EC6B0; // "public IPocketSlotModel get_SlotModel()"
            inline constexpr std::uintptr_t TrySet = 0x4A62830; // "public bool TrySet(IPocketsModel pocketsModel, PocketSlotDescription slot, SelectedQuickSlotModel selectedQuickSlot, QuickSlotSelectProgressModel quickSlotSelectProgress, ContextMenuUseItemModel contextMenuUseItemModel, ItemActionProcessModel itemActionProcessModel, InventoryUseItemModel inventoryUseItemModel)"
            inline constexpr std::uintptr_t CheckSet = 0x4A622E0; // "public bool CheckSet(InventoryItemDescription item, int count, int ammo, int durability, int cumulativePoints, out bool isSet)"
            inline constexpr std::uintptr_t CheckMoveTo = 0x4A62230; // "public bool CheckMoveTo(InventoryItemDescription item, int count, int ammo, int durability, int cumulativePoints, IItemActionModel fromModel, out bool isSet)"
            inline constexpr std::uintptr_t CheckMoveFrom = 0x4A62040; // "public bool CheckMoveFrom(int count, out InventoryItemDescription item, out int ammo, out int durability, out int cumulativePoints, out bool isUnset)"
            inline constexpr std::uintptr_t CheckUnset = 0x4A62430; // "public bool CheckUnset()"
            inline constexpr std::uintptr_t CheckSwap = 0x4A62390; // "public bool CheckSwap(InventoryItemDescription item, int count, int ammo, int durability, int cumulativePoints)"
            inline constexpr std::uintptr_t TryGetContent = 0x4A626F0; // "public bool TryGetContent(out InventoryItemDescription item, out int count, out int ammo, out int durability, out int cumulativePoints)"
            inline constexpr std::uintptr_t AreEqual = 0x4A61EE0; // "public bool AreEqual(IItemActionModel other)"
            inline constexpr std::uintptr_t Set = 0x4A62660; // "public void Set(long now, InventoryItemDescription item, int count, int ammo, int durability, int cumulativePoints)"
            inline constexpr std::uintptr_t Unset = 0x4A629B0; // "public void Unset()"
            inline constexpr std::uintptr_t ChangeStack = 0x4A61FA0; // "public void ChangeStack(int count)"
            inline constexpr std::uintptr_t ChangeAmmo = 0x4A61F60; // "public void ChangeAmmo(int ammo)"
            inline constexpr std::uintptr_t MarkSelectedQuickSlotItemChanged = 0x4A62630; // "private void MarkSelectedQuickSlotItemChanged()"
            inline constexpr std::uintptr_t IsRememberedSlot = 0x4A624E0; // "private bool IsRememberedSlot()"
            inline constexpr std::uintptr_t IsSelectedSlot = 0x4A62590; // "private bool IsSelectedSlot()"
            inline constexpr std::uintptr_t get_IsUsed = 0x4A62BC0; // "private bool get_IsUsed()"
            inline constexpr std::uintptr_t get_IsSlotBusy = 0x4A62A20; // "public bool get_IsSlotBusy()"
            inline constexpr std::uintptr_t CheckUnloadAmmo = 0x7EC9F0; // "public bool CheckUnloadAmmo(long now)"
        }
    } // namespace PocketItemActionModel

    namespace PocketItemMoveContext { // "Game.Battle.Inventory.PocketItemMoveContext (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Slot = 0x10; // "IPocketSlotModel"
            inline constexpr std::uintptr_t EmptyInventorySlotDescription = 0x18; // "InventorySlotDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_ItemModel = 0xA26AC0; // "public IInventoryItemModel get_ItemModel()"
            inline constexpr std::uintptr_t get_RevealContainerModel = 0xA26B10; // "public IRevealContainerModel get_RevealContainerModel()"
            inline constexpr std::uintptr_t get_Revealed = 0x7D5050; // "public bool get_Revealed()"
            inline constexpr std::uintptr_t get_Count = 0xA26A50; // "public int get_Count()"
            inline constexpr std::uintptr_t get_Ammo = 0x7E3AB0; // "public int get_Ammo()"
            inline constexpr std::uintptr_t get_Durability = 0x7E3AB0; // "public int get_Durability()"
            inline constexpr std::uintptr_t get_CumulativePoints = 0x7E3AB0; // "public int get_CumulativePoints()"
        }
    } // namespace PocketItemMoveContext

    namespace PocketRestrictedShadowUpdater { // "Game.Battle.Inventory.RestrictedCells.PocketRestrictedShadowUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t restrictedCellsModel = 0x20; // "RestrictedCellsModel"
            inline constexpr std::uintptr_t pocketSlotModel = 0x28; // "IPocketSlotModel"
            inline constexpr std::uintptr_t parent = 0x30; // "Transform"
            inline constexpr std::uintptr_t restrictedShadowPool = 0x38; // "PooledLoadedComponentContent<Transform>"
            inline constexpr std::uintptr_t restrictedShadowContent = 0x40; // "IDisposableContent<Transform>"
            inline constexpr std::uintptr_t isActive = 0x48; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA693E0; // "public PocketRestrictedShadowUpdater Init(RestrictedCellsModel restrictedCellsModel, IPocketSlotModel pocketSlotModel, Transform parent, PooledLoadedComponentContent<Transform> restrictedShadowPool)"
            inline constexpr std::uintptr_t Dispose = 0xA692F0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA69500; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t GenerateRestrictedShadow = 0xA69380; // "private void GenerateRestrictedShadow()"
            inline constexpr std::uintptr_t DisposeRestrictedShadow = 0xA69290; // "private void DisposeRestrictedShadow()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace PocketRestrictedShadowUpdater

    namespace PocketSellItemMessage { // "Models.Messages.Inventory.Sell.PocketSellItemMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t entityId = 0x20; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t slot = 0x28; // "IPrimitiveData<PocketSlotDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_TraderEntityId = 0x4A2D530; // "public override int get_TraderEntityId()"
            inline constexpr std::uintptr_t get_Slot = 0x4A2D4E0; // "public PocketSlotDescription get_Slot()"
            inline constexpr std::uintptr_t get_Type = 0x4A2D580; // "public override string get_Type()"
        }
    } // namespace PocketSellItemMessage

    namespace PocketSlotData { // "Models.Data.PocketSlotData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Item = 0x20; // "IPrimitiveData<InventoryItemDescription>"
            inline constexpr std::uintptr_t StackAmount = 0x28; // "IPrimitiveData<int>"
        }
    } // namespace PocketSlotData

    namespace PocketSlotModel { // "Models.Models.PocketSlotModel.PocketSlotModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Description = 0x10; // "PocketSlotDescription"
            inline constexpr std::uintptr_t ItemModel = 0x18; // "IInventoryItemModel"
            inline constexpr std::uintptr_t StackModel = 0x20; // "IInventoryStackModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Set = 0x48FC930; // "public void Set(InventoryItemDescription item, int count)"
            inline constexpr std::uintptr_t Unset = 0x48FCA30; // "public void Unset()"
        }
    } // namespace PocketSlotModel

    namespace PocketSlotModelUpdater { // "Game.Battle.Inventory.PocketSlotModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t slotModel = 0x20; // "IPocketSlotModel"
            inline constexpr std::uintptr_t inventoryModels = 0x28; // "InventoryModels"
            inline constexpr std::uintptr_t itemMoveContext = 0x30; // "IItemMoveContext"
            inline constexpr std::uintptr_t view = 0x38; // "InventoryItemView"
            inline constexpr std::uintptr_t isEmpty = 0x40; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA69660; // "public PocketSlotModelUpdater Init(IPocketSlotModel slotModel, InventoryModels inventoryModels, InventoryItemView view, IItemMoveContext itemMoveContext)"
            inline constexpr std::uintptr_t Dispose = 0xA695F0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA69700; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace PocketSlotModelUpdater

    namespace PocketSlotsModel { // "Models.Models.PocketSlotsModel.PocketSlotsModel (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t get_Item = 0x48FCD20; // "public IPocketSlotModel get_Item(int index)"
        }
    } // namespace PocketSlotsModel

    namespace PocketSlotStackModel { // "Models.Models.InventoryStackModel.PocketSlotStackModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "IPrimitiveData<int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Value = 0x4947920; // "public int get_Value()"
            inline constexpr std::uintptr_t set_Value = 0x4947970; // "public void set_Value(int value)"
        }
    } // namespace PocketSlotStackModel

    namespace PocketSlotViewUpdater { // "Game.Battle.Inventory.PocketSlotViewUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t slotModel = 0x20; // "IPocketSlotModel"
            inline constexpr std::uintptr_t pocketsModel = 0x28; // "IPocketsModel"
            inline constexpr std::uintptr_t view = 0x30; // "InventoryItemView"
            inline constexpr std::uintptr_t inventoryDragAndDropModel = 0x38; // "InventoryDragAndDropModel"
            inline constexpr std::uintptr_t isInteractable = 0x40; // "bool"
            inline constexpr std::uintptr_t showBlocked = 0x41; // "bool"
            inline constexpr std::uintptr_t draggedItem = 0x48; // "IItemMoveContext"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA69820; // "public PocketSlotViewUpdater Init(IPocketSlotModel slotModel, IPocketsModel pocketsModel, InventoryItemView view, InventoryDragAndDropModel inventoryDragAndDropModel)"
            inline constexpr std::uintptr_t Dispose = 0x9F4BF0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA698B0; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace PocketSlotViewUpdater

    namespace PocketsModel { // "Models.Models.PocketsModel.PocketsModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t beltItemModel = 0x10; // "IInventoryItemModel"
            inline constexpr std::uintptr_t startPocketsCount = 0x18; // "int"
            inline constexpr std::uintptr_t Slots = 0x20; // "IPocketSlotsModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_BeltItem = 0x48FD290; // "private InventoryItemDescription get_BeltItem()"
            inline constexpr std::uintptr_t get_StartPocketsCount = 0x7AB140; // "public int get_StartPocketsCount()"
            inline constexpr std::uintptr_t get_AdditionalSlotsCount = 0x48FD1F0; // "private int get_AdditionalSlotsCount()"
            inline constexpr std::uintptr_t get_Count = 0x48FD2E0; // "public int get_Count()"
            inline constexpr std::uintptr_t TryGetSlot = 0x48FCEA0; // "public bool TryGetSlot(PocketSlotDescription slot, out IPocketSlotModel model)"
            inline constexpr std::uintptr_t IsSlotInBelt = 0x48FCDE0; // "private bool IsSlotInBelt(PocketSlotDescription slot)"
        }
    } // namespace PocketsModel

    namespace PocketsUiView { // "Game.Battle.Inventory.PocketsUiView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t inventoryItemView = 0x20; // "InventoryItemView[]"
            inline constexpr std::uintptr_t dropAreaViews = 0x28; // "DropAreaView[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t GetView = 0xA69A40; // "public InventoryItemView GetView(int index)"
            inline constexpr std::uintptr_t GetDropAreaView = 0xA69A10; // "public DropAreaView GetDropAreaView(int index)"
        }
    } // namespace PocketsUiView

    namespace PredictPutCargoInInventorySystem { // "Models.Systems.PredictPutCargoInInventorySystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t worldEntitiesModel = 0x38; // "WorldEntitiesModel"
            inline constexpr std::uintptr_t settlementHelperModel = 0x40; // "ISettlementHelperModel"
            inline constexpr std::uintptr_t partyMemberAccessModel = 0x48; // "IPartyMemberAccessModel"
            inline constexpr std::uintptr_t characterSlotsModel = 0x50; // "ICharacterSlotsModel"
            inline constexpr std::uintptr_t clanBattleCharacterTeamModel = 0x58; // "IClanBattleCharacterTeamModel"
            inline constexpr std::uintptr_t vehicles = 0x60; // "ReadOnly.Dictionary<int, VehicleModel>"
            inline constexpr std::uintptr_t cargoOpenWorkbenches = 0x68; // "ReadOnly.Dictionary<int, CargoOpenWorkbenchModel>"
            inline constexpr std::uintptr_t cargoExchangeWorkbenches = 0x70; // "ReadOnly.Dictionary<int, CargoExchangeWorkbenchModel>"
            inline constexpr std::uintptr_t shelvings = 0x78; // "ReadOnly.Dictionary<int, ShelvingModel>"
            inline constexpr std::uintptr_t cargoChargeWorkbenches = 0x80; // "ReadOnly.Dictionary<int, CargoChargeWorkbenchModel>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x4104850; // "protected override void Tick(ITick tick)"
            inline constexpr std::uintptr_t CheckPutCargo = 0x4104260; // "private bool CheckPutCargo(int targetEntityId, int characterEntityId, CargoDescription cargo)"
            inline constexpr std::uintptr_t HasEmptySlot = 0x4104670; // "private bool HasEmptySlot(CargoInventoryModel cargoInventoryModel)"
        }
    } // namespace PredictPutCargoInInventorySystem

    namespace QuickSlotAutoSelectRules { // "Models.Models.QuickSlotAutoSelect.QuickSlotAutoSelectRules (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t IsAutoSelectQuickSlotAvailable = 0x48D79A0; // "public static bool IsAutoSelectQuickSlotAvailable(BattleCharacterModel model)"
        }
    } // namespace QuickSlotAutoSelectRules

    namespace QuickSlotAutoSelectSystem { // "Models.Systems.QuickSlotAutoSelectSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t worldInterruptModel = 0x38; // "IWorldInterruptModel"
            inline constexpr std::uintptr_t battleCharacters = 0x40; // "ReadOnly.Dictionary<int, BattleCharacterModel>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x4106240; // "protected override void Tick(ITick tick)"
            inline constexpr std::uintptr_t TryGetQuickSlotToSet = 0x4106860; // "private bool TryGetQuickSlotToSet(long now, QuickSlotDescription currentSlot, LastQuickSlotModel lastQuickSlotModel, QuickSlotsModel slots, EquipSlotsDelaysModel equipSlotsDelays, SelectedQuickSlotModel selectedSlotModel, out QuickSlotDescription newSlot, out bool setTakeInHandsIntentionOnEquipDelayEnds)"
            inline constexpr std::uintptr_t TryGetAvailableQuickSlotToSelect = 0x4106650; // "private bool TryGetAvailableQuickSlotToSelect(long now, QuickSlotsModel slots, EquipSlotsDelaysModel equipSlotsDelays, out QuickSlotDescription slot)"
            inline constexpr std::uintptr_t IsQuickSlotAvailableToSelect = 0x41060F0; // "private bool IsQuickSlotAvailableToSelect(long now, QuickSlotDescription quickSlotDescription, QuickSlotsModel slotsModel, EquipSlotsDelaysModel equipSlotsDelays)"
            inline constexpr std::uintptr_t IsQuickSlotHasItem = 0x41061B0; // "private static bool IsQuickSlotHasItem(QuickSlotDescription quickSlotDescription, QuickSlotsModel slotsModel)"
        }
    } // namespace QuickSlotAutoSelectSystem

    namespace QuickSlotDescription { // "Models.References.Inventory.QuickSlotDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x81AE0A8; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace Fields {
            inline constexpr std::uintptr_t IsWeapon = 0x20; // "bool"
            inline constexpr std::uintptr_t WeaponSlot = 0x28; // "EquipSlotDescription"
            inline constexpr std::uintptr_t IsPocket = 0x30; // "bool"
            inline constexpr std::uintptr_t PocketSlotFunc = 0x38; // "Func<PocketSlotDescription>"
            inline constexpr std::uintptr_t IsInventory = 0x40; // "bool"
        }
        namespace StaticFields {
            inline constexpr std::uintptr_t enum_id = 0x0; // "Enum<QuickSlotDescription>"
            inline constexpr std::uintptr_t Weapon0 = 0x8; // "QuickSlotDescription"
            inline constexpr std::uintptr_t Weapon1 = 0x10; // "QuickSlotDescription"
            inline constexpr std::uintptr_t Pocket0 = 0x18; // "QuickSlotDescription"
            inline constexpr std::uintptr_t Pocket1 = 0x20; // "QuickSlotDescription"
            inline constexpr std::uintptr_t Pocket2 = 0x28; // "QuickSlotDescription"
            inline constexpr std::uintptr_t Pocket3 = 0x30; // "QuickSlotDescription"
            inline constexpr std::uintptr_t Inventory = 0x38; // "QuickSlotDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Enum = 0x43ED2C0; // "public static ReadOnlyEnum<QuickSlotDescription> get_Enum()"
            inline constexpr std::uintptr_t get_PocketSlot = 0x43ED4A0; // "public PocketSlotDescription get_PocketSlot()"
        }
    } // namespace QuickSlotDescription

    namespace QuickSlotItemView { // "Game.Battle.Inventory.QuickSlotItemView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t InventoryItemRareView = 0x20; // "InventoryItemRareView"
            inline constexpr std::uintptr_t InventorySlotView = 0x28; // "InventoryIconView"
            inline constexpr std::uintptr_t brokenView = 0x30; // "InventoryItemDurabilityView"
            inline constexpr std::uintptr_t state = 0x38; // "StateGroup"
            inline constexpr std::uintptr_t progress = 0x40; // "Image"
            inline constexpr std::uintptr_t progressRectTransform = 0x48; // "RectTransform"
            inline constexpr std::uintptr_t selectedState = 0x50; // "StateElementBase"
            inline constexpr std::uintptr_t emptyIcon = 0x58; // "ImageExtend"
            inline constexpr std::uintptr_t lockIcon = 0x60; // "ImageExtend"
            inline constexpr std::uintptr_t lockEnabled = 0x68; // "Nullable<bool>"
            inline constexpr std::uintptr_t emptyEnabled = 0x6A; // "Nullable<bool>"
            inline constexpr std::uintptr_t isBroken = 0x6C; // "bool"
            inline constexpr std::uintptr_t IsSelected = 0x6D; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Awake = 0xA69A70; // "private void Awake()"
            inline constexpr std::uintptr_t SetProgress = 0xA69AC0; // "public void SetProgress(float progress)"
            inline constexpr std::uintptr_t SetBroken = 0xA69A80; // "public void SetBroken(bool value)"
            inline constexpr std::uintptr_t SetSelected = 0xA69B50; // "public void SetSelected(bool value)"
            inline constexpr std::uintptr_t UpdateColor = 0xA69B60; // "private void UpdateColor()"
            inline constexpr std::uintptr_t SetIcon = 0xA69AA0; // "public void SetIcon()"
            inline constexpr std::uintptr_t SetEmpty = 0xA69A90; // "public void SetEmpty()"
            inline constexpr std::uintptr_t SetLock = 0xA69AB0; // "public void SetLock()"
            inline constexpr std::uintptr_t UpdateIcons = 0xA69C90; // "private void UpdateIcons(bool lockEnabled, bool emptyEnabled)"
        }
    } // namespace QuickSlotItemView

    namespace QuickSlotSelectedUpdater { // "Game.Battle.Inventory.QuickSlotSelectedUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t quickSlotDescription = 0x10; // "QuickSlotDescription"
            inline constexpr std::uintptr_t itemModel = 0x18; // "IInventoryItemModel"
            inline constexpr std::uintptr_t selectedQuickSlotModel = 0x20; // "SelectedQuickSlotModel"
            inline constexpr std::uintptr_t lastQuickSlotModel = 0x28; // "LastQuickSlotModel"
            inline constexpr std::uintptr_t durabilityModel = 0x30; // "IDurabilityModel"
            inline constexpr std::uintptr_t view = 0x38; // "IItemSelectedView"
            inline constexpr std::uintptr_t inventoryProgressItemModel = 0x40; // "InventoryProgressItemModel"
            inline constexpr std::uintptr_t itemMoveContext = 0x48; // "IItemMoveContext"
            inline constexpr std::uintptr_t isSelected = 0x50; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA05BD0; // "public void Update()"
        }
    } // namespace QuickSlotSelectedUpdater

    namespace QuickSlotSelectProgressModel { // "Models.Models.QuickSlotSelectProgress.QuickSlotSelectProgressModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ts = 0x10; // "IPrimitiveData<long>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_EndTs = 0x48D7C30; // "public long get_EndTs()"
            inline constexpr std::uintptr_t set_EndTs = 0x48D7D00; // "public void set_EndTs(long value)"
            inline constexpr std::uintptr_t get_IsInProcess = 0x48D7C80; // "public bool get_IsInProcess()"
        }
    } // namespace QuickSlotSelectProgressModel

    namespace QuickSlotsModel { // "Models.Models.QuickSlots.QuickSlotsModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t equipSlots = 0x10; // "IEquipSlotsModel"
            inline constexpr std::uintptr_t pockets = 0x18; // "IPocketsModel"
            inline constexpr std::uintptr_t contextMenuUseItemModel = 0x20; // "ContextMenuUseItemModel"
            inline constexpr std::uintptr_t inventoryModel = 0x28; // "IInventoryModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t TryGetItemModel = 0x48D7D60; // "public bool TryGetItemModel(QuickSlotDescription slot, out IInventoryItemModel itemModel)"
        }
    } // namespace QuickSlotsModel

    namespace QuickSlotsUtils { // "Models.Models.QuickSlots.QuickSlotsUtils (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t IsQuickSlotEquipDelayActive = 0x48D7FC0; // "public static bool IsQuickSlotEquipDelayActive(long now, QuickSlotDescription quickSlotDescription, EquipSlotsDelaysModel equipSlotsDelays)"
            inline constexpr std::uintptr_t TryGetEquipSlotByQuickSlot = 0x48D8030; // "private static bool TryGetEquipSlotByQuickSlot(QuickSlotDescription quickSlotDescription, out EquipSlotDescription equipSlotDescription)"
        }
    } // namespace QuickSlotsUtils

    namespace QuickSlotUsingProgressUpdater { // "Game.Battle.Inventory.QuickSlotUsingProgressUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t itemMoveContext = 0x10; // "IItemMoveContext"
            inline constexpr std::uintptr_t quickSlotItemView = 0x18; // "QuickSlotItemView"
            inline constexpr std::uintptr_t inventoryProgressItemModel = 0x20; // "InventoryProgressItemModel"
            inline constexpr std::uintptr_t quickSlotDescription = 0x28; // "QuickSlotDescription"
            inline constexpr std::uintptr_t lastProgress = 0x30; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA05DE0; // "public void Update()"
        }
    } // namespace QuickSlotUsingProgressUpdater

    namespace RandomLootEntityModel { // "Game.Battle.Entities.Building.Models.RandomLootEntityModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ServerModel = 0x18; // "RandomLootObjectModel"
        }
    } // namespace RandomLootEntityModel

    namespace RandomLootObjectData { // "Models.Data.RandomLootObjectData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Item = 0x20; // "IPrimitiveData<LootObjectItemDescription>"
            inline constexpr std::uintptr_t IsTaken = 0x28; // "IPrimitiveData<bool>"
        }
    } // namespace RandomLootObjectData

    namespace RandomLootObjectDescription { // "Models.References.LootObject.RandomLootObjectDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t EntityId = 0x20; // "int"
            inline constexpr std::uintptr_t Position = 0x24; // "Vector3"
            inline constexpr std::uintptr_t Orientation = 0x30; // "Quaternion"
            inline constexpr std::uintptr_t InteractPoint = 0x40; // "Vector3"
            inline constexpr std::uintptr_t InteractIgnoreStaticBodies = 0x50; // "HashSet<PhysicsBodyId>"
            inline constexpr std::uintptr_t InteractDescription = 0x58; // "InteractDescription"
            inline constexpr std::uintptr_t SecurityAlarmDescriptionFunc = 0x60; // "Func<LocationSecurityAlarmDescription>"
            inline constexpr std::uintptr_t AvailableForUseRolesLazy = 0x68; // "Lazy<HashSet<PlayerRoleDescription>>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_SecurityAlarmDescription = 0x4048EC0; // "public LocationSecurityAlarmDescription get_SecurityAlarmDescription()"
            inline constexpr std::uintptr_t get_AvailableForUseRoles = 0x40C6F10; // "public HashSet<PlayerRoleDescription> get_AvailableForUseRoles()"
            inline constexpr std::uintptr_t New = 0x40C6BF0; // "public static RandomLootObjectDescription New(string id, int index, int entityId, Vector3 position, Quaternion orientation, Vector3 interactPoint, HashSet<PhysicsBodyId> interactIgnoreStaticBodies, InteractDescription interactDescription, LocationSecurityAlarmDescription securityAlarmDescription, HashSet<PlayerRoleDescription> availableForUseRoles)"
        }
    } // namespace RandomLootObjectDescription

    namespace RandomLootObjectItemsData { // "Models.Data.RandomLootObjectItemsData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsFilled = 0x20; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t Buildings = 0x28; // "BuildingsRandomLootObjectItemsData"
        }
    } // namespace RandomLootObjectItemsData

    namespace RandomLootObjectModel { // "Models.Models.LootObjectModel.Random.RandomLootObjectModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t item = 0x18; // "IPrimitiveData<LootObjectItemDescription>"
            inline constexpr std::uintptr_t Description = 0x20; // "RandomLootObjectDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Reset = 0x49483B0; // "public override void Reset()"
            inline constexpr std::uintptr_t get_IsEmpty = 0x4948520; // "public bool get_IsEmpty()"
            inline constexpr std::uintptr_t get_Item = 0x4948570; // "public override LootObjectItemDescription get_Item()"
            inline constexpr std::uintptr_t SetItem = 0x4948440; // "public void SetItem(LootObjectItemDescription item)"
        }
    } // namespace RandomLootObjectModel

    namespace RefillEquipBoxAnimationUpdater { // "Game.Battle.Entities.Building.RefillAmmo.RefillEquipBoxAnimationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t interactableObjectOpenedModel = 0x10; // "InteractableObjectOpenedModel"
            inline constexpr std::uintptr_t refillAmmoView = 0x18; // "RefillAmmoView"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xBCF140; // "public void Update()"
            inline constexpr std::uintptr_t Stop = 0x7B3360; // "public void Stop()"
        }
    } // namespace RefillEquipBoxAnimationUpdater

    namespace RefillEquipExtensions { // "Models.Utils.Extensions.RefillEquipExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t TryGetInteractableObject = 0x396B530; // "public static bool TryGetInteractableObject(int entityId, ReadOnly.Dictionary<int, VehicleModel> vehicles, ReadOnly.Dictionary<int, CopEquipBoxModel> copEquipBoxes, ReadOnly.Dictionary<int, BreachEntityModel> breachEntities, out InteractableObjectOpenedModel interactableObject)"
            inline constexpr std::uintptr_t TryGetInteractEntityId = 0x396B2A0; // "public static bool TryGetInteractEntityId(int entityId, ReadOnly.Dictionary<int, VehicleModel> vehicles, ReadOnly.Dictionary<int, CopEquipBoxModel> copEquipBoxes, ReadOnly.Dictionary<int, BreachEntityModel> breachEntities, out int interactEntityId)"
            inline constexpr std::uintptr_t TryGetInteractableObjectForCleanup = 0x396B420; // "public static bool TryGetInteractableObjectForCleanup(int entityId, ReadOnly.Dictionary<int, VehicleModel> vehicles, ReadOnly.Dictionary<int, CopEquipBoxModel> copEquipBoxes, out InteractableObjectOpenedModel interactableObject)"
        }
    } // namespace RefillEquipExtensions

    namespace RefillEquipModel { // "Models.Models.ProlongedInteractionHandler.Handlers.RefillEquipModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t vehicles = 0x10; // "ReadOnly.Dictionary<int, VehicleModel>"
            inline constexpr std::uintptr_t copEquipBoxes = 0x18; // "ReadOnly.Dictionary<int, CopEquipBoxModel>"
            inline constexpr std::uintptr_t breachEntities = 0x20; // "ReadOnly.Dictionary<int, BreachEntityModel>"
            inline constexpr std::uintptr_t interactEntities = 0x28; // "ReadOnly.Dictionary<int, IInteractEntityModel>"
            inline constexpr std::uintptr_t worldInterruptModel = 0x30; // "IWorldInterruptModel"
            inline constexpr std::uintptr_t isServer = 0x38; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Process = 0x48FF2B0; // "public override MutuallyExclusiveProcessesDescription get_Process()"
            inline constexpr std::uintptr_t get_StartCommand = 0x48FF340; // "internal override UseEntityCommandDescription get_StartCommand()"
            inline constexpr std::uintptr_t get_StopCommand = 0x48FF3D0; // "internal override UseEntityCommandDescription get_StopCommand()"
            inline constexpr std::uintptr_t CheckInteractionStart = 0x48FEA30; // "public override bool CheckInteractionStart(UseEntityCommandDescription command, int useEntityId, PlayerRoleDescription playerRole)"
            inline constexpr std::uintptr_t HandelRequest = 0x48FEB00; // "public override void HandelRequest(long now, int entityId, ProlongedInteractionInputDescription prolongedInteractionInput, BattleCharacterModel characterModel)"
            inline constexpr std::uintptr_t TryFinishPrediction = 0x48FEEC0; // "public override bool TryFinishPrediction(long now, BattleCharacterModel characterModel)"
            inline constexpr std::uintptr_t TryGetTargetPosition = 0x48FF200; // "public override bool TryGetTargetPosition(int entityId, out Vector3 position)"
            inline constexpr std::uintptr_t TryGetPosition = 0x48FF020; // "private bool TryGetPosition(int entityId, out Vector3 position)"
        }
    } // namespace RefillEquipModel

    namespace RefillEquipProlongedAction { // "Game.Battle.Entities.Player.ProlongedActions.RefillEquipProlongedAction (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "ProlongedInteractionModel"
            inline constexpr std::uintptr_t Label = 0x18; // "LocalizedString"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsActive = 0xB223E0; // "public bool get_IsActive()"
            inline constexpr std::uintptr_t get_EndTs = 0xB19D10; // "public long get_EndTs()"
            inline constexpr std::uintptr_t get_Duration = 0xB22380; // "public long get_Duration()"
            inline constexpr std::uintptr_t Interrupt = 0xB222D0; // "public void Interrupt(BattleInputModel battleInputModel)"
        }
    } // namespace RefillEquipProlongedAction

    namespace ResetDialogByDistanceUpdater { // "Game.Battle.Inventory.ResetDialogByDistanceUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t characterPositionModel = 0x20; // "IPositionModel"
            inline constexpr std::uintptr_t targetPositionModel = 0x28; // "IPositionModel"
            inline constexpr std::uintptr_t screenModel = 0x30; // "IScreenModel"
            inline constexpr std::uintptr_t sqrDistance = 0x38; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA060B0; // "public ResetDialogByDistanceUpdater Init(BattleCharacterModel characterModel, IScreenModel screenModel, Vector3 position, float sqrDistance)"
            inline constexpr std::uintptr_t Init_2 = 0xA06190; // "public ResetDialogByDistanceUpdater Init(BattleCharacterModel characterModel, IScreenModel screenModel, IPositionModel positionModel, float sqrDistance)"
            inline constexpr std::uintptr_t Dispose = 0x9F6DA0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA06210; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace ResetDialogByDistanceUpdater

    namespace ResetDialogByRaidLockUpdater { // "Game.Battle.Inventory.ResetDialogByRaidLockUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t inventoryDialogModel = 0x20; // "InventoryDialogModel"
            inline constexpr std::uintptr_t now = 0x28; // "INow"
            inline constexpr std::uintptr_t defenseBlockPublicModel = 0x30; // "DefenseBlockPublicModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA06360; // "public ResetDialogByRaidLockUpdater Init(InventoryDialogModel inventoryDialogModel, DefenseBlockPublicModel defenseBlockPublicModel, INow now)"
            inline constexpr std::uintptr_t Dispose = 0x9F6DA0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA063C0; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace ResetDialogByRaidLockUpdater

    namespace ResetDialogByRaycastUpdater { // "Game.Battle.Inventory.ResetDialogByRaycastUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t characterModel = 0x20; // "BattleCharacterModel"
            inline constexpr std::uintptr_t screenModel = 0x28; // "IScreenModel"
            inline constexpr std::uintptr_t interactRaycastModel = 0x30; // "InteractRaycastModel"
            inline constexpr std::uintptr_t entityId = 0x38; // "int"
            inline constexpr std::uintptr_t worldEntitiesModel = 0x40; // "WorldEntitiesModel"
            inline constexpr std::uintptr_t now = 0x48; // "INow"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA064E0; // "public ResetDialogByRaycastUpdater Init(BattleCharacterModel characterModel, IScreenModel screenModel, InteractRaycastModel interactRaycastModel, int entityId, WorldEntitiesModel worldEntitiesModel, INow now)"
            inline constexpr std::uintptr_t Dispose = 0xA06470; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA06570; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace ResetDialogByRaycastUpdater

    namespace ResetDialogByRemoveEntityUpdater { // "Game.Battle.Inventory.ResetDialogByRemoveEntityUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t menuModel = 0x10; // "PlayerContextMenuModel"
            inline constexpr std::uintptr_t slotsModel = 0x18; // "ClientCharacterSlotsModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA06640; // "public void Update()"
        }
    } // namespace ResetDialogByRemoveEntityUpdater

    namespace ResetLaptopDialogByExitTeamUpdater { // "Game.Battle.Inventory.ResetLaptopDialogByExitTeamUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t partyMemberAccessModel = 0x10; // "IPartyMemberAccessModel"
            inline constexpr std::uintptr_t screenModel = 0x18; // "IScreenModel"
            inline constexpr std::uintptr_t characterPublicId = 0x20; // "long"
            inline constexpr std::uintptr_t traderPublicId = 0x28; // "long"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA69DC0; // "public void Update()"
        }
    } // namespace ResetLaptopDialogByExitTeamUpdater

    namespace RestoreArmorDescription { // "Models.References.Inventory.RestoreArmorDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t SegmentsCount = 0x20; // "int"
        }
    } // namespace RestoreArmorDescription

    namespace RestrictedCellsModel { // "Game.Battle.Inventory.RestrictedCells.RestrictedCellsModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t inventoryRestrictedSlots = 0x10; // "Dictionary<IInventorySlotModel, bool>"
            inline constexpr std::uintptr_t equipRestrictedSlots = 0x18; // "Dictionary<IEquipSlotModel, bool>"
            inline constexpr std::uintptr_t pocketRestrictedSlots = 0x20; // "Dictionary<IPocketSlotModel, bool>"
            inline constexpr std::uintptr_t InventoryRestrictedSlots = 0x28; // "ReadOnlyDictionaryNonAlloc<IInventorySlotModel, bool>"
            inline constexpr std::uintptr_t EquipRestrictedSlots = 0x30; // "ReadOnlyDictionaryNonAlloc<IEquipSlotModel, bool>"
            inline constexpr std::uintptr_t PocketRestrictedSlots = 0x38; // "ReadOnlyDictionaryNonAlloc<IPocketSlotModel, bool>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetInventorySlot = 0xA6AA70; // "public void SetInventorySlot(IInventorySlotModel inventorySlotModel, bool isActive)"
            inline constexpr std::uintptr_t SetEquipSlot = 0xA6AA00; // "public void SetEquipSlot(IEquipSlotModel inventorySlotModel, bool isActive)"
            inline constexpr std::uintptr_t SetPocketSlot = 0xA6AAE0; // "public void SetPocketSlot(IPocketSlotModel inventorySlotModel, bool isActive)"
            inline constexpr std::uintptr_t Clear = 0xA6A970; // "public void Clear()"
            inline constexpr std::uintptr_t SetSlot_T_inst_1 = 0x117E260; // "RestrictedCellsModel.SetSlot<object>"
            inline constexpr std::uintptr_t SetSlot_T_inst_2 = 0x117E170; // "RestrictedCellsModel.SetSlot<__Il2CppFullySharedGenericType>"
        }
    } // namespace RestrictedCellsModel

    namespace RestrictedCellsModelUpdater { // "Game.Battle.Inventory.RestrictedCells.RestrictedCellsModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleCharacterModel = 0x20; // "BattleCharacterModel"
            inline constexpr std::uintptr_t restrictedCellsModel = 0x28; // "RestrictedCellsModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t InitBase = 0xA69F40; // "protected void InitBase(BattleCharacterModel battleCharacterModel, RestrictedCellsModel restrictedCellsModel)"
            inline constexpr std::uintptr_t Dispose = 0x92B5C0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA69F80; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace RestrictedCellsModelUpdater

    namespace RevealContainerModel { // "Game.Global.Inventory.Reveal.Models.RevealContainerModel (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t snapshot = 0x10; // "Dictionary<int, string>"
            inline constexpr std::uintptr_t Slot = 0x18; // "int"
            inline constexpr std::uintptr_t RevealingCount = 0x1C; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Item = 0x35BBE20; // "public string get_Item(int key)"
            inline constexpr std::uintptr_t set_Item = 0x35BBE80; // "public void set_Item(int key, string value)"
            inline constexpr std::uintptr_t IncrementSlot = 0x35BBD70; // "public void IncrementSlot()"
            inline constexpr std::uintptr_t ContainsKey = 0x35BBC90; // "public bool ContainsKey(int key)"
            inline constexpr std::uintptr_t Remove = 0x35BBDC0; // "public bool Remove(int key)"
            inline constexpr std::uintptr_t Clear = 0x35BBC40; // "public void Clear()"
            inline constexpr std::uintptr_t GetEnumerator = 0x35BBCF0; // "public Dictionary.Enumerator<int, string> GetEnumerator()"
        }
    } // namespace RevealContainerModel

    namespace RobberInventoryCostModel { // "Models.Models.RobberInventoryCost.RobberInventoryCostModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t CharacterInventory = 0x10; // "int"
            inline constexpr std::uintptr_t VehicleInventory = 0x14; // "int"
            inline constexpr std::uintptr_t CharacterEquip = 0x18; // "int"
            inline constexpr std::uintptr_t CharacterInventoryCash = 0x1C; // "int"
            inline constexpr std::uintptr_t CharacterInventoryItems = 0x20; // "int"
            inline constexpr std::uintptr_t VehicleInventoryCash = 0x24; // "int"
            inline constexpr std::uintptr_t VehicleInventoryItems = 0x28; // "int"
        }
    } // namespace RobberInventoryCostModel

    namespace RouletteBarterModel { // "Game.Battle.Entities.Roulette.RouletteBarter.RouletteBarterModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Scroller = 0x10; // "RecipeScrollerModel"
            inline constexpr std::uintptr_t ItemsForTooltipModel = 0x18; // "PointerButtonsItemModel"
            inline constexpr std::uintptr_t RecipeRectTransforms = 0x20; // "List<RectTransform>"
            inline constexpr std::uintptr_t Views = 0x28; // "List<PointerButtonView>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t GetSelectedChipDescription = 0xAF60D0; // "public RouletteChipDescription GetSelectedChipDescription()"
            inline constexpr std::uintptr_t get_RecipeCount = 0xAF6330; // "public int get_RecipeCount()"
            inline constexpr std::uintptr_t GetChipByIndex = 0xAF5FA0; // "public RouletteChipDescription GetChipByIndex(int index)"
        }
    } // namespace RouletteBarterModel

    namespace RouletteBarterUpdater { // "Game.Battle.EntityModel.Roulette.RouletteBarter.RouletteBarterUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t updaters = 0x20; // "List<IUpdater>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xC09150; // "public RouletteBarterUpdater Init(TabData<RouletteInventoryDialogView.RouletteTab> currentTab, GlobalModel globalModel, PlayerClientModel playerClientModel, IInventoryModel playerInventory, RouletteBarterModel barterModel, PooledLoadedComponentContent<RouletteRecipeView> recipeTemplate, RouletteInventoryDialogView dialogView, GlobalScreenContent globalScreenContent, UpdaterPool updaterPool, IRegisterDisposable registerDisposable)"
            inline constexpr std::uintptr_t Dispose = 0xC090F0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0x94CF50; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace RouletteBarterUpdater

    namespace RouletteInventoryCurrentTabStateUpdater { // "Game.Battle.Entities.Roulette.RouletteInventoryDialog.RouletteInventoryCurrentTabStateUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t barterModel = 0x20; // "RouletteBarterModel"
            inline constexpr std::uintptr_t currentTab = 0x28; // "TabData<RouletteInventoryDialogView.RouletteTab>"
            inline constexpr std::uintptr_t characterRouletteReward = 0x30; // "CharacterRouletteRewardModel"
            inline constexpr std::uintptr_t dialogView = 0x38; // "RouletteInventoryDialogView"
            inline constexpr std::uintptr_t mainInputUpdaters = 0x40; // "List<IUpdater>"
            inline constexpr std::uintptr_t inventoryInputUpdater = 0x48; // "RouletteInventoryDialogInputUpdater"
            inline constexpr std::uintptr_t barterInputUpdater = 0x50; // "RouletteBarterInputUpdater"
            inline constexpr std::uintptr_t state = 0x58; // "RouletteInventoryDialogView.RouletteTab"
            inline constexpr std::uintptr_t wasReward = 0x5C; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xAF63C0; // "public RouletteInventoryCurrentTabStateUpdater Init(RouletteBarterModel barterModel, TabData<RouletteInventoryDialogView.RouletteTab> currentTab, CharacterRouletteRewardModel characterRouletteReward, RouletteInventoryDialogView dialogView, List<IUpdater> mainInputUpdaters, RouletteInventoryDialogInputUpdater inventoryInputUpdater, RouletteBarterInputUpdater barterInputUpdater)"
            inline constexpr std::uintptr_t Dispose = 0x9ED4D0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xAF6480; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t UpdateState = 0xAF6530; // "private void UpdateState()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace RouletteInventoryCurrentTabStateUpdater

    namespace RouletteInventoryNotificationTabUpdater { // "Game.Battle.Entities.Roulette.RouletteInventoryDialog.RouletteInventoryNotificationTabUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x20; // "CharacterRouletteRewardModel"
            inline constexpr std::uintptr_t currentTab = 0x28; // "TabData<RouletteInventoryDialogView.RouletteTab>"
            inline constexpr std::uintptr_t view = 0x30; // "NewContentIndicatorView"
            inline constexpr std::uintptr_t isVisible = 0x38; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xAF8890; // "public RouletteInventoryNotificationTabUpdater Init(CharacterRouletteRewardModel model, TabData<RouletteInventoryDialogView.RouletteTab> currentTab, NewContentIndicatorView view)"
            inline constexpr std::uintptr_t Dispose = 0x9F6DA0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xAF8910; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace RouletteInventoryNotificationTabUpdater

    namespace RouletteRecipeUpdater { // "Game.Battle.Entities.Roulette.RouletteBarter.RouletteRecipeUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t recipeView = 0x20; // "RouletteRecipeView"
            inline constexpr std::uintptr_t recipeScrollModel = 0x28; // "RecipeScrollerModel"
            inline constexpr std::uintptr_t playerInventory = 0x30; // "IInventoryModel"
            inline constexpr std::uintptr_t currentTab = 0x38; // "TabData<RouletteInventoryDialogView.RouletteTab>"
            inline constexpr std::uintptr_t chipDescription = 0x40; // "RouletteChipDescription"
            inline constexpr std::uintptr_t recipeIndex = 0x48; // "int"
            inline constexpr std::uintptr_t cashItem = 0x50; // "InventoryItemDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xAF8A20; // "public RouletteRecipeUpdater Init(RecipeScrollerModel recipeScrollModel, IInventoryModel playerInventory, TabData<RouletteInventoryDialogView.RouletteTab> currentTab, RouletteChipDescription chipDescription, int recipeIndex, RouletteRecipeView view, PointerButtonsItemModel itemsForTooltip, InventoryItemViewDescriptions inventoryItemViewDescription)"
            inline constexpr std::uintptr_t Dispose = 0xAF89A0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xAF8F10; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace RouletteRecipeUpdater

    namespace ScrollableItemsModel { // "Game.Battle.Inventory.ScrollableItemsModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t items = 0x10; // "Dictionary<IItemMoveContext, ValueTuple<ScrollRect, float>>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Add = 0xA26BA0; // "public void Add(IItemMoveContext model, ScrollRect scroll, float scrollSector)"
            inline constexpr std::uintptr_t Remove = 0xA26C50; // "public void Remove(IItemMoveContext model)"
            inline constexpr std::uintptr_t TryGetValue = 0xA26CB0; // "public bool TryGetValue(IItemMoveContext model, out ValueTuple<ScrollRect, float> item)"
        }
    } // namespace ScrollableItemsModel

    namespace ScrollableItemsSlotUpdater { // "Game.Battle.Inventory.ScrollableItemsSlotUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t scrollableItemsModel = 0x20; // "ScrollableItemsModel"
            inline constexpr std::uintptr_t scrollRect = 0x28; // "ScrollRect"
            inline constexpr std::uintptr_t itemMoveContext = 0x30; // "IItemMoveContext"
            inline constexpr std::uintptr_t slotModel = 0x38; // "IInventorySlotModel"
            inline constexpr std::uintptr_t scrollSector = 0x40; // "float"
            inline constexpr std::uintptr_t isEmpty = 0x44; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA06B40; // "public ScrollableItemsSlotUpdater Init(BattleModel battleModel, ScrollRect scrollRect, IItemMoveContext itemMoveContext, IInventorySlotModel slotModel, float scrollSector)"
            inline constexpr std::uintptr_t Dispose = 0xA06AD0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA06BE0; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace ScrollableItemsSlotUpdater

    namespace ScrolledCellsUiView { // "Game.Battle.Inventory.ScrolledCellsUiView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ScrollRect = 0x20; // "ScrollRect"
            inline constexpr std::uintptr_t scrollToSlotViewport = 0x28; // "RectTransform"
            inline constexpr std::uintptr_t unlocked = 0x30; // "RectTransform"
            inline constexpr std::uintptr_t takeOnly = 0x38; // "RectTransform"
            inline constexpr std::uintptr_t locked = 0x40; // "RectTransform"
            inline constexpr std::uintptr_t tierHeadersParent = 0x48; // "GameObject"
            inline constexpr std::uintptr_t TraderTierHeaderViews = 0x50; // "List<TraderCategoryHeaderView>"
            inline constexpr std::uintptr_t TraderTierGrids = 0x58; // "List<RectTransform>"
            inline constexpr std::uintptr_t ItemParent = 0x60; // "Transform"
            inline constexpr std::uintptr_t FrameParent = 0x68; // "Transform"
            inline constexpr std::uintptr_t RevealParent = 0x70; // "Transform"
            inline constexpr std::uintptr_t CellSize = 0x78; // "float"
            inline constexpr std::uintptr_t CellPadding = 0x7C; // "Vector2"
            inline constexpr std::uintptr_t TierVerticalPadding = 0x84; // "float"
            inline constexpr std::uintptr_t TierHeaderVerticalPadding = 0x88; // "float"
            inline constexpr std::uintptr_t DropAreaView = 0x90; // "DropAreaView"
            inline constexpr std::uintptr_t DragShadowView = 0x98; // "DragShadowView"
            inline constexpr std::uintptr_t InventoryProgressView = 0xA0; // "InventoryProgressView"
            inline constexpr std::uintptr_t AreaTransform = 0xA8; // "RectTransform"
            inline constexpr std::uintptr_t ContentRect = 0xB0; // "Vector2"
            inline constexpr std::uintptr_t scrollRect = 0xB8; // "RectTransform"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_ScrollToSlotViewport = 0xA07C30; // "public RectTransform get_ScrollToSlotViewport()"
            inline constexpr std::uintptr_t get_GetScrollRect = 0xA07B80; // "private RectTransform get_GetScrollRect()"
            inline constexpr std::uintptr_t ShowLines = 0xA07A10; // "public void ShowLines(bool show)"
            inline constexpr std::uintptr_t SetActiveTiersView = 0xA07350; // "public void SetActiveTiersView(bool active)"
            inline constexpr std::uintptr_t ActivateNextGroupGrid = 0xA06CE0; // "public void ActivateNextGroupGrid(int groupIndex, int startLine, int lineCount)"
            inline constexpr std::uintptr_t ActivateNextGroupHeader = 0xA06F30; // "public void ActivateNextGroupHeader(int groupIndex, int startLine, LocalizedString title, bool locked)"
            inline constexpr std::uintptr_t SetLinesCount = 0xA07670; // "public void SetLinesCount(int unlockedValue, int takeOnlyValue)"
            inline constexpr std::uintptr_t SetAreaSizeShowLinesWithCategory = 0xA074A0; // "public void SetAreaSizeShowLinesWithCategory(int showLines, int categoryInex)"
            inline constexpr std::uintptr_t ResetScrollRect = 0x9F1EA0; // "public void ResetScrollRect()"
            inline constexpr std::uintptr_t ForceRebindToScrollbar = 0xA07160; // "private void ForceRebindToScrollbar(bool enableScrollbarAfter)"
            inline constexpr std::uintptr_t GetMaxVisibleLines = 0xA071D0; // "private int GetMaxVisibleLines()"
        }
    } // namespace ScrolledCellsUiView

    namespace ScrollToInventorySlotUpdater { // "Game.Battle.Inventory.ScrollToInventorySlotUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleModel = 0x20; // "BattleModel"
            inline constexpr std::uintptr_t model = 0x28; // "IInventoryItemModel"
            inline constexpr std::uintptr_t viewRectTransform = 0x30; // "RectTransform"
            inline constexpr std::uintptr_t scrollRect = 0x38; // "ScrollRect"
            inline constexpr std::uintptr_t viewportRect = 0x40; // "RectTransform"
            inline constexpr std::uintptr_t inventoryEntityId = 0x48; // "int"
            inline constexpr std::uintptr_t currentDescription = 0x50; // "InventoryItemDescription"
            inline constexpr std::uintptr_t blockedEntitiesModel = 0x58; // "BlockedEntitiesModel"
            inline constexpr std::uintptr_t init = 0x60; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA6AE70; // "public ScrollToInventorySlotUpdater Init(BattleModel battleModel, IInventoryItemModel model, RectTransform viewRectTransform, ScrollRect scrollRect, RectTransform scrollViewport, int inventoryEntityId, bool init)"
            inline constexpr std::uintptr_t Dispose = 0xA6AE00; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA6AF80; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace ScrollToInventorySlotUpdater

    namespace SectorCenterRestrictedCellsViewUpdater { // "Game.Battle.Inventory.RestrictedCells.SectorCenterRestrictedCellsViewUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t player = 0x20; // "BattleCharacterModel"
            inline constexpr std::uintptr_t dragAndDropModel = 0x28; // "InventoryDragAndDropModel"
            inline constexpr std::uintptr_t sectorDescription = 0x30; // "SectorDescription"
            inline constexpr std::uintptr_t view = 0x38; // "InventoryDropMessageView"
            inline constexpr std::uintptr_t isActive = 0x40; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0x9F4C50; // "public SectorCenterRestrictedCellsViewUpdater Init(BattleCharacterModel player, InventoryDragAndDropModel dragModel, SectorDescription sector, InventoryDropMessageView view)"
            inline constexpr std::uintptr_t OnUpdate = 0xA6B1B0; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Dispose = 0xA6B0E0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace SectorCenterRestrictedCellsViewUpdater

    namespace SelectedCargoModel { // "Game.Battle.Trunk.Cargo.SelectedCargoModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Cargo = 0x10; // "CargoDescription"
            inline constexpr std::uintptr_t Size = 0x18; // "Vector2"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetCargo = 0xD8C8A0; // "public void SetCargo(CargoDescription cargo, Vector2 size)"
            inline constexpr std::uintptr_t Clear = 0xD8C840; // "public void Clear()"
        }
    } // namespace SelectedCargoModel

    namespace SelectedQuickSlotModel { // "Models.Models.SelectedQuickSlot.SelectedQuickSlotModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t selectedQuickSlot = 0x10; // "IPrimitiveData<QuickSlotDescription>"
            inline constexpr std::uintptr_t ItemChanged = 0x18; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Slot = 0x48E7140; // "public QuickSlotDescription get_Slot()"
            inline constexpr std::uintptr_t set_Slot = 0x48E7200; // "public void set_Slot(QuickSlotDescription value)"
        }
    } // namespace SelectedQuickSlotModel

    namespace SelectQuickSlotSystem { // "Models.Systems.SelectQuickSlotSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dropCargoModel = 0x38; // "IDropCargoModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x43609C0; // "protected override void Tick(ITick tick)"
            inline constexpr std::uintptr_t GetTakeInTime = 0x43607C0; // "private long GetTakeInTime(InventoryItemDescription item)"
            inline constexpr std::uintptr_t GetSlotItem = 0x4360730; // "private InventoryItemDescription GetSlotItem(QuickSlotDescription slot, QuickSlotsModel quickSlots)"
            inline constexpr std::uintptr_t GetWeaponSkin = 0x4360880; // "private WeaponSkinDescription GetWeaponSkin(QuickSlotDescription slot, WeaponSkinsModel weaponSkinsModel, IEquipSlotsModel equipSlotsModel)"
        }
    } // namespace SelectQuickSlotSystem

    namespace SetInventoryItemCheatMessage { // "Models.Messages.Inventory.SetInventoryItemCheatMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t slotSource = 0x20; // "IPrimitiveData<SlotSourceDescription>"
            inline constexpr std::uintptr_t inventorySlot = 0x28; // "IPrimitiveData<InventorySlotDescription>"
            inline constexpr std::uintptr_t equipSlot = 0x30; // "IPrimitiveData<EquipSlotDescription>"
            inline constexpr std::uintptr_t pocketSlot = 0x38; // "IPrimitiveData<PocketSlotDescription>"
            inline constexpr std::uintptr_t item = 0x40; // "IPrimitiveData<InventoryItemDescription>"
            inline constexpr std::uintptr_t count = 0x48; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t ammo = 0x50; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t durability = 0x58; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t cumulativePoints = 0x60; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t entityId = 0x68; // "IPrimitiveData<int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x4A2F7E0; // "public override string get_Type()"
            inline constexpr std::uintptr_t get_SlotSource = 0x4A2F790; // "public SlotSourceDescription get_SlotSource()"
            inline constexpr std::uintptr_t get_InventorySlot = 0x4A2F6A0; // "public InventorySlotDescription get_InventorySlot()"
            inline constexpr std::uintptr_t get_EquipSlot = 0x4A2F650; // "public EquipSlotDescription get_EquipSlot()"
            inline constexpr std::uintptr_t get_PocketSlot = 0x4A2F740; // "public PocketSlotDescription get_PocketSlot()"
            inline constexpr std::uintptr_t get_Item = 0x4A2F6F0; // "public InventoryItemDescription get_Item()"
            inline constexpr std::uintptr_t get_Count = 0x4A2F510; // "public int get_Count()"
            inline constexpr std::uintptr_t get_Ammo = 0x4A2F4C0; // "public int get_Ammo()"
            inline constexpr std::uintptr_t get_Durability = 0x4A2F5B0; // "public int get_Durability()"
            inline constexpr std::uintptr_t get_CumulativePoints = 0x4A2F560; // "public int get_CumulativePoints()"
            inline constexpr std::uintptr_t get_EntityId = 0x4A2F600; // "public int get_EntityId()"
        }
    } // namespace SetInventoryItemCheatMessage

    namespace ShelvingCargoInventoryModel { // "Models.Models.CargoInventory.ShelvingCargoInventoryModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t descriptionModel = 0x18; // "DescriptionModel<LocationShelvingDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_MaxSlotsCount = 0x4983690; // "public override int get_MaxSlotsCount()"
            inline constexpr std::uintptr_t get_SlotsCount = 0x4983690; // "public override int get_SlotsCount()"
            inline constexpr std::uintptr_t GetSlotsCount = 0x49835A0; // "private int GetSlotsCount()"
        }
    } // namespace ShelvingCargoInventoryModel

    namespace ShopSplitUpdater { // "Game.Battle.Inventory.ShopSplit.ShopSplitUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t laptopDirtyCashModel = 0x10; // "DirtyCashModel"
            inline constexpr std::uintptr_t modalDialogModel = 0x18; // "ModalDialogModel"
            inline constexpr std::uintptr_t splitModel = 0x20; // "ShopSplitModel"
            inline constexpr std::uintptr_t settlementBonusModel = 0x28; // "SettlementBonusModel"
            inline constexpr std::uintptr_t traderSplitSliderDialogRules = 0x30; // "TraderSplitSliderDialogRules"
            inline constexpr std::uintptr_t playerPublicId = 0x38; // "long"
            inline constexpr std::uintptr_t intention = 0x40; // "ShopSplitModel.Intentions"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA6B4D0; // "public void Update()"
            inline constexpr std::uintptr_t GetMaxCount = 0xA6B300; // "private int GetMaxCount()"
        }
    } // namespace ShopSplitUpdater

    namespace SlotBlockedView { // "Game.Battle.Inventory.SlotBlockedView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t iconCanvasGroup = 0x20; // "CanvasGroup"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetBlocked = 0xA6B890; // "public void SetBlocked(bool isBlocked)"
        }
    } // namespace SlotBlockedView

    namespace SlotDropInfoView { // "Game.Battle.Inventory.Slot.SlotDropInfoView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t transform = 0x20; // "RectTransform"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetSize = 0xA84580; // "public void SetSize(Vector2 value)"
            inline constexpr std::uintptr_t SetPosition = 0xA84530; // "public void SetPosition(Vector2 position)"
        }
    } // namespace SlotDropInfoView

    namespace SlotLockedView { // "Game.Battle.Inventory.Slot.SlotLockedView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t blackout = 0x20; // "GameObject"
            inline constexpr std::uintptr_t LockTypeState = 0x28; // "EnumStateElement<SlotLockedView.LockType>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetLocked = 0xA845F0; // "public void SetLocked(bool hasBlackout, SlotLockedView.LockType lockType)"
        }
    } // namespace SlotLockedView

    namespace SlotSourceDescription { // "Models.References.Inventory.SlotSourceDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x8254560; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t enum_id = 0x0; // "Enum<SlotSourceDescription>"
            inline constexpr std::uintptr_t Inventory = 0x8; // "SlotSourceDescription"
            inline constexpr std::uintptr_t Equip = 0x10; // "SlotSourceDescription"
            inline constexpr std::uintptr_t Pocket = 0x18; // "SlotSourceDescription"
            inline constexpr std::uintptr_t ExternalInventory = 0x20; // "SlotSourceDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Enum = 0x4401090; // "public static ReadOnlyEnum<SlotSourceDescription> get_Enum()"
        }
    } // namespace SlotSourceDescription

    namespace StartInventoryUseItemSystem { // "Models.Systems.StartInventoryUseItemSystem (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x4364390; // "protected override void Tick(ITick tick)"
            inline constexpr std::uintptr_t CheckUse = 0x4364110; // "private bool CheckUse(long now, InventoryUseItemInputInfo inputInfo, IInventoryModel inventory, IEquipSlotsModel equipSlots, IEquipAmmoModel equipAmmo, IPocketsModel pockets, IPrimitiveModel<PlayerRoleDescription> role, HealthModel health, UsableItemCooldownModel usableItemCooldownModel, out InventoryItemDescription sourceItem)"
            inline constexpr std::uintptr_t TryGetInventoryItem = 0x43649C0; // "private bool TryGetInventoryItem(InventorySlotDescription slotDescription, IInventoryModel inventory, out InventoryItemDescription itemDescription, out IAmmoModel ammo, out IDurabilityModel durability)"
            inline constexpr std::uintptr_t TryGetEquipItem = 0x43647A0; // "private bool TryGetEquipItem(EquipSlotDescription slotDescription, IEquipSlotsModel equipSlots, IEquipAmmoModel equipAmmo, out InventoryItemDescription itemDescription, out IAmmoModel ammo, out IDurabilityModel durability)"
            inline constexpr std::uintptr_t TryGetPocketItem = 0x4364C00; // "private bool TryGetPocketItem(PocketSlotDescription slotDescription, IPocketsModel pockets, out InventoryItemDescription itemDescription)"
        }
    } // namespace StartInventoryUseItemSystem

    namespace StaticLinesCountInventoryModel { // "Models.Models.InventoryModel.StaticLinesCountInventoryModel (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t get_LinesCount = 0x1F8C780; // "public override int get_LinesCount()"
        }
    } // namespace StaticLinesCountInventoryModel

    namespace StaticLootEntityModel { // "Game.Battle.Entities.Building.Models.StaticLootEntityModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ServerModel = 0x18; // "StaticLootObjectModel"
        }
    } // namespace StaticLootEntityModel

    namespace StaticLootObjectDescription { // "Models.References.LootObject.StaticLootObjectDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t EntityId = 0x20; // "int"
            inline constexpr std::uintptr_t LootObjectItemDescriptionFunc = 0x28; // "Func<LootObjectItemDescription>"
            inline constexpr std::uintptr_t Position = 0x30; // "Vector3"
            inline constexpr std::uintptr_t Orientation = 0x3C; // "Quaternion"
            inline constexpr std::uintptr_t InteractPoint = 0x4C; // "Vector3"
            inline constexpr std::uintptr_t InteractIgnoreStaticBodies = 0x58; // "HashSet<PhysicsBodyId>"
            inline constexpr std::uintptr_t InteractDescription = 0x60; // "InteractDescription"
            inline constexpr std::uintptr_t SecurityAlarmDescriptionFunc = 0x68; // "Func<LocationSecurityAlarmDescription>"
            inline constexpr std::uintptr_t AvailableForUseRolesLazy = 0x70; // "Lazy<HashSet<PlayerRoleDescription>>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_LootObjectItemDescription = 0x993E50; // "public LootObjectItemDescription get_LootObjectItemDescription()"
            inline constexpr std::uintptr_t get_SecurityAlarmDescription = 0x4048EF0; // "public LocationSecurityAlarmDescription get_SecurityAlarmDescription()"
            inline constexpr std::uintptr_t get_AvailableForUseRoles = 0x40C90D0; // "public HashSet<PlayerRoleDescription> get_AvailableForUseRoles()"
            inline constexpr std::uintptr_t New = 0x40C8D30; // "public static StaticLootObjectDescription New(string id, int index, int entityId, LootObjectItemDescription lootObjectItemDescription, Vector3 position, Quaternion orientation, Vector3 interactPoint, HashSet<PhysicsBodyId> interactIgnoreStaticBodies, InteractDescription interactDescription, LocationSecurityAlarmDescription securityAlarmDescription, HashSet<PlayerRoleDescription> availableForUseRoles)"
        }
    } // namespace StaticLootObjectDescription

    namespace StaticLootObjectModel { // "Models.Models.LootObjectModel.Static.StaticLootObjectModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Description = 0x18; // "StaticLootObjectDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Item = 0x4948860; // "public override LootObjectItemDescription get_Item()"
        }
    } // namespace StaticLootObjectModel

    namespace StaticSlotsCargoInventoryModel { // "Models.Models.CargoInventory.StaticSlotsCargoInventoryModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t slotsCount = 0x18; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_MaxSlotsCount = 0x7AB140; // "public override int get_MaxSlotsCount()"
            inline constexpr std::uintptr_t get_SlotsCount = 0x7AB140; // "public override int get_SlotsCount()"
        }
    } // namespace StaticSlotsCargoInventoryModel

    namespace StorageBoxInventoryData { // "Models.Data.Settlement.Storage.StorageBoxInventoryData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Inventory = 0x20; // "InventoryData"
            inline constexpr std::uintptr_t InventoryRevealId = 0x28; // "InventoryRevealIdData"
        }
    } // namespace StorageBoxInventoryData

    namespace StorageBoxInventoryEntityModel { // "Game.Battle.EntityModel.StorageBox.Models.StorageBoxInventoryEntityModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ServerModel = 0x18; // "StorageBoxInventoryModel"
            inline constexpr std::uintptr_t BusySlotsModel = 0x20; // "BusySlotsModel"
            inline constexpr std::uintptr_t ChangedSlotsInventoryModel = 0x28; // "ChangedSlotsInventoryModel"
            inline constexpr std::uintptr_t ShadowAreaModel = 0x30; // "InventoryShadowAreaModel"
        }
    } // namespace StorageBoxInventoryEntityModel

    namespace StorageBoxInventoryModel { // "Models.Models.StorageBoxInventory.StorageBoxInventoryModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Id = 0x10; // "int"
            inline constexpr std::uintptr_t InventoryModel = 0x18; // "IInventoryModel"
            inline constexpr std::uintptr_t InventoryRevealIdModel = 0x20; // "InventoryRevealIdModel"
        }
    } // namespace StorageBoxInventoryModel

    namespace StorageBoxInventoryModelUpdater { // "Game.Battle.EntityModel.StorageBox.Updaters.StorageBoxInventoryModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t changedSlotsInventoryModelUpdater = 0x10; // "IUpdater"
            inline constexpr std::uintptr_t busySlotsModelUpdater = 0x18; // "IUpdater"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xBF89A0; // "public void Update()"
        }
    } // namespace StorageBoxInventoryModelUpdater

    namespace StorageInventoryEntityStreamReader { // "Models.Replication.EntityStreamReader.StorageInventoryEntityStreamReader (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t entitiesParamsModel = 0x20; // "EntitiesParamsModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t TryReadParams = 0x44D3380; // "protected override bool TryReadParams(int entityId, IBinaryReadStream stream)"
        }
    } // namespace StorageInventoryEntityStreamReader

    namespace SubscribeEntityMessage { // "Models.Messages.Inventory.SubscribeEntityMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t entityId = 0x20; // "BattleEntityIdData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_EntityId = 0x4A2F990; // "public int get_EntityId()"
            inline constexpr std::uintptr_t get_Type = 0x4A2F9D0; // "public override string get_Type()"
        }
    } // namespace SubscribeEntityMessage

    namespace SwapBuilderWithInventoryMessage { // "Models.Messages.Builder.SwapBuilderWithInventoryMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t entityId = 0x20; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t fromInventorySlot = 0x28; // "IPrimitiveData<InventorySlotDescription>"
            inline constexpr std::uintptr_t toInventorySlot = 0x30; // "IPrimitiveData<InventorySlotDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_EntityId = 0x4A30000; // "public int get_EntityId()"
            inline constexpr std::uintptr_t get_FromInventorySlot = 0x4A30050; // "public InventorySlotDescription get_FromInventorySlot()"
            inline constexpr std::uintptr_t get_ToInventorySlot = 0x4A300A0; // "public InventorySlotDescription get_ToInventorySlot()"
            inline constexpr std::uintptr_t get_Type = 0x4A300F0; // "public override string get_Type()"
        }
    } // namespace SwapBuilderWithInventoryMessage

    namespace SwapInventoryWithDefenseModuleSlotMessage { // "Models.Messages.PlotBuildingDefenseSlot.SwapInventoryWithDefenseModuleSlotMessage (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x4A12C80; // "public override string get_Type()"
        }
    } // namespace SwapInventoryWithDefenseModuleSlotMessage

    namespace SwapInventoryWithSpecialModuleSlotMessage { // "Models.Messages.PlotBuildingDefenseSlot.SwapInventoryWithSpecialModuleSlotMessage (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x4A12CB0; // "public override string get_Type()"
        }
    } // namespace SwapInventoryWithSpecialModuleSlotMessage

    namespace TakeAllButtonKeyboardViewUpdater { // "Game.Battle.Inventory.TakeAllButtonKeyboardViewUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t updaters = 0x20; // "List<IUpdater>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA6B930; // "public TakeAllButtonKeyboardViewUpdater Init(BusySlotsModel busySlotsModel, InputAction action, HoldPointerButtonView holdPointerButtonView, CompositeButtonView compositeButtonView, IRevealContainerModel revealContainerModel, UpdaterPool updaterPool, IRegisterDisposable registerDisposable, Func<bool> isCorrectTab)"
            inline constexpr std::uintptr_t Dispose = 0xA6B8D0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0x94CF50; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace TakeAllButtonKeyboardViewUpdater

    namespace TakeAllDisableInputUpdater { // "Game.Battle.Inventory.TakeAllDisableInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t busySlots = 0x20; // "BusySlotsModel"
            inline constexpr std::uintptr_t revealContainerModel = 0x28; // "IRevealContainerModel"
            inline constexpr std::uintptr_t takeAll = 0x30; // "InputAction"
            inline constexpr std::uintptr_t isEnabled = 0x38; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA6BCF0; // "public TakeAllDisableInputUpdater Init(InputAction takeAll, BusySlotsModel busySlots, IRevealContainerModel revealContainerModel)"
            inline constexpr std::uintptr_t Dispose = 0xA6BC90; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA6BD90; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t SetEnabled = 0xA6BE00; // "private void SetEnabled(bool isEnabled)"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace TakeAllDisableInputUpdater

    namespace TakeAllInputUpdater { // "Game.Battle.Inventory.TakeAllInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t entityId = 0x20; // "int"
            inline constexpr std::uintptr_t inventoryModel = 0x28; // "IInventoryModel"
            inline constexpr std::uintptr_t takeAll = 0x30; // "InputAction"
            inline constexpr std::uintptr_t itemMoveModel = 0x38; // "ItemMoveModel"
            inline constexpr std::uintptr_t personalNotificationModel = 0x40; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t notificationError = 0x48; // "NotificationError"
            inline constexpr std::uintptr_t inventoryDragAndDropModel = 0x50; // "InventoryDragAndDropModel"
            inline constexpr std::uintptr_t playerClientModel = 0x58; // "PlayerClientModel"
            inline constexpr std::uintptr_t revealContainerModel = 0x60; // "IRevealContainerModel"
            inline constexpr std::uintptr_t sector = 0x68; // "SectorDescription"
            inline constexpr std::uintptr_t takeItems = 0x70; // "List<ExternalItemMoveContext>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA6BF20; // "public TakeAllInputUpdater Init(int entityId, IInventoryModel inventoryModel, InputAction takeAll, ItemMoveModel itemMoveModel, PersonalNotificationModel personalNotificationModel, NotificationError notificationError, InventoryDragAndDropModel inventoryDragAndDropModel, PlayerClientModel playerClientModel, IRevealContainerModel revealContainerModel, SectorDescription sector)"
            inline constexpr std::uintptr_t Dispose = 0xA6BE30; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA6BFF0; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace TakeAllInputUpdater

    namespace TakeAllPagesInputUpdater { // "Game.Battle.Inventory.TakeAllPagesInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t paginatorModel = 0x20; // "ItemInventoryPaginatorModel"
            inline constexpr std::uintptr_t takeAll = 0x28; // "InputAction"
            inline constexpr std::uintptr_t itemMoveModel = 0x30; // "ItemMoveModel"
            inline constexpr std::uintptr_t personalNotificationModel = 0x38; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t notificationError = 0x40; // "NotificationError"
            inline constexpr std::uintptr_t inventoryDragAndDropModel = 0x48; // "InventoryDragAndDropModel"
            inline constexpr std::uintptr_t playerClientModel = 0x50; // "PlayerClientModel"
            inline constexpr std::uintptr_t revealContainerModel = 0x58; // "IRevealContainerModel"
            inline constexpr std::uintptr_t takeItems = 0x60; // "List<ExternalItemMoveContext>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA6CC70; // "public TakeAllPagesInputUpdater Init(ItemInventoryPaginatorModel paginatorModel, InputAction takeAll, ItemMoveModel itemMoveModel, PersonalNotificationModel personalNotificationModel, NotificationError notificationError, InventoryDragAndDropModel inventoryDragAndDropModel, PlayerClientModel playerClientModel, IRevealContainerModel revealContainerModel)"
            inline constexpr std::uintptr_t Dispose = 0xA6C6C0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA6CD80; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t FillByPage = 0xA6C7A0; // "private void FillByPage(IInventoryModel inventoryModel, int entityId)"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace TakeAllPagesInputUpdater

    namespace TakeCargoModel { // "Models.Models.ProlongedInteractionHandler.Handlers.TakeCargoModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t worldEntitiesModel = 0x10; // "WorldEntitiesModel"
            inline constexpr std::uintptr_t cargos = 0x18; // "ReadOnly.Dictionary<int, CargoModel>"
            inline constexpr std::uintptr_t buildingCargos = 0x20; // "ReadOnly.Dictionary<int, IBuildingCargoModel>"
            inline constexpr std::uintptr_t collectionCargos = 0x28; // "ReadOnly.Dictionary<int, CollectionTableRewardModel>"
            inline constexpr std::uintptr_t cargoOpenWorkbenchSlots = 0x30; // "ReadOnly.Dictionary<int, CargoOpenWorkbenchSlotModel>"
            inline constexpr std::uintptr_t cargoExchangeWorkbenchSlots = 0x38; // "ReadOnly.Dictionary<int, CargoExchangeWorkbenchSlotModel>"
            inline constexpr std::uintptr_t cargoProductionWorkbenchResultCargoSlots = 0x40; // "ReadOnly.Dictionary<int, CargoProductionWorkbenchResultCargoSlotModel>"
            inline constexpr std::uintptr_t worldInterruptModel = 0x48; // "IWorldInterruptModel"
            inline constexpr std::uintptr_t crouchStandUpModel = 0x50; // "CrouchStandUpModel"
            inline constexpr std::uintptr_t vehicleTrunkInventories = 0x58; // "ReadOnly.Dictionary<int, VehicleTrunkInventoriesModel>"
            inline constexpr std::uintptr_t vehicleLootInventories = 0x60; // "ReadOnly.Dictionary<int, VehicleLootEntityInventoryModel>"
            inline constexpr std::uintptr_t cargoInventorySlots = 0x68; // "ReadOnly.Dictionary<int, CargoInventorySlotModel>"
            inline constexpr std::uintptr_t subscribeEntities = 0x70; // "ReadOnly.Dictionary<int, SubscribeEntityModel>"
            inline constexpr std::uintptr_t vehicleTrunkInventoriesModelByCargoInventorySlot = 0x78; // "ReadOnly.Dictionary<int, VehicleTrunkInventoriesModel>"
            inline constexpr std::uintptr_t vehicleLootInventoryByCargoInventorySlot = 0x80; // "ReadOnly.Dictionary<int, VehicleLootEntityInventoryModel>"
            inline constexpr std::uintptr_t furnitureLootInventoryByCargoInventorySlot = 0x88; // "ReadOnly.Dictionary<int, FurnitureLootEntityInventoryModel>"
            inline constexpr std::uintptr_t buildingLootInventoryByCargoInventorySlot = 0x90; // "ReadOnly.Dictionary<int, BuilderLootEntityInventoryModel>"
            inline constexpr std::uintptr_t shelvingByCargoInventorySlot = 0x98; // "ReadOnly.Dictionary<int, ShelvingModel>"
            inline constexpr std::uintptr_t furnitureLootEntityInventories = 0xA0; // "ReadOnly.Dictionary<int, FurnitureLootEntityInventoryModel>"
            inline constexpr std::uintptr_t buildingLootEntityInventories = 0xA8; // "ReadOnly.Dictionary<int, BuilderLootEntityInventoryModel>"
            inline constexpr std::uintptr_t locationEventCargoSpawnPoints = 0xB0; // "ReadOnly.Dictionary<int, LocationEventCargoSpawnPointModel>"
            inline constexpr std::uintptr_t locationEventDescriptionModel = 0xB8; // "IPrimitiveModel<LocationEventDescription>"
            inline constexpr std::uintptr_t settlementHelperModel = 0xC0; // "ISettlementHelperModel"
            inline constexpr std::uintptr_t partyMemberAccessModel = 0xC8; // "IPartyMemberAccessModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Process = 0x4906300; // "public override MutuallyExclusiveProcessesDescription get_Process()"
            inline constexpr std::uintptr_t get_StartCommand = 0x4906390; // "internal override UseEntityCommandDescription get_StartCommand()"
            inline constexpr std::uintptr_t get_StopCommand = 0x4906420; // "internal override UseEntityCommandDescription get_StopCommand()"
            inline constexpr std::uintptr_t CheckInteractionStart = 0x4904D80; // "public override bool CheckInteractionStart(UseEntityCommandDescription command, int useEntityId, PlayerRoleDescription playerRole)"
            inline constexpr std::uintptr_t TryFinishPrediction = 0x4905360; // "public override bool TryFinishPrediction(long now, BattleCharacterModel characterModel)"
            inline constexpr std::uintptr_t HandelRequest = 0x4905050; // "public override void HandelRequest(long now, int entityId, ProlongedInteractionInputDescription prolongedInteractionInput, BattleCharacterModel characterModel)"
            inline constexpr std::uintptr_t TryGetTargetPosition = 0x4905F80; // "public override bool TryGetTargetPosition(int entityId, out Vector3 position)"
            inline constexpr std::uintptr_t TryGetCargo = 0x49054F0; // "private bool TryGetCargo(int entityId, int characterEntityId, long now, out CargoDescription cargo, out int cumulativePoints)"
            inline constexpr std::uintptr_t TryGetTakeTime = 0x49059C0; // "private bool TryGetTakeTime(int entityId, int characterEntityId, long now, out long takeTime)"
            inline constexpr std::uintptr_t CheckInteractWithCargoSlot = 0x4904A70; // "private bool CheckInteractWithCargoSlot(int slotId, int characterId)"
            inline constexpr std::uintptr_t CheckInteractWithSubscribeEntity = 0x4904CD0; // "private bool CheckInteractWithSubscribeEntity(int subscribeEntityId, int characterId)"
            inline constexpr std::uintptr_t CheckInteractWithShelvingInventory = 0x4904C90; // "private bool CheckInteractWithShelvingInventory(ShelvingModel shelvingModel, int characterId)"
        }
    } // namespace TakeCargoModel

    namespace TakeCargoProlongedAction { // "Game.Battle.Entities.Player.ProlongedActions.TakeCargoProlongedAction (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "ProlongedInteractionModel"
            inline constexpr std::uintptr_t worldEntitiesModel = 0x18; // "WorldEntitiesModel"
            inline constexpr std::uintptr_t now = 0x20; // "INow"
            inline constexpr std::uintptr_t eventModel = 0x28; // "IPrimitiveModel<LocationEventDescription>"
            inline constexpr std::uintptr_t Label = 0x30; // "LocalizedString"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsActive = 0xB251A0; // "public bool get_IsActive()"
            inline constexpr std::uintptr_t get_EndTs = 0xB19D10; // "public long get_EndTs()"
            inline constexpr std::uintptr_t get_Duration = 0xB25160; // "public long get_Duration()"
            inline constexpr std::uintptr_t Interrupt = 0xB25020; // "public void Interrupt(BattleInputModel battleInputModel)"
            inline constexpr std::uintptr_t GetTakeTime = 0xB24BD0; // "private long GetTakeTime(int entityId)"
        }
    } // namespace TakeCargoProlongedAction

    namespace TakeInHandsIntentionOnEquipDelayEndsModel { // "Models.Models.TakeInHandsIntentionOnEquipDelayEnds.TakeInHandsIntentionOnEquipDelayEndsModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "IPrimitiveData<bool>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_HasIntention = 0x48C7270; // "public bool get_HasIntention()"
            inline constexpr std::uintptr_t Set = 0x48C71F0; // "public void Set()"
            inline constexpr std::uintptr_t Unset = 0x48C7230; // "public void Unset()"
        }
    } // namespace TakeInHandsIntentionOnEquipDelayEndsModel

    namespace TakeItemAction { // "Game.Battle.Inventory.TakeItemAction (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t EntityIds = 0x0; // "List<int>"
            inline constexpr std::uintptr_t Commands = 0x8; // "List<InventoryTakeCommand>"
            inline constexpr std::uintptr_t FromContexts = 0x10; // "IReadOnlyList<ExternalItemMoveContext>"
        }
    } // namespace TakeItemAction

    namespace TakeLootNodeExtensions { // "Models.Utils.Extensions.TakeLootNodeExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t CanLoot = 0x396F190; // "public static bool CanLoot(LootNodeModel lootNodeModel, PlayerRoleDescription role)"
            inline constexpr std::uintptr_t CheckTake = 0x396F240; // "public static bool CheckTake(LootNodeModel lootNodeModel, ReadOnly.Dictionary<int, IInteractEntityModel> interactEntities, IPositionModel positionModel)"
            inline constexpr std::uintptr_t IsTakeLootNodeDiggingAnimation = 0x396F5B0; // "public static bool IsTakeLootNodeDiggingAnimation(ProlongedInteractionModel prolongedInteraction, PlayerRoleDescription role)"
            inline constexpr std::uintptr_t IsTakeLootNodeAnimation = 0x396F450; // "public static bool IsTakeLootNodeAnimation(ProlongedInteractionModel prolongedInteraction, PlayerRoleDescription role)"
        }
    } // namespace TakeLootNodeExtensions

    namespace TakeLootNodeModel { // "Models.Models.ProlongedInteractionHandler.Handlers.TakeLootNodeModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t lootNodes = 0x10; // "ReadOnly.Dictionary<int, LootNodeModel>"
            inline constexpr std::uintptr_t interactEntities = 0x18; // "ReadOnly.Dictionary<int, IInteractEntityModel>"
            inline constexpr std::uintptr_t itemActionsController = 0x20; // "IItemActionsController"
            inline constexpr std::uintptr_t worldInterruptModel = 0x28; // "IWorldInterruptModel"
            inline constexpr std::uintptr_t pickupLootResult = 0x30; // "PickupLootResult"
            inline constexpr std::uintptr_t checkPickupNextLootResult = 0x38; // "PickupLootResult"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Process = 0x4909660; // "public override MutuallyExclusiveProcessesDescription get_Process()"
            inline constexpr std::uintptr_t get_StartCommand = 0x49096F0; // "internal override UseEntityCommandDescription get_StartCommand()"
            inline constexpr std::uintptr_t get_StopCommand = 0x4909780; // "internal override UseEntityCommandDescription get_StopCommand()"
            inline constexpr std::uintptr_t CheckInteractionStart = 0x49086B0; // "public override bool CheckInteractionStart(UseEntityCommandDescription command, int useEntityId, PlayerRoleDescription playerRole)"
            inline constexpr std::uintptr_t HandelRequest = 0x49088E0; // "public override void HandelRequest(long now, int entityId, ProlongedInteractionInputDescription prolongedInteractionInput, BattleCharacterModel characterModel)"
            inline constexpr std::uintptr_t TryFinishPrediction = 0x4908DB0; // "public override bool TryFinishPrediction(long now, BattleCharacterModel characterModel)"
            inline constexpr std::uintptr_t TryGetTargetPosition = 0x4909480; // "public override bool TryGetTargetPosition(int entityId, out Vector3 position)"
            inline constexpr std::uintptr_t TryGetItem = 0x49092A0; // "private bool TryGetItem(long now, IInventoryModel inventory, IEquipSlotsModel equipSlots, IPocketsModel pockets, IEquipAmmoModel equipAmmo, EquipSlotsDelaysModel equipSlotsDelays, InventoryItemDescription item, int count)"
            inline constexpr std::uintptr_t CheckTakeLoot = 0x4908760; // "private bool CheckTakeLoot(IInventoryModel inventory, IEquipSlotsModel equipSlots, IPocketsModel pockets, LootNodeLootDescription lootNodeLootDescription)"
            inline constexpr std::uintptr_t CheckTakeLoot_2 = 0x4908830; // "private bool CheckTakeLoot(IInventoryModel inventory, IEquipSlotsModel equipSlots, IPocketsModel pockets, InventoryItemDescription item, int count)"
        }
    } // namespace TakeLootNodeModel

    namespace TakeLootNodeProlongedAction { // "Game.Battle.Entities.Player.ProlongedActions.TakeLootNodeProlongedAction (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "ProlongedInteractionModel"
            inline constexpr std::uintptr_t Label = 0x18; // "LocalizedString"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsActive = 0xB25780; // "public bool get_IsActive()"
            inline constexpr std::uintptr_t get_EndTs = 0xB19D10; // "public long get_EndTs()"
            inline constexpr std::uintptr_t get_Duration = 0xB25720; // "public long get_Duration()"
            inline constexpr std::uintptr_t Interrupt = 0xB25670; // "public void Interrupt(BattleInputModel battleInputModel)"
        }
    } // namespace TakeLootNodeProlongedAction

    namespace TakeLootObjectExtensions { // "Models.Utils.Extensions.TakeLootObjectExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t CanLoot = 0x396F680; // "public static bool CanLoot(ILootObjectModel lootObjectModel, PlayerRoleDescription role)"
        }
    } // namespace TakeLootObjectExtensions

    namespace TakeLootObjectModel { // "Models.Models.ProlongedInteractionHandler.Handlers.TakeLootObjectModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t worldEntitiesModel = 0x10; // "WorldEntitiesModel"
            inline constexpr std::uintptr_t checkTakeLootObjectModel = 0x18; // "CheckTakeLootObjectModel"
            inline constexpr std::uintptr_t worldInterruptModel = 0x20; // "IWorldInterruptModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Process = 0x490A0F0; // "public override MutuallyExclusiveProcessesDescription get_Process()"
            inline constexpr std::uintptr_t get_StartCommand = 0x490A180; // "internal override UseEntityCommandDescription get_StartCommand()"
            inline constexpr std::uintptr_t get_StopCommand = 0x490A210; // "internal override UseEntityCommandDescription get_StopCommand()"
            inline constexpr std::uintptr_t CheckInteractionStart = 0x4909810; // "public override bool CheckInteractionStart(UseEntityCommandDescription command, int useEntityId, PlayerRoleDescription playerRole)"
            inline constexpr std::uintptr_t HandelRequest = 0x4909910; // "public override void HandelRequest(long now, int entityId, ProlongedInteractionInputDescription prolongedInteractionInput, BattleCharacterModel characterModel)"
            inline constexpr std::uintptr_t TryFinishPrediction = 0x4909CF0; // "public override bool TryFinishPrediction(long now, BattleCharacterModel characterModel)"
            inline constexpr std::uintptr_t TryGetTargetPosition = 0x4909FC0; // "public override bool TryGetTargetPosition(int entityId, out Vector3 position)"
            inline constexpr std::uintptr_t TryGetLootObject = 0x4909E30; // "private bool TryGetLootObject(int entityId, long now, BattleCharacterModel characterModel, IInventoryModel inventoryModel, out ILootObjectModel lootObjectModel)"
        }
    } // namespace TakeLootObjectModel

    namespace TakeLootObjectProlongedAction { // "Game.Battle.Entities.Player.ProlongedActions.TakeLootObjectProlongedAction (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "ProlongedInteractionModel"
            inline constexpr std::uintptr_t worldEntitiesModel = 0x18; // "WorldEntitiesModel"
            inline constexpr std::uintptr_t Label = 0x20; // "LocalizedString"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsActive = 0xB25890; // "public bool get_IsActive()"
            inline constexpr std::uintptr_t get_EndTs = 0xB19D10; // "public long get_EndTs()"
            inline constexpr std::uintptr_t get_Duration = 0xB25830; // "public long get_Duration()"
            inline constexpr std::uintptr_t Interrupt = 0xB25790; // "public void Interrupt(BattleInputModel battleInputModel)"
        }
    } // namespace TakeLootObjectProlongedAction

    namespace ThrowableItemCooldownModel { // "Models.Models.ThrowableItemCooldown.ThrowableItemCooldownModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t models = 0x10; // "Dictionary<ThrowableItemTypeDescription, IPrimitiveModel<long>>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Item = 0x48C7B90; // "public IPrimitiveModel<long> get_Item(ThrowableItemTypeDescription description)"
            inline constexpr std::uintptr_t CheckOnCooldown = 0x48C78E0; // "public bool CheckOnCooldown(ThrowableItemTypeDescription description, long now)"
        }
    } // namespace ThrowableItemCooldownModel

    namespace ThrowableItemDescription { // "Models.References.Inventory.ThrowableItemDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t TypeFunc = 0x20; // "Func<ThrowableItemTypeDescription>"
            inline constexpr std::uintptr_t TakeInTime = 0x28; // "long"
            inline constexpr std::uintptr_t CastTime = 0x30; // "long"
            inline constexpr std::uintptr_t PostCastTime = 0x38; // "long"
            inline constexpr std::uintptr_t GrenadeFunc = 0x40; // "Func<GrenadeDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x9D6230; // "public ThrowableItemTypeDescription get_Type()"
            inline constexpr std::uintptr_t get_Grenade = 0x4048E60; // "public GrenadeDescription get_Grenade()"
            inline constexpr std::uintptr_t get_IsGrenade = 0x40A22C0; // "public bool get_IsGrenade()"
        }
    } // namespace ThrowableItemDescription

    namespace ThrowableItemModel { // "Models.Models.ThrowableItem.ThrowableItemModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t itemInHands = 0x10; // "IInventoryItemModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_HasValue = 0x48C7BF0; // "public bool get_HasValue()"
            inline constexpr std::uintptr_t get_Value = 0x48C7C70; // "public ThrowableItemDescription get_Value()"
        }
    } // namespace ThrowableItemModel

    namespace ThrowableItemTypeDescription { // "Models.References.Inventory.ThrowableItemTypeDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Cooldown = 0x20; // "long"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_HasCooldown = 0x36639B0; // "public bool get_HasCooldown()"
        }
    } // namespace ThrowableItemTypeDescription

    namespace TooltipBuyButtonUpdater { // "Game.Battle.Inventory.Tooltip.TooltipBuyButtonUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t tooltipModel = 0x20; // "TooltipModel"
            inline constexpr std::uintptr_t currentInventoryModel = 0x28; // "CurrentInventoryModel"
            inline constexpr std::uintptr_t inventoryIntention = 0x30; // "InventoryIntention"
            inline constexpr std::uintptr_t itemTooltipView = 0x38; // "ItemTooltipView"
            inline constexpr std::uintptr_t lockedTraderItemByVendorTree = 0x40; // "BlockedSlotsModel"
            inline constexpr std::uintptr_t tooltipContext = 0x48; // "ITooltipContext"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA6D170; // "public TooltipBuyButtonUpdater Init(TooltipModel tooltipModel, CurrentInventoryModel currentInventoryModel, InventoryIntention inventoryIntention, ItemTooltipView itemTooltipView, BlockedSlotsModel lockedTraderItemByVendorTree)"
            inline constexpr std::uintptr_t Dispose = 0xA123B0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA6D490; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t IsActive = 0xA6D200; // "private bool IsActive(ITooltipContext tooltipContext)"
            inline constexpr std::uintptr_t IsInteractable = 0xA6D290; // "private bool IsInteractable(ITooltipContext tooltipContext)"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace TooltipBuyButtonUpdater

    namespace TooltipCollectButtonUpdater { // "Game.Battle.Inventory.Tooltip.TooltipCollectButtonUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t tooltipModel = 0x20; // "TooltipModel"
            inline constexpr std::uintptr_t itemTooltipView = 0x28; // "ItemTooltipView"
            inline constexpr std::uintptr_t inventoryIntention = 0x30; // "InventoryIntention"
            inline constexpr std::uintptr_t currentInventoryModel = 0x38; // "CurrentInventoryModel"
            inline constexpr std::uintptr_t inventoryModels = 0x40; // "InventoryModels"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x48; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t tooltipContext = 0x50; // "ITooltipContext"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA6D5E0; // "public TooltipCollectButtonUpdater Init(TooltipModel tooltipModel, ItemTooltipView itemTooltipView, InventoryIntention inventoryIntention, CurrentInventoryModel currentInventoryModel, InventoryModels inventoryModels, IBattleEntitiesModel battleEntitiesModel)"
            inline constexpr std::uintptr_t Dispose = 0xA0E680; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA6D9C0; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t IsActive = 0xA6D690; // "private bool IsActive(ITooltipContext tooltipContext)"
            inline constexpr std::uintptr_t IsInteractable = 0xA6D720; // "private bool IsInteractable(ITooltipContext tooltipContext)"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace TooltipCollectButtonUpdater

    namespace TooltipDropButtonUpdater { // "Game.Battle.Inventory.Tooltip.TooltipDropButtonUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t tooltipModel = 0x20; // "TooltipModel"
            inline constexpr std::uintptr_t itemTooltipView = 0x28; // "ItemTooltipView"
            inline constexpr std::uintptr_t inventoryIntention = 0x30; // "InventoryIntention"
            inline constexpr std::uintptr_t blockedSlotsModel = 0x38; // "BlockedSlotsModel"
            inline constexpr std::uintptr_t tooltipContext = 0x40; // "ITooltipContext"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA6DB10; // "public TooltipDropButtonUpdater Init(TooltipModel tooltipModel, PlayerEntityModel playerEntityModel, ItemTooltipView itemTooltipView)"
            inline constexpr std::uintptr_t Dispose = 0x9F4BF0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA6DCE0; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t IsActive = 0xA6DBB0; // "private bool IsActive(ITooltipContext tooltipContext)"
            inline constexpr std::uintptr_t IsInteractable = 0xA6DC20; // "private bool IsInteractable(ITooltipContext tooltipContext)"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace TooltipDropButtonUpdater

    namespace TooltipEquipButtonUpdater { // "Game.Battle.Inventory.Tooltip.TooltipEquipButtonUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t tooltipModel = 0x20; // "TooltipModel"
            inline constexpr std::uintptr_t tooltipView = 0x28; // "ItemTooltipView"
            inline constexpr std::uintptr_t inventoryIntention = 0x30; // "InventoryIntention"
            inline constexpr std::uintptr_t tooltipContext = 0x38; // "ITooltipContext"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0x9FA8F0; // "public TooltipEquipButtonUpdater Init(TooltipModel tooltipModel, ItemTooltipView tooltipView, InventoryIntention inventoryIntention)"
            inline constexpr std::uintptr_t Dispose = 0x9F6DA0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA6DFE0; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t IsActive = 0xA6DEC0; // "private bool IsActive(ITooltipContext tooltipContext)"
            inline constexpr std::uintptr_t IsInteractable = 0xA6DF30; // "private bool IsInteractable(ITooltipContext tooltipContext)"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace TooltipEquipButtonUpdater

    namespace TooltipFindButtonUpdater { // "Game.Battle.Inventory.Tooltip.TooltipFindButtonUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t tooltipModel = 0x20; // "TooltipModel"
            inline constexpr std::uintptr_t itemTooltipView = 0x28; // "ItemTooltipView"
            inline constexpr std::uintptr_t unlockRequirementItemPositionModel = 0x30; // "UnlockRequirementItemPositionModel"
            inline constexpr std::uintptr_t tooltipContext = 0x38; // "ITooltipContext"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0x9FA8F0; // "public TooltipFindButtonUpdater Init(TooltipModel tooltipModel, ItemTooltipView itemTooltipView, UnlockRequirementItemPositionModel unlockRequirementItemPositionModel)"
            inline constexpr std::uintptr_t Dispose = 0x9F6DA0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA6E3E0; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t IsActive = 0xA6E1B0; // "private bool IsActive(ITooltipContext tooltipContext)"
            inline constexpr std::uintptr_t IsInteractable = 0xA6E360; // "private bool IsInteractable(ITooltipContext tooltipContext)"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace TooltipFindButtonUpdater

    namespace TooltipFindInVendorButtonUpdater { // "Game.Battle.Inventory.Tooltip.TooltipFindInVendorButtonUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t tooltipModel = 0x20; // "TooltipModel"
            inline constexpr std::uintptr_t currentInventoryModel = 0x28; // "CurrentInventoryModel"
            inline constexpr std::uintptr_t itemTooltipView = 0x30; // "ItemTooltipView"
            inline constexpr std::uintptr_t lockedTraderItemByVendorTree = 0x38; // "BlockedSlotsModel"
            inline constexpr std::uintptr_t tooltipContext = 0x40; // "ITooltipContext"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA6E6B0; // "public TooltipFindInVendorButtonUpdater Init(TooltipModel tooltipModel, CurrentInventoryModel currentInventoryModel, ItemTooltipView itemTooltipView, BlockedSlotsModel lockedTraderItemByVendorTree)"
            inline constexpr std::uintptr_t Dispose = 0x9F4BF0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA6E850; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t IsActive = 0xA6E730; // "private bool IsActive(ITooltipContext tooltipContext)"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace TooltipFindInVendorButtonUpdater

    namespace TooltipInstallButtonUpdater { // "Game.Battle.Inventory.Tooltip.TooltipInstallButtonUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t tooltipModel = 0x20; // "TooltipModel"
            inline constexpr std::uintptr_t itemTooltipView = 0x28; // "ItemTooltipView"
            inline constexpr std::uintptr_t inventoryIntention = 0x30; // "InventoryIntention"
            inline constexpr std::uintptr_t currentInventoryModel = 0x38; // "CurrentInventoryModel"
            inline constexpr std::uintptr_t inventoryModels = 0x40; // "InventoryModels"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x48; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t tooltipContext = 0x50; // "ITooltipContext"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA6D5E0; // "public TooltipInstallButtonUpdater Init(TooltipModel tooltipModel, ItemTooltipView itemTooltipView, InventoryIntention inventoryIntention, CurrentInventoryModel currentInventoryModel, InventoryModels inventoryModels, IBattleEntitiesModel battleEntitiesModel)"
            inline constexpr std::uintptr_t Dispose = 0xA0E680; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA6EB20; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t IsActive = 0xA6E9E0; // "private bool IsActive(ITooltipContext tooltipContext)"
            inline constexpr std::uintptr_t IsInteractable = 0xA6EA70; // "private bool IsInteractable(ITooltipContext tooltipContext)"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace TooltipInstallButtonUpdater

    namespace TooltipMoveButtonUpdater { // "Game.Battle.Inventory.Tooltip.TooltipMoveButtonUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t tooltipModel = 0x20; // "TooltipModel"
            inline constexpr std::uintptr_t itemTooltipView = 0x28; // "ItemTooltipView"
            inline constexpr std::uintptr_t inventoryIntention = 0x30; // "InventoryIntention"
            inline constexpr std::uintptr_t currentInventoryModel = 0x38; // "CurrentInventoryModel"
            inline constexpr std::uintptr_t inventoryModels = 0x40; // "InventoryModels"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x48; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t tooltipContext = 0x50; // "ITooltipContext"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA6D5E0; // "public TooltipMoveButtonUpdater Init(TooltipModel tooltipModel, ItemTooltipView itemTooltipView, InventoryIntention inventoryIntention, CurrentInventoryModel currentInventoryModel, InventoryModels inventoryModels, IBattleEntitiesModel battleEntitiesModel)"
            inline constexpr std::uintptr_t Dispose = 0xA0E680; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA6EE30; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t IsActive = 0xA6ECF0; // "private bool IsActive(ITooltipContext tooltipContext)"
            inline constexpr std::uintptr_t IsInteractable = 0xA6ED80; // "private bool IsInteractable(ITooltipContext tooltipContext)"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace TooltipMoveButtonUpdater

    namespace TooltipReloadButtonUpdater { // "Game.Battle.Inventory.Tooltip.TooltipReloadButtonUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t itemTooltipView = 0x20; // "ItemTooltipView"
            inline constexpr std::uintptr_t useReloadWeapon = 0x28; // "UseReloadWeapon"
            inline constexpr std::uintptr_t characterCargoModel = 0x30; // "CharacterCargoModel"
            inline constexpr std::uintptr_t tooltipModel = 0x38; // "TooltipModel"
            inline constexpr std::uintptr_t tooltipContext = 0x40; // "ITooltipContext"
            inline constexpr std::uintptr_t isActive = 0x48; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA6F000; // "public TooltipReloadButtonUpdater Init(TooltipModel tooltipModel, PlayerEntityModel playerEntityModel, ItemTooltipView itemTooltipView)"
            inline constexpr std::uintptr_t Dispose = 0x9F4BF0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA6F1F0; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t IsActive = 0xA6F0B0; // "private bool IsActive(ITooltipContext tooltipContext)"
            inline constexpr std::uintptr_t IsInteractable = 0xA6F120; // "private bool IsInteractable(ITooltipContext tooltipContext)"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace TooltipReloadButtonUpdater

    namespace TooltipSellButtonUpdater { // "Game.Battle.Inventory.Tooltip.TooltipSellButtonUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t tooltipModel = 0x20; // "TooltipModel"
            inline constexpr std::uintptr_t currentInventoryModel = 0x28; // "CurrentInventoryModel"
            inline constexpr std::uintptr_t inventoryIntention = 0x30; // "InventoryIntention"
            inline constexpr std::uintptr_t itemTooltipView = 0x38; // "ItemTooltipView"
            inline constexpr std::uintptr_t tooltipContext = 0x40; // "ITooltipContext"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA6E6B0; // "public TooltipSellButtonUpdater Init(TooltipModel tooltipModel, CurrentInventoryModel currentInventoryModel, InventoryIntention inventoryIntention, ItemTooltipView itemTooltipView)"
            inline constexpr std::uintptr_t Dispose = 0x9F4BF0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA6F4F0; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t IsActive = 0xA6F3D0; // "private bool IsActive(ITooltipContext tooltipContext)"
            inline constexpr std::uintptr_t IsInteractable = 0xA6F460; // "private bool IsInteractable(ITooltipContext tooltipContext)"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace TooltipSellButtonUpdater

    namespace TooltipSplitButtonUpdater { // "Game.Battle.Inventory.Tooltip.TooltipSplitButtonUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t tooltipModel = 0x20; // "TooltipModel"
            inline constexpr std::uintptr_t itemTooltipView = 0x28; // "ItemTooltipView"
            inline constexpr std::uintptr_t inventoryIntention = 0x30; // "InventoryIntention"
            inline constexpr std::uintptr_t tooltipContext = 0x38; // "ITooltipContext"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0x9FA8F0; // "public TooltipSplitButtonUpdater Init(TooltipModel tooltipModel, ItemTooltipView itemTooltipView, InventoryIntention inventoryIntention)"
            inline constexpr std::uintptr_t Dispose = 0x9F6DA0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA848B0; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t IsActive = 0xA84750; // "private bool IsActive(ITooltipContext tooltipContext)"
            inline constexpr std::uintptr_t IsInteractable = 0xA847C0; // "private bool IsInteractable(ITooltipContext tooltipContext)"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace TooltipSplitButtonUpdater

    namespace TooltipUnequipButtonUpdater { // "Game.Battle.Inventory.Tooltip.TooltipUnequipButtonUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t tooltipModel = 0x20; // "TooltipModel"
            inline constexpr std::uintptr_t tooltipView = 0x28; // "ItemTooltipView"
            inline constexpr std::uintptr_t inventoryIntention = 0x30; // "InventoryIntention"
            inline constexpr std::uintptr_t tooltipContext = 0x38; // "ITooltipContext"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0x9FA8F0; // "public TooltipUnequipButtonUpdater Init(TooltipModel tooltipModel, ItemTooltipView tooltipView, InventoryIntention inventoryIntention)"
            inline constexpr std::uintptr_t Dispose = 0x9F6DA0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA84BE0; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t IsActive = 0xA84AC0; // "private bool IsActive(ITooltipContext tooltipContext)"
            inline constexpr std::uintptr_t IsInteractable = 0xA84B30; // "private bool IsInteractable(ITooltipContext tooltipContext)"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace TooltipUnequipButtonUpdater

    namespace TooltipUnloadButtonUpdater { // "Game.Battle.Inventory.Tooltip.TooltipUnloadButtonUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t tooltipModel = 0x20; // "TooltipModel"
            inline constexpr std::uintptr_t tooltipView = 0x28; // "ItemTooltipView"
            inline constexpr std::uintptr_t playerEntityModel = 0x30; // "PlayerEntityModel"
            inline constexpr std::uintptr_t tooltipContext = 0x38; // "ITooltipContext"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA84DB0; // "public TooltipUnloadButtonUpdater Init(TooltipModel tooltipModel, PlayerEntityModel playerEntityModel, ItemTooltipView tooltipView)"
            inline constexpr std::uintptr_t Dispose = 0x9F6DA0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA84F30; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t IsActive = 0xA84E20; // "private bool IsActive(ITooltipContext tooltipContext)"
            inline constexpr std::uintptr_t IsInteractable = 0xA84E90; // "private bool IsInteractable(ITooltipContext tooltipContext)"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace TooltipUnloadButtonUpdater

    namespace TooltipUseButtonUpdater { // "Game.Battle.Inventory.Tooltip.TooltipUseButtonUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t tooltipModel = 0x20; // "TooltipModel"
            inline constexpr std::uintptr_t itemTooltipView = 0x28; // "ItemTooltipView"
            inline constexpr std::uintptr_t usePlateRule = 0x30; // "UsePlate"
            inline constexpr std::uintptr_t singleUseItemRule = 0x38; // "SingleUseItem"
            inline constexpr std::uintptr_t blockedSlotsModel = 0x40; // "BlockedSlotsModel"
            inline constexpr std::uintptr_t cargoModel = 0x48; // "CharacterCargoModel"
            inline constexpr std::uintptr_t timeModel = 0x50; // "TimeModel"
            inline constexpr std::uintptr_t tooltipContext = 0x58; // "ITooltipContext"
            inline constexpr std::uintptr_t isActive = 0x60; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA85100; // "public TooltipUseButtonUpdater Init(TooltipModel tooltipModel, PlayerEntityModel playerEntityModel, TimeModel timeModel, ItemTooltipView itemTooltipView)"
            inline constexpr std::uintptr_t Dispose = 0x9ED4D0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA85580; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t IsActive = 0xA85200; // "private bool IsActive(ITooltipContext tooltipContext)"
            inline constexpr std::uintptr_t IsInteractable = 0xA85380; // "private bool IsInteractable(ITooltipContext tooltipContext)"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace TooltipUseButtonUpdater

    namespace TooltipUseConsumableItemButtonUpdater { // "Game.Battle.Inventory.Tooltip.TooltipUseConsumableItemButtonUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleModeDescription = 0x20; // "BattleModeDescription"
            inline constexpr std::uintptr_t tooltipModel = 0x28; // "TooltipModel"
            inline constexpr std::uintptr_t itemTooltipView = 0x30; // "ItemTooltipView"
            inline constexpr std::uintptr_t battleCharacterModel = 0x38; // "BattleCharacterModel"
            inline constexpr std::uintptr_t inventoryItemViewDescriptions = 0x40; // "InventoryItemViewDescriptions"
            inline constexpr std::uintptr_t tooltipContext = 0x48; // "ITooltipContext"
            inline constexpr std::uintptr_t isActive = 0x50; // "bool"
            inline constexpr std::uintptr_t cachedInteractable = 0x51; // "Nullable<bool>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA857C0; // "public TooltipUseConsumableItemButtonUpdater Init(BattleModeDescription battleModeDescription, TooltipModel tooltipModel, PlayerEntityModel playerEntityModel, ItemTooltipView itemTooltipView, InventoryItemViewDescriptions inventoryItemViewDescriptions)"
            inline constexpr std::uintptr_t Dispose = 0xA123B0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA85950; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t IsActive = 0xA85870; // "private bool IsActive(ITooltipContext context)"
            inline constexpr std::uintptr_t IsInteractable = 0xA85940; // "private bool IsInteractable()"
            inline constexpr std::uintptr_t TryGetLocalization = 0xA85BB0; // "private bool TryGetLocalization(ITooltipContext context, out LocalizedString localizedString)"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace TooltipUseConsumableItemButtonUpdater

    namespace TouchCargoInputUpdater { // "Game.Battle.Trunk.Cargo.TouchCargoInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t updaters = 0x20; // "List<IUpdater>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xD93750; // "public TouchCargoInputUpdater Init(CargoInventoryModel cargoInventoryModel, CargoInventoryTabView cargoInventoryView, GlobalUISoundModel uiSoundModel, InventoryDialogModel inventoryDialogModel, BecomeRobberNotificationModel becomeRobberNotificationModel, UnavailableTargetActionsKeys unavailableKeys, PersonalNotificationModel personalNotificationModel, BattleModel battleModel, UpdaterPool updaterPool, IRegisterDisposable disposable)"
            inline constexpr std::uintptr_t Dispose = 0xD936F0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0x94CF50; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace TouchCargoInputUpdater

    namespace TouchCargoSlotInputUpdater { // "Game.Battle.Trunk.Cargo.TouchCargoSlotInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t slotView = 0x20; // "CargoInventorySlotView"
            inline constexpr std::uintptr_t slotModel = 0x28; // "CargoInventorySlotModel"
            inline constexpr std::uintptr_t tooltipModel = 0x30; // "TooltipModel"
            inline constexpr std::uintptr_t uiSoundModel = 0x38; // "GlobalUISoundModel"
            inline constexpr std::uintptr_t inventoryDialogModel = 0x40; // "InventoryDialogModel"
            inline constexpr std::uintptr_t becomeRobberNotificationModel = 0x48; // "BecomeRobberNotificationModel"
            inline constexpr std::uintptr_t unavailableKeys = 0x50; // "UnavailableTargetActionsKeys"
            inline constexpr std::uintptr_t personalNotificationModel = 0x58; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t battleModel = 0x60; // "BattleModel"
            inline constexpr std::uintptr_t cargo = 0x68; // "CargoDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xD93A60; // "public TouchCargoSlotInputUpdater Init(CargoInventorySlotView slotView, CargoInventorySlotModel slotModel, GlobalUISoundModel uiSoundModel, InventoryDialogModel inventoryDialogModel, BecomeRobberNotificationModel becomeRobberNotificationModel, UnavailableTargetActionsKeys unavailableKeys, PersonalNotificationModel personalNotificationModel, BattleModel battleModel)"
            inline constexpr std::uintptr_t Dispose = 0xB5FCF0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xD93B70; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t UpdateCargoTakeButton = 0xD93E90; // "private void UpdateCargoTakeButton()"
            inline constexpr std::uintptr_t TakeCargo = 0xD93D20; // "private void TakeCargo()"
            inline constexpr std::uintptr_t UpdateCargoTooltipOpen = 0xD94250; // "private void UpdateCargoTooltipOpen()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace TouchCargoSlotInputUpdater

    namespace TouchClickableItemsUpdater { // "Game.Battle.Inventory.TouchClickableItemsUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleEntitiesModel = 0x20; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t tooltipModel = 0x28; // "TooltipModel"
            inline constexpr std::uintptr_t inventoryModels = 0x30; // "InventoryModels"
            inline constexpr std::uintptr_t fastMoveOnClick = 0x38; // "FastMoveOnClick"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA26EB0; // "public TouchClickableItemsUpdater Init(InventoryModels inventoryModels, IBattleEntitiesModel battleEntitiesModel, CurrentInventoryModel currentInventoryModel, BattleModel battleModel, PersonalNotificationModel personalNotificationModel, NotificationError notificationError, BattleScreenContent content)"
            inline constexpr std::uintptr_t Dispose = 0xA26E50; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA26FA0; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace TouchClickableItemsUpdater

    namespace TouchHoverableSlotsUpdater { // "Game.Battle.Inventory.TouchHoverableSlotsUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleEntitiesModel = 0x10; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t tooltipModel = 0x18; // "TooltipMiniModel"
            inline constexpr std::uintptr_t inventoryModels = 0x20; // "InventoryModels"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA27700; // "public void Update()"
        }
    } // namespace TouchHoverableSlotsUpdater

    namespace TouchInventoryDialogView { // "Game.Battle.Inventory.TouchInventoryDialogView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t BtClose = 0x40; // "ClickButtonView"
        }
    } // namespace TouchInventoryDialogView

    namespace TouchTakeAllButtonDisableUpdater { // "Game.Battle.Inventory.TouchTakeAllButtonDisableUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t busySlotsModel = 0x20; // "BusySlotsModel"
            inline constexpr std::uintptr_t revealContainerModel = 0x28; // "IRevealContainerModel"
            inline constexpr std::uintptr_t takeAllCompositeButton = 0x30; // "CompositeButtonView"
            inline constexpr std::uintptr_t isEnabled = 0x38; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA6F6A0; // "public TouchTakeAllButtonDisableUpdater Init(BusySlotsModel busySlotsModel, IRevealContainerModel revealContainerModel, CompositeButtonView takeAllCompositeButton)"
            inline constexpr std::uintptr_t Dispose = 0x9F6DA0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA6F730; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t SetEnabled = 0xA6F780; // "private void SetEnabled(bool isEnabled)"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace TouchTakeAllButtonDisableUpdater

    namespace TraderCardCostUpdater { // "Game.Battle.Laptop.ShopBuy.TraderCardCostUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t itemMoveContext = 0x20; // "TraderItemMoveContext"
            inline constexpr std::uintptr_t view = 0x28; // "InventoryItemCostView"
            inline constexpr std::uintptr_t settlementBonusModel = 0x30; // "SettlementBonusModel"
            inline constexpr std::uintptr_t dirtyCashModel = 0x38; // "DirtyCashModel"
            inline constexpr std::uintptr_t coinsModel = 0x40; // "CoinsModel"
            inline constexpr std::uintptr_t buyBlockedSlotsModel = 0x48; // "BlockedSlotsModel"
            inline constexpr std::uintptr_t lockedByVendorTree = 0x50; // "BlockedSlotsModel"
            inline constexpr std::uintptr_t playerPublicId = 0x58; // "long"
            inline constexpr std::uintptr_t isShow = 0x60; // "bool"
            inline constexpr std::uintptr_t cost = 0x64; // "int"
            inline constexpr std::uintptr_t enough = 0x68; // "Nullable<bool>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0x9ED560; // "public TraderCardCostUpdater Init(BattleModel battleModel, TraderItemMoveContext itemMoveContext, InventoryItemCostView view)"
            inline constexpr std::uintptr_t Dispose = 0x9ED4D0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0x9ED6E0; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace TraderCardCostUpdater

    namespace TraderCardRules { // "Game.Battle.Laptop.ShopBuy.TraderCardRules (Battle.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x81B21E0; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t noPriceItems = 0x0; // "ReadOnly.Dictionary<InventoryItemDescription, int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t GetState = 0x9EDBB0; // "public static TraderCardState GetState(TraderItemMoveContext context, GlobalModel globalModel, BattleModel battleModel)"
            inline constexpr std::uintptr_t CanUnlock = 0x9ED9B0; // "public static bool CanUnlock(VendorTreeNodeDescription node, RealmVersion realmVersion, BattleModeDescription battleMode, SectorDescription selfSector, IBattleEntitiesModel battleEntitiesModel, long now)"
            inline constexpr std::uintptr_t IsCashOnlyPrice = 0x9EE0A0; // "private static bool IsCashOnlyPrice(VendorTreeNodeParams nodeParams)"
            inline constexpr std::uintptr_t HasEnoughPrice = 0x9EDFD0; // "public static bool HasEnoughPrice(VendorTreeNodeDescription node, RealmVersion realmVersion, DirtyCashModel dirtyCashModel)"
            inline constexpr std::uintptr_t GetUnlockCashPrice = 0x9EDE00; // "public static int GetUnlockCashPrice(VendorTreeNodeDescription node, RealmVersion realmVersion)"
        }
    } // namespace TraderCardRules

    namespace TraderCardSlotUpdater { // "Game.Battle.Laptop.ShopBuy.TraderCardSlotUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t updaters = 0x20; // "List<IUpdater>"
            inline constexpr std::uintptr_t battleModel = 0x28; // "BattleModel"
            inline constexpr std::uintptr_t globalModel = 0x30; // "GlobalModel"
            inline constexpr std::uintptr_t battleScreenContent = 0x38; // "BattleScreenContent"
            inline constexpr std::uintptr_t globalScreenContent = 0x40; // "GlobalScreenContent"
            inline constexpr std::uintptr_t inventoryScreenContent = 0x48; // "InventoryScreenContent"
            inline constexpr std::uintptr_t updaterPool = 0x50; // "UpdaterPool"
            inline constexpr std::uintptr_t draggableItemsModel = 0x58; // "DraggableItemsModel"
            inline constexpr std::uintptr_t clickableItemsModel = 0x60; // "ClickableItemsModel"
            inline constexpr std::uintptr_t dialogModel = 0x68; // "LaptopDialogModel"
            inline constexpr std::uintptr_t view = 0x70; // "TraderShowcaseView"
            inline constexpr std::uintptr_t itemMoveContext = 0x78; // "TraderItemMoveContext"
            inline constexpr std::uintptr_t slotModel = 0x80; // "IInventorySlotModel"
            inline constexpr std::uintptr_t inventoryEntityId = 0x88; // "int"
            inline constexpr std::uintptr_t cardContent = 0x90; // "IDisposableContent<TraderCardView>"
            inline constexpr std::uintptr_t currentItem = 0x98; // "InventoryItemDescription"
            inline constexpr std::uintptr_t itemDisposable = 0xA0; // "RegisterDisposable"
            inline constexpr std::uintptr_t wasInventoryLoaded = 0xA8; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0x9EF040; // "public TraderCardSlotUpdater Init(BattleModel battleModel, GlobalModel globalModel, BattleScreenContent battleScreenContent, GlobalScreenContent globalScreenContent, InventoryScreenContent inventoryScreenContent, UpdaterPool updaterPool, TraderShowcaseView view, TraderItemMoveContext itemMoveContext, int inventoryEntityId)"
            inline constexpr std::uintptr_t Dispose = 0x9EEE70; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0x9EF1A0; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t ClearItem = 0x9EED40; // "private void ClearItem()"
            inline constexpr std::uintptr_t SetItem = 0x9EF2E0; // "private void SetItem()"
            inline constexpr std::uintptr_t AddCompositeViews = 0x9EE250; // "private void AddCompositeViews(TraderCardView card)"
            inline constexpr std::uintptr_t GetTierGroupIndex = 0x9EEF60; // "private int GetTierGroupIndex()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace TraderCardSlotUpdater

    namespace TraderCardsSlotsUpdater { // "Game.Battle.Laptop.ShopBuy.TraderCardsSlotsUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t updaters = 0x10; // "List<IUpdater>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x9E52A0; // "public void Update()"
        }
    } // namespace TraderCardsSlotsUpdater

    namespace TraderCardStateUpdater { // "Game.Battle.Laptop.ShopBuy.TraderCardStateUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleModel = 0x20; // "BattleModel"
            inline constexpr std::uintptr_t globalModel = 0x28; // "GlobalModel"
            inline constexpr std::uintptr_t itemMoveContext = 0x30; // "TraderItemMoveContext"
            inline constexpr std::uintptr_t view = 0x38; // "TraderCardView"
            inline constexpr std::uintptr_t blockedSlotsModel = 0x40; // "BlockedSlotsModel"
            inline constexpr std::uintptr_t buyBlockedSlotsModel = 0x48; // "BlockedSlotsModel"
            inline constexpr std::uintptr_t dragAndDropModel = 0x50; // "InventoryDragAndDropModel"
            inline constexpr std::uintptr_t dirtyCashModel = 0x58; // "DirtyCashModel"
            inline constexpr std::uintptr_t realmVersion = 0x60; // "RealmVersion"
            inline constexpr std::uintptr_t state = 0x64; // "Nullable<TraderCardState>"
            inline constexpr std::uintptr_t isDraggable = 0x6C; // "Nullable<bool>"
            inline constexpr std::uintptr_t unlockPriceNode = 0x70; // "VendorTreeNodeDescription"
            inline constexpr std::uintptr_t hasEnoughPrice = 0x78; // "Nullable<bool>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0x9F03A0; // "public TraderCardStateUpdater Init(BattleModel battleModel, GlobalModel globalModel, TraderItemMoveContext itemMoveContext, TraderCardView view)"
            inline constexpr std::uintptr_t Dispose = 0x9F0300; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0x9F0550; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t UpdateUnlockPrice = 0x9F0870; // "private void UpdateUnlockPrice(VendorTreeNodeDescription node)"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace TraderCardStateUpdater

    namespace TraderCategoryCellBackgroundUpdater { // "Game.Battle.Laptop.ShopBuy.TraderCategoryCellBackgroundUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t showcaseView = 0x10; // "TraderShowcaseView"
            inline constexpr std::uintptr_t dialogModel = 0x18; // "LaptopDialogModel"
            inline constexpr std::uintptr_t inventoryModel = 0x20; // "TraderInventoryModel"
            inline constexpr std::uintptr_t battleMode = 0x28; // "BattleModeDescription"
            inline constexpr std::uintptr_t laptopViewDescriptions = 0x30; // "LaptopViewDescriptions"
            inline constexpr std::uintptr_t settlementModel = 0x38; // "RegionUserSettlementModel"
            inline constexpr std::uintptr_t realmVersion = 0x40; // "RealmVersion"
            inline constexpr std::uintptr_t selectedFilter = 0x44; // "ValueTuple<int, int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x9F1A10; // "public void Update()"
            inline constexpr std::uintptr_t ReInitialize = 0x9F1540; // "private void ReInitialize()"
        }
    } // namespace TraderCategoryCellBackgroundUpdater

    namespace TraderCategoryHeaderView { // "Game.Battle.Inventory.Slot.TraderCategoryHeaderView (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ButtonView = 0x20; // "CompositeButtonView"
            inline constexpr std::uintptr_t lockedState = 0x28; // "StateGroup"
            inline constexpr std::uintptr_t text = 0x30; // "LocalizeStringEvent"
            inline constexpr std::uintptr_t rectTransform = 0x38; // "RectTransform"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_GetRectTransform = 0xA85EB0; // "public RectTransform get_GetRectTransform()"
            inline constexpr std::uintptr_t Activate = 0xA85E30; // "public void Activate(LocalizedString title, bool isLocked)"
        }
    } // namespace TraderCategoryHeaderView

    namespace TraderCellBlockUpdater { // "Game.Battle.Inventory.TraderCellBlockUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t itemMoveContext = 0x10; // "TraderItemMoveContext"
            inline constexpr std::uintptr_t buyBlockedSlotsModel = 0x18; // "BlockedSlotsModel"
            inline constexpr std::uintptr_t lockedTraderItemByLocationTier = 0x20; // "BlockedSlotsModel"
            inline constexpr std::uintptr_t lockedTraderItemByVendorTree = 0x28; // "BlockedSlotsModel"
            inline constexpr std::uintptr_t laptopDirtyCashModel = 0x30; // "DirtyCashModel"
            inline constexpr std::uintptr_t unlockedVendorTreeNodes = 0x38; // "UnlockedVendorTreeNodesModel"
            inline constexpr std::uintptr_t playerPublicId = 0x40; // "long"
            inline constexpr std::uintptr_t settlementBonusModel = 0x48; // "SettlementBonusModel"
            inline constexpr std::uintptr_t battleMode = 0x50; // "BattleModeDescription"
            inline constexpr std::uintptr_t settlementModel = 0x58; // "RegionUserSettlementModel"
            inline constexpr std::uintptr_t realmVersion = 0x60; // "RealmVersion"
            inline constexpr std::uintptr_t lastCoins = 0x64; // "Nullable<int>"
            inline constexpr std::uintptr_t wasBlocked = 0x6C; // "bool"
            inline constexpr std::uintptr_t wasLockByLocationTier = 0x6D; // "bool"
            inline constexpr std::uintptr_t wasLockByVendorTree = 0x6E; // "bool"
            inline constexpr std::uintptr_t wasBuyItem = 0x70; // "InventoryItemDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA087E0; // "public void Update()"
        }
    } // namespace TraderCellBlockUpdater

    namespace TraderConfig { // "Models.References.Trader.TraderConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t GetCashItemCountExpiringResource = 0x10; // "ExpiringResourceDescription"
            inline constexpr std::uintptr_t IsBlockedUnderRaid = 0x18; // "bool"
        }
    } // namespace TraderConfig

    namespace TraderDescription { // "Models.References.TraderDescription (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t CountBaseSellPrice = 0x405C3C0; // "public static int CountBaseSellPrice(InventoryItemDescription item, int count, int ammo, int durability)"
            inline constexpr std::uintptr_t CheckBuyItem = 0x405C230; // "public static bool CheckBuyItem(InventoryItemDescription item, int count, TraderInventoryDescription traderInventoryDescription, long playerPublicId, SettlementBonusModel settlementBonusModel, InventoryItemsSearchSources itemsSearchSources, InventoryItemsSearchResult itemsSearchResult)"
            inline constexpr std::uintptr_t GetBuyPrice = 0x405C490; // "public static int GetBuyPrice(TraderInventoryDescription traderInventoryDescription, InventoryItemDescription itemDescription, long publicId, SettlementBonusModel settlementBonusModel)"
            inline constexpr std::uintptr_t IsTraderItemLockedByVendorTree = 0x405C920; // "public static bool IsTraderItemLockedByVendorTree(TraderInventoryDescription traderInventoryDescription, InventoryItemDescription item, RealmVersion realmVersion, out VendorTreeNodeDescription node)"
            inline constexpr std::uintptr_t GetTraderBuyItemByUnlockedVendorTree = 0x405C6D0; // "public static InventoryItemDescription GetTraderBuyItemByUnlockedVendorTree(InventoryItemDescription item, UnlockedVendorTreeNodesModel unlockedVendorTreeNodes, LocationDescription location, RealmVersion realmVersion)"
            inline constexpr std::uintptr_t TryGetLastUnlockedWeaponMkVersionItem = 0x405C970; // "private static bool TryGetLastUnlockedWeaponMkVersionItem(WeaponDescription sourceWeapon, UnlockedVendorTreeNodesModel unlockedVendorTreeNodes, RealmVersion realmVersion, out InventoryItemDescription lastUnlockedWeaponMkVersionItem)"
            inline constexpr std::uintptr_t CheckPlayerRole = 0x405C330; // "public static bool CheckPlayerRole(TraderInventoryDescription traderInventoryDescription, PlayerRoleDescription role)"
        }
    } // namespace TraderDescription

    namespace TradeRestrictedCellsModelUpdater { // "Game.Battle.Inventory.RestrictedCells.TradeRestrictedCellsModelUpdater (Battle.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0x9F7740; // "public TradeRestrictedCellsModelUpdater Init(BattleCharacterModel battleCharacterModel, RestrictedCellsModel restrictedCellsModel)"
            inline constexpr std::uintptr_t GetIsActive = 0xA6F7B0; // "protected override bool GetIsActive(IInventoryItemModel itemModel)"
        }
    } // namespace TradeRestrictedCellsModelUpdater

    namespace TraderInventoryConfig { // "Models.References.Trader.TraderInventoryConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t LaptopFunc = 0x10; // "Func<TraderInventoryDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Laptop = 0x1765CB0; // "public TraderInventoryDescription get_Laptop()"
        }
    } // namespace TraderInventoryConfig

    namespace TraderInventoryDescription { // "Models.References.Trader.TraderInventoryDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t BuyPriceModifier = 0x20; // "float"
            inline constexpr std::uintptr_t IsVendorTreeLocked = 0x24; // "bool"
            inline constexpr std::uintptr_t ItemsWithoutTierLazy = 0x28; // "Lazy<IReadOnlyList<InventoryItemDescription>>"
            inline constexpr std::uintptr_t ItemsListsByTiersLazy = 0x30; // "Lazy<IReadOnlyDictionary<TierDescription, IReadOnlyList<InventoryItemDescription>>>"
            inline constexpr std::uintptr_t RequiredPlayerRolesLazy = 0x38; // "Lazy<HashSet<PlayerRoleDescription>>"
            inline constexpr std::uintptr_t AllItemsLazy = 0x40; // "Lazy<IReadOnlyList<InventoryItemDescription>>"
            inline constexpr std::uintptr_t ItemToTierLazy = 0x48; // "Lazy<IReadOnlyDictionary<InventoryItemDescription, TierDescription>>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_ItemsWithoutTier = 0x4074500; // "public IReadOnlyList<InventoryItemDescription> get_ItemsWithoutTier()"
            inline constexpr std::uintptr_t get_ItemsListsByTiers = 0x40744B0; // "public IReadOnlyDictionary<TierDescription, IReadOnlyList<InventoryItemDescription>> get_ItemsListsByTiers()"
            inline constexpr std::uintptr_t get_RequiredPlayerRoles = 0x4074550; // "public HashSet<PlayerRoleDescription> get_RequiredPlayerRoles()"
            inline constexpr std::uintptr_t get_AllItems = 0x4074350; // "public IReadOnlyList<InventoryItemDescription> get_AllItems()"
            inline constexpr std::uintptr_t get_ItemToTier = 0x4074460; // "public IReadOnlyDictionary<InventoryItemDescription, TierDescription> get_ItemToTier()"
            inline constexpr std::uintptr_t get_IsCategoryTrader = 0x40743A0; // "public bool get_IsCategoryTrader()"
        }
    } // namespace TraderInventoryDescription

    namespace TraderInventoryDescriptionExtensions { // "Models.Utils.Extensions.TraderInventoryDescriptionExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t CheckItemRequiredTierByPlayerSector = 0x396FE30; // "public static bool CheckItemRequiredTierByPlayerSector(TierDescription requiredTier, SectorDescription playerSector, RealmVersion realmVersion)"
            inline constexpr std::uintptr_t GetSettlementTierIndex = 0x396FEF0; // "public static int GetSettlementTierIndex(TierDescription settlementTier)"
        }
    } // namespace TraderInventoryDescriptionExtensions

    namespace TraderInventoryModel { // "Game.Battle.TraderInventory.TraderInventoryModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Trader = 0x10; // "LocationNpcDescription"
            inline constexpr std::uintptr_t Description = 0x18; // "InventoryCellsSizeDescription"
            inline constexpr std::uintptr_t TraderSlots = 0x20; // "TraderSlotsModel"
            inline constexpr std::uintptr_t locationDescription = 0x28; // "LocationDescription"
            inline constexpr std::uintptr_t battleMode = 0x30; // "BattleModeDescription"
            inline constexpr std::uintptr_t settlementModel = 0x38; // "RegionUserSettlementModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Slots = 0x7AB150; // "public IInventorySlotsModel get_Slots()"
            inline constexpr std::uintptr_t get_LinesCount = 0xD947E0; // "public int get_LinesCount()"
            inline constexpr std::uintptr_t get_TakeOnlyLinesCount = 0x7E3AB0; // "public int get_TakeOnlyLinesCount()"
            inline constexpr std::uintptr_t TryGetSlot = 0xD94580; // "public bool TryGetSlot(InventorySlotDescription slot, out IInventorySlotModel slotModel)"
            inline constexpr std::uintptr_t CanBuyItemOnLocation = 0xD943F0; // "public bool CanBuyItemOnLocation(BuyItemSlotModel buyItemSlotModel, RealmVersion realmVersion)"
            inline constexpr std::uintptr_t GetBuyItem = 0xD944D0; // "public BuyItemSlotModel GetBuyItem(InventorySlotDescription slot)"
        }
    } // namespace TraderInventoryModel

    namespace TraderItemMoveContext { // "Game.Battle.Inventory.TraderItemMoveContext (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Slot = 0x10; // "IInventorySlotModel"
            inline constexpr std::uintptr_t BuyItemSlotModel = 0x18; // "BuyItemSlotModel"
            inline constexpr std::uintptr_t TraderInventory = 0x20; // "TraderInventoryModel"
            inline constexpr std::uintptr_t Inventory = 0x28; // "IInventoryModel"
            inline constexpr std::uintptr_t EntityId = 0x30; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_ItemModel = 0xA27E60; // "public IInventoryItemModel get_ItemModel()"
            inline constexpr std::uintptr_t get_RevealContainerModel = 0xA27EB0; // "public IRevealContainerModel get_RevealContainerModel()"
            inline constexpr std::uintptr_t get_Revealed = 0x7D5050; // "public bool get_Revealed()"
            inline constexpr std::uintptr_t get_Count = 0xA27D10; // "public int get_Count()"
            inline constexpr std::uintptr_t get_Ammo = 0xA27CA0; // "public int get_Ammo()"
            inline constexpr std::uintptr_t get_Durability = 0xA27DF0; // "public int get_Durability()"
            inline constexpr std::uintptr_t get_CumulativePoints = 0xA27D80; // "public int get_CumulativePoints()"
            inline constexpr std::uintptr_t GetBuyCount = 0xA27B10; // "public int GetBuyCount(bool alwaysFullStack)"
        }
    } // namespace TraderItemMoveContext

    namespace TraderSlotsModel { // "Game.Battle.TraderInventory.TraderSlotsModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t traderModel = 0x18; // "Dictionary<InventorySlotDescription, BuyItemSlotModel>"
            inline constexpr std::uintptr_t TierSlotPositions = 0x20; // "List<ValueTuple<TierDescription, int, int>>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetGroupPosition = 0xD94C90; // "public void SetGroupPosition(TierDescription tier, int startLine, int lineCount)"
            inline constexpr std::uintptr_t Set = 0xD94DA0; // "public void Set(IInventorySlotModel slot, InventoryItemDescription buyItemDescription, int buyItemIndex, TierDescription tier)"
            inline constexpr std::uintptr_t Clear = 0xD94800; // "public void Clear()"
            inline constexpr std::uintptr_t GetBuyItem = 0xD94C30; // "public BuyItemSlotModel GetBuyItem(InventorySlotDescription index)"
            inline constexpr std::uintptr_t get_Item = 0xD95290; // "public IInventorySlotModel get_Item(int index)"
        }
    } // namespace TraderSlotsModel

    namespace TraderSlotsPackUpdater { // "Game.Battle.Laptop.ShopBuy.TraderSlotsPackUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t inventoryModel = 0x10; // "TraderInventoryModel"
            inline constexpr std::uintptr_t traderInventoryDescription = 0x18; // "TraderInventoryDescription"
            inline constexpr std::uintptr_t dialogModel = 0x20; // "LaptopDialogModel"
            inline constexpr std::uintptr_t cache = 0x28; // "List<ValueTuple<InventoryItemDescription, int>>"
            inline constexpr std::uintptr_t categoryItems = 0x30; // "List<ValueTuple<InventoryItemDescription, int>>"
            inline constexpr std::uintptr_t observer = 0x38; // "IDataObserver"
            inline constexpr std::uintptr_t unlockedVendorTreeNodesModel = 0x40; // "UnlockedVendorTreeNodesModel"
            inline constexpr std::uintptr_t battleCharacterModel = 0x48; // "BattleCharacterModel"
            inline constexpr std::uintptr_t location = 0x50; // "LocationDescription"
            inline constexpr std::uintptr_t realmVersion = 0x58; // "RealmVersion"
            inline constexpr std::uintptr_t replicationClock = 0x60; // "ReplicationClock"
            inline constexpr std::uintptr_t showcaseView = 0x68; // "TraderShowcaseView"
            inline constexpr std::uintptr_t currentFilter = 0x70; // "ValueTuple<int, int>"
            inline constexpr std::uintptr_t imprisonmentYears = 0x78; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x9F3770; // "public void Update()"
            inline constexpr std::uintptr_t RepackSlotsWithFilters = 0x9F29A0; // "private void RepackSlotsWithFilters()"
            inline constexpr std::uintptr_t LastLine = 0x9F25C0; // "private int LastLine(int lastLine, TierDescription tier)"
            inline constexpr std::uintptr_t RepackSlotsWithoutFilters = 0x9F3360; // "private void RepackSlotsWithoutFilters()"
            inline constexpr std::uintptr_t AddNewFilterCash = 0x9F2240; // "private void AddNewFilterCash()"
            inline constexpr std::uintptr_t IsLockedByImprisonmentYears = 0x9F2550; // "private bool IsLockedByImprisonmentYears(InventoryItemDescription item)"
            inline constexpr std::uintptr_t PackItemsToSlotsFromLine = 0x9F2670; // "private int PackItemsToSlotsFromLine(List<ValueTuple<InventoryItemDescription, int>> items, int startLine)"
        }
    } // namespace TraderSlotsPackUpdater

    namespace TraderSplitDescriptionTextUpdater { // "Game.Battle.ShopSplit.TraderSplitDescriptionTextUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t description = 0x10; // "Text<int, Money, bool>"
            inline constexpr std::uintptr_t buttonBuy = 0x18; // "Text<Money, string>"
            inline constexpr std::uintptr_t shopSplitModel = 0x20; // "ShopSplitModel"
            inline constexpr std::uintptr_t laptopDirtyCashModel = 0x28; // "DirtyCashModel"
            inline constexpr std::uintptr_t currentCost = 0x30; // "int"
            inline constexpr std::uintptr_t currentCount = 0x34; // "int"
            inline constexpr std::uintptr_t enoughMoneyColor = 0x38; // "string"
            inline constexpr std::uintptr_t notEnoughMoneyColor = 0x40; // "string"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x9F3CC0; // "public void Update()"
        }
    } // namespace TraderSplitDescriptionTextUpdater

    namespace TraderSplitSliderDialogRules { // "Game.Battle.Inventory.ShopSplit.TraderSplitSliderDialogRules (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t modalDialogModel = 0x10; // "ModalDialogModel"
            inline constexpr std::uintptr_t battleScreenContent = 0x18; // "BattleScreenContent"
            inline constexpr std::uintptr_t globalScreenContent = 0x20; // "GlobalScreenContent"
            inline constexpr std::uintptr_t shopSplitModel = 0x28; // "ShopSplitModel"
            inline constexpr std::uintptr_t laptopDirtyCashModel = 0x30; // "DirtyCashModel"
            inline constexpr std::uintptr_t inputActions = 0x38; // "InputActions"
            inline constexpr std::uintptr_t playerEntityModel = 0x40; // "PlayerEntityModel"
            inline constexpr std::uintptr_t itemViewDescriptions = 0x48; // "InventoryItemViewDescriptions"
        }
        namespace Methods {
            inline constexpr std::uintptr_t OpenSliderDialog = 0xA6F8D0; // "public void OpenSliderDialog(int minSliderValue, int maxSliderValue, int currentSliderValue)"
            inline constexpr std::uintptr_t Buy = 0xA6F870; // "private void Buy(SliderInputFieldModel model)"
            inline constexpr std::uintptr_t BuyValidator = 0xA6F800; // "private bool BuyValidator()"
        }
    } // namespace TraderSplitSliderDialogRules

    namespace TraderTargetActions { // "Game.Battle.Entities.Npc.TraderTargetActions (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleModel = 0x10; // "BattleModel"
            inline constexpr std::uintptr_t npcModel = 0x18; // "BattleNpcModel"
            inline constexpr std::uintptr_t personalNotificationModel = 0x20; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t uiSoundModel = 0x28; // "GlobalUISoundModel"
            inline constexpr std::uintptr_t npcView = 0x30; // "NpcView"
            inline constexpr std::uintptr_t clientCodexModel = 0x38; // "ClientCodexModel"
            inline constexpr std::uintptr_t talkViewDescriptions = 0x40; // "TalkViewDescriptions"
            inline constexpr std::uintptr_t TradeAction = 0x48; // "TargetAction"
            inline constexpr std::uintptr_t TalkAction = 0x50; // "TargetAction"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Trade = 0xB41CA0; // "private void Trade()"
            inline constexpr std::uintptr_t Talk = 0xB41BB0; // "private void Talk()"
            inline constexpr std::uintptr_t Unavailable = 0x9CDF30; // "private void Unavailable(LocalizedString invalidNotification, PersonalNotificationActionIds id)"
        }
    } // namespace TraderTargetActions

    namespace TraderTargetProvider { // "Game.Battle.Entities.Npc.TraderTargetProvider (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t view = 0x20; // "NpcView"
            inline constexpr std::uintptr_t npcModel = 0x28; // "BattleNpcModel"
            inline constexpr std::uintptr_t traderTargetActions = 0x30; // "TraderTargetActions"
            inline constexpr std::uintptr_t talkViewDescriptions = 0x38; // "TalkViewDescriptions"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x40; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t unavailableKeys = 0x48; // "UnavailableTargetActionsKeys"
            inline constexpr std::uintptr_t talkInappropriateRoleNotify = 0x50; // "LocalizedString"
        }
        namespace Methods {
            inline constexpr std::uintptr_t FillTargetActions = 0xB421D0; // "protected internal override void FillTargetActions(List<ITargetAction> actions)"
            inline constexpr std::uintptr_t GetTraderRequiredPlayerRole = 0xB42810; // "private bool GetTraderRequiredPlayerRole(TraderInventoryDescription traderInventory, out PlayerRoleDescription requiredRole)"
        }
    } // namespace TraderTargetProvider

    namespace TrunkRestrictedCellsModelUpdater { // "Game.Battle.Inventory.RestrictedCells.TrunkRestrictedCellsModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t trunkUIView = 0x30; // "TrunkDialogView"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0x998C80; // "public TrunkRestrictedCellsModelUpdater Init(BattleCharacterModel battleCharacterModel, RestrictedCellsModel restrictedCellsModel, TrunkDialogView trunkUIView)"
            inline constexpr std::uintptr_t Dispose = 0x9F6DA0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t GetIsActive = 0xA6FFC0; // "protected override bool GetIsActive(IInventoryItemModel itemModel)"
        }
    } // namespace TrunkRestrictedCellsModelUpdater

    namespace UnloadAmmoItemAction { // "Game.Battle.Inventory.UnloadAmmoItemAction (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t From = 0x0; // "IItemMoveContext"
        }
    } // namespace UnloadAmmoItemAction

    namespace UnloadAmmoModel { // "Models.Inventory.UnloadAmmo.UnloadAmmo.UnloadAmmoModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ammoItemsModel = 0x10; // "AmmoItemsModel"
            inline constexpr std::uintptr_t refilledSlots = 0x18; // "int[]"
            inline constexpr std::uintptr_t freeSlots = 0x20; // "int[]"
            inline constexpr std::uintptr_t occupiedSlots = 0x28; // "bool[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t TryFindSlotsForAmmo = 0x4A632A0; // "public bool TryFindSlotsForAmmo(IInventoryModel inventoryModel, InventoryItemDescription ammoItem, int ammo, out int refilledSlotsCount, out int[] refilledSlots, out int freeSlotsCount, out int[] freeSlots)"
            inline constexpr std::uintptr_t IsSlotOccupied = 0x4A631A0; // "private bool IsSlotOccupied(int index)"
            inline constexpr std::uintptr_t SetSlotIsBusy = 0x4A631D0; // "private void SetSlotIsBusy(InventoryCellsSizeDescription inventoryCellsSizeDescription, InventoryItemDescription item, int itemIndex)"
            inline constexpr std::uintptr_t ClearBusySlots = 0x4A63120; // "private void ClearBusySlots(bool[] busySlots)"
            inline constexpr std::uintptr_t GetWeaponAmmoItem = 0x4A63160; // "public InventoryItemDescription GetWeaponAmmoItem(WeaponDescription weapon)"
        }
    } // namespace UnloadAmmoModel

    namespace UnsetInventoryInputUpdater { // "Game.Battle.Inventory.UnsetInventoryInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dragAndDropModel = 0x10; // "InventoryDragAndDropModel"
            inline constexpr std::uintptr_t inventoryBorder = 0x18; // "RectTransform"
            inline constexpr std::uintptr_t unsetItemMoveModel = 0x20; // "UnsetItemMoveModel"
            inline constexpr std::uintptr_t personalNotificationModel = 0x28; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t localizationKeys = 0x30; // "LocalizationKeys"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x38; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t uiCamera = 0x40; // "Camera"
            inline constexpr std::uintptr_t isDragStarted = 0x48; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA281D0; // "public void Update()"
            inline constexpr std::uintptr_t ContainsPosition = 0xA27F40; // "private bool ContainsPosition(RectTransform rectTransform, Vector3 point)"
        }
    } // namespace UnsetInventoryInputUpdater

    namespace UnsetItemAction { // "Game.Battle.Inventory.UnsetItemAction (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t From = 0x0; // "IItemMoveContext"
        }
    } // namespace UnsetItemAction

    namespace UnsetItemMoveModel { // "Game.Battle.Inventory.UnsetItemMoveModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t From = 0x10; // "IItemMoveContext"
        }
    } // namespace UnsetItemMoveModel

    namespace UnsetItemUpdater { // "Game.Battle.Inventory.UnsetItemUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "ItemMoveModel"
            inline constexpr std::uintptr_t unsetItemMoveModel = 0x18; // "UnsetItemMoveModel"
            inline constexpr std::uintptr_t laptopDialogModel = 0x20; // "LaptopDialogModel"
            inline constexpr std::uintptr_t modalDialogModel = 0x28; // "ModalDialogModel"
            inline constexpr std::uintptr_t inventoryKeys = 0x30; // "InventoryKeys"
            inline constexpr std::uintptr_t globalScreenContent = 0x38; // "GlobalScreenContent"
            inline constexpr std::uintptr_t inputActions = 0x40; // "InputActions"
            inline constexpr std::uintptr_t playerPrefsModel = 0x48; // "PlayerPrefsModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA707D0; // "public void Update()"
            inline constexpr std::uintptr_t OnUnset = 0xA70730; // "private void OnUnset(IItemMoveContext from)"
        }
    } // namespace UnsetItemUpdater

    namespace UsableItemCooldownModel { // "Models.Models.UsableItemCooldown.UsableItemCooldownModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t models = 0x10; // "Dictionary<UsableItemTypeDescription, IPrimitiveModel<long>>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Item = 0x48CBB50; // "public IPrimitiveModel<long> get_Item(UsableItemTypeDescription description)"
            inline constexpr std::uintptr_t CheckOnCooldown = 0x48CB8A0; // "public bool CheckOnCooldown(UsableItemTypeDescription description, long now)"
        }
    } // namespace UsableItemCooldownModel

    namespace UsableItemDescription { // "Models.References.Inventory.UsableItemDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t TypeFunc = 0x20; // "Func<UsableItemTypeDescription>"
            inline constexpr std::uintptr_t TakeInTime = 0x28; // "long"
            inline constexpr std::uintptr_t CastTime = 0x30; // "long"
            inline constexpr std::uintptr_t PostCastTime = 0x38; // "long"
            inline constexpr std::uintptr_t CanUseInMove = 0x40; // "bool"
            inline constexpr std::uintptr_t CanUseAutoRepeat = 0x41; // "bool"
            inline constexpr std::uintptr_t AllowToChangeCrouchState = 0x42; // "bool"
            inline constexpr std::uintptr_t IsInterruptByJumpInput = 0x43; // "bool"
            inline constexpr std::uintptr_t CharacterSpeed = 0x48; // "CharacterSpeed"
            inline constexpr std::uintptr_t CharacterAnimatorLayerFunc = 0x50; // "Func<BattleCharacterAnimatorLayerDescription>"
            inline constexpr std::uintptr_t CastSpecialCharacterAnimatorStateFunc = 0x58; // "Func<BattleCharacterAnimatorStateDescription>"
            inline constexpr std::uintptr_t PostCastSpecialCharacterAnimatorStateFunc = 0x60; // "Func<BattleCharacterAnimatorStateDescription>"
            inline constexpr std::uintptr_t HealItemFunc = 0x68; // "Func<HealItemDescription>"
            inline constexpr std::uintptr_t TimeEffectFunc = 0x70; // "Func<TimeEffectDescription>"
            inline constexpr std::uintptr_t RestoreArmorFunc = 0x78; // "Func<RestoreArmorDescription>"
            inline constexpr std::uintptr_t IsNotFullHealthRequired = 0x80; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x9D6230; // "public UsableItemTypeDescription get_Type()"
            inline constexpr std::uintptr_t get_CharacterAnimatorLayer = 0x1CE7810; // "public BattleCharacterAnimatorLayerDescription get_CharacterAnimatorLayer()"
            inline constexpr std::uintptr_t get_CastSpecialCharacterAnimatorState = 0x4048FB0; // "public BattleCharacterAnimatorStateDescription get_CastSpecialCharacterAnimatorState()"
            inline constexpr std::uintptr_t get_PostCastSpecialCharacterAnimatorState = 0x4048EC0; // "public BattleCharacterAnimatorStateDescription get_PostCastSpecialCharacterAnimatorState()"
            inline constexpr std::uintptr_t get_HealItem = 0x4048EF0; // "public HealItemDescription get_HealItem()"
            inline constexpr std::uintptr_t get_TimeEffect = 0x4048F80; // "public TimeEffectDescription get_TimeEffect()"
            inline constexpr std::uintptr_t get_RestoreArmor = 0x4048F20; // "public RestoreArmorDescription get_RestoreArmor()"
            inline constexpr std::uintptr_t get_IsRestoreArmor = 0x4402A50; // "public bool get_IsRestoreArmor()"
            inline constexpr std::uintptr_t get_IsHealItem = 0x43E8630; // "public bool get_IsHealItem()"
            inline constexpr std::uintptr_t get_IsTimeEffectItem = 0x4402A90; // "public bool get_IsTimeEffectItem()"
        }
    } // namespace UsableItemDescription

    namespace UsableItemModel { // "Models.Models.UsableItem.UsableItemModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t itemInHands = 0x10; // "IInventoryItemModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_HasValue = 0x48CBBB0; // "public bool get_HasValue()"
            inline constexpr std::uintptr_t get_Value = 0x48CBC30; // "public UsableItemDescription get_Value()"
        }
    } // namespace UsableItemModel

    namespace UsableItemNotificationKeys { // "Game.Battle.BattleScreenContentDirectory.Localization.UsableItemNotificationKeys (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t CantUseHealItemWithFullHealth = 0x10; // "LocalizedString"
            inline constexpr std::uintptr_t CantUseArmorPlateWithFullArmor = 0x18; // "LocalizedString"
            inline constexpr std::uintptr_t CantUseArmorPlateWithoutArmor = 0x20; // "LocalizedString"
            inline constexpr std::uintptr_t CantUseInPeaceZone = 0x28; // "LocalizedString"
        }
    } // namespace UsableItemNotificationKeys

    namespace UsableItemRules { // "Models.Models.UsableItem.UsableItemRules (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t CheckUseItemInHands = 0x48CBFE0; // "public static bool CheckUseItemInHands(PlayerRoleDescription role, UsableItemModel usableItemModel, UsableItemCooldownModel cooldownModel, long now, HealthModel health, ArmorModel armorModel)"
            inline constexpr std::uintptr_t CheckUseItemByContextMenu = 0x48CBE30; // "public static bool CheckUseItemByContextMenu(PlayerRoleDescription role, QuickSlotDescription targetQuickSlot, InventorySlotDescription inventorySlotTarget, IPocketsModel pocketsModel, IInventoryModel inventoryModel, UsableItemCooldownModel cooldownModel, long now, HealthModel health, ArmorModel armorModel)"
            inline constexpr std::uintptr_t TryGetItemForUse = 0x48CC340; // "public static bool TryGetItemForUse(QuickSlotDescription quickSlotTarget, InventorySlotDescription inventorySlotTarget, IPocketsModel pocketsModel, IInventoryModel inventoryModel, out InventoryItemDescription item)"
            inline constexpr std::uintptr_t CheckUseItem = 0x48CC190; // "public static bool CheckUseItem(long now, PlayerRoleDescription role, UsableItemDescription usableItem, HealthModel healthModel, ArmorModel armorModel)"
            inline constexpr std::uintptr_t IsHealItem = 0x48CC2C0; // "public static bool IsHealItem(UsableItemDescription usableItem)"
            inline constexpr std::uintptr_t IsArmorPlateItem = 0x48CC2A0; // "public static bool IsArmorPlateItem(UsableItemDescription usableItem)"
            inline constexpr std::uintptr_t CheckUseHealItem = 0x48CBDD0; // "public static bool CheckUseHealItem(PlayerRoleDescription role, UsableItemDescription usableItem, HealthModel healthModel)"
            inline constexpr std::uintptr_t CheckRestoreVestArmor = 0x48CBC90; // "public static bool CheckRestoreVestArmor(long now, ArmorModel armorModel)"
            inline constexpr std::uintptr_t CheckRestoreVestArmor_2 = 0x48CBD10; // "public static bool CheckRestoreVestArmor(InventoryItemDescription vestItem, IDurabilityModel vestDurabilityModel, IAmmoModel vestAmmoModel)"
            inline constexpr std::uintptr_t IsVestArmorMax = 0x48CC320; // "private static bool IsVestArmorMax(int amount, ArmorDescription armorDescription)"
        }
    } // namespace UsableItemRules

    namespace UsableItemTypeDescription { // "Models.References.Inventory.UsableItemTypeDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Cooldown = 0x20; // "long"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_HasCooldown = 0x36639B0; // "public bool get_HasCooldown()"
        }
    } // namespace UsableItemTypeDescription

    namespace UseConsumableItemAction { // "Game.Battle.Inventory.UseConsumableItemAction (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t From = 0x0; // "IItemMoveContext"
            inline constexpr std::uintptr_t InventoryEntityId = 0x8; // "int"
        }
    } // namespace UseConsumableItemAction

    namespace UseItemModel { // "Game.Battle.Inventory.UseItemModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t NewInput = 0x10; // "IUseItemAction"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_HasNewInput = 0xA18FC0; // "public bool get_HasNewInput()"
            inline constexpr std::uintptr_t Clear = 0xA18FA0; // "public void Clear()"
        }
    } // namespace UseItemModel

    namespace UseItemModelUpdater { // "Game.Battle.InventoryContainer.UseItemModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t useItemModel = 0x20; // "UseItemModel"
            inline constexpr std::uintptr_t battleInputModel = 0x28; // "BattleInputModel"
            inline constexpr std::uintptr_t battleCharacterModel = 0x30; // "BattleCharacterModel"
            inline constexpr std::uintptr_t personalNotificationModel = 0x38; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t unavailableTargetActionsKeys = 0x40; // "UnavailableTargetActionsKeys"
            inline constexpr std::uintptr_t inBattleSettingsModel = 0x48; // "InBattleSettingsModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0x9F4E70; // "public UseItemModelUpdater Init(GlobalModel globalModel, UseItemModel useItemModel, BattleInputModel battleInputModel, BattleCharacterModel battleCharacterModel, UnavailableTargetActionsKeys unavailableTargetActionsKeys)"
            inline constexpr std::uintptr_t Dispose = 0x9F4DE0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0x9F56C0; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t ItemUse = 0x9F52B0; // "private void ItemUse(IItemMoveContext from)"
            inline constexpr std::uintptr_t WeaponReloading = 0x9F5A60; // "private void WeaponReloading(IItemMoveContext from, IItemMoveContext to)"
            inline constexpr std::uintptr_t InventoryItemInput = 0x9F4F10; // "private void InventoryItemInput(IItemMoveContext from, IItemMoveContext to)"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace UseItemModelUpdater

    namespace VehicleRestrictedCellsModelUpdater { // "Game.Battle.Inventory.RestrictedCells.VehicleRestrictedCellsModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t isValidItem = 0x30; // "Func<IInventoryItemModel, bool>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0x998C80; // "public VehicleRestrictedCellsModelUpdater Init(BattleCharacterModel battleCharacterModel, RestrictedCellsModel restrictedCellsModel, Func<IInventoryItemModel, bool> isValidItem)"
            inline constexpr std::uintptr_t Dispose = 0x9F6DA0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t GetIsActive = 0xA70CC0; // "protected override bool GetIsActive(IInventoryItemModel itemModel)"
        }
    } // namespace VehicleRestrictedCellsModelUpdater

    namespace VendorTreeTargetActions { // "Game.Battle.Entities.HubTrader.VendorTreeTargetActions (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t globalModel = 0x10; // "GlobalModel"
            inline constexpr std::uintptr_t vendorTreeDialogModel = 0x18; // "VendorTreeDialogModel"
            inline constexpr std::uintptr_t OpenAction = 0x20; // "TargetAction"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Open = 0xB72990; // "private void Open()"
            inline constexpr std::uintptr_t Unavailable = 0x957930; // "private void Unavailable(LocalizedString invalidNotification, PersonalNotificationActionIds id)"
        }
    } // namespace VendorTreeTargetActions

    namespace VendorTreeTargetProvider { // "Game.Battle.Entities.HubTrader.VendorTreeTargetProvider (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleModel = 0x20; // "BattleModel"
            inline constexpr std::uintptr_t actions = 0x28; // "VendorTreeTargetActions"
            inline constexpr std::uintptr_t unavailableKeys = 0x30; // "UnavailableTargetActionsKeys"
        }
        namespace Methods {
            inline constexpr std::uintptr_t FillTargetActions = 0xB72BB0; // "protected internal override void FillTargetActions(List<ITargetAction> actions)"
        }
    } // namespace VendorTreeTargetProvider

    namespace WeaponItemTypeViewDescription { // "Game.Battle.Inventory.WeaponItemTypeViewDescription (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Damage = 0x38; // "LocalizedString"
            inline constexpr std::uintptr_t DamageValue = 0x40; // "LocalizedString"
            inline constexpr std::uintptr_t FireRate = 0x48; // "LocalizedString"
            inline constexpr std::uintptr_t Magazine = 0x50; // "LocalizedString"
            inline constexpr std::uintptr_t AmmoSymbol = 0x58; // "string"
            inline constexpr std::uintptr_t weaponType = 0x60; // "WeaponItemTypeViewDescription.WeaponType"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x354E900; // "public override InventoryItemType get_Type()"
        }
    } // namespace WeaponItemTypeViewDescription

    namespace WeaponPreset { // "Models.References.Inventory.WeaponPreset (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t WeaponFunc = 0x10; // "Func<InventoryItemDescription>"
            inline constexpr std::uintptr_t AmmoStacksCount = 0x18; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Weapon = 0x1765CB0; // "public InventoryItemDescription get_Weapon()"
        }
    } // namespace WeaponPreset

    namespace WeaponReloadingAction { // "Game.Battle.Inventory.WeaponReloadingAction (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t From = 0x10; // "IItemMoveContext"
            inline constexpr std::uintptr_t To = 0x18; // "IItemMoveContext"
        }
    } // namespace WeaponReloadingAction

    namespace WorkbenchSpeedupExtensions { // "Models.Utils.Extensions.WorkbenchSpeedupExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t CalculateDurationWithSpeedup = 0x3976F50; // "public static long CalculateDurationWithSpeedup(double baseDuration, float speedupPercent)"
            inline constexpr std::uintptr_t GetSpeedupModifiers = 0x39770A0; // "public static float GetSpeedupModifiers(CargoOpenWorkbenchModel cargoOpenWorkbenchModel, SettlementBonusModel settlementBonusModel)"
            inline constexpr std::uintptr_t GetSpeedupModifiers_2 = 0x3977870; // "public static float GetSpeedupModifiers(CargoExchangeWorkbenchModel cargoExchangeWorkbenchModel)"
            inline constexpr std::uintptr_t GetSpeedupModifiers_3 = 0x3977040; // "public static float GetSpeedupModifiers(CargoChargeWorkbenchModel cargoChargeWorkbenchModel, SettlementBonusModel settlementBonusModel)"
            inline constexpr std::uintptr_t GetUpgradesSpeedupModifiers = 0x3977D30; // "public static float GetUpgradesSpeedupModifiers(CargoChargeWorkbenchModel cargoChargeWorkbenchModel)"
            inline constexpr std::uintptr_t GetSpeedupModifiers_4 = 0x3977AA0; // "public static float GetSpeedupModifiers(CargoProductionWorkbenchDescription cargoProductionWorkbenchDescription, SettlementBonusModel settlementBonusModel)"
            inline constexpr std::uintptr_t GetSpeedupModifiers_5 = 0x39773A0; // "public static float GetSpeedupModifiers(CargoWorkbenchTypeDescription cargoOpenWorkbenchType, SettlementBonusModel settlementBonusModel)"
            inline constexpr std::uintptr_t GetSpeedupModifiers_6 = 0x3977630; // "public static float GetSpeedupModifiers(CargoChargeWorkbenchTypeDescription cargoChargeWorkbenchType, SettlementBonusModel settlementBonusModel)"
            inline constexpr std::uintptr_t CalculateNewEndTsWhenSpeedupChanged = 0x3976F70; // "public static long CalculateNewEndTsWhenSpeedupChanged(float oldSpeedupPercent, float newSpeedupPercent, long now, long oldEndTs, CargoWorkbenchTypeDescription cargoOpenWorkbenchType, SettlementBonusModel settlementBonusModel)"
            inline constexpr std::uintptr_t CalculateNewEndTsWhenSpeedupChanged_2 = 0x3977000; // "public static long CalculateNewEndTsWhenSpeedupChanged(float oldSpeedupPercent, float newSpeedupPercent, long now, long oldEndTs)"
        }
    } // namespace WorkbenchSpeedupExtensions

    namespace WorkbenchUpgrade { // "Game.Battle.ItemType.WorkbenchUpgrade (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Id = 0x10; // "IdentifiedProperty<InventoryItemDescription>"
            inline constexpr std::uintptr_t TooltipDescription = 0x18; // "LocalizedString"
        }
    } // namespace WorkbenchUpgrade

} // namespace Offsets::Inventory_Cargo
