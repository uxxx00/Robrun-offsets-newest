#pragma once
#include <cstdint>

namespace Offsets::Social_Party_Clan {

    namespace AcceptClanInviteMessage { // "Models.Messages.Clan.AcceptClanInviteMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t clanId = 0x20; // "IPrimitiveData<string>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_ClanId = 0x4A16550; // "public string get_ClanId()"
            inline constexpr std::uintptr_t get_Type = 0x4A165A0; // "public override string get_Type()"
        }
    } // namespace AcceptClanInviteMessage

    namespace AcceptPartyMessage { // "Models.Messages.Party.AcceptPartyMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t partyId = 0x20; // "IPrimitiveData<string>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_PartyId = 0x49EF580; // "public string get_PartyId()"
            inline constexpr std::uintptr_t get_Type = 0x49EF5D0; // "public override string get_Type()"
        }
    } // namespace AcceptPartyMessage

    namespace AddUserInBlacklistMessage { // "Models.Messages.Chat.AddUserInBlacklistMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t publicId = 0x20; // "IPrimitiveData<long>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_PublicId = 0x4A16760; // "public long get_PublicId()"
            inline constexpr std::uintptr_t get_Type = 0x4A167B0; // "public override string get_Type()"
        }
    } // namespace AddUserInBlacklistMessage

    namespace AdvanceChatsUpdater { // "Game.Global.Chat.AdvanceChatsUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t chatsModel = 0x10; // "ChatsModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x36AEB00; // "public void Update()"
            inline constexpr std::uintptr_t Advance = 0x36AE8A0; // "private static void Advance(ChatChannelModel channel)"
        }
    } // namespace AdvanceChatsUpdater

    namespace ApproveClanRequestMessage { // "Models.Messages.Clan.ApproveClanRequestMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t publicId = 0x20; // "IPrimitiveData<long>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_PublicId = 0x4A16C60; // "public long get_PublicId()"
            inline constexpr std::uintptr_t get_Type = 0x4A16CB0; // "public override string get_Type()"
        }
    } // namespace ApproveClanRequestMessage

    namespace BadWordsFilterModel { // "Game.Global.Chat.BadWordsFilterModel (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t userRegion = 0x10; // "UserRegionModel"
            inline constexpr std::uintptr_t chatsModel = 0x18; // "ChatsModel"
            inline constexpr std::uintptr_t chatViewDescription = 0x20; // "ChatViewDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetChatViewDescription = 0x7AB190; // "public void SetChatViewDescription(ChatViewDescription chatViewDescription)"
            inline constexpr std::uintptr_t FilterBadWords = 0x36AED70; // "public string FilterBadWords(string message)"
        }
    } // namespace BadWordsFilterModel

    namespace BadWordsPostprocessorViewDescription { // "Game.Global.Chat.BadWordsPostprocessorViewDescription (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t replacement = 0x18; // "string"
            inline constexpr std::uintptr_t patterns = 0x20; // "string[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t ReplaceBadWords = 0x36AEF60; // "public string ReplaceBadWords(string message)"
        }
    } // namespace BadWordsPostprocessorViewDescription

    namespace BattleAddObjectBetMessage { // "Models.Messages.Clan.ClanBattle.BattleAddObjectBetMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t objectType = 0x20; // "IPrimitiveData<ClanConquestObjectTypeDescription>"
            inline constexpr std::uintptr_t amount = 0x28; // "IPrimitiveData<int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_ObjectType = 0x4A17570; // "public ClanConquestObjectTypeDescription get_ObjectType()"
            inline constexpr std::uintptr_t get_Amount = 0x4A17520; // "public int get_Amount()"
            inline constexpr std::uintptr_t get_Type = 0x4A175C0; // "public override string get_Type()"
        }
    } // namespace BattleAddObjectBetMessage

    namespace BattleChatInputUpdater { // "Game.Battle.Chat.BattleChatInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t inputModel = 0x10; // "InputModel"
            inline constexpr std::uintptr_t battleModel = 0x18; // "BattleModel"
            inline constexpr std::uintptr_t globalModel = 0x20; // "GlobalModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xD0ABC0; // "public void Update()"
        }
    } // namespace BattleChatInputUpdater

    namespace BattleChatRestrictionUpdater { // "Game.Battle.Player.BattleChatRestrictionUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleMode = 0x10; // "BattleModeDescription"
            inline constexpr std::uintptr_t chatRestrictionModel = 0x18; // "ChatRestrictionModel"
            inline constexpr std::uintptr_t battleModel = 0x20; // "BattleModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x95F1C0; // "public void Update()"
        }
    } // namespace BattleChatRestrictionUpdater

    namespace BattleMailClaimAttachmentsStrategy { // "Game.Battle.Mail.BattleMailClaimAttachmentsStrategy (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleMode = 0x10; // "BattleModeDescription"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x18; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t inventory = 0x20; // "IInventoryModel"
            inline constexpr std::uintptr_t changedSlotsInventoryModel = 0x28; // "ChangedSlotsInventoryModel"
            inline constexpr std::uintptr_t equipSlotsModel = 0x30; // "IEquipSlotsModel"
            inline constexpr std::uintptr_t pocketsModel = 0x38; // "IPocketsModel"
            inline constexpr std::uintptr_t claimedSlots = 0x40; // "HashSet<InventorySlotDescription>"
            inline constexpr std::uintptr_t reservedInventorySlots = 0x48; // "Dictionary<InventorySlotDescription, ValueTuple<InventoryItemDescription, int>>"
            inline constexpr std::uintptr_t commandsBuffer = 0x50; // "List<MailClaimItemAttachmentCommand>"
            inline constexpr std::uintptr_t pickupLootResult = 0x58; // "PickupLootResult"
            inline constexpr std::uintptr_t reservedPocketSlots = 0x60; // "Dictionary<PocketSlotDescription, ValueTuple<InventoryItemDescription, int>>"
            inline constexpr std::uintptr_t reservedEquipSlots = 0x68; // "HashSet<int>"
            inline constexpr std::uintptr_t equipSlotModels = 0x70; // "List<IEquipSlotModel>"
            inline constexpr std::uintptr_t wasPockets = 0x78; // "ValueTuple<InventoryItemDescription, int>[]"
            inline constexpr std::uintptr_t wasOccupiedEquipSlots = 0x80; // "ulong"
        }
        namespace Methods {
            inline constexpr std::uintptr_t CanClaimAttachmentsHere = 0x9AC660; // "public bool CanClaimAttachmentsHere()"
            inline constexpr std::uintptr_t CanClaimAttachmentsNow = 0x9AC7A0; // "public bool CanClaimAttachmentsNow()"
            inline constexpr std::uintptr_t InventoryChanged = 0x9AD5E0; // "public bool InventoryChanged()"
            inline constexpr std::uintptr_t UpdateEquipSlots = 0x9ADD50; // "private bool UpdateEquipSlots()"
            inline constexpr std::uintptr_t UpdatePockets = 0x9ADF60; // "private bool UpdatePockets()"
            inline constexpr std::uintptr_t GetPocketState = 0x9AD420; // "private ValueTuple<InventoryItemDescription, int> GetPocketState(int index)"
            inline constexpr std::uintptr_t BuildCommands = 0x9AC2F0; // "public bool BuildCommands(MailModel mail, out IReadOnlyList<MailClaimItemAttachmentCommand> commands)"
            inline constexpr std::uintptr_t FillCommands = 0x9AC800; // "private bool FillCommands(InventoryItemDescription item, int amount, bool isCash, int itemIndex)"
            inline constexpr std::uintptr_t TryClaimFootprint = 0x9AD7C0; // "private bool TryClaimFootprint(InventoryItemDescription item, int anchorIndex)"
            inline constexpr std::uintptr_t TryFindPocketSlot = 0x9ADA10; // "private bool TryFindPocketSlot(InventoryItemDescription item, int amount, out PocketSlotDescription slotDescription, out int refilledAmount)"
        }
    } // namespace BattleMailClaimAttachmentsStrategy

    namespace BattlePartiesUnreleasedSlotsModel { // "Models.Models.BattlePartiesUnreleasedSlots.BattlePartiesUnreleasedSlotsModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t PartiesMarkedForCheck = 0x10; // "HashSet<string>"
            inline constexpr std::uintptr_t UnreleasedSlotsByParty = 0x18; // "Dictionary<string, List<BattleCharacterSlotDescription>>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t AddUnreleasedSlot = 0x49DF9F0; // "public void AddUnreleasedSlot(string partyId, BattleCharacterSlotDescription slot)"
        }
    } // namespace BattlePartiesUnreleasedSlotsModel

    namespace BattlePartyData { // "Models.Data.Party.BattlePartyData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t BecomeRobberReadyCheckEndTs = 0x20; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t BecomeRobberEntityId = 0x28; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t Vehicles = 0x30; // "PartyVehiclesData"
            inline constexpr std::uintptr_t CopRecruitingReadyCheckEndTs = 0x38; // "IPrimitiveData<long>"
        }
    } // namespace BattlePartyData

    namespace BattlePartyFilterDescription { // "Models.References.BattlePartyMode.BattlePartyFilterDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Options = 0x20; // "IReadOnlyList<Func<BattlePartyModeDescription>>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Match = 0x453A810; // "public bool Match(BattlePartyModeDescription partyMode)"
        }
    } // namespace BattlePartyFilterDescription

    namespace BattlePartyMemberData { // "Models.Data.Party.BattlePartyMemberData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t X = 0x20; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t Y = 0x28; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t Z = 0x30; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t RySector = 0x38; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t EntityId = 0x40; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t Health = 0x48; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t Armor = 0x50; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t EquipArmorItem = 0x58; // "IPrimitiveData<InventoryItemDescription>"
            inline constexpr std::uintptr_t PublicRoleDescription = 0x60; // "IPrimitiveData<PlayerRoleDescription>"
            inline constexpr std::uintptr_t HideObjectEntityId = 0x68; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t ArrestTs = 0x70; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t ArrestState = 0x78; // "IPrimitiveData<ArrestStateDescription>"
            inline constexpr std::uintptr_t InterruptArrestingTs = 0x80; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t ReadyCheckStatus = 0x88; // "IPrimitiveData<PartyReadyCheckStatusDescription>"
            inline constexpr std::uintptr_t KnockoutEndTs = 0x90; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t KnockoutPhase = 0x98; // "IPrimitiveData<KnockoutPhaseDescription>"
            inline constexpr std::uintptr_t ReviveEndTs = 0xA0; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t InVehicleSeatSlot = 0xA8; // "IPrimitiveData<VehicleSeatSlotDescription>"
            inline constexpr std::uintptr_t InVehicleType = 0xB0; // "IPrimitiveData<VehicleTypeDescription>"
            inline constexpr std::uintptr_t InVehicleEntityId = 0xB8; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t HasMark = 0xC0; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t MarkX = 0xC8; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t MarkY = 0xD0; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t MarkZ = 0xD8; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t PingMarkType = 0xE0; // "IPrimitiveData<PingMarkTypeDescription>"
            inline constexpr std::uintptr_t PingMarkX = 0xE8; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t PingMarkY = 0xF0; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t PingMarkZ = 0xF8; // "IPrimitiveData<float>"
            inline constexpr std::uintptr_t PingMarkTs = 0x100; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t CharacterControllerState = 0x108; // "IPrimitiveData<CharacterControllerStateDescription>"
            inline constexpr std::uintptr_t SurrenderTs = 0x110; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t ImmuneEndTs = 0x118; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t HoldingCellReleaseTs = 0x120; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t IsCopRewardBoxEmpty = 0x128; // "IPrimitiveData<bool>"
        }
    } // namespace BattlePartyMemberData

    namespace BattlePartyMemberModelsUpdater { // "Game.Battle.BattlePartyMemberModelsUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t partyModel = 0x10; // "PartyModel"
            inline constexpr std::uintptr_t partyMembersData = 0x18; // "BattlePartyMembersData"
            inline constexpr std::uintptr_t partyVehiclesData = 0x20; // "PartyVehiclesData"
            inline constexpr std::uintptr_t characterSlotsModel = 0x28; // "ClientCharacterSlotsModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x30; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t vehicleOwnersModel = 0x38; // "VehicleOwnersModel"
            inline constexpr std::uintptr_t playerBattleModel = 0x40; // "PlayerBattleModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB46680; // "public void Update()"
            inline constexpr std::uintptr_t ClearAllMembersInfo = 0xB46020; // "private void ClearAllMembersInfo()"
            inline constexpr std::uintptr_t UpdateCharacterPosition = 0xB46230; // "private void UpdateCharacterPosition(PartyMemberModel partyMemberModel, int entityId)"
            inline constexpr std::uintptr_t UpdateVehiclePosition = 0xB46420; // "private void UpdateVehiclePosition(PartyMemberModel partyMemberModel)"
        }
    } // namespace BattlePartyMemberModelsUpdater

    namespace BattlePartyUpdater { // "Game.Battle.Party.BattlePartyUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t partyModel = 0x10; // "PartyModel"
            inline constexpr std::uintptr_t battlePartyData = 0x18; // "BattlePartyData"
            inline constexpr std::uintptr_t updater = 0x20; // "IUpdater"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x97C4A0; // "public void Update()"
        }
    } // namespace BattlePartyUpdater

    namespace BlackListDialogInputUpdater { // "Game.Global.Chat.BlackList.BlackListDialogInputUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dialogModel = 0x10; // "BlackListDialogModel"
            inline constexpr std::uintptr_t uiSoundModel = 0x18; // "GlobalUISoundModel"
            inline constexpr std::uintptr_t userRoom = 0x20; // "IRoomConnection"
            inline constexpr std::uintptr_t personalNotificationModel = 0x28; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t chatLocalization = 0x30; // "ChatLocalization"
            inline constexpr std::uintptr_t isRequesting = 0x38; // "bool"
            inline constexpr std::uintptr_t Handlers = 0x40; // "ValueTuple<InputMask, IUpdater>[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t OnClose = 0x36C5300; // "private void OnClose()"
            inline constexpr std::uintptr_t OnRemoveFromBlackListClicked = 0x36C5340; // "private void OnRemoveFromBlackListClicked(long publicId)"
            inline constexpr std::uintptr_t get_Priority = 0x7E5D90; // "public InputHandlerPriority get_Priority()"
        }
    } // namespace BlackListDialogInputUpdater

    namespace BlackListDialogModel { // "Game.Global.Chat.BlackList.BlackListDialogModel (Global.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t Open = 0x3597220; // "public void Open()"
        }
    } // namespace BlackListDialogModel

    namespace BlackListDialogUpdater { // "Game.Global.Chat.BlackList.BlackListDialogUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t updater = 0x10; // "IUpdater"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x36C5890; // "public void Update()"
        }
    } // namespace BlackListDialogUpdater

    namespace BlackListDialogView { // "Game.Global.Chat.BlackList.BlackListDialogView (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t CapacityLabel = 0x20; // "TextLabel<int, int>"
            inline constexpr std::uintptr_t Parent = 0x28; // "RectTransform"
            inline constexpr std::uintptr_t ListState = 0x30; // "EnumStateElement<ChatDialogView.ListState>"
            inline constexpr std::uintptr_t Close = 0x38; // "CompositeButtonView"
        }
    } // namespace BlackListDialogView

    namespace BlackListItemView { // "Game.Global.Chat.BlackList.BlackListItemView (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t NicknameLabel = 0x20; // "TMP_Text"
            inline constexpr std::uintptr_t Button = 0x28; // "CompositeButtonView"
        }
    } // namespace BlackListItemView

    namespace BlackListModel { // "Game.Global.Chat.BlackList.BlackListModel (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "BlacklistData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsMaxCount = 0x36C5E10; // "public bool get_IsMaxCount()"
            inline constexpr std::uintptr_t Contains = 0x36C5DB0; // "public bool Contains(long publicId)"
            inline constexpr std::uintptr_t get_Item = 0x36C5EA0; // "public string get_Item(long publicId)"
            inline constexpr std::uintptr_t get_PublicIds = 0x36C5F20; // "public Dictionary.KeyCollection<long, IPrimitiveData<string>> get_PublicIds()"
        }
    } // namespace BlackListModel

    namespace BlackListViewUpdater { // "Game.Global.Chat.BlackList.BlackListViewUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t wasPublicIds = 0x10; // "long[]"
            inline constexpr std::uintptr_t publicIds = 0x18; // "long[]"
            inline constexpr std::uintptr_t views = 0x20; // "IDisposableContent<BlackListItemView>[]"
            inline constexpr std::uintptr_t template_id = 0x28; // "IComponentInstantiateContent<BlackListItemView>"
            inline constexpr std::uintptr_t view = 0x30; // "BlackListDialogView"
            inline constexpr std::uintptr_t blackListModel = 0x38; // "BlackListModel"
            inline constexpr std::uintptr_t clickablePublicIds = 0x40; // "ClickableItemsModel<long>"
            inline constexpr std::uintptr_t wasCount = 0x48; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x36C6840; // "public void Update()"
            inline constexpr std::uintptr_t RefreshValues = 0x36C64A0; // "private void RefreshValues(int count)"
            inline constexpr std::uintptr_t RefreshCount = 0x36C5F70; // "private void RefreshCount(int count)"
            inline constexpr std::uintptr_t RefreshPublicIds = 0x36C62D0; // "private void RefreshPublicIds(out int count)"
        }
    } // namespace BlackListViewUpdater

    namespace ChangeLeaderPartyMessage { // "Models.Messages.Party.ChangeLeaderPartyMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t publicId = 0x20; // "IPrimitiveData<long>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_PublicId = 0x49F0340; // "public long get_PublicId()"
            inline constexpr std::uintptr_t get_Type = 0x49F0390; // "public override string get_Type()"
        }
    } // namespace ChangeLeaderPartyMessage

    namespace ChangeMemberRankClanMessage { // "Models.Messages.Clan.ChangeMemberRankClanMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t memberPublicId = 0x20; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t rankDescription = 0x28; // "IPrimitiveData<ClanRankDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_MemberPublicId = 0x4A18FD0; // "public long get_MemberPublicId()"
            inline constexpr std::uintptr_t get_RankDescription = 0x4A19020; // "public ClanRankDescription get_RankDescription()"
            inline constexpr std::uintptr_t get_Type = 0x4A190E0; // "public override string get_Type()"
        }
    } // namespace ChangeMemberRankClanMessage

    namespace ChatAccessExtensions { // "Models.Utils.Extensions.ChatAccessExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t HasChatAccess = 0x3940E80; // "public static bool HasChatAccess(int imprisonmentYears, bool hasOwnedSettlements, bool hasPlot)"
        }
    } // namespace ChatAccessExtensions

    namespace ChatAccessRules { // "Game.Global.Chat.ChatAccessRules (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t chatRestrictionModel = 0x10; // "ChatRestrictionModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Apply = 0x36CC000; // "public void Apply(ChatChannelModel channel)"
        }
    } // namespace ChatAccessRules

    namespace ChatAttachmentModel { // "Game.Global.Chat.ChatAttachmentModel (Global.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x81CBF18; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace Fields {
            inline constexpr std::uintptr_t AttachmentType = 0x10; // "ChatAttachmentModel.Type"
            inline constexpr std::uintptr_t UserPublicId = 0x18; // "long"
            inline constexpr std::uintptr_t UserClanTag = 0x20; // "string"
            inline constexpr std::uintptr_t UserNickname = 0x28; // "string"
        }
        namespace StaticFields {
            inline constexpr std::uintptr_t Pool = 0x0; // "ObjectPool<ChatAttachmentModel>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Clear = 0x36CC1D0; // "private void Clear()"
        }
    } // namespace ChatAttachmentModel

    namespace ChatAuthorColorRuleExtension { // "Game.Global.Chat.ChatAuthorColorRuleExtension (Global.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t GetColorType = 0x36CC3A0; // "public static UserColorType GetColorType(IChatAuthorColorRule[] authorColorRules, long publicId)"
        }
    } // namespace ChatAuthorColorRuleExtension

    namespace ChatChannelModel { // "Game.Global.Chat.ChatChannelModel (Global.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x81CC0B8; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace Fields {
            inline constexpr std::uintptr_t capacity = 0x10; // "int"
            inline constexpr std::uintptr_t addedGen0 = 0x18; // "List<ChatMessageModel>"
            inline constexpr std::uintptr_t addedGen1 = 0x20; // "List<ChatMessageModel>"
            inline constexpr std::uintptr_t spamTexts = 0x28; // "Dictionary<long, HashSet<string>>"
            inline constexpr std::uintptr_t Sources = 0x30; // "SortedList<int, IChatMessageSource>"
            inline constexpr std::uintptr_t Messages = 0x38; // "List<ChatMessageModel>"
            inline constexpr std::uintptr_t Filter = 0x40; // "Predicate<ChatMessageModel>"
            inline constexpr std::uintptr_t ChatInputModel = 0x48; // "ChatInputModel"
            inline constexpr std::uintptr_t hasNotification = 0x50; // "bool"
            inline constexpr std::uintptr_t isReorderedGen0 = 0x51; // "bool"
            inline constexpr std::uintptr_t isReorderedGen1 = 0x52; // "bool"
            inline constexpr std::uintptr_t SinceTs = 0x58; // "long"
            inline constexpr std::uintptr_t LastMessageReceivedTs = 0x60; // "long"
            inline constexpr std::uintptr_t AuthorColorRules = 0x68; // "IChatAuthorColorRule[]"
            inline constexpr std::uintptr_t SpamRules = 0x70; // "ChatSpamRules"
            inline constexpr std::uintptr_t IsNotificationAllowed = 0x78; // "bool"
            inline constexpr std::uintptr_t IsHiddenWhileEmpty = 0x79; // "bool"
        }
        namespace StaticFields {
            inline constexpr std::uintptr_t alwaysTrue = 0x0; // "Predicate<ChatMessageModel>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t IterateSources = 0x36CCF80; // "public void IterateSources()"
            inline constexpr std::uintptr_t AddMessages = 0x36CC720; // "public void AddMessages(IEnumerable<ChatMessageModel> messages)"
            inline constexpr std::uintptr_t IsSpam = 0x36CCBD0; // "private bool IsSpam(ChatMessageModel message)"
            inline constexpr std::uintptr_t RemoveAuthorMessagesWithText = 0x36CD2F0; // "private bool RemoveAuthorMessagesWithText(long authorPublicId, string text)"
            inline constexpr std::uintptr_t AddMessage = 0x36CC4D0; // "private void AddMessage(ChatMessageModel message)"
            inline constexpr std::uintptr_t GetInsertIndex = 0x36CCA70; // "private int GetInsertIndex(long ts)"
            inline constexpr std::uintptr_t IncrementGeneration = 0x36CCB10; // "public void IncrementGeneration()"
            inline constexpr std::uintptr_t get_HasNewMessageNotification = 0x36CD730; // "public bool get_HasNewMessageNotification()"
            inline constexpr std::uintptr_t SetHasNewMessageNotification = 0x8E1C80; // "public void SetHasNewMessageNotification(bool hasNewMessageNotification)"
            inline constexpr std::uintptr_t get_Capacity = 0x7AA080; // "public int get_Capacity()"
            inline constexpr std::uintptr_t get_MessagesToPrint = 0x7E7130; // "public List<ChatMessageModel> get_MessagesToPrint()"
            inline constexpr std::uintptr_t get_IsReordered = 0xA4EFE0; // "public bool get_IsReordered()"
            inline constexpr std::uintptr_t Clear = 0x36CC8E0; // "public void Clear()"
        }
    } // namespace ChatChannelModel

    namespace ChatColorsViewDescription { // "Game.Global.Chat.ChatColorsViewDescription (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t colors = 0x18; // "List<ChatColorsViewDescription.ColorByType>"
            inline constexpr std::uintptr_t colorDict = 0x20; // "Dictionary<ChatMessageType, ValueTuple<string, PaletteColor>>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t GetColor = 0x36AF550; // "public ValueTuple<string, PaletteColor> GetColor(ChatMessageType type)"
        }
    } // namespace ChatColorsViewDescription

    namespace ChatColorsViewDescription_ColorByType { // "Game.Global.Chat.ChatColorsViewDescription.ColorByType (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Type = 0x0; // "ChatMessageType"
            inline constexpr std::uintptr_t PaletteColor = 0x8; // "PaletteColor"
            inline constexpr std::uintptr_t BackgroundColor = 0x10; // "PaletteColor"
        }
    } // namespace ChatColorsViewDescription_ColorByType

    namespace ChatConfig { // "Models.References.Chat.ChatConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t MaxMessageLength = 0x10; // "int"
            inline constexpr std::uintptr_t LocationChatMaxMessagesCount = 0x14; // "int"
            inline constexpr std::uintptr_t PartyChatMaxMessagesCount = 0x18; // "int"
            inline constexpr std::uintptr_t ClanChatMaxMessagesCount = 0x1C; // "int"
            inline constexpr std::uintptr_t CopsChatMaxMessagesCount = 0x20; // "int"
            inline constexpr std::uintptr_t PrivateChatMaxMessagesCount = 0x24; // "int"
            inline constexpr std::uintptr_t RealmChatMaxMessagesCount = 0x28; // "int"
            inline constexpr std::uintptr_t PrivateChatUsersCount = 0x2C; // "int"
            inline constexpr std::uintptr_t PrivateChatExpirationTime = 0x30; // "long"
            inline constexpr std::uintptr_t BlacklistSize = 0x38; // "int"
            inline constexpr std::uintptr_t SendMessageExpiringResource = 0x40; // "ExpiringResourceDescription"
            inline constexpr std::uintptr_t SendMessageInRealmExpiringResource = 0x48; // "ExpiringResourceDescription"
            inline constexpr std::uintptr_t ChatRequiredImprisonmentYears = 0x50; // "int"
        }
    } // namespace ChatConfig

    namespace ChatContext { // "Game.Global.Chat.ChatContext (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t PublicId = 0x0; // "long"
            inline constexpr std::uintptr_t ClanTag = 0x8; // "string"
            inline constexpr std::uintptr_t Nickname = 0x10; // "string"
            inline constexpr std::uintptr_t IsPrivate = 0x18; // "bool"
        }
    } // namespace ChatContext

    namespace ChatContextActionsViewUpdater { // "Game.Global.Chat.ChatContextActionsViewUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t clickableContextActions = 0x10; // "ClickableItemsModel<ContextAction>"
            inline constexpr std::uintptr_t contextActionRules = 0x18; // "GeneralContextActionRules"
            inline constexpr std::uintptr_t actionViewTemplate = 0x20; // "IComponentInstantiateContent<ButtonView>"
            inline constexpr std::uintptr_t chatDialogModel = 0x28; // "ChatDialogModel"
            inline constexpr std::uintptr_t contextView = 0x30; // "ChatContextView"
            inline constexpr std::uintptr_t contextLocalization = 0x38; // "ContextLocalization"
            inline constexpr std::uintptr_t chatLocalization = 0x40; // "ChatLocalization"
            inline constexpr std::uintptr_t partyModel = 0x48; // "PartyModel"
            inline constexpr std::uintptr_t clanModel = 0x50; // "ClanModel"
            inline constexpr std::uintptr_t realmModel = 0x58; // "RegionUserRealmModel"
            inline constexpr std::uintptr_t battleRoomModel = 0x60; // "RegionUserBattleRoomModel"
            inline constexpr std::uintptr_t publicIdModel = 0x68; // "PublicIdModel"
            inline constexpr std::uintptr_t blackListModel = 0x70; // "BlackListModel"
            inline constexpr std::uintptr_t now = 0x78; // "INow"
            inline constexpr std::uintptr_t wasContext = 0x80; // "ChatContext"
            inline constexpr std::uintptr_t disposable = 0xA0; // "IRegisterDisposable"
            inline constexpr std::uintptr_t updaters = 0xA8; // "List<IUpdater>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x36B0900; // "public void Update()"
            inline constexpr std::uintptr_t CanInviteToParty = 0x36B0200; // "private bool CanInviteToParty(ChatContext context)"
            inline constexpr std::uintptr_t CanKickFromParty = 0x36B06A0; // "private bool CanKickFromParty(ChatContext context)"
            inline constexpr std::uintptr_t CanInviteToClan = 0x36B0010; // "private bool CanInviteToClan(ChatContext context)"
            inline constexpr std::uintptr_t AttachAction = 0x36AFB60; // "private void AttachAction(ContextAction contextAction, IText text, IRegisterDisposable disposable)"
            inline constexpr std::uintptr_t AttachAction_2 = 0x36AFD60; // "private void AttachAction(ContextAction contextAction, GeneralContextActionRules contextActionRules, IText text, Text.ReadOnly<long> textWithTimer, IRegisterDisposable disposable)"
        }
    } // namespace ChatContextActionsViewUpdater

    namespace ChatContextModel { // "Game.Global.Chat.ChatContextModel (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsOpen = 0x10; // "bool"
            inline constexpr std::uintptr_t Context = 0x18; // "ChatContext"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Open = 0x36CD770; // "public void Open(ChatContext context)"
            inline constexpr std::uintptr_t Close = 0x36CD740; // "public void Close()"
        }
    } // namespace ChatContextModel

    namespace ChatContextView { // "Game.Global.Chat.ChatContextView (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Title = 0x20; // "TextLabel<string, string>"
            inline constexpr std::uintptr_t Parent = 0x28; // "RectTransform"
            inline constexpr std::uintptr_t rectTransform = 0x30; // "RectTransform"
            inline constexpr std::uintptr_t corners = 0x38; // "Vector3[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_RectTransform = 0x36CD9A0; // "private RectTransform get_RectTransform()"
            inline constexpr std::uintptr_t IsPointInsideRect = 0x36CD860; // "public bool IsPointInsideRect(Vector2 worldPoint)"
        }
    } // namespace ChatContextView

    namespace ChatContextViewUpdater { // "Game.Global.Chat.ChatContextViewUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t view = 0x10; // "ChatContextView"
            inline constexpr std::uintptr_t contextModel = 0x18; // "ChatContextModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x36CD7F0; // "public void Update()"
        }
    } // namespace ChatContextViewUpdater

    namespace ChatDialogHandleHyperlinksInputRules { // "Game.Global.Chat.ChatDialogHandleHyperlinksInputRules (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t publicIdModel = 0x10; // "PublicIdModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t TryBuildContext = 0x36CDC50; // "public bool TryBuildContext(string link, ChatMessageModel message, out ChatContext context)"
            inline constexpr std::uintptr_t TryParseAttachmentType = 0x36CDDB0; // "private bool TryParseAttachmentType(string link, out ChatAttachmentModel.Type type, out long publicId)"
            inline constexpr std::uintptr_t BuildContext = 0x36CDA10; // "private ChatContext BuildContext(ChatMessageModel msg, ChatAttachmentModel.Type type, long publicId)"
            inline constexpr std::uintptr_t TryBuildContextFromAttachment = 0x36CDBA0; // "private bool TryBuildContextFromAttachment(ChatAttachmentModel.Type type, long publicId, ChatAttachmentModel attachment, out ChatContext context)"
        }
    } // namespace ChatDialogHandleHyperlinksInputRules

    namespace ChatDialogInputUpdater { // "Game.Global.Chat.ChatDialogInputUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t chatDialog = 0x10; // "ChatDialogModel"
            inline constexpr std::uintptr_t uiSoundModel = 0x18; // "GlobalUISoundModel"
            inline constexpr std::uintptr_t view = 0x20; // "ChatDialogView"
            inline constexpr std::uintptr_t inputActions = 0x28; // "InputActions"
            inline constexpr std::uintptr_t localization = 0x30; // "ChatLocalization"
            inline constexpr std::uintptr_t tabViews = 0x38; // "List<ValueTuple<TabView<Unit>, ChatTab, IText>>"
            inline constexpr std::uintptr_t personalNotificationModel = 0x40; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t privateChatChannelsModel = 0x48; // "PrivateChatChannelsModel"
            inline constexpr std::uintptr_t userNow = 0x50; // "INow"
            inline constexpr std::uintptr_t publicIdModel = 0x58; // "PublicIdModel"
            inline constexpr std::uintptr_t predictedPrivateChatInput = 0x60; // "SystemChatMessageSource"
            inline constexpr std::uintptr_t blackListModel = 0x68; // "BlackListModel"
            inline constexpr std::uintptr_t badWordsFilter = 0x70; // "BadWordsFilterModel"
            inline constexpr std::uintptr_t hyperlinksInputRules = 0x78; // "ChatDialogHandleHyperlinksInputRules"
            inline constexpr std::uintptr_t contextActionRules = 0x80; // "GeneralContextActionRules"
            inline constexpr std::uintptr_t globalLocalization = 0x88; // "GlobalLocalizationKeys"
            inline constexpr std::uintptr_t isMessageClicked = 0x90; // "bool"
            inline constexpr std::uintptr_t focusedHandler = 0x98; // "ValueTuple<InputMask, IUpdater>[]"
            inline constexpr std::uintptr_t idleHandler = 0xA0; // "ValueTuple<InputMask, IUpdater>[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t OnMessageClicked = 0x36CE6D0; // "private void OnMessageClicked(ChatMessagePair message)"
            inline constexpr std::uintptr_t OnChatSubmit = 0x36CDFD0; // "private void OnChatSubmit()"
            inline constexpr std::uintptr_t OnTouchChatSubmit = 0x36CEB30; // "private void OnTouchChatSubmit()"
            inline constexpr std::uintptr_t TrySendChatMessage = 0x36CEDE0; // "private void TrySendChatMessage(string chatMessage, ChatInputModel.RoomInput roomInput)"
            inline constexpr std::uintptr_t Notify = 0x36CDEC0; // "private void Notify(IText text)"
            inline constexpr std::uintptr_t OnBackToPrivatesList = 0x36CDF40; // "private void OnBackToPrivatesList()"
            inline constexpr std::uintptr_t OnChatClose = 0x36CDF90; // "private void OnChatClose()"
            inline constexpr std::uintptr_t get_Handlers = 0x36CFCA0; // "public ValueTuple<InputMask, IUpdater>[] get_Handlers()"
            inline constexpr std::uintptr_t get_Priority = 0x1260C00; // "public InputHandlerPriority get_Priority()"
            inline constexpr std::uintptr_t OnChatTabClicked = 0x36CE100; // "private void OnChatTabClicked(ChatTab tab)"
            inline constexpr std::uintptr_t OnPrivateChannelClicked = 0x36CE9E0; // "private void OnPrivateChannelClicked(PrivateChannel privateChannel)"
            inline constexpr std::uintptr_t OnTabulationHotkeyClicked = 0x36CEA30; // "private void OnTabulationHotkeyClicked()"
            inline constexpr std::uintptr_t SwitchToTab = 0x36CEC50; // "private void SwitchToTab(int tabDirection)"
            inline constexpr std::uintptr_t GetIndexOfTab = 0x36CDDF0; // "private int GetIndexOfTab(ChatTab tab)"
            inline constexpr std::uintptr_t OnContextActionClicked = 0x36CE1A0; // "private void OnContextActionClicked(ContextAction contextAction)"
            inline constexpr std::uintptr_t TryToCloseContextOnClickElsewhere = 0x36CEED0; // "private void TryToCloseContextOnClickElsewhere()"
        }
    } // namespace ChatDialogInputUpdater

    namespace ChatDialogModel { // "Game.Global.Chat.ChatDialogModel (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t chatsModel = 0x18; // "ChatsModel"
            inline constexpr std::uintptr_t IsInputFieldFocused = 0x20; // "bool"
            inline constexpr std::uintptr_t SelectedTab = 0x28; // "ChatTab"
            inline constexpr std::uintptr_t Context = 0x30; // "ChatContextModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_SelectedChannel = 0x36B1230; // "public ChatChannelModel get_SelectedChannel()"
            inline constexpr std::uintptr_t Open = 0x3597220; // "public void Open()"
            inline constexpr std::uintptr_t OpenPrivate = 0x36B1040; // "public void OpenPrivate(long publicId)"
            inline constexpr std::uintptr_t Close = 0xC2DB70; // "public void Close()"
        }
    } // namespace ChatDialogModel

    namespace ChatDialogUpdater { // "Game.Global.Chat.ChatDialogUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t updater = 0x10; // "IUpdater"
        }
        namespace Methods {
            inline constexpr std::uintptr_t RegisterTab = 0x36B13C0; // "private void RegisterTab(ChatTab tab, TabView<Unit> tabView, ClickableItemsModel<ChatTab> chatTabs, List<ValueTuple<TabView<Unit>, ChatTab, IText>> tabViews, IText chatTitle)"
            inline constexpr std::uintptr_t Update = 0x36B1540; // "public void Update()"
        }
    } // namespace ChatDialogUpdater

    namespace ChatDialogView { // "Game.Global.Chat.ChatDialogView (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ChatTitleLabel = 0x20; // "LocalizeStringEvent"
            inline constexpr std::uintptr_t ChatInput = 0x28; // "InputFieldView"
            inline constexpr std::uintptr_t CharacterLimitCounterLabel = 0x30; // "TMP_Text"
            inline constexpr std::uintptr_t PrivateChatNicknameBreadcrumb = 0x38; // "TMP_Text"
            inline constexpr std::uintptr_t ChatInputWarning = 0x40; // "LocalizeStringEvent"
            inline constexpr std::uintptr_t MessagesParent = 0x48; // "RectTransform"
            inline constexpr std::uintptr_t PrivatesParent = 0x50; // "RectTransform"
            inline constexpr std::uintptr_t StateScreen = 0x58; // "EnumStateElement<ChatDialogView.ChatScreen>"
            inline constexpr std::uintptr_t StatePrivatesList = 0x60; // "EnumStateElement<ChatDialogView.ListState>"
            inline constexpr std::uintptr_t StateChatInput = 0x68; // "EnumStateElement<ChatDialogView.ChatInputState>"
            inline constexpr std::uintptr_t BackToPrivatesList = 0x70; // "ClickButtonView"
            inline constexpr std::uintptr_t Scroll = 0x78; // "ChatSegmentScroll"
            inline constexpr std::uintptr_t HyperlinkCanvasRenderer = 0x80; // "UnderlineRenderer"
            inline constexpr std::uintptr_t PositionByMembersState = 0x88; // "StateElementBase"
            inline constexpr std::uintptr_t General = 0x90; // "TabView<Unit>"
            inline constexpr std::uintptr_t Party = 0x98; // "TabView<Unit>"
            inline constexpr std::uintptr_t Private = 0xA0; // "TabView<Unit>"
            inline constexpr std::uintptr_t Clan = 0xA8; // "TabView<Unit>"
            inline constexpr std::uintptr_t Battle = 0xB0; // "TabView<Unit>"
            inline constexpr std::uintptr_t Police = 0xB8; // "TabView<Unit>"
            inline constexpr std::uintptr_t ChatContextView = 0xC0; // "ChatContextView"
        }
    } // namespace ChatDialogView

    namespace ChatHudView { // "Game.Global.Chat.ChatHudView (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t NewNotification = 0x20; // "GameObject"
            inline constexpr std::uintptr_t MiniChat = 0x28; // "MiniChatView"
            inline constexpr std::uintptr_t StateByParty = 0x30; // "StateElementBase"
        }
    } // namespace ChatHudView

    namespace ChatInputFieldSelectionUpdater { // "Game.Global.Chat.ChatInputFieldSelectionUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t chatDialogModel = 0x10; // "ChatDialogModel"
            inline constexpr std::uintptr_t view = 0x18; // "InputFieldView"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x36B2770; // "public void Update()"
        }
    } // namespace ChatInputFieldSelectionUpdater

    namespace ChatInputModel { // "Game.Global.Chat.ChatInputModel (Global.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x81CD268; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t InputUnavailable = 0x0; // "ChatInputModel.NoInput"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsInteractable = 0x7EC9F0; // "public virtual bool get_IsInteractable()"
            inline constexpr std::uintptr_t get_ReportRoom = 0x7E3AB0; // "public virtual IRoomConnection get_ReportRoom()"
            inline constexpr std::uintptr_t get_CharactersLimit = 0x36D0130; // "public int get_CharactersLimit()"
        }
    } // namespace ChatInputModel

    namespace ChatInputModel_NoInput { // "Game.Global.Chat.ChatInputModel.NoInput (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Reason = 0x10; // "ChatInputModel.NoInput.NoInputReason"
            inline constexpr std::uintptr_t Warning = 0x18; // "IText"
            inline constexpr std::uintptr_t CooldownEndTs = 0x20; // "long"
        }
    } // namespace ChatInputModel_NoInput

    namespace ChatInputModel_RestrictedInput { // "Game.Global.Chat.ChatInputModel.RestrictedInput (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Input = 0x28; // "ChatInputModel.RoomInput"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_ReportRoom = 0x36DA400; // "public override IRoomConnection get_ReportRoom()"
        }
    } // namespace ChatInputModel_RestrictedInput

    namespace ChatInputModel_RoomInput { // "Game.Global.Chat.ChatInputModel.RoomInput (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Room = 0x10; // "IRoomConnection"
            inline constexpr std::uintptr_t Cooldown = 0x18; // "ExpiringResourceModel"
            inline constexpr std::uintptr_t Now = 0x20; // "INow"
            inline constexpr std::uintptr_t BuildMessage = 0x28; // "Func<string, IMessage>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsInteractable = 0x7D5050; // "public override bool get_IsInteractable()"
            inline constexpr std::uintptr_t get_ReportRoom = 0x7EC6B0; // "public override IRoomConnection get_ReportRoom()"
        }
    } // namespace ChatInputModel_RoomInput

    namespace ChatInputViewUpdater { // "Game.Global.Chat.ChatInputViewUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t chatDialogView = 0x10; // "ChatDialogView"
            inline constexpr std::uintptr_t inputValidator = 0x18; // "WhitespacesTrimInputValidator"
            inline constexpr std::uintptr_t dialogModel = 0x20; // "ChatDialogModel"
            inline constexpr std::uintptr_t now = 0x28; // "INow"
            inline constexpr std::uintptr_t chatLocalization = 0x30; // "ChatLocalization"
            inline constexpr std::uintptr_t cooldownWarning = 0x38; // "Text<long>"
            inline constexpr std::uintptr_t restrictedWarning = 0x40; // "Text<long>"
            inline constexpr std::uintptr_t privateChatChannels = 0x48; // "PrivateChatChannelsModel"
            inline constexpr std::uintptr_t globalModel = 0x50; // "GlobalModel"
            inline constexpr std::uintptr_t inputHandlers = 0x58; // "InputHandlersManager"
            inline constexpr std::uintptr_t lastNickName = 0x60; // "string"
            inline constexpr std::uintptr_t chatInputState = 0x68; // "ChatDialogView.ChatInputState"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x36B2BD0; // "public void Update()"
            inline constexpr std::uintptr_t GetWarning = 0x36B2930; // "private IText GetWarning(ChatInputModel.NoInput noInput)"
            inline constexpr std::uintptr_t GetCooldownWarning = 0x36B2850; // "private IText GetCooldownWarning(long cooldownEndTs)"
        }
    } // namespace ChatInputViewUpdater

    namespace ChatMessageBuildRules { // "Game.Global.Chat.ChatMessageBuildRules (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t publicIdModel = 0x10; // "PublicIdModel"
            inline constexpr std::uintptr_t chatViewDescription = 0x18; // "ChatViewDescription"
            inline constexpr std::uintptr_t userColorViewDescriptions = 0x20; // "UserColorViewDescriptions"
        }
        namespace Methods {
            inline constexpr std::uintptr_t BuildAuthor = 0x36B3340; // "public string BuildAuthor(ChatMessageModel message)"
            inline constexpr std::uintptr_t BuildTime = 0x36B3530; // "public string BuildTime(ChatMessageModel message)"
            inline constexpr std::uintptr_t GetChatParseSafety = 0x36B3650; // "public ChatMessageContext.ParseSafety GetChatParseSafety(ChatMessageType type)"
        }
    } // namespace ChatMessageBuildRules

    namespace ChatMessageContext { // "Game.Global.Chat.ChatMessageContext (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Color = 0x0; // "string"
            inline constexpr std::uintptr_t BackgroundColor = 0x8; // "PaletteColor"
            inline constexpr std::uintptr_t Message = 0x10; // "string"
            inline constexpr std::uintptr_t Author = 0x18; // "string"
            inline constexpr std::uintptr_t Time = 0x20; // "string"
            inline constexpr std::uintptr_t Safety = 0x28; // "ChatMessageContext.ParseSafety"
        }
    } // namespace ChatMessageContext

    namespace ChatMessageData { // "Models.Data.Chat.ChatMessageData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Ts = 0x20; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t PublicId = 0x28; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t Name = 0x30; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t ClanTag = 0x38; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t Message = 0x40; // "IPrimitiveData<string>"
        }
    } // namespace ChatMessageData

    namespace ChatMessageListUpdater { // "Game.Global.Chat.ChatMessageListUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t channelModel = 0x10; // "ChatChannelModel"
            inline constexpr std::uintptr_t dialogView = 0x18; // "ChatDialogView"
            inline constexpr std::uintptr_t template_id = 0x20; // "IComponentInstantiateContent<ChatMessageView>"
            inline constexpr std::uintptr_t chatViewDescription = 0x28; // "ChatViewDescription"
            inline constexpr std::uintptr_t clickableMessages = 0x30; // "ClickableItemsModel<ChatMessagePair>"
            inline constexpr std::uintptr_t visibleMessages = 0x38; // "Dictionary<ChatMessageModel, ChatMessagePair>"
            inline constexpr std::uintptr_t scrollMessages = 0x40; // "Queue<ChatMessageModel>"
            inline constexpr std::uintptr_t chatMessageBuildRules = 0x48; // "ChatMessageBuildRules"
            inline constexpr std::uintptr_t isRebuildPending = 0x50; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t InitScroll = 0x36B3FB0; // "private void InitScroll()"
            inline constexpr std::uintptr_t ClearScroll = 0x36B3DB0; // "private void ClearScroll()"
            inline constexpr std::uintptr_t HoldInScroll = 0x36B3F40; // "private void HoldInScroll(ChatMessageModel message)"
            inline constexpr std::uintptr_t Destroy = 0x36B3E60; // "private void Destroy(ChatMessageModel model)"
            inline constexpr std::uintptr_t Build = 0x36B3680; // "private void Build(ChatMessageModel message, out RectTransform rect)"
            inline constexpr std::uintptr_t PrintMessage = 0x36B4210; // "private void PrintMessage(ChatMessageModel message)"
            inline constexpr std::uintptr_t Update = 0x36B4310; // "public void Update()"
        }
    } // namespace ChatMessageListUpdater

    namespace ChatMessageModel { // "Game.Global.Chat.ChatMessageModel (Global.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x81CDA78; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace Fields {
            inline constexpr std::uintptr_t Message = 0x10; // "string"
            inline constexpr std::uintptr_t AuthorClanTag = 0x18; // "string"
            inline constexpr std::uintptr_t AuthorNickname = 0x20; // "string"
            inline constexpr std::uintptr_t AuthorNicknameColorType = 0x28; // "UserColorType"
            inline constexpr std::uintptr_t PublicId = 0x30; // "long"
            inline constexpr std::uintptr_t ClientDrawTs = 0x38; // "long"
            inline constexpr std::uintptr_t ServerReceiveTs = 0x40; // "long"
            inline constexpr std::uintptr_t Type = 0x48; // "ChatMessageType"
            inline constexpr std::uintptr_t IsPrivate = 0x4C; // "bool"
            inline constexpr std::uintptr_t Composition = 0x50; // "ChatMessageComposition"
            inline constexpr std::uintptr_t Attachment0 = 0x58; // "ChatAttachmentModel"
            inline constexpr std::uintptr_t Attachment1 = 0x60; // "ChatAttachmentModel"
            inline constexpr std::uintptr_t refCount = 0x68; // "int"
        }
        namespace StaticFields {
            inline constexpr std::uintptr_t Pool = 0x0; // "ObjectPool<ChatMessageModel>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t HasFlag = 0x36D0420; // "public bool HasFlag(ChatMessageComposition composition)"
            inline constexpr std::uintptr_t Clear = 0x36D0260; // "private void Clear()"
            inline constexpr std::uintptr_t IncReference = 0x36D0430; // "public void IncReference()"
            inline constexpr std::uintptr_t DecReference = 0x36D02F0; // "public void DecReference()"
        }
    } // namespace ChatMessageModel

    namespace ChatMessagePair { // "Game.Global.Chat.ChatMessagePair (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Model = 0x0; // "ChatMessageModel"
            inline constexpr std::uintptr_t View = 0x8; // "IDisposableContent<ChatMessageView>"
        }
    } // namespace ChatMessagePair

    namespace ChatMessageView { // "Game.Global.Chat.ChatMessageView (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t time = 0x20; // "TMP_Text"
            inline constexpr std::uintptr_t message = 0x28; // "TextLabel<string, string, string>"
            inline constexpr std::uintptr_t safetyState = 0x30; // "EnumStateElement<ChatMessageContext.ParseSafety>"
            inline constexpr std::uintptr_t Button = 0x38; // "CompositeButtonView"
            inline constexpr std::uintptr_t Hyperlink = 0x40; // "TextHyperlinkView"
            inline constexpr std::uintptr_t Background = 0x48; // "GraphicsPalette"
            inline constexpr std::uintptr_t rectTransform = 0x50; // "RectTransform"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetContext = 0x36B4930; // "public void SetContext(ChatMessageContext context)"
            inline constexpr std::uintptr_t SetUnderlineRenderer = 0x36B4AC0; // "public void SetUnderlineRenderer(UnderlineRenderer underlineRenderer)"
            inline constexpr std::uintptr_t get_RectTransform = 0x36B4AF0; // "public RectTransform get_RectTransform()"
        }
    } // namespace ChatMessageView

    namespace ChatNewMessageNotificationUpdater { // "Game.Global.Chat.ChatNewMessageNotificationUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t chatHudView = 0x10; // "ChatHudView"
            inline constexpr std::uintptr_t chatsModel = 0x18; // "ChatsModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x36D0750; // "public void Update()"
            inline constexpr std::uintptr_t HasNotification = 0x36D05D0; // "private bool HasNotification()"
        }
    } // namespace ChatNewMessageNotificationUpdater

    namespace ChatPositionByMembersUpdater { // "Game.Global.Chat.ChatPositionByMembersUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t partyModel = 0x10; // "PartyModel"
            inline constexpr std::uintptr_t battleRoomModel = 0x18; // "RegionUserBattleRoomModel"
            inline constexpr std::uintptr_t view = 0x20; // "ChatDialogView"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x36B50C0; // "public void Update()"
        }
    } // namespace ChatPositionByMembersUpdater

    namespace ChatRebuildMessageListByTabUpdater { // "Game.Global.Chat.ChatRebuildMessageListByTabUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t globalModel = 0x10; // "GlobalModel"
            inline constexpr std::uintptr_t chatDialog = 0x18; // "ChatDialogModel"
            inline constexpr std::uintptr_t view = 0x20; // "ChatDialogView"
            inline constexpr std::uintptr_t messageTemplate = 0x28; // "IComponentInstantiateContent<ChatMessageView>"
            inline constexpr std::uintptr_t contactTemplate = 0x30; // "IComponentInstantiateContent<PrivateChatContactView>"
            inline constexpr std::uintptr_t chatViewDescription = 0x38; // "ChatViewDescription"
            inline constexpr std::uintptr_t userColorViewDescriptions = 0x40; // "UserColorViewDescriptions"
            inline constexpr std::uintptr_t privatesClickableItems = 0x48; // "ClickableItemsModel<PrivateChannel>"
            inline constexpr std::uintptr_t clickableMessages = 0x50; // "ClickableItemsModel<ChatMessagePair>"
            inline constexpr std::uintptr_t oldTab = 0x58; // "ChatTab"
            inline constexpr std::uintptr_t updater = 0x60; // "IUpdater"
            inline constexpr std::uintptr_t disposable = 0x68; // "IRegisterDisposable"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x36B56C0; // "public void Update()"
            inline constexpr std::uintptr_t ResolveSelectedTab = 0x36B52B0; // "private void ResolveSelectedTab()"
        }
    } // namespace ChatRebuildMessageListByTabUpdater

    namespace ChatRestrictionBuffUpdater { // "Game.Battle.Buffs.ChatRestrictionBuffUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t chatRestrictionModel = 0x40; // "ChatRestrictionModel"
            inline constexpr std::uintptr_t isActive = 0x48; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xD4A310; // "public override void Update()"
        }
    } // namespace ChatRestrictionBuffUpdater

    namespace ChatRestrictionModel { // "Game.Global.Chat.ChatRestrictionModel (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsTextChatAvailable = 0x10; // "bool"
            inline constexpr std::uintptr_t IsVoiceChatAvailable = 0x11; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_HasActiveBuff = 0x36B5880; // "public bool get_HasActiveBuff()"
        }
    } // namespace ChatRestrictionModel

    namespace ChatSelectedTabViewUpdater { // "Game.Global.Chat.ChatSelectedTabViewUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t chatDialog = 0x10; // "ChatDialogModel"
            inline constexpr std::uintptr_t stateScreen = 0x18; // "EnumStateElement<ChatDialogView.ChatScreen>"
            inline constexpr std::uintptr_t tabViews = 0x20; // "List<ValueTuple<TabView<Unit>, ChatTab, IText>>"
            inline constexpr std::uintptr_t view = 0x28; // "ChatDialogView"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x36B58E0; // "public void Update()"
        }
    } // namespace ChatSelectedTabViewUpdater

    namespace ChatSettingsPreset { // "Game.Global.Chat.ChatSettingsPreset (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t GeneralChatDuplicationOption = 0x18; // "SystemChatSetting"
            inline constexpr std::uintptr_t SystemDuplication = 0x1C; // "bool"
            inline constexpr std::uintptr_t ClanDuplication = 0x1D; // "bool"
            inline constexpr std::uintptr_t PartyDuplication = 0x1E; // "bool"
            inline constexpr std::uintptr_t BattleDuplication = 0x1F; // "bool"
            inline constexpr std::uintptr_t BadWordFilter = 0x20; // "bool"
            inline constexpr std::uintptr_t ShowMiniChat = 0x21; // "bool"
            inline constexpr std::uintptr_t PlaySoundWhenNewMessageArrived = 0x22; // "bool"
            inline constexpr std::uintptr_t ShowHudNotificationWhenNewMessageArrived = 0x23; // "bool"
        }
    } // namespace ChatSettingsPreset

    namespace ChatSettingsView { // "Game.Global.Chat.ChatSettingsView (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t SystemChatDuplicateMessagesInGeneral = 0x20; // "StepperView"
            inline constexpr std::uintptr_t SystemChatDuplicateClanMessages = 0x28; // "ToggleStateView"
            inline constexpr std::uintptr_t SystemChatDuplicatePartyMessages = 0x30; // "ToggleStateView"
            inline constexpr std::uintptr_t SystemChatDuplicateBattleMessages = 0x38; // "ToggleStateView"
            inline constexpr std::uintptr_t SystemChatDuplicateSystemMessages = 0x40; // "ToggleStateView"
            inline constexpr std::uintptr_t SystemChatBadWordFilter = 0x48; // "ToggleStateView"
            inline constexpr std::uintptr_t MarkChatsAsUnread = 0x50; // "ToggleStateView"
            inline constexpr std::uintptr_t PlaySoundOnNewMessage = 0x58; // "ToggleStateView"
            inline constexpr std::uintptr_t ShowMiniChat = 0x60; // "ToggleStateView"
            inline constexpr std::uintptr_t OpenBlackListButton = 0x68; // "ClickButtonView"
            inline constexpr std::uintptr_t ChatSettingsToggles = 0x70; // "ToggleStateView[]"
        }
    } // namespace ChatSettingsView

    namespace ChatsModel { // "Game.Global.Chat.ChatsModel (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Channels = 0x10; // "List<ChatChannelModel>"
            inline constexpr std::uintptr_t Global = 0x18; // "ChatChannelModel"
            inline constexpr std::uintptr_t Battle = 0x20; // "ChatChannelModel"
            inline constexpr std::uintptr_t ShooterPolice = 0x28; // "ChatChannelModel"
            inline constexpr std::uintptr_t Party = 0x30; // "ChatChannelModel"
            inline constexpr std::uintptr_t Clan = 0x38; // "ChatChannelModel"
            inline constexpr std::uintptr_t PrivateChannels = 0x40; // "PrivateChatChannelsModel"
            inline constexpr std::uintptr_t ChatNotificationPreference = 0x48; // "ChatNotificationPreference"
            inline constexpr std::uintptr_t SystemChatFilterPreference = 0x4C; // "SystemChatPreference"
            inline constexpr std::uintptr_t ShowMiniChat = 0x50; // "bool"
            inline constexpr std::uintptr_t EnableBadWordFilter = 0x51; // "bool"
            inline constexpr std::uintptr_t ShouldShowInitialMessagesInGlobalChat = 0x52; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Add = 0x36B6C00; // "private ChatChannelModel Add(ChatChannelModel model)"
        }
    } // namespace ChatsModel

    namespace ChatSourceSettings { // "Game.Global.Chat.ChatSourceSettings (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Composition = 0x10; // "ChatMessageComposition"
            inline constexpr std::uintptr_t Type = 0x14; // "ChatMessageType"
            inline constexpr std::uintptr_t IsPrivate = 0x18; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t HasFlag = 0x36D0790; // "public bool HasFlag(ChatMessageComposition composition)"
        }
    } // namespace ChatSourceSettings

    namespace ChatSpamRules { // "Game.Global.Chat.ChatSpamRules (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t publicIdModel = 0x10; // "PublicIdModel"
            inline constexpr std::uintptr_t spamWords = 0x18; // "List<string>"
            inline constexpr std::uintptr_t linkRegexes = 0x20; // "List<Regex>"
            inline constexpr std::uintptr_t lettersBuilder = 0x28; // "StringBuilder"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetChatViewDescription = 0x36D0C80; // "public void SetChatViewDescription(ChatViewDescription chatViewDescription)"
            inline constexpr std::uintptr_t IsPlayerMessage = 0x36D0B50; // "public static bool IsPlayerMessage(ChatMessageModel message)"
            inline constexpr std::uintptr_t IsMyMessage = 0x36D0B10; // "public bool IsMyMessage(ChatMessageModel message)"
            inline constexpr std::uintptr_t GetComparableText = 0x36D0AA0; // "public static string GetComparableText(string message)"
            inline constexpr std::uintptr_t IsSameText = 0x36D0B70; // "public static bool IsSameText(string comparableText, string message)"
            inline constexpr std::uintptr_t IsForbidden = 0x36D0AC0; // "public bool IsForbidden(string message)"
            inline constexpr std::uintptr_t ContainsLink = 0x36D07F0; // "private bool ContainsLink(string message)"
            inline constexpr std::uintptr_t ContainsSpamWord = 0x36D0940; // "private bool ContainsSpamWord(string message)"
            inline constexpr std::uintptr_t KeepLettersAndDigits = 0x36D0BB0; // "private string KeepLettersAndDigits(string text)"
        }
    } // namespace ChatSpamRules

    namespace ChatTab_Channel { // "Game.Global.Chat.ChatTab.Channel (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ChatChannel = 0x10; // "ChatChannelModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t HasNewMessage = 0x36AF2A0; // "public override bool HasNewMessage()"
            inline constexpr std::uintptr_t IsHidden = 0x36AF2C0; // "public override bool IsHidden()"
        }
    } // namespace ChatTab_Channel

    namespace ChatTab_PrivateList { // "Game.Global.Chat.ChatTab.PrivateList (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t PrivatesList = 0x10; // "PrivateChatChannelsModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t HasNewMessage = 0x36C1210; // "public override bool HasNewMessage()"
            inline constexpr std::uintptr_t IsHidden = 0x36C1230; // "public override bool IsHidden()"
        }
    } // namespace ChatTab_PrivateList

    namespace ChatTabNotificationUpdater { // "Game.Global.Chat.ChatTabNotificationUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t chatsModel = 0x10; // "ChatsModel"
            inline constexpr std::uintptr_t tabs = 0x18; // "List<ValueTuple<TabView<Unit>, ChatTab, IText>>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x36B5C70; // "public void Update()"
        }
    } // namespace ChatTabNotificationUpdater

    namespace ChatTabVisibilityUpdater { // "Game.Global.Chat.ChatTabVisibilityUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t tabViews = 0x10; // "List<ValueTuple<TabView<Unit>, ChatTab, IText>>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x36B5E10; // "public void Update()"
        }
    } // namespace ChatTabVisibilityUpdater

    namespace ChatViewDescription { // "Game.Global.Chat.ChatViewDescription (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t keyboardMouseChat = 0x18; // "AssetReference"
            inline constexpr std::uintptr_t keyboardMessage = 0x20; // "AssetReference"
            inline constexpr std::uintptr_t keyboardMiniMessage = 0x28; // "AssetReference"
            inline constexpr std::uintptr_t keyboardChatContact = 0x30; // "AssetReference"
            inline constexpr std::uintptr_t keyboardChatContext = 0x38; // "AssetReference"
            inline constexpr std::uintptr_t keyboardChatContextAction = 0x40; // "AssetReference"
            inline constexpr std::uintptr_t keyboardBlackListDialog = 0x48; // "AssetReference"
            inline constexpr std::uintptr_t keyboardBlackListItem = 0x50; // "AssetReference"
            inline constexpr std::uintptr_t touchChat = 0x58; // "AssetReference"
            inline constexpr std::uintptr_t touchMessage = 0x60; // "AssetReference"
            inline constexpr std::uintptr_t touchMiniMessage = 0x68; // "AssetReference"
            inline constexpr std::uintptr_t touchChatContact = 0x70; // "AssetReference"
            inline constexpr std::uintptr_t touchChatContext = 0x78; // "AssetReference"
            inline constexpr std::uintptr_t touchChatContextAction = 0x80; // "AssetReference"
            inline constexpr std::uintptr_t touchBlackListDialog = 0x88; // "AssetReference"
            inline constexpr std::uintptr_t touchBlackListItem = 0x90; // "AssetReference"
            inline constexpr std::uintptr_t KeyboardChat = 0x98; // "CachedLoadedComponentContent<ChatDialogView>"
            inline constexpr std::uintptr_t KeyboardMessage = 0xA0; // "PooledLoadedComponentContent<ChatMessageView>"
            inline constexpr std::uintptr_t KeyboardMiniMessage = 0xA8; // "PooledLoadedComponentContent<ChatMessageView>"
            inline constexpr std::uintptr_t KeyboardChatContact = 0xB0; // "PooledLoadedComponentContent<PrivateChatContactView>"
            inline constexpr std::uintptr_t KeyboardChatContext = 0xB8; // "CachedLoadedComponentContent<ChatContextView>"
            inline constexpr std::uintptr_t KeyboardChatContextAction = 0xC0; // "PooledLoadedComponentContent<ButtonView>"
            inline constexpr std::uintptr_t KeyboardBlackListDialogView = 0xC8; // "CachedLoadedComponentContent<BlackListDialogView>"
            inline constexpr std::uintptr_t KeyboardBlackListItemView = 0xD0; // "PooledLoadedComponentContent<BlackListItemView>"
            inline constexpr std::uintptr_t TouchChat = 0xD8; // "CachedLoadedComponentContent<ChatDialogView>"
            inline constexpr std::uintptr_t TouchMessage = 0xE0; // "PooledLoadedComponentContent<ChatMessageView>"
            inline constexpr std::uintptr_t TouchMiniMessage = 0xE8; // "PooledLoadedComponentContent<ChatMessageView>"
            inline constexpr std::uintptr_t TouchChatContact = 0xF0; // "PooledLoadedComponentContent<PrivateChatContactView>"
            inline constexpr std::uintptr_t TouchChatContext = 0xF8; // "CachedLoadedComponentContent<ChatContextView>"
            inline constexpr std::uintptr_t TouchChatContextAction = 0x100; // "PooledLoadedComponentContent<ButtonView>"
            inline constexpr std::uintptr_t TouchBlackListDialogView = 0x108; // "CachedLoadedComponentContent<BlackListDialogView>"
            inline constexpr std::uintptr_t TouchBlackListItemView = 0x110; // "PooledLoadedComponentContent<BlackListItemView>"
            inline constexpr std::uintptr_t ChatLocalization = 0x118; // "ChatLocalization"
            inline constexpr std::uintptr_t ChatColorsViewDescription = 0x120; // "ChatColorsViewDescription"
            inline constexpr std::uintptr_t badWordsFiltersByRegion = 0x128; // "List<ChatViewDescription.RegionBadWordsFilters>"
            inline constexpr std::uintptr_t fallbackBadWordsFilters = 0x130; // "ChatViewDescription.RegionBadWordsFilters"
            inline constexpr std::uintptr_t spamWords = 0x138; // "string[]"
            inline constexpr std::uintptr_t spamLinkPatterns = 0x140; // "string[]"
            inline constexpr std::uintptr_t badWordsFilters = 0x148; // "Dictionary<string, BadWordsPostprocessorViewDescription[]>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_SpamWords = 0x926CA0; // "public IReadOnlyList<string> get_SpamWords()"
            inline constexpr std::uintptr_t get_SpamLinkPatterns = 0x926C00; // "public IReadOnlyList<string> get_SpamLinkPatterns()"
            inline constexpr std::uintptr_t GetBadWordsFilters = 0x36B6240; // "public BadWordsPostprocessorViewDescription[] GetBadWordsFilters(string region)"
        }
    } // namespace ChatViewDescription

    namespace ChatViewDescription_RegionBadWordsFilters { // "Game.Global.Chat.ChatViewDescription.RegionBadWordsFilters (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Region = 0x10; // "string"
            inline constexpr std::uintptr_t Filters = 0x18; // "BadWordsPostprocessorViewDescription[]"
        }
    } // namespace ChatViewDescription_RegionBadWordsFilters

    namespace CheatAddClanConquestSectorOwnerMessage { // "Models.Messages.Clan.ClanBattle.CheatAddClanConquestSectorOwnerMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t sector = 0x20; // "IPrimitiveData<SectorDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Sector = 0x4A19350; // "public SectorDescription get_Sector()"
            inline constexpr std::uintptr_t get_Type = 0x4A193A0; // "public override string get_Type()"
        }
    } // namespace CheatAddClanConquestSectorOwnerMessage

    namespace CheatAddMailMessage { // "Models.Messages.Mail.CheatAddMailMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t description = 0x20; // "IPrimitiveData<MailDescription>"
            inline constexpr std::uintptr_t attachmentsData = 0x28; // "MailAttachmentsData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Description = 0x49F0760; // "public MailDescription get_Description()"
            inline constexpr std::uintptr_t get_Attachments = 0x49F0750; // "public MailAttachments get_Attachments()"
            inline constexpr std::uintptr_t get_Type = 0x49F0820; // "public override string get_Type()"
        }
    } // namespace CheatAddMailMessage

    namespace CheatResetClanCooldownMessage { // "Models.Messages.CheatResetClanCooldownMessage (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x49F4A80; // "public override string get_Type()"
        }
    } // namespace CheatResetClanCooldownMessage

    namespace ClaimMailAttachmentsMessage { // "Models.Messages.Mail.ClaimMailAttachmentsMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t mailId = 0x20; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t commands = 0x28; // "ListData<MailClaimItemAttachmentCommandData>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_MailId = 0x4A04370; // "public int get_MailId()"
            inline constexpr std::uintptr_t GetCommands = 0x4A03C20; // "public List<MailClaimItemAttachmentCommand> GetCommands()"
            inline constexpr std::uintptr_t get_Type = 0x4A043C0; // "public override string get_Type()"
        }
    } // namespace ClaimMailAttachmentsMessage

    namespace ClanAnnouncementConfig { // "Models.References.Clan.ClanAnnouncementConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t MaxLength = 0x10; // "int"
        }
    } // namespace ClanAnnouncementConfig

    namespace ClanAnnouncementInputUpdater { // "Game.Global.Clan.ClanDialog.ClanAnnouncementInputUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t globalModel = 0x10; // "GlobalModel"
            inline constexpr std::uintptr_t dialogModel = 0x18; // "ClanDialogModel"
            inline constexpr std::uintptr_t view = 0x20; // "ClanAnnouncementView"
            inline constexpr std::uintptr_t roomConnections = 0x28; // "IRoomConnections"
            inline constexpr std::uintptr_t clanLocalization = 0x30; // "ClanLocalization"
            inline constexpr std::uintptr_t updaters = 0x38; // "IUpdater"
            inline constexpr std::uintptr_t isProgress = 0x40; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t OnSwapEdit = 0x3696AF0; // "private void OnSwapEdit()"
            inline constexpr std::uintptr_t OnEndEdit = 0x36969F0; // "private void OnEndEdit()"
            inline constexpr std::uintptr_t OnSave = 0x3696A40; // "private void OnSave()"
            inline constexpr std::uintptr_t Update = 0x3696B40; // "public void Update()"
        }
    } // namespace ClanAnnouncementInputUpdater

    namespace ClanAnnouncementView { // "Game.Global.Clan.ClanDialog.ClanAnnouncementView (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Edit = 0x20; // "CompositeButtonView"
            inline constexpr std::uintptr_t Save = 0x28; // "CompositeButtonView"
            inline constexpr std::uintptr_t Cancel = 0x30; // "CompositeButtonView"
            inline constexpr std::uintptr_t InputField = 0x38; // "InputFieldWithLimitCounterView"
            inline constexpr std::uintptr_t label = 0x40; // "TextMeshProUGUI"
            inline constexpr std::uintptr_t editState = 0x48; // "StateGroup"
            inline constexpr std::uintptr_t isEdit = 0x50; // "bool"
            inline constexpr std::uintptr_t isLabelEmpty = 0x51; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetLabel = 0x3697510; // "public void SetLabel(string label)"
            inline constexpr std::uintptr_t SetEdit = 0x3697500; // "public void SetEdit(bool value)"
            inline constexpr std::uintptr_t UpdateState = 0x36975A0; // "private void UpdateState()"
        }
    } // namespace ClanAnnouncementView

    namespace ClanAnnouncementViewUpdater { // "Game.Global.Clan.ClanDialog.ClanAnnouncementViewUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t clanModel = 0x10; // "ClanModel"
            inline constexpr std::uintptr_t personalNotificationModel = 0x18; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t clanLocalization = 0x20; // "ClanLocalization"
            inline constexpr std::uintptr_t view = 0x28; // "ClanAnnouncementView"
            inline constexpr std::uintptr_t dialogModel = 0x30; // "ClanDialogModel"
            inline constexpr std::uintptr_t isAnnouncementEdit = 0x38; // "bool"
            inline constexpr std::uintptr_t uiSoundModel = 0x40; // "GlobalUISoundModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x3697130; // "public void Update()"
            inline constexpr std::uintptr_t UpdateAnnouncement = 0x36970B0; // "private void UpdateAnnouncement()"
        }
    } // namespace ClanAnnouncementViewUpdater

    namespace ClanAppointmentNotificationUpdater { // "Game.Global.PopupNotificationDialog.ClanAppointmentNotificationUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t clanModel = 0x10; // "ClanModel"
            inline constexpr std::uintptr_t globalNotificationModel = 0x18; // "GlobalNotificationModel"
            inline constexpr std::uintptr_t clanBattleAppointmentNotificationsModel = 0x20; // "ClanBattleAppointmentNotificationsModel"
            inline constexpr std::uintptr_t now = 0x28; // "INow"
            inline constexpr std::uintptr_t battleRoomModel = 0x30; // "RegionUserBattleRoomModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x35A9EA0; // "public void Update()"
        }
    } // namespace ClanAppointmentNotificationUpdater

    namespace ClanAppointmentsContainer { // "Game.Global.Clan.ClanDialog.AppointmentsContainer.ClanAppointmentsContainer (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t BetsContainer = 0x20; // "Transform"
            inline constexpr std::uintptr_t ShowdownsContainer = 0x28; // "Transform"
            inline constexpr std::uintptr_t betsEmptyState = 0x30; // "StateElementBase"
            inline constexpr std::uintptr_t showdownsEmptyState = 0x38; // "StateElementBase"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetBetsEmpty = 0x97CF70; // "public void SetBetsEmpty(ClanAppointmentsContainer.EmptyState value)"
            inline constexpr std::uintptr_t SetShowdownsEmpty = 0x3597860; // "public void SetShowdownsEmpty(ClanAppointmentsContainer.EmptyState value)"
        }
    } // namespace ClanAppointmentsContainer

    namespace ClanAppointmentsContainerUpdater { // "Game.Global.Clan.ClanDialog.AppointmentsContainer.ClanAppointmentsContainerUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dialogModel = 0x10; // "ClanDialogModel"
            inline constexpr std::uintptr_t showdownsUpdater = 0x18; // "IUpdater"
            inline constexpr std::uintptr_t betsUpdater = 0x20; // "IUpdater"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x36B78B0; // "public void Update()"
        }
    } // namespace ClanAppointmentsContainerUpdater

    namespace ClanAppointmentsInputUpdater { // "Game.Global.Clan.ClanDialog.ClanAppointmentsInputUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t globalModel = 0x10; // "GlobalModel"
            inline constexpr std::uintptr_t globalScreenContent = 0x18; // "GlobalScreenContent"
            inline constexpr std::uintptr_t dialogModel = 0x20; // "ClanDialogModel"
            inline constexpr std::uintptr_t roomConnections = 0x28; // "IRoomConnections"
            inline constexpr std::uintptr_t clanLocalization = 0x30; // "ClanLocalization"
            inline constexpr std::uintptr_t partyLocalization = 0x38; // "PartyLocalization"
            inline constexpr std::uintptr_t hasActiveVehicle = 0x40; // "Func<bool>"
            inline constexpr std::uintptr_t inputActions = 0x48; // "InputActions"
            inline constexpr std::uintptr_t updater = 0x50; // "IUpdater"
            inline constexpr std::uintptr_t inProgress = 0x58; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t OnClickShowdownEnter = 0x3697960; // "private void OnClickShowdownEnter(ProtectionContext protectionContext)"
            inline constexpr std::uintptr_t Enter = 0x3697630; // "private void Enter(ProtectionContext protectionContext)"
            inline constexpr std::uintptr_t OnClickBetCancel = 0x36977D0; // "private void OnClickBetCancel(ProtectionContext protectionContext)"
            inline constexpr std::uintptr_t OnCancelBet = 0x3697700; // "private void OnCancelBet(ProtectionContext protectionContext)"
            inline constexpr std::uintptr_t Update = 0x3697E20; // "public void Update()"
        }
    } // namespace ClanAppointmentsInputUpdater

    namespace ClanAppointmentsNotificationUpdater { // "Game.Global.Clan.ClanDialog.ClanAppointmentsNotificationUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t clanModel = 0x10; // "ClanModel"
            inline constexpr std::uintptr_t dialogModel = 0x18; // "ClanDialogModel"
            inline constexpr std::uintptr_t now = 0x20; // "INow"
            inline constexpr std::uintptr_t tabView = 0x28; // "TabView<ClanTabs>"
            inline constexpr std::uintptr_t isVisible = 0x30; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x36984E0; // "public void Update()"
            inline constexpr std::uintptr_t GetIsActive = 0x36981A0; // "private bool GetIsActive(long now)"
        }
    } // namespace ClanAppointmentsNotificationUpdater

    namespace ClanAuctionExtensions { // "Models.Utils.Extensions.ClanAuctionExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t IsClanParticipatingInAuctionOrHasItems_T_inst_1 = 0x156EFC0; // "ClanAuctionExtensions.IsClanParticipatingInAuctionOrHasItems<object>"
        }
    } // namespace ClanAuctionExtensions

    namespace ClanBattleAppointmentData { // "Models.Data.Clan.ClanBattleAppointmentData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t PeriodIndex = 0x20; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t IsDefender = 0x28; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t ClanId = 0x30; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t ClanTag = 0x38; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t ClanName = 0x40; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t ClanEmblem = 0x48; // "IPrimitiveData<ClanEmblemDescription>"
            inline constexpr std::uintptr_t StartOffsetIndex = 0x50; // "IPrimitiveData<int>"
        }
    } // namespace ClanBattleAppointmentData

    namespace ClanBattleAppointmentModel { // "Game.Global.Clan.Model.ClanBattleAppointmentModel (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "ClanBattleAppointmentData"
            inline constexpr std::uintptr_t clanBattleAuctionPeriodConfig = 0x18; // "ClanBattleAuctionPeriodConfig"
            inline constexpr std::uintptr_t clanBattleTier = 0x20; // "ClanBattleTierDescription"
            inline constexpr std::uintptr_t regionTsOffset = 0x28; // "IPrimitiveData<long>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_HasAppointment = 0x367F060; // "public bool get_HasAppointment()"
            inline constexpr std::uintptr_t get_PeriodIndex = 0x367F110; // "public int get_PeriodIndex()"
            inline constexpr std::uintptr_t get_StartOffsetIndex = 0x367F160; // "public int get_StartOffsetIndex()"
            inline constexpr std::uintptr_t get_IsDefender = 0x367F0C0; // "public bool get_IsDefender()"
            inline constexpr std::uintptr_t get_ClanId = 0x367EF70; // "public string get_ClanId()"
            inline constexpr std::uintptr_t get_ClanTag = 0x367F010; // "public string get_ClanTag()"
            inline constexpr std::uintptr_t get_ClanName = 0x367EFC0; // "public string get_ClanName()"
            inline constexpr std::uintptr_t GetStartTs = 0x367EDB0; // "public long GetStartTs()"
            inline constexpr std::uintptr_t GetPreparePhaseEndTs = 0x367ED70; // "public long GetPreparePhaseEndTs()"
            inline constexpr std::uintptr_t GetPhaseTimesConfig = 0x367ED50; // "public ClanBattlePhaseTimesConfig GetPhaseTimesConfig()"
            inline constexpr std::uintptr_t IsAppointmentWithPreparePhase = 0x367EEC0; // "public bool IsAppointmentWithPreparePhase(long now)"
        }
    } // namespace ClanBattleAppointmentModel

    namespace ClanBattleAppointmentNotificationsModel { // "Game.Global.ClanBattleAppointmentNotificationsModel (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t showedSet = 0x10; // "HashSet<ProtectionContext>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Remove = 0x3657CD0; // "public void Remove(ProtectionContext protectionContext)"
            inline constexpr std::uintptr_t Add = 0x3657C10; // "public void Add(ProtectionContext protectionContext)"
            inline constexpr std::uintptr_t Contains = 0x3657C70; // "public bool Contains(ProtectionContext protectionContext)"
        }
    } // namespace ClanBattleAppointmentNotificationsModel

    namespace ClanBattleAuctionConfig { // "Models.References.ClanBattle.ClanBattleAuctionConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t SectorTierAvailableForBetIfNoSectorOwnedFunc = 0x10; // "Func<TierDescription>"
            inline constexpr std::uintptr_t ClanBattleBetExpiringResource = 0x18; // "ExpiringResourceDescription"
            inline constexpr std::uintptr_t ChangeStartOffsetIndexExpiringResource = 0x20; // "ExpiringResourceDescription"
            inline constexpr std::uintptr_t SectorsAuctionPeriodConfig = 0x28; // "ClanBattleAuctionPeriodConfig"
            inline constexpr std::uintptr_t ObjectsAuctionPeriodConfig = 0x30; // "ClanBattleAuctionPeriodConfig"
            inline constexpr std::uintptr_t ClanBattlePeriodIndexMax = 0x38; // "int"
            inline constexpr std::uintptr_t ClanBattleStartOffsetsCountMax = 0x3C; // "int"
            inline constexpr std::uintptr_t BetPhaseEndMaxAdditionalTime = 0x40; // "long"
            inline constexpr std::uintptr_t AppointmentEndMinAdditionalTime = 0x48; // "long"
            inline constexpr std::uintptr_t AppointmentEndMaxAdditionalTime = 0x50; // "long"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_SectorTierAvailableForBetIfNoSectorOwned = 0x1765CB0; // "public TierDescription get_SectorTierAvailableForBetIfNoSectorOwned()"
        }
    } // namespace ClanBattleAuctionConfig

    namespace ClanBattleAuctionPeriodConfig { // "Models.References.ClanBattle.ClanBattleAuctionPeriodConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Period = 0x10; // "long"
            inline constexpr std::uintptr_t PeriodStartTs = 0x18; // "long"
            inline constexpr std::uintptr_t BetsPhaseDuration = 0x20; // "long"
            inline constexpr std::uintptr_t ClanBattleStartTsSincePeriodStart = 0x28; // "long"
            inline constexpr std::uintptr_t ClanBattleStartOffsetTime = 0x30; // "long"
            inline constexpr std::uintptr_t ClanBattleStartOffsetsCount = 0x38; // "int"
            inline constexpr std::uintptr_t ClanBattleDefaultStartOffsetIndex = 0x3C; // "int"
        }
    } // namespace ClanBattleAuctionPeriodConfig

    namespace ClanBattleAuctionPresetDescription { // "Models.References.ClanBattle.ClanBattleAuctionPresetDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x81D99F8; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace Fields {
            inline constexpr std::uintptr_t SectorsAuctionPeriodConfig = 0x10; // "ClanBattleAuctionPeriodConfig"
            inline constexpr std::uintptr_t ObjectsAuctionPeriodConfig = 0x18; // "ClanBattleAuctionPeriodConfig"
            inline constexpr std::uintptr_t TiersPhaseTimesPreset = 0x20; // "ClanBattleTiersPhaseTimesPreset"
        }
        namespace StaticFields {
            inline constexpr std::uintptr_t Develop = 0x0; // "ClanBattleAuctionPresetDescription"
            inline constexpr std::uintptr_t Performance = 0x8; // "ClanBattleAuctionPresetDescription"
            inline constexpr std::uintptr_t Night = 0x10; // "ClanBattleAuctionPresetDescription"
            inline constexpr std::uintptr_t Playtest = 0x18; // "ClanBattleAuctionPresetDescription"
            inline constexpr std::uintptr_t Production = 0x20; // "ClanBattleAuctionPresetDescription"
        }
    } // namespace ClanBattleAuctionPresetDescription

    namespace ClanBattleAuctionTimeRules { // "Models.Models.ClanBattleAuctionTime.ClanBattleAuctionTimeRules (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t GetPeriodIndex = 0x497F150; // "public static int GetPeriodIndex(long now, ClanBattleAuctionPeriodConfig periodConfig, long regionTsOffset)"
            inline constexpr std::uintptr_t GetBetsPhaseEndTs = 0x497F080; // "public static long GetBetsPhaseEndTs(int periodIndex, ClanBattleAuctionPeriodConfig periodConfig, long regionTsOffset)"
            inline constexpr std::uintptr_t GetPeriodStartTs = 0x497F180; // "public static long GetPeriodStartTs(int periodIndex, ClanBattleAuctionPeriodConfig periodConfig, long regionTsOffset)"
            inline constexpr std::uintptr_t GetClanBattleStartTsSincePeriodStart = 0x497F0F0; // "public static long GetClanBattleStartTsSincePeriodStart(int startOffsetIndex, ClanBattleAuctionPeriodConfig periodConfig)"
            inline constexpr std::uintptr_t IsBetsPhaseActive = 0x497F1B0; // "public static bool IsBetsPhaseActive(long now, ClanBattleAuctionPeriodConfig periodConfig, long regionTsOffset)"
            inline constexpr std::uintptr_t IsBetsPhaseActive_2 = 0x497F200; // "public static bool IsBetsPhaseActive(long now, int periodIndex, ClanBattleAuctionPeriodConfig periodConfig, long regionTsOffset)"
            inline constexpr std::uintptr_t GetClanBattleStartTs = 0x497F110; // "public static long GetClanBattleStartTs(int periodIndex, int startOffsetIndex, ClanBattleAuctionPeriodConfig periodConfig, long regionTsOffset)"
            inline constexpr std::uintptr_t GetClanBattleEndTs = 0x497F0B0; // "public static long GetClanBattleEndTs(int periodIndex, int startOffsetIndex, ClanBattleAuctionPeriodConfig periodConfig, ClanBattlePhaseTimesConfig phaseTimesConfig, long regionTsOffset)"
            inline constexpr std::uintptr_t CanChangeStartOffsetIndex = 0x497F020; // "public static bool CanChangeStartOffsetIndex(long now, ClanBattleAuctionPeriodConfig periodConfig, long regionTsOffset)"
        }
    } // namespace ClanBattleAuctionTimeRules

    namespace ClanBattleBetData { // "Models.Data.Clan.ClanBattleBetData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsActive = 0x20; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t PeriodIndex = 0x28; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t ClanId = 0x30; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t ClanName = 0x38; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t ClanTag = 0x40; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t Emblem = 0x48; // "IPrimitiveData<ClanEmblemDescription>"
            inline constexpr std::uintptr_t StartOffsetIndex = 0x50; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t Amount = 0x58; // "IPrimitiveData<int>"
        }
    } // namespace ClanBattleBetData

    namespace ClanBattleBetModel { // "Game.Global.Clan.Model.ClanBattleBetModel (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "ClanBattleBetData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsActive = 0x367F350; // "public bool get_IsActive()"
            inline constexpr std::uintptr_t get_HasClan = 0x367F2F0; // "public bool get_HasClan()"
            inline constexpr std::uintptr_t get_PeriodIndex = 0x367F3A0; // "public int get_PeriodIndex()"
            inline constexpr std::uintptr_t get_StartOffsetIndex = 0x367F3F0; // "public int get_StartOffsetIndex()"
            inline constexpr std::uintptr_t get_ClanId = 0x367F200; // "public string get_ClanId()"
            inline constexpr std::uintptr_t get_ClanName = 0x367F250; // "public string get_ClanName()"
            inline constexpr std::uintptr_t get_ClanTag = 0x367F2A0; // "public string get_ClanTag()"
            inline constexpr std::uintptr_t get_Amount = 0x367F1B0; // "public int get_Amount()"
        }
    } // namespace ClanBattleBetModel

    namespace ClanBattleBetProcessData { // "Models.Data.Clan.ClanBattleBetProcessData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsAdding = 0x20; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t Object = 0x28; // "IPrimitiveData<ClanConquestObjectTypeDescription>"
            inline constexpr std::uintptr_t Sector = 0x30; // "IPrimitiveData<SectorDescription>"
            inline constexpr std::uintptr_t PeriodIndex = 0x38; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t Amount = 0x40; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t MemberName = 0x48; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t MemberPublicId = 0x50; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t MemberClanRank = 0x58; // "IPrimitiveData<ClanRankDescription>"
        }
    } // namespace ClanBattleBetProcessData

    namespace ClanBattleChatGreetingsUpdater { // "Game.Battle.ClanBattle.ClanBattleChatGreetingsUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t clanBattleModel = 0x10; // "ClanBattleModel"
            inline constexpr std::uintptr_t rulesSource = 0x18; // "SystemChatMessageSource"
            inline constexpr std::uintptr_t sectorsViewDescription = 0x20; // "SectorsViewDescription"
            inline constexpr std::uintptr_t greetings = 0x28; // "Text<string>"
            inline constexpr std::uintptr_t sectorDescription = 0x30; // "SectorDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xCF1FF0; // "public void Update()"
        }
    } // namespace ClanBattleChatGreetingsUpdater

    namespace ClanBattleClanData { // "Models.Models.ClanBattleClan.ClanBattleClanData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Id = 0x10; // "string"
            inline constexpr std::uintptr_t Name = 0x18; // "string"
            inline constexpr std::uintptr_t Tag = 0x20; // "string"
            inline constexpr std::uintptr_t Emblem = 0x28; // "ClanEmblemDescription"
        }
    } // namespace ClanBattleClanData

    namespace ClanBattleCompetitorsTeamsSizeDescription { // "Models.References.ClanBattle.ClanBattleCompetitorsTeamsSizeDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t AttackersTeamCapacity = 0x20; // "int"
            inline constexpr std::uintptr_t DefendersTeamCapacity = 0x24; // "int"
        }
    } // namespace ClanBattleCompetitorsTeamsSizeDescription

    namespace ClanBattleCompetitorsTeamsSizeViewDescription { // "Game.Global.Clan.ViewDescriptions.ClanBattleCompetitorsTeamsSizeViewDescription (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Identified = 0x10; // "IdentifiedProperty<ClanBattleCompetitorsTeamsSizeDescription>"
            inline constexpr std::uintptr_t SizeLocalization = 0x18; // "Text"
            inline constexpr std::uintptr_t ConquestBusinessTitleSizeLocalization = 0x20; // "LocalizedString"
            inline constexpr std::uintptr_t LaunderingBonusLocalization = 0x28; // "LocalizedString"
            inline constexpr std::uintptr_t IncomeBonusLocalization = 0x30; // "LocalizedString"
            inline constexpr std::uintptr_t MinClanMoneyLocalization = 0x38; // "LocalizedString"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Id = 0x367F440; // "public string get_Id()"
        }
    } // namespace ClanBattleCompetitorsTeamsSizeViewDescription

    namespace ClanBattleComputedConfig { // "Models.References.ClanBattle.ClanBattleComputedConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t LocationsByClanConquestObjects = 0x10; // "IReadOnlyDictionary<ClanConquestObjectTypeDescription, LocationDescription>"
        }
    } // namespace ClanBattleComputedConfig

    namespace ClanBattleConfig { // "Models.References.ClanBattle.ClanBattleConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t SectorsClanBattleTierFunc = 0x10; // "Func<ClanBattleTierDescription>"
            inline constexpr std::uintptr_t CaptureFlagMaxProgress = 0x18; // "int"
            inline constexpr std::uintptr_t CaptureFlagTickProgressHeatAmount = 0x1C; // "int"
            inline constexpr std::uintptr_t CaptureFlagTickProgressChillAmount = 0x20; // "int"
            inline constexpr std::uintptr_t ClanBattleJoinCooldown = 0x28; // "long"
            inline constexpr std::uintptr_t SectorClanBattleLocationFunc = 0x30; // "Func<LocationDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_SectorsClanBattleTier = 0x1765CB0; // "public ClanBattleTierDescription get_SectorsClanBattleTier()"
            inline constexpr std::uintptr_t get_SectorClanBattleLocation = 0x9AA5D0; // "public LocationDescription get_SectorClanBattleLocation()"
        }
    } // namespace ClanBattleConfig

    namespace ClanBattleConquestObjectTargetActions { // "Game.Battle.ClanBattle.Conquest.ClanBattleConquestObjectTargetActions (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleModel = 0x10; // "BattleModel"
            inline constexpr std::uintptr_t conquestObjectDescription = 0x18; // "LocationClanBattleConquestObjectDescription"
            inline constexpr std::uintptr_t globalModel = 0x20; // "GlobalModel"
            inline constexpr std::uintptr_t personalNotificationModel = 0x28; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t uiSoundModel = 0x30; // "GlobalUISoundModel"
            inline constexpr std::uintptr_t Open = 0x38; // "TargetAction"
        }
        namespace Methods {
            inline constexpr std::uintptr_t OpenDialog = 0xD157C0; // "private void OpenDialog()"
            inline constexpr std::uintptr_t Unavailable = 0xAF9E60; // "private void Unavailable(LocalizedString invalidNotification, PersonalNotificationActionIds id)"
        }
    } // namespace ClanBattleConquestObjectTargetActions

    namespace ClanBattleConquestObjectTargetProvider { // "Game.Battle.ClanBattle.Conquest.ClanBattleConquestObjectTargetProvider (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleEntitiesModel = 0x20; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t targetActions = 0x28; // "ClanBattleConquestObjectTargetActions"
            inline constexpr std::uintptr_t unavailableKeys = 0x30; // "UnavailableTargetActionsKeys"
        }
        namespace Methods {
            inline constexpr std::uintptr_t GetTargetAction = 0xD15B30; // "protected override ITargetAction GetTargetAction()"
        }
    } // namespace ClanBattleConquestObjectTargetProvider

    namespace ClanBattleData { // "Models.Data.ClanBattleData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Phase = 0x20; // "IPrimitiveData<ClanBattlePhaseDescription>"
            inline constexpr std::uintptr_t PhaseEndTs = 0x28; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t ConquestObjectType = 0x30; // "IPrimitiveData<ClanConquestObjectTypeDescription>"
            inline constexpr std::uintptr_t ConquestSector = 0x38; // "IPrimitiveData<SectorDescription>"
            inline constexpr std::uintptr_t Defenders = 0x40; // "ClanBattleTeamData"
            inline constexpr std::uintptr_t Attackers = 0x48; // "ClanBattleTeamData"
            inline constexpr std::uintptr_t FlagCaptureProgress = 0x50; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t IsFlagCapturePause = 0x58; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t Winner = 0x60; // "IPrimitiveData<ClanBattleTeamDescription>"
        }
    } // namespace ClanBattleData

    namespace ClanBattleDescription { // "Models.References.ClanBattle.ClanBattleDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x81DB558; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t StartPhase = 0x0; // "ClanBattlePhaseDescription"
        }
    } // namespace ClanBattleDescription

    namespace ClanBattleEnterDialogInputHandler { // "Game.Global.Clan.ClanBattleEnterDialog.ClanBattleEnterDialogInputHandler (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t globalModel = 0x10; // "GlobalModel"
            inline constexpr std::uintptr_t globalScreenContent = 0x18; // "GlobalScreenContent"
            inline constexpr std::uintptr_t dialogModel = 0x20; // "ClanBattleEnterDialogModel"
            inline constexpr std::uintptr_t inputActions = 0x28; // "InputActions"
            inline constexpr std::uintptr_t roomConnections = 0x30; // "IRoomConnections"
            inline constexpr std::uintptr_t dialogView = 0x38; // "ClanBattleEnterDialogView"
            inline constexpr std::uintptr_t clanLocalization = 0x40; // "ClanLocalization"
            inline constexpr std::uintptr_t partyLocalization = 0x48; // "PartyLocalization"
            inline constexpr std::uintptr_t playerPrefsModel = 0x50; // "PlayerPrefsModel"
            inline constexpr std::uintptr_t uiSoundModel = 0x58; // "GlobalUISoundModel"
            inline constexpr std::uintptr_t personalNotificationModel = 0x60; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t dontShowAgain = 0x68; // "ChangeBuffer<bool>"
            inline constexpr std::uintptr_t partyModel = 0x70; // "PartyModel"
            inline constexpr std::uintptr_t inProgress = 0x78; // "bool"
            inline constexpr std::uintptr_t Handlers = 0x80; // "ValueTuple<InputMask, IUpdater>[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Priority = 0x7E5DA0; // "public InputHandlerPriority get_Priority()"
            inline constexpr std::uintptr_t CloseDialog = 0x3686AE0; // "private void CloseDialog()"
            inline constexpr std::uintptr_t OnSubmit = 0x36B7D60; // "private void OnSubmit()"
            inline constexpr std::uintptr_t Enter = 0x36B7CB0; // "private void Enter()"
            inline constexpr std::uintptr_t SaveAndClose = 0x36B80F0; // "private void SaveAndClose()"
            inline constexpr std::uintptr_t SetSkipShowClanBattleEnter = 0x36B8150; // "private void SetSkipShowClanBattleEnter(bool result)"
        }
    } // namespace ClanBattleEnterDialogInputHandler

    namespace ClanBattleEnterDialogModel { // "Game.Global.Clan.ClanBattleEnterDialog.ClanBattleEnterDialogModel (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ProtectionContext = 0x18; // "ProtectionContext"
            inline constexpr std::uintptr_t HasActiveVehicle = 0x20; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Open = 0x36B8A80; // "public void Open(ProtectionContext protectionContext, bool hasActiveVehicle)"
        }
    } // namespace ClanBattleEnterDialogModel

    namespace ClanBattleEnterDialogUpdater { // "Game.Global.Clan.ClanBattleEnterDialog.ClanBattleEnterDialogUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t updater = 0x10; // "IUpdater"
            inline constexpr std::uintptr_t clanModel = 0x18; // "ClanModel"
            inline constexpr std::uintptr_t dialogModel = 0x20; // "ClanBattleEnterDialogModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x36B8AC0; // "public void Update()"
        }
    } // namespace ClanBattleEnterDialogUpdater

    namespace ClanBattleEnterDialogView { // "Game.Global.Clan.ClanBattleEnterDialog.ClanBattleEnterDialogView (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Back = 0x20; // "CompositeButtonView"
            inline constexpr std::uintptr_t Cancel = 0x28; // "CompositeButtonView"
            inline constexpr std::uintptr_t Submit = 0x30; // "CompositeButtonView"
            inline constexpr std::uintptr_t ToggleView = 0x38; // "ToggleStateView"
            inline constexpr std::uintptr_t BgClose = 0x40; // "ClickButtonView"
        }
    } // namespace ClanBattleEnterDialogView

    namespace ClanBattleExtension { // "Models.Utils.Extensions.ClanBattleExtension (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t GetClanBattleLocation = 0x3940EF0; // "public static LocationDescription GetClanBattleLocation(ClanConquestObjectTypeDescription clanConquestObjectType)"
            inline constexpr std::uintptr_t TryGetLocationClanBattleConquestObject = 0x39413A0; // "public static bool TryGetLocationClanBattleConquestObject(LocationDescription locationDescription, ClanBattleModel clanBattleModel, out LocationClanBattleConquestObjectDescription locationClanBattleConquestObjectDescription)"
            inline constexpr std::uintptr_t GetLocationClanBattleConquestObject = 0x3941160; // "public static LocationClanBattleConquestObjectDescription GetLocationClanBattleConquestObject(LocationDescription locationDescription, ClanBattleModel clanBattleModel)"
            inline constexpr std::uintptr_t GetClanBattleTier = 0x39410C0; // "public static ClanBattleTierDescription GetClanBattleTier(SectorDescription sector, ClanConquestObjectTypeDescription clanConquestObject)"
            inline constexpr std::uintptr_t GetClanBattleTier_2 = 0x3941060; // "public static ClanBattleTierDescription GetClanBattleTier(SectorDescription sector)"
            inline constexpr std::uintptr_t GetClanBattleTier_3 = 0x3941140; // "public static ClanBattleTierDescription GetClanBattleTier(ClanConquestObjectTypeDescription clanConquestObject)"
            inline constexpr std::uintptr_t IsInTeamClan = 0x39412B0; // "public static bool IsInTeamClan(RegionUserClanModel clanModel, ClanBattleTeamDescription team, ClanBattleClanData defenseClan, ClanBattleClanData attackClan)"
        }
    } // namespace ClanBattleExtension

    namespace ClanBattleFlagCaptureModel { // "Models.Models.ClanBattleFlagCapture.ClanBattleFlagCaptureModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t progress = 0x10; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t isPause = 0x18; // "IPrimitiveData<bool>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsPaused = 0x497F9A0; // "public bool get_IsPaused()"
            inline constexpr std::uintptr_t set_IsPaused = 0x497FA40; // "public void set_IsPaused(bool value)"
            inline constexpr std::uintptr_t get_Progress = 0x497F9F0; // "public int get_Progress()"
            inline constexpr std::uintptr_t set_Progress = 0x497FA90; // "public void set_Progress(int value)"
            inline constexpr std::uintptr_t get_IsFinished = 0x497F910; // "public bool get_IsFinished()"
        }
    } // namespace ClanBattleFlagCaptureModel

    namespace ClanBattleFlagIsUnderAttackUpdater { // "Game.Battle.ClanBattle.ClanBattleFlagIsUnderAttackUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t hud = 0x10; // "ClanBattleFlagHudView"
            inline constexpr std::uintptr_t clanBattleModel = 0x18; // "ClanBattleModel"
            inline constexpr std::uintptr_t location = 0x20; // "LocationDescription"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x28; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t scene = 0x30; // "PhysicsSceneModel"
            inline constexpr std::uintptr_t bodies = 0x38; // "PhysicsBodiesModel"
            inline constexpr std::uintptr_t slotsModel = 0x40; // "ClientCharacterSlotsModel"
            inline constexpr std::uintptr_t bodyIds = 0x48; // "List<PhysicsBodyId>"
            inline constexpr std::uintptr_t clanBattleTeamsCacheModel = 0x50; // "ClanBattleTeamsCacheModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xCF44F0; // "public void Update()"
            inline constexpr std::uintptr_t GetClanBattleFlagState = 0xCF4090; // "private FlagState GetClanBattleFlagState(LocationClanBattleConquestObjectDescription contestedObject)"
            inline constexpr std::uintptr_t CheckByCharactersInVehicle = 0xCF3B70; // "private void CheckByCharactersInVehicle(LocationClanBattleConquestObjectDescription contestedObject, PhysicsBodyId bodyId, ref bool hasAttacker, ref bool hasDefender)"
            inline constexpr std::uintptr_t CheckByCharacter = 0xCF38D0; // "private void CheckByCharacter(LocationClanBattleConquestObjectDescription contestedObject, PhysicsBodyId bodyId, ref bool hasAttacker, ref bool hasDefender)"
            inline constexpr std::uintptr_t IsAttacker = 0xCF43B0; // "private bool IsAttacker(BattleCharacterSlotModel slotModel)"
            inline constexpr std::uintptr_t IsDefender = 0xCF4450; // "private bool IsDefender(BattleCharacterSlotModel slotModel)"
            inline constexpr std::uintptr_t Dispose = 0xCF4060; // "private void Dispose()"
        }
    } // namespace ClanBattleFlagIsUnderAttackUpdater

    namespace ClanBattleFlagMapUpdater { // "Game.Battle.ClanBattle.ClanBattleFlagMapUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t mapMarkersModel = 0x10; // "MapMarkersModel"
            inline constexpr std::uintptr_t clanBattleTeamsCacheModel = 0x18; // "ClanBattleTeamsCacheModel"
            inline constexpr std::uintptr_t location = 0x20; // "LocationDescription"
            inline constexpr std::uintptr_t clanBattleModel = 0x28; // "ClanBattleModel"
            inline constexpr std::uintptr_t battleScreenContent = 0x30; // "BattleScreenContent"
            inline constexpr std::uintptr_t flagMarkerModel = 0x38; // "StaticMapMarkerModel"
            inline constexpr std::uintptr_t oldTeam = 0x40; // "ClanBattleTeamDescription"
            inline constexpr std::uintptr_t oldObjectDescription = 0x48; // "LocationClanBattleConquestObjectDescription"
            inline constexpr std::uintptr_t phase = 0x50; // "ClanBattlePhaseDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xCF49F0; // "public void Update()"
            inline constexpr std::uintptr_t Dispose = 0xCF49A0; // "private void Dispose()"
        }
    } // namespace ClanBattleFlagMapUpdater

    namespace ClanBattleJoinCooldownModel { // "Models.Models.ClanBattleJoinCooldown.ClanBattleJoinCooldownModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "IPrimitiveData<long>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_EndTs = 0x497FB90; // "private long get_EndTs()"
            inline constexpr std::uintptr_t IsActive = 0x497FAE0; // "public bool IsActive(long now)"
            inline constexpr std::uintptr_t Set = 0x497FB40; // "public void Set(long ts)"
        }
    } // namespace ClanBattleJoinCooldownModel

    namespace ClanBattleLeftReason { // "Models.References.ClanBattle.ClanBattleLeftReason (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x81DCD78; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t enum_id = 0x0; // "Enum<ClanBattleLeftReason>"
            inline constexpr std::uintptr_t Dead = 0x8; // "ClanBattleLeftReason"
            inline constexpr std::uintptr_t Flee = 0x10; // "ClanBattleLeftReason"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Enum = 0x4446AE0; // "public static ReadOnlyEnum<ClanBattleLeftReason> get_Enum()"
        }
    } // namespace ClanBattleLeftReason

    namespace ClanBattleMemberData { // "Models.Data.ClanBattleMemberData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t LeftReason = 0x20; // "IPrimitiveData<ClanBattleLeftReason>"
            inline constexpr std::uintptr_t Rank = 0x28; // "IPrimitiveData<ClanRankDescription>"
            inline constexpr std::uintptr_t BattleCharacterSlot = 0x30; // "IPrimitiveData<BattleCharacterSlotDescription>"
            inline constexpr std::uintptr_t Nickname = 0x38; // "IPrimitiveData<string>"
        }
    } // namespace ClanBattleMemberData

    namespace ClanBattleMemberModel { // "Models.Models.ClanBattleMember.ClanBattleMemberModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "ClanBattleMemberData"
            inline constexpr std::uintptr_t positionData = 0x18; // "ClanBattleCharacterPositionData"
            inline constexpr std::uintptr_t ClanBattleMemberSlotDescription = 0x20; // "ClanBattleMemberSlotDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsEmpty = 0x4980110; // "public bool get_IsEmpty()"
            inline constexpr std::uintptr_t get_IsAlive = 0x4980050; // "public bool get_IsAlive()"
            inline constexpr std::uintptr_t get_BattleCharacterSlotDescription = 0x497FF80; // "public BattleCharacterSlotDescription get_BattleCharacterSlotDescription()"
            inline constexpr std::uintptr_t get_LeftReason = 0x4980170; // "public ClanBattleLeftReason get_LeftReason()"
            inline constexpr std::uintptr_t get_Rank = 0x4980290; // "public ClanRankDescription get_Rank()"
            inline constexpr std::uintptr_t get_Nickname = 0x4980240; // "public string get_Nickname()"
            inline constexpr std::uintptr_t Set = 0x497FCF0; // "public void Set(BattleCharacterSlotDescription slotDescription, ClanRankDescription rank, string nickname)"
            inline constexpr std::uintptr_t UpdateClanRank = 0x497FF20; // "public void UpdateClanRank(ClanRankDescription clanRank)"
            inline constexpr std::uintptr_t Unset = 0x497FDD0; // "public void Unset()"
            inline constexpr std::uintptr_t get_X = 0x49802E0; // "public int get_X()"
            inline constexpr std::uintptr_t get_Z = 0x4980330; // "public int get_Z()"
            inline constexpr std::uintptr_t SetPosition = 0x497FC70; // "public void SetPosition(int x, int z)"
            inline constexpr std::uintptr_t SetLeft = 0x497FBE0; // "public void SetLeft(ClanBattleLeftReason leftReason)"
        }
    } // namespace ClanBattleMemberModel

    namespace ClanBattleMemberSlotDescription { // "Models.References.ClanBattle.ClanBattleMemberSlotDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x81DD3E0; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t enum_id = 0x0; // "Enum<ClanBattleMemberSlotDescription>"
            inline constexpr std::uintptr_t Slot0 = 0x8; // "ClanBattleMemberSlotDescription"
            inline constexpr std::uintptr_t Slot1 = 0x10; // "ClanBattleMemberSlotDescription"
            inline constexpr std::uintptr_t Slot2 = 0x18; // "ClanBattleMemberSlotDescription"
            inline constexpr std::uintptr_t Slot3 = 0x20; // "ClanBattleMemberSlotDescription"
            inline constexpr std::uintptr_t Slot4 = 0x28; // "ClanBattleMemberSlotDescription"
            inline constexpr std::uintptr_t Slot5 = 0x30; // "ClanBattleMemberSlotDescription"
            inline constexpr std::uintptr_t Slot6 = 0x38; // "ClanBattleMemberSlotDescription"
            inline constexpr std::uintptr_t Slot7 = 0x40; // "ClanBattleMemberSlotDescription"
            inline constexpr std::uintptr_t Slot8 = 0x48; // "ClanBattleMemberSlotDescription"
            inline constexpr std::uintptr_t Slot9 = 0x50; // "ClanBattleMemberSlotDescription"
            inline constexpr std::uintptr_t Slot10 = 0x58; // "ClanBattleMemberSlotDescription"
            inline constexpr std::uintptr_t Slot11 = 0x60; // "ClanBattleMemberSlotDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Enum = 0x4447110; // "public static ReadOnlyEnum<ClanBattleMemberSlotDescription> get_Enum()"
        }
    } // namespace ClanBattleMemberSlotDescription

    namespace ClanBattleMembersModel { // "Models.Models.ClanBattleMembers.ClanBattleMembersModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t free = 0x10; // "List<ClanBattleMemberSlotDescription>"
            inline constexpr std::uintptr_t modelByMemberSlot = 0x18; // "Dictionary<ClanBattleMemberSlotDescription, ClanBattleMemberModel>"
            inline constexpr std::uintptr_t modelByCharacterSlot = 0x20; // "Dictionary<BattleCharacterSlotDescription, ClanBattleMemberModel>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_MemberModelByMemberSlot = 0x7E7130; // "public IReadOnlyDictionary<ClanBattleMemberSlotDescription, ClanBattleMemberModel> get_MemberModelByMemberSlot()"
            inline constexpr std::uintptr_t Add = 0x4980380; // "public void Add(BattleCharacterSlotDescription slotDescription, ClanRankDescription rank, string nickname)"
            inline constexpr std::uintptr_t Remove = 0x49806E0; // "public void Remove(BattleCharacterSlotDescription slotDescription)"
            inline constexpr std::uintptr_t CharacterLeftBattle = 0x4980530; // "public void CharacterLeftBattle(BattleCharacterSlotDescription slotDescription, ClanBattleLeftReason leftReason)"
            inline constexpr std::uintptr_t TryGetModel = 0x4980930; // "public bool TryGetModel(BattleCharacterSlotDescription slot, out ClanBattleMemberModel clanBattleMemberModel)"
            inline constexpr std::uintptr_t GetEnumerator = 0x4980640; // "public IEnumerator<ClanBattleMemberModel> GetEnumerator()"
            inline constexpr std::uintptr_t System_Collections_IEnumerable_GetEnumerator = 0x4980640; // "private IEnumerator System.Collections.IEnumerable.GetEnumerator()"
        }
    } // namespace ClanBattleMembersModel

    namespace ClanBattleModel { // "Models.Models.ClanBattle.ClanBattleModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t teams = 0x10; // "Dictionary<ClanBattleTeamDescription, ClanBattleTeamModel>"
            inline constexpr std::uintptr_t ConquestObjectTypeModel = 0x18; // "IPrimitiveModel<ClanConquestObjectTypeDescription>"
            inline constexpr std::uintptr_t ConquestSectorModel = 0x20; // "IPrimitiveModel<SectorDescription>"
            inline constexpr std::uintptr_t Attacker = 0x28; // "ClanBattleTeamModel"
            inline constexpr std::uintptr_t Defender = 0x30; // "ClanBattleTeamModel"
            inline constexpr std::uintptr_t Phase = 0x38; // "ClanBattlePhaseModel"
            inline constexpr std::uintptr_t FlagCapture = 0x40; // "ClanBattleFlagCaptureModel"
            inline constexpr std::uintptr_t Winner = 0x48; // "IPrimitiveModel<ClanBattleTeamDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_ClanBattleTier = 0x49811E0; // "public ClanBattleTierDescription get_ClanBattleTier()"
            inline constexpr std::uintptr_t get_Item = 0x4981270; // "public ClanBattleTeamModel get_Item(ClanBattleTeamDescription team)"
        }
    } // namespace ClanBattleModel

    namespace ClanBattleModeUpdater { // "Game.Battle.ClanBattle.ClanBattleModeUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t zoneUpdater = 0x10; // "ClanBattleUpdater"
            inline constexpr std::uintptr_t updaters = 0x18; // "IUpdater"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xCF6E50; // "public void Update()"
        }
    } // namespace ClanBattleModeUpdater

    namespace ClanBattlePhaseDescription { // "Models.References.ClanBattle.ClanBattlePhaseDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x81DDBE0; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace Fields {
            inline constexpr std::uintptr_t IsTeamZonesBlocked = 0x20; // "bool"
            inline constexpr std::uintptr_t IsFlagCaptureActive = 0x21; // "bool"
            inline constexpr std::uintptr_t IsEndWhenTeamKilled = 0x22; // "bool"
            inline constexpr std::uintptr_t UpdateCharacterLeaveStateOnRemove = 0x23; // "bool"
        }
        namespace StaticFields {
            inline constexpr std::uintptr_t enum_id = 0x0; // "Enum<ClanBattlePhaseDescription>"
            inline constexpr std::uintptr_t Preparation = 0x8; // "ClanBattlePhaseDescription"
            inline constexpr std::uintptr_t Process = 0x10; // "ClanBattlePhaseDescription"
            inline constexpr std::uintptr_t Completion = 0x18; // "ClanBattlePhaseDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Enum = 0x4447A00; // "public static ReadOnlyEnum<ClanBattlePhaseDescription> get_Enum()"
            inline constexpr std::uintptr_t get_CanKickCharacter = 0x4447920; // "public bool get_CanKickCharacter()"
            inline constexpr std::uintptr_t get_CanCharacterEnter = 0x4447800; // "public bool get_CanCharacterEnter()"
            inline constexpr std::uintptr_t get_CanCharacterLeave = 0x4447890; // "public bool get_CanCharacterLeave()"
            inline constexpr std::uintptr_t get_IsPreparation = 0x4447AE0; // "public bool get_IsPreparation()"
            inline constexpr std::uintptr_t get_HasNextPhase = 0x4447A50; // "public bool get_HasNextPhase()"
            inline constexpr std::uintptr_t get_NextPhase = 0x4447B70; // "public ClanBattlePhaseDescription get_NextPhase()"
        }
    } // namespace ClanBattlePhaseDescription

    namespace ClanBattlePhaseGlobalNotificationsUpdater { // "Game.Global.Clan.Updater.ClanBattlePhaseGlobalNotificationsUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t globalModel = 0x10; // "GlobalModel"
            inline constexpr std::uintptr_t objectsPeriodConfig = 0x18; // "ClanBattleAuctionPeriodConfig"
            inline constexpr std::uintptr_t sectorsPeriodConfig = 0x20; // "ClanBattleAuctionPeriodConfig"
            inline constexpr std::uintptr_t now = 0x28; // "INow"
            inline constexpr std::uintptr_t content = 0x30; // "NotInstantiateLoadedContent<GlobalScreenContent>"
            inline constexpr std::uintptr_t objPeriodIndex = 0x38; // "int"
            inline constexpr std::uintptr_t sectorPeriodIndex = 0x3C; // "int"
            inline constexpr std::uintptr_t objClanBattleStartTs = 0x40; // "long"
            inline constexpr std::uintptr_t sectorClanBattleStartTs = 0x48; // "long"
            inline constexpr std::uintptr_t isInited = 0x50; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_RegionTsOffset = 0x36802D0; // "private long get_RegionTsOffset()"
            inline constexpr std::uintptr_t Init = 0x367F4C0; // "private void Init()"
            inline constexpr std::uintptr_t Update = 0x367F830; // "public void Update()"
        }
    } // namespace ClanBattlePhaseGlobalNotificationsUpdater

    namespace ClanBattlePhaseModel { // "Models.Models.ClanBattlePhase.ClanBattlePhaseModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t phase = 0x10; // "IPrimitiveData<ClanBattlePhaseDescription>"
            inline constexpr std::uintptr_t endTs = 0x18; // "IPrimitiveData<long>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Phase = 0x4981400; // "public ClanBattlePhaseDescription get_Phase()"
            inline constexpr std::uintptr_t get_EndTs = 0x49813B0; // "public long get_EndTs()"
            inline constexpr std::uintptr_t Set = 0x4981320; // "public void Set(ClanBattlePhaseDescription phaseDescription, long phaseEndTs)"
            inline constexpr std::uintptr_t Clear = 0x49812D0; // "public void Clear()"
        }
    } // namespace ClanBattlePhaseModel

    namespace ClanBattlePhaseTimesConfig { // "Models.References.ClanBattle.ClanBattlePhaseTimesConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t PreparationTime = 0x10; // "long"
            inline constexpr std::uintptr_t ProcessTime = 0x18; // "long"
            inline constexpr std::uintptr_t CompletionTime = 0x20; // "long"
            inline constexpr std::uintptr_t TotalTime = 0x28; // "long"
        }
        namespace Methods {
            inline constexpr std::uintptr_t GetPhaseDurationTime = 0x4447FE0; // "public long GetPhaseDurationTime(ClanBattlePhaseDescription phase)"
        }
    } // namespace ClanBattlePhaseTimesConfig

    namespace ClanBattleSpawnPointModel { // "Models.Models.ClanBattleSpawnPoint.ClanBattleSpawnPointModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t spawnIndex = 0x10; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t GetSpawnPoint = 0x49814C0; // "public LocationEnterPoint GetSpawnPoint(LocationClanBattleTeamZoneDescription locationClanBattleTeamZoneDescription)"
        }
    } // namespace ClanBattleSpawnPointModel

    namespace ClanBattleSpawnPointsModel { // "Models.Models.ClanBattleSpawnPoints.ClanBattleSpawnPointsModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t locationDescription = 0x10; // "LocationDescription"
            inline constexpr std::uintptr_t clanBattleModel = 0x18; // "ClanBattleModel"
            inline constexpr std::uintptr_t attackerSpawnPointModel = 0x20; // "ClanBattleSpawnPointModel"
            inline constexpr std::uintptr_t defenderSpawnPointModel = 0x28; // "ClanBattleSpawnPointModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t GetAttackerPoint = 0x4981510; // "public LocationEnterPoint GetAttackerPoint()"
            inline constexpr std::uintptr_t GetDefenderPoint = 0x4981590; // "public LocationEnterPoint GetDefenderPoint()"
        }
    } // namespace ClanBattleSpawnPointsModel

    namespace ClanBattleStartAreaMapUpdater { // "Game.Battle.ClanBattle.ClanBattleStartAreaMapUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t mapMarkersModel = 0x10; // "MapMarkersModel"
            inline constexpr std::uintptr_t clanBattleTeamsCacheModel = 0x18; // "ClanBattleTeamsCacheModel"
            inline constexpr std::uintptr_t location = 0x20; // "LocationDescription"
            inline constexpr std::uintptr_t clanBattleModel = 0x28; // "ClanBattleModel"
            inline constexpr std::uintptr_t flagMarkerModel = 0x30; // "AreaMapMarkerModel"
            inline constexpr std::uintptr_t oldTeam = 0x38; // "ClanBattleTeamDescription"
            inline constexpr std::uintptr_t oldObjectDescription = 0x40; // "LocationClanBattleConquestObjectDescription"
            inline constexpr std::uintptr_t phase = 0x48; // "ClanBattlePhaseDescription"
            inline constexpr std::uintptr_t myMapMarker = 0x50; // "IMapMarkerModel"
            inline constexpr std::uintptr_t enemyMapMarker = 0x58; // "IMapMarkerModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xCF8760; // "public void Update()"
            inline constexpr std::uintptr_t CreateZone = 0xCF84A0; // "private IMapMarkerModel CreateZone(LocationClanBattleTeamZoneDescription zone, MapMarkerType markerType)"
            inline constexpr std::uintptr_t Dispose = 0xCF86E0; // "private void Dispose()"
        }
    } // namespace ClanBattleStartAreaMapUpdater

    namespace ClanBattleTeamCacheUpdater { // "Game.Battle.ClanBattleTeamCacheUpdater (Battle.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x81DEA58; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace Fields {
            inline constexpr std::uintptr_t clanBattleTeamsCacheModel = 0x10; // "ClanBattleTeamsCacheModel"
            inline constexpr std::uintptr_t clanBattleModel = 0x18; // "ClanBattleModel"
            inline constexpr std::uintptr_t characterSlotsModel = 0x20; // "ClientCharacterSlotsModel"
            inline constexpr std::uintptr_t publicIdModel = 0x28; // "PublicIdModel"
        }
        namespace StaticFields {
            inline constexpr std::uintptr_t removeList = 0x0; // "List<BattleCharacterSlotDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA50140; // "public void Update()"
            inline constexpr std::uintptr_t UpdateMyTeam = 0xA4F690; // "private void UpdateMyTeam()"
            inline constexpr std::uintptr_t TryFindPlayer = 0xA4F4E0; // "private bool TryFindPlayer(BattleCharacterSlotDescription battleCharacterSlotDescription, HashSet<ClanBattleMemberModel> memberModels, ClanBattleTeamDescription teamDescription)"
            inline constexpr std::uintptr_t UpdateTeam = 0xA4F960; // "private static void UpdateTeam(ClanBattleTeamMembersModel membersModel, ClanBattleMembersModel teamModel)"
        }
    } // namespace ClanBattleTeamCacheUpdater

    namespace ClanBattleTeamData { // "Models.Data.ClanBattleTeamData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ClanId = 0x20; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t ClanName = 0x28; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t ClanTag = 0x30; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t ClanEmblem = 0x38; // "IPrimitiveData<ClanEmblemDescription>"
            inline constexpr std::uintptr_t ClanMembersData = 0x40; // "ReferenceMapData<ClanBattleMemberSlotDescription, ClanBattleMemberData>"
        }
    } // namespace ClanBattleTeamData

    namespace ClanBattleTeamDescription { // "Models.References.ClanBattle.ClanBattleTeamDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x81DED90; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t enum_id = 0x0; // "Enum<ClanBattleTeamDescription>"
            inline constexpr std::uintptr_t Attacker = 0x8; // "ClanBattleTeamDescription"
            inline constexpr std::uintptr_t Defender = 0x10; // "ClanBattleTeamDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Enum = 0x4448600; // "public static ReadOnlyEnum<ClanBattleTeamDescription> get_Enum()"
            inline constexpr std::uintptr_t GetOtherTeam = 0x44481D0; // "public static ClanBattleTeamDescription GetOtherTeam(ClanBattleTeamDescription team)"
        }
    } // namespace ClanBattleTeamDescription

    namespace ClanBattleTeamMembersModel { // "Game.Battle.ClanBattleTeamMembersModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ActiveMembers = 0x10; // "HashSet<ClanBattleMemberModel>"
            inline constexpr std::uintptr_t LeftOrDeadMembers = 0x18; // "HashSet<ClanBattleMemberModel>"
            inline constexpr std::uintptr_t ModelByCharacterSlot = 0x20; // "Dictionary<BattleCharacterSlotDescription, ClanBattleMemberModel>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Clear = 0xA503A0; // "public void Clear()"
        }
    } // namespace ClanBattleTeamMembersModel

    namespace ClanBattleTeamModel { // "Models.Models.ClanBattleTeam.ClanBattleTeamModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "ClanBattleTeamData"
            inline constexpr std::uintptr_t ClanBattleMembersModel = 0x18; // "ClanBattleMembersModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Set = 0x49816E0; // "public void Set(string clanId, string clanName, string clanTag, ClanEmblemDescription clanEmblemDescription)"
            inline constexpr std::uintptr_t get_ClanId = 0x49819E0; // "public string get_ClanId()"
            inline constexpr std::uintptr_t get_ClanName = 0x4981A30; // "public string get_ClanName()"
            inline constexpr std::uintptr_t get_ClanTag = 0x4981A80; // "public string get_ClanTag()"
            inline constexpr std::uintptr_t get_ClanEmblem = 0x4981910; // "public ClanEmblemDescription get_ClanEmblem()"
        }
    } // namespace ClanBattleTeamModel

    namespace ClanBattleTeamRules { // "Models.Models.ClanBattleMatchmakingRules.ClanBattleTeamRules (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t GetLimitForTeam = 0x4981B80; // "public static int GetLimitForTeam(ClanBattleTeamDescription team, ClanBattleModel clanBattleModel)"
            inline constexpr std::uintptr_t GetCapacityByTeam = 0x4981AD0; // "private static int GetCapacityByTeam(ClanBattleTeamDescription team, ClanBattleCompetitorsTeamsSizeDescription sizeDescription)"
        }
    } // namespace ClanBattleTeamRules

    namespace ClanBattleTeamsCacheModel { // "Game.Battle.ClanBattleTeamsCacheModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Attackers = 0x10; // "ClanBattleTeamMembersModel"
            inline constexpr std::uintptr_t Defenders = 0x18; // "ClanBattleTeamMembersModel"
            inline constexpr std::uintptr_t PlayerTeam = 0x20; // "ClanBattleTeamDescription"
            inline constexpr std::uintptr_t PlayerTeamSlot = 0x28; // "ClanBattleMemberSlotDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t IsAlly = 0xA50550; // "public bool IsAlly(BattleCharacterSlotDescription slotDescription)"
            inline constexpr std::uintptr_t Clear = 0xA50510; // "public void Clear()"
            inline constexpr std::uintptr_t TryGetClanBattleTeam = 0xA50640; // "public bool TryGetClanBattleTeam(out ClanBattleTeamMembersModel teamMembersModel)"
        }
    } // namespace ClanBattleTeamsCacheModel

    namespace ClanBattleTeamZonesModel { // "Models.Models.ClanBattleTeamZones.ClanBattleTeamZonesModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t clanBattleModel = 0x10; // "ClanBattleModel"
            inline constexpr std::uintptr_t locationDescription = 0x18; // "LocationDescription"
            inline constexpr std::uintptr_t physicsSceneModel = 0x20; // "PhysicsSceneModel"
            inline constexpr std::uintptr_t bodyIds = 0x28; // "List<PhysicsBodyId>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Block = 0x4981CD0; // "public void Block()"
            inline constexpr std::uintptr_t Unblock = 0x4981EA0; // "public void Unblock()"
        }
    } // namespace ClanBattleTeamZonesModel

    namespace ClanBattleTierDescription { // "Models.References.ClanBattle.ClanBattleTierDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t TeamSizeFunc = 0x20; // "Func<ClanBattleCompetitorsTeamsSizeDescription>"
            inline constexpr std::uintptr_t PhaseTimesConfig = 0x28; // "ClanBattlePhaseTimesConfig"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_TeamSize = 0x9D6230; // "public ClanBattleCompetitorsTeamsSizeDescription get_TeamSize()"
        }
    } // namespace ClanBattleTierDescription

    namespace ClanBattleUpdater { // "ClientCore.ClanBattle.ClanBattleUpdater (Client.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t clanBattleModel = 0x10; // "ClanBattleModel"
            inline constexpr std::uintptr_t clanBattleTeamZonesModel = 0x18; // "ClanBattleTeamZonesModel"
            inline constexpr std::uintptr_t oldPhase = 0x20; // "ClanBattlePhaseDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xE80A10; // "public void Update()"
        }
    } // namespace ClanBattleUpdater

    namespace ClanBetButtonClickInputUpdater { // "Game.Global.Clan.ClanBetDialog.ClanBetButtonClickInputUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t clanModel = 0x10; // "ClanModel"
            inline constexpr std::uintptr_t globalModel = 0x18; // "GlobalModel"
            inline constexpr std::uintptr_t regionUser = 0x20; // "IRoomConnection"
            inline constexpr std::uintptr_t parentScreen = 0x28; // "ScreenModel"
            inline constexpr std::uintptr_t clickButtonView = 0x30; // "ClickButtonView"
            inline constexpr std::uintptr_t cancelButtonView = 0x38; // "ClickButtonView"
            inline constexpr std::uintptr_t inputActions = 0x40; // "InputActions"
            inline constexpr std::uintptr_t protectionContext = 0x48; // "ProtectionContext"
            inline constexpr std::uintptr_t clanLocalization = 0x50; // "ClanLocalization"
            inline constexpr std::uintptr_t roomConnections = 0x58; // "IRoomConnections"
            inline constexpr std::uintptr_t clanBattleAuctionPeriodConfig = 0x60; // "ClanBattleAuctionPeriodConfig"
            inline constexpr std::uintptr_t screenModel = 0x68; // "ScreenModel"
            inline constexpr std::uintptr_t personalNotificationModel = 0x70; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t uiSoundModel = 0x78; // "GlobalUISoundModel"
            inline constexpr std::uintptr_t now = 0x80; // "ISetNow"
            inline constexpr std::uintptr_t modalDialogModel = 0x88; // "ModalDialogModel"
            inline constexpr std::uintptr_t coinsLessThanMinimalBet = 0x90; // "Text<Money>"
            inline constexpr std::uintptr_t globalLocalizationKeys = 0x98; // "GlobalLocalizationKeys"
            inline constexpr std::uintptr_t clanConquestObjectTypeViewDescriptions = 0xA0; // "ClanConquestObjectTypeViewDescriptions"
            inline constexpr std::uintptr_t clanBattleCompetitorsTeamsSizeViewDescriptions = 0xA8; // "ClanBattleCompetitorsTeamsSizeViewDescriptions"
            inline constexpr std::uintptr_t sectorsViewDescription = 0xB0; // "SectorsViewDescription"
            inline constexpr std::uintptr_t updaters = 0xB8; // "List<IUpdater>"
            inline constexpr std::uintptr_t inProgress = 0xC0; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x36BA3F0; // "public void Update()"
            inline constexpr std::uintptr_t OnClanBet = 0x36BA370; // "private void OnClanBet()"
            inline constexpr std::uintptr_t OnClanCancel = 0x36BA3B0; // "private void OnClanCancel()"
            inline constexpr std::uintptr_t OnClanBetOrCancelImplementation = 0x36B9390; // "private void OnClanBetOrCancelImplementation()"
            inline constexpr std::uintptr_t OnCancelBet = 0x36B92E0; // "private void OnCancelBet()"
            inline constexpr std::uintptr_t OnApply = 0x36B91F0; // "private void OnApply(ProtectionContext protectionContext, ModalTransferCoinModel modalTransferCoinModel)"
        }
    } // namespace ClanBetButtonClickInputUpdater

    namespace ClanBetButtonUpdater { // "Game.Global.Clan.ClanBetDialog.ClanBetButtonUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t globalModel = 0x10; // "GlobalModel"
            inline constexpr std::uintptr_t buttonModel = 0x18; // "ButtonModel"
            inline constexpr std::uintptr_t clanModel = 0x20; // "ClanModel"
            inline constexpr std::uintptr_t clanBattleBetModel = 0x28; // "ClanBattleBetModel"
            inline constexpr std::uintptr_t wasAddingClanBattleBet = 0x30; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x36BA950; // "public void Update()"
        }
    } // namespace ClanBetButtonUpdater

    namespace ClanBetDialogTimeUpdater { // "Game.Global.Clan.ClanBetDialog.ClanBetDialogTimeUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t modalCountdownModel = 0x10; // "ModalCountdownModel"
            inline constexpr std::uintptr_t modalDialogModel = 0x18; // "ModalDialogModel"
            inline constexpr std::uintptr_t text = 0x20; // "Text<string>"
            inline constexpr std::uintptr_t clanModel = 0x28; // "ClanModel"
            inline constexpr std::uintptr_t clanBattleBetModel = 0x30; // "ClanBattleBetModel"
            inline constexpr std::uintptr_t realmInfoModel = 0x38; // "RealmInfoModel"
            inline constexpr std::uintptr_t protectionContext = 0x40; // "ProtectionContext"
            inline constexpr std::uintptr_t now = 0x48; // "INow"
            inline constexpr std::uintptr_t clanBattleAuctionPeriodConfig = 0x50; // "ClanBattleAuctionPeriodConfig"
            inline constexpr std::uintptr_t lastPeriodIndex = 0x58; // "int"
            inline constexpr std::uintptr_t lastStartOffsetIndex = 0x5C; // "int"
            inline constexpr std::uintptr_t isCriticalTimeLeft = 0x60; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x36BADB0; // "public void Update()"
            inline constexpr std::uintptr_t GetStartOffsetIndex = 0x36BAC50; // "private int GetStartOffsetIndex()"
        }
    } // namespace ClanBetDialogTimeUpdater

    namespace ClanBetLineView { // "Game.Global.Clan.ClanDialog.AppointmentsContainer.ClanBetLineView (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Authority = 0x20; // "TextLabel<Money>"
            inline constexpr std::uintptr_t ClanName = 0x28; // "TextLabel<string, string>"
            inline constexpr std::uintptr_t Date = 0x30; // "LocalizedDateView"
            inline constexpr std::uintptr_t Cancel = 0x38; // "CompositeButtonView"
            inline constexpr std::uintptr_t TeamCapacity = 0x40; // "TMP_Text"
            inline constexpr std::uintptr_t locationCity = 0x48; // "LocalizeStringEvent"
            inline constexpr std::uintptr_t business = 0x50; // "LocalizeStringEvent"
            inline constexpr std::uintptr_t emptyClan = 0x58; // "StateElementBase"
            inline constexpr std::uintptr_t businessIcon = 0x60; // "Image"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetCity = 0x36BB2D0; // "public void SetCity(LocalizedString title)"
            inline constexpr std::uintptr_t SetConquestObject = 0x36BB2F0; // "public void SetConquestObject(LocalizedString businessName, Sprite businessIcon)"
            inline constexpr std::uintptr_t SetEmptyClan = 0x36BB340; // "public void SetEmptyClan(bool value)"
        }
    } // namespace ClanBetLineView

    namespace ClanBetsUpdater { // "Game.Global.Clan.ClanDialog.AppointmentsContainer.ClanBetsUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t globalModel = 0x10; // "GlobalModel"
            inline constexpr std::uintptr_t globalScreenContent = 0x18; // "GlobalScreenContent"
            inline constexpr std::uintptr_t clickableModel = 0x20; // "ClickableItemsModel<ProtectionContext>"
            inline constexpr std::uintptr_t view = 0x28; // "ClanAppointmentsContainer"
            inline constexpr std::uintptr_t clanBetLineView = 0x30; // "PooledLoadedComponentContent<ClanBetLineView>"
            inline constexpr std::uintptr_t views = 0x38; // "Dictionary<ProtectionContext, IDisposableContent<ClanBetLineView>>"
            inline constexpr std::uintptr_t conquestObjectTypeViewDescriptions = 0x40; // "ClanConquestObjectTypeViewDescriptions"
            inline constexpr std::uintptr_t clanBattleCompetitorsTeamsSizeViewDescriptions = 0x48; // "ClanBattleCompetitorsTeamsSizeViewDescriptions"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x36BC070; // "public void Update()"
            inline constexpr std::uintptr_t AddView = 0x36BB370; // "private IDisposableContent<ClanBetLineView> AddView(ProtectionContext protectionContext)"
            inline constexpr std::uintptr_t RemoveView = 0x36BB460; // "private void RemoveView(ProtectionContext protectionContext)"
            inline constexpr std::uintptr_t UpdateView = 0x36BB700; // "private void UpdateView(ClanBattleBetModel betModel, ProtectionContext protectionContext, ClanBetLineView view)"
        }
    } // namespace ClanBetsUpdater

    namespace ClanBonusData { // "Models.Data.Settlement.ClanBonusData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t LaunderingDirtyCashPerPeriodModifier = 0x20; // "IPrimitiveData<float>"
        }
    } // namespace ClanBonusData

    namespace ClanBonusesUpdater { // "Game.Global.Clan.ClanDialog.ClanBonusesUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t view = 0x10; // "ClanInfoContainerView"
            inline constexpr std::uintptr_t conquestObjects = 0x18; // "IOwnedClanConquestItemsModel<ClanConquestObjectTypeDescription>"
            inline constexpr std::uintptr_t conquestSectors = 0x20; // "IOwnedClanConquestItemsModel<SectorDescription>"
            inline constexpr std::uintptr_t realmVersion = 0x28; // "RealmVersion"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x3698650; // "public void Update()"
        }
    } // namespace ClanBonusesUpdater

    namespace ClanBonusModel { // "Models.Models.ClanBonus.ClanBonusModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "ClanBonusData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_LaunderingDirtyCashPerPeriodModifier = 0x49821D0; // "public float get_LaunderingDirtyCashPerPeriodModifier()"
            inline constexpr std::uintptr_t Set = 0x4982170; // "public void Set(float launderingDirtyCashPerPeriodModifier)"
            inline constexpr std::uintptr_t Clear = 0x4982120; // "public void Clear()"
        }
    } // namespace ClanBonusModel

    namespace ClanBorderInfoUpdater { // "Game.Battle.Environment.ClanBorderInfoUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t clanBorderInfo = 0x10; // "List<ClanBorderInfoView>"
            inline constexpr std::uintptr_t clanEmblemViewDescriptions = 0x18; // "ClanEmblemViewDescriptions"
            inline constexpr std::uintptr_t realmBattleStateModel = 0x20; // "RealmBattleStateModel"
            inline constexpr std::uintptr_t realmInfoModel = 0x28; // "RealmInfoModel"
            inline constexpr std::uintptr_t isInitialized = 0x30; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xAAD0C0; // "public void Update()"
            inline constexpr std::uintptr_t UpdateClanBordersInfo = 0xAACEC0; // "private void UpdateClanBordersInfo(ClanConquestSectorModel conquestSectorModel)"
        }
    } // namespace ClanBorderInfoUpdater

    namespace ClanCancelBetRules { // "Game.Global.Clan.ClanBetDialog.ClanCancelBetRules (Global.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t OpenConfirmCancellationDialog = 0x36BC520; // "public static void OpenConfirmCancellationDialog(ClanModel clanModel, ClanBattleBetModel betModel, ModalDialogModel modalDialogModel, InputActions inputActions, ClanLocalization localization, PersonalNotificationModel notificationModel, Action onApplyClick)"
        }
    } // namespace ClanCancelBetRules

    namespace ClanCardInfoUpdater { // "Game.Global.Clan.ClanCardInfoUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t view = 0x10; // "ClanCardInfoView"
            inline constexpr std::uintptr_t clanModel = 0x18; // "ClanModel"
            inline constexpr std::uintptr_t clanEmblemViewDescriptions = 0x20; // "ClanEmblemViewDescriptions"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x3671B00; // "public void Update()"
        }
    } // namespace ClanCardInfoUpdater

    namespace ClanCardInfoView { // "Game.Global.Clan.ClanCardInfoView (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Emblem = 0x20; // "ClanEmblemView"
            inline constexpr std::uintptr_t ClanName = 0x28; // "TextLabel<string, string>"
            inline constexpr std::uintptr_t leaderNickname = 0x30; // "TextMeshProUGUI"
            inline constexpr std::uintptr_t ReputationPoints = 0x38; // "TextLabel<int>"
            inline constexpr std::uintptr_t MembersCount = 0x40; // "TextLabel<int>"
            inline constexpr std::uintptr_t ConquestObjectsCount = 0x48; // "TextLabel<int>"
            inline constexpr std::uintptr_t ConquestSectorsCount = 0x50; // "TextLabel<int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetLeader = 0x358FA60; // "public void SetLeader(string leaderNickname)"
        }
    } // namespace ClanCardInfoView

    namespace ClanCellEmblemView { // "Game.Global.Clan.ClanSettings.ClanCellEmblemView (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Button = 0x20; // "CompositeButtonView"
            inline constexpr std::uintptr_t Emblem = 0x28; // "ClanEmblemView"
            inline constexpr std::uintptr_t selectState = 0x30; // "StateGroup"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetSelect = 0x9A5610; // "public void SetSelect(bool selected)"
        }
    } // namespace ClanCellEmblemView

    namespace ClanChatUpdater { // "Game.Global.Clan.ClanChatUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t clanModel = 0x10; // "ClanModel"
            inline constexpr std::uintptr_t chatsModel = 0x18; // "ChatsModel"
            inline constexpr std::uintptr_t clanChatSettings = 0x20; // "ChatSourceSettings"
            inline constexpr std::uintptr_t now = 0x28; // "INow"
            inline constexpr std::uintptr_t regionUserRoom = 0x30; // "IRoomConnection"
            inline constexpr std::uintptr_t chatLocalization = 0x38; // "ChatLocalization"
            inline constexpr std::uintptr_t globalScreenContent = 0x40; // "GlobalScreenContent"
            inline constexpr std::uintptr_t blackListModel = 0x48; // "BlackListModel"
            inline constexpr std::uintptr_t badWordsFilter = 0x50; // "BadWordsFilterModel"
            inline constexpr std::uintptr_t systemChat = 0x58; // "SystemChatMessageSource"
            inline constexpr std::uintptr_t clanBattleChat = 0x60; // "SystemChatMessageSource"
            inline constexpr std::uintptr_t chatCooldown = 0x68; // "ExpiringResourceModel"
            inline constexpr std::uintptr_t updater = 0x70; // "IUpdater"
            inline constexpr std::uintptr_t disposable = 0x78; // "IRegisterDisposable"
            inline constexpr std::uintptr_t wasInClan = 0x80; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x3672AF0; // "public void Update()"
            inline constexpr std::uintptr_t ResolveInClan = 0x36720B0; // "private void ResolveInClan()"
        }
    } // namespace ClanChatUpdater

    namespace ClanClearModelOnTabChangeUpdater { // "Game.Global.Clan.ClanDialog.ClanClearModelOnTabChangeUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dialogModel = 0x10; // "ClanDialogModel"
            inline constexpr std::uintptr_t tab = 0x18; // "Nullable<ClanTabs>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x3698750; // "public void Update()"
        }
    } // namespace ClanClearModelOnTabChangeUpdater

    namespace ClanCloseDialogOnInvalidBattleEnteringUpdater { // "Game.Global.Clan.ClanDialog.Updater.ClanCloseDialogOnInvalidBattleEnteringUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t globalModel = 0x10; // "GlobalModel"
            inline constexpr std::uintptr_t dialogModel = 0x18; // "ScreenModel"
            inline constexpr std::uintptr_t protectionContext = 0x20; // "ProtectionContext"
            inline constexpr std::uintptr_t clanLocalization = 0x28; // "ClanLocalization"
            inline constexpr std::uintptr_t isTriggered = 0x30; // "bool"
            inline constexpr std::uintptr_t partyLocalization = 0x38; // "PartyLocalization"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x36BC8A0; // "public void Update()"
        }
    } // namespace ClanCloseDialogOnInvalidBattleEnteringUpdater

    namespace ClanConfig { // "Models.References.Clan.ClanConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t MaxDescriptionLength = 0x10; // "int"
            inline constexpr std::uintptr_t CreateCoinsAmount = 0x14; // "int"
            inline constexpr std::uintptr_t CreateClanCooldown = 0x18; // "long"
            inline constexpr std::uintptr_t JoinClanCooldown = 0x20; // "long"
            inline constexpr std::uintptr_t MaxMembersCount = 0x28; // "int"
            inline constexpr std::uintptr_t ClanMaxRequestsCount = 0x2C; // "int"
            inline constexpr std::uintptr_t RequestExpirationTime = 0x30; // "long"
            inline constexpr std::uintptr_t InviteExpirationTime = 0x38; // "long"
            inline constexpr std::uintptr_t AvailableForJoinClansListMaxCount = 0x40; // "int"
            inline constexpr std::uintptr_t GetInfoResourceDescription = 0x48; // "ExpiringResourceDescription"
        }
    } // namespace ClanConfig

    namespace ClanConfirmationsModel { // "Models.Models.ClanConfirmations.ClanConfirmationsModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "DictionaryData<int, IPrimitiveData<string>>"
            inline constexpr std::uintptr_t privateIds = 0x18; // "Dictionary<string, int>"
            inline constexpr std::uintptr_t index = 0x20; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t UpdateAfterLoad = 0x49823E0; // "public void UpdateAfterLoad()"
            inline constexpr std::uintptr_t Contains = 0x49822E0; // "public bool Contains(string privateId)"
            inline constexpr std::uintptr_t Add = 0x4982220; // "public void Add(string privateId)"
            inline constexpr std::uintptr_t Remove = 0x4982340; // "public bool Remove(string privateId)"
            inline constexpr std::uintptr_t get_PrivateIds = 0x4982710; // "public IEnumerable<string> get_PrivateIds()"
        }
    } // namespace ClanConfirmationsModel

    namespace ClanConquestItemsDescription { // "Models.References.Clan.ClanConquestItemsDescription (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t get_ConquestItemsTakeRewardsCooldownTime = 0x44497C0; // "public static long get_ConquestItemsTakeRewardsCooldownTime()"
        }
    } // namespace ClanConquestItemsDescription

    namespace ClanConquestItemsRewardModel { // "Models.Models.ClanConquestItemsReward.ClanConquestItemsRewardModel (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x81E1C40; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "IPrimitiveData<long>"
        }
        namespace StaticFields {
            inline constexpr std::uintptr_t noValue = 0x0; // "long"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsActive = 0x4982970; // "public bool get_IsActive()"
            inline constexpr std::uintptr_t get_CooldownStartTs = 0x4982920; // "public long get_CooldownStartTs()"
            inline constexpr std::uintptr_t get_CooldownEndTs = 0x49828C0; // "public long get_CooldownEndTs()"
            inline constexpr std::uintptr_t SetCooldownStartTs = 0x49827F0; // "public void SetCooldownStartTs(long startTs)"
            inline constexpr std::uintptr_t Deactivate = 0x4982760; // "public void Deactivate()"
        }
    } // namespace ClanConquestItemsRewardModel

    namespace ClanConquestObjectData { // "Models.Data.ClanConquestObjectData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ClanId = 0x20; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t ClanTag = 0x28; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t ClanName = 0x30; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t Emblem = 0x38; // "IPrimitiveData<ClanEmblemDescription>"
            inline constexpr std::uintptr_t ClanBattleStartOffsetIndex = 0x40; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t IsAuctionStarted = 0x48; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t PeriodIndex = 0x50; // "IPrimitiveData<int>"
        }
    } // namespace ClanConquestObjectData

    namespace ClanConquestObjectPublicData { // "Models.Data.Clan.ClanConquestObjectPublicData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ClanTag = 0x20; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t ClanName = 0x28; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t Emblem = 0x30; // "IPrimitiveData<ClanEmblemDescription>"
            inline constexpr std::uintptr_t ClanBattleStartOffsetIndex = 0x38; // "IPrimitiveData<int>"
        }
    } // namespace ClanConquestObjectPublicData

    namespace ClanConquestObjectsData { // "Models.Data.ClanConquestObjectsData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t MigrationVersion = 0x20; // "MigrationVersionData"
            inline constexpr std::uintptr_t Objects = 0x28; // "ReferenceMapData<ClanConquestObjectTypeDescription, ClanConquestObjectData>"
        }
    } // namespace ClanConquestObjectsData

    namespace ClanConquestObjectTypeDescription { // "Models.References.ClanBattle.ClanConquestObjectTypeDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t LaunderingDirtyCashPerPeriodModifier = 0x20; // "float"
            inline constexpr std::uintptr_t ClanBattleBetMinAmount = 0x24; // "int"
            inline constexpr std::uintptr_t CashReward = 0x28; // "int"
            inline constexpr std::uintptr_t ClanBattleTierFunc = 0x30; // "Func<ClanBattleTierDescription>"
            inline constexpr std::uintptr_t IsEnabled = 0x38; // "RealmVersionedBoolValues"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_ClanBattleTier = 0x9AA5D0; // "public ClanBattleTierDescription get_ClanBattleTier()"
        }
    } // namespace ClanConquestObjectTypeDescription

    namespace ClanConquestObjectTypeDescriptionExtensions { // "Models.Utils.Extensions.ClanConquestObjectTypeDescriptionExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t IsEnabled = 0x39415C0; // "public static bool IsEnabled(ClanConquestObjectTypeDescription description, RealmVersion realmVersion)"
        }
    } // namespace ClanConquestObjectTypeDescriptionExtensions

    namespace ClanConquestObjectTypeViewDescription { // "Game.Global.Clan.ViewDescriptions.ClanConquestObjectTypeViewDescription (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Identified = 0x10; // "IdentifiedProperty<ClanConquestObjectTypeDescription>"
            inline constexpr std::uintptr_t Name = 0x18; // "LocalizedString"
            inline constexpr std::uintptr_t ShortName = 0x20; // "LocalizedString"
            inline constexpr std::uintptr_t Description = 0x28; // "LocalizedString"
            inline constexpr std::uintptr_t ObjectIcon = 0x30; // "Sprite"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Id = 0x3680300; // "public string get_Id()"
        }
    } // namespace ClanConquestObjectTypeViewDescription

    namespace ClanConquestObjectTypeViewDescriptions { // "Game.Global.Clan.ViewDescriptions.ClanConquestObjectTypeViewDescriptions (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t OpenTip = 0x28; // "LocalizedString"
            inline constexpr std::uintptr_t ClanBalanceSprite = 0x30; // "Sprite"
            inline constexpr std::uintptr_t OwnedObjectTemplate = 0x38; // "Text.ReadOnly<LocalizedString, LocalizedString>"
            inline constexpr std::uintptr_t SectorProfitLabel = 0x40; // "LocalizedString"
            inline constexpr std::uintptr_t BusinessProfitLabel = 0x48; // "LocalizedString"
            inline constexpr std::uintptr_t LaunderingBonusLabel = 0x50; // "LocalizedString"
            inline constexpr std::uintptr_t ProfitBonusPercent = 0x58; // "Text.ReadOnly<string>"
            inline constexpr std::uintptr_t ProfitBonusValue = 0x60; // "Text.ReadOnly<string>"
            inline constexpr std::uintptr_t LaunderingBonusValue = 0x68; // "Text.ReadOnly<string>"
        }
    } // namespace ClanConquestObjectTypeViewDescriptions

    namespace ClanConquestRewardExtensions { // "Models.Utils.Extensions.ClanConquestRewardExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t ClanHasConquestItemsCashReward = 0x3941630; // "public static bool ClanHasConquestItemsCashReward(IOwnedClanConquestItemsModel<ClanConquestObjectTypeDescription> ownedObjects, IOwnedClanConquestItemsModel<SectorDescription> ownedSectors)"
        }
    } // namespace ClanConquestRewardExtensions

    namespace ClanConquestSectorData { // "Models.Data.ClanConquestSectorData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ClanId = 0x20; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t ClanTag = 0x28; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t ClanName = 0x30; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t Emblem = 0x38; // "IPrimitiveData<ClanEmblemDescription>"
            inline constexpr std::uintptr_t ClanBattleStartOffsetIndex = 0x40; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t IsAuctionStarted = 0x48; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t PeriodIndex = 0x50; // "IPrimitiveData<int>"
        }
    } // namespace ClanConquestSectorData

    namespace ClanConquestSectorModel { // "Game.Global.RealmInfo.ClanConquestSectorModel (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x0; // "RealmClanConquestSectorData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_HasClan = 0x3797EB0; // "public bool get_HasClan()"
            inline constexpr std::uintptr_t get_ClanId = 0x3797CC0; // "public string get_ClanId()"
            inline constexpr std::uintptr_t get_ClanTag = 0x3797D80; // "public string get_ClanTag()"
            inline constexpr std::uintptr_t get_ClanName = 0x3797D20; // "public string get_ClanName()"
            inline constexpr std::uintptr_t get_Emblem = 0x3797DE0; // "public ClanEmblemDescription get_Emblem()"
            inline constexpr std::uintptr_t get_ClanBattleStartOffsetIndex = 0x3797C20; // "public int get_ClanBattleStartOffsetIndex()"
        }
    } // namespace ClanConquestSectorModel

    namespace ClanConquestSectorsData { // "Models.Data.ClanConquestSectorsData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t MigrationVersion = 0x20; // "MigrationVersionData"
            inline constexpr std::uintptr_t Sectors = 0x28; // "ReferenceMapData<SectorDescription, ClanConquestSectorData>"
        }
    } // namespace ClanConquestSectorsData

    namespace ClanContextMenuButtonsUpdater { // "Game.Global.Clan.ClanDialog.ClanContextMenuButtonsUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleStateModel = 0x10; // "RealmBattleStateModel"
            inline constexpr std::uintptr_t dialogModel = 0x18; // "ClanDialogModel"
            inline constexpr std::uintptr_t clanModel = 0x20; // "ClanModel"
            inline constexpr std::uintptr_t partyModel = 0x28; // "PartyModel"
            inline constexpr std::uintptr_t view = 0x30; // "ClanParticipantContextMenuView"
            inline constexpr std::uintptr_t blackListModel = 0x38; // "BlackListModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x3698B90; // "public void Update()"
            inline constexpr std::uintptr_t GetCanInviteToParty = 0x3698A50; // "private bool GetCanInviteToParty()"
        }
    } // namespace ClanContextMenuButtonsUpdater

    namespace ClanData { // "Models.Data.Clan.ClanData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t MigrationVersion = 0x20; // "MigrationVersionData"
            inline constexpr std::uintptr_t Name = 0x28; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t Tag = 0x30; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t RealmId = 0x38; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t RealmStartTs = 0x40; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t RealmVersion = 0x48; // "IPrimitiveData<RealmVersion>"
            inline constexpr std::uintptr_t Members = 0x50; // "ReferenceMapData<ClanMemberSlotDescription, ClanMemberData>"
            inline constexpr std::uintptr_t LeaderSlot = 0x58; // "IPrimitiveData<ClanMemberSlotDescription>"
            inline constexpr std::uintptr_t EnterType = 0x60; // "IPrimitiveData<ClanEnterTypeDescription>"
            inline constexpr std::uintptr_t Language = 0x68; // "IPrimitiveData<ClanLanguageDescription>"
            inline constexpr std::uintptr_t Emblem = 0x70; // "IPrimitiveData<ClanEmblemDescription>"
            inline constexpr std::uintptr_t Description = 0x78; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t IsRemoving = 0x80; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t Requests = 0x88; // "DictionaryData<int, ClanRequestData>"
            inline constexpr std::uintptr_t RequestOwners = 0x90; // "DictionaryData<int, PrivateIdData>"
            inline constexpr std::uintptr_t Announcement = 0x98; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t JoinConfirmations = 0xA0; // "DictionaryData<int, IPrimitiveData<string>>"
            inline constexpr std::uintptr_t LeaveConfirmations = 0xA8; // "DictionaryData<int, IPrimitiveData<string>>"
            inline constexpr std::uintptr_t ObjectsClanBattleBets = 0xB0; // "ReferenceMapData<ClanConquestObjectTypeDescription, ClanBattleBetData>"
            inline constexpr std::uintptr_t ObjectsClanBattleAppointments = 0xB8; // "ReferenceMapData<ClanConquestObjectTypeDescription, ClanBattleAppointmentData>"
            inline constexpr std::uintptr_t OwnedClanConquestObjects = 0xC0; // "DictionaryData<ClanConquestObjectTypeDescription, IPrimitiveData<int>>"
            inline constexpr std::uintptr_t Coins = 0xC8; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t Logs = 0xD0; // "ReferenceMapData<ClanLogSlotDescription, ByteArrayData>"
            inline constexpr std::uintptr_t LastLogsSlot = 0xD8; // "IPrimitiveData<ClanLogSlotDescription>"
            inline constexpr std::uintptr_t ClanBattleBetProcess = 0xE0; // "ClanBattleBetProcessData"
            inline constexpr std::uintptr_t ChangeStartOffsetIndexObject = 0xE8; // "IPrimitiveData<ClanConquestObjectTypeDescription>"
            inline constexpr std::uintptr_t ChangeStartOffsetIndexSector = 0xF0; // "IPrimitiveData<SectorDescription>"
            inline constexpr std::uintptr_t ChangeStartOffsetIndex = 0xF8; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t ClanBattleBetExpiringResourceTs = 0x100; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t ClanBattleBetExpiringResourceAmount = 0x108; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t ChangeStartOffsetIndexExpiringResourceTs = 0x110; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t ChangeStartOffsetIndexExpiringResourceAmount = 0x118; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t SectorsClanBattleBets = 0x120; // "ReferenceMapData<SectorDescription, ClanBattleBetData>"
            inline constexpr std::uintptr_t SectorsClanBattleAppointments = 0x128; // "ReferenceMapData<SectorDescription, ClanBattleAppointmentData>"
            inline constexpr std::uintptr_t OwnedClanConquestSectors = 0x130; // "DictionaryData<SectorDescription, OwnedClanConquestSectorData>"
            inline constexpr std::uintptr_t ChangeEmblemCooldownEndTs = 0x138; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t IsChangingEmblem = 0x140; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t ConquestItemsTakeRewardsCooldownStartTs = 0x148; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t Chat = 0x150; // "ChatMessagesData"
        }
    } // namespace ClanData

    namespace ClanDialogAvailableByRanksUpdater { // "Game.Global.Clan.ClanDialog.ClanDialogAvailableByRanksUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t clanModel = 0x10; // "ClanModel"
            inline constexpr std::uintptr_t dialogView = 0x18; // "ClanDialogView"
            inline constexpr std::uintptr_t clanTabs = 0x20; // "TabData<ClanTabs>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x3699010; // "public void Update()"
        }
    } // namespace ClanDialogAvailableByRanksUpdater

    namespace ClanDialogInputUpdater { // "Game.Global.Clan.ClanDialog.ClanDialogInputUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dialogView = 0x10; // "ClanDialogView"
            inline constexpr std::uintptr_t inputActions = 0x18; // "InputActions"
            inline constexpr std::uintptr_t dialogModel = 0x20; // "ClanDialogModel"
            inline constexpr std::uintptr_t globalModel = 0x28; // "GlobalModel"
            inline constexpr std::uintptr_t globalScreenContent = 0x30; // "GlobalScreenContent"
            inline constexpr std::uintptr_t roomConnections = 0x38; // "IRoomConnections"
            inline constexpr std::uintptr_t coinsModel = 0x40; // "ICoinsReadonlyModel"
            inline constexpr std::uintptr_t coinsAccessModel = 0x48; // "CoinsAccessModel"
            inline constexpr std::uintptr_t clanLocalization = 0x50; // "ClanLocalization"
            inline constexpr std::uintptr_t clanRankViewDescriptions = 0x58; // "ClanRankViewDescriptions"
            inline constexpr std::uintptr_t contextActionRules = 0x60; // "GeneralContextActionRules"
            inline constexpr std::uintptr_t focusedHandler = 0x68; // "ValueTuple<InputMask, IUpdater>[]"
            inline constexpr std::uintptr_t idleHandler = 0x70; // "ValueTuple<InputMask, IUpdater>[]"
            inline constexpr std::uintptr_t isProgress = 0x78; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t OnRemoveFromBlacklist = 0x369A4D0; // "private void OnRemoveFromBlacklist()"
            inline constexpr std::uintptr_t OnAddToBlackList = 0x36994E0; // "private void OnAddToBlackList()"
            inline constexpr std::uintptr_t OnWhisper = 0x369AC00; // "private void OnWhisper()"
            inline constexpr std::uintptr_t OnTransferFinances = 0x369A830; // "private void OnTransferFinances()"
            inline constexpr std::uintptr_t OnTransferCoins = 0x369A760; // "private void OnTransferCoins(ModalTransferCoinModel modalTransferCoinModel)"
            inline constexpr std::uintptr_t OnInviteToParty = 0x36998F0; // "private void OnInviteToParty()"
            inline constexpr std::uintptr_t OnMakeALeader = 0x3699FF0; // "private void OnMakeALeader()"
            inline constexpr std::uintptr_t OnMakeLeaderConfirm = 0x369A410; // "private void OnMakeLeaderConfirm(long memberPublicId)"
            inline constexpr std::uintptr_t OnSetRights = 0x369A5B0; // "private void OnSetRights()"
            inline constexpr std::uintptr_t OnKickOut = 0x36999D0; // "private void OnKickOut()"
            inline constexpr std::uintptr_t OnLeave = 0x3699CA0; // "private void OnLeave()"
            inline constexpr std::uintptr_t CheckLeaveFromClan = 0x36991D0; // "private bool CheckLeaveFromClan(out LocalizedString failReason)"
            inline constexpr std::uintptr_t OnLeaveConfirm = 0x3699BF0; // "private void OnLeaveConfirm()"
            inline constexpr std::uintptr_t ClearParticipant = 0x3699300; // "private void ClearParticipant()"
            inline constexpr std::uintptr_t OnClickParticipant = 0x3699740; // "private void OnClickParticipant(EnumValue<ClanMemberSlotDescription> slot)"
            inline constexpr std::uintptr_t OnClickAcceptRequest = 0x36995C0; // "private void OnClickAcceptRequest(int slot)"
            inline constexpr std::uintptr_t OnClickDeclineRequest = 0x3699680; // "private void OnClickDeclineRequest(int slot)"
            inline constexpr std::uintptr_t OnClose = 0x36997C0; // "private void OnClose()"
            inline constexpr std::uintptr_t CloseOrInfoOpen = 0x36993E0; // "private void CloseOrInfoOpen()"
            inline constexpr std::uintptr_t CloseOrAppointmentsOpen = 0x3699330; // "private void CloseOrAppointmentsOpen()"
            inline constexpr std::uintptr_t OnEdit = 0x36997F0; // "private void OnEdit()"
            inline constexpr std::uintptr_t get_Handlers = 0x369C480; // "public ValueTuple<InputMask, IUpdater>[] get_Handlers()"
            inline constexpr std::uintptr_t IsInputFieldFocused = 0x3699490; // "private bool IsInputFieldFocused()"
            inline constexpr std::uintptr_t get_Priority = 0x7E5DA0; // "public InputHandlerPriority get_Priority()"
        }
    } // namespace ClanDialogInputUpdater

    namespace ClanDialogModel { // "Game.Global.Clan.ClanDialog.ClanDialogModel (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t NeedOpenIfClanCreated = 0x18; // "bool"
            inline constexpr std::uintptr_t CurrentTab = 0x20; // "TabData<ClanTabs>"
            inline constexpr std::uintptr_t CurrentMembersTab = 0x28; // "TabData<ClanMembersTabs>"
            inline constexpr std::uintptr_t SelectedParticipant = 0x30; // "ClanMemberSlotDescription"
            inline constexpr std::uintptr_t IsAnnouncementEdit = 0x38; // "bool"
            inline constexpr std::uintptr_t ClanRequestsLastViewedTs = 0x40; // "long"
            inline constexpr std::uintptr_t LastAppointmentsTabClicked = 0x48; // "long"
            inline constexpr std::uintptr_t LastProtectionTabClicked = 0x50; // "long"
            inline constexpr std::uintptr_t LastShowdownsClickedProtectionContext = 0x58; // "ProtectionContext"
        }
        namespace Methods {
            inline constexpr std::uintptr_t ClearOnCloseOrTabChange = 0x369C4E0; // "public void ClearOnCloseOrTabChange()"
            inline constexpr std::uintptr_t ClearOnClose = 0x369C500; // "public void ClearOnClose()"
        }
    } // namespace ClanDialogModel

    namespace ClanDialogParticipantsCounterViewUpdater { // "Game.Global.Clan.ClanDialog.ClanDialogParticipantsCounterViewUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t view = 0x10; // "ClanDialogView"
            inline constexpr std::uintptr_t clanModel = 0x18; // "ClanModel"
            inline constexpr std::uintptr_t wasCount = 0x20; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x369C5F0; // "public void Update()"
        }
    } // namespace ClanDialogParticipantsCounterViewUpdater

    namespace ClanDialogSelectedParticipantClearUpdater { // "Game.Global.Clan.ClanDialog.Updater.ClanDialogSelectedParticipantClearUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t clanModel = 0x10; // "ClanModel"
            inline constexpr std::uintptr_t clanDialogModel = 0x18; // "ClanDialogModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x36BCAA0; // "public void Update()"
        }
    } // namespace ClanDialogSelectedParticipantClearUpdater

    namespace ClanDialogUpdater { // "Game.Global.Clan.ClanDialog.ClanDialogUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t updaters = 0x10; // "CompositeUpdater"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x9B7840; // "public void Update()"
        }
    } // namespace ClanDialogUpdater

    namespace ClanDialogView { // "Game.Global.Clan.ClanDialog.ClanDialogView (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t CloseButton = 0x20; // "CompositeButtonView"
            inline constexpr std::uintptr_t Tabs = 0x28; // "List<TabView<ClanTabs>>"
            inline constexpr std::uintptr_t MembersTabs = 0x30; // "List<TabView<ClanMembersTabs>>"
            inline constexpr std::uintptr_t RequestsNotifications = 0x38; // "GameObject[]"
            inline constexpr std::uintptr_t CardInfo = 0x40; // "ClanCardInfoView"
            inline constexpr std::uintptr_t Finances = 0x48; // "ClanFinancesView"
            inline constexpr std::uintptr_t EventsContainer = 0x50; // "Transform"
            inline constexpr std::uintptr_t ParticipantsCount = 0x58; // "TextLabel<int, int>"
            inline constexpr std::uintptr_t hasEventsState = 0x60; // "StateGroup"
            inline constexpr std::uintptr_t InfoContainer = 0x68; // "ClanInfoContainerView"
            inline constexpr std::uintptr_t ProtectionContainer = 0x70; // "ClanProtectionContainerView"
            inline constexpr std::uintptr_t ParticipantsContainer = 0x78; // "ClanParticipantsContainerView"
            inline constexpr std::uintptr_t RequestsContainer = 0x80; // "ClanRequestsContainerView"
            inline constexpr std::uintptr_t AppointmentsContainer = 0x88; // "ClanAppointmentsContainer"
            inline constexpr std::uintptr_t EditClan = 0x90; // "GameObject"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetHasEvents = 0x36BCB50; // "public void SetHasEvents(bool value)"
        }
    } // namespace ClanDialogView

    namespace ClanEmblemView { // "Game.Global.Clan.ClanEmblemView (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t emblem = 0x20; // "Image"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetEmblem = 0x35B7740; // "public void SetEmblem(Sprite sprite)"
        }
    } // namespace ClanEmblemView

    namespace ClanEmblemViewDescription { // "Game.Global.Clan.ClanEmblemViewDescription (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t id = 0x10; // "string"
            inline constexpr std::uintptr_t Identified = 0x18; // "IdentifiedProperty<ClanEmblemDescription>"
            inline constexpr std::uintptr_t Emblem = 0x20; // "Sprite"
            inline constexpr std::uintptr_t EmblemMaterial = 0x28; // "Material"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Id = 0x3672E30; // "public string get_Id()"
        }
    } // namespace ClanEmblemViewDescription

    namespace ClanEnterTypeDescription { // "Models.References.Clan.ClanEnterTypeDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x81E3938; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t enum_id = 0x0; // "Enum<ClanEnterTypeDescription>"
            inline constexpr std::uintptr_t Open = 0x8; // "ClanEnterTypeDescription"
            inline constexpr std::uintptr_t Close = 0x10; // "ClanEnterTypeDescription"
            inline constexpr std::uintptr_t Request = 0x18; // "ClanEnterTypeDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Enum = 0x444A2E0; // "public static ReadOnlyEnum<ClanEnterTypeDescription> get_Enum()"
        }
    } // namespace ClanEnterTypeDescription

    namespace ClanEnterTypeViewDescription { // "Game.Global.Clan.ClanEnterTypeViewDescription (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t id = 0x10; // "string"
            inline constexpr std::uintptr_t Identified = 0x18; // "IdentifiedProperty<ClanEnterTypeDescription>"
            inline constexpr std::uintptr_t Type = 0x20; // "LocalizedString"
            inline constexpr std::uintptr_t PaletteColor = 0x28; // "PaletteColor"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Id = 0x3672F80; // "public string get_Id()"
        }
    } // namespace ClanEnterTypeViewDescription

    namespace ClanFinancesUpdater { // "Game.Global.Clan.ClanFinancesUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t clanModel = 0x10; // "ClanModel"
            inline constexpr std::uintptr_t view = 0x18; // "ClanFinancesView"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x3673000; // "public void Update()"
        }
    } // namespace ClanFinancesUpdater

    namespace ClanFinancesView { // "Game.Global.Clan.ClanFinancesView (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Finances = 0x20; // "TextLabel<Money>"
            inline constexpr std::uintptr_t TransferFinances = 0x28; // "CompositeButtonView"
            inline constexpr std::uintptr_t BankAccountStateGroup = 0x30; // "StateGroup"
        }
    } // namespace ClanFinancesView

    namespace ClanInfoContainerView { // "Game.Global.Clan.ClanDialog.ClanInfoContainerView (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Announcement = 0x20; // "ClanAnnouncementView"
            inline constexpr std::uintptr_t launderingSpeed = 0x28; // "TextLabel<int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetBonuses = 0x369E670; // "public void SetBonuses(int launderingSpeed)"
        }
    } // namespace ClanInfoContainerView

    namespace ClanInviteInputUpdater { // "Game.Global.Clan.ClanDialog.Updater.ClanInviteInputUpdater (Global.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x81E3E08; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace Fields {
            inline constexpr std::uintptr_t globalModel = 0x10; // "GlobalModel"
            inline constexpr std::uintptr_t dialogModel = 0x18; // "ClanDialogModel"
            inline constexpr std::uintptr_t roomConnections = 0x20; // "IRoomConnections"
            inline constexpr std::uintptr_t clanLocalization = 0x28; // "ClanLocalization"
            inline constexpr std::uintptr_t globalScreenContent = 0x30; // "GlobalScreenContent"
            inline constexpr std::uintptr_t clickUpdater = 0x38; // "IUpdater"
            inline constexpr std::uintptr_t modalInputField = 0x40; // "ModalInputFieldModel"
            inline constexpr std::uintptr_t originalValue = 0x48; // "string"
            inline constexpr std::uintptr_t isProgress = 0x50; // "bool"
        }
        namespace StaticFields {
            inline constexpr std::uintptr_t publicIdMaxLength = 0x0; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t OnInvite = 0x36BCE30; // "private void OnInvite()"
            inline constexpr std::uintptr_t WrapInputConfirm = 0x36BD330; // "private Action WrapInputConfirm(Action confirm, ModalInputFieldModel inputField)"
            inline constexpr std::uintptr_t FinalValidation = 0x36BCB80; // "private bool FinalValidation(string input, out IText error)"
            inline constexpr std::uintptr_t OnInviteConfirm = 0x36BCD80; // "private void OnInviteConfirm()"
            inline constexpr std::uintptr_t OnInviteCancel = 0x36BCD30; // "private void OnInviteCancel()"
            inline constexpr std::uintptr_t Update = 0x36BD2E0; // "public void Update()"
        }
    } // namespace ClanInviteInputUpdater

    namespace ClanInviteModel { // "Game.Global.Clan.Model.ClanInviteModel (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "RegionUserClanInviteData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_HasInvite = 0x36804C0; // "public bool get_HasInvite()"
            inline constexpr std::uintptr_t get_ClanId = 0x3680380; // "public string get_ClanId()"
            inline constexpr std::uintptr_t get_ClanName = 0x36803D0; // "public string get_ClanName()"
            inline constexpr std::uintptr_t get_Tag = 0x3680560; // "public string get_Tag()"
            inline constexpr std::uintptr_t get_Emblem = 0x3680420; // "public ClanEmblemDescription get_Emblem()"
            inline constexpr std::uintptr_t get_UserName = 0x36805B0; // "public string get_UserName()"
            inline constexpr std::uintptr_t get_ExpirationTs = 0x3680470; // "public long get_ExpirationTs()"
        }
    } // namespace ClanInviteModel

    namespace ClanInviteNotificationsUpdater { // "Game.Global.PopupNotificationDialog.ClanInviteNotificationsUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t clanModel = 0x10; // "ClanModel"
            inline constexpr std::uintptr_t popupNotificationsModel = 0x18; // "PopupNotificationsModel"
            inline constexpr std::uintptr_t now = 0x20; // "INow"
            inline constexpr std::uintptr_t socialModel = 0x28; // "SocialModel"
            inline constexpr std::uintptr_t regionUser = 0x30; // "IRoomConnection"
            inline constexpr std::uintptr_t toRemove = 0x38; // "HashSet<ClanInviteSlotDescription>"
            inline constexpr std::uintptr_t models = 0x40; // "Dictionary<ClanInviteSlotDescription, PopupNotification.Clan>"
            inline constexpr std::uintptr_t isProgress = 0x48; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x35AB000; // "public void Update()"
            inline constexpr std::uintptr_t RemoveNotValidNotifications = 0x35AAB60; // "private void RemoveNotValidNotifications()"
            inline constexpr std::uintptr_t RemoveAllNotifications = 0x35AA9A0; // "private void RemoveAllNotifications()"
            inline constexpr std::uintptr_t AddNewNotifications = 0x35AA460; // "private void AddNewNotifications()"
            inline constexpr std::uintptr_t OnDeclineInvite = 0x35AA8D0; // "private void OnDeclineInvite(string clanId)"
        }
    } // namespace ClanInviteNotificationsUpdater

    namespace ClanInvitePopupCloseUpdater { // "Game.Global.Clan.ClanInvitePopup.ClanInvitePopupCloseUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t clanModel = 0x10; // "ClanModel"
            inline constexpr std::uintptr_t popupModel = 0x18; // "ClanInvitePopupModel"
            inline constexpr std::uintptr_t now = 0x20; // "INow"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x369E6D0; // "public void Update()"
        }
    } // namespace ClanInvitePopupCloseUpdater

    namespace ClanInvitePopupInputUpdater { // "Game.Global.Clan.ClanInvitePopup.ClanInvitePopupInputUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t popupModel = 0x10; // "ClanInvitePopupModel"
            inline constexpr std::uintptr_t roomConnections = 0x18; // "IRoomConnections"
            inline constexpr std::uintptr_t globalModel = 0x20; // "GlobalModel"
            inline constexpr std::uintptr_t clanLocalization = 0x28; // "ClanLocalization"
            inline constexpr std::uintptr_t isProgress = 0x30; // "bool"
            inline constexpr std::uintptr_t Handlers = 0x38; // "ValueTuple<InputMask, IUpdater>[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t OnSubmit = 0x369E820; // "private void OnSubmit()"
            inline constexpr std::uintptr_t OnCancel = 0x369E770; // "private void OnCancel()"
            inline constexpr std::uintptr_t get_Priority = 0x10B1310; // "public InputHandlerPriority get_Priority()"
        }
    } // namespace ClanInvitePopupInputUpdater

    namespace ClanInvitePopupModel { // "Game.Global.Clan.ClanInvitePopup.ClanInvitePopupModel (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Notification = 0x18; // "PopupNotification.Clan"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Open = 0xD19F70; // "public void Open(PopupNotification.Clan notification)"
            inline constexpr std::uintptr_t Close = 0x35B8DF0; // "public void Close()"
        }
    } // namespace ClanInvitePopupModel

    namespace ClanInvitePopupUpdater { // "Game.Global.Clan.ClanInvitePopup.ClanInvitePopupUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t updater = 0x10; // "IUpdater"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x369EDA0; // "public void Update()"
        }
    } // namespace ClanInvitePopupUpdater

    namespace ClanInvitePopupView { // "Game.Global.Clan.ClanInvitePopup.ClanInvitePopupView (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t AcceptButtonView = 0x20; // "ClickButtonView"
            inline constexpr std::uintptr_t DeclineButtonView = 0x28; // "ClickButtonView"
            inline constexpr std::uintptr_t ClanName = 0x30; // "TextLabel<string, string>"
            inline constexpr std::uintptr_t Emblem = 0x38; // "ClanEmblemView"
            inline constexpr std::uintptr_t description = 0x40; // "TextLabel<string>"
            inline constexpr std::uintptr_t reputationPoints = 0x48; // "TextLabel<int>"
            inline constexpr std::uintptr_t progressRect = 0x50; // "SlicedFilledImage"
            inline constexpr std::uintptr_t nickname = 0x58; // "string"
            inline constexpr std::uintptr_t points = 0x60; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetProgress = 0x369F800; // "public void SetProgress(float val)"
            inline constexpr std::uintptr_t SetReputationPoints = 0x369F820; // "public void SetReputationPoints(int points)"
            inline constexpr std::uintptr_t SetNickname = 0x369F780; // "public void SetNickname(string nickname)"
        }
    } // namespace ClanInvitePopupView

    namespace ClanInvitePopupViewUpdater { // "Game.Global.Clan.ClanInvitePopup.ClanInvitePopupViewUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t popupView = 0x10; // "ClanInvitePopupView"
            inline constexpr std::uintptr_t popupModel = 0x18; // "ClanInvitePopupModel"
            inline constexpr std::uintptr_t clanEmblemViewDescriptions = 0x20; // "ClanEmblemViewDescriptions"
            inline constexpr std::uintptr_t now = 0x28; // "ISetNow"
            inline constexpr std::uintptr_t emblem = 0x30; // "ClanEmblemDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x369F4A0; // "public void Update()"
        }
    } // namespace ClanInvitePopupViewUpdater

    namespace ClanJoinTypeDescription { // "Models.References.Clan.ClanJoinTypeDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x81E4E20; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t enum_id = 0x0; // "Enum<ClanJoinTypeDescription>"
            inline constexpr std::uintptr_t Free = 0x8; // "ClanJoinTypeDescription"
            inline constexpr std::uintptr_t Request = 0x10; // "ClanJoinTypeDescription"
            inline constexpr std::uintptr_t Invite = 0x18; // "ClanJoinTypeDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Enum = 0x444A8A0; // "public static ReadOnlyEnum<ClanJoinTypeDescription> get_Enum()"
        }
    } // namespace ClanJoinTypeDescription

    namespace ClanLanguageViewDescription { // "Game.Global.Clan.ClanLanguageViewDescription (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t id = 0x10; // "string"
            inline constexpr std::uintptr_t Identified = 0x18; // "IdentifiedProperty<ClanLanguageDescription>"
            inline constexpr std::uintptr_t Language = 0x20; // "LocalizedString"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Id = 0x3673280; // "public string get_Id()"
        }
    } // namespace ClanLanguageViewDescription

    namespace ClanLanguageViewDescriptions { // "Game.Global.Clan.ClanLanguageViewDescriptions (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t AnyLanguage = 0x28; // "LocalizedString"
        }
    } // namespace ClanLanguageViewDescriptions

    namespace ClanLeavingReasonDescription { // "Models.References.Clan.ClanLeavingReasonDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x81E52F0; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t enum_id = 0x0; // "Enum<ClanLeavingReasonDescription>"
            inline constexpr std::uintptr_t Request = 0x8; // "ClanLeavingReasonDescription"
            inline constexpr std::uintptr_t Kicked = 0x10; // "ClanLeavingReasonDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Enum = 0x444C2A0; // "public static ReadOnlyEnum<ClanLeavingReasonDescription> get_Enum()"
        }
    } // namespace ClanLeavingReasonDescription

    namespace ClanLogAddedCashLineView { // "Game.Global.Clan.ClanDialog.ClanLogAddedCashLineView (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t moneyTitle = 0x30; // "TextLabel<string, Money, string>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetTitle = 0x369F890; // "public void SetTitle(string color, Money money, string text)"
        }
    } // namespace ClanLogAddedCashLineView

    namespace ClanLogCashLineView { // "Game.Global.Clan.ClanDialog.ClanLogCashLineView (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t moneyTitle = 0x30; // "TextLabel<string, Money, string>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetTitle = 0x369F920; // "public void SetTitle(string color, Money money, string text)"
        }
    } // namespace ClanLogCashLineView

    namespace ClanLogLineView { // "Game.Global.Clan.ClanDialog.ClanLogLineView (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Date = 0x20; // "DateView"
            inline constexpr std::uintptr_t description = 0x28; // "TextMeshProUGUI"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Set = 0x358FA30; // "public void Set(string description)"
        }
    } // namespace ClanLogLineView

    namespace ClanLogModel { // "Game.Global.Clan.Model.ClanLogModel (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "ByteArrayData"
            inline constexpr std::uintptr_t serializer = 0x18; // "ClanLogSerializer"
            inline constexpr std::uintptr_t cachedLogData = 0x20; // "byte[]"
            inline constexpr std::uintptr_t cachedLogValue = 0x28; // "ClanLogValue"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_LogData = 0x3680780; // "public byte[] get_LogData()"
            inline constexpr std::uintptr_t TryGet = 0x3680600; // "public bool TryGet(out ClanLogValue result)"
        }
    } // namespace ClanLogModel

    namespace ClanLogModel_2 { // "Models.Models.ClanLog.ClanLogModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "ByteArrayData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_HasData = 0x4982AB0; // "public bool get_HasData()"
            inline constexpr std::uintptr_t get_LogData = 0x4982B00; // "public byte[] get_LogData()"
            inline constexpr std::uintptr_t Set = 0x4982A00; // "public void Set(byte[] bytes)"
            inline constexpr std::uintptr_t Unset = 0x4982A60; // "public void Unset()"
        }
    } // namespace ClanLogModel_2

    namespace ClanLogPrimaryLineView { // "Game.Global.Clan.ClanDialog.ClanLogPrimaryLineView (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t WinState = 0x30; // "EnumStateElement<ClanLogPrimaryLineView.ClanLogPrimaryLineType>"
            inline constexpr std::uintptr_t ImageState = 0x38; // "EnumStateElement<ClanLogPrimaryLineView.ClanLogPrimaryLineImageType>"
        }
    } // namespace ClanLogPrimaryLineView

    namespace ClanLogsConfig { // "Models.References.Clan.ClanLogsConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t MaxDataLength = 0x10; // "int"
        }
    } // namespace ClanLogsConfig

    namespace ClanLogSimpleLineView { // "Game.Global.Clan.ClanDialog.ClanLogSimpleLineView (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t title = 0x30; // "TextLabel<string, string, string>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetTitle = 0x369F9B0; // "public void SetTitle(string color, string mainText, string text)"
        }
    } // namespace ClanLogSimpleLineView

    namespace ClanLogsModel { // "Models.Models.ClanLogs.ClanLogsModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t lastLogsSlot = 0x10; // "IPrimitiveData<ClanLogSlotDescription>"
            inline constexpr std::uintptr_t logModels = 0x18; // "Dictionary<ClanLogSlotDescription, ClanLogModel>"
            inline constexpr std::uintptr_t writeStream = 0x20; // "IPooledBinaryWriteStream"
            inline constexpr std::uintptr_t clanLogSerializer = 0x28; // "ClanLogSerializer"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_LastLogSlot = 0x4983460; // "public ClanLogSlotDescription get_LastLogSlot()"
            inline constexpr std::uintptr_t get_LogModels = 0x7E7130; // "public IReadOnlyDictionary<ClanLogSlotDescription, ClanLogModel> get_LogModels()"
            inline constexpr std::uintptr_t Add = 0x4982B40; // "public void Add(ClanLogValue value)"
            inline constexpr std::uintptr_t Unset = 0x4982FB0; // "public void Unset()"
            inline constexpr std::uintptr_t NextSlot = 0x4982DB0; // "private void NextSlot()"
        }
    } // namespace ClanLogsModel

    namespace ClanLogsToNotificationsUpdater { // "Game.Global.PopupNotificationDialog.ClanLogsToNotificationsUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t clanModel = 0x10; // "ClanModel"
            inline constexpr std::uintptr_t globalNotificationModel = 0x18; // "GlobalNotificationModel"
            inline constexpr std::uintptr_t plotAlarmNotificationModel = 0x20; // "PlotAlarmNotificationModel"
            inline constexpr std::uintptr_t publicIdModel = 0x28; // "PublicIdModel"
            inline constexpr std::uintptr_t globalScreenContent = 0x30; // "GlobalScreenContent"
            inline constexpr std::uintptr_t clanBattleChat = 0x38; // "SystemChatMessageSource"
            inline constexpr std::uintptr_t now = 0x40; // "INow"
            inline constexpr std::uintptr_t lastLogData = 0x48; // "byte[]"
            inline constexpr std::uintptr_t lastNotificationTs = 0x50; // "long"
            inline constexpr std::uintptr_t hasClan = 0x58; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x35AB310; // "public void Update()"
            inline constexpr std::uintptr_t SetLastNotification = 0x35AB210; // "private void SetLastNotification()"
        }
    } // namespace ClanLogsToNotificationsUpdater

    namespace ClanLogsViewUpdater { // "Game.Global.Clan.ClanDialog.ClanLogsViewUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t clanModel = 0x10; // "ClanModel"
            inline constexpr std::uintptr_t dialogModel = 0x18; // "ClanDialogModel"
            inline constexpr std::uintptr_t dialogView = 0x20; // "ClanDialogView"
            inline constexpr std::uintptr_t lines = 0x28; // "List<IDisposable>"
            inline constexpr std::uintptr_t clanLogTypeViewDescriptions = 0x30; // "ClanLogTypeViewDescriptions"
            inline constexpr std::uintptr_t conquestObjectTypeViewDescriptions = 0x38; // "ClanConquestObjectTypeViewDescriptions"
            inline constexpr std::uintptr_t conquestSectorViewDescriptions = 0x40; // "SectorsViewDescription"
            inline constexpr std::uintptr_t clanRankViewDescriptions = 0x48; // "ClanRankViewDescriptions"
            inline constexpr std::uintptr_t lineContent = 0x50; // "ClanLogsViewDescription"
            inline constexpr std::uintptr_t lastLogSlot = 0x58; // "ClanLogSlotDescription"
            inline constexpr std::uintptr_t currentDate = 0x60; // "DateTime"
            inline constexpr std::uintptr_t nowDate = 0x68; // "DateTime"
            inline constexpr std::uintptr_t now = 0x70; // "INow"
            inline constexpr std::uintptr_t lastLogData = 0x78; // "byte[]"
            inline constexpr std::uintptr_t lastTab = 0x80; // "ClanTabs"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x36A3810; // "public void Update()"
            inline constexpr std::uintptr_t UpdateLinesView = 0x36A3410; // "private void UpdateLinesView()"
            inline constexpr std::uintptr_t UpdateLineView = 0x36A3040; // "private void UpdateLineView(int slotIndex, ref int viewIndex)"
            inline constexpr std::uintptr_t CreateEventContent = 0x36A0380; // "private IDisposable CreateEventContent(ClanLogValue value)"
            inline constexpr std::uintptr_t CreatePrimaryEventContent = 0x36A0970; // "private IDisposable CreatePrimaryEventContent(ClanLogValue logValue)"
            inline constexpr std::uintptr_t CreateSimpleEventContent = 0x36A0CF0; // "private IDisposable CreateSimpleEventContent(ClanLogValue logValue)"
            inline constexpr std::uintptr_t CreateCashEventContent = 0x369FDA0; // "private IDisposable CreateCashEventContent(ClanLogValue logValue)"
            inline constexpr std::uintptr_t CreateAddCoinsEventContent = 0x369FA30; // "private IDisposable CreateAddCoinsEventContent(ClanLogValue.AddCoins addCoins)"
            inline constexpr std::uintptr_t GetLocalize = 0x36A1310; // "private string GetLocalize(ClanLogValue value)"
        }
    } // namespace ClanLogsViewUpdater

    namespace ClanLogTypeDescription { // "Models.References.Clan.ClanLogTypeDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x81E5C98; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t enum_id = 0x0; // "Enum<ClanLogTypeDescription>"
            inline constexpr std::uintptr_t AddCoins = 0x8; // "ClanLogTypeDescription"
            inline constexpr std::uintptr_t ClanJoin = 0x10; // "ClanLogTypeDescription"
            inline constexpr std::uintptr_t ClanLeave = 0x18; // "ClanLogTypeDescription"
            inline constexpr std::uintptr_t ClanKick = 0x20; // "ClanLogTypeDescription"
            inline constexpr std::uintptr_t ClanChangeRank = 0x28; // "ClanLogTypeDescription"
            inline constexpr std::uintptr_t AddObjectBet = 0x30; // "ClanLogTypeDescription"
            inline constexpr std::uintptr_t RemoveObjectBet = 0x38; // "ClanLogTypeDescription"
            inline constexpr std::uintptr_t ObjectBetWin = 0x40; // "ClanLogTypeDescription"
            inline constexpr std::uintptr_t ObjectBetLose = 0x48; // "ClanLogTypeDescription"
            inline constexpr std::uintptr_t ObjectAppointmentWin = 0x50; // "ClanLogTypeDescription"
            inline constexpr std::uintptr_t AddOwnedClanConquestObjectByAppointmentWin = 0x58; // "ClanLogTypeDescription"
            inline constexpr std::uintptr_t ObjectAppointmentLose = 0x60; // "ClanLogTypeDescription"
            inline constexpr std::uintptr_t RemoveOwnedClanConquestObjectByAppointmentLose = 0x68; // "ClanLogTypeDescription"
            inline constexpr std::uintptr_t AddOwnedClanConquestObjectByBetWin = 0x70; // "ClanLogTypeDescription"
            inline constexpr std::uintptr_t AddSectorBet = 0x78; // "ClanLogTypeDescription"
            inline constexpr std::uintptr_t RemoveSectorBet = 0x80; // "ClanLogTypeDescription"
            inline constexpr std::uintptr_t SectorBetWin = 0x88; // "ClanLogTypeDescription"
            inline constexpr std::uintptr_t SectorBetLose = 0x90; // "ClanLogTypeDescription"
            inline constexpr std::uintptr_t SectorAppointmentWin = 0x98; // "ClanLogTypeDescription"
            inline constexpr std::uintptr_t AddOwnedClanConquestSectorByAppointmentWin = 0xA0; // "ClanLogTypeDescription"
            inline constexpr std::uintptr_t SectorAppointmentLose = 0xA8; // "ClanLogTypeDescription"
            inline constexpr std::uintptr_t RemoveOwnedClanConquestSectorByAppointmentLose = 0xB0; // "ClanLogTypeDescription"
            inline constexpr std::uintptr_t AddOwnedClanConquestSectorByBetWin = 0xB8; // "ClanLogTypeDescription"
            inline constexpr std::uintptr_t MemberPlotAlarm = 0xC0; // "ClanLogTypeDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Enum = 0x44509B0; // "public static ReadOnlyEnum<ClanLogTypeDescription> get_Enum()"
        }
    } // namespace ClanLogTypeDescription

    namespace ClanLogTypeViewDescription { // "Game.Global.Clan.ClanLogTypeViewDescription (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Identified = 0x10; // "IdentifiedProperty<ClanLogTypeDescription>"
            inline constexpr std::uintptr_t Title = 0x18; // "LocalizedString"
            inline constexpr std::uintptr_t Localize = 0x20; // "LocalizedString"
            inline constexpr std::uintptr_t color = 0x28; // "PaletteColor"
            inline constexpr std::uintptr_t AvailableOnTabs = 0x30; // "ClanTabs"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Id = 0x3673760; // "public string get_Id()"
            inline constexpr std::uintptr_t get_Color = 0x3544D70; // "public Color get_Color()"
        }
    } // namespace ClanLogTypeViewDescription

    namespace ClanLogTypeViewDescriptions { // "Game.Global.Clan.ClanLogTypeViewDescriptions (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Won = 0x28; // "LocalizedString"
            inline constexpr std::uintptr_t Lost = 0x30; // "LocalizedString"
            inline constexpr std::uintptr_t Associate = 0x38; // "LocalizedString"
        }
    } // namespace ClanLogTypeViewDescriptions

    namespace ClanLogValue { // "Models.References.Clan.ClanLogValue (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Type = 0x10; // "ClanLogTypeDescription"
            inline constexpr std::uintptr_t Ts = 0x18; // "long"
        }
    } // namespace ClanLogValue

    namespace ClanLogValue_AddCoins { // "Models.References.Clan.ClanLogValue.AddCoins (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t UserName = 0x20; // "string"
            inline constexpr std::uintptr_t PublicId = 0x28; // "long"
            inline constexpr std::uintptr_t ClanRank = 0x30; // "ClanRankDescription"
            inline constexpr std::uintptr_t CoinsAmount = 0x38; // "int"
        }
    } // namespace ClanLogValue_AddCoins

    namespace ClanLogValue_AddObjectBet { // "Models.References.Clan.ClanLogValue.AddObjectBet (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t UserName = 0x20; // "string"
            inline constexpr std::uintptr_t PublicId = 0x28; // "long"
            inline constexpr std::uintptr_t ClanRank = 0x30; // "ClanRankDescription"
            inline constexpr std::uintptr_t ClanConquestObject = 0x38; // "ClanConquestObjectTypeDescription"
            inline constexpr std::uintptr_t CoinsAmount = 0x40; // "int"
        }
    } // namespace ClanLogValue_AddObjectBet

    namespace ClanLogValue_AddOwnedClanConquestObjectByAppointmentWin { // "Models.References.Clan.ClanLogValue.AddOwnedClanConquestObjectByAppointmentWin (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ClanConquestObject = 0x20; // "ClanConquestObjectTypeDescription"
        }
    } // namespace ClanLogValue_AddOwnedClanConquestObjectByAppointmentWin

    namespace ClanLogValue_AddOwnedClanConquestObjectByBetWin { // "Models.References.Clan.ClanLogValue.AddOwnedClanConquestObjectByBetWin (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ClanConquestObject = 0x20; // "ClanConquestObjectTypeDescription"
        }
    } // namespace ClanLogValue_AddOwnedClanConquestObjectByBetWin

    namespace ClanLogValue_AddOwnedClanConquestSectorByAppointmentWin { // "Models.References.Clan.ClanLogValue.AddOwnedClanConquestSectorByAppointmentWin (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ClanConquestSector = 0x20; // "SectorDescription"
        }
    } // namespace ClanLogValue_AddOwnedClanConquestSectorByAppointmentWin

    namespace ClanLogValue_AddOwnedClanConquestSectorByBetWin { // "Models.References.Clan.ClanLogValue.AddOwnedClanConquestSectorByBetWin (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ClanConquestSector = 0x20; // "SectorDescription"
        }
    } // namespace ClanLogValue_AddOwnedClanConquestSectorByBetWin

    namespace ClanLogValue_AddSectorBet { // "Models.References.Clan.ClanLogValue.AddSectorBet (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t UserName = 0x20; // "string"
            inline constexpr std::uintptr_t PublicId = 0x28; // "long"
            inline constexpr std::uintptr_t ClanRank = 0x30; // "ClanRankDescription"
            inline constexpr std::uintptr_t ClanConquestSector = 0x38; // "SectorDescription"
            inline constexpr std::uintptr_t CoinsAmount = 0x40; // "int"
        }
    } // namespace ClanLogValue_AddSectorBet

    namespace ClanLogValue_ClanChangeRank { // "Models.References.Clan.ClanLogValue.ClanChangeRank (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t UserName = 0x20; // "string"
            inline constexpr std::uintptr_t PublicId = 0x28; // "long"
            inline constexpr std::uintptr_t ClanRank = 0x30; // "ClanRankDescription"
        }
    } // namespace ClanLogValue_ClanChangeRank

    namespace ClanLogValue_ClanJoin { // "Models.References.Clan.ClanLogValue.ClanJoin (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t UserName = 0x20; // "string"
            inline constexpr std::uintptr_t PublicId = 0x28; // "long"
            inline constexpr std::uintptr_t ClanRank = 0x30; // "ClanRankDescription"
        }
    } // namespace ClanLogValue_ClanJoin

    namespace ClanLogValue_ClanKick { // "Models.References.Clan.ClanLogValue.ClanKick (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t UserName = 0x20; // "string"
            inline constexpr std::uintptr_t PublicId = 0x28; // "long"
            inline constexpr std::uintptr_t ClanRank = 0x30; // "ClanRankDescription"
        }
    } // namespace ClanLogValue_ClanKick

    namespace ClanLogValue_ClanLeave { // "Models.References.Clan.ClanLogValue.ClanLeave (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t UserName = 0x20; // "string"
            inline constexpr std::uintptr_t PublicId = 0x28; // "long"
            inline constexpr std::uintptr_t ClanRank = 0x30; // "ClanRankDescription"
        }
    } // namespace ClanLogValue_ClanLeave

    namespace ClanLogValue_MemberPlotAlarm { // "Models.References.Clan.ClanLogValue.MemberPlotAlarm (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t UserName = 0x20; // "string"
            inline constexpr std::uintptr_t PublicId = 0x28; // "long"
            inline constexpr std::uintptr_t ClanRank = 0x30; // "ClanRankDescription"
            inline constexpr std::uintptr_t Sector = 0x38; // "SectorDescription"
            inline constexpr std::uintptr_t Settlement = 0x40; // "SettlementDescription"
        }
    } // namespace ClanLogValue_MemberPlotAlarm

    namespace ClanLogValue_ObjectAppointmentLose { // "Models.References.Clan.ClanLogValue.ObjectAppointmentLose (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ClanConquestObject = 0x20; // "ClanConquestObjectTypeDescription"
        }
    } // namespace ClanLogValue_ObjectAppointmentLose

    namespace ClanLogValue_ObjectAppointmentWin { // "Models.References.Clan.ClanLogValue.ObjectAppointmentWin (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ClanConquestObject = 0x20; // "ClanConquestObjectTypeDescription"
        }
    } // namespace ClanLogValue_ObjectAppointmentWin

    namespace ClanLogValue_ObjectBetLose { // "Models.References.Clan.ClanLogValue.ObjectBetLose (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ClanConquestObject = 0x20; // "ClanConquestObjectTypeDescription"
        }
    } // namespace ClanLogValue_ObjectBetLose

    namespace ClanLogValue_ObjectBetWin { // "Models.References.Clan.ClanLogValue.ObjectBetWin (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ClanConquestObject = 0x20; // "ClanConquestObjectTypeDescription"
        }
    } // namespace ClanLogValue_ObjectBetWin

    namespace ClanLogValue_RemoveObjectBet { // "Models.References.Clan.ClanLogValue.RemoveObjectBet (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t UserName = 0x20; // "string"
            inline constexpr std::uintptr_t PublicId = 0x28; // "long"
            inline constexpr std::uintptr_t ClanRank = 0x30; // "ClanRankDescription"
            inline constexpr std::uintptr_t ClanConquestObject = 0x38; // "ClanConquestObjectTypeDescription"
            inline constexpr std::uintptr_t CoinsAmount = 0x40; // "int"
        }
    } // namespace ClanLogValue_RemoveObjectBet

    namespace ClanLogValue_RemoveOwnedClanConquestObjectByAppointmentLose { // "Models.References.Clan.ClanLogValue.RemoveOwnedClanConquestObjectByAppointmentLose (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ClanConquestObject = 0x20; // "ClanConquestObjectTypeDescription"
        }
    } // namespace ClanLogValue_RemoveOwnedClanConquestObjectByAppointmentLose

    namespace ClanLogValue_RemoveOwnedClanConquestSectorByAppointmentLose { // "Models.References.Clan.ClanLogValue.RemoveOwnedClanConquestSectorByAppointmentLose (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ClanConquestSector = 0x20; // "SectorDescription"
        }
    } // namespace ClanLogValue_RemoveOwnedClanConquestSectorByAppointmentLose

    namespace ClanLogValue_RemoveSectorBet { // "Models.References.Clan.ClanLogValue.RemoveSectorBet (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t UserName = 0x20; // "string"
            inline constexpr std::uintptr_t PublicId = 0x28; // "long"
            inline constexpr std::uintptr_t ClanRank = 0x30; // "ClanRankDescription"
            inline constexpr std::uintptr_t ClanConquestSector = 0x38; // "SectorDescription"
            inline constexpr std::uintptr_t CoinsAmount = 0x40; // "int"
        }
    } // namespace ClanLogValue_RemoveSectorBet

    namespace ClanLogValue_SectorAppointmentLose { // "Models.References.Clan.ClanLogValue.SectorAppointmentLose (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ClanConquestSector = 0x20; // "SectorDescription"
        }
    } // namespace ClanLogValue_SectorAppointmentLose

    namespace ClanLogValue_SectorAppointmentWin { // "Models.References.Clan.ClanLogValue.SectorAppointmentWin (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ClanConquestSector = 0x20; // "SectorDescription"
        }
    } // namespace ClanLogValue_SectorAppointmentWin

    namespace ClanLogValue_SectorBetLose { // "Models.References.Clan.ClanLogValue.SectorBetLose (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ClanConquestSector = 0x20; // "SectorDescription"
        }
    } // namespace ClanLogValue_SectorBetLose

    namespace ClanLogValue_SectorBetWin { // "Models.References.Clan.ClanLogValue.SectorBetWin (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ClanConquestSector = 0x20; // "SectorDescription"
        }
    } // namespace ClanLogValue_SectorBetWin

    namespace ClanMemberData { // "Models.Data.Clan.ClanMemberData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t PrivateId = 0x20; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t PublicId = 0x28; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t Name = 0x30; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t Rank = 0x38; // "IPrimitiveData<ClanRankDescription>"
            inline constexpr std::uintptr_t LastOnlineTs = 0x40; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t IsOnline = 0x48; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t BattleMode = 0x50; // "IPrimitiveData<BattleModeDescription>"
            inline constexpr std::uintptr_t Location = 0x58; // "IPrimitiveData<LocationDescription>"
            inline constexpr std::uintptr_t Sector = 0x60; // "IPrimitiveData<SectorDescription>"
            inline constexpr std::uintptr_t Settlement = 0x68; // "IPrimitiveData<SettlementDescription>"
            inline constexpr std::uintptr_t TransactionCoinsNumber = 0x70; // "IPrimitiveData<int>"
        }
    } // namespace ClanMemberData

    namespace ClanMemberModel { // "Game.Global.Clan.Model.ClanMemberModel (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "ClanMemberData"
            inline constexpr std::uintptr_t dataLeaderSlot = 0x18; // "IPrimitiveData<ClanMemberSlotDescription>"
            inline constexpr std::uintptr_t Slot = 0x20; // "ClanMemberSlotDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsExist = 0x3680890; // "public bool get_IsExist()"
            inline constexpr std::uintptr_t get_PublicId = 0x3680B80; // "public long get_PublicId()"
            inline constexpr std::uintptr_t get_Name = 0x3680B30; // "public string get_Name()"
            inline constexpr std::uintptr_t get_Rank = 0x3680BD0; // "public ClanRankDescription get_Rank()"
            inline constexpr std::uintptr_t get_IsLeader = 0x36808F0; // "public bool get_IsLeader()"
            inline constexpr std::uintptr_t get_IsOnline = 0x36809C0; // "public bool get_IsOnline()"
            inline constexpr std::uintptr_t get_LastOnlineTs = 0x3680A10; // "public long get_LastOnlineTs()"
            inline constexpr std::uintptr_t get_Location = 0x3680A60; // "public LocationDescription get_Location()"
            inline constexpr std::uintptr_t get_Settlement = 0x3680CF0; // "public SettlementDescription get_Settlement()"
            inline constexpr std::uintptr_t get_Sector = 0x3680CA0; // "public SectorDescription get_Sector()"
            inline constexpr std::uintptr_t get_IsClanBattle = 0x36807C0; // "public bool get_IsClanBattle()"
        }
    } // namespace ClanMemberModel

    namespace ClanMembersModelUpdater { // "Game.Global.Clan.ClanMembersModelUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t clanModel = 0x10; // "ClanModel"
            inline constexpr std::uintptr_t publicIdModel = 0x18; // "PublicIdModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x3673A80; // "public void Update()"
        }
    } // namespace ClanMembersModelUpdater

    namespace ClanModalChooseTimeSliderUpdater { // "Game.Global.Clan.ClanDialog.ProtectionContainer.ClanModalChooseTimeSliderUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t sliderTimeModel = 0x10; // "SliderTimeModel"
            inline constexpr std::uintptr_t currentTime = 0x18; // "Text<TimeSpan>"
            inline constexpr std::uintptr_t clanBattleAuctionPeriodConfig = 0x20; // "ClanBattleAuctionPeriodConfig"
            inline constexpr std::uintptr_t modalDialogModel = 0x28; // "ModalDialogModel"
            inline constexpr std::uintptr_t now = 0x30; // "INow"
            inline constexpr std::uintptr_t clanModel = 0x38; // "ClanModel"
            inline constexpr std::uintptr_t value = 0x40; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x36BD730; // "public void Update()"
        }
    } // namespace ClanModalChooseTimeSliderUpdater

    namespace ClanModalInviteByRanksChangeUpdater { // "Game.Global.Clan.ClanDialog.Updater.ClanModalInviteByRanksChangeUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t clanModel = 0x10; // "ClanModel"
            inline constexpr std::uintptr_t personalNotificationModel = 0x18; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t modalDialogModel = 0x20; // "ModalDialogModel"
            inline constexpr std::uintptr_t clanLocalization = 0x28; // "ClanLocalization"
            inline constexpr std::uintptr_t uiSoundModel = 0x30; // "GlobalUISoundModel"
            inline constexpr std::uintptr_t isTriggered = 0x38; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x36BD9E0; // "public void Update()"
        }
    } // namespace ClanModalInviteByRanksChangeUpdater

    namespace ClanModalKickByRankChangeUpdater { // "Game.Global.Clan.ClanDialog.Updater.ClanModalKickByRankChangeUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t contextActionRules = 0x10; // "GeneralContextActionRules"
            inline constexpr std::uintptr_t modalDialogModel = 0x18; // "ModalDialogModel"
            inline constexpr std::uintptr_t personalNotificationModel = 0x20; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t clanLocalization = 0x28; // "ClanLocalization"
            inline constexpr std::uintptr_t uiSoundModel = 0x30; // "GlobalUISoundModel"
            inline constexpr std::uintptr_t publicId = 0x38; // "long"
            inline constexpr std::uintptr_t isTriggered = 0x40; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x36BDB60; // "public void Update()"
        }
    } // namespace ClanModalKickByRankChangeUpdater

    namespace ClanModel { // "Game.Global.Clan.Model.ClanModel (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t BattleBets = 0x10; // "ReadOnlyDictionaryNonAlloc<ProtectionContext, ClanBattleBetModel>"
            inline constexpr std::uintptr_t BattleAppointments = 0x18; // "ReadOnlyDictionaryNonAlloc<ProtectionContext, ClanBattleAppointmentModel>"
            inline constexpr std::uintptr_t BusinessAppointments = 0x20; // "ReadOnlyDictionaryNonAlloc<ClanConquestObjectTypeDescription, ClanBattleAppointmentModel>"
            inline constexpr std::uintptr_t SectorAppointments = 0x28; // "ReadOnlyDictionaryNonAlloc<SectorDescription, ClanBattleAppointmentModel>"
            inline constexpr std::uintptr_t clanData = 0x30; // "ClanData"
            inline constexpr std::uintptr_t regionTsOffset = 0x38; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t isClanDataActual = 0x40; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t availableForJoinClansListUpdateTs = 0x48; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t coinData = 0x50; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t lastLogSlot = 0x58; // "IPrimitiveData<ClanLogSlotDescription>"
            inline constexpr std::uintptr_t betProcessModel = 0x60; // "ClanBattleBetProcessModel<ClanConquestObjectTypeDescription>"
            inline constexpr std::uintptr_t RegionUserClanModel = 0x68; // "RegionUserClanModel"
            inline constexpr std::uintptr_t ClanSearchExpiringResourceModel = 0x70; // "ExpiringResourceModel"
            inline constexpr std::uintptr_t ChangeStartOffsetIndexExpiringResource = 0x78; // "ExpiringResourceModel"
            inline constexpr std::uintptr_t ClanBattleBetExpiringResource = 0x80; // "ExpiringResourceModel"
            inline constexpr std::uintptr_t Members = 0x88; // "ReadOnlyDictionaryNonAlloc<ClanMemberSlotDescription, ClanMemberModel>"
            inline constexpr std::uintptr_t Requests = 0x90; // "Dictionary<int, ClanRequestModel>"
            inline constexpr std::uintptr_t Invites = 0x98; // "ReadOnlyDictionaryNonAlloc<ClanInviteSlotDescription, ClanInviteModel>"
            inline constexpr std::uintptr_t UserClanRequests = 0xA0; // "ReadOnlyDictionaryNonAlloc<UserClanRequestSlotDescription, UserClanRequestModel>"
            inline constexpr std::uintptr_t AddingClanBattleBetError = 0xA8; // "string"
            inline constexpr std::uintptr_t RemovingClanBattleBetError = 0xB0; // "string"
            inline constexpr std::uintptr_t PlayerAsClanMember = 0xB8; // "ClanMemberModel"
            inline constexpr std::uintptr_t ClanLeader = 0xC0; // "ClanMemberModel"
            inline constexpr std::uintptr_t ActualClanMemberModels = 0xC8; // "Dictionary<long, ClanMemberModel>"
            inline constexpr std::uintptr_t OwnedClanConquestObjects = 0xD0; // "IOwnedClanConquestItemsModel<ClanConquestObjectTypeDescription>"
            inline constexpr std::uintptr_t OwnedClanConquestSectors = 0xD8; // "IOwnedClanConquestItemsModel<SectorDescription>"
            inline constexpr std::uintptr_t Logs = 0xE0; // "Dictionary<ClanLogSlotDescription, ClanLogModel>"
            inline constexpr std::uintptr_t ClanConquestItemsRewardModel = 0xE8; // "ClanConquestItemsRewardModel"
            inline constexpr std::uintptr_t ClanLogsSource = 0xF0; // "SystemChatMessageSource"
            inline constexpr std::uintptr_t ChatPostedAppointments = 0xF8; // "HashSet<ClanBattleAppointmentModel>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_RegionTsOffset = 0x3683A00; // "public long get_RegionTsOffset()"
            inline constexpr std::uintptr_t get_HasClan = 0x36836B0; // "public bool get_HasClan()"
            inline constexpr std::uintptr_t get_ClanId = 0x3683530; // "public string get_ClanId()"
            inline constexpr std::uintptr_t get_Name = 0x36839E0; // "public string get_Name()"
            inline constexpr std::uintptr_t get_Tag = 0x3683A50; // "public string get_Tag()"
            inline constexpr std::uintptr_t get_IsAddingClanBattleBet = 0x36837F0; // "public bool get_IsAddingClanBattleBet()"
            inline constexpr std::uintptr_t get_IsRemovingClanBattleBet = 0x3683840; // "public bool get_IsRemovingClanBattleBet()"
            inline constexpr std::uintptr_t get_Description = 0x36835C0; // "public string get_Description()"
            inline constexpr std::uintptr_t get_Announcement = 0x3683390; // "public string get_Announcement()"
            inline constexpr std::uintptr_t get_EnterType = 0x3683660; // "public ClanEnterTypeDescription get_EnterType()"
            inline constexpr std::uintptr_t get_Language = 0x36838D0; // "public ClanLanguageDescription get_Language()"
            inline constexpr std::uintptr_t get_Emblem = 0x3683610; // "public ClanEmblemDescription get_Emblem()"
            inline constexpr std::uintptr_t get_CreateClanCooldownTs = 0x36835A0; // "public long get_CreateClanCooldownTs()"
            inline constexpr std::uintptr_t get_JoinClanCooldownTs = 0x36838B0; // "public long get_JoinClanCooldownTs()"
            inline constexpr std::uintptr_t get_AvailableForJoinClansListUpdateTs = 0x36833F0; // "public long get_AvailableForJoinClansListUpdateTs()"
            inline constexpr std::uintptr_t get_IsRequestingClan = 0x3683890; // "public bool get_IsRequestingClan()"
            inline constexpr std::uintptr_t get_Coins = 0x3683550; // "public int get_Coins()"
            inline constexpr std::uintptr_t get_LastLogSlot = 0x3683920; // "public ClanLogSlotDescription get_LastLogSlot()"
            inline constexpr std::uintptr_t get_ChangeEmblemCooldownEndTs = 0x36834B0; // "public long get_ChangeEmblemCooldownEndTs()"
            inline constexpr std::uintptr_t get_CanPerformClanActions = 0x3683440; // "public bool get_CanPerformClanActions()"
            inline constexpr std::uintptr_t get_CanPerformNotInClanActions = 0x3683490; // "public bool get_CanPerformNotInClanActions()"
            inline constexpr std::uintptr_t IsAnyAppointmentWithPreparePhase = 0x36814F0; // "public bool IsAnyAppointmentWithPreparePhase(long now)"
            inline constexpr std::uintptr_t CalculateCashAmount = 0x3680DC0; // "public int CalculateCashAmount()"
            inline constexpr std::uintptr_t HasMember = 0x3681320; // "public bool HasMember(long publicId)"
            inline constexpr std::uintptr_t get_ChatData = 0x3683510; // "public ChatMessagesData get_ChatData()"
        }
    } // namespace ClanModel

    namespace ClanNameConfig { // "Models.References.Clan.ClanNameConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t MinLength = 0x10; // "int"
            inline constexpr std::uintptr_t MaxLength = 0x14; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Validate = 0x40A02A0; // "public bool Validate(string name)"
        }
    } // namespace ClanNameConfig

    namespace ClanParticipantContextMenuView { // "Game.Global.Clan.ClanDialog.ClanParticipantContextMenuView (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ContextMenu = 0x20; // "ContextMenuView"
            inline constexpr std::uintptr_t Whisper = 0x28; // "CompositeButtonView"
            inline constexpr std::uintptr_t AddToBlackList = 0x30; // "CompositeButtonView"
            inline constexpr std::uintptr_t RemoveFromBlackList = 0x38; // "CompositeButtonView"
            inline constexpr std::uintptr_t InviteToParty = 0x40; // "CompositeButtonView"
            inline constexpr std::uintptr_t MakeALeader = 0x48; // "CompositeButtonView"
            inline constexpr std::uintptr_t SetRights = 0x50; // "CompositeButtonView"
            inline constexpr std::uintptr_t KickOut = 0x58; // "CompositeButtonView"
        }
    } // namespace ClanParticipantContextMenuView

    namespace ClanParticipantLineView { // "Game.Global.Clan.ClanDialog.ClanParticipantLineView (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t nickname = 0x20; // "TextMeshProUGUI"
            inline constexpr std::uintptr_t reputationPoints = 0x28; // "TextLabel<int>"
            inline constexpr std::uintptr_t rankName = 0x30; // "LocalizeStringEvent"
            inline constexpr std::uintptr_t rankIcon = 0x38; // "LocalizeStringEvent"
            inline constexpr std::uintptr_t isPlayerState = 0x40; // "StateElementBase"
            inline constexpr std::uintptr_t selection = 0x48; // "StateElementBase"
            inline constexpr std::uintptr_t OnlineStatus = 0x50; // "OnlineStatusView"
            inline constexpr std::uintptr_t ContextMenuContainer = 0x58; // "RectTransform"
            inline constexpr std::uintptr_t Menu = 0x60; // "CompositeButtonView"
            inline constexpr std::uintptr_t Leave = 0x68; // "CompositeButtonView"
            inline constexpr std::uintptr_t oldNickname = 0x70; // "string"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetNickname = 0x36A3B80; // "public void SetNickname(string nickname)"
            inline constexpr std::uintptr_t SetReputationPoints = 0x36A3C30; // "public void SetReputationPoints(int points)"
            inline constexpr std::uintptr_t SetRank = 0x36A3BE0; // "public void SetRank(LocalizedString rankName, LocalizedString rankIcon)"
            inline constexpr std::uintptr_t SetSelect = 0x36A3C90; // "public void SetSelect(bool selected)"
            inline constexpr std::uintptr_t SetIsPlayer = 0x36A3B40; // "public void SetIsPlayer(bool isPlayer)"
        }
    } // namespace ClanParticipantLineView

    namespace ClanParticipantsContainerUpdater { // "Game.Global.Clan.ClanDialog.ClanParticipantsContainerUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dialogModel = 0x10; // "ClanDialogModel"
            inline constexpr std::uintptr_t view = 0x18; // "ClanParticipantsContainerView"
            inline constexpr std::uintptr_t clanParticipantLineContent = 0x20; // "IComponentInstantiateContent<ClanParticipantLineView>"
            inline constexpr std::uintptr_t clanRankViewDescriptions = 0x28; // "ClanRankViewDescriptions"
            inline constexpr std::uintptr_t clanModel = 0x30; // "ClanModel"
            inline constexpr std::uintptr_t clanLocalization = 0x38; // "ClanLocalization"
            inline constexpr std::uintptr_t participantsClickableModel = 0x40; // "ClickableItemsModel<EnumValue<ClanMemberSlotDescription>>"
            inline constexpr std::uintptr_t leaveClickableModel = 0x48; // "ClickableListModel"
            inline constexpr std::uintptr_t locationNameViewDescriptions = 0x50; // "LocationNameViewDescriptions"
            inline constexpr std::uintptr_t sectorsViewDescription = 0x58; // "SectorsViewDescription"
            inline constexpr std::uintptr_t serverNow = 0x60; // "ISetNow"
            inline constexpr std::uintptr_t items = 0x68; // "List<ValueTuple<IDisposableContent<ClanParticipantLineView>, EnumValue<ClanMemberSlotDescription>>>"
            inline constexpr std::uintptr_t wasContextPosition = 0x70; // "Vector2"
            inline constexpr std::uintptr_t previousClanMembersTabsValue = 0x78; // "ClanMembersTabs"
            inline constexpr std::uintptr_t clanMemberModes = 0x80; // "ClanMemberModel[]"
            inline constexpr std::uintptr_t clanComparer = 0x88; // "ClanParticipantsContainerUpdater.ClanComparer"
            inline constexpr std::uintptr_t updaters = 0x90; // "List<IUpdater>"
            inline constexpr std::uintptr_t updater = 0x98; // "IUpdater"
            inline constexpr std::uintptr_t realmInfoModel = 0xA0; // "RealmInfoModel"
            inline constexpr std::uintptr_t streamerMode = 0xA8; // "IChangeBufferValue<bool>"
            inline constexpr std::uintptr_t localizationKeys = 0xB0; // "GlobalLocalizationKeys"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x36A4DE0; // "public void Update()"
            inline constexpr std::uintptr_t UpdateClanMembers = 0x36A3F20; // "private void UpdateClanMembers()"
            inline constexpr std::uintptr_t UpdatePosition = 0x36A4BC0; // "private void UpdatePosition(ClanParticipantLineView participantForContext)"
        }
    } // namespace ClanParticipantsContainerUpdater

    namespace ClanParticipantsContainerUpdater_ClanComparer { // "Game.Global.Clan.ClanDialog.ClanParticipantsContainerUpdater.ClanComparer (Global.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t GetPriority = 0x36989E0; // "private int GetPriority(ClanMemberModel model)"
            inline constexpr std::uintptr_t Compare = 0x36988F0; // "public int Compare(ClanMemberModel a, ClanMemberModel b)"
        }
    } // namespace ClanParticipantsContainerUpdater_ClanComparer

    namespace ClanParticipantsContainerView { // "Game.Global.Clan.ClanDialog.ClanParticipantsContainerView (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Invite = 0x20; // "CompositeButtonView"
            inline constexpr std::uintptr_t ScrollContent = 0x28; // "Transform"
            inline constexpr std::uintptr_t ScrollRect = 0x30; // "ScrollRect"
            inline constexpr std::uintptr_t ContextMenu = 0x38; // "ClanParticipantContextMenuView"
        }
    } // namespace ClanParticipantsContainerView

    namespace ClanPresetConfig { // "Models.References.Clan.ClanPresetConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t CreateClanCooldown = 0x10; // "long"
            inline constexpr std::uintptr_t JoinClanCooldown = 0x18; // "long"
        }
    } // namespace ClanPresetConfig

    namespace ClanPreviewModel { // "Game.Global.Clan.ClanSearch.ClanPreviewModel (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Id = 0x0; // "string"
            inline constexpr std::uintptr_t Tag = 0x8; // "string"
            inline constexpr std::uintptr_t Name = 0x10; // "string"
            inline constexpr std::uintptr_t ReputationPoints = 0x18; // "int"
            inline constexpr std::uintptr_t MembersCount = 0x1C; // "int"
            inline constexpr std::uintptr_t Emblem = 0x20; // "ClanEmblemDescription"
            inline constexpr std::uintptr_t Language = 0x28; // "ClanLanguageDescription"
            inline constexpr std::uintptr_t EnterType = 0x30; // "ClanEnterTypeDescription"
            inline constexpr std::uintptr_t ConquestObjectsCount = 0x38; // "int"
            inline constexpr std::uintptr_t ConquestSectorsCount = 0x3C; // "int"
            inline constexpr std::uintptr_t Description = 0x40; // "string"
            inline constexpr std::uintptr_t Leader = 0x48; // "string"
        }
    } // namespace ClanPreviewModel

    namespace ClanProtectionCategorySeparatorView { // "Game.Global.Clan.ClanDialog.ClanProtectionCategorySeparatorView (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Title = 0x20; // "LocalizeStringEvent"
        }
    } // namespace ClanProtectionCategorySeparatorView

    namespace ClanProtectionContainerUpdater { // "Game.Global.Clan.ClanDialog.ClanProtectionContainerUpdater (Global.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x81E8800; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace Fields {
            inline constexpr std::uintptr_t clanModel = 0x10; // "ClanModel"
            inline constexpr std::uintptr_t realmVersion = 0x18; // "RealmVersion"
            inline constexpr std::uintptr_t dialogModel = 0x20; // "ClanDialogModel"
            inline constexpr std::uintptr_t now = 0x28; // "INow"
            inline constexpr std::uintptr_t view = 0x30; // "ClanProtectionContainerView"
            inline constexpr std::uintptr_t protectionLineView = 0x38; // "IComponentInstantiateContent<ClanProtectionLineView>"
            inline constexpr std::uintptr_t protectionsClickableModel = 0x40; // "ClickableItemsModel<EnumValue<ClanConquestObjectTypeDescription>>"
            inline constexpr std::uintptr_t protectionsSectorsClickableModel = 0x48; // "ClickableItemsModel<EnumValue<SectorDescription>>"
            inline constexpr std::uintptr_t clanConquestObjectTypeViewDescriptions = 0x50; // "ClanConquestObjectTypeViewDescriptions"
            inline constexpr std::uintptr_t clanBattleCompetitorsTeamsSizeViewDescriptions = 0x58; // "ClanBattleCompetitorsTeamsSizeViewDescriptions"
            inline constexpr std::uintptr_t sectorsViewDescription = 0x60; // "SectorsViewDescription"
            inline constexpr std::uintptr_t locationNameViewDescriptions = 0x68; // "LocationNameViewDescriptions"
            inline constexpr std::uintptr_t linesObjects = 0x70; // "List<ValueTuple<EnumValue<ClanConquestObjectTypeDescription>, IDisposableContent<ClanProtectionLineView>>>"
            inline constexpr std::uintptr_t linesSectors = 0x78; // "List<ValueTuple<EnumValue<SectorDescription>, IDisposableContent<ClanProtectionLineView>>>"
        }
        namespace StaticFields {
            inline constexpr std::uintptr_t profitPeriodsPerHour = 0x0; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x36A5930; // "public void Update()"
            inline constexpr std::uintptr_t IsBattlePhase = 0x36A52C0; // "private bool IsBattlePhase(ClanBattleAppointmentModel appointment, long now, ClanBattleAuctionPeriodConfig clanBattleAuctionPeriodConfig)"
            inline constexpr std::uintptr_t Reorder = 0x36A5390; // "private void Reorder()"
            inline constexpr std::uintptr_t UpdateTopPanel = 0x36A5720; // "private void UpdateTopPanel()"
        }
    } // namespace ClanProtectionContainerUpdater

    namespace ClanProtectionContainerView { // "Game.Global.Clan.ClanDialog.ClanProtectionContainerView (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ConquestObjectsCount = 0x20; // "TextMeshProUGUI"
            inline constexpr std::uintptr_t LaunderingSpeed = 0x28; // "TextLabel<int>"
            inline constexpr std::uintptr_t ConquestSectorsCount = 0x30; // "TextMeshProUGUI"
            inline constexpr std::uintptr_t TaxInfo = 0x38; // "TextMeshProUGUI"
            inline constexpr std::uintptr_t Container = 0x40; // "Transform"
            inline constexpr std::uintptr_t hasLinesState = 0x48; // "StateGroup"
            inline constexpr std::uintptr_t timeState = 0x50; // "EnumStateElement<ClanProtectionContainerView.ClanProtectionState>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetHasLines = 0x36A3C90; // "public void SetHasLines(bool value)"
            inline constexpr std::uintptr_t SetShowTime = 0x36A8060; // "public void SetShowTime(ClanProtectionContainerView.ClanProtectionState value)"
        }
    } // namespace ClanProtectionContainerView

    namespace ClanProtectionInputUpdater { // "Game.Global.Clan.ClanDialog.ProtectionContainer.ClanProtectionInputUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t globalModel = 0x10; // "GlobalModel"
            inline constexpr std::uintptr_t clanLocalization = 0x18; // "ClanLocalization"
            inline constexpr std::uintptr_t conquestObjectsUpdater = 0x20; // "IUpdater"
            inline constexpr std::uintptr_t sectorsUpdater = 0x28; // "IUpdater"
            inline constexpr std::uintptr_t regionRoomConnection = 0x30; // "IRoomConnection"
            inline constexpr std::uintptr_t inputActions = 0x38; // "InputActions"
            inline constexpr std::uintptr_t globalLocalizationKeys = 0x40; // "GlobalLocalizationKeys"
            inline constexpr std::uintptr_t protectionContext = 0x48; // "ProtectionContext"
            inline constexpr std::uintptr_t isRequesting = 0x50; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t OnClickConquestObjectChangeTime = 0x36BE520; // "private void OnClickConquestObjectChangeTime(EnumValue<ClanConquestObjectTypeDescription> descriptionValue)"
            inline constexpr std::uintptr_t OnClickSectorChangeTime = 0x36BE680; // "private void OnClickSectorChangeTime(EnumValue<SectorDescription> descriptionValue)"
            inline constexpr std::uintptr_t OnClickChangeTime = 0x36BDD80; // "private void OnClickChangeTime(int currentOffset)"
            inline constexpr std::uintptr_t ChangeStartOffsetIndex = 0x36BDCC0; // "private void ChangeStartOffsetIndex(int newOffset)"
            inline constexpr std::uintptr_t Update = 0x36BE7E0; // "public void Update()"
        }
    } // namespace ClanProtectionInputUpdater

    namespace ClanProtectionLineView { // "Game.Global.Clan.ClanDialog.ClanProtectionLineView (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t categoryName = 0x20; // "LocalizeStringEvent"
            inline constexpr std::uintptr_t conquestObjectName = 0x28; // "LocalizeStringEvent"
            inline constexpr std::uintptr_t buildingIcon = 0x30; // "Image"
            inline constexpr std::uintptr_t stateProfitCategory = 0x38; // "EnumStateElement<ClanProtectionLineView.AppointmentCategory>"
            inline constexpr std::uintptr_t firstBonus = 0x40; // "ClanProtectionLineView.BonusView"
            inline constexpr std::uintptr_t secondBonus = 0x58; // "ClanProtectionLineView.BonusView"
            inline constexpr std::uintptr_t divider = 0x70; // "GameObject"
            inline constexpr std::uintptr_t ProtectionTimeLabel = 0x78; // "TextMeshProUGUI"
            inline constexpr std::uintptr_t Appointment = 0x80; // "EnumStateElement<ClanProtectionLineView.AppointmentState>"
            inline constexpr std::uintptr_t ChangeButton = 0x88; // "CompositeButtonView"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetObjectName = 0x3610890; // "public void SetObjectName(LocalizedString title)"
            inline constexpr std::uintptr_t SetCategoryName = 0xD79FE0; // "public void SetCategoryName(LocalizedString category)"
            inline constexpr std::uintptr_t SetIcon = 0x999C50; // "public void SetIcon(Sprite icon)"
            inline constexpr std::uintptr_t SetAppointmentCategory = 0x36A8110; // "public void SetAppointmentCategory(ClanProtectionLineView.AppointmentCategory category)"
            inline constexpr std::uintptr_t SetBonus = 0x36A8170; // "public void SetBonus(int bonusIndex, LocalizedString label, LocalizedString bonus)"
            inline constexpr std::uintptr_t ClearBonus = 0x36A80C0; // "public void ClearBonus()"
        }
    } // namespace ClanProtectionLineView

    namespace ClanProtectionLineView_BonusView { // "Game.Global.Clan.ClanDialog.ClanProtectionLineView.BonusView (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Container = 0x0; // "GameObject"
            inline constexpr std::uintptr_t Label = 0x8; // "LocalizeStringEvent"
            inline constexpr std::uintptr_t Value = 0x10; // "LocalizeStringEvent"
        }
    } // namespace ClanProtectionLineView_BonusView

    namespace ClanProtectionNotificationUpdater { // "Game.Global.Clan.ClanDialog.ClanProtectionNotificationUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t clanModel = 0x10; // "ClanModel"
            inline constexpr std::uintptr_t dialogModel = 0x18; // "ClanDialogModel"
            inline constexpr std::uintptr_t now = 0x20; // "INow"
            inline constexpr std::uintptr_t tabView = 0x28; // "TabView<ClanTabs>"
            inline constexpr std::uintptr_t isVisible = 0x30; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x36BEB40; // "public void Update()"
            inline constexpr std::uintptr_t CheckVisible = 0x36BEA20; // "private bool CheckVisible()"
        }
    } // namespace ClanProtectionNotificationUpdater

    namespace ClanRankDescription { // "Models.References.Clan.ClanRankDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t CanInviteAndManageRequests = 0x20; // "bool"
            inline constexpr std::uintptr_t CanKickOut = 0x21; // "bool"
            inline constexpr std::uintptr_t CanChangeRanks = 0x22; // "bool"
            inline constexpr std::uintptr_t CanMakeLeader = 0x23; // "bool"
            inline constexpr std::uintptr_t CanPublishAnnouncement = 0x24; // "bool"
            inline constexpr std::uintptr_t CanChangeSettings = 0x25; // "bool"
            inline constexpr std::uintptr_t CanParticipateInClanBattle = 0x26; // "bool"
            inline constexpr std::uintptr_t CanKickFromClanBattle = 0x27; // "bool"
            inline constexpr std::uintptr_t CanPlaceClanBattleBet = 0x28; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_CanChangeAppointmentStartTime = 0x9293E0; // "public bool get_CanChangeAppointmentStartTime()"
            inline constexpr std::uintptr_t get_CanCancelBets = 0x9293E0; // "public bool get_CanCancelBets()"
        }
    } // namespace ClanRankDescription

    namespace ClanRankDialogInputUpdater { // "Game.Global.Clan.RankDialog.ClanRankDialogInputUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dialogView = 0x10; // "ClanRankDialogView"
            inline constexpr std::uintptr_t dialogModel = 0x18; // "ClanRankDialogModel"
            inline constexpr std::uintptr_t globalModel = 0x20; // "GlobalModel"
            inline constexpr std::uintptr_t roomConnections = 0x28; // "IRoomConnections"
            inline constexpr std::uintptr_t clanLocalization = 0x30; // "ClanLocalization"
            inline constexpr std::uintptr_t isProgress = 0x38; // "bool"
            inline constexpr std::uintptr_t Handlers = 0x40; // "ValueTuple<InputMask, IUpdater>[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t OnConfirm = 0x3683A70; // "private void OnConfirm()"
            inline constexpr std::uintptr_t OnClose = 0xB1DF00; // "private void OnClose()"
            inline constexpr std::uintptr_t get_Priority = 0x7E5D90; // "public InputHandlerPriority get_Priority()"
        }
    } // namespace ClanRankDialogInputUpdater

    namespace ClanRankDialogModel { // "Game.Global.Clan.RankDialog.ClanRankDialogModel (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Selection = 0x18; // "TabData<IdentifiedProperty<ClanRankDescription>>"
            inline constexpr std::uintptr_t Slot = 0x20; // "ClanMemberSlotDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Open = 0x3684150; // "public void Open(ClanMemberSlotDescription slot)"
        }
    } // namespace ClanRankDialogModel

    namespace ClanRankDialogUpdater { // "Game.Global.Clan.RankDialog.ClanRankDialogUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t updater = 0x10; // "IUpdater"
            inline constexpr std::uintptr_t dialogModel = 0x18; // "ClanRankDialogModel"
            inline constexpr std::uintptr_t dialogView = 0x20; // "ClanRankDialogView"
            inline constexpr std::uintptr_t clanMember = 0x28; // "ClanMemberModel"
            inline constexpr std::uintptr_t clanModel = 0x30; // "ClanModel"
            inline constexpr std::uintptr_t publicId = 0x38; // "long"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x3684360; // "public void Update()"
            inline constexpr std::uintptr_t CanSelect = 0x3684200; // "private bool CanSelect()"
        }
    } // namespace ClanRankDialogUpdater

    namespace ClanRankDialogView { // "Game.Global.Clan.RankDialog.ClanRankDialogView (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Description = 0x20; // "TextLabel<string>"
            inline constexpr std::uintptr_t Ranks = 0x28; // "List<TabView<IdentifiedProperty<ClanRankDescription>>>"
            inline constexpr std::uintptr_t Close = 0x30; // "CompositeButtonView"
            inline constexpr std::uintptr_t Confirm = 0x38; // "CompositeButtonView"
            inline constexpr std::uintptr_t Cancel = 0x40; // "CompositeButtonView"
            inline constexpr std::uintptr_t Background = 0x48; // "ClickButtonView"
        }
    } // namespace ClanRankDialogView

    namespace ClanRankPermissionGuardUpdater { // "Game.Global.Clan.ClanRankPermissionGuardUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t clanModel = 0x10; // "ClanModel"
            inline constexpr std::uintptr_t hasPermission = 0x18; // "Func<ClanRankDescription, bool>"
            inline constexpr std::uintptr_t screen = 0x20; // "IScreenModel"
            inline constexpr std::uintptr_t notificationModel = 0x28; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t notification = 0x30; // "LocalizedString"
            inline constexpr std::uintptr_t lastRank = 0x38; // "ClanRankDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x3673D70; // "public void Update()"
        }
    } // namespace ClanRankPermissionGuardUpdater

    namespace ClanRankViewDescription { // "Game.Global.Clan.ClanRankViewDescription (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t id = 0x10; // "string"
            inline constexpr std::uintptr_t Identified = 0x18; // "IdentifiedProperty<ClanRankDescription>"
            inline constexpr std::uintptr_t IconName = 0x20; // "LocalizedString"
            inline constexpr std::uintptr_t Name = 0x28; // "LocalizedString"
            inline constexpr std::uintptr_t Icon = 0x30; // "LocalizedString"
            inline constexpr std::uintptr_t Pictogram = 0x38; // "string"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Id = 0x3674090; // "public string get_Id()"
        }
    } // namespace ClanRankViewDescription

    namespace ClanRemovingBetErrorUpdater { // "Game.Global.Clan.Updater.ClanRemovingBetErrorUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t clanModel = 0x10; // "ClanModel"
            inline constexpr std::uintptr_t soundModel = 0x18; // "GlobalUISoundModel"
            inline constexpr std::uintptr_t personalNotificationModel = 0x20; // "PersonalNotificationModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x3685110; // "public void Update()"
        }
    } // namespace ClanRemovingBetErrorUpdater

    namespace ClanRequestData { // "Models.Data.Clan.ClanRequestData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t PublicId = 0x20; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t Name = 0x28; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t ExpirationTs = 0x30; // "IPrimitiveData<long>"
        }
    } // namespace ClanRequestData

    namespace ClanRequestLineView { // "Game.Global.Clan.ClanDialog.ClanRequestLineView (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t TimeStatus = 0x20; // "TimeStatusView"
            inline constexpr std::uintptr_t Accept = 0x28; // "CompositeButtonView"
            inline constexpr std::uintptr_t Decline = 0x30; // "CompositeButtonView"
            inline constexpr std::uintptr_t nickname = 0x38; // "TextMeshProUGUI"
            inline constexpr std::uintptr_t reputationPoints = 0x40; // "TextLabel<int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetDescription = 0x36A8230; // "public void SetDescription(string nickname, int points)"
        }
    } // namespace ClanRequestLineView

    namespace ClanRequestModel { // "Game.Global.Clan.Model.ClanRequestModel (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "ClanRequestData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_PublicId = 0x3685360; // "public long get_PublicId()"
            inline constexpr std::uintptr_t get_Name = 0x3685310; // "public string get_Name()"
            inline constexpr std::uintptr_t get_ExpirationTs = 0x3685260; // "public long get_ExpirationTs()"
            inline constexpr std::uintptr_t get_HasRequest = 0x36852B0; // "public bool get_HasRequest()"
            inline constexpr std::uintptr_t Set = 0x7EC730; // "public void Set(ClanRequestData data)"
        }
    } // namespace ClanRequestModel

    namespace ClanRequestsContainerUpdater { // "Game.Global.Clan.ClanDialog.ClanRequestsContainerUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t clanModel = 0x10; // "ClanModel"
            inline constexpr std::uintptr_t dialogModel = 0x18; // "ClanDialogModel"
            inline constexpr std::uintptr_t now = 0x20; // "ISetNow"
            inline constexpr std::uintptr_t requestAcceptsClickableModel = 0x28; // "ClickableItemsModel<int>"
            inline constexpr std::uintptr_t requestDeclinesClickableModel = 0x30; // "ClickableItemsModel<int>"
            inline constexpr std::uintptr_t view = 0x38; // "ClanRequestsContainerView"
            inline constexpr std::uintptr_t clanRequestLineContent = 0x40; // "IComponentInstantiateContent<ClanRequestLineView>"
            inline constexpr std::uintptr_t clanLocalization = 0x48; // "ClanLocalization"
            inline constexpr std::uintptr_t views = 0x50; // "Dictionary<int, IDisposableContent<ClanRequestLineView>>"
            inline constexpr std::uintptr_t activeRequestIndexes = 0x58; // "HashSet<int>"
            inline constexpr std::uintptr_t notActiveRequestIndexes = 0x60; // "List<int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x36A8540; // "public void Update()"
        }
    } // namespace ClanRequestsContainerUpdater

    namespace ClanRequestsContainerView { // "Game.Global.Clan.ClanDialog.ClanRequestsContainerView (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ScrollContent = 0x20; // "Transform"
            inline constexpr std::uintptr_t Notification = 0x28; // "LocalizeStringEvent"
            inline constexpr std::uintptr_t NotificationContainer = 0x30; // "GameObject"
        }
        namespace Methods {
            inline constexpr std::uintptr_t ShowNotification = 0x36A92D0; // "public void ShowNotification(LocalizedString notification)"
            inline constexpr std::uintptr_t HideNotification = 0x36A92A0; // "public void HideNotification()"
        }
    } // namespace ClanRequestsContainerView

    namespace ClanRequestsModelUpdater { // "Game.Global.Clan.Updater.ClanRequestsModelUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t clientClanModel = 0x10; // "ClanModel"
            inline constexpr std::uintptr_t regionUserData = 0x18; // "RegionUserClientData"
            inline constexpr std::uintptr_t indexesToRemove = 0x20; // "HashSet<int>"
            inline constexpr std::uintptr_t hasClan = 0x28; // "bool"
            inline constexpr std::uintptr_t requestsObserver = 0x30; // "IDataObserver"
            inline constexpr std::uintptr_t replicationClock = 0x38; // "ReplicationClock"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x36853B0; // "public void Update()"
        }
    } // namespace ClanRequestsModelUpdater

    namespace ClanRequestsNotificationUpdater { // "Game.Global.Clan.ClanDialog.ClanRequestsNotificationUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t clanModel = 0x10; // "ClanModel"
            inline constexpr std::uintptr_t dialogModel = 0x18; // "ClanDialogModel"
            inline constexpr std::uintptr_t views = 0x20; // "GameObject[]"
            inline constexpr std::uintptr_t isVisible = 0x28; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x36BEF10; // "public void Update()"
            inline constexpr std::uintptr_t GetIsVisible = 0x36BED60; // "private bool GetIsVisible()"
        }
    } // namespace ClanRequestsNotificationUpdater

    namespace ClanSearchActionsUpdater { // "Game.Global.Clan.ClanSearch.Updater.ClanSearchActionsUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dialogModel = 0x10; // "ClanSearchDialogModel"
            inline constexpr std::uintptr_t clanModel = 0x18; // "ClanModel"
            inline constexpr std::uintptr_t dialogView = 0x20; // "ClanSearchDialogView"
            inline constexpr std::uintptr_t now = 0x28; // "INow"
            inline constexpr std::uintptr_t lastState = 0x30; // "ClanSearchDialogView.ActionState"
            inline constexpr std::uintptr_t delayCounter = 0x34; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x36A96F0; // "public void Update()"
            inline constexpr std::uintptr_t GetState = 0x36A9310; // "private ClanSearchDialogView.ActionState GetState()"
            inline constexpr std::uintptr_t get_IsDelayActive = 0x36A9840; // "private bool get_IsDelayActive()"
        }
    } // namespace ClanSearchActionsUpdater

    namespace ClanSearchClearInvalidSelectionUpdater { // "Game.Global.Clan.ClanSearch.ClanSearchClearInvalidSelectionUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dialogModel = 0x10; // "ClanSearchDialogModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x3685C20; // "public void Update()"
        }
    } // namespace ClanSearchClearInvalidSelectionUpdater

    namespace ClanSearchConfig { // "Models.References.Clan.ClanSearchConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t MaxResultCount = 0x10; // "int"
            inline constexpr std::uintptr_t ResourceDescription = 0x18; // "ExpiringResourceDescription"
            inline constexpr std::uintptr_t MinLength = 0x20; // "int"
            inline constexpr std::uintptr_t MaxLength = 0x24; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Validate = 0x44529C0; // "public bool Validate(string name)"
        }
    } // namespace ClanSearchConfig

    namespace ClanSearchDialogAutoRefreshUpdater { // "Game.Global.Clan.ClanSearch.ClanSearchDialogAutoRefreshUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dialogModel = 0x10; // "ClanSearchDialogModel"
            inline constexpr std::uintptr_t clanModel = 0x18; // "ClanModel"
            inline constexpr std::uintptr_t roomConnections = 0x20; // "IRoomConnections"
            inline constexpr std::uintptr_t now = 0x28; // "INow"
            inline constexpr std::uintptr_t serializer = 0x30; // "IClanSummaryDataCollectionSerializer"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x3685DF0; // "public void Update()"
            inline constexpr std::uintptr_t UpdateList = 0x3685D40; // "private void UpdateList()"
        }
    } // namespace ClanSearchDialogAutoRefreshUpdater

    namespace ClanSearchDialogCardViewUpdater { // "Game.Global.Clan.ClanSearch.ClanSearchDialogCardViewUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dialogModel = 0x10; // "ClanSearchDialogModel"
            inline constexpr std::uintptr_t dialogView = 0x18; // "ClanSearchDialogView"
            inline constexpr std::uintptr_t emblemViewDescriptions = 0x20; // "ClanEmblemViewDescriptions"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x36860E0; // "public void Update()"
        }
    } // namespace ClanSearchDialogCardViewUpdater

    namespace ClanSearchDialogDropdownUpdater { // "Game.Global.Clan.ClanSearch.ClanSearchDialogDropdownUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dialogModel = 0x10; // "ClanSearchDialogModel"
            inline constexpr std::uintptr_t dialogView = 0x18; // "ClanSearchDialogView"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x36863E0; // "public void Update()"
        }
    } // namespace ClanSearchDialogDropdownUpdater

    namespace ClanSearchDialogInputUpdater { // "Game.Global.Clan.ClanSearch.ClanSearchDialogInputUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t globalModel = 0x10; // "GlobalModel"
            inline constexpr std::uintptr_t dialogView = 0x18; // "ClanSearchDialogView"
            inline constexpr std::uintptr_t dialogModel = 0x20; // "ClanSearchDialogModel"
            inline constexpr std::uintptr_t roomConnections = 0x28; // "IRoomConnections"
            inline constexpr std::uintptr_t clanLocalization = 0x30; // "ClanLocalization"
            inline constexpr std::uintptr_t uiSoundModel = 0x38; // "GlobalUISoundModel"
            inline constexpr std::uintptr_t focusedHandler = 0x40; // "ValueTuple<InputMask, IUpdater>[]"
            inline constexpr std::uintptr_t idleHandler = 0x48; // "ValueTuple<InputMask, IUpdater>[]"
            inline constexpr std::uintptr_t isInProgress = 0x50; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t OnChangeLanguage = 0x3686810; // "private void OnChangeLanguage(int index)"
            inline constexpr std::uintptr_t OnOnlyOpenedToggle = 0x3686BB0; // "private void OnOnlyOpenedToggle(bool openedOnly)"
            inline constexpr std::uintptr_t UpdateParametersFilter = 0x3686EE0; // "private void UpdateParametersFilter(bool openedOnly, ClanLanguageDescription language)"
            inline constexpr std::uintptr_t IsMatch = 0x3686720; // "private static bool IsMatch(bool openedOnly, ClanLanguageDescription language, ClanPreviewModel model)"
            inline constexpr std::uintptr_t OnClickClan = 0x3686920; // "private void OnClickClan(string id)"
            inline constexpr std::uintptr_t OnSearchValueChanged = 0x3686C50; // "private void OnSearchValueChanged()"
            inline constexpr std::uintptr_t OnClickSearch = 0x3686A30; // "private void OnClickSearch()"
            inline constexpr std::uintptr_t OnClickSearchWithSound = 0x3686970; // "private void OnClickSearchWithSound()"
            inline constexpr std::uintptr_t OnJoin = 0x3686B00; // "private void OnJoin()"
            inline constexpr std::uintptr_t OnSendRequest = 0x3686E30; // "private void OnSendRequest()"
            inline constexpr std::uintptr_t OnClose = 0x3686AE0; // "private void OnClose()"
            inline constexpr std::uintptr_t get_Handlers = 0x3687B80; // "public ValueTuple<InputMask, IUpdater>[] get_Handlers()"
            inline constexpr std::uintptr_t IsInputFieldFocused = 0x36866F0; // "private bool IsInputFieldFocused()"
            inline constexpr std::uintptr_t get_Priority = 0x7E5DA0; // "public InputHandlerPriority get_Priority()"
        }
    } // namespace ClanSearchDialogInputUpdater

    namespace ClanSearchDialogListUpdater { // "Game.Global.Clan.ClanSearch.ClanSearchDialogListUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t clanModel = 0x10; // "ClanModel"
            inline constexpr std::uintptr_t dialogView = 0x18; // "ClanSearchDialogView"
            inline constexpr std::uintptr_t dialogModel = 0x20; // "ClanSearchDialogModel"
            inline constexpr std::uintptr_t clickableItemsModel = 0x28; // "ClickableItemsModel<string>"
            inline constexpr std::uintptr_t searchLineContent = 0x30; // "IComponentInstantiateContent<ClanSearchLineView>"
            inline constexpr std::uintptr_t globalScreenContent = 0x38; // "GlobalScreenContent"
            inline constexpr std::uintptr_t now = 0x40; // "INow"
            inline constexpr std::uintptr_t lines = 0x48; // "List<ValueTuple<ClanPreviewModel, IDisposableContent<ClanSearchLineView>>>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x3688EE0; // "public void Update()"
            inline constexpr std::uintptr_t Clear = 0x3687BD0; // "private void Clear()"
            inline constexpr std::uintptr_t Redraw = 0x3687E60; // "private void Redraw()"
            inline constexpr std::uintptr_t UpdateSelections = 0x3688A90; // "private void UpdateSelections()"
        }
    } // namespace ClanSearchDialogListUpdater

    namespace ClanSearchDialogModel { // "Game.Global.Clan.ClanSearch.ClanSearchDialogModel (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t fullPreviewModels = 0x18; // "List<ClanPreviewModel>"
            inline constexpr std::uintptr_t previewModels = 0x20; // "Dictionary<string, ClanPreviewModel>"
            inline constexpr std::uintptr_t NeedRedrawList = 0x28; // "bool"
            inline constexpr std::uintptr_t NeedSelectClanId = 0x30; // "string"
            inline constexpr std::uintptr_t SelectedClanId = 0x38; // "string"
            inline constexpr std::uintptr_t IsRequestingClanList = 0x40; // "bool"
            inline constexpr std::uintptr_t lastParametersFilter = 0x48; // "ClanSearchFilter.ByParameters"
            inline constexpr std::uintptr_t filter = 0x50; // "ClanSearchFilter"
            inline constexpr std::uintptr_t FilterName = 0x58; // "string"
            inline constexpr std::uintptr_t IsSearching = 0x60; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_FullPreviewModels = 0x7E7130; // "public IReadOnlyList<ClanPreviewModel> get_FullPreviewModels()"
            inline constexpr std::uintptr_t get_PreviewModels = 0x7AB150; // "public IReadOnlyDictionary<string, ClanPreviewModel> get_PreviewModels()"
            inline constexpr std::uintptr_t SetFullPreviews = 0x36892F0; // "public void SetFullPreviews(IEnumerable<ClanPreviewModel> models)"
            inline constexpr std::uintptr_t TryGetFilter = 0x3689670; // "public bool TryGetFilter(out ClanSearchFilter filter)"
            inline constexpr std::uintptr_t TryGetLastParametersFilter = 0x36896C0; // "public bool TryGetLastParametersFilter(out ClanSearchFilter.ByParameters filter)"
            inline constexpr std::uintptr_t SetPreviewsWithFilter = 0x3689380; // "public void SetPreviewsWithFilter(ClanSearchFilter filter, IEnumerable<ClanPreviewModel> previews)"
            inline constexpr std::uintptr_t ClearAllFilters = 0x36890C0; // "public void ClearAllFilters()"
        }
    } // namespace ClanSearchDialogModel

    namespace ClanSearchDialogSelectedCardUpdater { // "Game.Global.Clan.ClanSearch.ClanSearchDialogSelectedCardUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dialogModel = 0x10; // "ClanSearchDialogModel"
            inline constexpr std::uintptr_t dialogView = 0x18; // "ClanSearchDialogView"
            inline constexpr std::uintptr_t needSelectClanId = 0x20; // "string"
            inline constexpr std::uintptr_t cardHided = 0x28; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x36A9850; // "public void Update()"
        }
    } // namespace ClanSearchDialogSelectedCardUpdater

    namespace ClanSearchDialogUpdater { // "Game.Global.Clan.ClanSearch.ClanSearchDialogUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t updater = 0x10; // "IUpdater"
            inline constexpr std::uintptr_t clanLocalization = 0x18; // "ClanLocalization"
        }
        namespace Methods {
            inline constexpr std::uintptr_t AdviceValidate = 0x36A9BB0; // "private bool AdviceValidate(string name, out IText result)"
            inline constexpr std::uintptr_t FinalValidate = 0x36A9C70; // "private bool FinalValidate(string name, out IText result)"
            inline constexpr std::uintptr_t Update = 0x36A9D60; // "public void Update()"
        }
    } // namespace ClanSearchDialogUpdater

    namespace ClanSearchDialogView { // "Game.Global.Clan.ClanSearch.ClanSearchDialogView (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Close = 0x20; // "CompositeButtonView"
            inline constexpr std::uintptr_t Name = 0x28; // "InputFieldWithErrorView"
            inline constexpr std::uintptr_t NameFilterSearch = 0x30; // "CompositeButtonView"
            inline constexpr std::uintptr_t NameFilterSearchLoading = 0x38; // "LoadingView"
            inline constexpr std::uintptr_t ToggleView = 0x40; // "ToggleStateView"
            inline constexpr std::uintptr_t LanguageFilter = 0x48; // "DropdownView"
            inline constexpr std::uintptr_t activeParametersFilters = 0x50; // "StateElementBase"
            inline constexpr std::uintptr_t listEmptyContainer = 0x58; // "GameObject"
            inline constexpr std::uintptr_t Content = 0x60; // "Transform"
            inline constexpr std::uintptr_t ClanCard = 0x68; // "ClanCardInfoView"
            inline constexpr std::uintptr_t clanCardInfoResultState = 0x70; // "EnumStateElement<ClanSearchDialogView.ClanCardInfoResultType>"
            inline constexpr std::uintptr_t actionState = 0x78; // "StateGroup"
            inline constexpr std::uintptr_t description = 0x80; // "TextMeshProUGUI"
            inline constexpr std::uintptr_t Join = 0x88; // "CompositeButtonView"
            inline constexpr std::uintptr_t SendRequest = 0x90; // "CompositeButtonView"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetParametersFiltersActive = 0x36AAE50; // "public void SetParametersFiltersActive(bool active)"
            inline constexpr std::uintptr_t SetDescription = 0x3573870; // "public void SetDescription(string description)"
            inline constexpr std::uintptr_t SetActionState = 0x36AAD70; // "public void SetActionState(ClanSearchDialogView.ActionState value)"
            inline constexpr std::uintptr_t SetListEmpty = 0x36AAE00; // "public void SetListEmpty(bool value)"
            inline constexpr std::uintptr_t SetClanCardInfoResult = 0x36AADA0; // "public void SetClanCardInfoResult(bool hasResult)"
        }
    } // namespace ClanSearchDialogView

    namespace ClanSearchFilter_ByParameters { // "Game.Global.Clan.ClanSearch.ClanSearchFilter.ByParameters (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t OpenedOnly = 0x10; // "bool"
            inline constexpr std::uintptr_t Language = 0x18; // "ClanLanguageDescription"
        }
    } // namespace ClanSearchFilter_ByParameters

    namespace ClanSearchLineView { // "Game.Global.Clan.ClanSearch.ClanSearchLineView (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Emblem = 0x20; // "ClanEmblemView"
            inline constexpr std::uintptr_t Select = 0x28; // "CompositeButtonView"
            inline constexpr std::uintptr_t selectionState = 0x30; // "StateGroup"
            inline constexpr std::uintptr_t requestState = 0x38; // "StateGroup"
            inline constexpr std::uintptr_t pointState = 0x40; // "StateGroup"
            inline constexpr std::uintptr_t ClanName = 0x48; // "TextLabel<string, string>"
            inline constexpr std::uintptr_t participantsCount = 0x50; // "TextMeshProUGUI"
            inline constexpr std::uintptr_t reputationPoints = 0x58; // "TextLabel<int>"
            inline constexpr std::uintptr_t status = 0x60; // "LocalizeStringEvent"
            inline constexpr std::uintptr_t statusText = 0x68; // "TextMeshProUGUI"
            inline constexpr std::uintptr_t language = 0x70; // "LocalizeStringEvent"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetParticipantsCount = 0x36AAEA0; // "public void SetParticipantsCount(int count, int max)"
            inline constexpr std::uintptr_t SetStatus = 0x36AAFA0; // "public void SetStatus(LocalizedString status, Color color, bool isRequestSent)"
            inline constexpr std::uintptr_t SetLanguage = 0x36AAE80; // "public void SetLanguage(LocalizedString language)"
            inline constexpr std::uintptr_t SetPoints = 0x36AAF40; // "public void SetPoints(int value)"
            inline constexpr std::uintptr_t SetSelected = 0x9A5610; // "public void SetSelected(bool selected)"
            inline constexpr std::uintptr_t SetRequestSent = 0xD59060; // "public void SetRequestSent(bool selected)"
        }
    } // namespace ClanSearchLineView

    namespace ClanSearchNameFilterControlUpdater { // "Game.Global.Clan.ClanSearch.ClanSearchNameFilterControlUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dialogModel = 0x10; // "ClanSearchDialogModel"
            inline constexpr std::uintptr_t dialogView = 0x18; // "ClanSearchDialogView"
            inline constexpr std::uintptr_t inputFieldModel = 0x20; // "ModalInputFieldModel"
            inline constexpr std::uintptr_t inputFieldView = 0x28; // "InputFieldView"
            inline constexpr std::uintptr_t wasFilter = 0x30; // "ClanSearchFilter"
            inline constexpr std::uintptr_t inputFieldUpdater = 0x38; // "ModalInputFieldUpdater"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x36AB030; // "public void Update()"
        }
    } // namespace ClanSearchNameFilterControlUpdater

    namespace ClanSearchOnlyOpenedToggleUpdater { // "Game.Global.Clan.ClanSearch.ClanSearchOnlyOpenedToggleUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dialogModel = 0x10; // "ClanSearchDialogModel"
            inline constexpr std::uintptr_t dialogView = 0x18; // "ClanSearchDialogView"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x7B3360; // "public void Update()"
        }
    } // namespace ClanSearchOnlyOpenedToggleUpdater

    namespace ClanSearchParametersFiltersActiveUpdater { // "Game.Global.Clan.ClanSearch.ClanSearchParametersFiltersActiveUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dialogView = 0x10; // "ClanSearchDialogView"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x36AB330; // "public void Update()"
        }
    } // namespace ClanSearchParametersFiltersActiveUpdater

    namespace ClanSettingsButtonCreateUpdater { // "Game.Global.Clan.ClanSettings.ClanSettingsButtonCreateUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dialogModel = 0x10; // "ClanSettingsDialogModel"
            inline constexpr std::uintptr_t clanModel = 0x18; // "ClanModel"
            inline constexpr std::uintptr_t coinsModel = 0x20; // "ICoinsReadonlyModel"
            inline constexpr std::uintptr_t dialogView = 0x28; // "ClanSettingsDialogView"
            inline constexpr std::uintptr_t createText = 0x30; // "Text<Money, string>"
            inline constexpr std::uintptr_t enoughMoney = 0x38; // "bool"
            inline constexpr std::uintptr_t isInteractable = 0x39; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t GetCreateClanConfirmationButtonColorCode = 0x3689A60; // "private string GetCreateClanConfirmationButtonColorCode(bool isEnough)"
            inline constexpr std::uintptr_t Update = 0x3689AC0; // "public void Update()"
        }
    } // namespace ClanSettingsButtonCreateUpdater

    namespace ClanSettingsCloseOnRankChangedUpdater { // "Game.Global.Clan.ClanSettings.ClanSettingsCloseOnRankChangedUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t clanDialogModel = 0x10; // "ClanDialogModel"
            inline constexpr std::uintptr_t personalNotificationModel = 0x18; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t dialogModel = 0x20; // "ClanSettingsDialogModel"
            inline constexpr std::uintptr_t clanModel = 0x28; // "ClanModel"
            inline constexpr std::uintptr_t clanLocalization = 0x30; // "ClanLocalization"
            inline constexpr std::uintptr_t uiSoundModel = 0x38; // "GlobalUISoundModel"
            inline constexpr std::uintptr_t isTriggered = 0x40; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x368A0A0; // "public void Update()"
        }
    } // namespace ClanSettingsCloseOnRankChangedUpdater

    namespace ClanSettingsCurrentPageViewUpdater { // "Game.Global.Clan.ClanSettings.ClanSettingsCurrentPageViewUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t pageView = 0x10; // "TextLabel<int, int>"
            inline constexpr std::uintptr_t dialog = 0x18; // "ClanSettingsDialogModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x368A280; // "public void Update()"
        }
    } // namespace ClanSettingsCurrentPageViewUpdater

    namespace ClanSettingsDescriptionDialogUpdater { // "Game.Global.Clan.ClanSettings.ClanSettingsDescriptionDialogUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dialogModel = 0x10; // "ClanSettingsDialogModel"
            inline constexpr std::uintptr_t inputFieldWithErrorView = 0x18; // "InputFieldWithErrorView"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x368A2E0; // "public void Update()"
        }
    } // namespace ClanSettingsDescriptionDialogUpdater

    namespace ClanSettingsDialogInputUpdater { // "Game.Global.Clan.ClanSettings.ClanSettingsDialogInputUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t globalModel = 0x10; // "GlobalModel"
            inline constexpr std::uintptr_t dialogView = 0x18; // "ClanSettingsDialogView"
            inline constexpr std::uintptr_t dialogModel = 0x20; // "ClanSettingsDialogModel"
            inline constexpr std::uintptr_t emblemsPerPage = 0x28; // "int"
            inline constexpr std::uintptr_t roomConnections = 0x30; // "IRoomConnections"
            inline constexpr std::uintptr_t clanLocalization = 0x38; // "ClanLocalization"
            inline constexpr std::uintptr_t coinsModel = 0x40; // "ICoinsReadonlyModel"
            inline constexpr std::uintptr_t focusedHandler = 0x48; // "ValueTuple<InputMask, IUpdater>[]"
            inline constexpr std::uintptr_t idleHandler = 0x50; // "ValueTuple<InputMask, IUpdater>[]"
            inline constexpr std::uintptr_t clanModel = 0x58; // "ClanModel"
            inline constexpr std::uintptr_t timeModel = 0x60; // "UserTimeModel"
            inline constexpr std::uintptr_t isProcess = 0x68; // "bool"
            inline constexpr std::uintptr_t hasClan = 0x69; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t OnEmblemClicked = 0x368A9B0; // "private void OnEmblemClicked(int index)"
            inline constexpr std::uintptr_t OnCreateAndEdit = 0x368A680; // "private void OnCreateAndEdit()"
            inline constexpr std::uintptr_t OnCreate = 0x368A900; // "private void OnCreate()"
            inline constexpr std::uintptr_t OnSave = 0x368AAB0; // "private void OnSave()"
            inline constexpr std::uintptr_t OnNextPage = 0x368AA10; // "private void OnNextPage()"
            inline constexpr std::uintptr_t OnPrevPage = 0x368AA60; // "private void OnPrevPage()"
            inline constexpr std::uintptr_t OnClose = 0x368A630; // "private void OnClose()"
            inline constexpr std::uintptr_t get_Handlers = 0x368B380; // "public ValueTuple<InputMask, IUpdater>[] get_Handlers()"
            inline constexpr std::uintptr_t get_Priority = 0x7E5DA0; // "public InputHandlerPriority get_Priority()"
            inline constexpr std::uintptr_t IsEditingText = 0x368A440; // "private bool IsEditingText()"
            inline constexpr std::uintptr_t IsSubmitTriggered = 0x368A5C0; // "private bool IsSubmitTriggered()"
            inline constexpr std::uintptr_t IsInputFieldFocused = 0x368A530; // "private bool IsInputFieldFocused()"
        }
    } // namespace ClanSettingsDialogInputUpdater

    namespace ClanSettingsDialogModel { // "Game.Global.Clan.ClanSettings.ClanSettingsDialogModel (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ShowClanDialogAfterClose = 0x18; // "bool"
            inline constexpr std::uintptr_t Name = 0x20; // "string"
            inline constexpr std::uintptr_t Tag = 0x28; // "string"
            inline constexpr std::uintptr_t Description = 0x30; // "string"
            inline constexpr std::uintptr_t Language = 0x38; // "ClanLanguageDescription"
            inline constexpr std::uintptr_t EnterType = 0x40; // "ClanEnterTypeDescription"
            inline constexpr std::uintptr_t IsNameValid = 0x48; // "bool"
            inline constexpr std::uintptr_t IsTagValid = 0x49; // "bool"
            inline constexpr std::uintptr_t OccupiedTag = 0x50; // "string"
            inline constexpr std::uintptr_t OccupiedName = 0x58; // "string"
            inline constexpr std::uintptr_t PagesCount = 0x60; // "int"
            inline constexpr std::uintptr_t CurrentPage = 0x64; // "int"
            inline constexpr std::uintptr_t EmblemIndex = 0x68; // "int"
            inline constexpr std::uintptr_t Emblem = 0x70; // "ClanEmblemDescription"
            inline constexpr std::uintptr_t IsClanCreating = 0x78; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Open = 0x368B3B0; // "public void Open(bool showClanDialogAfterClose)"
            inline constexpr std::uintptr_t SetEmblem = 0x368B3C0; // "public void SetEmblem(int index)"
            inline constexpr std::uintptr_t SetEmblem_2 = 0x368B470; // "public void SetEmblem(ClanEmblemDescription emblem)"
        }
    } // namespace ClanSettingsDialogModel

    namespace ClanSettingsDialogUpdater { // "Game.Global.Clan.ClanSettings.ClanSettingsDialogUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t updaters = 0x10; // "IUpdater"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x368B4B0; // "public void Update()"
        }
    } // namespace ClanSettingsDialogUpdater

    namespace ClanSettingsDialogView { // "Game.Global.Clan.ClanSettings.ClanSettingsDialogView (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Emblem = 0x20; // "ClanEmblemView"
            inline constexpr std::uintptr_t Close = 0x28; // "CompositeButtonView"
            inline constexpr std::uintptr_t state = 0x30; // "StateGroup"
            inline constexpr std::uintptr_t isCreatingState = 0x38; // "StateElementBase"
            inline constexpr std::uintptr_t EmblemsPerPage = 0x40; // "int"
            inline constexpr std::uintptr_t EmblemsContent = 0x48; // "Transform"
            inline constexpr std::uintptr_t NextPage = 0x50; // "CompositeButtonView"
            inline constexpr std::uintptr_t PrevPage = 0x58; // "CompositeButtonView"
            inline constexpr std::uintptr_t SelectedPageIndicator = 0x60; // "TextLabel<int, int>"
            inline constexpr std::uintptr_t Name = 0x68; // "InputFieldWithErrorView"
            inline constexpr std::uintptr_t NameLimit = 0x70; // "InputFieldWithLimitCounterView"
            inline constexpr std::uintptr_t Tag = 0x78; // "InputFieldWithErrorView"
            inline constexpr std::uintptr_t TagLimit = 0x80; // "InputFieldWithLimitCounterView"
            inline constexpr std::uintptr_t Description = 0x88; // "InputFieldWithErrorView"
            inline constexpr std::uintptr_t DescriptionLimit = 0x90; // "InputFieldWithLimitCounterView"
            inline constexpr std::uintptr_t Language = 0x98; // "DropdownView"
            inline constexpr std::uintptr_t InviteType = 0xA0; // "DropdownView"
            inline constexpr std::uintptr_t CreateAndEdit = 0xA8; // "CompositeButtonView"
            inline constexpr std::uintptr_t ButtonText = 0xB0; // "LocalizeStringEvent"
            inline constexpr std::uintptr_t CreateCountStyle = 0xB8; // "ColorStyleViewDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetState = 0x97CF70; // "public void SetState(ClanSettingsDialogView.State state)"
            inline constexpr std::uintptr_t SetIsCreating = 0xD59060; // "public void SetIsCreating(bool value)"
        }
    } // namespace ClanSettingsDialogView

    namespace ClanSettingsEmblemCellUpdater { // "Game.Global.Clan.ClanSettings.ClanSettingsEmblemCellUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dialogModel = 0x10; // "ClanSettingsDialogModel"
            inline constexpr std::uintptr_t index = 0x18; // "int"
            inline constexpr std::uintptr_t clanEmblemViewDescriptions = 0x20; // "ClanEmblemViewDescriptions"
            inline constexpr std::uintptr_t emblemsPerPage = 0x28; // "int"
            inline constexpr std::uintptr_t view = 0x30; // "ClanCellEmblemView"
            inline constexpr std::uintptr_t currentPage = 0x38; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x368CBB0; // "public void Update()"
            inline constexpr std::uintptr_t UpdateEmblem = 0x368CA50; // "private void UpdateEmblem(int emblemIndex)"
        }
    } // namespace ClanSettingsEmblemCellUpdater

    namespace ClanSettingsEmblemDialogUpdater { // "Game.Global.Clan.ClanSettings.ClanSettingsEmblemDialogUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dialogModel = 0x10; // "ClanSettingsDialogModel"
            inline constexpr std::uintptr_t clanEmblemViewDescriptions = 0x18; // "ClanEmblemViewDescriptions"
            inline constexpr std::uintptr_t emblemView = 0x20; // "ClanEmblemView"
            inline constexpr std::uintptr_t emblemIndex = 0x28; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x368CEB0; // "public void Update()"
        }
    } // namespace ClanSettingsEmblemDialogUpdater

    namespace ClanSettingsEmblemsDialogUpdater { // "Game.Global.Clan.ClanSettings.ClanSettingsEmblemsDialogUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t updaters = 0x10; // "IUpdater"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x368CFB0; // "public void Update()"
        }
    } // namespace ClanSettingsEmblemsDialogUpdater

    namespace ClanSettingsEnterTypeDialogUpdater { // "Game.Global.Clan.ClanSettings.ClanSettingsEnterTypeDialogUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dialogModel = 0x10; // "ClanSettingsDialogModel"
            inline constexpr std::uintptr_t dialogView = 0x18; // "ClanSettingsDialogView"
            inline constexpr std::uintptr_t wasEnterTypeIndex = 0x20; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x368D2F0; // "public void Update()"
        }
    } // namespace ClanSettingsEnterTypeDialogUpdater

    namespace ClanSettingsIsCreatingUpdater { // "Game.Global.Clan.ClanSettings.ClanSettingsIsCreatingUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dialogModel = 0x10; // "ClanSettingsDialogModel"
            inline constexpr std::uintptr_t view = 0x18; // "ClanSettingsDialogView"
            inline constexpr std::uintptr_t isClanCreating = 0x20; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x368D630; // "public void Update()"
        }
    } // namespace ClanSettingsIsCreatingUpdater

    namespace ClanSettingsLanguageDialogUpdater { // "Game.Global.Clan.ClanSettings.ClanSettingsLanguageDialogUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dialogModel = 0x10; // "ClanSettingsDialogModel"
            inline constexpr std::uintptr_t view = 0x18; // "ClanSettingsDialogView"
            inline constexpr std::uintptr_t wasLanguageIndex = 0x20; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x368D740; // "public void Update()"
        }
    } // namespace ClanSettingsLanguageDialogUpdater

    namespace ClanSettingsNameDialogUpdater { // "Game.Global.Clan.ClanSettings.ClanSettingsNameDialogUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dialogModel = 0x10; // "ClanSettingsDialogModel"
            inline constexpr std::uintptr_t inputFieldWithErrorView = 0x18; // "InputFieldWithErrorView"
            inline constexpr std::uintptr_t clanLocalization = 0x20; // "ClanLocalization"
            inline constexpr std::uintptr_t fieldValidationLocalization = 0x28; // "FieldValidationLocalization"
            inline constexpr std::uintptr_t clanModel = 0x30; // "ClanModel"
            inline constexpr std::uintptr_t wasFocusedOnce = 0x38; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x368DD70; // "public void Update()"
            inline constexpr std::uintptr_t UpdateName = 0x368DD20; // "private string UpdateName()"
            inline constexpr std::uintptr_t IsNameValid = 0x368DB40; // "private bool IsNameValid(string name, out IText errorMessage)"
            inline constexpr std::uintptr_t GetState = 0x368DA40; // "private InputFieldWithErrorView.InputFieldState GetState(bool isNameValid, IText nameValidText, out IText tip)"
        }
    } // namespace ClanSettingsNameDialogUpdater

    namespace ClanSettingsPageArrowUpdater { // "Game.Global.Clan.ClanSettings.ClanSettingsPageArrowUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dialogModel = 0x10; // "ClanSettingsDialogModel"
            inline constexpr std::uintptr_t pageButton = 0x18; // "CompositeButtonView"
            inline constexpr std::uintptr_t inactivePage = 0x20; // "int"
            inline constexpr std::uintptr_t wasInteractable = 0x24; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x368E120; // "public void Update()"
        }
    } // namespace ClanSettingsPageArrowUpdater

    namespace ClanSettingsPaginatorDialogUpdater { // "Game.Global.Clan.ClanSettings.ClanSettingsPaginatorDialogUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t updaters = 0x10; // "IUpdater"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x368E200; // "public void Update()"
        }
    } // namespace ClanSettingsPaginatorDialogUpdater

    namespace ClanSettingsSaveButtonUpdater { // "Game.Global.Clan.ClanSettings.ClanSettingsSaveButtonUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dialogModel = 0x10; // "ClanSettingsDialogModel"
            inline constexpr std::uintptr_t clanModel = 0x18; // "ClanModel"
            inline constexpr std::uintptr_t dialogView = 0x20; // "ClanSettingsDialogView"
            inline constexpr std::uintptr_t needSave = 0x28; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x368E7A0; // "public void Update()"
            inline constexpr std::uintptr_t GetNeedSave = 0x368E5E0; // "private bool GetNeedSave()"
        }
    } // namespace ClanSettingsSaveButtonUpdater

    namespace ClanSettingsTagDialogUpdater { // "Game.Global.Clan.ClanSettings.ClanSettingsTagDialogUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dialogModel = 0x10; // "ClanSettingsDialogModel"
            inline constexpr std::uintptr_t inputField = 0x18; // "InputFieldWithErrorView"
            inline constexpr std::uintptr_t clanLocalization = 0x20; // "ClanLocalization"
            inline constexpr std::uintptr_t fieldValidationLocalization = 0x28; // "FieldValidationLocalization"
            inline constexpr std::uintptr_t clanModel = 0x30; // "ClanModel"
            inline constexpr std::uintptr_t clanTagLengthValidationTip = 0x38; // "Text<int>"
            inline constexpr std::uintptr_t wasFocusedOnce = 0x40; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x368EBB0; // "public void Update()"
            inline constexpr std::uintptr_t GetState = 0x368E8D0; // "private InputFieldWithErrorView.InputFieldState GetState(bool isTagValid, IText tagValidText, out IText tip)"
            inline constexpr std::uintptr_t UpdateTag = 0x368EB50; // "private string UpdateTag()"
            inline constexpr std::uintptr_t IsTagValid = 0x368E9D0; // "private bool IsTagValid(string name, out IText errorMessage)"
        }
    } // namespace ClanSettingsTagDialogUpdater

    namespace ClanShowdownIconUiView { // "Game.Global.Clan.ClanShowdown.ClanShowdownIconUiView (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t timerState = 0x20; // "StateElementBase"
            inline constexpr std::uintptr_t Timer = 0x28; // "DateView"
            inline constexpr std::uintptr_t animation = 0x30; // "Animation"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetALittleTimeLeft = 0xD5BFC0; // "public void SetALittleTimeLeft(bool value)"
            inline constexpr std::uintptr_t PlayBlinkAnim = 0xB4C4D0; // "public void PlayBlinkAnim()"
            inline constexpr std::uintptr_t StopBlinkAnim = 0xB4C2A0; // "public void StopBlinkAnim()"
        }
    } // namespace ClanShowdownIconUiView

    namespace ClanShowdownIconViewUpdater { // "Game.Global.Clan.ClanShowdown.ClanShowdownIconViewUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t clanModel = 0x10; // "ClanModel"
            inline constexpr std::uintptr_t now = 0x18; // "INow"
            inline constexpr std::uintptr_t view = 0x20; // "ClanShowdownIconUiView"
            inline constexpr std::uintptr_t isBlinking = 0x28; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x368EFE0; // "public void Update()"
        }
    } // namespace ClanShowdownIconViewUpdater

    namespace ClanShowdownLineView { // "Game.Global.Clan.ClanDialog.AppointmentsContainer.ClanShowdownLineView (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ClanName = 0x20; // "TextLabel<string, string>"
            inline constexpr std::uintptr_t Date = 0x28; // "LocalizedDateView"
            inline constexpr std::uintptr_t WaitForAppointmentTimer = 0x30; // "TextLabel<long>"
            inline constexpr std::uintptr_t Enter = 0x38; // "CompositeButtonView"
            inline constexpr std::uintptr_t BattlePreparationPhaseTimer = 0x40; // "TextLabel<long>"
            inline constexpr std::uintptr_t CompetitorsCapacity = 0x48; // "TMP_Text"
            inline constexpr std::uintptr_t visibleState = 0x50; // "StateElementBase"
            inline constexpr std::uintptr_t actionState = 0x58; // "StateElementBase"
            inline constexpr std::uintptr_t locationCity = 0x60; // "LocalizeStringEvent"
            inline constexpr std::uintptr_t business = 0x68; // "LocalizeStringEvent"
            inline constexpr std::uintptr_t loading = 0x70; // "GameObject"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetVisibleState = 0x35767F0; // "public void SetVisibleState(ClanShowdownLineView.VisibleState value)"
            inline constexpr std::uintptr_t SetAction = 0x35A6D80; // "public void SetAction(ClanShowdownLineView.Actions value)"
            inline constexpr std::uintptr_t SetCity = 0x36BF060; // "public void SetCity(LocalizedString title)"
            inline constexpr std::uintptr_t SetConquestObject = 0xD5BF50; // "public void SetConquestObject(LocalizedString name)"
            inline constexpr std::uintptr_t SetLoading = 0x36BF080; // "public void SetLoading(bool isBattleEnter)"
        }
    } // namespace ClanShowdownLineView

    namespace ClanShowdownNotificationView { // "Game.Global.Clan.ClanShowdownNotificationView (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t animation = 0x20; // "Animation"
            inline constexpr std::uintptr_t TeamCapacityLabel = 0x28; // "TMP_Text"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsActive = 0x35C2E80; // "public bool get_IsActive()"
            inline constexpr std::uintptr_t Play = 0x35AD700; // "public void Play()"
            inline constexpr std::uintptr_t Update = 0x368F170; // "private void Update()"
            inline constexpr std::uintptr_t OnDisable = 0x35AD6C0; // "private void OnDisable()"
            inline constexpr std::uintptr_t Reset = 0x35AD6C0; // "public void Reset()"
        }
    } // namespace ClanShowdownNotificationView

    namespace ClanShowdownRules { // "Game.Global.Clan.ClanShowdown.ClanShowdownRules (Global.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x81ED9A8; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t clanShowdownType = 0x0; // "Type"
        }
        namespace Methods {
            inline constexpr std::uintptr_t IsClanShowdownIconActive = 0x368F780; // "public static bool IsClanShowdownIconActive(ClanModel clanModel, GlobalNotificationModel globalNotificationModel, long now)"
            inline constexpr std::uintptr_t TryGetClanShowdownTimeLeftToStart = 0x368F880; // "public static bool TryGetClanShowdownTimeLeftToStart(ClanModel clanModel, long now, out long timeLeft, out ClanBattleCompetitorsTeamsSizeDescription teamSize)"
            inline constexpr std::uintptr_t GetAppointmentTime = 0x368F550; // "public static TimeSpan GetAppointmentTime(int period, int offset, ClanBattleAuctionPeriodConfig clanBattleAuctionPeriodConfig, long regionTsOffset)"
            inline constexpr std::uintptr_t GetNextAppointmentTime = 0x368F640; // "public static TimeSpan GetNextAppointmentTime(long now, int offset, ClanBattleAuctionPeriodConfig clanBattleAuctionPeriodConfig, long regionTsOffset)"
            inline constexpr std::uintptr_t CanRequestChangeStartOffsetIndex = 0x368F4F0; // "public static bool CanRequestChangeStartOffsetIndex(long now, ClanBattleAuctionPeriodConfig clanBattleAuctionPeriodConfig, long regionTsOffset)"
            inline constexpr std::uintptr_t CanParticipateInClanBattle = 0x368F1F0; // "public static bool CanParticipateInClanBattle(GlobalModel globalModel, ProtectionContext protectionContext, ClanLocalization clanLocalization, PartyLocalization partyLocalization, out LocalizedString message)"
        }
    } // namespace ClanShowdownRules

    namespace ClanShowdownsUpdater { // "Game.Global.Clan.ClanDialog.AppointmentsContainer.ClanShowdownsUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t globalModel = 0x10; // "GlobalModel"
            inline constexpr std::uintptr_t globalScreenContent = 0x18; // "GlobalScreenContent"
            inline constexpr std::uintptr_t clickableModel = 0x20; // "ClickableItemsModel<ProtectionContext>"
            inline constexpr std::uintptr_t networkStatusModel = 0x28; // "NetworkStatusModel"
            inline constexpr std::uintptr_t dialogModel = 0x30; // "ClanDialogModel"
            inline constexpr std::uintptr_t view = 0x38; // "ClanAppointmentsContainer"
            inline constexpr std::uintptr_t clanShowdownLineView = 0x40; // "PooledLoadedComponentContent<ClanShowdownLineView>"
            inline constexpr std::uintptr_t views = 0x48; // "Dictionary<ProtectionContext, IDisposableContent<ClanShowdownLineView>>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x36BFDD0; // "public void Update()"
            inline constexpr std::uintptr_t AddView = 0x36BF0A0; // "private IDisposableContent<ClanShowdownLineView> AddView(ProtectionContext protectionContext)"
            inline constexpr std::uintptr_t RemoveView = 0x36BF1B0; // "private void RemoveView(ProtectionContext protectionContext)"
            inline constexpr std::uintptr_t UpdateView = 0x36BF450; // "private void UpdateView(ClanBattleAppointmentModel appointmentModel, ProtectionContext protectionContext, ClanShowdownLineView view)"
            inline constexpr std::uintptr_t GetVisibleState = 0x36BF190; // "private static ClanShowdownLineView.VisibleState GetVisibleState(long startTs, long now, long preparePhaseEndTs)"
        }
    } // namespace ClanShowdownsUpdater

    namespace ClanSummaryData { // "Models.Models.ClanSummaryData.ClanSummaryData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Id = 0x10; // "string"
            inline constexpr std::uintptr_t Name = 0x18; // "string"
            inline constexpr std::uintptr_t Tag = 0x20; // "string"
            inline constexpr std::uintptr_t MembersCount = 0x28; // "int"
            inline constexpr std::uintptr_t EnterType = 0x30; // "ClanEnterTypeDescription"
            inline constexpr std::uintptr_t Language = 0x38; // "ClanLanguageDescription"
            inline constexpr std::uintptr_t Emblem = 0x40; // "ClanEmblemDescription"
            inline constexpr std::uintptr_t Description = 0x48; // "string"
            inline constexpr std::uintptr_t LeaderName = 0x50; // "string"
            inline constexpr std::uintptr_t OwnedConquestObjectCount = 0x58; // "int"
            inline constexpr std::uintptr_t OwnedConquestSectorsCount = 0x5C; // "int"
        }
    } // namespace ClanSummaryData

    namespace ClanTabsVisitTimeUpdater { // "Game.Global.Clan.ClanDialog.ClanTabsVisitTimeUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dialogModel = 0x10; // "ClanDialogModel"
            inline constexpr std::uintptr_t playerPrefsModel = 0x18; // "PlayerPrefsModel"
            inline constexpr std::uintptr_t now = 0x20; // "INow"
            inline constexpr std::uintptr_t tab = 0x28; // "Nullable<ClanTabs>"
            inline constexpr std::uintptr_t membersTab = 0x30; // "Nullable<ClanMembersTabs>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x36C06D0; // "public void Update()"
            inline constexpr std::uintptr_t UpdateTimestamps = 0x36C0560; // "private void UpdateTimestamps(ClanTabs currentTab, ClanMembersTabs currentMembersTab)"
            inline constexpr std::uintptr_t TryUpdateRequestsClickTs = 0x36C03F0; // "private void TryUpdateRequestsClickTs()"
            inline constexpr std::uintptr_t TryUpdateRequestsClickTs_2 = 0x36C0460; // "private void TryUpdateRequestsClickTs(ClanTabs currentTab, ClanMembersTabs currentMembersTab)"
            inline constexpr std::uintptr_t TryUpdateAppointmentsClickTs = 0x36C0270; // "private void TryUpdateAppointmentsClickTs(ClanTabs currentTab)"
            inline constexpr std::uintptr_t TryUpdateProtectionClickTs = 0x36C0330; // "private void TryUpdateProtectionClickTs(ClanTabs currentTab)"
        }
    } // namespace ClanTabsVisitTimeUpdater

    namespace ClanTagConfig { // "Models.References.Clan.ClanTagConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Length = 0x10; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Validate = 0x4452C10; // "public bool Validate(string tag)"
        }
    } // namespace ClanTagConfig

    namespace ClanTransactionCoinsConfig { // "Models.References.Clan.ClanTransactionCoinsConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t MaxClanTransactionCoinsNumber = 0x10; // "int"
            inline constexpr std::uintptr_t MaxClanTransactionCoinsCount = 0x14; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Increase = 0x4452E10; // "public void Increase(IPrimitiveData<int> data)"
            inline constexpr std::uintptr_t Next = 0x4452EF0; // "public int Next(int number)"
        }
    } // namespace ClanTransactionCoinsConfig

    namespace ClearSelectedChatNotificationUpdater { // "Game.Global.Chat.ClearSelectedChatNotificationUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t chatDialog = 0x10; // "ChatDialogModel"
            inline constexpr std::uintptr_t chatsModel = 0x18; // "ChatsModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x36C0A50; // "public void Update()"
        }
    } // namespace ClearSelectedChatNotificationUpdater

    namespace ClientPartyMemberAccessModel { // "Game.Battle.Party.ClientPartyMemberAccessModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t worldEntitiesModel = 0x10; // "WorldEntitiesModel"
            inline constexpr std::uintptr_t partyModel = 0x18; // "PartyModel"
            inline constexpr std::uintptr_t battleConnectionModel = 0x20; // "BattleConnectionModel"
            inline constexpr std::uintptr_t characterSlotsModel = 0x28; // "ICharacterSlotsModel"
            inline constexpr std::uintptr_t settlementHelperModel = 0x30; // "ISettlementHelperModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t HasPlotAccess = 0x97CFC0; // "public bool HasPlotAccess(int characterId, int targetEntityId)"
            inline constexpr std::uintptr_t HasPlotAccess_2 = 0x97D0F0; // "public bool HasPlotAccess(int characterId, PlotModel plotModel)"
            inline constexpr std::uintptr_t HasSettlementLocationEntityAccess = 0x97D170; // "public bool HasSettlementLocationEntityAccess(int characterId)"
            inline constexpr std::uintptr_t IsSameParty = 0x97D5C0; // "public bool IsSameParty(long firstPublicId, long secondPublicId)"
            inline constexpr std::uintptr_t IsPartyContainsMember = 0x97D1D0; // "private bool IsPartyContainsMember(long targetMemberPublicId)"
            inline constexpr std::uintptr_t IsPartyContainsSettlementOwnerOrPlotOwner = 0x97D400; // "private bool IsPartyContainsSettlementOwnerOrPlotOwner()"
        }
    } // namespace ClientPartyMemberAccessModel

    namespace CloseDialogOnHasClanChangedUpdater { // "Game.Global.Clan.Updater.CloseDialogOnHasClanChangedUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dialogModel = 0x10; // "IScreenModel"
            inline constexpr std::uintptr_t clanModel = 0x18; // "ClanModel"
            inline constexpr std::uintptr_t hasClan = 0x20; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x368FB80; // "public void Update()"
        }
    } // namespace CloseDialogOnHasClanChangedUpdater

    namespace ConstantAuthorColorRule { // "Game.Global.Chat.ConstantAuthorColorRule (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t colorType = 0x10; // "UserColorType"
        }
        namespace Methods {
            inline constexpr std::uintptr_t TryGetColorType = 0x36D1540; // "public bool TryGetColorType(long publicId, out UserColorType colorType)"
        }
    } // namespace ConstantAuthorColorRule

    namespace ContextMenuScrollUpdater { // "Game.Global.Clan.ClanDialog.ParticipantsContainer.ContextMenuScrollUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t clanDialogModel = 0x10; // "ClanDialogModel"
            inline constexpr std::uintptr_t scrollRect = 0x18; // "ScrollRect"
            inline constexpr std::uintptr_t wasScrolled = 0x20; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x36C0AB0; // "public void Update()"
        }
    } // namespace ContextMenuScrollUpdater

    namespace CopsChatUpdater { // "Game.Battle.Player.CopsChatUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleData = 0x10; // "IBattleData"
            inline constexpr std::uintptr_t battleModel = 0x18; // "BattleModel"
            inline constexpr std::uintptr_t copChatSettings = 0x20; // "ChatSourceSettings"
            inline constexpr std::uintptr_t chatsModel = 0x28; // "ChatsModel"
            inline constexpr std::uintptr_t battleRoom = 0x30; // "IRoomConnection"
            inline constexpr std::uintptr_t chatLocalization = 0x38; // "ChatLocalization"
            inline constexpr std::uintptr_t blackListModel = 0x40; // "BlackListModel"
            inline constexpr std::uintptr_t badWordsFilter = 0x48; // "BadWordsFilterModel"
            inline constexpr std::uintptr_t systemChat = 0x50; // "SystemChatMessageSource"
            inline constexpr std::uintptr_t chatDialog = 0x58; // "ChatDialogModel"
            inline constexpr std::uintptr_t accessRules = 0x60; // "ChatAccessRules"
            inline constexpr std::uintptr_t updater = 0x68; // "IUpdater"
            inline constexpr std::uintptr_t disposable = 0x70; // "IRegisterDisposable"
            inline constexpr std::uintptr_t wasCop = 0x78; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x962920; // "public void Update()"
            inline constexpr std::uintptr_t ResolveInChat = 0x961F00; // "private void ResolveInChat()"
        }
    } // namespace CopsChatUpdater

    namespace CreateClanMessage { // "Models.Messages.Clan.CreateClanMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t name = 0x20; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t tag = 0x28; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t enterType = 0x30; // "IPrimitiveData<ClanEnterTypeDescription>"
            inline constexpr std::uintptr_t language = 0x38; // "IPrimitiveData<ClanLanguageDescription>"
            inline constexpr std::uintptr_t emblem = 0x40; // "IPrimitiveData<ClanEmblemDescription>"
            inline constexpr std::uintptr_t description = 0x48; // "IPrimitiveData<string>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Name = 0x4A1B8D0; // "public string get_Name()"
            inline constexpr std::uintptr_t get_Tag = 0x4A1B920; // "public string get_Tag()"
            inline constexpr std::uintptr_t get_EnterType = 0x4A1B830; // "public ClanEnterTypeDescription get_EnterType()"
            inline constexpr std::uintptr_t get_Language = 0x4A1B880; // "public ClanLanguageDescription get_Language()"
            inline constexpr std::uintptr_t get_Emblem = 0x4A1B7E0; // "public ClanEmblemDescription get_Emblem()"
            inline constexpr std::uintptr_t get_Description = 0x4A1B790; // "public string get_Description()"
            inline constexpr std::uintptr_t get_Type = 0x4A1B970; // "public override string get_Type()"
        }
    } // namespace CreateClanMessage

    namespace CreateClanParamsModel { // "Models.Models.RegionUserClan.CreateClanParamsModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "RegionUserCreateClanData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_EnterType = 0x48D4830; // "public ClanEnterTypeDescription get_EnterType()"
            inline constexpr std::uintptr_t get_Language = 0x48D4900; // "public ClanLanguageDescription get_Language()"
            inline constexpr std::uintptr_t get_Emblem = 0x48D4760; // "public ClanEmblemDescription get_Emblem()"
            inline constexpr std::uintptr_t get_Description = 0x48D4710; // "public string get_Description()"
            inline constexpr std::uintptr_t Set = 0x48D4580; // "public void Set(ClanEnterTypeDescription enterType, ClanLanguageDescription language, ClanEmblemDescription emblem, string description)"
            inline constexpr std::uintptr_t Unset = 0x48D4660; // "public void Unset()"
        }
    } // namespace CreateClanParamsModel

    namespace DataChatMessageSource { // "Game.Global.Chat.DataChatMessageSource (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t chatMessagesData = 0x10; // "ChatMessagesData"
            inline constexpr std::uintptr_t blackListModel = 0x18; // "BlackListModel"
            inline constexpr std::uintptr_t chatSourceSettings = 0x20; // "ChatSourceSettings"
            inline constexpr std::uintptr_t badWordsFilter = 0x28; // "BadWordsFilterModel"
            inline constexpr std::uintptr_t now = 0x30; // "INow"
            inline constexpr std::uintptr_t authorColorRules = 0x38; // "IChatAuthorColorRule[]"
            inline constexpr std::uintptr_t gatherInitialMessages = 0x40; // "bool"
            inline constexpr std::uintptr_t isInited = 0x48; // "Func<bool>"
            inline constexpr std::uintptr_t capacity = 0x50; // "int"
            inline constexpr std::uintptr_t currentDataIndex = 0x54; // "int"
            inline constexpr std::uintptr_t sinceTs = 0x58; // "long"
            inline constexpr std::uintptr_t NewMessageAdded = 0x60; // "List<ChatMessageModel>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t InitializeIndex = 0x36D1790; // "private int InitializeIndex()"
            inline constexpr std::uintptr_t GetFirstDataIndex = 0x36D1600; // "private int GetFirstDataIndex()"
            inline constexpr std::uintptr_t Update = 0x36D22F0; // "public void Update()"
            inline constexpr std::uintptr_t PostMessagesInRange = 0x36D1C30; // "private void PostMessagesInRange(int fromIndex, int toIndex)"
            inline constexpr std::uintptr_t PostMessage = 0x36D1910; // "private void PostMessage(ChatMessageData messageData, bool useCurrentTime)"
            inline constexpr std::uintptr_t GetNextIndex = 0x36D1780; // "private int GetNextIndex(int index)"
            inline constexpr std::uintptr_t Clear = 0x36D15A0; // "public void Clear()"
            inline constexpr std::uintptr_t get_ShouldRaiseNotification = 0x7D5050; // "public bool get_ShouldRaiseNotification()"
        }
    } // namespace DataChatMessageSource

    namespace DataChatMessageSourceUpdater { // "Game.Global.Chat.DataChatMessageSourceUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t source = 0x10; // "IUpdatedChatMessageSource"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x36D1550; // "public void Update()"
        }
    } // namespace DataChatMessageSourceUpdater

    namespace DataPrivateChatMessageSource { // "Game.Global.Chat.DataPrivateChatMessageSource (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t chatMessagesData = 0x10; // "PrivateChatMessagesData"
            inline constexpr std::uintptr_t chatUsersData = 0x18; // "PrivateChatUsersData"
            inline constexpr std::uintptr_t chatSourceSettings = 0x20; // "ChatSourceSettings"
            inline constexpr std::uintptr_t badWordsFilter = 0x28; // "BadWordsFilterModel"
            inline constexpr std::uintptr_t authorColorRules = 0x30; // "IChatAuthorColorRule[]"
            inline constexpr std::uintptr_t now = 0x38; // "INow"
            inline constexpr std::uintptr_t sinceTs = 0x40; // "long"
            inline constexpr std::uintptr_t NewMessageAdded = 0x48; // "List<ChatMessageModel>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x36D2E00; // "public void Update()"
            inline constexpr std::uintptr_t CreateMessage = 0x36D2B20; // "private ChatMessageModel CreateMessage(PrivateChatMessageData messageData)"
            inline constexpr std::uintptr_t Clear = 0x36D2AC0; // "public void Clear()"
            inline constexpr std::uintptr_t get_ShouldRaiseNotification = 0x7D5050; // "public bool get_ShouldRaiseNotification()"
        }
    } // namespace DataPrivateChatMessageSource

    namespace DebugLayerPartyMembersUpdater { // "Game.Battle.EntityModel.Player.Debug.DebugLayerPartyMembersUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "BattlePartyMembersData"
            inline constexpr std::uintptr_t view = 0x18; // "DebugLayerPartyMembersView"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC70D40; // "public void Update()"
        }
    } // namespace DebugLayerPartyMembersUpdater

    namespace DeclineClanInviteMessage { // "Models.Messages.Clan.DeclineClanInviteMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t clanId = 0x20; // "IPrimitiveData<string>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_ClanId = 0x4A1C1B0; // "public string get_ClanId()"
            inline constexpr std::uintptr_t get_Type = 0x4A1C200; // "public override string get_Type()"
        }
    } // namespace DeclineClanInviteMessage

    namespace DeclinePartyMessage { // "Models.Messages.Party.DeclinePartyMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t partyId = 0x20; // "IPrimitiveData<string>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_PartyId = 0x4A05910; // "public string get_PartyId()"
            inline constexpr std::uintptr_t get_Type = 0x4A05960; // "public override string get_Type()"
        }
    } // namespace DeclinePartyMessage

    namespace DuplicateChatInGeneralUpdater { // "Game.Global.Chat.DuplicateChatInGeneralUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t chats = 0x10; // "ChatsModel"
            inline constexpr std::uintptr_t chatMessageSource = 0x18; // "IChatMessageSource"
            inline constexpr std::uintptr_t chatId = 0x20; // "SystemChatPreference"
            inline constexpr std::uintptr_t order = 0x24; // "int"
            inline constexpr std::uintptr_t wasDuplicating = 0x28; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x36D31F0; // "public void Update()"
        }
    } // namespace DuplicateChatInGeneralUpdater

    namespace EditClanInputActiveUpdater { // "Game.Global.Clan.ClanDialog.Updater.EditClanInputActiveUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t tabs = 0x10; // "TabData<ClanTabs>"
            inline constexpr std::uintptr_t activeWithTab = 0x18; // "ClanTabs"
            inline constexpr std::uintptr_t editAction = 0x20; // "InputAction"
            inline constexpr std::uintptr_t isVisible = 0x28; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x36C0BB0; // "public void Update()"
            inline constexpr std::uintptr_t SetVisible = 0x36C0B80; // "private void SetVisible(bool isVisible)"
        }
    } // namespace EditClanInputActiveUpdater

    namespace ExitClanBattlePrepareMessage { // "Models.Messages.ExitClanBattlePrepareMessage (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x4A06420; // "public override string get_Type()"
        }
    } // namespace ExitClanBattlePrepareMessage

    namespace FillChatsUpdater { // "Game.Global.Chat.FillChatsUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t chatsModel = 0x10; // "ChatsModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x36D33C0; // "public void Update()"
        }
    } // namespace FillChatsUpdater

    namespace GetAvailableForJoinClansMessage { // "Models.Messages.Clan.GetAvailableForJoinClansMessage (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x4A25060; // "public override string get_Type()"
        }
    } // namespace GetAvailableForJoinClansMessage

    namespace GetClanConquestSectorsMessage { // "Models.Messages.Clan.ClanBattle.GetClanConquestSectorsMessage (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x4A252A0; // "public override string get_Type()"
        }
    } // namespace GetClanConquestSectorsMessage

    namespace GetClanInfoMessage { // "Models.Messages.GetClanInfoMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t clanId = 0x20; // "IPrimitiveData<string>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_ClanId = 0x4A09380; // "public string get_ClanId()"
            inline constexpr std::uintptr_t get_Type = 0x4A093D0; // "public override string get_Type()"
        }
    } // namespace GetClanInfoMessage

    namespace GlobalChatsUpdater { // "Game.Global.Chat.GlobalChatsUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t globalModel = 0x10; // "GlobalModel"
            inline constexpr std::uintptr_t regionUserRoom = 0x18; // "IRoomConnection"
            inline constexpr std::uintptr_t globalScreenLoadedContent = 0x20; // "NotInstantiateLoadedContent<GlobalScreenContent>"
            inline constexpr std::uintptr_t receivedRequestsModel = 0x28; // "ReceivedRequestsModel"
            inline constexpr std::uintptr_t disposable = 0x30; // "IRegisterDisposable"
            inline constexpr std::uintptr_t updater = 0x38; // "IUpdater"
            inline constexpr std::uintptr_t isGlobalContentLoaded = 0x40; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x36D3640; // "public void Update()"
        }
    } // namespace GlobalChatsUpdater

    namespace GlobalNotificationModel_GlobalNotification_ClanBattlePhase { // "Game.Shared.Models.GlobalNotificationModel.GlobalNotification.ClanBattlePhase (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Text = 0x18; // "string"
            inline constexpr std::uintptr_t ColorText = 0x20; // "string"
            inline constexpr std::uintptr_t ActualityEndTs = 0x28; // "long"
            inline constexpr std::uintptr_t notificationType = 0x30; // "GlobalNotificationDescription.NotificationType"
        }
    } // namespace GlobalNotificationModel_GlobalNotification_ClanBattlePhase

    namespace GlobalNotificationModel_GlobalNotification_ClanShowdown { // "Game.Shared.Models.GlobalNotificationModel.GlobalNotification.ClanShowdown (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t AttackersCap = 0x18; // "int"
            inline constexpr std::uintptr_t DefendersCap = 0x1C; // "int"
            inline constexpr std::uintptr_t EndTs = 0x20; // "long"
        }
    } // namespace GlobalNotificationModel_GlobalNotification_ClanShowdown

    namespace GlobalNotificationModel_GlobalNotification_ObjectClanAppointment { // "Game.Shared.Models.GlobalNotificationModel.GlobalNotification.ObjectClanAppointment (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsWin = 0x18; // "bool"
            inline constexpr std::uintptr_t ConquestObject = 0x20; // "ClanConquestObjectTypeDescription"
        }
    } // namespace GlobalNotificationModel_GlobalNotification_ObjectClanAppointment

    namespace GlobalNotificationModel_GlobalNotification_ObjectClanBet { // "Game.Shared.Models.GlobalNotificationModel.GlobalNotification.ObjectClanBet (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsWin = 0x18; // "bool"
            inline constexpr std::uintptr_t ConquestObject = 0x20; // "ClanConquestObjectTypeDescription"
            inline constexpr std::uintptr_t AppointmentStartTs = 0x28; // "long"
        }
    } // namespace GlobalNotificationModel_GlobalNotification_ObjectClanBet

    namespace GlobalNotificationModel_GlobalNotification_SectorClanAppointment { // "Game.Shared.Models.GlobalNotificationModel.GlobalNotification.SectorClanAppointment (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsWin = 0x18; // "bool"
            inline constexpr std::uintptr_t ConquestSector = 0x20; // "SectorDescription"
        }
    } // namespace GlobalNotificationModel_GlobalNotification_SectorClanAppointment

    namespace GlobalNotificationModel_GlobalNotification_SectorClanBet { // "Game.Shared.Models.GlobalNotificationModel.GlobalNotification.SectorClanBet (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsWin = 0x18; // "bool"
            inline constexpr std::uintptr_t ConquestSector = 0x20; // "SectorDescription"
            inline constexpr std::uintptr_t AppointmentStartTs = 0x28; // "long"
        }
    } // namespace GlobalNotificationModel_GlobalNotification_SectorClanBet

    namespace InputFieldWithErrorView { // "Game.Global.Clan.ClanSettings.InputFieldWithErrorView (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t InputField = 0x20; // "InputFieldView"
            inline constexpr std::uintptr_t tip = 0x28; // "LocalizeStringEvent"
            inline constexpr std::uintptr_t state = 0x30; // "EnumStateElement<InputFieldWithErrorView.InputFieldState>"
            inline constexpr std::uintptr_t Placeholder = 0x38; // "LocalizeStringEvent"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetState = 0x3690240; // "public void SetState(InputFieldWithErrorView.InputFieldState state)"
            inline constexpr std::uintptr_t SetTip = 0x36902A0; // "public void SetTip(IText tip)"
            inline constexpr std::uintptr_t ClearInput = 0x3690220; // "public void ClearInput()"
        }
    } // namespace InputFieldWithErrorView

    namespace InputFieldWithLimitCounterView { // "Game.Global.Clan.ClanSettings.InputFieldWithLimitCounterView (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t InputField = 0x20; // "InputFieldView"
            inline constexpr std::uintptr_t characterCounter = 0x28; // "TextMeshProUGUI"
            inline constexpr std::uintptr_t characterLimit = 0x30; // "int"
            inline constexpr std::uintptr_t previousCount = 0x34; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x36903A0; // "private void Update()"
            inline constexpr std::uintptr_t SetCharacterLimit = 0x3690370; // "public void SetCharacterLimit(int value)"
        }
    } // namespace InputFieldWithLimitCounterView

    namespace InviteClanMessage { // "Models.Messages.Clan.InviteClanMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t publicId = 0x20; // "IPrimitiveData<long>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_PublicId = 0x4A2B6C0; // "public long get_PublicId()"
            inline constexpr std::uintptr_t get_Type = 0x4A2B710; // "public override string get_Type()"
        }
    } // namespace InviteClanMessage

    namespace InviteDeclinedNotificationUpdater { // "Game.Global.Party.InviteDeclinedNotificationUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t partyModel = 0x10; // "PartyModel"
            inline constexpr std::uintptr_t notificationModel = 0x18; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t partyLocalization = 0x20; // "PartyLocalization"
            inline constexpr std::uintptr_t cachedInvites = 0x28; // "Dictionary<long, string>"
            inline constexpr std::uintptr_t lastFramePartyState = 0x30; // "InviteDeclinedNotificationUpdater.PartyState"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x3799860; // "public void Update()"
            inline constexpr std::uintptr_t ShowDeclinedInviteNotifications = 0x37994F0; // "private void ShowDeclinedInviteNotifications()"
            inline constexpr std::uintptr_t ClearCachedInvites = 0x37994A0; // "private void ClearCachedInvites()"
            inline constexpr std::uintptr_t CacheActualInvites = 0x3799240; // "private void CacheActualInvites()"
        }
    } // namespace InviteDeclinedNotificationUpdater

    namespace InvitePartyMessage { // "Models.Messages.Party.InvitePartyMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t publicId = 0x20; // "IPrimitiveData<long>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_PublicId = 0x4A09BD0; // "public long get_PublicId()"
            inline constexpr std::uintptr_t get_Type = 0x4A09C20; // "public override string get_Type()"
        }
    } // namespace InvitePartyMessage

    namespace InviteToPartyIntentionModel { // "Game.Global.Party.InviteToPartyIntentionModel (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t PublicId = 0x10; // "long"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_HaveIntention = 0x3799B20; // "public bool get_HaveIntention()"
            inline constexpr std::uintptr_t Clear = 0x3799B10; // "public void Clear()"
        }
    } // namespace InviteToPartyIntentionModel

    namespace InviteToPartyIntentionUpdater { // "Game.Global.Party.InviteToPartyIntentionUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t inviteToPartyIntentionModel = 0x10; // "InviteToPartyIntentionModel"
            inline constexpr std::uintptr_t partyModel = 0x18; // "PartyModel"
            inline constexpr std::uintptr_t partyManagerDialogModel = 0x20; // "PartyManagerDialogModel"
            inline constexpr std::uintptr_t roomConnectionsRegionUser = 0x28; // "IRoomConnection"
            inline constexpr std::uintptr_t globalModelUISoundModel = 0x30; // "GlobalUISoundModel"
            inline constexpr std::uintptr_t personalNotificationModel = 0x38; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t partyLocalization = 0x40; // "PartyLocalization"
            inline constexpr std::uintptr_t realmBattleStateModel = 0x48; // "RealmBattleStateModel"
            inline constexpr std::uintptr_t publicIdModel = 0x50; // "PublicIdModel"
            inline constexpr std::uintptr_t delayedResponsesModel = 0x58; // "IDelayedResponsesModel"
            inline constexpr std::uintptr_t haveIntention = 0x60; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x3799E70; // "public void Update()"
            inline constexpr std::uintptr_t InviteToParty = 0x3799B30; // "private void InviteToParty()"
            inline constexpr std::uintptr_t ParseResponse = 0x3799BE0; // "private void ParseResponse(string value)"
            inline constexpr std::uintptr_t Notify = 0x356C870; // "private void Notify(LocalizedString localizedString)"
        }
    } // namespace InviteToPartyIntentionUpdater

    namespace JoinClanMessage { // "Models.Messages.Clan.JoinClanMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t clanId = 0x20; // "IPrimitiveData<string>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_ClanId = 0x4A2B8D0; // "public string get_ClanId()"
            inline constexpr std::uintptr_t get_Type = 0x4A2B920; // "public override string get_Type()"
        }
    } // namespace JoinClanMessage

    namespace KeyboardClanDialogView { // "Game.Global.Clan.ClanDialog.KeyboardClanDialogView (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t InputTextView = 0x98; // "InputTextView"
        }
    } // namespace KeyboardClanDialogView

    namespace KeyboardMouseClanInvitePopupView { // "Game.Global.Clan.ClanInvitePopup.KeyboardMouseClanInvitePopupView (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Popup = 0x20; // "ClanInvitePopupView"
            inline constexpr std::uintptr_t Confirm = 0x28; // "InputTextView"
            inline constexpr std::uintptr_t Decline = 0x30; // "InputTextView"
        }
    } // namespace KeyboardMouseClanInvitePopupView

    namespace KeyboardMouseClanRankDialogView { // "Game.Global.Clan.RankDialog.KeyboardMouseClanRankDialogView (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t View = 0x20; // "ClanRankDialogView"
            inline constexpr std::uintptr_t BackInput = 0x28; // "InputTextView"
        }
    } // namespace KeyboardMouseClanRankDialogView

    namespace KeyboardMouseClanSearchDialogView { // "Game.Global.Clan.ClanSearch.KeyboardMouseClanSearchDialogView (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t BackInput = 0x98; // "InputTextView"
        }
    } // namespace KeyboardMouseClanSearchDialogView

    namespace KickClanMessage { // "Models.Messages.Clan.KickClanMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t publicId = 0x20; // "IPrimitiveData<long>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_PublicId = 0x4A2BAE0; // "public long get_PublicId()"
            inline constexpr std::uintptr_t get_Type = 0x4A2BB30; // "public override string get_Type()"
        }
    } // namespace KickClanMessage

    namespace KickFromPartyMessage { // "Models.Messages.Party.KickFromPartyMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t publicId = 0x20; // "IPrimitiveData<long>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_PublicId = 0x4A09FF0; // "public long get_PublicId()"
            inline constexpr std::uintptr_t get_Type = 0x4A0A040; // "public override string get_Type()"
        }
    } // namespace KickFromPartyMessage

    namespace KickMemberClanBattleMessage { // "Models.Messages.Clan.ClanBattle.KickMemberClanBattleMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t entityId = 0x20; // "IPrimitiveData<int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_EntityId = 0x4A2BCF0; // "public int get_EntityId()"
            inline constexpr std::uintptr_t get_Type = 0x4A2BD40; // "public override string get_Type()"
        }
    } // namespace KickMemberClanBattleMessage

    namespace LeaveClanMessage { // "Models.Messages.Clan.LeaveClanMessage (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x4A2CC90; // "public override string get_Type()"
        }
    } // namespace LeaveClanMessage

    namespace LeavePartyMessage { // "Models.Messages.Party.LeavePartyMessage (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x4A0A2B0; // "public override string get_Type()"
        }
    } // namespace LeavePartyMessage

    namespace MailAttachmentItemData { // "Models.Data.Mail.MailAttachmentItemData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Item = 0x20; // "IPrimitiveData<InventoryItemDescription>"
            inline constexpr std::uintptr_t Amount = 0x28; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t ClaimedAmount = 0x30; // "IPrimitiveData<int>"
        }
    } // namespace MailAttachmentItemData

    namespace MailAttachmentItemsModel { // "Models.Models.Mail.MailAttachmentItemsModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "IListData<MailAttachmentItemData>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Count = 0x4944480; // "public int get_Count()"
            inline constexpr std::uintptr_t GetItem = 0x4944020; // "public InventoryItemDescription GetItem(int index)"
            inline constexpr std::uintptr_t GetAmount = 0x4943F20; // "public int GetAmount(int index)"
            inline constexpr std::uintptr_t GetClaimedAmount = 0x4943FA0; // "public int GetClaimedAmount(int index)"
            inline constexpr std::uintptr_t IsClaimed = 0x49440A0; // "public bool IsClaimed(int index)"
            inline constexpr std::uintptr_t Set = 0x4944140; // "public void Set(List<ValueTuple<InventoryItemDescription, int>> items)"
            inline constexpr std::uintptr_t Claim = 0x4943E70; // "public void Claim(int index, int amount)"
        }
    } // namespace MailAttachmentItemsModel

    namespace MailAttachmentOwnedSkins { // "Models.Models.Mail.MailAttachmentOwnedSkins (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Bodies = 0x10; // "IOwnedItemsModel<CharacterBodyDescription>"
            inline constexpr std::uintptr_t FBodies = 0x18; // "IOwnedItemsModel<CharacterFBodyDescription>"
            inline constexpr std::uintptr_t Bags = 0x20; // "IOwnedItemsModel<CharacterBagDescription>"
            inline constexpr std::uintptr_t Masks = 0x28; // "IOwnedItemsModel<CharacterMaskDescription>"
            inline constexpr std::uintptr_t Keychains = 0x30; // "IOwnedItemsModel<CharacterKeychainDescription>"
            inline constexpr std::uintptr_t Cars = 0x38; // "IOwnedItemsModel<CarDescription>"
            inline constexpr std::uintptr_t Helicopters = 0x40; // "IOwnedItemsModel<HelicopterDescription>"
            inline constexpr std::uintptr_t WeaponSkins = 0x48; // "IOwnedItemsModel<WeaponSkinDescription>"
        }
    } // namespace MailAttachmentOwnedSkins

    namespace MailAttachments { // "Models.Models.Mail.MailAttachments (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t CryptoCoinsAmount = 0x10; // "int"
            inline constexpr std::uintptr_t CoinsAmount = 0x14; // "int"
            inline constexpr std::uintptr_t CashAmount = 0x18; // "int"
            inline constexpr std::uintptr_t Bodies = 0x20; // "HashSet<CharacterBodyDescription>"
            inline constexpr std::uintptr_t FBodies = 0x28; // "HashSet<CharacterFBodyDescription>"
            inline constexpr std::uintptr_t Bags = 0x30; // "HashSet<CharacterBagDescription>"
            inline constexpr std::uintptr_t Masks = 0x38; // "HashSet<CharacterMaskDescription>"
            inline constexpr std::uintptr_t Keychains = 0x40; // "HashSet<CharacterKeychainDescription>"
            inline constexpr std::uintptr_t Cars = 0x48; // "HashSet<CarDescription>"
            inline constexpr std::uintptr_t Helicopters = 0x50; // "HashSet<HelicopterDescription>"
            inline constexpr std::uintptr_t WeaponSkins = 0x58; // "HashSet<WeaponSkinDescription>"
            inline constexpr std::uintptr_t Items = 0x60; // "List<ValueTuple<InventoryItemDescription, int>>"
        }
    } // namespace MailAttachments

    namespace MailAttachmentsData { // "Models.Data.Mail.MailAttachmentsData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t CryptoCoinsAmount = 0x20; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t CoinsAmount = 0x28; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t CashAmount = 0x30; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t Bodies = 0x38; // "SetData<CharacterBodyDescription>"
            inline constexpr std::uintptr_t FBodies = 0x40; // "SetData<CharacterFBodyDescription>"
            inline constexpr std::uintptr_t Bags = 0x48; // "SetData<CharacterBagDescription>"
            inline constexpr std::uintptr_t Masks = 0x50; // "SetData<CharacterMaskDescription>"
            inline constexpr std::uintptr_t Keychains = 0x58; // "SetData<CharacterKeychainDescription>"
            inline constexpr std::uintptr_t Cars = 0x60; // "SetData<CarDescription>"
            inline constexpr std::uintptr_t Helicopters = 0x68; // "SetData<HelicopterDescription>"
            inline constexpr std::uintptr_t WeaponSkins = 0x70; // "SetData<WeaponSkinDescription>"
            inline constexpr std::uintptr_t Items = 0x78; // "ListData<ItemToSendData>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t BuildSkinsSetData_T_inst_1 = 0x1711200; // "MailAttachmentsData.BuildSkinsSetData<object>"
        }
    } // namespace MailAttachmentsData

    namespace MailAttachmentsDataExtension { // "Models.Utils.Extensions.MailAttachmentsDataExtension (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t Set = 0x3960CE0; // "public static void Set(MailAttachmentsData data, MailAttachments attachments)"
            inline constexpr std::uintptr_t ToMailAttachments = 0x3961550; // "public static MailAttachments ToMailAttachments(MailAttachmentsData data)"
            inline constexpr std::uintptr_t AddValuesToSet_T_inst_1 = 0x1710FC0; // "MailAttachmentsDataExtension.AddValuesToSet<object>"
            inline constexpr std::uintptr_t AddValuesToSet_T_inst_2 = 0x1710CC0; // "MailAttachmentsDataExtension.AddValuesToSet<__Il2CppFullySharedGenericType>"
            inline constexpr std::uintptr_t ToSet_T_inst_1 = 0x1711190; // "MailAttachmentsDataExtension.ToSet<object>"
            inline constexpr std::uintptr_t ToSet_T_inst_2 = 0x1578190; // "MailAttachmentsDataExtension.ToSet<__Il2CppFullySharedGenericType>"
            inline constexpr std::uintptr_t ToItemsList = 0x3961120; // "private static List<ValueTuple<InventoryItemDescription, int>> ToItemsList(IListData<ItemToSendData> items)"
        }
    } // namespace MailAttachmentsDataExtension

    namespace MailAttachmentsExtensions { // "Models.Utils.Extensions.MailAttachmentsExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t AppendToStringBuilder = 0x39617F0; // "public static void AppendToStringBuilder(MailAttachments attachments, StringBuilder builder)"
            inline constexpr std::uintptr_t AppendSkins_T_inst_1 = 0x1711730; // "MailAttachmentsExtensions.AppendSkins<object>"
            inline constexpr std::uintptr_t AppendSkins_T_inst_2 = 0x1711300; // "MailAttachmentsExtensions.AppendSkins<__Il2CppFullySharedGenericType>"
        }
    } // namespace MailAttachmentsExtensions

    namespace MailboxData { // "Models.Data.Mail.MailboxData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Index = 0x20; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t Mails = 0x28; // "DictionaryData<int, MailData>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Clear = 0x4AAE330; // "public void Clear()"
        }
    } // namespace MailboxData

    namespace MailboxModel { // "Models.Models.Mail.MailboxModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t indexData = 0x10; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t mailsData = 0x18; // "IDictionaryData<int, MailData>"
            inline constexpr std::uintptr_t lastChangeTs = 0x20; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t mailsByKey = 0x28; // "Dictionary<int, MailModel>"
            inline constexpr std::uintptr_t toRemove = 0x30; // "List<int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t UpdateModelsAfterDataUpdate = 0x4945630; // "public void UpdateModelsAfterDataUpdate()"
            inline constexpr std::uintptr_t get_Count = 0x4945D90; // "public int get_Count()"
            inline constexpr std::uintptr_t get_LastChangeTs = 0x4945DE0; // "public long get_LastChangeTs()"
            inline constexpr std::uintptr_t TryGet = 0x49455C0; // "public bool TryGet(int id, out MailModel mailModel)"
            inline constexpr std::uintptr_t Add = 0x4945040; // "public void Add(MailDescription description, long now, MailAttachments attachments)"
            inline constexpr std::uintptr_t Remove = 0x49453A0; // "public void Remove(int key, long now)"
            inline constexpr std::uintptr_t Clear = 0x4945240; // "public void Clear(long now)"
            inline constexpr std::uintptr_t GetEnumerator = 0x4945310; // "public Dictionary.ValueCollection.Enumerator<int, MailModel> GetEnumerator()"
            inline constexpr std::uintptr_t System_Collections_Generic_IEnumerable_Models_Models_Mail_MailModel_GetEnumerator = 0x4945460; // "private IEnumerator<MailModel> System.Collections.Generic.IEnumerable<Models.Models.Mail.MailModel>.GetEnumerator()"
            inline constexpr std::uintptr_t System_Collections_IEnumerable_GetEnumerator = 0x4945510; // "private IEnumerator System.Collections.IEnumerable.GetEnumerator()"
        }
    } // namespace MailboxModel

    namespace MailboxModelUpdater { // "Game.Global.Mail.Updaters.MailboxModelUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t mailboxModel = 0x10; // "MailboxModel"
            inline constexpr std::uintptr_t lastChangeTs = 0x18; // "long"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x35A5960; // "public void Update()"
            inline constexpr std::uintptr_t Refresh = 0x35A5920; // "private void Refresh()"
        }
    } // namespace MailboxModelUpdater

    namespace MailClaimItemAttachmentCommand { // "Models.Messages.Mail.MailClaimItemAttachmentCommand (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsCash = 0x0; // "bool"
            inline constexpr std::uintptr_t ItemIndex = 0x4; // "int"
            inline constexpr std::uintptr_t Type = 0x8; // "InventoryTakeCommandTypeDescription"
            inline constexpr std::uintptr_t SlotIndex = 0x10; // "int"
            inline constexpr std::uintptr_t Count = 0x14; // "int"
        }
    } // namespace MailClaimItemAttachmentCommand

    namespace MailClaimItemAttachmentCommandData { // "Models.Messages.Mail.MailClaimItemAttachmentCommandData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t isCash = 0x20; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t itemIndex = 0x28; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t type = 0x30; // "IPrimitiveData<InventoryTakeCommandTypeDescription>"
            inline constexpr std::uintptr_t slotIndex = 0x38; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t count = 0x40; // "IPrimitiveData<int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Set = 0x4A0A4E0; // "public void Set(MailClaimItemAttachmentCommand command)"
            inline constexpr std::uintptr_t Get = 0x4A0A340; // "public MailClaimItemAttachmentCommand Get()"
        }
    } // namespace MailClaimItemAttachmentCommandData

    namespace MailConfig { // "Models.References.Mail.MailConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t MaxMailsCount = 0x10; // "int"
            inline constexpr std::uintptr_t MaxAttachmentBodiesCount = 0x14; // "int"
            inline constexpr std::uintptr_t MaxAttachmentFBodiesCount = 0x18; // "int"
            inline constexpr std::uintptr_t MaxAttachmentBagsCount = 0x1C; // "int"
            inline constexpr std::uintptr_t MaxAttachmentMasksCount = 0x20; // "int"
            inline constexpr std::uintptr_t MaxAttachmentKeychainsCount = 0x24; // "int"
            inline constexpr std::uintptr_t MaxAttachmentCarsCount = 0x28; // "int"
            inline constexpr std::uintptr_t MaxAttachmentHelicoptersCount = 0x2C; // "int"
            inline constexpr std::uintptr_t MaxAttachmentWeaponSkinsCount = 0x30; // "int"
            inline constexpr std::uintptr_t MaxAttachmentItemsCount = 0x34; // "int"
        }
    } // namespace MailConfig

    namespace MailData { // "Models.Data.Mail.MailData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Description = 0x20; // "IPrimitiveData<MailDescription>"
            inline constexpr std::uintptr_t ReceivedTs = 0x28; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t IsRead = 0x30; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t IsCoinsClaimed = 0x38; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t IsCryptoCoinsClaimed = 0x40; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t CryptoCoinsAmount = 0x48; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t CoinsAmount = 0x50; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t CashAmount = 0x58; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t ClaimedCashAmount = 0x60; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t Bodies = 0x68; // "SetData<CharacterBodyDescription>"
            inline constexpr std::uintptr_t FBodies = 0x70; // "SetData<CharacterFBodyDescription>"
            inline constexpr std::uintptr_t Bags = 0x78; // "SetData<CharacterBagDescription>"
            inline constexpr std::uintptr_t Masks = 0x80; // "SetData<CharacterMaskDescription>"
            inline constexpr std::uintptr_t Keychains = 0x88; // "SetData<CharacterKeychainDescription>"
            inline constexpr std::uintptr_t Cars = 0x90; // "SetData<CarDescription>"
            inline constexpr std::uintptr_t Helicopters = 0x98; // "SetData<HelicopterDescription>"
            inline constexpr std::uintptr_t WeaponSkins = 0xA0; // "SetData<WeaponSkinDescription>"
            inline constexpr std::uintptr_t Items = 0xA8; // "ListData<MailAttachmentItemData>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t BuildSkinsSetData_T_inst_1 = 0x1711200; // "MailData.BuildSkinsSetData<object>"
        }
    } // namespace MailData

    namespace MailDescription { // "Models.References.Mail.MailDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsRealm = 0x20; // "bool"
            inline constexpr std::uintptr_t ExpirationTime = 0x28; // "long"
            inline constexpr std::uintptr_t IsPurchase = 0x30; // "bool"
        }
    } // namespace MailDescription

    namespace MailExtensions { // "Models.Utils.Extensions.MailExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t CanBeClaimed = 0x3961C00; // "public static bool CanBeClaimed(MailModel mailModel, MailAttachmentOwnedSkins ownedSkins)"
            inline constexpr std::uintptr_t HasUnreadOrUnclaimedMail = 0x3962550; // "public static bool HasUnreadOrUnclaimedMail(MailboxModel mailboxModel, MailAttachmentOwnedSkins ownedSkins)"
            inline constexpr std::uintptr_t CanClaimCoins = 0x3961E70; // "public static bool CanClaimCoins(MailModel mailModel)"
            inline constexpr std::uintptr_t CanClaimCryptoCoins = 0x3961EB0; // "public static bool CanClaimCryptoCoins(MailModel mailModel)"
            inline constexpr std::uintptr_t IsCoinsBlockedByBankAccount = 0x3962700; // "public static bool IsCoinsBlockedByBankAccount(MailModel mailModel, bool hasBankAccount)"
            inline constexpr std::uintptr_t CanClaimSkins = 0x3961F60; // "public static bool CanClaimSkins(MailModel mailModel, MailAttachmentOwnedSkins ownedSkins)"
            inline constexpr std::uintptr_t HasUnclaimedSkin_T_inst_1 = 0x1712340; // "MailExtensions.HasUnclaimedSkin<object>"
            inline constexpr std::uintptr_t HasUnclaimedSkin_T_inst_2 = 0x1712030; // "MailExtensions.HasUnclaimedSkin<__Il2CppFullySharedGenericType>"
            inline constexpr std::uintptr_t CanClaimCash = 0x3961E30; // "public static bool CanClaimCash(MailModel mailModel)"
            inline constexpr std::uintptr_t CanClaimItems = 0x3961EF0; // "public static bool CanClaimItems(MailModel mailModel)"
            inline constexpr std::uintptr_t ClaimCryptoCoins = 0x3962130; // "public static void ClaimCryptoCoins(CoinsModel cryptoCoinsModel, MailModel mailModel)"
            inline constexpr std::uintptr_t ClaimCoins = 0x39620E0; // "public static void ClaimCoins(CoinsModel coinsModel, MailModel mailModel)"
            inline constexpr std::uintptr_t ClaimSkins = 0x3962180; // "public static List<IEnumItem> ClaimSkins(MailAttachmentOwnedSkins ownedSkins, MailModel mailModel)"
            inline constexpr std::uintptr_t ClaimSkins_T_inst_1 = 0x1711D40; // "MailExtensions.ClaimSkins<object>"
            inline constexpr std::uintptr_t ClaimSkins_T_inst_2 = 0x17119B0; // "MailExtensions.ClaimSkins<__Il2CppFullySharedGenericType>"
            inline constexpr std::uintptr_t HasUnclaimedRealmMail = 0x39623E0; // "public static bool HasUnclaimedRealmMail(MailboxModel mailboxModel, MailAttachmentOwnedSkins ownedSkins)"
            inline constexpr std::uintptr_t HasInventoryItemAttachments = 0x3962390; // "public static bool HasInventoryItemAttachments(MailModel mailModel)"
            inline constexpr std::uintptr_t IsClaimAttachmentsAvailable = 0x39626B0; // "public static bool IsClaimAttachmentsAvailable(BattleCharacterModel battleCharacterModel)"
            inline constexpr std::uintptr_t HasExpirationTime = 0x3962370; // "public static bool HasExpirationTime(MailDescription mailDescription)"
            inline constexpr std::uintptr_t GetExpirationTs = 0x3962320; // "public static long GetExpirationTs(MailModel mailModel)"
            inline constexpr std::uintptr_t IsExpired = 0x3962760; // "public static bool IsExpired(MailModel mailModel, long now)"
        }
    } // namespace MailExtensions

    namespace MailIndicationModel { // "Game.Global.Mail.Models.MailIndicationModel (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t HasNewMail = 0x10; // "bool"
        }
    } // namespace MailIndicationModel

    namespace MailIndicationModelUpdater { // "Game.Global.Mail.Updaters.MailIndicationModelUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t mailboxModel = 0x10; // "MailboxModel"
            inline constexpr std::uintptr_t skinCenterModelProvider = 0x18; // "Func<SkinCenterModel>"
            inline constexpr std::uintptr_t indicationModel = 0x20; // "MailIndicationModel"
            inline constexpr std::uintptr_t ownedSkins = 0x28; // "MailAttachmentOwnedSkins"
            inline constexpr std::uintptr_t wasMailboxChangeTs = 0x30; // "long"
            inline constexpr std::uintptr_t framesUntilMailRecheck = 0x38; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x35A11E0; // "public void Update()"
            inline constexpr std::uintptr_t TryGetOwnedSkins = 0x35A1050; // "private bool TryGetOwnedSkins(out MailAttachmentOwnedSkins ownedSkins)"
        }
    } // namespace MailIndicationModelUpdater

    namespace MailItemContext_BagSkin { // "Game.Global.Mail.Models.MailItemContext.BagSkin (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Description = 0x10; // "CharacterBagDescription"
        }
    } // namespace MailItemContext_BagSkin

    namespace MailItemContext_BodySkin { // "Game.Global.Mail.Models.MailItemContext.BodySkin (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Description = 0x10; // "CharacterBodyDescription"
        }
    } // namespace MailItemContext_BodySkin

    namespace MailItemContext_Cash { // "Game.Global.Mail.Models.MailItemContext.Cash (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t mailModel = 0x10; // "MailModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Amount = 0x35935E0; // "public int get_Amount()"
            inline constexpr std::uintptr_t get_ClaimedAmount = 0x3593600; // "public int get_ClaimedAmount()"
        }
    } // namespace MailItemContext_Cash

    namespace MailItemContext_Coins { // "Game.Global.Mail.Models.MailItemContext.Coins (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t mailModel = 0x10; // "MailModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Amount = 0x3593B00; // "public int get_Amount()"
            inline constexpr std::uintptr_t get_IsClaimed = 0x3593B70; // "public bool get_IsClaimed()"
        }
    } // namespace MailItemContext_Coins

    namespace MailItemContext_Crypto { // "Game.Global.Mail.Models.MailItemContext.Crypto (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t mailModel = 0x10; // "MailModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Amount = 0x3594020; // "public int get_Amount()"
            inline constexpr std::uintptr_t get_IsClaimed = 0x3594090; // "public bool get_IsClaimed()"
        }
    } // namespace MailItemContext_Crypto

    namespace MailItemContext_FBodySkin { // "Game.Global.Mail.Models.MailItemContext.FBodySkin (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Description = 0x10; // "CharacterFBodyDescription"
        }
    } // namespace MailItemContext_FBodySkin

    namespace MailItemContext_Item { // "Game.Global.Mail.Models.MailItemContext.Item (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t itemsModel = 0x10; // "MailAttachmentItemsModel"
            inline constexpr std::uintptr_t index = 0x18; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Description = 0x3596CE0; // "public InventoryItemDescription get_Description()"
            inline constexpr std::uintptr_t get_Amount = 0x3596C80; // "public int get_Amount()"
            inline constexpr std::uintptr_t get_ClaimedAmount = 0x3596CB0; // "public int get_ClaimedAmount()"
        }
    } // namespace MailItemContext_Item

    namespace MailItemContext_KeychainSkin { // "Game.Global.Mail.Models.MailItemContext.KeychainSkin (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Description = 0x10; // "CharacterKeychainDescription"
        }
    } // namespace MailItemContext_KeychainSkin

    namespace MailItemContext_MaskSkin { // "Game.Global.Mail.Models.MailItemContext.MaskSkin (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Description = 0x10; // "CharacterMaskDescription"
        }
    } // namespace MailItemContext_MaskSkin

    namespace MailItemContextUtils { // "Game.Global.Mail.Models.MailItemContextUtils (Global.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t BuildCashContexts = 0x35A26B0; // "public static List<MailItemContext> BuildCashContexts(List<MailItemContext> contexts, MailModel mail, int listCapacity)"
            inline constexpr std::uintptr_t BuildItemsContexts = 0x35A29E0; // "public static List<MailItemContext> BuildItemsContexts(List<MailItemContext> contexts, MailModel mail, int listCapacity)"
            inline constexpr std::uintptr_t BuildSkinsContexts = 0x35A2D30; // "public static List<MailItemContext> BuildSkinsContexts(List<MailItemContext> contexts, MailModel mail, int listCapacity)"
            inline constexpr std::uintptr_t GetIcon = 0x35A3EE0; // "public static Sprite GetIcon(MailItemContext context, SkinCenterModel skinCenterModel, GlobalScreenContent globalScreenContent)"
            inline constexpr std::uintptr_t GetIconColor = 0x35A3C80; // "public static PaletteColor GetIconColor(MailItemContext context, MailViewDescriptions mailViewDescriptions)"
            inline constexpr std::uintptr_t GetRarity = 0x35A4BA0; // "public static RarityItem GetRarity(MailItemContext context, SkinCenterModel skinCenterModel, GlobalScreenContent globalScreenContent)"
            inline constexpr std::uintptr_t ComputeClaimedMask = 0x35A3920; // "public static ulong ComputeClaimedMask(List<MailItemContext> contexts, SkinCenterModel skinCenterModel)"
            inline constexpr std::uintptr_t GetIsClaimed = 0x35A4230; // "public static bool GetIsClaimed(MailItemContext context, SkinCenterModel skinCenterModel)"
            inline constexpr std::uintptr_t GetItemSize = 0x35A4960; // "public static MailDialogItemView.SizeState GetItemSize(MailItemContext context)"
            inline constexpr std::uintptr_t GetIconSize = 0x35A3D90; // "public static MailDialogItemView.IconSizeState GetIconSize(MailItemContext context)"
            inline constexpr std::uintptr_t GetCurrencyTooltipContext = 0x35A39D0; // "public static ITooltipContext GetCurrencyTooltipContext(MailItemContext context, GlobalScreenContent globalScreenContent)"
            inline constexpr std::uintptr_t GetItemTooltipContext = 0x35A4AB0; // "public static ITooltipContext GetItemTooltipContext(MailItemContext context, SkinCenterModel skinCenterModel, GlobalScreenContent globalScreenContent)"
            inline constexpr std::uintptr_t BuildCashTooltipContext = 0x35A2850; // "private static ITooltipContext BuildCashTooltipContext(GlobalScreenContent globalScreenContent)"
            inline constexpr std::uintptr_t BuildCurrencyTooltipContext = 0x35A2970; // "private static ITooltipContext BuildCurrencyTooltipContext(MailCurrencyTooltipDescription tooltip, RarityItem rarity)"
            inline constexpr std::uintptr_t BuildSkinTooltipContext = 0x35A2B40; // "private static ITooltipContext BuildSkinTooltipContext(MailItemContext context, SkinCenterModel skinCenterModel, GlobalScreenContent globalScreenContent)"
            inline constexpr std::uintptr_t GetSkinCell = 0x35A4E40; // "private static ISkinCenterCellViewDescription GetSkinCell(MailItemContext context, SkinCenterModel skinCenterModel, GlobalScreenContent globalScreenContent)"
        }
    } // namespace MailItemContextUtils

    namespace MailModel { // "Models.Models.Mail.MailModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "MailData"
            inline constexpr std::uintptr_t Id = 0x18; // "int"
            inline constexpr std::uintptr_t Bodies = 0x20; // "MailAttachmentSkinsModel<CharacterBodyDescription>"
            inline constexpr std::uintptr_t FBodies = 0x28; // "MailAttachmentSkinsModel<CharacterFBodyDescription>"
            inline constexpr std::uintptr_t Bags = 0x30; // "MailAttachmentSkinsModel<CharacterBagDescription>"
            inline constexpr std::uintptr_t Masks = 0x38; // "MailAttachmentSkinsModel<CharacterMaskDescription>"
            inline constexpr std::uintptr_t Keychains = 0x40; // "MailAttachmentSkinsModel<CharacterKeychainDescription>"
            inline constexpr std::uintptr_t Cars = 0x48; // "MailAttachmentSkinsModel<CarDescription>"
            inline constexpr std::uintptr_t Helicopters = 0x50; // "MailAttachmentSkinsModel<HelicopterDescription>"
            inline constexpr std::uintptr_t WeaponSkins = 0x58; // "MailAttachmentSkinsModel<WeaponSkinDescription>"
            inline constexpr std::uintptr_t Items = 0x60; // "MailAttachmentItemsModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Description = 0x4944E30; // "public MailDescription get_Description()"
            inline constexpr std::uintptr_t get_ReceivedTs = 0x4944FF0; // "public long get_ReceivedTs()"
            inline constexpr std::uintptr_t get_IsRead = 0x4944FA0; // "public bool get_IsRead()"
            inline constexpr std::uintptr_t get_IsCoinsClaimed = 0x4944F00; // "public bool get_IsCoinsClaimed()"
            inline constexpr std::uintptr_t get_IsCryptoCoinsClaimed = 0x4944F50; // "public bool get_IsCryptoCoinsClaimed()"
            inline constexpr std::uintptr_t get_CryptoCoinsAmount = 0x4944DE0; // "public int get_CryptoCoinsAmount()"
            inline constexpr std::uintptr_t get_CoinsAmount = 0x4944D90; // "public int get_CoinsAmount()"
            inline constexpr std::uintptr_t get_CashAmount = 0x4944CF0; // "public int get_CashAmount()"
            inline constexpr std::uintptr_t get_ClaimedCashAmount = 0x4944D40; // "public int get_ClaimedCashAmount()"
            inline constexpr std::uintptr_t Set = 0x4944670; // "public void Set(MailDescription description, long receivedTs, MailAttachments attachments)"
            inline constexpr std::uintptr_t MarkRead = 0x4944610; // "public void MarkRead()"
            inline constexpr std::uintptr_t MarkCoinsClaimed = 0x4944550; // "public void MarkCoinsClaimed()"
            inline constexpr std::uintptr_t MarkCryptoCoinsClaimed = 0x49445B0; // "public void MarkCryptoCoinsClaimed()"
            inline constexpr std::uintptr_t ClaimCash = 0x49444D0; // "public void ClaimCash(int amount)"
        }
    } // namespace MailModel

    namespace MailUpdater { // "Game.Battle.Mail.MailUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t indicationModel = 0x10; // "MailIndicationModel"
            inline constexpr std::uintptr_t mailContainer = 0x18; // "GameObject"
            inline constexpr std::uintptr_t isContainerActive = 0x20; // "Nullable<bool>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x9B2BD0; // "public void Update()"
        }
    } // namespace MailUpdater

    namespace MarkMailReadMessage { // "Models.Messages.Mail.MarkMailReadMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t mailId = 0x20; // "IPrimitiveData<int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_MailId = 0x4A0AFB0; // "public int get_MailId()"
            inline constexpr std::uintptr_t get_Type = 0x4A0B000; // "public override string get_Type()"
        }
    } // namespace MarkMailReadMessage

    namespace MiniChatActiveUpdater { // "Game.Global.Chat.MiniChatActiveUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t chatsModel = 0x10; // "ChatsModel"
            inline constexpr std::uintptr_t partyModel = 0x18; // "PartyModel"
            inline constexpr std::uintptr_t chatHudView = 0x20; // "ChatHudView"
            inline constexpr std::uintptr_t hasState = 0x28; // "bool"
            inline constexpr std::uintptr_t chatDialogModel = 0x30; // "ChatDialogModel"
            inline constexpr std::uintptr_t showMiniChat = 0x38; // "bool"
            inline constexpr std::uintptr_t membersCount = 0x3C; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x36D3C90; // "public void Update()"
        }
    } // namespace MiniChatActiveUpdater

    namespace MiniChatMessageListUpdater { // "Game.Global.Chat.MiniChatMessageListUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t chatDialog = 0x10; // "ChatDialogModel"
            inline constexpr std::uintptr_t view = 0x18; // "MiniChatView"
            inline constexpr std::uintptr_t template_id = 0x20; // "IComponentInstantiateContent<ChatMessageView>"
            inline constexpr std::uintptr_t chatViewDescription = 0x28; // "ChatViewDescription"
            inline constexpr std::uintptr_t wasSelected = 0x30; // "ChatChannelModel"
            inline constexpr std::uintptr_t container = 0x38; // "List<ChatMessageModel>"
            inline constexpr std::uintptr_t drawnMessages = 0x40; // "SlidingList<IDisposableContent<ChatMessageView>>"
            inline constexpr std::uintptr_t chatMessageBuildRules = 0x48; // "ChatMessageBuildRules"
            inline constexpr std::uintptr_t capacity = 0x50; // "int"
            inline constexpr std::uintptr_t wasVisible = 0x54; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Clear = 0x36D3F00; // "private void Clear()"
            inline constexpr std::uintptr_t PrintMessage = 0x36D4060; // "private IDisposableContent<ChatMessageView> PrintMessage(ChatMessageModel message)"
            inline constexpr std::uintptr_t Update = 0x36D49F0; // "public void Update()"
            inline constexpr std::uintptr_t Relocate = 0x36D4470; // "private void Relocate()"
            inline constexpr std::uintptr_t SetupNew = 0x36D48B0; // "private void SetupNew()"
        }
    } // namespace MiniChatMessageListUpdater

    namespace MiniChatView { // "Game.Global.Chat.MiniChatView (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Parent = 0x20; // "RectTransform"
            inline constexpr std::uintptr_t Viewport = 0x28; // "RectTransform"
            inline constexpr std::uintptr_t Spacing = 0x30; // "float"
            inline constexpr std::uintptr_t MinRequiredGap = 0x34; // "float"
        }
    } // namespace MiniChatView

    namespace OnlineStatusView { // "Game.Global.Clan.OnlineStatusView (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t isOnline = 0x20; // "StateGroup"
            inline constexpr std::uintptr_t onlineLocationDefaultName = 0x28; // "TextMeshProUGUI"
            inline constexpr std::uintptr_t onlineLocation = 0x30; // "TextMeshProUGUI"
            inline constexpr std::uintptr_t offlineStatus = 0x38; // "TextLabel<int, int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetOnLocation = 0x3690630; // "public void SetOnLocation(LocalizedString currentLocationName)"
            inline constexpr std::uintptr_t SetOnSettlement = 0x36906F0; // "public void SetOnSettlement(string settlementName, LocalizedString currentLocationName, string suffix)"
            inline constexpr std::uintptr_t SetOffline = 0x36904C0; // "public void SetOffline(TimeSpan timeSpan)"
            inline constexpr std::uintptr_t SetOffline_2 = 0x3690430; // "private void SetOffline(int time, TimeStatus timeStatus)"
            inline constexpr std::uintptr_t SetOnlineState = 0x35B43D0; // "private void SetOnlineState(bool isOnline)"
        }
    } // namespace OnlineStatusView

    namespace OpenClanDialogAfterCreatingUpdater { // "Game.Global.Clan.ClanDialog.OpenClanDialogAfterCreatingUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dialogModel = 0x10; // "ClanDialogModel"
            inline constexpr std::uintptr_t clanModel = 0x18; // "ClanModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x36AB390; // "public void Update()"
        }
    } // namespace OpenClanDialogAfterCreatingUpdater

    namespace OwnedClanConquestObjectsModel { // "Models.Models.OwnedClanConquestItemsModel.OwnedClanConquestObjectsModel (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t GetClanBattleStartOffsetIndex = 0x4915C70; // "public override int GetClanBattleStartOffsetIndex(ClanConquestObjectTypeDescription description)"
            inline constexpr std::uintptr_t ChangeClanBattleStartOffsetIndex = 0x4915BE0; // "public override void ChangeClanBattleStartOffsetIndex(ClanConquestObjectTypeDescription description, int startOffsetIndex)"
            inline constexpr std::uintptr_t GetItemCashReward = 0x39500A0; // "public override int GetItemCashReward(ClanConquestObjectTypeDescription description)"
            inline constexpr std::uintptr_t SetItemCashReward = 0x7B3360; // "public override void SetItemCashReward(ClanConquestObjectTypeDescription description, int amount)"
            inline constexpr std::uintptr_t ClearItemCashReward = 0x7B3360; // "public override void ClearItemCashReward(ClanConquestObjectTypeDescription description)"
        }
    } // namespace OwnedClanConquestObjectsModel

    namespace OwnedClanConquestSectorData { // "Models.Data.Clan.OwnedClanConquestSectorData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ClanBattleStartOffsetIndex = 0x20; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t CashReward = 0x28; // "IPrimitiveData<int>"
        }
    } // namespace OwnedClanConquestSectorData

    namespace OwnedClanConquestSectorsModel { // "Models.Models.OwnedClanConquestItemsModel.OwnedClanConquestSectorsModel (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t GetClanBattleStartOffsetIndex = 0x4915DF0; // "public override int GetClanBattleStartOffsetIndex(SectorDescription description)"
            inline constexpr std::uintptr_t ChangeClanBattleStartOffsetIndex = 0x4915D40; // "public override void ChangeClanBattleStartOffsetIndex(SectorDescription description, int startOffsetIndex)"
            inline constexpr std::uintptr_t GetItemCashReward = 0x4915E70; // "public override int GetItemCashReward(SectorDescription description)"
            inline constexpr std::uintptr_t SetItemCashReward = 0x4915EF0; // "public override void SetItemCashReward(SectorDescription description, int amount)"
            inline constexpr std::uintptr_t ClearItemCashReward = 0x4915DD0; // "public override void ClearItemCashReward(SectorDescription description)"
        }
    } // namespace OwnedClanConquestSectorsModel

    namespace Parties { // "Models.Models.Parties.Parties (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t parties = 0x10; // "Dictionary<string, PartyModel>"
            inline constexpr std::uintptr_t partiesByEntity = 0x18; // "Dictionary<int, PartyModel>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t AddParty = 0x4916730; // "public void AddParty(PartyModel partyModel)"
            inline constexpr std::uintptr_t RemoveParty = 0x49169C0; // "public void RemoveParty(string partyId)"
            inline constexpr std::uintptr_t AddToParty = 0x4916790; // "public void AddToParty(int entityId, string partyId)"
            inline constexpr std::uintptr_t RemoveFromParty = 0x4916900; // "public void RemoveFromParty(int entityId)"
            inline constexpr std::uintptr_t TryGetParty = 0x4916A90; // "public bool TryGetParty(string partyId, out PartyModel partyModel)"
            inline constexpr std::uintptr_t TryGetPartyByEntity = 0x4916A20; // "public bool TryGetPartyByEntity(int entityId, out PartyModel partyModel)"
            inline constexpr std::uintptr_t GetEnumerator = 0x4916860; // "public IEnumerator<PartyModel> GetEnumerator()"
            inline constexpr std::uintptr_t System_Collections_IEnumerable_GetEnumerator = 0x4916860; // "private IEnumerator System.Collections.IEnumerable.GetEnumerator()"
        }
    } // namespace Parties

    namespace PartiesExtensions { // "Models.Utils.Extensions.PartiesExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t IsSameParty = 0x3964C50; // "public static bool IsSameParty(IParties parties, int entityId1, int entityId2)"
            inline constexpr std::uintptr_t GetPartySize = 0x3964B60; // "public static int GetPartySize(IParties parties, int entityId)"
            inline constexpr std::uintptr_t IsVehicleHeldByParty = 0x3964DD0; // "public static bool IsVehicleHeldByParty(IParties parties, int characterEntityId, VehicleModel vehicle)"
        }
    } // namespace PartiesExtensions

    namespace PartyAuthorColorRule { // "Game.Global.Chat.PartyAuthorColorRule (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t partyModel = 0x10; // "PartyModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t TryGetColorType = 0x36D57C0; // "public bool TryGetColorType(long publicId, out UserColorType colorType)"
        }
    } // namespace PartyAuthorColorRule

    namespace PartyBuffModel { // "Game.Battle.Buffs.PartyBuffModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Buff = 0x10; // "CodexBuffsDescription"
        }
    } // namespace PartyBuffModel

    namespace PartyBuffModelUpdater { // "Game.Battle.Buffs.PartyBuffModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "PartyBuffModel"
            inline constexpr std::uintptr_t partyModel = 0x18; // "PartyModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x20; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t hasAuthority = 0x28; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xD4D270; // "public void Update()"
        }
    } // namespace PartyBuffModelUpdater

    namespace PartyBuffUpdater { // "Game.Battle.Buffs.PartyBuffUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t partyBuffModel = 0x40; // "PartyBuffModel"
            inline constexpr std::uintptr_t buff = 0x48; // "CodexBuffsDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xD4D6C0; // "public override void Update()"
            inline constexpr std::uintptr_t GetModifierState = 0xD4D480; // "private static PercentBuffView.ModifierState GetModifierState(CodexBuffsDescription buff)"
        }
    } // namespace PartyBuffUpdater

    namespace PartyChatUpdater { // "Game.Global.Party.PartyChatUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t partyModel = 0x10; // "PartyModel"
            inline constexpr std::uintptr_t chatsModel = 0x18; // "ChatsModel"
            inline constexpr std::uintptr_t partyChatSettings = 0x20; // "ChatSourceSettings"
            inline constexpr std::uintptr_t now = 0x28; // "INow"
            inline constexpr std::uintptr_t regionUserRoom = 0x30; // "IRoomConnection"
            inline constexpr std::uintptr_t chatLocalization = 0x38; // "ChatLocalization"
            inline constexpr std::uintptr_t rulesSource = 0x40; // "SystemChatMessageSource"
            inline constexpr std::uintptr_t blackListModel = 0x48; // "BlackListModel"
            inline constexpr std::uintptr_t badWordsFilter = 0x50; // "BadWordsFilterModel"
            inline constexpr std::uintptr_t chatCooldown = 0x58; // "ExpiringResourceModel"
            inline constexpr std::uintptr_t systemChat = 0x60; // "SystemChatMessageSource"
            inline constexpr std::uintptr_t eventsUpdater = 0x68; // "IUpdater"
            inline constexpr std::uintptr_t updater = 0x70; // "IUpdater"
            inline constexpr std::uintptr_t disposable = 0x78; // "IRegisterDisposable"
            inline constexpr std::uintptr_t wasInParty = 0x80; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x379AA80; // "public void Update()"
            inline constexpr std::uintptr_t ResolveInParty = 0x379A310; // "private void ResolveInParty()"
        }
    } // namespace PartyChatUpdater

    namespace PartyConfig { // "Models.References.Party.PartyConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t InviteTimeout = 0x10; // "long"
            inline constexpr std::uintptr_t ReadyCheckTimeDuration = 0x18; // "long"
            inline constexpr std::uintptr_t ShooterJoinTime = 0x20; // "long"
        }
    } // namespace PartyConfig

    namespace PartyData { // "Models.Data.Party.PartyData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Invites = 0x20; // "ReferenceMapData<PartyInviteSlotDescription, PartyInviteData>"
            inline constexpr std::uintptr_t Members = 0x28; // "ReferenceMapData<PartyMemberSlotDescription, PartyMemberData>"
            inline constexpr std::uintptr_t IsReadyCheck = 0x30; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t ReadyCheckInitiator = 0x38; // "IPrimitiveData<PartyMemberSlotDescription>"
            inline constexpr std::uintptr_t ReadyCheckEndTs = 0x40; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t PartyEnterBattleMode = 0x48; // "ReferenceData<BattleModeDescription>"
            inline constexpr std::uintptr_t PartyEnterLocation = 0x50; // "ReferenceData<LocationDescription>"
            inline constexpr std::uintptr_t PartyEnterSector = 0x58; // "ReferenceData<SectorDescription>"
            inline constexpr std::uintptr_t PartyEnterSettlement = 0x60; // "ReferenceData<SettlementDescription>"
            inline constexpr std::uintptr_t Chat = 0x68; // "ChatMessagesData"
        }
    } // namespace PartyData

    namespace PartyIncomingInviteModel { // "Game.Global.Party.PartyIncomingInviteModel (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t userPartyInviteData = 0x10; // "UserPartyInviteData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_PublicId = 0x356B3F0; // "public long get_PublicId()"
            inline constexpr std::uintptr_t get_Nickname = 0x356B350; // "public string get_Nickname()"
            inline constexpr std::uintptr_t get_PartyId = 0x356B3A0; // "public string get_PartyId()"
            inline constexpr std::uintptr_t get_EndTs = 0x356B2A0; // "public long get_EndTs()"
            inline constexpr std::uintptr_t get_ClanTag = 0x356B250; // "public string get_ClanTag()"
            inline constexpr std::uintptr_t get_IsExist = 0x356B2F0; // "public bool get_IsExist()"
        }
    } // namespace PartyIncomingInviteModel

    namespace PartyInviteData { // "Models.Data.Party.PartyInviteData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t PublicId = 0x20; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t Nickname = 0x28; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t EndTs = 0x30; // "IPrimitiveData<long>"
        }
    } // namespace PartyInviteData

    namespace PartyInviteModel { // "Game.Global.Party.PartyInviteModel (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t partyInviteData = 0x10; // "PartyInviteData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_PublicId = 0x356B4F0; // "public long get_PublicId()"
            inline constexpr std::uintptr_t get_Nickname = 0x356B4A0; // "public string get_Nickname()"
            inline constexpr std::uintptr_t get_IsExist = 0x356B440; // "public bool get_IsExist()"
        }
    } // namespace PartyInviteModel

    namespace PartyInviteNotificationsUpdater { // "Game.Global.PopupNotificationDialog.PartyInviteNotificationsUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t partyModel = 0x10; // "PartyModel"
            inline constexpr std::uintptr_t popupNotificationsModel = 0x18; // "PopupNotificationsModel"
            inline constexpr std::uintptr_t now = 0x20; // "INow"
            inline constexpr std::uintptr_t popupNotificationKeys = 0x28; // "PopupNotificationKeys"
            inline constexpr std::uintptr_t regionUser = 0x30; // "IRoomConnection"
            inline constexpr std::uintptr_t partyLocalization = 0x38; // "PartyLocalization"
            inline constexpr std::uintptr_t personalNotificationModel = 0x40; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t delayedResponsesModel = 0x48; // "IDelayedResponsesModel"
            inline constexpr std::uintptr_t realmBattleStateModel = 0x50; // "RealmBattleStateModel"
            inline constexpr std::uintptr_t toRemove = 0x58; // "HashSet<PartyInviteNotificationsUpdater.InviteNotificationFingerprint>"
            inline constexpr std::uintptr_t models = 0x60; // "Dictionary<PartyInviteNotificationsUpdater.InviteNotificationFingerprint, PopupNotification>"
            inline constexpr std::uintptr_t socialModel = 0x68; // "SocialModel"
            inline constexpr std::uintptr_t isProgress = 0x70; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x35B71A0; // "public void Update()"
            inline constexpr std::uintptr_t RemoveNotValidNotifications = 0x35B6D90; // "private void RemoveNotValidNotifications()"
            inline constexpr std::uintptr_t RemoveAllNotifications = 0x35B6B90; // "private void RemoveAllNotifications()"
            inline constexpr std::uintptr_t AddNewNotifications = 0x35B6060; // "private void AddNewNotifications()"
            inline constexpr std::uintptr_t OnDeclineInvite = 0x35B68D0; // "private void OnDeclineInvite(string partyId)"
            inline constexpr std::uintptr_t OnAcceptInvite = 0x35B6800; // "private void OnAcceptInvite(string partyId)"
            inline constexpr std::uintptr_t ParseResponse = 0x35B69A0; // "private void ParseResponse(string value)"
            inline constexpr std::uintptr_t Notify = 0x35B67B0; // "private void Notify(LocalizedString localizedString)"
        }
    } // namespace PartyInviteNotificationsUpdater

    namespace PartyInviteNotificationsUpdater_InviteNotificationFingerprint { // "Game.Global.PopupNotificationDialog.PartyInviteNotificationsUpdater.InviteNotificationFingerprint (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t InviteModel = 0x10; // "PartyIncomingInviteModel"
            inline constexpr std::uintptr_t PublicId = 0x18; // "long"
            inline constexpr std::uintptr_t EndTs = 0x20; // "long"
            inline constexpr std::uintptr_t PartyId = 0x28; // "string"
        }
    } // namespace PartyInviteNotificationsUpdater_InviteNotificationFingerprint

    namespace PartyInviteSlotDescription { // "Models.References.Party.PartyInviteSlotDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x825DA48; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t enum_id = 0x0; // "Enum<PartyInviteSlotDescription>"
            inline constexpr std::uintptr_t Slot0 = 0x8; // "PartyInviteSlotDescription"
            inline constexpr std::uintptr_t Slot1 = 0x10; // "PartyInviteSlotDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Enum = 0x40BD1B0; // "public static ReadOnlyEnum<PartyInviteSlotDescription> get_Enum()"
        }
    } // namespace PartyInviteSlotDescription

    namespace PartyLerpOverlayPosition { // "Game.Battle.Entities.BattleCharacter.Stats.Models.PartyLerpOverlayPosition (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Position = 0x10; // "Vector3"
            inline constexpr std::uintptr_t Progress = 0x1C; // "float"
            inline constexpr std::uintptr_t NeedLerp = 0x20; // "bool"
        }
    } // namespace PartyLerpOverlayPosition

    namespace PartyLogUpdater { // "Game.Global.Logs.PartyLogUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t partyModel = 0x10; // "PartyModel"
            inline constexpr std::uintptr_t partySize = 0x18; // "int"
            inline constexpr std::uintptr_t hasParty = 0x1C; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x35A6040; // "public void Update()"
            inline constexpr std::uintptr_t SetSentryData = 0x35A5F10; // "private void SetSentryData(int partySize)"
            inline constexpr std::uintptr_t ClearSentryData = 0x35A5E00; // "private void ClearSentryData()"
        }
    } // namespace PartyLogUpdater

    namespace PartyManagerModelUpdater { // "Game.Global.Party.Dialog.PartyManagerModelUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t partyModel = 0x10; // "PartyModel"
            inline constexpr std::uintptr_t partyManagerDialogModel = 0x18; // "PartyManagerDialogModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x356DE40; // "public void Update()"
            inline constexpr std::uintptr_t Dispose = 0x356DD90; // "private void Dispose()"
        }
    } // namespace PartyManagerModelUpdater

    namespace PartyManagerSteamFriendsUpdater { // "Game.Global.Party.Dialog.PartyManagerSteamFriendsUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t steamAdapter = 0x10; // "ISteamAdapter"
            inline constexpr std::uintptr_t partyModel = 0x18; // "PartyModel"
            inline constexpr std::uintptr_t inviteIntentionModel = 0x20; // "InviteToPartyIntentionModel"
            inline constexpr std::uintptr_t uiSoundModel = 0x28; // "GlobalUISoundModel"
            inline constexpr std::uintptr_t dialogModel = 0x30; // "PartyManagerDialogModel"
            inline constexpr std::uintptr_t dialogView = 0x38; // "KeyboardMousePartyManagerDialogView"
            inline constexpr std::uintptr_t gameSettings = 0x40; // "GameSettingsModel"
            inline constexpr std::uintptr_t hiddenInfoLabel = 0x48; // "Text"
            inline constexpr std::uintptr_t filteredFriends = 0x50; // "List<SteamFriend>"
            inline constexpr std::uintptr_t sliceScrollViewUpdater = 0x58; // "VerticalSliceScrollViewUpdater<PartyFriendLineView, SteamFriend>"
            inline constexpr std::uintptr_t realmKey = 0x60; // "ValueTuple<string, int>"
            inline constexpr std::uintptr_t pendingPublicId = 0x70; // "long"
            inline constexpr std::uintptr_t steamFriendsVersion = 0x78; // "int"
            inline constexpr std::uintptr_t isStreamerMode = 0x7C; // "Nullable<bool>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x356E970; // "public void Update()"
            inline constexpr std::uintptr_t UpdateRealmLabel = 0x356E760; // "private void UpdateRealmLabel()"
            inline constexpr std::uintptr_t UpdateRealmFriends = 0x356E5D0; // "private void UpdateRealmFriends()"
            inline constexpr std::uintptr_t UpdateScrollView = 0x356E8B0; // "private void UpdateScrollView()"
            inline constexpr std::uintptr_t UpdateFriendView = 0x356E3B0; // "private void UpdateFriendView(PartyFriendLineView line, SteamFriend friend)"
            inline constexpr std::uintptr_t ClearFriendView = 0x356E310; // "private void ClearFriendView(PartyFriendLineView line)"
            inline constexpr std::uintptr_t UpdateInviteButton = 0x356E450; // "private void UpdateInviteButton(PartyFriendLineView line, long publicId)"
            inline constexpr std::uintptr_t Invite = 0x356E350; // "private void Invite(long publicId)"
        }
    } // namespace PartyManagerSteamFriendsUpdater

    namespace PartyManagerTabsUpdater { // "Game.Global.Party.Dialog.PartyManagerTabsUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dialogView = 0x10; // "KeyboardMousePartyManagerDialogView"
            inline constexpr std::uintptr_t dialogModel = 0x18; // "PartyManagerDialogModel"
            inline constexpr std::uintptr_t clickUpdaters = 0x20; // "List<IUpdater>"
            inline constexpr std::uintptr_t partyManagerTab = 0x28; // "Nullable<PartyManagerTab>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x356EE70; // "public void Update()"
        }
    } // namespace PartyManagerTabsUpdater

    namespace PartyMemberAccessModel { // "Models.Models.IPartyMemberAccessModel.PartyMemberAccessModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t worldEntitiesModel = 0x10; // "WorldEntitiesModel"
            inline constexpr std::uintptr_t parties = 0x18; // "IParties"
            inline constexpr std::uintptr_t characterSlotsModel = 0x20; // "ICharacterSlotsModel"
            inline constexpr std::uintptr_t settlementHelperModel = 0x28; // "ISettlementHelperModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t HasPlotAccess = 0x4947150; // "public bool HasPlotAccess(int characterId, int targetEntityId)"
            inline constexpr std::uintptr_t HasPlotAccess_2 = 0x4947040; // "public bool HasPlotAccess(int characterId, PlotModel plotModel)"
            inline constexpr std::uintptr_t HasSettlementLocationEntityAccess = 0x4947320; // "public bool HasSettlementLocationEntityAccess(int characterId)"
            inline constexpr std::uintptr_t IsSameParty = 0x4947750; // "public bool IsSameParty(long firstPublicId, long secondPublicId)"
            inline constexpr std::uintptr_t TryGetParty = 0x4947800; // "private bool TryGetParty(long publicId, out PartyModel partyModel)"
            inline constexpr std::uintptr_t IsPartyContainsMember = 0x4947430; // "private bool IsPartyContainsMember(PartyModel partyModel, long targetMemberPublicId)"
            inline constexpr std::uintptr_t IsPartyContainsSettlementOwnerOrPlotOwner = 0x4947560; // "private bool IsPartyContainsSettlementOwnerOrPlotOwner(PartyModel partyModel)"
        }
    } // namespace PartyMemberAccessModel

    namespace PartyMemberBattleDataModel { // "Game.Global.Party.PartyMemberBattleDataModel (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battlePartyMemberData = 0x10; // "BattlePartyMemberData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_ReadyCheckBecomeRobberStatusDescription = 0x356FFE0; // "public PartyReadyCheckStatusDescription get_ReadyCheckBecomeRobberStatusDescription()"
            inline constexpr std::uintptr_t get_EntityId = 0x356F650; // "public long get_EntityId()"
            inline constexpr std::uintptr_t get_Health = 0x356F760; // "public int get_Health()"
            inline constexpr std::uintptr_t get_Armor = 0x356F480; // "public int get_Armor()"
            inline constexpr std::uintptr_t get_Role = 0x35700A0; // "public PlayerRoleDescription get_Role()"
            inline constexpr std::uintptr_t get_EquipArmorItem = 0x356F6B0; // "public InventoryItemDescription get_EquipArmorItem()"
            inline constexpr std::uintptr_t get_HideObjectEntityId = 0x356F7B0; // "public int get_HideObjectEntityId()"
            inline constexpr std::uintptr_t get_ArrestTs = 0x356F5A0; // "public long get_ArrestTs()"
            inline constexpr std::uintptr_t get_ArrestStateDescription = 0x356F4D0; // "public ArrestStateDescription get_ArrestStateDescription()"
            inline constexpr std::uintptr_t get_InterruptArrestingTs = 0x356F920; // "public long get_InterruptArrestingTs()"
            inline constexpr std::uintptr_t get_KnockoutEndTs = 0x356FBC0; // "public long get_KnockoutEndTs()"
            inline constexpr std::uintptr_t get_KnockoutPhase = 0x356FC20; // "public KnockoutPhaseDescription get_KnockoutPhase()"
            inline constexpr std::uintptr_t get_ReviveEndTs = 0x3570040; // "public long get_ReviveEndTs()"
            inline constexpr std::uintptr_t get_IsInVehicle = 0x356FA70; // "public bool get_IsInVehicle()"
            inline constexpr std::uintptr_t get_InVehicleEntityId = 0x356F8C0; // "public int get_InVehicleEntityId()"
            inline constexpr std::uintptr_t get_HasMark = 0x356F700; // "public bool get_HasMark()"
            inline constexpr std::uintptr_t get_IsCopRewardBoxEmpty = 0x356F980; // "public bool get_IsCopRewardBoxEmpty()"
            inline constexpr std::uintptr_t get_Mark = 0x356FCF0; // "public Vector3 get_Mark()"
            inline constexpr std::uintptr_t get_PingMark = 0x356FF00; // "public Vector3 get_PingMark()"
            inline constexpr std::uintptr_t get_PingMarkType = 0x356FE30; // "public PingMarkTypeDescription get_PingMarkType()"
            inline constexpr std::uintptr_t get_PingMarkTs = 0x356FDD0; // "public long get_PingMarkTs()"
            inline constexpr std::uintptr_t get_CharacterControllerState = 0x356F5F0; // "public CharacterControllerStateDescription get_CharacterControllerState()"
            inline constexpr std::uintptr_t get_IsSurrendering = 0x356FB30; // "public bool get_IsSurrendering()"
            inline constexpr std::uintptr_t get_IsImmunity = 0x356F9E0; // "public bool get_IsImmunity()"
            inline constexpr std::uintptr_t get_ImmuneEndTs = 0x356F860; // "public long get_ImmuneEndTs()"
            inline constexpr std::uintptr_t get_HoldingCellReleaseTs = 0x356F800; // "public long get_HoldingCellReleaseTs()"
        }
    } // namespace PartyMemberBattleDataModel

    namespace PartyMemberData { // "Models.Data.Party.PartyMemberData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t PublicId = 0x20; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t Nickname = 0x28; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t ClanTag = 0x30; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t IsLeader = 0x38; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t ReadyCheckStatus = 0x40; // "IPrimitiveData<PartyReadyCheckStatusDescription>"
            inline constexpr std::uintptr_t BattleMode = 0x48; // "IPrimitiveData<BattleModeDescription>"
            inline constexpr std::uintptr_t Location = 0x50; // "IPrimitiveData<LocationDescription>"
            inline constexpr std::uintptr_t Sector = 0x58; // "IPrimitiveData<SectorDescription>"
            inline constexpr std::uintptr_t Settlement = 0x60; // "IPrimitiveData<SettlementDescription>"
            inline constexpr std::uintptr_t IsParticipatingInPartyEnter = 0x68; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t PlotSector = 0x70; // "IPrimitiveData<SectorDescription>"
            inline constexpr std::uintptr_t PlotSettlement = 0x78; // "IPrimitiveData<SettlementDescription>"
        }
    } // namespace PartyMemberData

    namespace PartyMemberModel { // "Game.Global.Party.PartyMemberModel (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t partyMemberData = 0x10; // "PartyMemberData"
            inline constexpr std::uintptr_t PositionModel = 0x18; // "LerpPositionModel"
            inline constexpr std::uintptr_t RotationModel = 0x20; // "CharacterRotationModel"
            inline constexpr std::uintptr_t VehiclePositionModel = 0x28; // "LerpPositionModel"
            inline constexpr std::uintptr_t characterInfo = 0x30; // "IMemberBattleDataModel"
            inline constexpr std::uintptr_t battlePartyMemberData = 0x38; // "BattlePartyMemberData"
            inline constexpr std::uintptr_t Index = 0x40; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_PublicId = 0x3571F00; // "public long get_PublicId()"
            inline constexpr std::uintptr_t get_Nickname = 0x3571E10; // "public string get_Nickname()"
            inline constexpr std::uintptr_t get_IsLeader = 0x3571D20; // "public bool get_IsLeader()"
            inline constexpr std::uintptr_t get_IsExist = 0x3571A30; // "public bool get_IsExist()"
            inline constexpr std::uintptr_t get_IsInRealm = 0x3571B40; // "public bool get_IsInRealm()"
            inline constexpr std::uintptr_t get_IsInSettlement = 0x3571C80; // "public bool get_IsInSettlement()"
            inline constexpr std::uintptr_t get_LocationCity = 0x3571DC0; // "public LocationDescription get_LocationCity()"
            inline constexpr std::uintptr_t get_Settlement = 0x3571FF0; // "public SettlementDescription get_Settlement()"
            inline constexpr std::uintptr_t get_Sector = 0x3571FA0; // "public SectorDescription get_Sector()"
            inline constexpr std::uintptr_t get_PlotSettlement = 0x3571EB0; // "public SettlementDescription get_PlotSettlement()"
            inline constexpr std::uintptr_t get_PlotSector = 0x3571E60; // "public SectorDescription get_PlotSector()"
            inline constexpr std::uintptr_t get_IsInRobbery = 0x3571BD0; // "public bool get_IsInRobbery()"
            inline constexpr std::uintptr_t get_IsInClanBattle = 0x3571A90; // "public bool get_IsInClanBattle()"
            inline constexpr std::uintptr_t get_ReadyCheckStatusDescription = 0x3571F50; // "public PartyReadyCheckStatusDescription get_ReadyCheckStatusDescription()"
            inline constexpr std::uintptr_t get_IsParticipatingInPartyEnter = 0x3571D70; // "public bool get_IsParticipatingInPartyEnter()"
            inline constexpr std::uintptr_t get_ClanTag = 0x35719E0; // "public string get_ClanTag()"
            inline constexpr std::uintptr_t SetPlayerInfo = 0x35714F0; // "public void SetPlayerInfo(BattleCharacterModel battleCharacterModel, PlayerBattleModel playerBattleModel)"
            inline constexpr std::uintptr_t SetCharacterInfo = 0x3571400; // "public void SetCharacterInfo(BattlePartyMemberData battlePartyMemberData)"
            inline constexpr std::uintptr_t TryGetCharacterInfo = 0x35718C0; // "public bool TryGetCharacterInfo(out IMemberBattleDataModel characterInfo)"
            inline constexpr std::uintptr_t ClearInfo = 0xB43AD0; // "public void ClearInfo()"
            inline constexpr std::uintptr_t SyncTransformByData = 0x35715D0; // "public void SyncTransformByData()"
            inline constexpr std::uintptr_t SyncVehicleTransformByData = 0x35717C0; // "public void SyncVehicleTransformByData(PartyVehicleData partyVehicleData)"
            inline constexpr std::uintptr_t SyncTransformByEntity = 0x3571760; // "public void SyncTransformByEntity(Vector3 position, float yaw)"
            inline constexpr std::uintptr_t SyncVehicleTransformByEntity = 0x3571880; // "public void SyncVehicleTransformByEntity(Vector3 position)"
        }
    } // namespace PartyMemberModel

    namespace PartyMemberPublicIdsExtensions { // "Models.Utils.Extensions.PartyMemberPublicIdsExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t GetValuesCollection = 0x3964F20; // "public static IReadOnlyCollection<long> GetValuesCollection(IListData<IPrimitiveData<long>> data)"
        }
    } // namespace PartyMemberPublicIdsExtensions

    namespace PartyMemberSlotColorDescription { // "Game.Global.Party.PartyMemberSlotColorDescription (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t PartyMemberColor = 0x10; // "PaletteColor"
            inline constexpr std::uintptr_t identified = 0x18; // "IdentifiedProperty<PartyMemberSlotDescription>"
            inline constexpr std::uintptr_t Index = 0x20; // "int"
        }
    } // namespace PartyMemberSlotColorDescription

    namespace PartyMemberSlotDescription { // "Models.References.Party.PartyMemberSlotDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x825F928; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t enum_id = 0x0; // "Enum<PartyMemberSlotDescription>"
            inline constexpr std::uintptr_t Slot0 = 0x8; // "PartyMemberSlotDescription"
            inline constexpr std::uintptr_t Slot1 = 0x10; // "PartyMemberSlotDescription"
            inline constexpr std::uintptr_t Slot2 = 0x18; // "PartyMemberSlotDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Enum = 0x40BD500; // "public static ReadOnlyEnum<PartyMemberSlotDescription> get_Enum()"
        }
    } // namespace PartyMemberSlotDescription

    namespace PartyModel { // "Game.Global.Party.PartyModel (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t partyData = 0x10; // "PartyData"
            inline constexpr std::uintptr_t partyInviteModels = 0x18; // "Dictionary<PartyInviteSlotDescription, PartyInviteModel>"
            inline constexpr std::uintptr_t partyIncomingInviteModels = 0x20; // "Dictionary<PartyInviteSlotDescription, PartyIncomingInviteModel>"
            inline constexpr std::uintptr_t partyMemberModels = 0x28; // "Dictionary<PartyMemberSlotDescription, PartyMemberModel>"
            inline constexpr std::uintptr_t actualPartyInviteModels = 0x30; // "Dictionary<long, PartyInviteModel>"
            inline constexpr std::uintptr_t actualPartyMemberModels = 0x38; // "Dictionary<long, PartyMemberModel>"
            inline constexpr std::uintptr_t actualMembersAddedOrderList = 0x40; // "List<long>"
            inline constexpr std::uintptr_t removedMembers = 0x48; // "List<long>"
            inline constexpr std::uintptr_t emptyPartyMembers = 0x50; // "IEnumerable<PartyMemberData>"
            inline constexpr std::uintptr_t regionUserPartyData = 0x58; // "RegionUserPartyData"
            inline constexpr std::uintptr_t HasParty = 0x60; // "bool"
            inline constexpr std::uintptr_t IsAllMembersInRealm = 0x61; // "bool"
            inline constexpr std::uintptr_t IsAllMembersNotInRealm = 0x62; // "bool"
            inline constexpr std::uintptr_t MembersInLocationCount = 0x64; // "int"
            inline constexpr std::uintptr_t PlayerPartyModel = 0x68; // "PartyMemberModel"
            inline constexpr std::uintptr_t BecomeRobberReadyCheckEndTs = 0x70; // "long"
            inline constexpr std::uintptr_t BecomeRobberReadyCheckEntityId = 0x78; // "long"
            inline constexpr std::uintptr_t CopRecruitingReadyCheckEndTs = 0x80; // "long"
            inline constexpr std::uintptr_t Vehicles = 0x88; // "PartyVehiclesModel"
            inline constexpr std::uintptr_t PartyLogsSource = 0x90; // "SystemChatMessageSource"
            inline constexpr std::uintptr_t IsPlayerJoinPartyChatNotificationDuringThisSession = 0x98; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t ClearActualModelDictionaries = 0x3573CC0; // "public void ClearActualModelDictionaries()"
            inline constexpr std::uintptr_t AddActualInviteModel = 0x3573A40; // "public void AddActualInviteModel(PartyInviteModel inviteModel)"
            inline constexpr std::uintptr_t AddActualMemberModel = 0x3573AE0; // "public void AddActualMemberModel(PartyMemberModel memberModel)"
            inline constexpr std::uintptr_t SetBecomeRobberReadyCheckEndTs = 0x3573FC0; // "public void SetBecomeRobberReadyCheckEndTs(long endTs, int entityId)"
            inline constexpr std::uintptr_t SetCopRecruitingReadyCheckEndTs = 0xAB7F60; // "public void SetCopRecruitingReadyCheckEndTs(long endTs)"
            inline constexpr std::uintptr_t SetPlayerPartyData = 0x3573FD0; // "public void SetPlayerPartyData(PlayerPartyData playerPartyData)"
            inline constexpr std::uintptr_t get_IsRequesting = 0x35750A0; // "public bool get_IsRequesting()"
            inline constexpr std::uintptr_t get_IsPlayerLeader = 0x3574FE0; // "public bool get_IsPlayerLeader()"
            inline constexpr std::uintptr_t get_IsSoloInParty = 0x35750F0; // "public bool get_IsSoloInParty()"
            inline constexpr std::uintptr_t get_IsPartyFull = 0x3574F20; // "public bool get_IsPartyFull()"
            inline constexpr std::uintptr_t get_IsReadyCheck = 0x3575050; // "public bool get_IsReadyCheck()"
            inline constexpr std::uintptr_t get_IsPartyEnter = 0x3574ED0; // "public bool get_IsPartyEnter()"
            inline constexpr std::uintptr_t get_ReadyCheckEndTs = 0x3575240; // "public long get_ReadyCheckEndTs()"
            inline constexpr std::uintptr_t get_ReadyCheckInitiatorNickname = 0x3575290; // "public string get_ReadyCheckInitiatorNickname()"
            inline constexpr std::uintptr_t get_PartyEnterLocation = 0x3575150; // "public LocationDescription get_PartyEnterLocation()"
            inline constexpr std::uintptr_t get_SettlementDescription = 0x35753F0; // "public SettlementDescription get_SettlementDescription()"
            inline constexpr std::uintptr_t get_SectorDescription = 0x35753A0; // "public SectorDescription get_SectorDescription()"
            inline constexpr std::uintptr_t get_BattleMode = 0x3574DE0; // "public BattleModeDescription get_BattleMode()"
            inline constexpr std::uintptr_t get_PartyInviteModels = 0x7E7130; // "public IReadOnlyDictionary<PartyInviteSlotDescription, PartyInviteModel> get_PartyInviteModels()"
            inline constexpr std::uintptr_t get_PartyIncomingInviteModels = 0x7AB150; // "public IReadOnlyDictionary<PartyInviteSlotDescription, PartyIncomingInviteModel> get_PartyIncomingInviteModels()"
            inline constexpr std::uintptr_t get_PartyMemberModels = 0x7AA000; // "public IReadOnlyDictionary<PartyMemberSlotDescription, PartyMemberModel> get_PartyMemberModels()"
            inline constexpr std::uintptr_t get_ActualPartyInviteModels = 0x7BB030; // "public IReadOnlyDictionary<long, PartyInviteModel> get_ActualPartyInviteModels()"
            inline constexpr std::uintptr_t get_ActualPartyMemberModels = 0x7E5BC0; // "public Dictionary<long, PartyMemberModel> get_ActualPartyMemberModels()"
            inline constexpr std::uintptr_t get_ActualMembersAddedOrderList = 0x7E9250; // "public IReadOnlyList<long> get_ActualMembersAddedOrderList()"
            inline constexpr std::uintptr_t get_IsInParty = 0x3574E70; // "public bool get_IsInParty()"
            inline constexpr std::uintptr_t GetDisplayIndexOfPartyMember = 0x3573D30; // "public int GetDisplayIndexOfPartyMember(long publicId)"
            inline constexpr std::uintptr_t IsPartyMember = 0x3573D90; // "public bool IsPartyMember(long publicId)"
            inline constexpr std::uintptr_t IsTeammate = 0x3573E00; // "public bool IsTeammate(int entityId)"
            inline constexpr std::uintptr_t UpdateCurrentPartyOrder = 0x3574010; // "public void UpdateCurrentPartyOrder()"
            inline constexpr std::uintptr_t get_PartyMembers = 0xAC0D40; // "public ReferenceMapData<PartyMemberSlotDescription, PartyMemberData> get_PartyMembers()"
            inline constexpr std::uintptr_t get_PartyMembersData = 0x35751A0; // "public IEnumerable<PartyMemberData> get_PartyMembersData()"
            inline constexpr std::uintptr_t get_ChatData = 0x3574E30; // "public ChatMessagesData get_ChatData()"
        }
    } // namespace PartyModel

    namespace PartyModel_2 { // "Models.Models.Party.PartyModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t entities = 0x10; // "HashSet<int>"
            inline constexpr std::uintptr_t memberPublicIds = 0x18; // "HashSet<long>"
            inline constexpr std::uintptr_t Id = 0x20; // "string"
            inline constexpr std::uintptr_t Data = 0x28; // "BattlePartyData"
            inline constexpr std::uintptr_t EnterGroup = 0x30; // "LocationEnterGroupDescription"
            inline constexpr std::uintptr_t Entities = 0x38; // "ReadOnly.HashSet<int>"
            inline constexpr std::uintptr_t MemberPublicIds = 0x40; // "ReadOnly.HashSet<long>"
            inline constexpr std::uintptr_t Vehicles = 0x48; // "PartyVehiclesModel"
            inline constexpr std::uintptr_t WantedPoints = 0x50; // "IPrimitiveModel<int>"
            inline constexpr std::uintptr_t BecomeRobberReadyCheckModel = 0x58; // "BattleReadyCheckModel"
            inline constexpr std::uintptr_t RobberAuthority = 0x60; // "RobberAuthorityModel"
            inline constexpr std::uintptr_t CopRecruitingReadyCheckModel = 0x68; // "BattleReadyCheckModel"
            inline constexpr std::uintptr_t ShooterTeammatesJoinEndTs = 0x70; // "long"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_MembersCount = 0x4917390; // "public int get_MembersCount()"
            inline constexpr std::uintptr_t Add = 0x4916BC0; // "public void Add(int entityId)"
            inline constexpr std::uintptr_t Remove = 0x4916C80; // "public void Remove(int entityId)"
            inline constexpr std::uintptr_t Contains = 0x4916C20; // "public bool Contains(int entityId)"
            inline constexpr std::uintptr_t UpdateMemberPublicIds = 0x4916CE0; // "public void UpdateMemberPublicIds(IReadOnlyCollection<long> memberPublicIds)"
        }
    } // namespace PartyModel_2

    namespace PartyReadyCheckFailedNotificationUpdater { // "Game.Global.Party.PartyReadyCheckFailedNotificationUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t partyModel = 0x10; // "PartyModel"
            inline constexpr std::uintptr_t personalNotificationModel = 0x18; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t memberNotReady = 0x20; // "LocalizedString"
            inline constexpr std::uintptr_t notifiedMembers = 0x28; // "HashSet<long>"
            inline constexpr std::uintptr_t unansweredMembers = 0x30; // "Dictionary<long, string>"
            inline constexpr std::uintptr_t wasReadyCheck = 0x38; // "bool"
            inline constexpr std::uintptr_t wasPlayerReady = 0x39; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x3577020; // "public void Update()"
            inline constexpr std::uintptr_t IsReadyCheckTimedOut = 0x3576A10; // "private bool IsReadyCheckTimedOut()"
            inline constexpr std::uintptr_t TrackMembers = 0x3576C60; // "private void TrackMembers()"
            inline constexpr std::uintptr_t NotifyUnansweredMembers = 0x3576A80; // "private void NotifyUnansweredMembers()"
            inline constexpr std::uintptr_t TryNotify = 0x3576EF0; // "private void TryNotify(long publicId, string nickname)"
        }
    } // namespace PartyReadyCheckFailedNotificationUpdater

    namespace PartyReadyCheckStatusDescription { // "Models.References.Party.PartyReadyCheckStatusDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x82602E8; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t enum_id = 0x0; // "Enum<PartyReadyCheckStatusDescription>"
            inline constexpr std::uintptr_t Ready = 0x8; // "PartyReadyCheckStatusDescription"
            inline constexpr std::uintptr_t NotReady = 0x10; // "PartyReadyCheckStatusDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Enum = 0x40BD850; // "public static ReadOnlyEnum<PartyReadyCheckStatusDescription> get_Enum()"
        }
    } // namespace PartyReadyCheckStatusDescription

    namespace PlayerAuthorColorRule { // "Game.Global.Chat.PlayerAuthorColorRule (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t publicIdModel = 0x10; // "PublicIdModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t TryGetColorType = 0x36D5A00; // "public bool TryGetColorType(long publicId, out UserColorType colorType)"
        }
    } // namespace PlayerAuthorColorRule

    namespace PopupClanDialogCooldownUpdater { // "Game.Global.Clan.PopupClan.PopupClanDialogCooldownUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t clanModel = 0x10; // "ClanModel"
            inline constexpr std::uintptr_t dialogView = 0x18; // "PopupClanDialogView"
            inline constexpr std::uintptr_t now = 0x20; // "INow"
            inline constexpr std::uintptr_t coinsAccessModel = 0x28; // "CoinsAccessModel"
            inline constexpr std::uintptr_t isCreateCooldownOver = 0x30; // "Nullable<bool>"
            inline constexpr std::uintptr_t isCreateActive = 0x32; // "Nullable<bool>"
            inline constexpr std::uintptr_t isJoinActive = 0x34; // "Nullable<bool>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x3690830; // "public void Update()"
            inline constexpr std::uintptr_t CheckConditions = 0x3690810; // "private bool CheckConditions()"
        }
    } // namespace PopupClanDialogCooldownUpdater

    namespace PopupClanDialogInputUpdater { // "Game.Global.Clan.PopupClan.PopupClanDialogInputUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t needBankAccountNotify = 0x10; // "LocalizedString"
            inline constexpr std::uintptr_t dialogModel = 0x18; // "PopupClanDialogModel"
            inline constexpr std::uintptr_t globalModel = 0x20; // "GlobalModel"
            inline constexpr std::uintptr_t coinsAccessModel = 0x28; // "CoinsAccessModel"
            inline constexpr std::uintptr_t Handlers = 0x30; // "ValueTuple<InputMask, IUpdater>[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t OnJoin = 0x3690CF0; // "private void OnJoin()"
            inline constexpr std::uintptr_t OnCreate = 0x3690BF0; // "private void OnCreate()"
            inline constexpr std::uintptr_t OnClose = 0xB1DF00; // "private void OnClose()"
            inline constexpr std::uintptr_t get_Priority = 0x7E5D90; // "public InputHandlerPriority get_Priority()"
        }
    } // namespace PopupClanDialogInputUpdater

    namespace PopupClanDialogUpdater { // "Game.Global.Clan.PopupClan.PopupClanDialogUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t updater = 0x10; // "IUpdater"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x36913E0; // "public void Update()"
        }
    } // namespace PopupClanDialogUpdater

    namespace PopupClanDialogView { // "Game.Global.Clan.PopupClan.PopupClanDialogView (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t CreateButton = 0x20; // "ClickableButtonWithLoadingView"
            inline constexpr std::uintptr_t JoinButton = 0x28; // "ClickableButtonWithLoadingView"
            inline constexpr std::uintptr_t Close = 0x30; // "CompositeButtonView"
            inline constexpr std::uintptr_t CloseBg = 0x38; // "CompositeButtonView"
            inline constexpr std::uintptr_t Conditions = 0x40; // "PopupClanDialogView.Condition[]"
        }
    } // namespace PopupClanDialogView

    namespace PopupClanDialogView_Condition { // "Game.Global.Clan.PopupClan.PopupClanDialogView.Condition (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Type = 0x0; // "PopupClanDialogView.ConditionType"
            inline constexpr std::uintptr_t State = 0x8; // "EnumStateElement<PopupClanDialogView.ConditionState>"
        }
    } // namespace PopupClanDialogView_Condition

    namespace PopupNotification_Clan { // "Game.Global.PopupNotificationDialog.PopupNotification.Clan (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Tag = 0x20; // "string"
            inline constexpr std::uintptr_t ClanId = 0x28; // "string"
            inline constexpr std::uintptr_t ClanName = 0x30; // "string"
            inline constexpr std::uintptr_t InvitingNickname = 0x38; // "string"
            inline constexpr std::uintptr_t Emblem = 0x40; // "ClanEmblemDescription"
            inline constexpr std::uintptr_t ReputationPoints = 0x48; // "int"
        }
    } // namespace PopupNotification_Clan

    namespace PostAppointmentInClanChatUpdater { // "Game.Global.Clan.PostAppointmentInClanChatUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t clanModel = 0x10; // "ClanModel"
            inline constexpr std::uintptr_t clanChat = 0x18; // "SystemChatMessageSource"
            inline constexpr std::uintptr_t chatLocalization = 0x20; // "ChatLocalization"
            inline constexpr std::uintptr_t conquestObjectsViewDescriptions = 0x28; // "ClanConquestObjectTypeViewDescriptions"
            inline constexpr std::uintptr_t conquestSectorViewDescriptions = 0x30; // "SectorsViewDescription"
            inline constexpr std::uintptr_t now = 0x38; // "INow"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x3675A40; // "public void Update()"
        }
    } // namespace PostAppointmentInClanChatUpdater

    namespace PostClanLogsInClanChatUpdater { // "Game.Global.Clan.PostClanLogsInClanChatUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t clanModel = 0x10; // "ClanModel"
            inline constexpr std::uintptr_t chat = 0x18; // "SystemChatMessageSource"
            inline constexpr std::uintptr_t chatLocalization = 0x20; // "ChatLocalization"
            inline constexpr std::uintptr_t clanRankViewDescriptions = 0x28; // "ClanRankViewDescriptions"
            inline constexpr std::uintptr_t conquestObjectsViewDescriptions = 0x30; // "ClanConquestObjectTypeViewDescriptions"
            inline constexpr std::uintptr_t conquestSectorViewDescriptions = 0x38; // "SectorsViewDescription"
            inline constexpr std::uintptr_t now = 0x40; // "INow"
            inline constexpr std::uintptr_t lastLogSlot = 0x48; // "ClanLogSlotDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x3677850; // "public void Update()"
            inline constexpr std::uintptr_t IncIndex = 0x36761D0; // "private void IncIndex(ref int index)"
            inline constexpr std::uintptr_t IndexOf = 0x3676260; // "private int IndexOf(ClanLogSlotDescription slot)"
            inline constexpr std::uintptr_t FromIndex = 0x3676140; // "private ClanLogSlotDescription FromIndex(int index)"
            inline constexpr std::uintptr_t PrintLog = 0x3676270; // "private void PrintLog(int index)"
            inline constexpr std::uintptr_t TryLogToMessage = 0x36764E0; // "private bool TryLogToMessage(ClanLogValue value, out ValueTuple<long, string, string> result)"
        }
    } // namespace PostClanLogsInClanChatUpdater

    namespace PostPartyEventsToPartyChatUpdater { // "Game.Global.Party.PostPartyEventsToPartyChatUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t partyModel = 0x10; // "PartyModel"
            inline constexpr std::uintptr_t now = 0x18; // "INow"
            inline constexpr std::uintptr_t chatLocalization = 0x20; // "ChatLocalization"
            inline constexpr std::uintptr_t chatSource = 0x28; // "SystemChatMessageSource"
            inline constexpr std::uintptr_t oldMembers = 0x30; // "PostPartyEventsToPartyChatUpdater.PartyMember[]"
            inline constexpr std::uintptr_t wasInParty = 0x38; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x37A3C40; // "public void Update()"
            inline constexpr std::uintptr_t ResolvePartyRoster = 0x37A35E0; // "private void ResolvePartyRoster()"
            inline constexpr std::uintptr_t ResolveInParty = 0x37A3000; // "private void ResolveInParty(out bool isInParty)"
        }
    } // namespace PostPartyEventsToPartyChatUpdater

    namespace PostPartyEventsToPartyChatUpdater_PartyMember { // "Game.Global.Party.PostPartyEventsToPartyChatUpdater.PartyMember (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t PublicId = 0x0; // "long"
            inline constexpr std::uintptr_t ClanTag = 0x8; // "string"
            inline constexpr std::uintptr_t Nickname = 0x10; // "string"
        }
    } // namespace PostPartyEventsToPartyChatUpdater_PartyMember

    namespace PrivateChannel { // "Game.Global.Chat.PrivateChannel (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t PredictedChat = 0x10; // "SystemChatMessageSource"
            inline constexpr std::uintptr_t Channel = 0x18; // "ChatChannelModel"
            inline constexpr std::uintptr_t PublicId = 0x20; // "long"
            inline constexpr std::uintptr_t Nickname = 0x28; // "string"
            inline constexpr std::uintptr_t IsTemporary = 0x30; // "bool"
        }
    } // namespace PrivateChannel

    namespace PrivateChatChannelsModel { // "Game.Global.Chat.PrivateChatChannelsModel (Global.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x819C310; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace Fields {
            inline constexpr std::uintptr_t PrivateChannels = 0x10; // "Dictionary<long, PrivateChannel>"
            inline constexpr std::uintptr_t SelectedChannel = 0x18; // "PrivateChannel"
            inline constexpr std::uintptr_t IsAnyNotificationAllowed = 0x20; // "bool"
            inline constexpr std::uintptr_t IsHiddenWhileEmpty = 0x21; // "bool"
            inline constexpr std::uintptr_t AuthorColorRules = 0x28; // "IChatAuthorColorRule[]"
        }
        namespace StaticFields {
            inline constexpr std::uintptr_t alwaysFalse = 0x0; // "Predicate<ChatMessageModel>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_HasNewMessageNotification = 0x36D6580; // "public bool get_HasNewMessageNotification()"
            inline constexpr std::uintptr_t TryAddTemporaryChannel = 0x36D6080; // "public void TryAddTemporaryChannel(long publicId, string nickname, PrivateChatContext chatContext)"
            inline constexpr std::uintptr_t Refresh = 0x36D5AC0; // "public void Refresh(long publicId, PrivateChatUserData userData, PrivateChatContext chatContext)"
            inline constexpr std::uintptr_t Remove = 0x36D6020; // "public void Remove(long publicId)"
            inline constexpr std::uintptr_t Filter = 0x36D5A60; // "private static bool Filter(ChatMessageModel msg, long publicId, PrivateChatContext chatContext)"
        }
    } // namespace PrivateChatChannelsModel

    namespace PrivateChatContactsViewUpdater { // "Game.Global.Chat.PrivateChatContactsViewUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t chatDialogView = 0x10; // "ChatDialogView"
            inline constexpr std::uintptr_t userColorViewDescriptions = 0x18; // "UserColorViewDescriptions"
            inline constexpr std::uintptr_t privatesModel = 0x20; // "PrivateChatChannelsModel"
            inline constexpr std::uintptr_t order = 0x28; // "List<PrivateChannel>"
            inline constexpr std::uintptr_t views = 0x30; // "Dictionary<long, ValueTuple<PrivateChannel, IDisposableContent<PrivateChatContactView>, long>>"
            inline constexpr std::uintptr_t toRemove = 0x38; // "List<long>"
            inline constexpr std::uintptr_t contactTemplate = 0x40; // "IComponentInstantiateContent<PrivateChatContactView>"
            inline constexpr std::uintptr_t clickableChannels = 0x48; // "ClickableItemsModel<PrivateChannel>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x36D6AC0; // "public void Update()"
        }
    } // namespace PrivateChatContactsViewUpdater

    namespace PrivateChatContactsViewUpdater_Comparer { // "Game.Global.Chat.PrivateChatContactsViewUpdater.Comparer (Global.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x827B5B8; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t Instance = 0x0; // "PrivateChatContactsViewUpdater.Comparer"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Compare = 0x36D12C0; // "public int Compare(PrivateChannel x, PrivateChannel y)"
            inline constexpr std::uintptr_t GetLastMessageTimestamp = 0x36D1420; // "private static long GetLastMessageTimestamp(PrivateChannel privateChannel)"
        }
    } // namespace PrivateChatContactsViewUpdater_Comparer

    namespace PrivateChatContactView { // "Game.Global.Chat.PrivateChatContactView (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t TextLabel = 0x20; // "TMP_Text"
            inline constexpr std::uintptr_t Button = 0x28; // "CompositeButtonView"
            inline constexpr std::uintptr_t notification = 0x30; // "Image"
            inline constexpr std::uintptr_t colorGraphics = 0x38; // "GraphicsPalette[]"
            inline constexpr std::uintptr_t rectTransform = 0x40; // "RectTransform"
            inline constexpr std::uintptr_t lastColor = 0x48; // "PaletteColor"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_RectTransform = 0x36D67D0; // "public RectTransform get_RectTransform()"
            inline constexpr std::uintptr_t SetNotificationVisible = 0xD7EF00; // "public void SetNotificationVisible(bool isVisible)"
            inline constexpr std::uintptr_t Content_ContentWrappers_IComponentContent_ResetOnDisposeContent = 0x35FFF30; // "private void Content.ContentWrappers.IComponentContent.ResetOnDisposeContent()"
            inline constexpr std::uintptr_t SetColor = 0x36D66F0; // "public void SetColor(PaletteColor color)"
        }
    } // namespace PrivateChatContactView

    namespace PrivateChatContext { // "Game.Global.Chat.PrivateChatContext (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t PublicIdModel = 0x10; // "PublicIdModel"
            inline constexpr std::uintptr_t Room = 0x18; // "IRoomConnection"
            inline constexpr std::uintptr_t Sources = 0x20; // "List<IChatMessageSource>"
            inline constexpr std::uintptr_t Cooldown = 0x28; // "ExpiringResourceModel"
            inline constexpr std::uintptr_t Now = 0x30; // "INow"
        }
    } // namespace PrivateChatContext

    namespace PrivateChatFilterDescription { // "Models.Models.SocialModels.PrivateChatFilterDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x819C7D0; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t enum_id = 0x0; // "Enum<PrivateChatFilterDescription>"
            inline constexpr std::uintptr_t All = 0x8; // "PrivateChatFilterDescription"
            inline constexpr std::uintptr_t None = 0x10; // "PrivateChatFilterDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Enum = 0x48B9B20; // "public static ReadOnlyEnum<PrivateChatFilterDescription> get_Enum()"
        }
    } // namespace PrivateChatFilterDescription

    namespace PrivateChatListUpdater { // "Game.Global.Chat.PrivateChatListUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t usersData = 0x10; // "PrivateChatUsersData"
            inline constexpr std::uintptr_t blacklistData = 0x18; // "BlacklistData"
            inline constexpr std::uintptr_t chatChannels = 0x20; // "PrivateChatChannelsModel"
            inline constexpr std::uintptr_t toRemove = 0x28; // "List<long>"
            inline constexpr std::uintptr_t privateChatContext = 0x30; // "PrivateChatContext"
            inline constexpr std::uintptr_t accessRules = 0x38; // "ChatAccessRules"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x36D7940; // "public void Update()"
        }
    } // namespace PrivateChatListUpdater

    namespace PrivateChatMessageData { // "Models.Data.Chat.PrivateChatMessageData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Ts = 0x20; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t PublicId = 0x28; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t Message = 0x30; // "IPrimitiveData<string>"
        }
    } // namespace PrivateChatMessageData

    namespace PrivateChatTabViewUpdater { // "Game.Global.Chat.PrivateChatTabViewUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t globalModel = 0x10; // "GlobalModel"
            inline constexpr std::uintptr_t privateChat = 0x18; // "PrivateChatChannelsModel"
            inline constexpr std::uintptr_t contactsViewUpdater = 0x20; // "IUpdater"
            inline constexpr std::uintptr_t view = 0x28; // "ChatDialogView"
            inline constexpr std::uintptr_t messageTemplate = 0x30; // "IComponentInstantiateContent<ChatMessageView>"
            inline constexpr std::uintptr_t chatViewDescription = 0x38; // "ChatViewDescription"
            inline constexpr std::uintptr_t userColorViewDescriptions = 0x40; // "UserColorViewDescriptions"
            inline constexpr std::uintptr_t clickableMessages = 0x48; // "ClickableItemsModel<ChatMessagePair>"
            inline constexpr std::uintptr_t disposable = 0x50; // "IRegisterDisposable"
            inline constexpr std::uintptr_t updater = 0x58; // "IUpdater"
            inline constexpr std::uintptr_t wasSelected = 0x60; // "PrivateChannel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x36D8410; // "public void Update()"
            inline constexpr std::uintptr_t ResolveSelectedChannel = 0x36D81E0; // "private void ResolveSelectedChannel()"
        }
    } // namespace PrivateChatTabViewUpdater

    namespace PrivateChatUserData { // "Models.Data.Chat.PrivateChatUserData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Ts = 0x20; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t Name = 0x28; // "IPrimitiveData<string>"
        }
    } // namespace PrivateChatUserData

    namespace ProtectionContext { // "Game.Global.Clan.Model.ProtectionContext (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ClanBattleAuctionPeriodConfig = 0x10; // "ClanBattleAuctionPeriodConfig"
            inline constexpr std::uintptr_t ClanBattleTier = 0x18; // "ClanBattleTierDescription"
        }
    } // namespace ProtectionContext

    namespace ProtectionContext_ConquestObject { // "Game.Global.Clan.Model.ProtectionContext.ConquestObject (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Description = 0x20; // "ClanConquestObjectTypeDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t GetBetMinAmount = 0x368FE00; // "public override int GetBetMinAmount(RealmVersion realmVersion)"
        }
    } // namespace ProtectionContext_ConquestObject

    namespace ProtectionContext_Sector { // "Game.Global.Clan.Model.ProtectionContext.Sector (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Description = 0x20; // "SectorDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t GetBetMinAmount = 0x3692ED0; // "public override int GetBetMinAmount(RealmVersion realmVersion)"
        }
    } // namespace ProtectionContext_Sector

    namespace ProtectionScheduleTimePanelView { // "Game.Global.Clan.ProtectionSchedule.ProtectionScheduleTimePanelView (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t BetsPhaseState = 0x20; // "EnumStateElement<ProtectionScheduleTimePanelView.PhaseState>"
            inline constexpr std::uintptr_t BetsPhaseTimeLabel = 0x28; // "TextLabel<TimeSpan, TimeSpan>"
            inline constexpr std::uintptr_t ConflictPhaseState = 0x30; // "EnumStateElement<ProtectionScheduleTimePanelView.PhaseState>"
            inline constexpr std::uintptr_t ConflictPhaseTimeLabel = 0x38; // "TextLabel<TimeSpan, TimeSpan>"
        }
    } // namespace ProtectionScheduleTimePanelView

    namespace ProtectionScheduleTooltipUpdater { // "Game.Global.Clan.ProtectionSchedule.ProtectionScheduleTooltipUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t inputModel = 0x10; // "InputModel"
            inline constexpr std::uintptr_t clanModel = 0x18; // "ClanModel"
            inline constexpr std::uintptr_t realmInfoModel = 0x20; // "RealmInfoModel"
            inline constexpr std::uintptr_t protectionContext = 0x28; // "ProtectionContext"
            inline constexpr std::uintptr_t now = 0x30; // "INow"
            inline constexpr std::uintptr_t uiSoundModel = 0x38; // "GlobalUISoundModel"
            inline constexpr std::uintptr_t tooltipView = 0x40; // "ProtectionScheduleTooltipView"
            inline constexpr std::uintptr_t periodConfig = 0x48; // "ClanBattleAuctionPeriodConfig"
            inline constexpr std::uintptr_t phaseTimesConfig = 0x50; // "ClanBattlePhaseTimesConfig"
            inline constexpr std::uintptr_t timePanels = 0x58; // "List<IDisposableContent<ProtectionScheduleTimePanelView>>"
            inline constexpr std::uintptr_t startOffsetIndex = 0x60; // "int"
            inline constexpr std::uintptr_t nextRefreshTs = 0x68; // "long"
            inline constexpr std::uintptr_t isOpen = 0x70; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x36927C0; // "public void Update()"
            inline constexpr std::uintptr_t GetStartOffsetIndex = 0x3692200; // "private int GetStartOffsetIndex()"
            inline constexpr std::uintptr_t RefreshTimePanels = 0x36923E0; // "private void RefreshTimePanels(long now)"
            inline constexpr std::uintptr_t GetPhaseState = 0x36921F0; // "private static ProtectionScheduleTimePanelView.PhaseState GetPhaseState(long phaseEndTs, long now)"
            inline constexpr std::uintptr_t RefreshOnPhaseEnd = 0x3692360; // "private void RefreshOnPhaseEnd(long phaseEndTs, long now)"
            inline constexpr std::uintptr_t GetLocalTimeOfDay = 0x36920D0; // "private static TimeSpan GetLocalTimeOfDay(long ts)"
            inline constexpr std::uintptr_t ClearTimePanels = 0x3691EE0; // "private void ClearTimePanels()"
        }
    } // namespace ProtectionScheduleTooltipUpdater

    namespace ProtectionScheduleTooltipView { // "Game.Global.Clan.ProtectionSchedule.ProtectionScheduleTooltipView (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t RealTimeLabel = 0x20; // "TextLabel<TimeSpan>"
            inline constexpr std::uintptr_t TimePanelsParent = 0x28; // "RectTransform"
        }
    } // namespace ProtectionScheduleTooltipView

    namespace PublicClanConquestSectorData { // "Models.Data.Clan.PublicClanConquestSectorData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ClanId = 0x20; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t ClanTag = 0x28; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t ClanName = 0x30; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t Emblem = 0x38; // "IPrimitiveData<ClanEmblemDescription>"
            inline constexpr std::uintptr_t ClanBattleStartOffsetIndex = 0x40; // "IPrimitiveData<int>"
        }
    } // namespace PublicClanConquestSectorData

    namespace PublishAnnouncementClanMessage { // "Models.Messages.Clan.PublishAnnouncementClanMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t announcement = 0x20; // "IPrimitiveData<string>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Announcement = 0x4A2D880; // "public string get_Announcement()"
            inline constexpr std::uintptr_t get_Type = 0x4A2D8D0; // "public override string get_Type()"
        }
    } // namespace PublishAnnouncementClanMessage

    namespace ReadyCheckPartyMessage { // "Models.Messages.ReadyCheck.ReadyCheckPartyMessage (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x4A0C4B0; // "public override string get_Type()"
        }
    } // namespace ReadyCheckPartyMessage

    namespace RealmChatUpdater { // "Game.Global.Chat.RealmChatUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t realm = 0x10; // "RegionUserRealmModel"
            inline constexpr std::uintptr_t realmInfoModel = 0x18; // "RealmInfoModel"
            inline constexpr std::uintptr_t blackListModel = 0x20; // "BlackListModel"
            inline constexpr std::uintptr_t badWordsFilter = 0x28; // "BadWordsFilterModel"
            inline constexpr std::uintptr_t chatCooldown = 0x30; // "ExpiringResourceModel"
            inline constexpr std::uintptr_t rulesSource = 0x38; // "SystemChatMessageSource"
            inline constexpr std::uintptr_t realmChatSettings = 0x40; // "ChatSourceSettings"
            inline constexpr std::uintptr_t chatsModel = 0x48; // "ChatsModel"
            inline constexpr std::uintptr_t regionUserRoom = 0x50; // "IRoomConnection"
            inline constexpr std::uintptr_t receivedRequestsModel = 0x58; // "ReceivedRequestsModel"
            inline constexpr std::uintptr_t chatLocalization = 0x60; // "ChatLocalization"
            inline constexpr std::uintptr_t realmNames = 0x68; // "RealmNamesViewDescription"
            inline constexpr std::uintptr_t now = 0x70; // "INow"
            inline constexpr std::uintptr_t realmInfoSourceModel = 0x78; // "IRealmInfoSourceModel"
            inline constexpr std::uintptr_t accessRules = 0x80; // "ChatAccessRules"
            inline constexpr std::uintptr_t updater = 0x88; // "IUpdater"
            inline constexpr std::uintptr_t disposable = 0x90; // "IRegisterDisposable"
            inline constexpr std::uintptr_t hasRealm = 0x98; // "bool"
            inline constexpr std::uintptr_t realm1stName = 0x9C; // "int"
            inline constexpr std::uintptr_t realm2ndName = 0xA0; // "int"
            inline constexpr std::uintptr_t isChatInited = 0xA4; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x36D9750; // "public void Update()"
            inline constexpr std::uintptr_t ResolveInited = 0x36D9490; // "private void ResolveInited()"
            inline constexpr std::uintptr_t ResolveInRealm = 0x36D8DF0; // "private void ResolveInRealm()"
        }
    } // namespace RealmChatUpdater

    namespace RealmClanConquestObjectData { // "Models.Data.RealmInfo.ClanConquestObjects.RealmClanConquestObjectData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ClanId = 0x20; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t ClanTag = 0x28; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t ClanName = 0x30; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t Emblem = 0x38; // "IPrimitiveData<ClanEmblemDescription>"
            inline constexpr std::uintptr_t ClanBattleStartOffsetIndex = 0x40; // "IPrimitiveData<int>"
        }
    } // namespace RealmClanConquestObjectData

    namespace RealmClanConquestSectorData { // "Models.Data.RealmInfo.ClanConquestSectors.RealmClanConquestSectorData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ClanId = 0x20; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t ClanTag = 0x28; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t ClanName = 0x30; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t Emblem = 0x38; // "IPrimitiveData<ClanEmblemDescription>"
            inline constexpr std::uintptr_t ClanBattleStartOffsetIndex = 0x40; // "IPrimitiveData<int>"
        }
    } // namespace RealmClanConquestSectorData

    namespace RegionUserClanData { // "Models.Data.Clan.RegionUserClanData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Id = 0x20; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t Name = 0x28; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t Tag = 0x30; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t Rank = 0x38; // "IPrimitiveData<ClanRankDescription>"
        }
    } // namespace RegionUserClanData

    namespace RegionUserClanInviteData { // "Models.Data.Clan.RegionUserClanInviteData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ClanId = 0x20; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t ClanName = 0x28; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t Tag = 0x30; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t Emblem = 0x38; // "IPrimitiveData<ClanEmblemDescription>"
            inline constexpr std::uintptr_t UserName = 0x40; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t ExpirationTs = 0x48; // "IPrimitiveData<long>"
        }
    } // namespace RegionUserClanInviteData

    namespace RegionUserClanModel { // "Models.Models.RegionUserClan.RegionUserClanModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t isCreating = 0x10; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t clanJoinType = 0x18; // "IPrimitiveData<ClanJoinTypeDescription>"
            inline constexpr std::uintptr_t isRequesting = 0x20; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t isLeaving = 0x28; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t leavingReason = 0x30; // "IPrimitiveData<ClanLeavingReasonDescription>"
            inline constexpr std::uintptr_t userClan = 0x38; // "RegionUserClanData"
            inline constexpr std::uintptr_t createClanCooldownTs = 0x40; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t joinClanCooldownTs = 0x48; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t ClanData = 0x50; // "IData"
            inline constexpr std::uintptr_t IsClanDataActual = 0x58; // "IPrimitiveModel<bool>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_CanPerformInClanActions = 0x48DFA00; // "public bool get_CanPerformInClanActions()"
            inline constexpr std::uintptr_t get_CanPerformNotInClanActions = 0x48DFAE0; // "public bool get_CanPerformNotInClanActions()"
            inline constexpr std::uintptr_t get_IsCreating = 0x48DFCC0; // "public bool get_IsCreating()"
            inline constexpr std::uintptr_t get_IsJoining = 0x48DFD10; // "public bool get_IsJoining()"
            inline constexpr std::uintptr_t get_JoinType = 0x48DFEB0; // "public ClanJoinTypeDescription get_JoinType()"
            inline constexpr std::uintptr_t get_IsLeaving = 0x48DFDC0; // "public bool get_IsLeaving()"
            inline constexpr std::uintptr_t get_LeavingReason = 0x48DFF70; // "public ClanLeavingReasonDescription get_LeavingReason()"
            inline constexpr std::uintptr_t get_IsRequesting = 0x48DFE10; // "public bool get_IsRequesting()"
            inline constexpr std::uintptr_t set_IsRequesting = 0x48E01A0; // "public void set_IsRequesting(bool value)"
            inline constexpr std::uintptr_t get_HasClanId = 0x48DFC10; // "public bool get_HasClanId()"
            inline constexpr std::uintptr_t get_Id = 0x48DFC70; // "public string get_Id()"
            inline constexpr std::uintptr_t get_Name = 0x48E0030; // "public string get_Name()"
            inline constexpr std::uintptr_t get_Tag = 0x48E0150; // "public string get_Tag()"
            inline constexpr std::uintptr_t get_Rank = 0x48E0080; // "public ClanRankDescription get_Rank()"
            inline constexpr std::uintptr_t set_Rank = 0x48E0200; // "public void set_Rank(ClanRankDescription value)"
            inline constexpr std::uintptr_t get_CreateClanCooldownTs = 0x48DFBC0; // "public long get_CreateClanCooldownTs()"
            inline constexpr std::uintptr_t get_JoinClanCooldownTs = 0x48DFE60; // "public long get_JoinClanCooldownTs()"
            inline constexpr std::uintptr_t StartCreate = 0x48DF610; // "public void StartCreate(string id, string name, string tag)"
            inline constexpr std::uintptr_t CancelCreate = 0x48DEF30; // "public void CancelCreate()"
            inline constexpr std::uintptr_t FinishCreate = 0x48DF1B0; // "public void FinishCreate()"
            inline constexpr std::uintptr_t SetClanData = 0x48DF500; // "private void SetClanData(string id, string name, string tag)"
            inline constexpr std::uintptr_t UnsetClanData = 0x48DF770; // "private void UnsetClanData()"
            inline constexpr std::uintptr_t StartJoin = 0x48DF6D0; // "public void StartJoin(string id, ClanJoinTypeDescription joinType)"
            inline constexpr std::uintptr_t CancelJoin = 0x48DEF90; // "public void CancelJoin()"
            inline constexpr std::uintptr_t FinishJoin = 0x48DF200; // "public void FinishJoin(string name, string tag)"
            inline constexpr std::uintptr_t LeaveAsMember = 0x48DF380; // "public void LeaveAsMember(long now)"
            inline constexpr std::uintptr_t LeaveAsLeader = 0x48DF2C0; // "public void LeaveAsLeader(long now)"
            inline constexpr std::uintptr_t ResetCooldowns = 0x48DF440; // "public void ResetCooldowns()"
            inline constexpr std::uintptr_t SetLeaving = 0x48DF580; // "public void SetLeaving(ClanLeavingReasonDescription reason)"
            inline constexpr std::uintptr_t UnsetLeaving = 0x48DF840; // "public void UnsetLeaving()"
            inline constexpr std::uintptr_t Clear = 0x48DF010; // "public void Clear()"
        }
    } // namespace RegionUserClanModel

    namespace RegionUserClanRequestData { // "Models.Data.Clan.RegionUserClanRequestData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ClanId = 0x20; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t ExpirationTs = 0x28; // "IPrimitiveData<long>"
        }
    } // namespace RegionUserClanRequestData

    namespace RegionUserCreateClanData { // "Models.Data.Clan.RegionUserCreateClanData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t EnterType = 0x20; // "IPrimitiveData<ClanEnterTypeDescription>"
            inline constexpr std::uintptr_t Language = 0x28; // "IPrimitiveData<ClanLanguageDescription>"
            inline constexpr std::uintptr_t Emblem = 0x30; // "IPrimitiveData<ClanEmblemDescription>"
            inline constexpr std::uintptr_t Description = 0x38; // "IPrimitiveData<string>"
        }
    } // namespace RegionUserCreateClanData

    namespace RegionUserPartyData { // "Models.Data.Party.RegionUserPartyData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t PartyId = 0x20; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t IsRequesting = 0x28; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t Invites = 0x30; // "ReferenceMapData<PartyInviteSlotDescription, UserPartyInviteData>"
        }
    } // namespace RegionUserPartyData

    namespace RegionUserPartyModelUpdater { // "Game.Network.RegionUserPartyModelUpdater (Game.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t partyModel = 0x10; // "PartyModel"
            inline constexpr std::uintptr_t publicIdModel = 0x18; // "PublicIdModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x10DDB40; // "public void Update()"
        }
    } // namespace RegionUserPartyModelUpdater

    namespace RejectClanRequestMessage { // "Models.Messages.Clan.RejectClanRequestMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t publicId = 0x20; // "IPrimitiveData<long>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_PublicId = 0x4A2DA90; // "public long get_PublicId()"
            inline constexpr std::uintptr_t get_Type = 0x4A2DAE0; // "public override string get_Type()"
        }
    } // namespace RejectClanRequestMessage

    namespace RemoveMailsMessage { // "Models.Messages.Mail.RemoveMailsMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t mailIds = 0x20; // "ListData<IPrimitiveData<int>>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_MailIds = 0x4A0CCA0; // "public List<int> get_MailIds()"
            inline constexpr std::uintptr_t get_Type = 0x4A0CDD0; // "public override string get_Type()"
        }
    } // namespace RemoveMailsMessage

    namespace RemoveUserFromBlacklistMessage { // "Models.Messages.Chat.RemoveUserFromBlacklistMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t publicId = 0x20; // "IPrimitiveData<long>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_PublicId = 0x4A2DCA0; // "public long get_PublicId()"
            inline constexpr std::uintptr_t get_Type = 0x4A2DCF0; // "public override string get_Type()"
        }
    } // namespace RemoveUserFromBlacklistMessage

    namespace SendClanRequestMessage { // "Models.Messages.Clan.SendClanRequestMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t clanId = 0x20; // "IPrimitiveData<string>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_ClanId = 0x4A2DEB0; // "public string get_ClanId()"
            inline constexpr std::uintptr_t get_Type = 0x4A2DF00; // "public override string get_Type()"
        }
    } // namespace SendClanRequestMessage

    namespace SendMessageInChatMessage { // "Models.Messages.Chat.SendMessageInChatMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t message = 0x20; // "IPrimitiveData<string>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Message = 0x4A2E040; // "public string get_Message()"
        }
    } // namespace SendMessageInChatMessage

    namespace SendMessageInClanChatMessage { // "Models.Messages.Chat.SendMessageInClanChatMessage (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x4A2E0A0; // "public override string get_Type()"
        }
    } // namespace SendMessageInClanChatMessage

    namespace SendMessageInCopsChatMessage { // "Models.Messages.Chat.SendMessageInCopsChatMessage (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x4A2E0D0; // "public override string get_Type()"
        }
    } // namespace SendMessageInCopsChatMessage

    namespace SendMessageInPartyChatMessage { // "Models.Messages.Chat.SendMessageInPartyChatMessage (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x4A2E130; // "public override string get_Type()"
        }
    } // namespace SendMessageInPartyChatMessage

    namespace SendMessageInPrivateChatMessage { // "Models.Messages.Chat.SendMessageInPrivateChatMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t publicId = 0x28; // "IPrimitiveData<long>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t AddProperties = 0x4A2E160; // "private void AddProperties()"
            inline constexpr std::uintptr_t get_PublicId = 0x4A2E390; // "public long get_PublicId()"
            inline constexpr std::uintptr_t get_Type = 0x4A2E3E0; // "public override string get_Type()"
        }
    } // namespace SendMessageInPrivateChatMessage

    namespace SendMessageInRealmChatMessage { // "Models.Messages.Chat.SendMessageInRealmChatMessage (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x4A2E410; // "public override string get_Type()"
        }
    } // namespace SendMessageInRealmChatMessage

    namespace SetChatFilterSettingsMessage { // "Models.Messages.Chat.SetChatFilterSettingsMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t privateChatFilter = 0x20; // "IPrimitiveData<PrivateChatFilterDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_PrivateChatFilter = 0x4A2E730; // "public PrivateChatFilterDescription get_PrivateChatFilter()"
            inline constexpr std::uintptr_t get_Type = 0x4A2E7F0; // "public override string get_Type()"
        }
    } // namespace SetChatFilterSettingsMessage

    namespace StartPartyHubMessage { // "Models.Messages.Party.StartPartyHubMessage (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x4A11260; // "public override string get_Type()"
        }
    } // namespace StartPartyHubMessage

    namespace StartPartyRobberyCommand { // "Game.Shared.StartPartyRobberyCommand (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Description = 0x10; // "LocationDescription"
        }
    } // namespace StartPartyRobberyCommand

    namespace StartPartyRobberyMessage { // "Models.Messages.Party.StartPartyRobberyMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t description = 0x20; // "IPrimitiveData<LocationDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Description = 0x4A11520; // "public LocationDescription get_Description()"
            inline constexpr std::uintptr_t get_Type = 0x4A11570; // "public override string get_Type()"
        }
    } // namespace StartPartyRobberyMessage

    namespace StartPartySectorCenterCommand { // "Game.Shared.StartPartySectorCenterCommand (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Sector = 0x10; // "SectorDescription"
        }
    } // namespace StartPartySectorCenterCommand

    namespace StartPartySectorCenterMessage { // "Models.Messages.Party.StartPartySectorCenterMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t sector = 0x20; // "IPrimitiveData<SectorDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Sector = 0x4A117E0; // "public SectorDescription get_Sector()"
            inline constexpr std::uintptr_t get_Type = 0x4A11830; // "public override string get_Type()"
        }
    } // namespace StartPartySectorCenterMessage

    namespace SteamFriend { // "Game.Steam.SteamFriend (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t SteamId = 0x10; // "ulong"
            inline constexpr std::uintptr_t Nickname = 0x18; // "string"
            inline constexpr std::uintptr_t Avatar = 0x20; // "Texture2D"
            inline constexpr std::uintptr_t PublicId = 0x28; // "long"
            inline constexpr std::uintptr_t Region = 0x30; // "string"
            inline constexpr std::uintptr_t RealmId = 0x38; // "int"
        }
    } // namespace SteamFriend

    namespace SteamFriendsProvider { // "Game.Global.Steam.Friends.SteamFriendsProvider (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "SteamModel"
            inline constexpr std::uintptr_t friends = 0x18; // "Dictionary<ulong, SteamFriend>"
            inline constexpr std::uintptr_t pendingAvatars = 0x20; // "Queue<SteamFriend>"
            inline constexpr std::uintptr_t friendRichPresenceUpdate = 0x28; // "Callback<FriendRichPresenceUpdate_t>"
            inline constexpr std::uintptr_t personaStateChange = 0x30; // "Callback<PersonaStateChange_t>"
            inline constexpr std::uintptr_t isInitialized = 0x38; // "bool"
            inline constexpr std::uintptr_t isDirty = 0x39; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Dispose = 0x3747910; // "public void Dispose()"
            inline constexpr std::uintptr_t Update = 0x37487F0; // "public void Update()"
            inline constexpr std::uintptr_t Reinitialize = 0x3747F40; // "private void Reinitialize()"
            inline constexpr std::uintptr_t UpdateAvatars = 0x37481C0; // "private void UpdateAvatars()"
            inline constexpr std::uintptr_t CreateAvatar = 0x3747650; // "private static Texture2D CreateAvatar(int handle)"
            inline constexpr std::uintptr_t UpdateFriends = 0x3748400; // "private void UpdateFriends()"
            inline constexpr std::uintptr_t OnFriendRichPresenceUpdate = 0x3747C30; // "private void OnFriendRichPresenceUpdate(FriendRichPresenceUpdate_t pCallback)"
            inline constexpr std::uintptr_t OnPersonaStateChange = 0x3747D80; // "private void OnPersonaStateChange(PersonaStateChange_t pCallback)"
            inline constexpr std::uintptr_t CreateOrUpdateFriend = 0x37477E0; // "private SteamFriend CreateOrUpdateFriend(CSteamID friendId)"
            inline constexpr std::uintptr_t IsFriendPlayingCurrentGame = 0x3747BD0; // "private bool IsFriendPlayingCurrentGame(CSteamID friendId)"
            inline constexpr std::uintptr_t ClearDirtyFlag = 0x3747620; // "private void ClearDirtyFlag()"
            inline constexpr std::uintptr_t UpdateFriendPresence = 0x3748310; // "private static void UpdateFriendPresence(SteamFriend friend, CSteamID friendId)"
        }
    } // namespace SteamFriendsProvider

    namespace SwitchRealmFriendsUpdater { // "Game.Global.SwitchRealmFriendsUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t switchRealmDialog = 0x10; // "SwitchRealmDialogModel"
            inline constexpr std::uintptr_t view = 0x18; // "SwitchRealmDialogView"
            inline constexpr std::uintptr_t steamAdapter = 0x20; // "ISteamAdapter"
            inline constexpr std::uintptr_t region = 0x28; // "string"
            inline constexpr std::uintptr_t friendsVersion = 0x30; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x366A3D0; // "public void Update()"
            inline constexpr std::uintptr_t UpdateStateGroup = 0x366A390; // "private void UpdateStateGroup(bool hasFriendsInRegion)"
            inline constexpr std::uintptr_t UpdateFilterToggle = 0x366A310; // "private void UpdateFilterToggle(bool hasFriendsInRegion)"
            inline constexpr std::uintptr_t HasFriendsInRegion = 0x366A150; // "private bool HasFriendsInRegion()"
        }
    } // namespace SwitchRealmFriendsUpdater

    namespace SystemChatMessageSource { // "Game.Global.Chat.SystemChatMessageSource (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t NewMessageAdded = 0x10; // "List<ChatMessageModel>"
            inline constexpr std::uintptr_t ShouldRaiseNotification = 0x18; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t NewMessage = 0x36DA9C0; // "public SystemChatMessageSource.Builder NewMessage(string message, ChatMessageType type)"
            inline constexpr std::uintptr_t Clear = 0x36DA960; // "public void Clear()"
        }
    } // namespace SystemChatMessageSource

    namespace SystemChatMessageSource_Builder { // "Game.Global.Chat.SystemChatMessageSource.Builder (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t source = 0x0; // "SystemChatMessageSource"
            inline constexpr std::uintptr_t message = 0x8; // "ChatMessageModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t WithAuthor = 0x36C6E20; // "public SystemChatMessageSource.Builder WithAuthor(string author, UserColorType authorNicknameColorType, string clanTag, long publicId)"
            inline constexpr std::uintptr_t WithTime = 0x36C6ED0; // "public SystemChatMessageSource.Builder WithTime(long receiveTs)"
            inline constexpr std::uintptr_t AttachUser = 0x36C6AE0; // "public SystemChatMessageSource.Builder AttachUser(long publicId, string clanTag, string nickname)"
            inline constexpr std::uintptr_t Print = 0x36C6D70; // "public void Print()"
        }
    } // namespace SystemChatMessageSource_Builder

    namespace TaxCollectionClanModel { // "Game.Battle.Taxes.Clan.TaxCollectionClanModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t HasClan = 0x10; // "bool"
            inline constexpr std::uintptr_t IsPlayerLeader = 0x11; // "bool"
            inline constexpr std::uintptr_t IsInClanSettlement = 0x12; // "bool"
            inline constexpr std::uintptr_t HasConquests = 0x13; // "bool"
            inline constexpr std::uintptr_t HasActiveTaxes = 0x14; // "bool"
            inline constexpr std::uintptr_t TaxCooldownEndTs = 0x18; // "long"
            inline constexpr std::uintptr_t TimeToActiveTaxes = 0x20; // "long"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_CanPlayerSeeTimer = 0xD8F820; // "public bool get_CanPlayerSeeTimer()"
            inline constexpr std::uintptr_t get_CanPlayerStartCollection = 0xD8F840; // "public bool get_CanPlayerStartCollection()"
            inline constexpr std::uintptr_t get_CanTakeTax = 0xD8F860; // "public bool get_CanTakeTax()"
        }
    } // namespace TaxCollectionClanModel

    namespace TaxCollectionClanModelUpdater { // "Game.Battle.Taxes.Clan.TaxCollectionClanModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t clanModel = 0x10; // "ClanModel"
            inline constexpr std::uintptr_t settlementModel = 0x18; // "SettlementModel"
            inline constexpr std::uintptr_t taxClanModel = 0x20; // "TaxCollectionClanModel"
            inline constexpr std::uintptr_t now = 0x28; // "INow"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xD8F4C0; // "public void Update()"
        }
    } // namespace TaxCollectionClanModelUpdater

    namespace TaxCollectionClanTabUpdater { // "Game.Battle.Taxes.Dialog.Tabs.TaxCollectionClanTabUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t clanModel = 0x10; // "ClanModel"
            inline constexpr std::uintptr_t taxDialogModel = 0x18; // "TaxCollectionDialogModel"
            inline constexpr std::uintptr_t taxClanModel = 0x20; // "TaxCollectionClanModel"
            inline constexpr std::uintptr_t taxDialogView = 0x28; // "TaxCollectionDialogView"
            inline constexpr std::uintptr_t clanEmblemDescriptions = 0x30; // "ClanEmblemViewDescriptions"
            inline constexpr std::uintptr_t lastMoneyAmount = 0x38; // "long"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xD8FE00; // "public void Update()"
            inline constexpr std::uintptr_t UpdateClan = 0xD8F880; // "private void UpdateClan()"
            inline constexpr std::uintptr_t UpdateTaxes = 0xD8FBC0; // "private void UpdateTaxes()"
            inline constexpr std::uintptr_t UpdateTip = 0xD8FD70; // "private void UpdateTip()"
            inline constexpr std::uintptr_t UpdateTakeButton = 0xD8FA50; // "private void UpdateTakeButton()"
        }
    } // namespace TaxCollectionClanTabUpdater

    namespace TimeStatusView { // "Game.Global.Clan.TimeStatusView (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t time = 0x20; // "TextLabel<int, int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Set = 0x3693320; // "public void Set(TimeSpan timeSpan)"
            inline constexpr std::uintptr_t Set_2 = 0x3693550; // "public void Set(int time, TimeStatus timeStatus)"
        }
    } // namespace TimeStatusView

    namespace UserAddSectorBetMessage { // "Models.Messages.Clan.ClanBattle.UserAddSectorBetMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t sector = 0x20; // "IPrimitiveData<SectorDescription>"
            inline constexpr std::uintptr_t amount = 0x28; // "IPrimitiveData<int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Sector = 0x4A30850; // "public SectorDescription get_Sector()"
            inline constexpr std::uintptr_t get_Amount = 0x4A30800; // "public int get_Amount()"
            inline constexpr std::uintptr_t get_Type = 0x4A308A0; // "public override string get_Type()"
        }
    } // namespace UserAddSectorBetMessage

    namespace UserChangeLeaderClanMessage { // "Models.Messages.Clan.UserChangeLeaderClanMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t memberPublicId = 0x20; // "IPrimitiveData<long>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_MemberPublicId = 0x4A30A60; // "public long get_MemberPublicId()"
            inline constexpr std::uintptr_t get_Type = 0x4A30AB0; // "public override string get_Type()"
        }
    } // namespace UserChangeLeaderClanMessage

    namespace UserChangeObjectStartOffsetIndexMessage { // "Models.Messages.Clan.ClanBattle.UserChangeObjectStartOffsetIndexMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t objectType = 0x20; // "IPrimitiveData<ClanConquestObjectTypeDescription>"
            inline constexpr std::uintptr_t startOffsetIndex = 0x28; // "IPrimitiveData<int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_ObjectType = 0x4A30E20; // "public ClanConquestObjectTypeDescription get_ObjectType()"
            inline constexpr std::uintptr_t get_StartOffsetIndex = 0x4A30E70; // "public int get_StartOffsetIndex()"
            inline constexpr std::uintptr_t get_Type = 0x4A30EC0; // "public override string get_Type()"
        }
    } // namespace UserChangeObjectStartOffsetIndexMessage

    namespace UserChangeSectorStartOffsetIndexMessage { // "Models.Messages.Clan.ClanBattle.UserChangeSectorStartOffsetIndexMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t sector = 0x20; // "IPrimitiveData<SectorDescription>"
            inline constexpr std::uintptr_t startOffsetIndex = 0x28; // "IPrimitiveData<int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Sector = 0x4A31230; // "public SectorDescription get_Sector()"
            inline constexpr std::uintptr_t get_StartOffsetIndex = 0x4A31280; // "public int get_StartOffsetIndex()"
            inline constexpr std::uintptr_t get_Type = 0x4A312D0; // "public override string get_Type()"
        }
    } // namespace UserChangeSectorStartOffsetIndexMessage

    namespace UserChangeSettingsClanMessage { // "Models.Messages.Clan.UserChangeSettingsClanMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t enterType = 0x20; // "IPrimitiveData<ClanEnterTypeDescription>"
            inline constexpr std::uintptr_t language = 0x28; // "IPrimitiveData<ClanLanguageDescription>"
            inline constexpr std::uintptr_t emblem = 0x30; // "IPrimitiveData<ClanEmblemDescription>"
            inline constexpr std::uintptr_t description = 0x38; // "IPrimitiveData<string>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_EnterType = 0x4A317A0; // "public ClanEnterTypeDescription get_EnterType()"
            inline constexpr std::uintptr_t get_Language = 0x4A317F0; // "public ClanLanguageDescription get_Language()"
            inline constexpr std::uintptr_t get_Emblem = 0x4A31750; // "public ClanEmblemDescription get_Emblem()"
            inline constexpr std::uintptr_t get_Description = 0x4A31700; // "public string get_Description()"
            inline constexpr std::uintptr_t get_Type = 0x4A31840; // "public override string get_Type()"
        }
    } // namespace UserChangeSettingsClanMessage

    namespace UserCheatJoinObjectClanBattleMessage { // "Models.Messages.Clan.ClanBattle.UserCheatJoinObjectClanBattleMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t objectType = 0x20; // "IPrimitiveData<ClanConquestObjectTypeDescription>"
            inline constexpr std::uintptr_t team = 0x28; // "IPrimitiveData<ClanBattleTeamDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_ObjectType = 0x4A31CB0; // "public ClanConquestObjectTypeDescription get_ObjectType()"
            inline constexpr std::uintptr_t get_Team = 0x4A31D00; // "public ClanBattleTeamDescription get_Team()"
            inline constexpr std::uintptr_t get_Type = 0x4A31D50; // "public override string get_Type()"
        }
    } // namespace UserCheatJoinObjectClanBattleMessage

    namespace UserCheatJoinSectorClanBattleMessage { // "Models.Messages.Clan.ClanBattle.UserCheatJoinSectorClanBattleMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t sector = 0x20; // "IPrimitiveData<SectorDescription>"
            inline constexpr std::uintptr_t team = 0x28; // "IPrimitiveData<ClanBattleTeamDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Sector = 0x4A321C0; // "public SectorDescription get_Sector()"
            inline constexpr std::uintptr_t get_Team = 0x4A32210; // "public ClanBattleTeamDescription get_Team()"
            inline constexpr std::uintptr_t get_Type = 0x4A32260; // "public override string get_Type()"
        }
    } // namespace UserCheatJoinSectorClanBattleMessage

    namespace UserClanRequestModel { // "Game.Global.Clan.Model.UserClanRequestModel (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "RegionUserClanRequestData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_ClanId = 0x3696950; // "public string get_ClanId()"
            inline constexpr std::uintptr_t get_ExpirationTs = 0x36969A0; // "public long get_ExpirationTs()"
        }
    } // namespace UserClanRequestModel

    namespace UserClanTransferCoinsMessage { // "Models.Messages.Clan.UserClanTransferCoinsMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t amount = 0x20; // "IPrimitiveData<int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Amount = 0x4A32440; // "public int get_Amount()"
            inline constexpr std::uintptr_t get_Type = 0x4A32490; // "public override string get_Type()"
        }
    } // namespace UserClanTransferCoinsMessage

    namespace UserFindClanMessage { // "Models.Messages.UserFindClanMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t name = 0x20; // "IPrimitiveData<string>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Name = 0x4A15070; // "public string get_Name()"
            inline constexpr std::uintptr_t get_Type = 0x4A150C0; // "public override string get_Type()"
        }
    } // namespace UserFindClanMessage

    namespace UserJoinObjectClanBattleAppointmentMessage { // "Models.Messages.Clan.ClanBattle.UserJoinObjectClanBattleAppointmentMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t object = 0x20; // "IPrimitiveData<ClanConquestObjectTypeDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Object = 0x4A32700; // "public ClanConquestObjectTypeDescription get_Object()"
            inline constexpr std::uintptr_t get_Type = 0x4A32750; // "public override string get_Type()"
        }
    } // namespace UserJoinObjectClanBattleAppointmentMessage

    namespace UserJoinSectorClanBattleAppointmentMessage { // "Models.Messages.Clan.ClanBattle.UserJoinSectorClanBattleAppointmentMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t sector = 0x20; // "IPrimitiveData<SectorDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Sector = 0x4A329C0; // "public SectorDescription get_Sector()"
            inline constexpr std::uintptr_t get_Type = 0x4A32A10; // "public override string get_Type()"
        }
    } // namespace UserJoinSectorClanBattleAppointmentMessage

    namespace UserPartyInviteData { // "Models.Data.Party.UserPartyInviteData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t PublicId = 0x20; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t Nickname = 0x28; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t EndTs = 0x30; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t PartyId = 0x38; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t ClanTag = 0x40; // "IPrimitiveData<string>"
        }
    } // namespace UserPartyInviteData

    namespace UserRemoveObjectBetMessage { // "Models.Messages.Clan.ClanBattle.UserRemoveObjectBetMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t object = 0x20; // "IPrimitiveData<ClanConquestObjectTypeDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Object = 0x4A32C80; // "public ClanConquestObjectTypeDescription get_Object()"
            inline constexpr std::uintptr_t get_Type = 0x4A32CD0; // "public override string get_Type()"
        }
    } // namespace UserRemoveObjectBetMessage

    namespace UserRemoveSectorBetMessage { // "Models.Messages.Clan.ClanBattle.UserRemoveSectorBetMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t sector = 0x20; // "IPrimitiveData<SectorDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Sector = 0x4A32F40; // "public SectorDescription get_Sector()"
            inline constexpr std::uintptr_t get_Type = 0x4A32F90; // "public override string get_Type()"
        }
    } // namespace UserRemoveSectorBetMessage

    namespace VoiceChatBattleBotModel { // "Game.Battle.VoiceChat.VoiceChatBattleBotModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Participant = 0x10; // "VoiceChatBattleParticipantModel"
            inline constexpr std::uintptr_t Frequency = 0x18; // "float"
            inline constexpr std::uintptr_t Phase = 0x20; // "double"
        }
    } // namespace VoiceChatBattleBotModel

    namespace VoiceChatBattleBotsUpdater { // "Game.Battle.VoiceChat.VoiceChatBattleBotsUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleCharacterSlotsModel = 0x10; // "BattleCharacterSlotsModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x18; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t voiceChatBattleRoomModel = 0x20; // "VoiceChatBattleRoomModel"
            inline constexpr std::uintptr_t bots = 0x28; // "Dictionary<string, VoiceChatBattleBotModel>"
            inline constexpr std::uintptr_t idsToRemove = 0x30; // "List<string>"
            inline constexpr std::uintptr_t samples = 0x38; // "short[]"
            inline constexpr std::uintptr_t samplesRemainder = 0x40; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xD62C50; // "public void Update()"
            inline constexpr std::uintptr_t UpdateParticipants = 0xD62360; // "private void UpdateParticipants()"
            inline constexpr std::uintptr_t IsDead = 0xD621C0; // "private bool IsDead(BattleCharacterSlotModel slotModel)"
            inline constexpr std::uintptr_t WriteAudio = 0xD62CD0; // "private void WriteAudio()"
        }
    } // namespace VoiceChatBattleBotsUpdater

    namespace VoiceChatBattleCacheParticipantSlotsUpdater { // "Game.Battle.VoiceChat.VoiceChatBattleCacheParticipantSlotsUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleCharacterSlotsModel = 0x10; // "BattleCharacterSlotsModel"
            inline constexpr std::uintptr_t voiceChatBattleRoomModel = 0x18; // "VoiceChatBattleRoomModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xD631B0; // "public void Update()"
        }
    } // namespace VoiceChatBattleCacheParticipantSlotsUpdater

    namespace VoiceChatBattleConnectionTimeoutLogUpdater { // "Game.Battle.VoiceChat.VoiceChatBattleConnectionTimeoutLogUpdater (Battle.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x82140D0; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace Fields {
            inline constexpr std::uintptr_t globalModel = 0x10; // "GlobalModel"
            inline constexpr std::uintptr_t battleModel = 0x18; // "BattleModel"
            inline constexpr std::uintptr_t isLogged = 0x20; // "bool"
            inline constexpr std::uintptr_t isWaitingConnection = 0x21; // "bool"
            inline constexpr std::uintptr_t startTime = 0x24; // "float"
        }
        namespace StaticFields {
            inline constexpr std::uintptr_t connectionTimeout = 0x0; // "TimeSpan"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xD63460; // "public void Update()"
        }
    } // namespace VoiceChatBattleConnectionTimeoutLogUpdater

    namespace VoiceChatBattleDebugDeviceIdUpdater { // "Game.Battle.VoiceChat.VoiceChatBattleDebugDeviceIdUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t eosGlobalModel = 0x10; // "EosGlobalModel"
            inline constexpr std::uintptr_t eosDeviceIdAuthorizer = 0x18; // "EosDeviceIdAuthorizer"
            inline constexpr std::uintptr_t isInProcess = 0x20; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xD63C10; // "public void Update()"
            inline constexpr std::uintptr_t ResetDeviceId = 0xD63B60; // "private void ResetDeviceId()"
        }
    } // namespace VoiceChatBattleDebugDeviceIdUpdater

    namespace VoiceChatBattleDebugGizmosUpdater { // "Game.Battle.VoiceChat.VoiceChatBattleDebugGizmosUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t voiceChatBattleRoomModel = 0x10; // "VoiceChatBattleRoomModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x7B3360; // "public void Update()"
            inline constexpr std::uintptr_t OnDrawGizmos = 0xD63D80; // "private void OnDrawGizmos()"
        }
    } // namespace VoiceChatBattleDebugGizmosUpdater

    namespace VoiceChatBattleDebugModel { // "Game.Battle.VoiceChat.VoiceChatBattleDebugModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsGizmosEnabled = 0x10; // "bool"
            inline constexpr std::uintptr_t ParticipantsStatisticMode = 0x14; // "ParticipantsStatisticMode"
            inline constexpr std::uintptr_t IsThreadTestEnabled = 0x18; // "bool"
            inline constexpr std::uintptr_t ThreadTestInterval = 0x1C; // "float"
            inline constexpr std::uintptr_t IsSpamEnabled = 0x20; // "bool"
            inline constexpr std::uintptr_t IsSpamReceiving = 0x21; // "bool"
            inline constexpr std::uintptr_t IsSpamSending = 0x22; // "bool"
            inline constexpr std::uintptr_t SpamInterval = 0x24; // "float"
            inline constexpr std::uintptr_t IsDeviceIdResetRequested = 0x28; // "bool"
        }
    } // namespace VoiceChatBattleDebugModel

    namespace VoiceChatBattleDebugSpamRequestsUpdater { // "Game.Battle.VoiceChat.VoiceChatBattleDebugSpamRequestsUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t eosGlobalModel = 0x10; // "EosGlobalModel"
            inline constexpr std::uintptr_t audioInterface = 0x18; // "RTCAudioInterface"
            inline constexpr std::uintptr_t voiceChatBattleRoomModel = 0x20; // "VoiceChatBattleRoomModel"
            inline constexpr std::uintptr_t onUpdateReceiving = 0x28; // "OnUpdateReceivingCallback"
            inline constexpr std::uintptr_t onUpdateSending = 0x30; // "OnUpdateSendingCallback"
            inline constexpr std::uintptr_t nextSpamTime = 0x38; // "float"
            inline constexpr std::uintptr_t isSpamming = 0x3C; // "bool"
            inline constexpr std::uintptr_t isReceivingAudioEnabled = 0x3D; // "bool"
            inline constexpr std::uintptr_t isSendingAudioEnabled = 0x3E; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xD648D0; // "public void Update()"
            inline constexpr std::uintptr_t RestoreState = 0xD64230; // "private void RestoreState()"
            inline constexpr std::uintptr_t SpamUpdateReceiving = 0xD64450; // "private void SpamUpdateReceiving()"
            inline constexpr std::uintptr_t UpdateReceiving = 0xD64670; // "private void UpdateReceiving(ProductUserId participantId, bool isAudioEnabled)"
            inline constexpr std::uintptr_t OnUpdateReceiving = 0x7B3360; // "private void OnUpdateReceiving(ref UpdateReceivingCallbackInfo data)"
            inline constexpr std::uintptr_t SpamUpdateSending = 0xD64650; // "private void SpamUpdateSending()"
            inline constexpr std::uintptr_t UpdateSending = 0xD647B0; // "private void UpdateSending(RTCAudioStatus audioStatus)"
            inline constexpr std::uintptr_t OnUpdateSending = 0x7B3360; // "private void OnUpdateSending(ref UpdateSendingCallbackInfo data)"
        }
    } // namespace VoiceChatBattleDebugSpamRequestsUpdater

    namespace VoiceChatBattleDebugThreadUpdater { // "Game.Battle.VoiceChat.VoiceChatBattleDebugThreadUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t nextGcCollectTime = 0x10; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xD64AF0; // "public void Update()"
        }
    } // namespace VoiceChatBattleDebugThreadUpdater

    namespace VoiceChatBattleParticipantDebugModel { // "Game.Battle.VoiceChat.VoiceChatBattleParticipantDebugModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Timer = 0x10; // "float"
            inline constexpr std::uintptr_t PreviousWriteCount = 0x14; // "int"
            inline constexpr std::uintptr_t WriteCount = 0x18; // "int"
            inline constexpr std::uintptr_t PreviousReadCount = 0x1C; // "int"
            inline constexpr std::uintptr_t ReadCount = 0x20; // "int"
            inline constexpr std::uintptr_t MinFillPercent = 0x24; // "int"
            inline constexpr std::uintptr_t MaxFillPercent = 0x28; // "int"
            inline constexpr std::uintptr_t IsFormatChanged = 0x2C; // "bool"
            inline constexpr std::uintptr_t FormatChangeCount = 0x30; // "int"
        }
    } // namespace VoiceChatBattleParticipantDebugModel

    namespace VoiceChatBattleParticipantModel { // "Game.Battle.VoiceChat.VoiceChatBattleParticipantModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t SlotDescription = 0x38; // "BattleCharacterSlotDescription"
            inline constexpr std::uintptr_t Position = 0x40; // "Nullable<Vector3>"
            inline constexpr std::uintptr_t SoundEmitterPosition = 0x50; // "Nullable<Vector3>"
            inline constexpr std::uintptr_t PositionCacheEndTime = 0x60; // "float"
            inline constexpr std::uintptr_t HideObjectEntityId = 0x64; // "int"
            inline constexpr std::uintptr_t IsPostingAudio = 0x68; // "bool"
        }
    } // namespace VoiceChatBattleParticipantModel

    namespace VoiceChatBattleParticipantsMuteUpdater { // "Game.Battle.VoiceChat.VoiceChatBattleParticipantsMuteUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t blackListModel = 0x10; // "BlackListModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x18; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t voiceChatBattleRoomModel = 0x20; // "VoiceChatBattleRoomModel"
            inline constexpr std::uintptr_t battleCharacterSlotsModel = 0x28; // "BattleCharacterSlotsModel"
            inline constexpr std::uintptr_t voiceChatViewDescription = 0x30; // "VoiceChatViewDescription"
            inline constexpr std::uintptr_t battleMode = 0x38; // "BattleModeDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xD66D80; // "public void Update()"
            inline constexpr std::uintptr_t IsMuted = 0xD66CE0; // "private bool IsMuted(BattleCharacterSlotModel slotModel)"
        }
    } // namespace VoiceChatBattleParticipantsMuteUpdater

    namespace VoiceChatBattleParticipantsPositionUpdater { // "Game.Battle.VoiceChat.VoiceChatBattleParticipantsPositionUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t eosGlobalModel = 0x10; // "EosGlobalModel"
            inline constexpr std::uintptr_t rtcDataInterface = 0x18; // "RTCDataInterface"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x20; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t battleCharacterSlotsModel = 0x28; // "BattleCharacterSlotsModel"
            inline constexpr std::uintptr_t locationDescription = 0x30; // "LocationDescription"
            inline constexpr std::uintptr_t voiceChatBattleRoomModel = 0x38; // "VoiceChatBattleRoomModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xD68080; // "public void Update()"
            inline constexpr std::uintptr_t AddNotifyDataReceived = 0xD67290; // "private void AddNotifyDataReceived()"
            inline constexpr std::uintptr_t OnHideObjectEntityIdReceived = 0xD67330; // "private void OnHideObjectEntityIdReceived(ref DataReceivedCallbackInfo data)"
            inline constexpr std::uintptr_t RemoveNotifyDataReceived = 0xD67470; // "private void RemoveNotifyDataReceived()"
            inline constexpr std::uintptr_t UpdateParticipantPositions = 0xD67650; // "private void UpdateParticipantPositions()"
        }
    } // namespace VoiceChatBattleParticipantsPositionUpdater

    namespace VoiceChatBattleRoomModel { // "Game.Battle.VoiceChat.VoiceChatBattleRoomModel (Battle.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t CreateParticipantModel = 0xD69AE0; // "public override VoiceChatRoomParticipantModel CreateParticipantModel(ProductUserId productUserId)"
        }
    } // namespace VoiceChatBattleRoomModel

    namespace VoiceChatBattleTokenUpdater { // "Game.Battle.VoiceChat.VoiceChatBattleTokenUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleEntitiesModel = 0x10; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t timeModel = 0x18; // "TimeModel"
            inline constexpr std::uintptr_t voiceChatBattleRoomModel = 0x20; // "VoiceChatBattleRoomModel"
            inline constexpr std::uintptr_t battleRoomConnection = 0x28; // "IRoomConnection"
            inline constexpr std::uintptr_t battleConnectionInfo = 0x30; // "RoomConnectionInfo"
            inline constexpr std::uintptr_t isClientRequesting = 0x38; // "bool"
            inline constexpr std::uintptr_t isWaitingServerData = 0x39; // "bool"
            inline constexpr std::uintptr_t cooldownEndTime = 0x3C; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xD69DC0; // "public void Update()"
            inline constexpr std::uintptr_t UpdateVoiceRoomToken = 0xD69C00; // "private void UpdateVoiceRoomToken(BattleEOSModel eosServerModel)"
            inline constexpr std::uintptr_t SendVoiceRoomTokenMessage = 0xD69B50; // "private void SendVoiceRoomTokenMessage()"
            inline constexpr std::uintptr_t WaitForServerCredentialsUpdate = 0xD6A160; // "private void WaitForServerCredentialsUpdate(BattleEOSModel eosServerModel)"
        }
    } // namespace VoiceChatBattleTokenUpdater

    namespace VoiceChatBattleUpdater { // "Game.Battle.VoiceChat.VoiceChatBattleUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t globalModel = 0x10; // "GlobalModel"
            inline constexpr std::uintptr_t battleModel = 0x18; // "BattleModel"
            inline constexpr std::uintptr_t battleRoomConnection = 0x20; // "IRoomConnection"
            inline constexpr std::uintptr_t battleConnectionInfo = 0x28; // "RoomConnectionInfo"
            inline constexpr std::uintptr_t now = 0x30; // "INow"
            inline constexpr std::uintptr_t globalScreenContent = 0x38; // "GlobalScreenContent"
            inline constexpr std::uintptr_t notificationKeys = 0x40; // "NotificationKeys"
            inline constexpr std::uintptr_t logUpdater = 0x48; // "IUpdater"
            inline constexpr std::uintptr_t registerDisposable = 0x50; // "IRegisterDisposable"
            inline constexpr std::uintptr_t updaters = 0x58; // "IUpdater[]"
            inline constexpr std::uintptr_t canUpdate = 0x60; // "bool"
            inline constexpr std::uintptr_t roomCachedProductUserId = 0x68; // "ProductUserId"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xD6A440; // "public void Update()"
            inline constexpr std::uintptr_t Dispose = 0xD6A3A0; // "private void Dispose()"
        }
    } // namespace VoiceChatBattleUpdater

    namespace VoiceChatClearRoomsUpdater { // "Game.Global.VoiceChat.VoiceChatClearRoomsUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t voiceChatGlobalModel = 0x10; // "VoiceChatGlobalModel"
            inline constexpr std::uintptr_t roomsToClear = 0x18; // "HashSet<VoiceChatRoomModel>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x3716230; // "public void Update()"
            inline constexpr std::uintptr_t ClearRoomsToAdd = 0x3715DF0; // "private void ClearRoomsToAdd()"
            inline constexpr std::uintptr_t ClearRoomsToRemove = 0x3715F70; // "private void ClearRoomsToRemove()"
        }
    } // namespace VoiceChatClearRoomsUpdater

    namespace VoiceChatDisconnectRoomsUpdater { // "Game.Global.VoiceChat.VoiceChatDisconnectRoomsUpdater (Global.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x8215C20; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace Fields {
            inline constexpr std::uintptr_t eosGlobalModel = 0x10; // "EosGlobalModel"
            inline constexpr std::uintptr_t voiceChatGlobalModel = 0x18; // "VoiceChatGlobalModel"
            inline constexpr std::uintptr_t rtcInterface = 0x20; // "RTCInterface"
        }
        namespace StaticFields {
            inline constexpr std::uintptr_t onNotifyDisconnected = 0x0; // "OnDisconnectedCallback"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x37166F0; // "public void Update()"
            inline constexpr std::uintptr_t AddNotifyDisconnected = 0x37162F0; // "private void AddNotifyDisconnected(VoiceChatRoomModel roomModel)"
            inline constexpr std::uintptr_t OnNotifyDisconnected = 0x37163E0; // "private static void OnNotifyDisconnected(ref DisconnectedCallbackInfo data)"
            inline constexpr std::uintptr_t RemoveNotifyDisconnected = 0x3716650; // "private void RemoveNotifyDisconnected(VoiceChatRoomModel roomModel)"
        }
    } // namespace VoiceChatDisconnectRoomsUpdater

    namespace VoiceChatGlobalModel { // "Game.Global.VoiceChat.VoiceChatGlobalModel (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ActiveRooms = 0x10; // "HashSet<VoiceChatRoomModel>"
            inline constexpr std::uintptr_t RoomsToAdd = 0x18; // "HashSet<VoiceChatRoomModel>"
            inline constexpr std::uintptr_t RoomsToRemove = 0x20; // "HashSet<VoiceChatRoomModel>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Add = 0x3716AF0; // "public void Add(VoiceChatRoomModel roomModel)"
            inline constexpr std::uintptr_t Remove = 0x3716B90; // "public void Remove(VoiceChatRoomModel roomModel)"
        }
    } // namespace VoiceChatGlobalModel

    namespace VoiceChatGlobalUpdater { // "Game.Global.VoiceChat.VoiceChatGlobalUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t globalModel = 0x10; // "GlobalModel"
            inline constexpr std::uintptr_t globalScreenLoadedContent = 0x18; // "NotInstantiateLoadedContent<GlobalScreenContent>"
            inline constexpr std::uintptr_t updaters = 0x20; // "IUpdater[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x3716CF0; // "public void Update()"
        }
    } // namespace VoiceChatGlobalUpdater

    namespace VoiceChatIssuesUpdater { // "Game.Global.SettingsDialog.Updaters.VoiceChatIssuesUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t eosGlobalModel = 0x20; // "EosGlobalModel"
            inline constexpr std::uintptr_t error = 0x28; // "GameObject"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0x3767360; // "public VoiceChatIssuesUpdater Init(EosGlobalModel eosGlobalModel, GameObject error)"
            inline constexpr std::uintptr_t Dispose = 0x92B5C0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0x37673C0; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace VoiceChatIssuesUpdater

    namespace VoiceChatJoinRoomsUpdater { // "Game.Global.VoiceChat.VoiceChatJoinRoomsUpdater (Global.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x8216290; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace Fields {
            inline constexpr std::uintptr_t eosGlobalModel = 0x10; // "EosGlobalModel"
            inline constexpr std::uintptr_t voiceChatGlobalModel = 0x18; // "VoiceChatGlobalModel"
            inline constexpr std::uintptr_t rtcInterface = 0x20; // "RTCInterface"
        }
        namespace StaticFields {
            inline constexpr std::uintptr_t onJoinRoom = 0x0; // "OnJoinRoomCallback"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x3717D40; // "public void Update()"
            inline constexpr std::uintptr_t JoinVoiceRoom = 0x3717710; // "private void JoinVoiceRoom(VoiceChatRoomModel roomModel)"
            inline constexpr std::uintptr_t OnJoinRoom = 0x37179C0; // "private static void OnJoinRoom(ref JoinRoomCallbackInfo data)"
        }
    } // namespace VoiceChatJoinRoomsUpdater

    namespace VoiceChatLeaveRoomsUpdater { // "Game.Global.VoiceChat.VoiceChatLeaveRoomsUpdater (Global.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x8216430; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace Fields {
            inline constexpr std::uintptr_t eosGlobalModel = 0x10; // "EosGlobalModel"
            inline constexpr std::uintptr_t voiceChatGlobalModel = 0x18; // "VoiceChatGlobalModel"
            inline constexpr std::uintptr_t rtcInterface = 0x20; // "RTCInterface"
        }
        namespace StaticFields {
            inline constexpr std::uintptr_t onLeaveRoom = 0x0; // "OnLeaveRoomCallback"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x3718380; // "public void Update()"
            inline constexpr std::uintptr_t LeaveVoiceRoom = 0x3717FC0; // "private void LeaveVoiceRoom(VoiceChatRoomModel roomModel)"
            inline constexpr std::uintptr_t OnLeaveRoom = 0x3718100; // "private static void OnLeaveRoom(ref LeaveRoomCallbackInfo data)"
        }
    } // namespace VoiceChatLeaveRoomsUpdater

    namespace VoiceChatParticipantsModel { // "Game.Global.VoiceChat.VoiceChatParticipantsModel (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t participantIdToModels = 0x10; // "ConcurrentDictionary<ProductUserId, VoiceChatRoomParticipantModel>"
            inline constexpr std::uintptr_t participantStringIdToModels = 0x18; // "ConcurrentDictionary<string, VoiceChatRoomParticipantModel>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Add = 0x3718E30; // "public void Add(VoiceChatRoomParticipantModel participantModel)"
            inline constexpr std::uintptr_t Remove = 0x3719060; // "public void Remove(VoiceChatRoomParticipantModel participantModel)"
            inline constexpr std::uintptr_t Contains = 0x3718F30; // "public bool Contains(ProductUserId productUserId)"
            inline constexpr std::uintptr_t Contains_2 = 0x3718F90; // "public bool Contains(string productUserIdString)"
            inline constexpr std::uintptr_t TryGetParticipant = 0x37191A0; // "public bool TryGetParticipant(ProductUserId productUserId, out VoiceChatRoomParticipantModel participantModel)"
            inline constexpr std::uintptr_t TryGetParticipant_2 = 0x3719100; // "public bool TryGetParticipant(string productUserIdString, out VoiceChatRoomParticipantModel participantModel)"
            inline constexpr std::uintptr_t Clear = 0x3718EC0; // "public void Clear()"
            inline constexpr std::uintptr_t GetEnumerator = 0x3718FF0; // "public IEnumerator<VoiceChatRoomParticipantModel> GetEnumerator()"
            inline constexpr std::uintptr_t System_Collections_IEnumerable_GetEnumerator = 0x3718FF0; // "private IEnumerator System.Collections.IEnumerable.GetEnumerator()"
        }
    } // namespace VoiceChatParticipantsModel

    namespace VoiceChatParticipantsMuteUpdater { // "Game.Global.VoiceChat.VoiceChatParticipantsMuteUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t eosGlobalModel = 0x10; // "EosGlobalModel"
            inline constexpr std::uintptr_t audioInterface = 0x18; // "RTCAudioInterface"
            inline constexpr std::uintptr_t voiceChatGlobalModel = 0x20; // "VoiceChatGlobalModel"
            inline constexpr std::uintptr_t receivingMuted = 0x28; // "Dictionary<VoiceChatRoomModel, HashSet<ProductUserId>>"
            inline constexpr std::uintptr_t receivingProcessing = 0x30; // "Dictionary<VoiceChatRoomModel, HashSet<ProductUserId>>"
            inline constexpr std::uintptr_t leftParticipantIds = 0x38; // "List<ProductUserId>"
            inline constexpr std::uintptr_t onUpdateReceiving = 0x40; // "OnUpdateReceivingCallback"
            inline constexpr std::uintptr_t nextReceivingDisableTime = 0x48; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x3719CD0; // "public void Update()"
            inline constexpr std::uintptr_t RemoveLeftParticipants = 0x3719470; // "private void RemoveLeftParticipants(VoiceChatRoomModel roomModel, HashSet<ProductUserId> receivingMuted)"
            inline constexpr std::uintptr_t UpdateReceiving = 0x3719780; // "private void UpdateReceiving(VoiceChatRoomModel roomModel, HashSet<ProductUserId> receivingMuted, HashSet<ProductUserId> receivingProcessing)"
            inline constexpr std::uintptr_t OnUpdateReceiving = 0x3719300; // "private void OnUpdateReceiving(ref UpdateReceivingCallbackInfo data)"
        }
    } // namespace VoiceChatParticipantsMuteUpdater

    namespace VoiceChatParticipantsUpdater { // "Game.Global.VoiceChat.VoiceChatParticipantsUpdater (Global.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x8216AA0; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace Fields {
            inline constexpr std::uintptr_t eosGlobalModel = 0x10; // "EosGlobalModel"
            inline constexpr std::uintptr_t rtcInterface = 0x18; // "RTCInterface"
            inline constexpr std::uintptr_t voiceChatGlobalModel = 0x20; // "VoiceChatGlobalModel"
        }
        namespace StaticFields {
            inline constexpr std::uintptr_t onParticipantStatusChanged = 0x0; // "OnParticipantStatusChangedCallback"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x371A770; // "public void Update()"
            inline constexpr std::uintptr_t AddNotifyParticipantStatusChanged = 0x371A370; // "private void AddNotifyParticipantStatusChanged(VoiceChatRoomModel roomModel)"
            inline constexpr std::uintptr_t OnParticipantStatusChanged = 0x371A460; // "private static void OnParticipantStatusChanged(ref ParticipantStatusChangedCallbackInfo data)"
            inline constexpr std::uintptr_t RemoveNotifyParticipantStatusChanged = 0x371A6D0; // "private void RemoveNotifyParticipantStatusChanged(VoiceChatRoomModel roomModel)"
        }
    } // namespace VoiceChatParticipantsUpdater

    namespace VoiceChatRestrictedNotificationUpdater { // "Game.Battle.VoiceChat.VoiceChatRestrictedNotificationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t voiceChatInputModel = 0x10; // "InputModel"
            inline constexpr std::uintptr_t chatRestrictionModel = 0x18; // "ChatRestrictionModel"
            inline constexpr std::uintptr_t personalNotificationModel = 0x20; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t restrictedText = 0x28; // "Text<long>"
            inline constexpr std::uintptr_t isTriggered = 0x30; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xD6B2B0; // "public void Update()"
        }
    } // namespace VoiceChatRestrictedNotificationUpdater

    namespace VoiceChatRoomConnectionModel { // "Game.Global.VoiceChat.VoiceChatRoomConnectionModel (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsConnected = 0x10; // "bool"
            inline constexpr std::uintptr_t NeedReconnect = 0x11; // "bool"
            inline constexpr std::uintptr_t IsRequesting = 0x12; // "bool"
            inline constexpr std::uintptr_t CooldownEndTime = 0x14; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t CanJoin = 0x371AB90; // "public bool CanJoin()"
            inline constexpr std::uintptr_t CanLeave = 0x371ABD0; // "public bool CanLeave()"
            inline constexpr std::uintptr_t CanDispose = 0x371AB70; // "public bool CanDispose()"
            inline constexpr std::uintptr_t CanRequest = 0x371AC10; // "private bool CanRequest()"
        }
    } // namespace VoiceChatRoomConnectionModel

    namespace VoiceChatRoomCredentialsModel { // "Game.Global.VoiceChat.VoiceChatRoomCredentialsModel (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t RoomUrl = 0x10; // "string"
            inline constexpr std::uintptr_t RoomToken = 0x18; // "string"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsValid = 0x371ACA0; // "public bool get_IsValid()"
            inline constexpr std::uintptr_t Set = 0xBFBA40; // "public void Set(string roomUrl, string roomToken)"
            inline constexpr std::uintptr_t Clear = 0x371AC50; // "public void Clear()"
        }
    } // namespace VoiceChatRoomCredentialsModel

    namespace VoiceChatRoomModel { // "Game.Global.VoiceChat.VoiceChatRoomModel (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t RoomName = 0x10; // "string"
            inline constexpr std::uintptr_t HasSpeakingInput = 0x18; // "bool"
            inline constexpr std::uintptr_t NotificationsModel = 0x20; // "VoiceChatRoomNotificationsModel"
            inline constexpr std::uintptr_t Credentials = 0x28; // "VoiceChatRoomCredentialsModel"
            inline constexpr std::uintptr_t ConnectionModel = 0x30; // "VoiceChatRoomConnectionModel"
            inline constexpr std::uintptr_t ParticipantsModel = 0x38; // "VoiceChatParticipantsModel"
        }
    } // namespace VoiceChatRoomModel

    namespace VoiceChatRoomNotificationsModel { // "Game.Global.VoiceChat.VoiceChatRoomNotificationsModel (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t NotifyDisconnectedId = 0x10; // "ulong"
            inline constexpr std::uintptr_t NotifyParticipantStatusChangedId = 0x18; // "ulong"
            inline constexpr std::uintptr_t NotifyParticipantsDataReceivedId = 0x20; // "ulong"
            inline constexpr std::uintptr_t NotifyAudioBeforeRenderId = 0x28; // "ulong"
            inline constexpr std::uintptr_t NotifyRoomBeforeJoinId = 0x30; // "ulong"
        }
    } // namespace VoiceChatRoomNotificationsModel

    namespace VoiceChatRoomParticipantModel { // "Game.Global.VoiceChat.VoiceChatRoomParticipantModel (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ProductUserId = 0x10; // "ProductUserId"
            inline constexpr std::uintptr_t ProductUserIdString = 0x18; // "string"
            inline constexpr std::uintptr_t IsMuted = 0x20; // "bool"
            inline constexpr std::uintptr_t IsSpeaking = 0x21; // "bool"
            inline constexpr std::uintptr_t AudioBuffer = 0x28; // "AudioInputBuffer"
            inline constexpr std::uintptr_t LastActiveSpeakingTs = 0x30; // "long"
        }
    } // namespace VoiceChatRoomParticipantModel

    namespace VoiceChatRules { // "Game.Global.VoiceChat.VoiceChatRules (Global.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t CanUseVoiceRoom = 0x371AF70; // "public static bool CanUseVoiceRoom(GlobalModel globalModel, VoiceChatRoomModel voiceChatRoomModel, ProductUserId roomCachedProductUserId, string serverProductUserId)"
        }
    } // namespace VoiceChatRules

    namespace VoiceChatSettingsPreset { // "Game.Global.Settings.VoiceChat.VoiceChatSettingsPreset (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Mode = 0x18; // "VoiceChatMode"
            inline constexpr std::uintptr_t OutputVolume = 0x1C; // "float"
            inline constexpr std::uintptr_t InputVolume = 0x20; // "float"
            inline constexpr std::uintptr_t InputDevice = 0x28; // "string"
            inline constexpr std::uintptr_t EchoCancellation = 0x30; // "bool"
            inline constexpr std::uintptr_t NoiseSuppression = 0x31; // "bool"
            inline constexpr std::uintptr_t AutoGain = 0x32; // "bool"
        }
    } // namespace VoiceChatSettingsPreset

    namespace VoiceChatSettingsUpdater { // "Game.Global.VoiceChat.VoiceChatSettingsUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t gameSettings = 0x10; // "GameSetting"
            inline constexpr std::uintptr_t eosGlobalModel = 0x18; // "EosGlobalModel"
            inline constexpr std::uintptr_t rtcInterface = 0x20; // "RTCInterface"
            inline constexpr std::uintptr_t audioInterface = 0x28; // "RTCAudioInterface"
            inline constexpr std::uintptr_t voiceChatGlobalModel = 0x30; // "VoiceChatGlobalModel"
            inline constexpr std::uintptr_t onSetInputDeviceSettings = 0x38; // "OnSetInputDeviceSettingsCallback"
            inline constexpr std::uintptr_t voiceChatMode = 0x40; // "Nullable<VoiceChatMode>"
            inline constexpr std::uintptr_t isEchoCancellationDisabled = 0x48; // "Nullable<bool>"
            inline constexpr std::uintptr_t isNoiseSuppressionDisabled = 0x4A; // "Nullable<bool>"
            inline constexpr std::uintptr_t isAutoGainDisabled = 0x4C; // "Nullable<bool>"
            inline constexpr std::uintptr_t audioInputDeviceName = 0x50; // "string"
            inline constexpr std::uintptr_t isRequesting = 0x58; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x371B9E0; // "public void Update()"
            inline constexpr std::uintptr_t UpdateAudioInputSettings = 0x371B290; // "private void UpdateAudioInputSettings()"
            inline constexpr std::uintptr_t OnSetInputDeviceSettings = 0x371B0E0; // "private void OnSetInputDeviceSettings(ref OnSetInputDeviceSettingsCallbackInfo data)"
            inline constexpr std::uintptr_t UpdateRtcSettings = 0x371B770; // "private void UpdateRtcSettings(out bool needReconnect)"
            inline constexpr std::uintptr_t UpdateRtcSetting = 0x371B4F0; // "private bool UpdateRtcSetting(string setting, ref Nullable<bool> currentValue, bool value)"
            inline constexpr std::uintptr_t UpdateVoiceChatMode = 0x371B900; // "private void UpdateVoiceChatMode(out bool needReconnect)"
        }
    } // namespace VoiceChatSettingsUpdater

    namespace VoiceChatSpeakingStateUpdater { // "Game.Global.VoiceChat.VoiceChatSpeakingStateUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t gameSettingsModel = 0x10; // "GameSettingsModel"
            inline constexpr std::uintptr_t eosGlobalModel = 0x18; // "EosGlobalModel"
            inline constexpr std::uintptr_t rtcInterface = 0x20; // "RTCInterface"
            inline constexpr std::uintptr_t audioInterface = 0x28; // "RTCAudioInterface"
            inline constexpr std::uintptr_t voiceChatGlobalModel = 0x30; // "VoiceChatGlobalModel"
            inline constexpr std::uintptr_t chatRestrictionModel = 0x38; // "ChatRestrictionModel"
            inline constexpr std::uintptr_t voiceChatViewDescription = 0x40; // "VoiceChatViewDescription"
            inline constexpr std::uintptr_t roomAudioStatuses = 0x48; // "Dictionary<VoiceChatRoomModel, Nullable<RTCAudioStatus>>"
            inline constexpr std::uintptr_t audioStatusProcessingRooms = 0x50; // "HashSet<VoiceChatRoomModel>"
            inline constexpr std::uintptr_t roomVolumes = 0x58; // "Dictionary<VoiceChatRoomModel, float>"
            inline constexpr std::uintptr_t volumeProcessingRooms = 0x60; // "HashSet<VoiceChatRoomModel>"
            inline constexpr std::uintptr_t onRoomBeforeJoin = 0x68; // "OnRoomBeforeJoinCallback"
            inline constexpr std::uintptr_t onUpdateSending = 0x70; // "OnUpdateSendingCallback"
            inline constexpr std::uintptr_t onUpdateSendingVolume = 0x78; // "OnUpdateSendingVolumeCallback"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x371CD30; // "public void Update()"
            inline constexpr std::uintptr_t AddNotifyRoomBeforeJoin = 0x371BE80; // "private void AddNotifyRoomBeforeJoin(VoiceChatRoomModel roomModel)"
            inline constexpr std::uintptr_t OnRoomBeforeJoin = 0x371C090; // "private void OnRoomBeforeJoin(ref RoomBeforeJoinCallbackInfo data)"
            inline constexpr std::uintptr_t RemoveNotifyRoomBeforeJoin = 0x371C770; // "private void RemoveNotifyRoomBeforeJoin(VoiceChatRoomModel roomModel)"
            inline constexpr std::uintptr_t UpdateAudioStatus = 0x371CAE0; // "private void UpdateAudioStatus(VoiceChatRoomModel roomModel)"
            inline constexpr std::uintptr_t GetAudioStatus = 0x371BF70; // "private RTCAudioStatus GetAudioStatus(VoiceChatRoomModel roomModel)"
            inline constexpr std::uintptr_t SendAudioStatus = 0x371C810; // "private void SendAudioStatus(VoiceChatRoomModel roomModel, RTCAudioStatus audioStatus)"
            inline constexpr std::uintptr_t OnUpdateSending = 0x371C510; // "private void OnUpdateSending(ref UpdateSendingCallbackInfo data)"
            inline constexpr std::uintptr_t UpdateVolume = 0x371CBF0; // "private void UpdateVolume(VoiceChatRoomModel roomModel)"
            inline constexpr std::uintptr_t GetVolume = 0x371BFB0; // "private float GetVolume()"
            inline constexpr std::uintptr_t SendVolume = 0x371C970; // "private void SendVolume(VoiceChatRoomModel roomModel, float volume)"
            inline constexpr std::uintptr_t OnUpdateSendingVolume = 0x371C2F0; // "private void OnUpdateSendingVolume(ref UpdateSendingVolumeCallbackInfo data)"
        }
    } // namespace VoiceChatSpeakingStateUpdater

} // namespace Offsets::Social_Party_Clan
