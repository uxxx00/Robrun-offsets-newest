#pragma once
#include <cstdint>

namespace Offsets::Combat_Weapons {

    namespace AimAssistCancellationUpdater { // "Game.Battle.Entities.Player.BattleAssistance.AimAssistCancellationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t aimAssistModel = 0x10; // "AimAssistModel"
            inline constexpr std::uintptr_t recoilModel = 0x18; // "RecoilModel"
            inline constexpr std::uintptr_t rotationInputModel = 0x20; // "PlayerRotationInputModel"
            inline constexpr std::uintptr_t aimAssistViewDescription = 0x28; // "AimAssistViewDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB2FB00; // "public void Update()"
            inline constexpr std::uintptr_t HasInputConflictWithCorrection = 0xB2FA00; // "private bool HasInputConflictWithCorrection(Vector2 lookInput)"
        }
    } // namespace AimAssistCancellationUpdater

    namespace AimAssistModel { // "Game.Battle.Entities.Player.BattleAssistance.AimAssistModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsActive = 0x10; // "bool"
            inline constexpr std::uintptr_t HasOppositeInput = 0x11; // "bool"
            inline constexpr std::uintptr_t HasTarget = 0x12; // "bool"
            inline constexpr std::uintptr_t Target = 0x18; // "BattleAssistanceTargetModel"
            inline constexpr std::uintptr_t TargetPoint = 0x20; // "BattleAssistanceTargetPointModel"
            inline constexpr std::uintptr_t AimCorrection = 0x28; // "Vector2"
            inline constexpr std::uintptr_t StickinessTimer = 0x30; // "float"
            inline constexpr std::uintptr_t BlockTimer = 0x34; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetTarget = 0xB19A20; // "public void SetTarget(BattleAssistanceTargetModel target, BattleAssistanceTargetPointModel targetPoint, Vector2 aimCorrection)"
            inline constexpr std::uintptr_t ClearTarget = 0xB199A0; // "public void ClearTarget()"
        }
    } // namespace AimAssistModel

    namespace AimAssistModelUpdater { // "Game.Battle.Entities.Player.BattleAssistance.AimAssistModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t gameSettings = 0x10; // "GameSettingsModel"
            inline constexpr std::uintptr_t battleAssistanceModel = 0x18; // "BattleAssistanceModel"
            inline constexpr std::uintptr_t playerModel = 0x20; // "PlayerEntityModel"
            inline constexpr std::uintptr_t aimAssistModel = 0x28; // "AimAssistModel"
            inline constexpr std::uintptr_t autoFireModel = 0x30; // "AutoFireModel"
            inline constexpr std::uintptr_t aimAssistViewDescription = 0x38; // "AimAssistViewDescription"
            inline constexpr std::uintptr_t canUpdate = 0x40; // "bool"
            inline constexpr std::uintptr_t isActiveByBaseRules = 0x41; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB301A0; // "public void Update()"
            inline constexpr std::uintptr_t UpdateBlockTimer = 0xB30160; // "private void UpdateBlockTimer()"
            inline constexpr std::uintptr_t UpdateActiveState = 0xB2FF90; // "private void UpdateActiveState()"
            inline constexpr std::uintptr_t IsActiveByBaseRules = 0xB2FD40; // "private bool IsActiveByBaseRules()"
            inline constexpr std::uintptr_t TickTimers = 0xB2FF00; // "private void TickTimers()"
            inline constexpr std::uintptr_t IsPlayerInValidState = 0xB2FE00; // "private bool IsPlayerInValidState()"
            inline constexpr std::uintptr_t Reset = 0xB2FED0; // "private void Reset()"
        }
    } // namespace AimAssistModelUpdater

    namespace AimAssistRotationUpdater { // "Game.Battle.Entities.Player.BattleAssistance.AimAssistRotationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleAssistanceModel = 0x10; // "BattleAssistanceModel"
            inline constexpr std::uintptr_t aimAssistModel = 0x18; // "AimAssistModel"
            inline constexpr std::uintptr_t rotationInputModel = 0x20; // "PlayerRotationInputModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB304B0; // "public void Update()"
        }
    } // namespace AimAssistRotationUpdater

    namespace AimAssistTargetModel { // "Game.Battle.Entities.Player.BattleAssistance.AimAssistTargetModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsPotentialTarget = 0x10; // "bool"
            inline constexpr std::uintptr_t view = 0x18; // "BattleAssistanceTargetView"
            inline constexpr std::uintptr_t rect = 0x20; // "Rect"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_WorldRectHalfSize = 0xB306E0; // "public Vector3 get_WorldRectHalfSize()"
            inline constexpr std::uintptr_t get_ScreenRectRef = 0xB306D0; // "public ref Rect get_ScreenRectRef()"
            inline constexpr std::uintptr_t Reset = 0xB30640; // "public void Reset()"
        }
    } // namespace AimAssistTargetModel

    namespace AimAssistTargetUpdater { // "Game.Battle.Entities.Player.BattleAssistance.AimAssistTargetUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleCameraModel = 0x10; // "BattleCameraModel"
            inline constexpr std::uintptr_t rotationInputModel = 0x18; // "PlayerRotationInputModel"
            inline constexpr std::uintptr_t battleAssistanceModel = 0x20; // "BattleAssistanceModel"
            inline constexpr std::uintptr_t aimAssistModel = 0x28; // "AimAssistModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB30B00; // "public void Update()"
            inline constexpr std::uintptr_t SetTarget = 0xB30720; // "private void SetTarget(BattleAssistanceTargetModel battleAssistanceTarget, BattleAssistanceTargetPointModel battleAssistanceTargetPoint)"
        }
    } // namespace AimAssistTargetUpdater

    namespace AimByKillUpdater { // "Game.Battle.Player.AimByKillUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t maxTicksDelay = 0x10; // "int"
            inline constexpr std::uintptr_t time = 0x18; // "TimeModel"
            inline constexpr std::uintptr_t lastKillTickIndexModel = 0x20; // "IPrimitiveModel<int>"
            inline constexpr std::uintptr_t soundEmitter = 0x28; // "GameObject"
            inline constexpr std::uintptr_t soundEvent = 0x30; // "Event"
            inline constexpr std::uintptr_t aimPointerView = 0x38; // "AimPointerView"
            inline constexpr std::uintptr_t lastKillTickIndex = 0x40; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x95EAC0; // "public void Update()"
        }
    } // namespace AimByKillUpdater

    namespace AimConfig { // "Models.References.Aim.AimConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t CooldownAfterGrounded = 0x10; // "long"
        }
    } // namespace AimConfig

    namespace AimCooldownSystem { // "Models.Systems.AimCooldownSystem (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x3C77C40; // "protected override void Tick(ITick tick)"
        }
    } // namespace AimCooldownSystem

    namespace AimInputUpdater { // "Game.Battle.Inputs.AimInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t aimInputModel = 0x10; // "InputModel"
            inline constexpr std::uintptr_t jumpInputModel = 0x18; // "InputModel"
            inline constexpr std::uintptr_t autoAimIntentionModel = 0x20; // "AutoAimIntentionModel"
            inline constexpr std::uintptr_t sprintIntentionModel = 0x28; // "InputIntentionModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x30; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t battleInputModel = 0x38; // "BattleInputModel"
            inline constexpr std::uintptr_t inventoryDialogModel = 0x40; // "InventoryDialogModel"
            inline constexpr std::uintptr_t wasInProlongedInteraction = 0x48; // "bool"
            inline constexpr std::uintptr_t isHoldConsumedByProlongedInteraction = 0x49; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA71570; // "public void Update()"
            inline constexpr std::uintptr_t UpdateHoldConsumedByProlongedInteraction = 0xA714C0; // "private void UpdateHoldConsumedByProlongedInteraction(bool isInProlongedInteraction)"
            inline constexpr std::uintptr_t UpdateAimHoldMode = 0xA713B0; // "private void UpdateAimHoldMode(bool serverTargetAiming)"
            inline constexpr std::uintptr_t UpdateAimPressMode = 0xA71430; // "private void UpdateAimPressMode(bool serverTargetAiming)"
            inline constexpr std::uintptr_t InterruptAim = 0xA712F0; // "private void InterruptAim(BattleCharacterModel serverModel)"
            inline constexpr std::uintptr_t UpdateSprintIntention = 0xA71520; // "private void UpdateSprintIntention(bool serverTargetAiming, bool hasWeapon)"
        }
    } // namespace AimInputUpdater

    namespace AimModeDescription { // "Models.References.AimModeDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x8203B18; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace Fields {
            inline constexpr std::uintptr_t ShouldUseLeftShoulderForCameraWhenAiming = 0x20; // "bool"
        }
        namespace StaticFields {
            inline constexpr std::uintptr_t enum_id = 0x0; // "Enum<AimModeDescription>"
            inline constexpr std::uintptr_t ThirdPerson = 0x8; // "AimModeDescription"
            inline constexpr std::uintptr_t FirstPerson = 0x10; // "AimModeDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Enum = 0x401EFE0; // "public static ReadOnlyEnum<AimModeDescription> get_Enum()"
            inline constexpr std::uintptr_t get_Default = 0x401EF50; // "public static AimModeDescription get_Default()"
        }
    } // namespace AimModeDescription

    namespace AimModeSystem { // "Models.Systems.AimModeSystem (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x3C77E40; // "protected override void Tick(ITick tick)"
        }
    } // namespace AimModeSystem

    namespace AimPointerKillIconTimerUpdater { // "Game.Battle.Entities.Player.Updaters.AimPointerKillIconTimerUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t lastKillTick = 0x10; // "IPrimitiveModel<int>"
            inline constexpr std::uintptr_t killOtherCharacterModel = 0x18; // "KillOtherCharacterModel"
            inline constexpr std::uintptr_t oldValue = 0x20; // "long"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB00830; // "public void Update()"
        }
    } // namespace AimPointerKillIconTimerUpdater

    namespace AimScaleUpdater { // "Game.Battle.AimScaleUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t viewCanvasNoScale = 0x10; // "CanvasScaler"
            inline constexpr std::uintptr_t viewUICanvas = 0x18; // "Canvas"
            inline constexpr std::uintptr_t oldScale = 0x20; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x90C290; // "public void Update()"
        }
    } // namespace AimScaleUpdater

    namespace AimStateDescription { // "Models.References.AimStateDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x8204328; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t enum_id = 0x0; // "Enum<AimStateDescription>"
            inline constexpr std::uintptr_t Entering = 0x8; // "AimStateDescription"
            inline constexpr std::uintptr_t Exiting = 0x10; // "AimStateDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Enum = 0x401F330; // "public static ReadOnlyEnum<AimStateDescription> get_Enum()"
        }
    } // namespace AimStateDescription

    namespace AimStateModel { // "Models.Models.AimState.AimStateModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t stateEndTs = 0x10; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t state = 0x18; // "IPrimitiveData<AimStateDescription>"
            inline constexpr std::uintptr_t cooldownEndTs = 0x20; // "IPrimitiveData<long>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_EndTs = 0x49D16E0; // "public long get_EndTs()"
            inline constexpr std::uintptr_t get_State = 0x49D17C0; // "public AimStateDescription get_State()"
            inline constexpr std::uintptr_t Set = 0x49D1560; // "public void Set(long endTs, AimStateDescription state)"
            inline constexpr std::uintptr_t Clear = 0x49D1440; // "public void Clear()"
            inline constexpr std::uintptr_t CheckStart = 0x40F4D70; // "public bool CheckStart(SprintModel sprint)"
            inline constexpr std::uintptr_t get_IsCooldownActive = 0x49D1730; // "public bool get_IsCooldownActive()"
            inline constexpr std::uintptr_t get_CooldownEndTs = 0x49D1690; // "public long get_CooldownEndTs()"
            inline constexpr std::uintptr_t SetCooldown = 0x49D1500; // "public void SetCooldown(long value)"
            inline constexpr std::uintptr_t UnsetCooldown = 0x49D15F0; // "public void UnsetCooldown()"
        }
    } // namespace AimStateModel

    namespace AimTargetModel { // "Game.Battle.AimTargetModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t CharacterId = 0x10; // "int"
            inline constexpr std::uintptr_t TargetType = 0x14; // "AimTargetModel.Type"
            inline constexpr std::uintptr_t OverlayId = 0x18; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_HasTarget = 0x90C8D0; // "public bool get_HasTarget()"
            inline constexpr std::uintptr_t get_HasOverlayTarget = 0x90C8C0; // "public bool get_HasOverlayTarget()"
            inline constexpr std::uintptr_t SetTarget = 0x90C8A0; // "public void SetTarget(int characterEntityId)"
            inline constexpr std::uintptr_t SetTarget_2 = 0x90C8B0; // "public void SetTarget(AimTargetModel.Type targetType)"
            inline constexpr std::uintptr_t SetOverlayTarget = 0x7AB180; // "public void SetOverlayTarget(int characterEntityId)"
            inline constexpr std::uintptr_t Clear = 0x90C350; // "public void Clear()"
            inline constexpr std::uintptr_t GetDangerousLevelBasedOnRoles = 0x90C370; // "public static AimTargetModel.DangerousLevel GetDangerousLevelBasedOnRoles(ICharacterSlotsModel characterSlotsModel, ClanBattleTeamsCacheModel clanBattleTeamsCacheModel, PlayerRoleDescription playerRole, BattleCharacterModel aimTargetCharacter, ClanModel clanModel, PartyModel partyModel, RegionUserBattleRoomModel battleRoomModel)"
        }
    } // namespace AimTargetModel

    namespace AnimationBlendTree { // "Models.HitBox.Animation.AnimationBlendTree (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Node = 0x10; // "IBlendTreeNode"
            inline constexpr std::uintptr_t MotionTime = 0x18; // "BlendTreeMotionTime"
            inline constexpr std::uintptr_t Args = 0x20; // "BlendTreeArg[]"
        }
    } // namespace AnimationBlendTree

    namespace AnimationClip { // "Models.HitBox.Animation.AnimationClip (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Frames = 0x10; // "AnimationClipFrame[]"
            inline constexpr std::uintptr_t NormalizedTime = 0x18; // "float[]"
            inline constexpr std::uintptr_t IntervalInvLengths = 0x20; // "float[]"
            inline constexpr std::uintptr_t Duration = 0x28; // "long"
        }
        namespace Methods {
            inline constexpr std::uintptr_t CollectAnimationClipFrames = 0x4A64F60; // "public void CollectAnimationClipFrames(float normalizedTime, float animationClipWeight, List<ValueTuple<AnimationClipFrame, float>> result)"
        }
    } // namespace AnimationClip

    namespace AnimationClipBlendTreeNode { // "Models.HitBox.BlendTreeNode.AnimationClipBlendTreeNode (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t AnimationClip = 0x10; // "AnimationClip"
        }
        namespace Methods {
            inline constexpr std::uintptr_t CollectAnimationClips = 0x4A64A20; // "public void CollectAnimationClips(ReadOnlySpan<float> args, float nodeWeight, List<ValueTuple<AnimationClip, float>> result)"
        }
    } // namespace AnimationClipBlendTreeNode

    namespace AnimationClipFrame { // "Models.HitBox.Animation.AnimationClipFrame (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t BonesData = 0x10; // "float[]"
        }
    } // namespace AnimationClipFrame

    namespace AnimatorLayerExtensions { // "Models.HitBox.Layer.AnimatorLayerExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t GetAnimatorLayer = 0x4A65400; // "public static BattleCharacterAnimatorLayerDescription GetAnimatorLayer(IBattleCharacterStateModel state, CharacterCargoModel cargo, ItemInHandsModel itemInHands, BattleStanceModel battleStance)"
        }
    } // namespace AnimatorLayerExtensions

    namespace ArmorDescriptionExtensions { // "Models.Utils.Extensions.ArmorDescriptionExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t MaxArmorAmount = 0x39314A0; // "public static int MaxArmorAmount(ArmorDescription armorDescription)"
            inline constexpr std::uintptr_t MaxArmorAmount_2 = 0x3931500; // "public static int MaxArmorAmount(ArmorDescription armorDescription, ArmorConfig armorConfig)"
        }
    } // namespace ArmorDescriptionExtensions

    namespace ArmorModel { // "Models.Models.Armor.ArmorModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t equipSlot = 0x10; // "EquipSlotDescription"
            inline constexpr std::uintptr_t bodyArmorSlotModel = 0x18; // "IEquipSlotModel"
            inline constexpr std::uintptr_t amountModel = 0x20; // "IAmmoModel"
            inline constexpr std::uintptr_t equipSlotsDelays = 0x28; // "EquipSlotsDelaysModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Damage = 0x49D23A0; // "public void Damage(int damage)"
            inline constexpr std::uintptr_t Restore = 0x49D2680; // "public void Restore(int segmentsCount)"
            inline constexpr std::uintptr_t get_Amount = 0x49D28A0; // "public int get_Amount()"
            inline constexpr std::uintptr_t get_Armor = 0x49D28F0; // "public ArmorDescription get_Armor()"
            inline constexpr std::uintptr_t HasArmorItem = 0x49D2450; // "public bool HasArmorItem(long now)"
            inline constexpr std::uintptr_t HasArmor = 0x49D2500; // "public bool HasArmor(long now)"
            inline constexpr std::uintptr_t IsBroken = 0x49D25E0; // "public bool IsBroken(long now)"
            inline constexpr std::uintptr_t IsEquipSlotDelayActive = 0x49D2660; // "private bool IsEquipSlotDelayActive(long now)"
        }
    } // namespace ArmorModel

    namespace ArrestBuffUpdater { // "Game.Battle.Buffs.ArrestBuffUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleEntitiesModel = 0x40; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t isActive = 0x48; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xD24FF0; // "public override void Update()"
        }
    } // namespace ArrestBuffUpdater

    namespace ArrestConfig { // "Models.References.Arrest.ArrestConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t HandcuffTime = 0x10; // "long"
            inline constexpr std::uintptr_t ArrestingTime = 0x18; // "long"
            inline constexpr std::uintptr_t InterruptArrestingTime = 0x20; // "long"
            inline constexpr std::uintptr_t GettingUpTime = 0x28; // "long"
            inline constexpr std::uintptr_t SitTime = 0x30; // "long"
            inline constexpr std::uintptr_t ForceArrestTime = 0x38; // "long"
            inline constexpr std::uintptr_t SitFromKnockoutTime = 0x40; // "long"
            inline constexpr std::uintptr_t ArrestFinishedHideDelay = 0x48; // "long"
        }
    } // namespace ArrestConfig

    namespace ArrestLootModel { // "Models.Models.ProlongedInteractionHandler.Handlers.ArrestLootModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t worldInterruptModel = 0x10; // "IWorldInterruptModel"
            inline constexpr std::uintptr_t cargoExchangers = 0x18; // "ReadOnly.Dictionary<int, CargoExchangerModel>"
            inline constexpr std::uintptr_t cashLootNodes = 0x20; // "ReadOnly.Dictionary<int, CashLootNodeModel>"
            inline constexpr std::uintptr_t loots = 0x28; // "ReadOnly.Dictionary<int, ILootModel>"
            inline constexpr std::uintptr_t cargos = 0x30; // "ReadOnly.Dictionary<int, CargoModel>"
            inline constexpr std::uintptr_t vehicleLoots = 0x38; // "ReadOnly.Dictionary<int, IVehicleLootModel>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Process = 0x48CFA90; // "public override MutuallyExclusiveProcessesDescription get_Process()"
            inline constexpr std::uintptr_t get_StartCommand = 0x48CFB20; // "internal override UseEntityCommandDescription get_StartCommand()"
            inline constexpr std::uintptr_t get_StopCommand = 0x48CFBB0; // "internal override UseEntityCommandDescription get_StopCommand()"
            inline constexpr std::uintptr_t CheckInteractionStart = 0x48CF200; // "public override bool CheckInteractionStart(UseEntityCommandDescription command, int useEntityId, PlayerRoleDescription playerRole)"
            inline constexpr std::uintptr_t HandelRequest = 0x48CF370; // "public override void HandelRequest(long now, int entityId, ProlongedInteractionInputDescription prolongedInteractionInput, BattleCharacterModel characterModel)"
            inline constexpr std::uintptr_t TryFinishPrediction = 0x48CF710; // "public override bool TryFinishPrediction(long now, BattleCharacterModel characterModel)"
            inline constexpr std::uintptr_t TryGetTargetPosition = 0x48CF860; // "public override bool TryGetTargetPosition(int entityId, out Vector3 position)"
            inline constexpr std::uintptr_t CheckArrest = 0x48CF0C0; // "private bool CheckArrest(int entityId, out long time)"
        }
    } // namespace ArrestLootModel

    namespace ArrestLootProlongedAction { // "Game.Battle.Entities.Player.ProlongedActions.ArrestLootProlongedAction (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "ProlongedInteractionModel"
            inline constexpr std::uintptr_t worldEntitiesModel = 0x18; // "WorldEntitiesModel"
            inline constexpr std::uintptr_t Label = 0x20; // "LocalizedString"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsActive = 0xB19D30; // "public bool get_IsActive()"
            inline constexpr std::uintptr_t get_EndTs = 0xB19D10; // "public long get_EndTs()"
            inline constexpr std::uintptr_t get_Duration = 0xB19A90; // "public long get_Duration()"
            inline constexpr std::uintptr_t GetDuration = 0xB19A90; // "private long GetDuration()"
            inline constexpr std::uintptr_t Interrupt = 0xB19BF0; // "public void Interrupt(BattleInputModel battleInputModel)"
        }
    } // namespace ArrestLootProlongedAction

    namespace ArrestModel { // "Models.Models.ProlongedInteractionHandler.Handlers.ArrestModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleCharacters = 0x10; // "ReadOnly.Dictionary<int, BattleCharacterModel>"
            inline constexpr std::uintptr_t worldEntitiesModel = 0x18; // "WorldEntitiesModel"
            inline constexpr std::uintptr_t interactRaycastModel = 0x20; // "InteractRaycastModel"
            inline constexpr std::uintptr_t worldInterruptModel = 0x28; // "IWorldInterruptModel"
            inline constexpr std::uintptr_t crouchStandUpModel = 0x30; // "CrouchStandUpModel"
            inline constexpr std::uintptr_t assistingCopsFinder = 0x38; // "IAssistingCopsFinderModel"
            inline constexpr std::uintptr_t isServer = 0x40; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Process = 0x48D08E0; // "public override MutuallyExclusiveProcessesDescription get_Process()"
            inline constexpr std::uintptr_t get_StartCommand = 0x48D0970; // "internal override UseEntityCommandDescription get_StartCommand()"
            inline constexpr std::uintptr_t get_StopCommand = 0x48D0A00; // "internal override UseEntityCommandDescription get_StopCommand()"
            inline constexpr std::uintptr_t CheckInteractionStart = 0x48CFDB0; // "public override bool CheckInteractionStart(UseEntityCommandDescription command, int useEntityId, PlayerRoleDescription playerRole)"
            inline constexpr std::uintptr_t HandelRequest = 0x48CFE70; // "public override void HandelRequest(long now, int entityId, ProlongedInteractionInputDescription prolongedInteractionInput, BattleCharacterModel characterModel)"
            inline constexpr std::uintptr_t CanBeArrested = 0x48CFC40; // "private bool CanBeArrested(BattleCharacterModel targetEntity)"
            inline constexpr std::uintptr_t TryFinishPrediction = 0x48D04E0; // "public override bool TryFinishPrediction(long now, BattleCharacterModel characterModel)"
            inline constexpr std::uintptr_t TryGetTargetPosition = 0x48D0760; // "public override bool TryGetTargetPosition(int entityId, out Vector3 position)"
        }
    } // namespace ArrestModel

    namespace ArrestProlongedAction { // "Game.Battle.Entities.Player.ProlongedActions.ArrestProlongedAction (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "ProlongedInteractionModel"
            inline constexpr std::uintptr_t entityId = 0x18; // "int"
            inline constexpr std::uintptr_t Label = 0x20; // "LocalizedString"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsActive = 0xB19ED0; // "public bool get_IsActive()"
            inline constexpr std::uintptr_t get_EndTs = 0xB19D10; // "public long get_EndTs()"
            inline constexpr std::uintptr_t get_Duration = 0xB19E80; // "public long get_Duration()"
            inline constexpr std::uintptr_t Interrupt = 0xB19D40; // "public void Interrupt(BattleInputModel battleInputModel)"
            inline constexpr std::uintptr_t UpdateInterruptData = 0xB19E00; // "public void UpdateInterruptData()"
        }
    } // namespace ArrestProlongedAction

    namespace ArrestStateDescription { // "Models.References.Arrest.ArrestStateDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x8224118; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t enum_id = 0x0; // "Enum<ArrestStateDescription>"
            inline constexpr std::uintptr_t Handcuff = 0x8; // "ArrestStateDescription"
            inline constexpr std::uintptr_t Arresting = 0x10; // "ArrestStateDescription"
            inline constexpr std::uintptr_t ArrestingFromKnockout = 0x18; // "ArrestStateDescription"
            inline constexpr std::uintptr_t GettingUp = 0x20; // "ArrestStateDescription"
            inline constexpr std::uintptr_t Arrested = 0x28; // "ArrestStateDescription"
            inline constexpr std::uintptr_t Bribed = 0x30; // "ArrestStateDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Enum = 0x455C1B0; // "public static ReadOnlyEnum<ArrestStateDescription> get_Enum()"
        }
    } // namespace ArrestStateDescription

    namespace ArrestTargetModel { // "Models.Models.ArrestTarget.ArrestTargetModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t arrestState = 0x10; // "IPrimitiveData<ArrestStateDescription>"
            inline constexpr std::uintptr_t endTs = 0x18; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t interruptArrestingEndTs = 0x20; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t copEntityId = 0x28; // "int"
            inline constexpr std::uintptr_t copName = 0x30; // "string"
            inline constexpr std::uintptr_t copClanTag = 0x38; // "string"
            inline constexpr std::uintptr_t handcuffEndTsByCop = 0x40; // "Dictionary<int, long>"
            inline constexpr std::uintptr_t handcuffingCops = 0x48; // "ILinkedQueue<int>"
            inline constexpr std::uintptr_t interruptArrestingEndTsByRobber = 0x50; // "Dictionary<int, long>"
            inline constexpr std::uintptr_t interruptArrestingRobbers = 0x58; // "ILinkedQueue<int>"
            inline constexpr std::uintptr_t Cops = 0x60; // "IEventsSet<FoundCopData>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsActive = 0x49D3AA0; // "public bool get_IsActive()"
            inline constexpr std::uintptr_t get_IsHandcuffActive = 0x49D4250; // "public bool get_IsHandcuffActive()"
            inline constexpr std::uintptr_t get_IsArrestingActive = 0x49D3ED0; // "public bool get_IsArrestingActive()"
            inline constexpr std::uintptr_t get_IsArrestingFromKnockout = 0x49D4010; // "public bool get_IsArrestingFromKnockout()"
            inline constexpr std::uintptr_t get_IsGettingUpActive = 0x49D4190; // "public bool get_IsGettingUpActive()"
            inline constexpr std::uintptr_t get_IsArrested = 0x49D3E10; // "public bool get_IsArrested()"
            inline constexpr std::uintptr_t get_IsBribed = 0x49D40D0; // "public bool get_IsBribed()"
            inline constexpr std::uintptr_t get_IsArrestFinished = 0x49D3CA0; // "public bool get_IsArrestFinished()"
            inline constexpr std::uintptr_t get_ArrestState = 0x49D39B0; // "public ArrestStateDescription get_ArrestState()"
            inline constexpr std::uintptr_t get_EndTs = 0x49D3A00; // "public long get_EndTs()"
            inline constexpr std::uintptr_t get_IsInterruptArrestingActive = 0x49D4310; // "public bool get_IsInterruptArrestingActive()"
            inline constexpr std::uintptr_t get_InterruptArrestingEndTs = 0x49D3A50; // "public long get_InterruptArrestingEndTs()"
            inline constexpr std::uintptr_t get_CopEntityId = 0x7BB070; // "public int get_CopEntityId()"
            inline constexpr std::uintptr_t get_CopName = 0x7BB030; // "public string get_CopName()"
            inline constexpr std::uintptr_t get_CopClanTag = 0x7E5BC0; // "public string get_CopClanTag()"
            inline constexpr std::uintptr_t StartHandcuff = 0x49D3370; // "public void StartHandcuff(long now, int copEntityId)"
            inline constexpr std::uintptr_t InterruptHandcuff = 0x49D31C0; // "public void InterruptHandcuff(int copEntityId)"
            inline constexpr std::uintptr_t FinishHandcuff = 0x49D2D50; // "public void FinishHandcuff(long now, int copEntityId, string copName, string copClanTag, bool isFromKnockout)"
            inline constexpr std::uintptr_t FinishArresting = 0x49D2BF0; // "public void FinishArresting(long now)"
            inline constexpr std::uintptr_t FinishArrestingByBribe = 0x49D2B00; // "public void FinishArrestingByBribe(long now)"
            inline constexpr std::uintptr_t FinishArrest = 0x49D29F0; // "private void FinishArrest(long endTs, ArrestStateDescription arrestState)"
            inline constexpr std::uintptr_t StartInterruptArresting = 0x49D3520; // "public void StartInterruptArresting(long now, int robberEntityId)"
            inline constexpr std::uintptr_t StopInterruptArresting = 0x49D3680; // "public void StopInterruptArresting(int robberEntityId)"
            inline constexpr std::uintptr_t FinishInterruptArresting = 0x49D2F80; // "public void FinishInterruptArresting(long now, int robberEntityId)"
            inline constexpr std::uintptr_t ClearCopsInfo = 0x49D2980; // "private void ClearCopsInfo()"
            inline constexpr std::uintptr_t FinishGettingUp = 0x49D2C90; // "public void FinishGettingUp()"
            inline constexpr std::uintptr_t StopArresting = 0x49D3630; // "public void StopArresting()"
        }
    } // namespace ArrestTargetModel

    namespace AutoAimIntentionModel { // "Game.Battle.Inputs.AutoAimIntentionModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsSet = 0x10; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Set = 0xA71850; // "public void Set()"
            inline constexpr std::uintptr_t Unset = 0x844D10; // "public void Unset()"
        }
    } // namespace AutoAimIntentionModel

    namespace AutoAimIntentionUpdater { // "Game.Battle.Inputs.AutoAimIntentionUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t gameSettings = 0x10; // "GameSettingsModel"
            inline constexpr std::uintptr_t battleEntities = 0x18; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t autoAimIntentionModel = 0x20; // "AutoAimIntentionModel"
            inline constexpr std::uintptr_t shotInput = 0x28; // "InputModel"
            inline constexpr std::uintptr_t shotInputLockModel = 0x30; // "ShotInputLockModel"
            inline constexpr std::uintptr_t battleAssistanceViewDescription = 0x38; // "BattleAssistanceViewDescription"
            inline constexpr std::uintptr_t exitDelayTimer = 0x40; // "float"
            inline constexpr std::uintptr_t hasAutoFire = 0x44; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA71C30; // "public void Update()"
            inline constexpr std::uintptr_t UpdateActiveState = 0xA71A70; // "private void UpdateActiveState(PlayerEntityModel player)"
            inline constexpr std::uintptr_t GetActiveState = 0xA718B0; // "private bool GetActiveState(PlayerEntityModel player)"
            inline constexpr std::uintptr_t TickTimer = 0xA71A30; // "private void TickTimer()"
            inline constexpr std::uintptr_t ResetShotLockWhenFullyAimed = 0xA719C0; // "private void ResetShotLockWhenFullyAimed(PlayerEntityModel player)"
            inline constexpr std::uintptr_t CacheAutoFireState = 0xA71860; // "private void CacheAutoFireState(PlayerEntityModel player)"
        }
    } // namespace AutoAimIntentionUpdater

    namespace AutoFireModel { // "Game.Battle.Entities.Player.BattleAssistance.AutoFireModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsActive = 0x10; // "bool"
            inline constexpr std::uintptr_t IsFiring = 0x11; // "bool"
            inline constexpr std::uintptr_t HasTarget = 0x12; // "bool"
            inline constexpr std::uintptr_t Target = 0x18; // "BattleAssistanceTargetModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetTarget = 0xB31E40; // "public void SetTarget(BattleAssistanceTargetModel target)"
            inline constexpr std::uintptr_t ClearTarget = 0xB31E20; // "public void ClearTarget()"
        }
    } // namespace AutoFireModel

    namespace AutoFireModelUpdater { // "Game.Battle.Entities.Player.BattleAssistance.AutoFireModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t gameSettings = 0x10; // "GameSettingsModel"
            inline constexpr std::uintptr_t battleAssistanceModel = 0x18; // "BattleAssistanceModel"
            inline constexpr std::uintptr_t playerModel = 0x20; // "PlayerEntityModel"
            inline constexpr std::uintptr_t autoFireModel = 0x28; // "AutoFireModel"
            inline constexpr std::uintptr_t timer = 0x30; // "float"
            inline constexpr std::uintptr_t tapTimer = 0x34; // "float"
            inline constexpr std::uintptr_t lastShotCooldownByDistance = 0x38; // "float"
            inline constexpr std::uintptr_t canUpdate = 0x3C; // "bool"
            inline constexpr std::uintptr_t isFiring = 0x3D; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB31BF0; // "public void Update()"
            inline constexpr std::uintptr_t UpdateActiveState = 0xB318B0; // "private void UpdateActiveState()"
            inline constexpr std::uintptr_t UpdateFiringState = 0xB318D0; // "private void UpdateFiringState()"
            inline constexpr std::uintptr_t UpdateAutomaticWeapon = 0x7D5050; // "private bool UpdateAutomaticWeapon()"
            inline constexpr std::uintptr_t UpdateSemiAutomaticWeapon = 0xB31B10; // "private bool UpdateSemiAutomaticWeapon(WeaponDescription weaponDescription)"
            inline constexpr std::uintptr_t IsPlayerInValidState = 0xB317A0; // "private bool IsPlayerInValidState()"
            inline constexpr std::uintptr_t Reset = 0xB31870; // "private void Reset()"
        }
    } // namespace AutoFireModelUpdater

    namespace AutoFireTargetModel { // "Game.Battle.Entities.Player.BattleAssistance.AutoFireTargetModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsPotentialTarget = 0x10; // "bool"
            inline constexpr std::uintptr_t IsColliderReachable = 0x11; // "bool"
            inline constexpr std::uintptr_t view = 0x18; // "BattleAssistanceTargetView"
            inline constexpr std::uintptr_t rect = 0x20; // "Rect"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_WorldRectHalfSize = 0xB31EB0; // "public Vector3 get_WorldRectHalfSize()"
            inline constexpr std::uintptr_t get_ScreenRectRef = 0xB306D0; // "public ref Rect get_ScreenRectRef()"
            inline constexpr std::uintptr_t Reset = 0xB31E60; // "public void Reset()"
        }
    } // namespace AutoFireTargetModel

    namespace AutoFireTargetUpdater { // "Game.Battle.Entities.Player.BattleAssistance.AutoFireTargetUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleAssistanceModel = 0x10; // "BattleAssistanceModel"
            inline constexpr std::uintptr_t autoFireModel = 0x18; // "AutoFireModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB31EF0; // "public void Update()"
        }
    } // namespace AutoFireTargetUpdater

    namespace AutomaticShotInputUpdater { // "Game.Battle.Inputs.AutomaticShotInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleEntitiesModel = 0x10; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t timeModel = 0x18; // "TimeModel"
            inline constexpr std::uintptr_t battleInputModel = 0x20; // "BattleInputModel"
            inline constexpr std::uintptr_t playerRotationInput = 0x28; // "PlayerRotationInputModel"
            inline constexpr std::uintptr_t shotIntentionModel = 0x30; // "ShotIntentionModel"
            inline constexpr std::uintptr_t shotParamsModel = 0x38; // "ShotParamsModel"
            inline constexpr std::uintptr_t playerNowTs = 0x40; // "long"
            inline constexpr std::uintptr_t currentTickStartTs = 0x48; // "long"
            inline constexpr std::uintptr_t previousTickStartTs = 0x50; // "long"
            inline constexpr std::uintptr_t currentLookDirection = 0x58; // "Vector3"
            inline constexpr std::uintptr_t currentTickStartLookDirection = 0x64; // "Vector3"
            inline constexpr std::uintptr_t previousTickStartLookDirection = 0x70; // "Vector3"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA87610; // "public void Update()"
            inline constexpr std::uintptr_t Stop = 0xA87460; // "public void Stop()"
            inline constexpr std::uintptr_t UpdateRuntimeData = 0xA874A0; // "private void UpdateRuntimeData()"
            inline constexpr std::uintptr_t SetShotParams = 0xA87140; // "private void SetShotParams()"
            inline constexpr std::uintptr_t CanFollowPreviousShot = 0xA86E90; // "private bool CanFollowPreviousShot(long shotEndTs)"
            inline constexpr std::uintptr_t SetInput = 0xA86EC0; // "private void SetInput()"
        }
    } // namespace AutomaticShotInputUpdater

    namespace BattleAimTargetUpdater { // "Game.Battle.Entities.Player.Updaters.BattleAimTargetUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsSceneModel = 0x10; // "PhysicsSceneModel"
            inline constexpr std::uintptr_t hitBoxesModel = 0x18; // "HitBoxesModel"
            inline constexpr std::uintptr_t physicsBodiesModel = 0x20; // "PhysicsBodiesModel"
            inline constexpr std::uintptr_t aimTargetModel = 0x28; // "AimTargetModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x30; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t playerRotationInput = 0x38; // "PlayerRotationInputModel"
            inline constexpr std::uintptr_t raycastModel = 0x40; // "RaycastModel"
            inline constexpr std::uintptr_t cinemachineBrain = 0x48; // "CinemachineBrain"
            inline constexpr std::uintptr_t weaponViewDescriptions = 0x50; // "WeaponViewDescriptions"
            inline constexpr std::uintptr_t maxRaycastDistance = 0x58; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB02380; // "public void Update()"
            inline constexpr std::uintptr_t RaycastTarget = 0xB01920; // "private void RaycastTarget()"
        }
    } // namespace BattleAimTargetUpdater

    namespace BattleCharacterDamageZoneCollisionSystem { // "Models.Systems.BattleCharacterDamageZoneCollisionSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsSceneModel = 0x38; // "PhysicsSceneModel"
            inline constexpr std::uintptr_t physicsBodiesModel = 0x40; // "PhysicsBodiesModel"
            inline constexpr std::uintptr_t analytics = 0x48; // "IBattleSystemsAnalyticsModel"
            inline constexpr std::uintptr_t touchingBodiesResult = 0x50; // "List<PhysicsBodyId>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x3F7B060; // "protected override void Tick(ITick tick)"
        }
    } // namespace BattleCharacterDamageZoneCollisionSystem

    namespace BattleCharacterDamageZoneModel { // "Models.Models.BattleCharacterDamageZone.BattleCharacterDamageZoneModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t effect = 0x10; // "IPrimitiveData<DamageZoneEffectDescription>"
            inline constexpr std::uintptr_t LastEffect = 0x18; // "DamageZoneEffectDescription"
            inline constexpr std::uintptr_t DamageCooldownEndTs = 0x20; // "long"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Effect = 0x49D6840; // "public DamageZoneEffectDescription get_Effect()"
            inline constexpr std::uintptr_t set_Effect = 0x49D6900; // "public void set_Effect(DamageZoneEffectDescription value)"
        }
    } // namespace BattleCharacterDamageZoneModel

    namespace BattleCharacterDebugShotUpdater { // "Game.Battle.EntityModel.BattleCharacter.Shoot.BattleCharacterDebugShotUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t time = 0x10; // "TimeModel"
            inline constexpr std::uintptr_t weaponModel = 0x18; // "IWeaponModel"
            inline constexpr std::uintptr_t shotArgsModel = 0x20; // "ShotArgsModel"
            inline constexpr std::uintptr_t fireModel = 0x28; // "FireModel"
            inline constexpr std::uintptr_t lastShotTickIndex = 0x30; // "long"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xCC62C0; // "public void Update()"
        }
    } // namespace BattleCharacterDebugShotUpdater

    namespace BattleCharacterFireModelUpdater { // "Game.Battle.Entities.BattleCharacter.Shoot.BattleCharacterFireModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t characterFireModel = 0x10; // "CharacterFireModel"
            inline constexpr std::uintptr_t timeModel = 0x18; // "TimeModel"
            inline constexpr std::uintptr_t fireModel = 0x20; // "FireModel"
            inline constexpr std::uintptr_t shotResultModel = 0x28; // "ShotResultModel"
            inline constexpr std::uintptr_t tickIndex = 0x30; // "long"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xBD3550; // "public void Update()"
        }
    } // namespace BattleCharacterFireModelUpdater

    namespace BattleCharacterHitBoxAccessModel { // "Models.Models.HitBoxAccessModel.BattleCharacterHitBoxAccessModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleCharacterStateModel = 0x10; // "IBattleCharacterStateModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsHaveAccess = 0x492CE60; // "public bool get_IsHaveAccess()"
        }
    } // namespace BattleCharacterHitBoxAccessModel

    namespace BattleCharacterKnockdownExtensions { // "Models.Utils.Extensions.BattleCharacterKnockdownExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t SetRequestFromVehicle = 0x39319B0; // "public static void SetRequestFromVehicle(PhysicsSceneModel physicsSceneModel, BattleCharacterModel battleCharacter, in Vector3 vehiclePosition, in Quaternion vehicleOrientation)"
        }
    } // namespace BattleCharacterKnockdownExtensions

    namespace BattleCharacterPredictShotUpdater { // "Game.Battle.EntityModel.BattleCharacter.Shoot.BattleCharacterPredictShotUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t bodyId = 0x10; // "PhysicsBodyId"
            inline constexpr std::uintptr_t id = 0x18; // "int"
            inline constexpr std::uintptr_t shotArgsModel = 0x20; // "ShotArgsModel"
            inline constexpr std::uintptr_t time = 0x28; // "TimeModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x30; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t locationHitsModel = 0x38; // "LocationHitsModel"
            inline constexpr std::uintptr_t shotResultModel = 0x40; // "ShotResultModel"
            inline constexpr std::uintptr_t charactersShotsModel = 0x48; // "CharactersShotsModel"
            inline constexpr std::uintptr_t physicsSceneModel = 0x50; // "PhysicsSceneModel"
            inline constexpr std::uintptr_t hitBoxesModel = 0x58; // "HitBoxesModel"
            inline constexpr std::uintptr_t weaponModel = 0x60; // "IWeaponModel"
            inline constexpr std::uintptr_t raycastModel = 0x68; // "RaycastModel"
            inline constexpr std::uintptr_t fireModel = 0x70; // "FireModel"
            inline constexpr std::uintptr_t lastShotTickIndex = 0x78; // "long"
            inline constexpr std::uintptr_t wasFiring = 0x80; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xCC6E30; // "public void Update()"
        }
    } // namespace BattleCharacterPredictShotUpdater

    namespace BattleCharacterStaminaClientSystem { // "ClientCore.Systems.BattleCharacterStaminaClientSystem (Client.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t HandleDamage = 0x7B3360; // "protected override void HandleDamage(int entityId, int damage, long now)"
        }
    } // namespace BattleCharacterStaminaClientSystem

    namespace BattleCharacterStaminaConfig { // "Models.References.Character.BattleCharacterStaminaConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t WasteSpeedPerSecond = 0x10; // "int"
            inline constexpr std::uintptr_t RecoverySpeedPerSecond = 0x14; // "int"
            inline constexpr std::uintptr_t RecoveryDelay = 0x18; // "long"
            inline constexpr std::uintptr_t DamagePerSecond = 0x20; // "int"
            inline constexpr std::uintptr_t MaxAmount = 0x24; // "int"
        }
    } // namespace BattleCharacterStaminaConfig

    namespace BattleCharacterStaminaDamageModel { // "Models.Models.BattleCharacterStaminaDamage.BattleCharacterStaminaDamageModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t LastDamageTs = 0x10; // "long"
        }
    } // namespace BattleCharacterStaminaDamageModel

    namespace BattleCharacterStaminaExtensions { // "Models.Utils.Extensions.BattleCharacterStaminaExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t ChangeDirection = 0x3932320; // "public static ValueTuple<long, int, bool> ChangeDirection(BattleCharacterStaminaConfig config, long now, long directionChangeTs, int directionChangeAmount, bool decreaseDirection)"
            inline constexpr std::uintptr_t ChangeDirection_2 = 0x39323D0; // "public static void ChangeDirection(long now, BattleCharacterStaminaModel stamina)"
            inline constexpr std::uintptr_t GetAmount = 0x39326D0; // "public static int GetAmount(BattleCharacterStaminaConfig config, long now, long directionChangeTs, int directionChangeAmount, bool decreaseDirection)"
            inline constexpr std::uintptr_t GetAmount_2 = 0x3932820; // "public static int GetAmount(long now, BattleCharacterStaminaModel stamina)"
            inline constexpr std::uintptr_t IsActive = 0x39328B0; // "public static bool IsActive(long directionChangeTs)"
            inline constexpr std::uintptr_t IsActive_2 = 0x3932910; // "public static bool IsActive(BattleCharacterStaminaModel stamina)"
            inline constexpr std::uintptr_t Clear = 0x39325F0; // "public static ValueTuple<long, int, bool> Clear()"
            inline constexpr std::uintptr_t Clear_2 = 0x39324E0; // "public static void Clear(BattleCharacterStaminaModel stamina)"
        }
    } // namespace BattleCharacterStaminaExtensions

    namespace BattleCharacterStaminaModel { // "Models.Models.BattleCharacterStamina.BattleCharacterStaminaModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t directionChangeTs = 0x10; // "TimestampData"
            inline constexpr std::uintptr_t directionChangeAmount = 0x18; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t decreaseDirection = 0x20; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t Config = 0x28; // "BattleCharacterStaminaConfig"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_DirectionChangeTs = 0x49DC200; // "public long get_DirectionChangeTs()"
            inline constexpr std::uintptr_t set_DirectionChangeTs = 0x49DC2E0; // "public void set_DirectionChangeTs(long value)"
            inline constexpr std::uintptr_t get_DirectionChangeAmount = 0x49DC1B0; // "public int get_DirectionChangeAmount()"
            inline constexpr std::uintptr_t set_DirectionChangeAmount = 0x49DC290; // "public void set_DirectionChangeAmount(int value)"
            inline constexpr std::uintptr_t get_DecreaseDirection = 0x49DC160; // "public bool get_DecreaseDirection()"
            inline constexpr std::uintptr_t set_DecreaseDirection = 0x49DC240; // "public void set_DecreaseDirection(bool value)"
        }
    } // namespace BattleCharacterStaminaModel

    namespace BattleCharacterStaminaSystem { // "Models.Systems.BattleCharacterStaminaSystem (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x3F7B7B0; // "protected override void Tick(ITick tick)"
        }
    } // namespace BattleCharacterStaminaSystem

    namespace BattleWeaponSkinModificationDescription { // "Game.Battle.Equipment.Weapon.BattleWeaponSkinModificationDescription (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Id = 0x10; // "string"
            inline constexpr std::uintptr_t ModelContent = 0x18; // "BattleWeaponSkinModificationDescription.ModelReference"
            inline constexpr std::uintptr_t MaterialContent = 0x20; // "BattleWeaponSkinModificationDescription.MaterialReference"
        }
    } // namespace BattleWeaponSkinModificationDescription

    namespace BattleWeaponSkinModificationDescription_MaterialReference { // "Game.Battle.Equipment.Weapon.BattleWeaponSkinModificationDescription.MaterialReference (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t materialReferences = 0x10; // "AssetReference[]"
            inline constexpr std::uintptr_t Materials = 0x18; // "List<NotInstantiateLoadedContent<Material>>"
            inline constexpr std::uintptr_t Content = 0x20; // "ILoadedContent[]"
        }
    } // namespace BattleWeaponSkinModificationDescription_MaterialReference

    namespace BattleWeaponSkinModificationDescription_ModelReference { // "Game.Battle.Equipment.Weapon.BattleWeaponSkinModificationDescription.ModelReference (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t weaponReference = 0x10; // "AssetReference"
            inline constexpr std::uintptr_t Weapon = 0x18; // "PooledLoadedComponentContent<CharacterWeaponView>"
            inline constexpr std::uintptr_t Content = 0x20; // "ILoadedContent[]"
        }
    } // namespace BattleWeaponSkinModificationDescription_ModelReference

    namespace BlendTreeArg { // "Models.HitBox.Arg.BlendTreeArg (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x825FFA0; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace Fields {
            inline constexpr std::uintptr_t calculateFunc = 0x20; // "Func<long, BattleCharacterModel, WorldEntitiesModel, float>"
        }
        namespace StaticFields {
            inline constexpr std::uintptr_t enum_id = 0x0; // "Enum<BlendTreeArg>"
            inline constexpr std::uintptr_t Crouch = 0x8; // "BlendTreeArg"
            inline constexpr std::uintptr_t MoveModeX = 0x10; // "BlendTreeArg"
            inline constexpr std::uintptr_t MoveModeY = 0x18; // "BlendTreeArg"
            inline constexpr std::uintptr_t RelativeVelocityDirectionX = 0x20; // "BlendTreeArg"
            inline constexpr std::uintptr_t RelativeVelocityDirectionY = 0x28; // "BlendTreeArg"
            inline constexpr std::uintptr_t Armed = 0x30; // "BlendTreeArg"
            inline constexpr std::uintptr_t VehicleInputX = 0x38; // "BlendTreeArg"
            inline constexpr std::uintptr_t VehicleInputY = 0x40; // "BlendTreeArg"
            inline constexpr std::uintptr_t VehicleInputZ = 0x48; // "BlendTreeArg"
            inline constexpr std::uintptr_t KnockoutDirectionX = 0x50; // "BlendTreeArg"
            inline constexpr std::uintptr_t KnockoutDirectionY = 0x58; // "BlendTreeArg"
            inline constexpr std::uintptr_t Sprint = 0x60; // "BlendTreeArg"
            inline constexpr std::uintptr_t AimY = 0x68; // "BlendTreeArg"
            inline constexpr std::uintptr_t Boxing = 0x70; // "BlendTreeArg"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Enum = 0x4A6FDE0; // "public static ReadOnlyEnum<BlendTreeArg> get_Enum()"
            inline constexpr std::uintptr_t Calculate = 0x4A6F480; // "public float Calculate(long now, BattleCharacterModel character, WorldEntitiesModel worldEntitiesModel)"
        }
    } // namespace BlendTreeArg

    namespace BlendTreeArgExtensions { // "Models.HitBox.Arg.BlendTreeArgExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t CalculateArgs = 0x4A6DF70; // "public static void CalculateArgs(ReadOnlySpan<BlendTreeArg> args, long now, BattleCharacterModel character, WorldEntitiesModel worldEntitiesModel, Span<float> argsCalculated)"
            inline constexpr std::uintptr_t CalculateCrouchArgForBlendTree = 0x4A6E2A0; // "public static float CalculateCrouchArgForBlendTree(long now, BattleCharacterModel character, WorldEntitiesModel worldEntitiesModel)"
            inline constexpr std::uintptr_t CalculateCrouch = 0x4A6E2D0; // "public static float CalculateCrouch(long now, BattleCharacterConfig battleCharacterConfig, CrouchModel crouchModel)"
            inline constexpr std::uintptr_t CalculateCrouch_2 = 0x4A6E3A0; // "public static float CalculateCrouch(long now, BattleCharacterConfig battleCharacterConfig, bool isInTransition, bool isCrouching, long transitionEndTs)"
            inline constexpr std::uintptr_t CalculateMoveModeXArgForBlendTree = 0x4A6E730; // "public static float CalculateMoveModeXArgForBlendTree(long now, BattleCharacterModel character, WorldEntitiesModel worldEntitiesModel)"
            inline constexpr std::uintptr_t CalculateMoveModeYArgForBlendTree = 0x4A6E760; // "public static float CalculateMoveModeYArgForBlendTree(long now, BattleCharacterModel character, WorldEntitiesModel worldEntitiesModel)"
            inline constexpr std::uintptr_t CalculateMoveModePrev = 0x4A6E630; // "public static Vector2 CalculateMoveModePrev(float velocity, in Vector2 currentMode, float dt)"
            inline constexpr std::uintptr_t CalculateMoveMode = 0x4A6E790; // "public static Vector2 CalculateMoveMode(Vector2 moveModePrev, float crouch)"
            inline constexpr std::uintptr_t CalculateTargetMoveMode = 0x4A6EFF0; // "private static Vector2 CalculateTargetMoveMode(float velocity, in Vector2 currentMode)"
            inline constexpr std::uintptr_t CalculateRelativeVelocityDirectionXArgForBlendTree = 0x4A6E890; // "public static float CalculateRelativeVelocityDirectionXArgForBlendTree(long now, BattleCharacterModel character, WorldEntitiesModel worldEntitiesModel)"
            inline constexpr std::uintptr_t CalculateRelativeVelocityDirectionYArgForBlendTree = 0x4A6E8C0; // "public static float CalculateRelativeVelocityDirectionYArgForBlendTree(long now, BattleCharacterModel character, WorldEntitiesModel worldEntitiesModel)"
            inline constexpr std::uintptr_t CalculateBoxingArgForBlendTree = 0xABFFA0; // "public static float CalculateBoxingArgForBlendTree(long now, BattleCharacterModel character, WorldEntitiesModel worldEntitiesModel)"
            inline constexpr std::uintptr_t CalculateRelativeVelocity = 0x4A6E8F0; // "public static void CalculateRelativeVelocity(ITransformModel transformModel, CharacterVelocityModel velocityModel, IPrimitiveModel<CharacterControllerStateDescription> characterControllerState, CharacterSpeedModel characterSpeedModel, float dt, out float relativeVelocity, out float relativeVelocityDirectionX, out float relativeVelocityDirectionY)"
            inline constexpr std::uintptr_t CalculateBaseSpeedForRelativeVelocity = 0x4A6E150; // "public static float CalculateBaseSpeedForRelativeVelocity(CharacterControllerStateDescription characterControllerState, CharacterSpeedModel speed)"
            inline constexpr std::uintptr_t CalculateRelativeVelocity_2 = 0x4A6ED20; // "public static void CalculateRelativeVelocity(in Vector3 tickPositionDiff, in Quaternion lookRotation, float baseSpeed, float dt, out float relativeVelocity, out float relativeVelocityDirectionX, out float relativeVelocityDirectionY)"
            inline constexpr std::uintptr_t CalculateArmedArgForBlendTree = 0x4A6E070; // "public static float CalculateArmedArgForBlendTree(long now, BattleCharacterModel character, WorldEntitiesModel worldEntitiesModel)"
            inline constexpr std::uintptr_t CalculateArmed = 0x4A6E0B0; // "public static float CalculateArmed(BattleCharacterModel character, float armedPrev, float changeSpeed)"
            inline constexpr std::uintptr_t CalculateVehicleInputXForBlendTree = 0x4A6F0E0; // "public static float CalculateVehicleInputXForBlendTree(long now, BattleCharacterModel character, WorldEntitiesModel worldEntitiesModel)"
            inline constexpr std::uintptr_t CalculateVehicleInputYForBlendTree = 0x4A6F240; // "public static float CalculateVehicleInputYForBlendTree(long now, BattleCharacterModel character, WorldEntitiesModel worldEntitiesModel)"
            inline constexpr std::uintptr_t CalculateVehicleInputZForBlendTree = 0x4A6F300; // "public static float CalculateVehicleInputZForBlendTree(long now, BattleCharacterModel character, WorldEntitiesModel worldEntitiesModel)"
            inline constexpr std::uintptr_t CalculateCarInputX = 0x4A6E220; // "public static float CalculateCarInputX(CarModel car)"
            inline constexpr std::uintptr_t CalculateCarInputZ = 0x4A6E250; // "public static float CalculateCarInputZ(CarModel car)"
            inline constexpr std::uintptr_t CalculateHelicopterInputX = 0x4A6E430; // "public static float CalculateHelicopterInputX(HelicopterModel helicopter)"
            inline constexpr std::uintptr_t CalculateHelicopterInputY = 0x4A6E460; // "public static float CalculateHelicopterInputY(HelicopterModel helicopter)"
            inline constexpr std::uintptr_t CalculateHelicopterInputZ = 0x4A6E490; // "public static float CalculateHelicopterInputZ(HelicopterModel helicopter)"
            inline constexpr std::uintptr_t CalculateKnockoutDirectionXArgForBlendTree = 0x4A6E4C0; // "public static float CalculateKnockoutDirectionXArgForBlendTree(long now, BattleCharacterModel character, WorldEntitiesModel worldEntitiesModel)"
            inline constexpr std::uintptr_t CalculateKnockoutDirectionYArgForBlendTree = 0x4A6E540; // "public static float CalculateKnockoutDirectionYArgForBlendTree(long now, BattleCharacterModel character, WorldEntitiesModel worldEntitiesModel)"
            inline constexpr std::uintptr_t CalculateKnockoutDirection = 0x4A6E5C0; // "public static ValueTuple<float, float> CalculateKnockoutDirection(KnockoutModel knockout, ITransformModel transform)"
            inline constexpr std::uintptr_t CalculateSprintArgForBlendTree = 0x4A6EF50; // "public static float CalculateSprintArgForBlendTree(long now, BattleCharacterModel character, WorldEntitiesModel worldEntitiesModel)"
            inline constexpr std::uintptr_t CalculateSprint = 0x4A6EF80; // "public static float CalculateSprint(BattleCharacterConfig battleCharacterConfig, float velocity, float currentSprint, float dt)"
            inline constexpr std::uintptr_t CalculateAimYArgForBlendTree = 0x4A6DB40; // "public static float CalculateAimYArgForBlendTree(long now, BattleCharacterModel character, WorldEntitiesModel worldEntitiesModel)"
            inline constexpr std::uintptr_t CalculateAimY = 0x4A6DDD0; // "public static float CalculateAimY(float pitchAbsThreshold, bool isArmed, BattleStanceDescription battleStance, bool isBreakColliderActive, float pitch, float prevAimY, float lerpSpeed)"
            inline constexpr std::uintptr_t CalculatePitchThresholdAbsForAimY = 0x4A6E7D0; // "public static float CalculatePitchThresholdAbsForAimY(BattleCharacterSkeletonDeformationConfig skeletonDeformationDescription)"
        }
    } // namespace BlendTreeArgExtensions

    namespace BlendTreeMotionTime { // "Models.HitBox.MotionTime.BlendTreeMotionTime (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x8260480; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace Fields {
            inline constexpr std::uintptr_t calculateFunc = 0x20; // "Func<long, BattleCharacterModel, float>"
        }
        namespace StaticFields {
            inline constexpr std::uintptr_t enum_id = 0x0; // "Enum<BlendTreeMotionTime>"
            inline constexpr std::uintptr_t AverageFrame = 0x8; // "BlendTreeMotionTime"
            inline constexpr std::uintptr_t AnimationClip = 0x10; // "BlendTreeMotionTime"
            inline constexpr std::uintptr_t AnimationClipLoop = 0x18; // "BlendTreeMotionTime"
            inline constexpr std::uintptr_t ArrestedIn = 0x20; // "BlendTreeMotionTime"
            inline constexpr std::uintptr_t ArrestedOut = 0x28; // "BlendTreeMotionTime"
            inline constexpr std::uintptr_t Arresting = 0x30; // "BlendTreeMotionTime"
            inline constexpr std::uintptr_t ArrestingInterrupt = 0x38; // "BlendTreeMotionTime"
            inline constexpr std::uintptr_t BecomeRobberPreCast = 0x40; // "BlendTreeMotionTime"
            inline constexpr std::uintptr_t BecomeRobberPostCast = 0x48; // "BlendTreeMotionTime"
            inline constexpr std::uintptr_t EmotionPreCast = 0x50; // "BlendTreeMotionTime"
            inline constexpr std::uintptr_t EmotionCast = 0x58; // "BlendTreeMotionTime"
            inline constexpr std::uintptr_t Knockdown = 0x60; // "BlendTreeMotionTime"
            inline constexpr std::uintptr_t KnockoutIn = 0x68; // "BlendTreeMotionTime"
            inline constexpr std::uintptr_t KnockoutOut = 0x70; // "BlendTreeMotionTime"
            inline constexpr std::uintptr_t Reviving = 0x78; // "BlendTreeMotionTime"
            inline constexpr std::uintptr_t UseItemPreCast = 0x80; // "BlendTreeMotionTime"
            inline constexpr std::uintptr_t UseItemPostCast = 0x88; // "BlendTreeMotionTime"
            inline constexpr std::uintptr_t ForceArrest = 0x90; // "BlendTreeMotionTime"
            inline constexpr std::uintptr_t ArrestedInKnockout = 0x98; // "BlendTreeMotionTime"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Enum = 0x4A71D80; // "public static ReadOnlyEnum<BlendTreeMotionTime> get_Enum()"
            inline constexpr std::uintptr_t Calculate = 0x4A71150; // "public float Calculate(long now, BattleCharacterModel character)"
        }
    } // namespace BlendTreeMotionTime

    namespace BlendTreeMotionTimeExtensions { // "Models.HitBox.MotionTime.BlendTreeMotionTimeExtensions (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x8260620; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t animationClips = 0x0; // "List<ValueTuple<AnimationClip, float>>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t IsNativeMotionTime = 0x4A71040; // "public static bool IsNativeMotionTime(BlendTreeMotionTime motionTime)"
            inline constexpr std::uintptr_t CalculateDurationForBlendTree = 0x4A70850; // "public static long CalculateDurationForBlendTree(IBlendTreeNode blendTreeNode)"
            inline constexpr std::uintptr_t CalculateDurationForBlendTree_2 = 0x4A70A20; // "public static long CalculateDurationForBlendTree(IBlendTreeNode blendTreeNode, ReadOnlySpan<float> blendTreeArgs)"
            inline constexpr std::uintptr_t CalculateDurationForAnimationClips = 0x4A706E0; // "public static long CalculateDurationForAnimationClips(List<ValueTuple<AnimationClip, float>> animationClips)"
            inline constexpr std::uintptr_t CalculateAverageFrame = 0xABFFA0; // "public static float CalculateAverageFrame(long now, BattleCharacterModel character)"
            inline constexpr std::uintptr_t CalculateAnimationClip = 0x4A6FFE0; // "public static float CalculateAnimationClip(long now, BattleCharacterModel character)"
            inline constexpr std::uintptr_t CalculateAnimationClipLoop = 0x4A6FE30; // "public static float CalculateAnimationClipLoop(long now, BattleCharacterModel character)"
            inline constexpr std::uintptr_t CalculateAnimationClipNormalizedTimeNotClamped = 0x4A6FF40; // "private static float CalculateAnimationClipNormalizedTimeNotClamped(long now, BattleCharacterModel character)"
            inline constexpr std::uintptr_t CalculateArrestedIn = 0x4A70160; // "public static float CalculateArrestedIn(long now, BattleCharacterModel character)"
            inline constexpr std::uintptr_t CalculateArrestedOut = 0x4A70200; // "public static float CalculateArrestedOut(long now, BattleCharacterModel character)"
            inline constexpr std::uintptr_t CalculateArresting = 0x4A70340; // "public static float CalculateArresting(long now, BattleCharacterModel character)"
            inline constexpr std::uintptr_t CalculateArrestingInterrupt = 0x4A702A0; // "public static float CalculateArrestingInterrupt(long now, BattleCharacterModel character)"
            inline constexpr std::uintptr_t CalculateForceArrest = 0x4A70C60; // "public static float CalculateForceArrest(long now, BattleCharacterModel character)"
            inline constexpr std::uintptr_t CalculateArrestedInKnockout = 0x4A700C0; // "public static float CalculateArrestedInKnockout(long now, BattleCharacterModel character)"
            inline constexpr std::uintptr_t CalculateBecomeRobberPreCast = 0x4A70600; // "public static float CalculateBecomeRobberPreCast(long now, BattleCharacterModel character)"
            inline constexpr std::uintptr_t CalculateBecomeRobberPreCast_2 = 0x4A70560; // "public static float CalculateBecomeRobberPreCast(long now, BecomeRobberModel becomeRobberModel)"
            inline constexpr std::uintptr_t CalculateBecomeRobberPostCast = 0x4A70480; // "public static float CalculateBecomeRobberPostCast(long now, BattleCharacterModel character)"
            inline constexpr std::uintptr_t CalculateBecomeRobberPostCast_2 = 0x4A703E0; // "public static float CalculateBecomeRobberPostCast(long now, BecomeRobberModel becomeRobberModel)"
            inline constexpr std::uintptr_t CalculateEmotionPreCast = 0x4A70C00; // "public static float CalculateEmotionPreCast(long now, BattleCharacterModel character)"
            inline constexpr std::uintptr_t CalculateEmotionCast = 0x4A70BA0; // "public static float CalculateEmotionCast(long now, BattleCharacterModel character)"
            inline constexpr std::uintptr_t CalculateKnockdown = 0x4A70D00; // "public static float CalculateKnockdown(long now, BattleCharacterModel character)"
            inline constexpr std::uintptr_t CalculateKnockoutIn = 0x4A70DE0; // "public static float CalculateKnockoutIn(long now, BattleCharacterModel character)"
            inline constexpr std::uintptr_t CalculateKnockoutIn_2 = 0x4A70E70; // "public static float CalculateKnockoutIn(long now, KnockoutModel knockout)"
            inline constexpr std::uintptr_t CalculateKnockoutOut = 0x4A70EC0; // "public static float CalculateKnockoutOut(long now, BattleCharacterModel character)"
            inline constexpr std::uintptr_t CalculateReviving = 0x4A70F10; // "public static float CalculateReviving(long now, BattleCharacterModel character)"
            inline constexpr std::uintptr_t CalculateUseItemPreCast = 0x4A70FD0; // "public static float CalculateUseItemPreCast(long now, BattleCharacterModel character)"
            inline constexpr std::uintptr_t CalculateUseItemPostCast = 0x4A70F60; // "public static float CalculateUseItemPostCast(long now, BattleCharacterModel character)"
        }
    } // namespace BlendTreeMotionTimeExtensions

    namespace BlendTreeNodeAsyncSerializerSettings { // "Models.HitBox.Serialization.Settings.BlendTreeNodeAsyncSerializerSettings (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Nodes = 0x0; // "AsyncItemsArrayAsyncSerializerSettings"
            inline constexpr std::uintptr_t FloatArray = 0x4; // "ArrayAsyncSerializerSettings"
            inline constexpr std::uintptr_t ReferenceArray = 0x10; // "ArrayAsyncSerializerSettings"
        }
    } // namespace BlendTreeNodeAsyncSerializerSettings

    namespace BlendTreeNodeExtensions { // "Models.HitBox.Extensions.BlendTreeNodeExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t LerpBonesDataWithoutNormalization = 0x4A72690; // "public static void LerpBonesDataWithoutNormalization(ReadOnlySpan<int> quaternionIndices, ReadOnlySpan<int> scalarIndices, int bonesDataSize, int boneDataSize, ReadOnlySpan<float> leftBonesData, ReadOnlySpan<float> rightBonesData, float leftWeight, float rightWeight, Span<float> resultBonesData)"
            inline constexpr std::uintptr_t NormalizeBonesDataQuaternions = 0x4A72A70; // "public static void NormalizeBonesDataQuaternions(in Span<float> bonesData, int boneDataSize, int bonesDataSize, ReadOnlySpan<int> quaternionIndices)"
        }
    } // namespace BlendTreeNodeExtensions

    namespace BlindedEffectDescription { // "Models.References.Grenade.BlindedEffect.BlindedEffectDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x8261320; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace Fields {
            inline constexpr std::uintptr_t Radius = 0x20; // "float"
        }
        namespace StaticFields {
            inline constexpr std::uintptr_t enum_id = 0x0; // "Enum<BlindedEffectDescription>"
            inline constexpr std::uintptr_t Blind0 = 0x8; // "BlindedEffectDescription"
            inline constexpr std::uintptr_t Blind1 = 0x10; // "BlindedEffectDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Enum = 0x4403A60; // "public static ReadOnlyEnum<BlindedEffectDescription> get_Enum()"
            inline constexpr std::uintptr_t GetBlindedEffect = 0x4403690; // "public static BlindedEffectDescription GetBlindedEffect(float radius)"
        }
    } // namespace BlindedEffectDescription

    namespace BreakableEffectGrenadeUpdater { // "Game.Battle.Entities.BreakableEffect.Updaters.BreakableEffectGrenadeUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleEntitiesModel = 0x10; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t worldEntitiesModel = 0x18; // "WorldEntitiesModel"
            inline constexpr std::uintptr_t timeModel = 0x20; // "TimeModel"
            inline constexpr std::uintptr_t breakableEffectsViewModel = 0x28; // "BreakableEffectsViewModel"
            inline constexpr std::uintptr_t overlapResultsTmp = 0x30; // "List<ValueTuple<int, Vector3>>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xBBD550; // "public void Update()"
            inline constexpr std::uintptr_t GrenadeExplosion = 0xBBCF20; // "private void GrenadeExplosion(Vector3 position, float radius)"
        }
    } // namespace BreakableEffectGrenadeUpdater

    namespace BreakableEffectMeleeUpdater { // "Game.Battle.Entities.BreakableEffect.Updaters.BreakableEffectMeleeUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t charactersMeleeAttackModel = 0x10; // "CharactersMeleeAttackModel"
            inline constexpr std::uintptr_t timeModel = 0x18; // "TimeModel"
            inline constexpr std::uintptr_t breakableEffectsViewModel = 0x20; // "BreakableEffectsViewModel"
            inline constexpr std::uintptr_t raycastResults = 0x28; // "List<ValueTuple<int, RaycastHit>>"
            inline constexpr std::uintptr_t tickIndex = 0x30; // "long"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xBBE110; // "public void Update()"
            inline constexpr std::uintptr_t RaycastMelee = 0xBBD890; // "private void RaycastMelee(Vector3 origin, Vector3 direction)"
        }
    } // namespace BreakableEffectMeleeUpdater

    namespace BreakableEffectShotUpdater { // "Game.Battle.Entities.BreakableEffect.Updaters.BreakableEffectShotUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t breakableEffectsViewModel = 0x10; // "BreakableEffectsViewModel"
            inline constexpr std::uintptr_t charactersShotsModel = 0x18; // "CharactersShotsModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x20; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t timeModel = 0x28; // "TimeModel"
            inline constexpr std::uintptr_t charactersTickIndex = 0x30; // "long"
            inline constexpr std::uintptr_t targetTickIndex = 0x38; // "long"
            inline constexpr std::uintptr_t raycastResultsTmp = 0x40; // "List<ValueTuple<int, RaycastHit>>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xBBEED0; // "public void Update()"
            inline constexpr std::uintptr_t UpdatePlayerShots = 0xBBEC80; // "private void UpdatePlayerShots()"
            inline constexpr std::uintptr_t UpdateCharactersShots = 0xBBEB60; // "private void UpdateCharactersShots()"
            inline constexpr std::uintptr_t RaycastShot = 0xBBE3B0; // "private void RaycastShot(Vector3 startPos, Vector3 endPos)"
        }
    } // namespace BreakableEffectShotUpdater

    namespace BuyWeaponSkinMessage { // "Models.Messages.BuyWeaponSkinMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t weaponSkin = 0x20; // "IPrimitiveData<WeaponSkinDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_WeaponSkin = 0x49E9640; // "public WeaponSkinDescription get_WeaponSkin()"
            inline constexpr std::uintptr_t get_Type = 0x49E9610; // "public override string get_Type()"
        }
    } // namespace BuyWeaponSkinMessage

    namespace Cartesian2dBlendTreeNode { // "Models.HitBox.BlendTreeNode.Cartesian2dBlendTreeNode (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Nodes = 0x10; // "IBlendTreeNode[]"
            inline constexpr std::uintptr_t Points = 0x18; // "float[]"
            inline constexpr std::uintptr_t Arg0 = 0x20; // "int"
            inline constexpr std::uintptr_t Arg0MinValue = 0x24; // "float"
            inline constexpr std::uintptr_t Arg0MaxValue = 0x28; // "float"
            inline constexpr std::uintptr_t Arg1 = 0x2C; // "int"
            inline constexpr std::uintptr_t Arg1MinValue = 0x30; // "float"
            inline constexpr std::uintptr_t Arg1MaxValue = 0x34; // "float"
            inline constexpr std::uintptr_t OffsetsData = 0x38; // "float[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t CollectAnimationClips = 0x4A76370; // "public void CollectAnimationClips(ReadOnlySpan<float> args, float nodeWeight, List<ValueTuple<AnimationClip, float>> result)"
            inline constexpr std::uintptr_t CalculateWeightsForPoint = 0x4A76120; // "private void CalculateWeightsForPoint(float px, float py, Span<float> result)"
        }
    } // namespace Cartesian2dBlendTreeNode

    namespace Cartesian2dBlendTreeNodeExtensions { // "Models.HitBox.Extensions.Cartesian2dBlendTreeNodeExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t CalculateOffsetsData = 0x4A75F10; // "public static float[] CalculateOffsetsData(ReadOnlySpan<float> points)"
        }
    } // namespace Cartesian2dBlendTreeNodeExtensions

    namespace CharacterAimAnimationModelUpdater { // "Game.Battle.EntityModel.BattleCharacter.CharacterAimAnimationModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t aimingModel = 0x10; // "CharacterAimingModel"
            inline constexpr std::uintptr_t weaponModel = 0x18; // "IWeaponModel"
            inline constexpr std::uintptr_t aimTransition = 0x20; // "AimStateModel"
            inline constexpr std::uintptr_t aiming = 0x28; // "AimingModel"
            inline constexpr std::uintptr_t now = 0x30; // "INow"
            inline constexpr std::uintptr_t health = 0x38; // "HealthModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xCC0410; // "public void Update()"
        }
    } // namespace CharacterAimAnimationModelUpdater

    namespace CharacterAimArgsAnimationUpdater { // "Game.Battle.Entities.BattleCharacter.Rotation.CharacterAimArgsAnimationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t rotationModel = 0x10; // "CharacterRotationModel"
            inline constexpr std::uintptr_t aimingModel = 0x18; // "CharacterAimingModel"
            inline constexpr std::uintptr_t armed = 0x20; // "ArmedModel"
            inline constexpr std::uintptr_t battleStance = 0x28; // "BattleStanceModel"
            inline constexpr std::uintptr_t breakCollider = 0x30; // "BreakColliderModel"
            inline constexpr std::uintptr_t pitchAbsBorder = 0x38; // "float"
            inline constexpr std::uintptr_t yawAbsBorder = 0x3C; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xBD3B20; // "public void Update()"
            inline constexpr std::uintptr_t CalculateYaw = 0xBD3940; // "private void CalculateYaw()"
            inline constexpr std::uintptr_t CalculatePitch = 0xBD3830; // "private void CalculatePitch()"
            inline constexpr std::uintptr_t DiscardYaw = 0xBD3AA0; // "private void DiscardYaw()"
        }
    } // namespace CharacterAimArgsAnimationUpdater

    namespace CharacterAimBlendArgsUpdater { // "Game.Battle.Entities.BattleCharacter.Rotation.CharacterAimBlendArgsUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t blendArgs = 0x10; // "BlendArgs"
            inline constexpr std::uintptr_t rotationModel = 0x18; // "CharacterRotationModel"
            inline constexpr std::uintptr_t armed = 0x20; // "ArmedModel"
            inline constexpr std::uintptr_t battleStance = 0x28; // "BattleStanceModel"
            inline constexpr std::uintptr_t pitchAbsBorder = 0x30; // "float"
            inline constexpr std::uintptr_t yawAbsBorder = 0x34; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xBD4120; // "public void Update()"
            inline constexpr std::uintptr_t CalculateYaw = 0xBD3E90; // "private void CalculateYaw()"
            inline constexpr std::uintptr_t CalculatePitch = 0xBD3DF0; // "private void CalculatePitch()"
            inline constexpr std::uintptr_t DiscardYaw = 0xBD4090; // "private void DiscardYaw()"
            inline constexpr std::uintptr_t DiscardPitch = 0xBD4000; // "private void DiscardPitch()"
        }
    } // namespace CharacterAimBlendArgsUpdater

    namespace CharacterArrestAnimationUpdater { // "Game.Battle.Entities.BattleCharacter.Updaters.CharacterArrestAnimationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t animationView = 0x10; // "CharacterAnimationView"
            inline constexpr std::uintptr_t prolongedInteractionModel = 0x18; // "ProlongedInteractionModel"
            inline constexpr std::uintptr_t now = 0x20; // "INow"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xBC4BA0; // "public void Update()"
        }
    } // namespace CharacterArrestAnimationUpdater

    namespace CharacterFallIntoKnockoutAnimationUpdater { // "Game.Battle.Entities.BattleCharacter.Updaters.CharacterFallIntoKnockoutAnimationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t animationView = 0x10; // "CharacterAnimationView"
            inline constexpr std::uintptr_t knockout = 0x18; // "KnockoutModel"
            inline constexpr std::uintptr_t now = 0x20; // "INow"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xBC5B50; // "public void Update()"
        }
    } // namespace CharacterFallIntoKnockoutAnimationUpdater

    namespace CharacterFireModel { // "Game.Battle.Entities.BattleCharacter.Shoot.CharacterFireModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsFiring = 0x10; // "bool"
            inline constexpr std::uintptr_t HasShot = 0x11; // "bool"
            inline constexpr std::uintptr_t ShotIndex = 0x14; // "int"
            inline constexpr std::uintptr_t ShotTime = 0x18; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Reset = 0xBD46A0; // "public void Reset()"
        }
    } // namespace CharacterFireModel

    namespace CharacterGetUpAfterGetRevivedAnimationUpdater { // "Game.Battle.EntityModel.BattleCharacter.CharacterGetUpAfterGetRevivedAnimationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t stateModel = 0x10; // "IBattleCharacterStateModel"
            inline constexpr std::uintptr_t view = 0x18; // "CharacterAnimationView"
            inline constexpr std::uintptr_t knockoutModel = 0x20; // "KnockoutModel"
            inline constexpr std::uintptr_t now = 0x28; // "INow"
            inline constexpr std::uintptr_t progress = 0x30; // "Nullable<float>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xCC1A30; // "public void Update()"
        }
    } // namespace CharacterGetUpAfterGetRevivedAnimationUpdater

    namespace CharacterIdleWeaponAnimationUpdater { // "Game.Battle.Entities.BattleCharacter.Weapon.CharacterIdleWeaponAnimationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t idleAnimation = 0x18; // "AnimationIKView"
            inline constexpr std::uintptr_t selectedWeaponModel = 0x20; // "SelectedWeaponModel"
            inline constexpr std::uintptr_t armedModel = 0x28; // "ArmedModel"
            inline constexpr std::uintptr_t selectedItem = 0x30; // "SelectedItemModel"
            inline constexpr std::uintptr_t reloading = 0x38; // "CharacterReloadingModel"
            inline constexpr std::uintptr_t meleeAttack = 0x40; // "MeleeAttackModel"
            inline constexpr std::uintptr_t breakCollider = 0x48; // "BreakColliderModel"
            inline constexpr std::uintptr_t inVehicleModel = 0x50; // "InVehicleModel"
            inline constexpr std::uintptr_t emotionModel = 0x58; // "EmotionModel"
            inline constexpr std::uintptr_t animStateAssistant = 0x60; // "AnimationStateAssistant"
        }
        namespace Methods {
            inline constexpr std::uintptr_t InnerUpdate = 0xBC6250; // "protected override void InnerUpdate()"
            inline constexpr std::uintptr_t ValidateTakingState = 0xBC6540; // "private bool ValidateTakingState()"
            inline constexpr std::uintptr_t ValidateReloadingState = 0xBC64F0; // "private bool ValidateReloadingState()"
            inline constexpr std::uintptr_t ValidateMeleeAttack = 0xBC64A0; // "private bool ValidateMeleeAttack()"
            inline constexpr std::uintptr_t InnerStart = 0x7B3360; // "protected override void InnerStart()"
            inline constexpr std::uintptr_t InnerStop = 0x7B3360; // "protected override void InnerStop()"
        }
    } // namespace CharacterIdleWeaponAnimationUpdater

    namespace CharacterKnockdownAnimationUpdater { // "Game.Battle.Entities.BattleCharacter.Updaters.CharacterKnockdownAnimationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t view = 0x10; // "CharacterAnimationView"
            inline constexpr std::uintptr_t knockdownModel = 0x18; // "KnockdownModel"
            inline constexpr std::uintptr_t stateModel = 0x20; // "IBattleCharacterStateModel"
            inline constexpr std::uintptr_t now = 0x28; // "INow"
            inline constexpr std::uintptr_t isKnocked = 0x30; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xBC67C0; // "public void Update()"
        }
    } // namespace CharacterKnockdownAnimationUpdater

    namespace CharacterKnockoutAnimationUpdater { // "Game.Battle.EntityModel.BattleCharacter.CharacterKnockoutAnimationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t animationView = 0x10; // "CharacterAnimationView"
            inline constexpr std::uintptr_t state = 0x18; // "IBattleCharacterStateModel"
            inline constexpr std::uintptr_t knockoutModel = 0x20; // "KnockoutModel"
            inline constexpr std::uintptr_t transformModel = 0x28; // "ITransformModel"
            inline constexpr std::uintptr_t arrestTargetModel = 0x30; // "ArrestTargetModel"
            inline constexpr std::uintptr_t isInKnockout = 0x38; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xCC25A0; // "public void Update()"
        }
    } // namespace CharacterKnockoutAnimationUpdater

    namespace CharacterKnockoutOrDeathExtensions { // "Models.Utils.Extensions.CharacterKnockoutOrDeathExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t GetRobberState = 0x39403F0; // "public static CharacterKnockoutOrDeathRobberStateDescription GetRobberState(long now, SurrenderModel targetSurrenderModel, ArrestTargetModel targetArrestModel, KnockoutModel targetKnockoutModel)"
            inline constexpr std::uintptr_t Revive = 0x3940630; // "public static void Revive(BattleCharacterModel characterModel, long now)"
        }
    } // namespace CharacterKnockoutOrDeathExtensions

    namespace CharacterKnockoutOrDeathRobberStateDescription { // "Models.References.CharacterKnockoutOrDeathRobberStateDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x81BE048; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t Idle = 0x0; // "CharacterKnockoutOrDeathRobberStateDescription"
            inline constexpr std::uintptr_t IsSurrendered = 0x8; // "CharacterKnockoutOrDeathRobberStateDescription"
            inline constexpr std::uintptr_t IsHandcuffing = 0x10; // "CharacterKnockoutOrDeathRobberStateDescription"
            inline constexpr std::uintptr_t IsHandcuffed = 0x18; // "CharacterKnockoutOrDeathRobberStateDescription"
        }
    } // namespace CharacterKnockoutOrDeathRobberStateDescription

    namespace CharacterMeleeAttackAnimationUpdater { // "Game.Battle.Entities.BattleCharacter.MeleeAttack.CharacterMeleeAttackAnimationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t view = 0x18; // "CharacterAnimationView"
            inline constexpr std::uintptr_t meleeAttack = 0x20; // "CharacterMeleeAttackProgressModel"
            inline constexpr std::uintptr_t battleStance = 0x28; // "BattleStanceModel"
            inline constexpr std::uintptr_t inBoxingStance = 0x30; // "bool"
            inline constexpr std::uintptr_t isActive = 0x31; // "bool"
            inline constexpr std::uintptr_t boxingValue = 0x34; // "float"
            inline constexpr std::uintptr_t targetBoxingValue = 0x38; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t InnerUpdate = 0xBD4710; // "protected override void InnerUpdate()"
            inline constexpr std::uintptr_t InnerStart = 0x7B3360; // "protected override void InnerStart()"
            inline constexpr std::uintptr_t InnerStop = 0xBD46C0; // "protected override void InnerStop()"
            inline constexpr std::uintptr_t UpdateBoxingStance = 0xBD47E0; // "private void UpdateBoxingStance()"
            inline constexpr std::uintptr_t UpdateMeleeAttack = 0xBD4A00; // "private void UpdateMeleeAttack()"
        }
    } // namespace CharacterMeleeAttackAnimationUpdater

    namespace CharacterMeleeAttackProgressModel { // "Game.Battle.Entities.BattleCharacter.MeleeAttack.CharacterMeleeAttackProgressModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Progress = 0x10; // "float"
            inline constexpr std::uintptr_t IsActive = 0x14; // "bool"
            inline constexpr std::uintptr_t Type = 0x18; // "int"
            inline constexpr std::uintptr_t IsBreakCollider = 0x1C; // "bool"
        }
    } // namespace CharacterMeleeAttackProgressModel

    namespace CharacterMeleeAttackProgressModelUpdater { // "Game.Battle.Entities.BattleCharacter.MeleeAttack.CharacterMeleeAttackProgressModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t clientMeleeAttack = 0x10; // "CharacterMeleeAttackProgressModel"
            inline constexpr std::uintptr_t breakCollider = 0x18; // "BreakColliderModel"
            inline constexpr std::uintptr_t meleeAttack = 0x20; // "MeleeAttackModel"
            inline constexpr std::uintptr_t now = 0x28; // "INow"
            inline constexpr std::uintptr_t attacksSequence = 0x30; // "int[]"
            inline constexpr std::uintptr_t attackIndex = 0x38; // "int"
            inline constexpr std::uintptr_t isActive = 0x3C; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xBD4D70; // "public void Update()"
        }
    } // namespace CharacterMeleeAttackProgressModelUpdater

    namespace CharacterReceiveDamageFromPlayerModel { // "Game.Battle.Entities.BattleCharacter.Shoot.CharacterReceiveDamageFromPlayerModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t DamageReceiveTickIndex = 0x10; // "long"
        }
    } // namespace CharacterReceiveDamageFromPlayerModel

    namespace CharacterRevivalAnimationUpdater { // "Game.Battle.Entities.BattleCharacter.Updaters.CharacterRevivalAnimationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t animationView = 0x10; // "CharacterAnimationView"
            inline constexpr std::uintptr_t prolongedInteractionModel = 0x18; // "ProlongedInteractionModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xBC80F0; // "public void Update()"
        }
    } // namespace CharacterRevivalAnimationUpdater

    namespace CharacterSelectedWeaponInfoAnimationUpdater { // "Game.Battle.Entities.BattleCharacter.Equipment.CharacterSelectedWeaponInfoAnimationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t selectedItem = 0x10; // "SelectedItemModel"
            inline constexpr std::uintptr_t animationView = 0x18; // "CharacterAnimationView"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xBEC0A0; // "public void Update()"
        }
    } // namespace CharacterSelectedWeaponInfoAnimationUpdater

    namespace CharacterShotAnimationUpdater { // "Game.Battle.Entities.BattleCharacter.Shoot.CharacterShotAnimationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t fireModel = 0x18; // "CharacterFireModel"
            inline constexpr std::uintptr_t weaponAnimationView = 0x20; // "CharacterWithWeaponAnimationView"
            inline constexpr std::uintptr_t selectedWeaponModel = 0x28; // "SelectedWeaponModel"
            inline constexpr std::uintptr_t nextShotCooldown = 0x30; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t InnerUpdate = 0xBDA950; // "protected override void InnerUpdate()"
            inline constexpr std::uintptr_t UpdateBursting = 0xBDAAC0; // "private void UpdateBursting()"
            inline constexpr std::uintptr_t UpdateSingle = 0xBDAD60; // "private void UpdateSingle()"
            inline constexpr std::uintptr_t InnerStart = 0x7B3360; // "protected override void InnerStart()"
            inline constexpr std::uintptr_t InnerStop = 0x7B3360; // "protected override void InnerStop()"
        }
    } // namespace CharacterShotAnimationUpdater

    namespace CharactersMeleeAttackModelUpdater { // "Game.Battle.Entities.BattleCharacter.MeleeAttack.CharactersMeleeAttackModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t charactersMeleeAttackModel = 0x10; // "CharactersMeleeAttackModel"
            inline constexpr std::uintptr_t battleCharacterModel = 0x18; // "BattleCharacterModel"
            inline constexpr std::uintptr_t meleeAttackModel = 0x20; // "MeleeAttackModel"
            inline constexpr std::uintptr_t timeModel = 0x28; // "TimeModel"
            inline constexpr std::uintptr_t now = 0x30; // "ISetNow"
            inline constexpr std::uintptr_t tickIndex = 0x38; // "long"
            inline constexpr std::uintptr_t isHandled = 0x40; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xBED0E0; // "public void Update()"
        }
    } // namespace CharactersMeleeAttackModelUpdater

    namespace CharacterSurrenderAnimationUpdater { // "Game.Battle.EntityModel.BattleCharacter.CharacterSurrenderAnimationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t surrenderStateModel = 0x10; // "SurrenderStateModel"
            inline constexpr std::uintptr_t animationView = 0x18; // "CharacterAnimationView"
            inline constexpr std::uintptr_t knockdownModel = 0x20; // "KnockdownModel"
            inline constexpr std::uintptr_t isSurrender = 0x28; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xCD18E0; // "public void Update()"
        }
    } // namespace CharacterSurrenderAnimationUpdater

    namespace CharactersWeaponReloadingAnimationUpdater { // "Game.Battle.Entities.BattleCharacter.Weapon.CharactersWeaponReloadingAnimationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t animationStateAssistant = 0x18; // "AnimationStateAssistant"
            inline constexpr std::uintptr_t selectedWeaponModel = 0x20; // "SelectedWeaponModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t InnerUpdate = 0xBCB1E0; // "protected override void InnerUpdate()"
            inline constexpr std::uintptr_t InnerStart = 0x7B3360; // "protected override void InnerStart()"
            inline constexpr std::uintptr_t InnerStop = 0x7B3360; // "protected override void InnerStop()"
        }
    } // namespace CharactersWeaponReloadingAnimationUpdater

    namespace CharacterWeaponIKUpdater { // "Game.Battle.Entities.BattleCharacter.Weapon.CharacterWeaponIKUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t selectedWeaponModel = 0x18; // "SelectedWeaponModel"
            inline constexpr std::uintptr_t rightHandIK = 0x20; // "LimbIKView"
            inline constexpr std::uintptr_t leftHandIK = 0x28; // "LimbIKView"
            inline constexpr std::uintptr_t armedPose = 0x30; // "PoseIKView"
            inline constexpr std::uintptr_t leftElbowPose = 0x38; // "PoseIKView"
            inline constexpr std::uintptr_t leftWristPose = 0x40; // "PoseIKView"
            inline constexpr std::uintptr_t magazineView = 0x48; // "IWeightedImpact"
        }
        namespace Methods {
            inline constexpr std::uintptr_t InnerUpdate = 0xBCB090; // "protected override void InnerUpdate()"
            inline constexpr std::uintptr_t InnerStart = 0x7B3360; // "protected override void InnerStart()"
            inline constexpr std::uintptr_t InnerStop = 0xBCAFF0; // "protected override void InnerStop()"
        }
    } // namespace CharacterWeaponIKUpdater

    namespace CheatKnockdownMessage { // "Models.Messages.CheatKnockdownMessage (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x49F3C60; // "public override string get_Type()"
        }
    } // namespace CheatKnockdownMessage

    namespace CheatReduceIncomeDamageToOneMessage { // "Models.Messages.CheatReduceIncomeDamageToOneMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t value = 0x20; // "IPrimitiveData<bool>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Value = 0x49F4090; // "public bool get_Value()"
            inline constexpr std::uintptr_t get_Type = 0x49F4060; // "public override string get_Type()"
        }
    } // namespace CheatReduceIncomeDamageToOneMessage

    namespace CheatSelfDamageMessage { // "Models.Messages.CheatSelfDamageMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t damage = 0x20; // "IPrimitiveData<int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Damage = 0x49F4FE0; // "public int get_Damage()"
            inline constexpr std::uintptr_t get_Type = 0x49F5030; // "public override string get_Type()"
        }
    } // namespace CheatSelfDamageMessage

    namespace CheatSetWeaponSkinMessage { // "Models.Messages.CheatSetWeaponSkinMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t weaponSkin = 0x20; // "IPrimitiveData<WeaponSkinDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_WeaponSkin = 0x49FDDB0; // "public WeaponSkinDescription get_WeaponSkin()"
            inline constexpr std::uintptr_t get_Type = 0x49FDD80; // "public override string get_Type()"
        }
    } // namespace CheatSetWeaponSkinMessage

    namespace CheatShotDebugInfoMessage { // "Models.Messages.CheatShotDebugInfoMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t enable = 0x20; // "IPrimitiveData<bool>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Enable = 0x49FDF90; // "public bool get_Enable()"
            inline constexpr std::uintptr_t get_Type = 0x49FDFE0; // "public override string get_Type()"
        }
    } // namespace CheatShotDebugInfoMessage

    namespace ClearAfterKnockoutDelaySystem { // "Models.Systems.ClearAfterKnockoutDelaySystem (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x40F3E50; // "protected override void Tick(ITick tick)"
        }
    } // namespace ClearAfterKnockoutDelaySystem

    namespace ClearShotInputUpdater { // "Game.Battle.Inputs.ClearShotInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t shotInput = 0x10; // "InputModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA73470; // "public void Update()"
        }
    } // namespace ClearShotInputUpdater

    namespace ClearTimelineReviveUpdater { // "Game.Battle.EntityModel.BattleCharacter.Movement.ClearTimelineReviveUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t movementTimeline = 0x10; // "MovementTimeline"
            inline constexpr std::uintptr_t lookRotationTimeline = 0x18; // "RotationTimeline"
            inline constexpr std::uintptr_t rotationTimeline = 0x20; // "RotationTimeline"
            inline constexpr std::uintptr_t stateModel = 0x28; // "IBattleCharacterStateModel"
            inline constexpr std::uintptr_t oldState = 0x30; // "BattleCharacterState"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xCD4030; // "public void Update()"
        }
    } // namespace ClearTimelineReviveUpdater

    namespace ClientGrenadeTriggerModel { // "Game.Battle.Entities.Grenade.Models.ClientGrenadeTriggerModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t HasLastState = 0x10; // "bool"
            inline constexpr std::uintptr_t LastTriggeredState = 0x11; // "bool"
            inline constexpr std::uintptr_t IsTriggered = 0x12; // "bool"
            inline constexpr std::uintptr_t TriggerTs = 0x18; // "long"
        }
    } // namespace ClientGrenadeTriggerModel

    namespace ClientNotification_KillLog { // "Models.ClientNotification.ClientNotification.KillLog (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t TargetPublicId = 0x10; // "long"
            inline constexpr std::uintptr_t TargetIsDangerous = 0x18; // "bool"
            inline constexpr std::uintptr_t TargetName = 0x20; // "string"
            inline constexpr std::uintptr_t TargetClanTag = 0x28; // "string"
            inline constexpr std::uintptr_t TargetRole = 0x30; // "PlayerRoleDescription"
            inline constexpr std::uintptr_t ActorPublicId = 0x38; // "long"
            inline constexpr std::uintptr_t ActorIsDangerous = 0x40; // "bool"
            inline constexpr std::uintptr_t ActorName = 0x48; // "string"
            inline constexpr std::uintptr_t ActorClanTag = 0x50; // "string"
            inline constexpr std::uintptr_t ActorRole = 0x58; // "PlayerRoleDescription"
            inline constexpr std::uintptr_t Reason = 0x60; // "KillLogReasonDescription"
            inline constexpr std::uintptr_t Weapon = 0x68; // "WeaponDescription"
            inline constexpr std::uintptr_t Grenade = 0x70; // "GrenadeDescription"
        }
    } // namespace ClientNotification_KillLog

    namespace DamageArmorModel { // "Game.Battle.EntityModel.Player.DamageArmorModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t CharacterDamageTick = 0x10; // "Dictionary<int, long>"
        }
    } // namespace DamageArmorModel

    namespace DamageArmorModelUpdater { // "Game.Battle.EntityModel.Player.DamageArmorModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t damageModel = 0x10; // "DamageModel"
            inline constexpr std::uintptr_t damageArmorModel = 0x18; // "DamageArmorModel"
            inline constexpr std::uintptr_t time = 0x20; // "TimeModel"
            inline constexpr std::uintptr_t armorTickTime = 0x28; // "int"
            inline constexpr std::uintptr_t now = 0x30; // "INow"
            inline constexpr std::uintptr_t removeList = 0x38; // "List<int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC37030; // "public void Update()"
        }
    } // namespace DamageArmorModelUpdater

    namespace DamageData { // "Models.Data.DamageData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t DamageTickIndex = 0x20; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t Hits = 0x28; // "DictionaryData<int, HitData>"
        }
    } // namespace DamageData

    namespace DamageImmuneModel { // "Models.Models.DamageImmune.DamageImmuneModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t immuneEndTs = 0x10; // "Dictionary<DamageTypeDescription, long>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t IsImmuneTo = 0x49578C0; // "public bool IsImmuneTo(DamageTypeDescription damageType, long now)"
            inline constexpr std::uintptr_t SetImmune = 0x4957950; // "public void SetImmune(DamageTypeDescription damageType, long immuneEndTs)"
        }
    } // namespace DamageImmuneModel

    namespace DamageModel { // "Models.Models.Damage.DamageModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "DamageData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Get = 0x4957B10; // "public void Get(int characterId, out int damage, out bool isHead, out bool isArmor, out bool isGrenade)"
            inline constexpr std::uintptr_t Set = 0x4957F10; // "public void Set(long damageTickIndex)"
            inline constexpr std::uintptr_t SetHit = 0x4957C60; // "public void SetHit(int battleCharacterId, int damage, bool isHead, bool isArmor)"
            inline constexpr std::uintptr_t SetGrenadeHit = 0x4957C30; // "public void SetGrenadeHit(int battleCharacterId, bool isArmor)"
            inline constexpr std::uintptr_t SetHit_2 = 0x4957C90; // "private void SetHit(int battleCharacterId, int damage, bool isHead, bool isArmor, bool isGrenade)"
            inline constexpr std::uintptr_t ClearBeforeTickIndex = 0x4957A80; // "public void ClearBeforeTickIndex(long tickIndex)"
            inline constexpr std::uintptr_t get_DamageTickIndex = 0x4957F70; // "public long get_DamageTickIndex()"
            inline constexpr std::uintptr_t get_Keys = 0x4957FC0; // "public Dictionary.KeyCollection<int, HitData> get_Keys()"
        }
    } // namespace DamageModel

    namespace DamageTypeDescription { // "Models.References.Damage.DamageTypeDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x823ABE0; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t enum_id = 0x0; // "Enum<DamageTypeDescription>"
            inline constexpr std::uintptr_t Gas = 0x8; // "DamageTypeDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Enum = 0x442B400; // "public static ReadOnlyEnum<DamageTypeDescription> get_Enum()"
        }
    } // namespace DamageTypeDescription

    namespace DamageZoneDescription { // "Models.References.DamageZone.DamageZoneDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Colliders = 0x10; // "CollidersDescription"
            inline constexpr std::uintptr_t EffectFunc = 0x18; // "Func<DamageZoneEffectDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Effect = 0x26CF2F0; // "public DamageZoneEffectDescription get_Effect()"
            inline constexpr std::uintptr_t New = 0x442B5E0; // "public static DamageZoneDescription New(CollidersDescription colliders, DamageZoneEffectDescription effect)"
        }
    } // namespace DamageZoneDescription

    namespace DamageZoneDestroyModel { // "Models.Models.DamageZoneDestroy.DamageZoneDestroyModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "DamageZoneModel"
            inline constexpr std::uintptr_t descriptionModel = 0x18; // "DescriptionModel<DamageZoneDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t DestroyStatic = 0x4958320; // "public void DestroyStatic(PhysicsSceneModel physicsSceneModel, PhysicsBodiesModel physicsBodiesModel)"
            inline constexpr std::uintptr_t DestroyKinematic = 0x4958010; // "public void DestroyKinematic(PhysicsSceneModel physicsSceneModel, PhysicsBodiesModel physicsBodiesModel)"
            inline constexpr std::uintptr_t DestroyPhysicsBodies = 0x4958290; // "private void DestroyPhysicsBodies(PhysicsBodiesModel physicsBodiesModel)"
        }
    } // namespace DamageZoneDestroyModel

    namespace DamageZoneEffectDescription { // "Models.References.DamageZone.DamageZoneEffectDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Damage = 0x20; // "int"
            inline constexpr std::uintptr_t DamagePeriod = 0x28; // "long"
            inline constexpr std::uintptr_t VelocityModifier = 0x30; // "float"
            inline constexpr std::uintptr_t IsBlockSprint = 0x34; // "bool"
            inline constexpr std::uintptr_t IsBlockJump = 0x35; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_HasDamage = 0xA28E10; // "public bool get_HasDamage()"
            inline constexpr std::uintptr_t get_HasVelocityModifier = 0x442BC00; // "public bool get_HasVelocityModifier()"
        }
    } // namespace DamageZoneEffectDescription

    namespace DamageZoneInitializeModel { // "Models.Models.DamageZoneInitialize.DamageZoneInitializeModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "DamageZoneModel"
            inline constexpr std::uintptr_t descriptionModel = 0x18; // "DescriptionModel<DamageZoneDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t InitializeStatic = 0x4958850; // "public void InitializeStatic(PhysicsSceneModel physicsSceneModel, PhysicsBodiesModel physicsBodiesModel, DamageZoneDescription description, in Vector3 parentPosition, in Quaternion parentOrientation)"
            inline constexpr std::uintptr_t InitializeKinematic = 0x49585A0; // "public void InitializeKinematic(PhysicsSceneModel physicsSceneModel, PhysicsBodiesModel physicsBodiesModel, DamageZoneDescription description, in Vector3 parentPosition, in Quaternion parentOrientation)"
            inline constexpr std::uintptr_t InitializePhysicsBodies = 0x4958750; // "private void InitializePhysicsBodies(PhysicsSceneModel physicsSceneModel, PhysicsBodiesModel physicsBodiesModel, CollidersIdData collidersIdData)"
        }
    } // namespace DamageZoneInitializeModel

    namespace DamageZoneModel { // "Models.Models.DamageZone.DamageZoneModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t descriptionModel = 0x10; // "DescriptionModel<DamageZoneDescription>"
            inline constexpr std::uintptr_t CollidersIdData = 0x18; // "CollidersIdData"
            inline constexpr std::uintptr_t Initialize = 0x20; // "DamageZoneInitializeModel"
            inline constexpr std::uintptr_t Destroy = 0x28; // "DamageZoneDestroyModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsInitialized = 0x4958BB0; // "public bool get_IsInitialized()"
            inline constexpr std::uintptr_t get_Description = 0x4958B70; // "public DamageZoneDescription get_Description()"
        }
    } // namespace DamageZoneModel

    namespace DealDamageRules { // "Models.Models.DealDamageRules.DealDamageRules (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t WeaponDamage = 0x49592F0; // "public static void WeaponDamage(long now, int damage, ArmorModel armorModel, HealthModel healthModel, KnockoutModel knockoutModel, RestoreHealthModel restoreHealthModel, PlayerRoleDescription roleDescription, ArrestTargetModel arrestTargetModel, IPrimitiveModel<CharacterControllerStateDescription> characterControllerState, out int armorDamage, out int healthDamage)"
            inline constexpr std::uintptr_t NonLethalDamage = 0x4958E80; // "public static void NonLethalDamage(long now, int damage, HealthModel healthModel, RestoreHealthModel restoreHealthModel, PlayerRoleDescription roleDescription, out int healthDamage)"
            inline constexpr std::uintptr_t PureDamage = 0x4958FF0; // "public static void PureDamage(long now, int damage, HealthModel healthModel, KnockoutModel knockoutModel, RestoreHealthModel restoreHealthModel, PlayerRoleDescription roleDescription, ArrestTargetModel arrestTargetModel, IPrimitiveModel<CharacterControllerStateDescription> characterControllerState, out int healthDamage)"
        }
    } // namespace DealDamageRules

    namespace DebugAimStateUpdater { // "Game.Battle.EntityModel.Player.Debug.DebugAimStateUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "BattleCharacterModel"
            inline constexpr std::uintptr_t time = 0x18; // "TimeModel"
            inline constexpr std::uintptr_t previousProgress = 0x20; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC6AA70; // "public void Update()"
        }
    } // namespace DebugAimStateUpdater

    namespace DebugShotPositionUpdater { // "Game.Battle.DebugShotPositionUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t view = 0x10; // "DebugShotPositionView"
            inline constexpr std::uintptr_t weapon = 0x18; // "IWeaponModel"
            inline constexpr std::uintptr_t rotationInputModel = 0x20; // "PlayerRotationInputModel"
            inline constexpr std::uintptr_t movementModel = 0x28; // "SetMovementModel"
            inline constexpr std::uintptr_t crouchModel = 0x30; // "CharacterCrouchModel"
            inline constexpr std::uintptr_t healthModel = 0x38; // "HealthModel"
            inline constexpr std::uintptr_t aimModeModel = 0x40; // "IPrimitiveModel<AimModeDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA550B0; // "public void Update()"
        }
    } // namespace DebugShotPositionUpdater

    namespace DebugShotsData { // "Game.Battle.EntityModel.Player.Debug.DebugShotsData (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Shots = 0x10; // "Dictionary<long, ShotDebugInfoPair>"
            inline constexpr std::uintptr_t Ticks = 0x18; // "SortedSet<long>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Clear = 0xC86CF0; // "public void Clear()"
        }
    } // namespace DebugShotsData

    namespace DebugShotsUpdater { // "Game.Battle.EntityModel.Player.Debug.DebugShotsUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleEntitiesModel = 0x10; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t incomingDebugShots = 0x18; // "IIncomingDebugShotsModel"
            inline constexpr std::uintptr_t roomConnection = 0x20; // "IRoomConnection"
            inline constexpr std::uintptr_t debugShotsData = 0x28; // "DebugShotsData"
            inline constexpr std::uintptr_t view = 0x30; // "DebugShotsView"
            inline constexpr std::uintptr_t previousIsEnabled = 0x38; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC87840; // "public void Update()"
            inline constexpr std::uintptr_t AddNewClientShot = 0xC86E20; // "private void AddNewClientShot(BattleCharacterModel model)"
            inline constexpr std::uintptr_t ReceiveServerDebugShots = 0xC87470; // "private void ReceiveServerDebugShots()"
            inline constexpr std::uintptr_t GetGameObjects = 0xC871B0; // "private GameObject[] GetGameObjects()"
            inline constexpr std::uintptr_t RecursiveClean = 0xC876D0; // "private void RecursiveClean(GameObject gameObject)"
            inline constexpr std::uintptr_t DisableAllComponentsExceptTransform = 0xC86FB0; // "private void DisableAllComponentsExceptTransform(GameObject gameObject)"
            inline constexpr std::uintptr_t SendEnable = 0xC87780; // "private void SendEnable(bool isEnabled)"
            inline constexpr std::uintptr_t OnDrawGizmos = 0xC87430; // "private void OnDrawGizmos()"
        }
    } // namespace DebugShotsUpdater

    namespace DefaultSkeletonAnimationMask { // "Models.HitBox.SkeletonAnimationMask.DefaultSkeletonAnimationMask (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t blendTree = 0x10; // "BlendTreeDescription"
            inline constexpr std::uintptr_t mask = 0x18; // "byte"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Calculate = 0xCEED10; // "public void Calculate(out BlendTreeDescription blendTree, out byte mask)"
        }
    } // namespace DefaultSkeletonAnimationMask

    namespace DefaultSkeletonAnimationState { // "Models.HitBox.SkeletonAnimationState.DefaultSkeletonAnimationState (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t blendTree = 0x10; // "BlendTreeDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Calculate = 0x4A45910; // "public void Calculate(SkeletonAnimationModel skeletonAnimationModel, out BlendTreeDescription blendTree)"
        }
    } // namespace DefaultSkeletonAnimationState

    namespace EmotionAimInputUpdater { // "Game.Battle.Emotion.InputHandlers.EmotionAimInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t lookAction = 0x10; // "InputAction"
            inline constexpr std::uintptr_t aimModel = 0x18; // "EmotionAimModel"
            inline constexpr std::uintptr_t maxDistance = 0x20; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xCEB060; // "public void Update()"
        }
    } // namespace EmotionAimInputUpdater

    namespace EmotionAimModel { // "Game.Battle.Emotion.Models.EmotionAimModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Position = 0x10; // "Vector2"
        }
    } // namespace EmotionAimModel

    namespace EmotionAimSectorUpdater { // "Game.Battle.Emotion.InputHandlers.EmotionAimSectorUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t aimModel = 0x10; // "EmotionAimModel"
            inline constexpr std::uintptr_t sectorInputModel = 0x18; // "SectorInputModel"
            inline constexpr std::uintptr_t isFirstItemInCenter = 0x20; // "bool"
            inline constexpr std::uintptr_t isClockwise = 0x21; // "bool"
            inline constexpr std::uintptr_t sectorAngle = 0x24; // "float"
            inline constexpr std::uintptr_t deadZoneDistanceSqr = 0x28; // "float"
            inline constexpr std::uintptr_t sectorAmount = 0x2C; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xCEB1B0; // "public void Update()"
        }
    } // namespace EmotionAimSectorUpdater

    namespace EmotionCastSkeletonAnimationState { // "Models.HitBox.SkeletonAnimationState.EmotionCastSkeletonAnimationState (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t blendTree = 0x10; // "BlendTreeDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Calculate = 0x4A45920; // "public void Calculate(SkeletonAnimationModel skeletonAnimationModel, out BlendTreeDescription blendTree)"
        }
    } // namespace EmotionCastSkeletonAnimationState

    namespace EmotionPreCastSkeletonAnimationState { // "Models.HitBox.SkeletonAnimationState.EmotionPreCastSkeletonAnimationState (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t blendTree = 0x10; // "BlendTreeDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Calculate = 0x4A45AA0; // "public void Calculate(SkeletonAnimationModel skeletonAnimationModel, out BlendTreeDescription blendTree)"
        }
    } // namespace EmotionPreCastSkeletonAnimationState

    namespace EmptySkeletonAnimationMask { // "Models.HitBox.SkeletonAnimationMask.EmptySkeletonAnimationMask (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t Calculate = 0x4A45C20; // "public void Calculate(out BlendTreeDescription blendTree, out byte mask)"
        }
    } // namespace EmptySkeletonAnimationMask

    namespace FallDamageConfig { // "Models.References.Character.FallDamage.FallDamageConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t StartTrackVelocity = 0x10; // "float"
            inline constexpr std::uintptr_t DamageMinDistance = 0x14; // "float"
            inline constexpr std::uintptr_t DamageMaxDistance = 0x18; // "float"
            inline constexpr std::uintptr_t MinDamage = 0x1C; // "int"
            inline constexpr std::uintptr_t MaxDamage = 0x20; // "int"
        }
    } // namespace FallDamageConfig

    namespace FallDamageTrackModel { // "Models.Models.FallDamageTrack.FallDamageTrackModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t fallDamageTrackActive = 0x10; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t fallDamageTrackStartPositionY = 0x18; // "IPrimitiveData<float>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsActive = 0x4961E20; // "public bool get_IsActive()"
            inline constexpr std::uintptr_t get_StartPositionY = 0x4961E70; // "public float get_StartPositionY()"
            inline constexpr std::uintptr_t Start = 0x4961D30; // "public void Start(float positionY)"
            inline constexpr std::uintptr_t Stop = 0x4961DB0; // "public void Stop()"
        }
    } // namespace FallDamageTrackModel

    namespace FallDamageTrackRequestDescription { // "Models.References.Character.FallDamage.FallDamageTrackRequestDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x81956B0; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t StartTrack = 0x0; // "FallDamageTrackRequestDescription"
            inline constexpr std::uintptr_t StopTrack = 0x8; // "FallDamageTrackRequestDescription"
        }
    } // namespace FallDamageTrackRequestDescription

    namespace FallDamageTrackSystem { // "Models.Systems.FallDamageTrackSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsDebugEnabledModel = 0x38; // "PhysicsDebugEnabledModel"
            inline constexpr std::uintptr_t physicsDebugModel = 0x40; // "IPhysicsDebugModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x40F56C0; // "protected override void Tick(ITick tick)"
            inline constexpr std::uintptr_t StartTrack = 0x40F5580; // "private static void StartTrack(FallDamageTrackModel fallDamageTrack, ITransformModel transform)"
            inline constexpr std::uintptr_t StopTrack = 0x40F55F0; // "private static void StopTrack(FallDamageTrackModel fallDamageTrack, RequestModel<float> fallDamageRequest, ITransformModel transform, PhysicsDebugBattleCharacterTickData physicsDebug)"
            inline constexpr std::uintptr_t InterruptTrack = 0x40F5560; // "private static void InterruptTrack(FallDamageTrackModel fallDamageTrack)"
            inline constexpr std::uintptr_t WriteFallDamageTrackStateToDebug = 0x40F5A00; // "private static void WriteFallDamageTrackStateToDebug(PhysicsDebugBattleCharacterTickData physicsDebug, FallDamageTrackModel fallDamageTrack)"
            inline constexpr std::uintptr_t WriteFallDamageTrackStopDistance = 0x40F5A50; // "private static void WriteFallDamageTrackStopDistance(PhysicsDebugBattleCharacterTickData physicsDebug, float fallDamageTrackStopDistance)"
        }
    } // namespace FallDamageTrackSystem

    namespace FinishAimStateSystem { // "Models.Systems.FinishAimStateSystem (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x40F5AE0; // "protected override void Tick(ITick tick)"
        }
    } // namespace FinishAimStateSystem

    namespace FinishArrestGettingUpSystem { // "Models.Systems.FinishArrestGettingUpSystem (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x40F5D80; // "protected override void Tick(ITick tick)"
        }
    } // namespace FinishArrestGettingUpSystem

    namespace FinishArrestMessage { // "Models.Messages.FinishArrestMessage (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x4A07240; // "public override string get_Type()"
        }
    } // namespace FinishArrestMessage

    namespace FireModel { // "Models.Models.Fire.FireModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t isFiring = 0x10; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t shotEndTs = 0x18; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t ShotTimeOffset = 0x20; // "int"
            inline constexpr std::uintptr_t ShotSimulatedTimeOffset = 0x24; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsInProcess = 0x4961F60; // "public bool get_IsInProcess()"
            inline constexpr std::uintptr_t get_ShotEndTs = 0x4961FB0; // "public long get_ShotEndTs()"
            inline constexpr std::uintptr_t set_ShotEndTs = 0x4962000; // "public void set_ShotEndTs(long value)"
            inline constexpr std::uintptr_t Start = 0x4961EC0; // "public void Start()"
            inline constexpr std::uintptr_t Stop = 0x4961F10; // "public void Stop()"
        }
    } // namespace FireModel

    namespace FireSystem { // "Models.Systems.FireSystem (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x40F8990; // "protected override void Tick(ITick tick)"
            inline constexpr std::uintptr_t CheckShotCooldown = 0x40F8960; // "private bool CheckShotCooldown(FireModel fireModel, long now)"
        }
    } // namespace FireSystem

    namespace ForceArrestTargetModel { // "Models.Models.ProlongedInteractionHandler.Handlers.ForceArrestTargetModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleCharacters = 0x10; // "ReadOnly.Dictionary<int, BattleCharacterModel>"
            inline constexpr std::uintptr_t worldEntitiesModel = 0x18; // "WorldEntitiesModel"
            inline constexpr std::uintptr_t interactRaycastModel = 0x20; // "InteractRaycastModel"
            inline constexpr std::uintptr_t worldInterruptModel = 0x28; // "IWorldInterruptModel"
            inline constexpr std::uintptr_t crouchStandUpModel = 0x30; // "CrouchStandUpModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Process = 0x48D6400; // "public override MutuallyExclusiveProcessesDescription get_Process()"
            inline constexpr std::uintptr_t get_StartCommand = 0x48D6490; // "internal override UseEntityCommandDescription get_StartCommand()"
            inline constexpr std::uintptr_t get_StopCommand = 0x48D6520; // "internal override UseEntityCommandDescription get_StopCommand()"
            inline constexpr std::uintptr_t CheckInteractionStart = 0x48D5C80; // "public override bool CheckInteractionStart(UseEntityCommandDescription command, int useEntityId, PlayerRoleDescription playerRole)"
            inline constexpr std::uintptr_t HandelRequest = 0x48D5D40; // "public override void HandelRequest(long now, int entityId, ProlongedInteractionInputDescription prolongedInteractionInput, BattleCharacterModel characterModel)"
            inline constexpr std::uintptr_t CanBeForceArrested = 0x48D5BE0; // "private bool CanBeForceArrested(BattleCharacterModel targetEntity)"
            inline constexpr std::uintptr_t TryFinishPrediction = 0x48D6100; // "public override bool TryFinishPrediction(long now, BattleCharacterModel characterModel)"
            inline constexpr std::uintptr_t TryGetTargetPosition = 0x48D62A0; // "public override bool TryGetTargetPosition(int entityId, out Vector3 position)"
        }
    } // namespace ForceArrestTargetModel

    namespace ForceArrestTargetProlongedAction { // "Game.Battle.Entities.Player.ProlongedActions.ForceArrestTargetProlongedAction (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "ProlongedInteractionModel"
            inline constexpr std::uintptr_t entityId = 0x18; // "int"
            inline constexpr std::uintptr_t Label = 0x20; // "LocalizedString"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsActive = 0xB1D620; // "public bool get_IsActive()"
            inline constexpr std::uintptr_t get_EndTs = 0xB19D10; // "public long get_EndTs()"
            inline constexpr std::uintptr_t get_Duration = 0xB1D5D0; // "public long get_Duration()"
            inline constexpr std::uintptr_t Interrupt = 0xB1D510; // "public void Interrupt(BattleInputModel battleInputModel)"
            inline constexpr std::uintptr_t UpdateInterruptData = 0xB19E00; // "public void UpdateInterruptData()"
        }
    } // namespace ForceArrestTargetProlongedAction

    namespace ForceKnockoutEndMessage { // "Models.Messages.ForceKnockoutEndMessage (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t get_Type = 0x4A07650; // "public override string get_Type()"
        }
    } // namespace ForceKnockoutEndMessage

    namespace ForearmTwistSettings { // "Game.Battle.Equipment.Weapon.ForearmTwistSettings (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Override = 0x0; // "bool"
            inline constexpr std::uintptr_t Armed = 0x4; // "float"
            inline constexpr std::uintptr_t Aiming = 0x8; // "float"
            inline constexpr std::uintptr_t ArmedArmTwistAngle = 0xC; // "float"
            inline constexpr std::uintptr_t AimingArmTwistAngle = 0x10; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Resolve = 0xAB0890; // "public float Resolve(float aimingWeight)"
            inline constexpr std::uintptr_t ResolveArmTwistAngle = 0xAB0850; // "public float ResolveArmTwistAngle(float aimingWeight)"
        }
    } // namespace ForearmTwistSettings

    namespace FoundCopData { // "Models.Models.Arrest.FoundCopData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t EntityId = 0x0; // "int"
            inline constexpr std::uintptr_t HasCryBuff = 0x4; // "bool"
        }
    } // namespace FoundCopData

    namespace FriendlyKillKeys { // "Game.Battle.BattleScreenContentDirectory.Localization.FriendlyKillKeys (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Header = 0x10; // "LocalizedString"
            inline constexpr std::uintptr_t Description = 0x18; // "LocalizedString"
            inline constexpr std::uintptr_t Confirm = 0x20; // "LocalizedString"
        }
    } // namespace FriendlyKillKeys

    namespace GrenadeBlindEffectOnCharacterSystem { // "Models.Systems.GrenadeBlindEffectOnCharacterSystem (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x40F8BA0; // "protected override void Tick(ITick tick)"
        }
    } // namespace GrenadeBlindEffectOnCharacterSystem

    namespace GrenadeCameraShakingModel { // "Game.Battle.GrenadeExplosion.GrenadeCameraShakingModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsShaking = 0x10; // "bool"
            inline constexpr std::uintptr_t Progress = 0x14; // "float"
            inline constexpr std::uintptr_t StartTs = 0x18; // "long"
        }
    } // namespace GrenadeCameraShakingModel

    namespace GrenadeCameraShakingModelUpdater { // "Game.Battle.GrenadeExplosion.GrenadeCameraShakingModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t grenadesExplosionsModel = 0x10; // "GrenadesExplosionsModel"
            inline constexpr std::uintptr_t transformModel = 0x18; // "ITransformModel"
            inline constexpr std::uintptr_t grenadeCameraShakingModel = 0x20; // "GrenadeCameraShakingModel"
            inline constexpr std::uintptr_t grenadeViewDescriptions = 0x28; // "GrenadeViewDescriptions"
            inline constexpr std::uintptr_t aimingModel = 0x30; // "AimingModel"
            inline constexpr std::uintptr_t now = 0x38; // "INow"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA8FCC0; // "public void Update()"
        }
    } // namespace GrenadeCameraShakingModelUpdater

    namespace GrenadeClientModel { // "Game.Battle.Entities.Grenade.Models.GrenadeClientModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t DrawTs = 0x10; // "GrenadeDrawTsModel"
            inline constexpr std::uintptr_t DataInterpolation = 0x18; // "GrenadeDataInterpolationModel"
            inline constexpr std::uintptr_t Position = 0x20; // "SetMovementModel"
            inline constexpr std::uintptr_t GrenadeRotation = 0x28; // "GrenadeRotationModel"
            inline constexpr std::uintptr_t SynchronizePositionWithOwner = 0x30; // "GrenadeSynchronizePositionWithOwnerModel"
            inline constexpr std::uintptr_t CollisionPoint = 0x38; // "GrenadeCollisionPointModel"
            inline constexpr std::uintptr_t Trigger = 0x40; // "ClientGrenadeTriggerModel"
        }
    } // namespace GrenadeClientModel

    namespace GrenadeCollisionPointModel { // "Game.Battle.Entities.Grenade.Models.GrenadeCollisionPointModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t HasLastSourceData = 0x10; // "bool"
            inline constexpr std::uintptr_t LastSourcePosition = 0x14; // "Vector3"
            inline constexpr std::uintptr_t LastSourceVelocity = 0x20; // "Vector3"
            inline constexpr std::uintptr_t LastSourceTs = 0x30; // "long"
            inline constexpr std::uintptr_t HasCollision = 0x38; // "bool"
            inline constexpr std::uintptr_t CollisionPoint = 0x3C; // "Vector3"
            inline constexpr std::uintptr_t HasAdditionalCollisionData = 0x48; // "bool"
            inline constexpr std::uintptr_t ContactNormalAdditionalCollisionData = 0x4C; // "Vector3"
            inline constexpr std::uintptr_t ContactSurfaceTypeAdditionalCollisionData = 0x58; // "byte"
        }
    } // namespace GrenadeCollisionPointModel

    namespace GrenadeCollisionPointUpdater { // "Game.Battle.Entities.Grenade.Updaters.GrenadeCollisionPointUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t interpolationModel = 0x20; // "GrenadeDataInterpolationModel"
            inline constexpr std::uintptr_t collisionPoint = 0x28; // "GrenadeCollisionPointModel"
            inline constexpr std::uintptr_t physicsSceneModel = 0x30; // "PhysicsSceneModel"
            inline constexpr std::uintptr_t hitBoxesModel = 0x38; // "HitBoxesModel"
            inline constexpr std::uintptr_t physicsBodiesModel = 0x40; // "PhysicsBodiesModel"
            inline constexpr std::uintptr_t raycastModel = 0x48; // "RaycastModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA0E700; // "public GrenadeCollisionPointUpdater Init(GrenadeDataInterpolationModel interpolationModel, GrenadeCollisionPointModel collisionPoint, PhysicsSceneModel physicsSceneModel, HitBoxesModel hitBoxesModel, PhysicsBodiesModel physicsBodiesModel, RaycastModel raycastModel)"
            inline constexpr std::uintptr_t Dispose = 0xA0E680; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xB5EDC0; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace GrenadeCollisionPointUpdater

    namespace GrenadeDamageInterval { // "Models.References.Grenade.GrenadeDamage.GrenadeDamageInterval (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Length = 0x10; // "float"
            inline constexpr std::uintptr_t Damage = 0x14; // "int"
        }
    } // namespace GrenadeDamageInterval

    namespace GrenadeData { // "Models.Data.GrenadeData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Description = 0x20; // "GrenadeDescription"
            inline constexpr std::uintptr_t SourcePosition = 0x28; // "IPrimitiveData<Vector3>"
            inline constexpr std::uintptr_t SourceVelocity = 0x30; // "IPrimitiveData<Vector3>"
            inline constexpr std::uintptr_t SourceTs = 0x38; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t IsSleeping = 0x40; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t IsTriggered = 0x48; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t OwnerPublicId = 0x50; // "PublicIdData"
        }
    } // namespace GrenadeData

    namespace GrenadeDataInterpolationModel { // "Game.Battle.Entities.Grenade.Models.GrenadeDataInterpolationModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t SourcePosition = 0x10; // "Vector3"
            inline constexpr std::uintptr_t SourceVelocity = 0x1C; // "Vector3"
            inline constexpr std::uintptr_t SourceTs = 0x28; // "long"
            inline constexpr std::uintptr_t IsSleeping = 0x30; // "bool"
            inline constexpr std::uintptr_t IsTriggered = 0x31; // "bool"
            inline constexpr std::uintptr_t IsStartSleeping = 0x32; // "bool"
        }
    } // namespace GrenadeDataInterpolationModel

    namespace GrenadeDataInterpolationUpdater { // "Game.Battle.Entities.Grenade.Updaters.GrenadeDataInterpolationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t interpolationModel = 0x20; // "GrenadeDataInterpolationModel"
            inline constexpr std::uintptr_t grenadeDescription = 0x28; // "GrenadeDescription"
            inline constexpr std::uintptr_t serverTransform = 0x30; // "GrenadeTransformModel"
            inline constexpr std::uintptr_t serverSourceVelocity = 0x38; // "VelocityModel"
            inline constexpr std::uintptr_t serverSourceTs = 0x40; // "IPrimitiveModel<long>"
            inline constexpr std::uintptr_t serverFlyPhysics = 0x48; // "GrenadeFlyPhysicsModel"
            inline constexpr std::uintptr_t serverTrigger = 0x50; // "GrenadeTriggerModel"
            inline constexpr std::uintptr_t snapshots = 0x58; // "TimelineSnapshotsData<GrenadeTimelineData>"
            inline constexpr std::uintptr_t extrapolations = 0x60; // "TimelineExtrapolationsData<GrenadeTimelineData>"
            inline constexpr std::uintptr_t drawTsModel = 0x68; // "GrenadeDrawTsModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xB5FDA0; // "public GrenadeDataInterpolationUpdater Init(GrenadeDataInterpolationModel interpolationModel, GrenadeDescription grenadeDescription, GrenadeTransformModel serverTransform, VelocityModel serverSourceVelocity, IPrimitiveModel<long> serverSourceTs, GrenadeFlyPhysicsModel serverFlyPhysics, GrenadeTriggerModel serverTrigger, TimelineSnapshotsData<GrenadeTimelineData> snapshots, TimelineExtrapolationsData<GrenadeTimelineData> extrapolations, GrenadeDrawTsModel drawTsModel)"
            inline constexpr std::uintptr_t Dispose = 0xB5FCF0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xB5FE80; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace GrenadeDataInterpolationUpdater

    namespace GrenadeDescription { // "Models.References.Grenade.GrenadeDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t TriggerTimer = 0x20; // "long"
            inline constexpr std::uintptr_t PeriodsCount = 0x28; // "int"
            inline constexpr std::uintptr_t PeriodDuration = 0x2C; // "int"
            inline constexpr std::uintptr_t InstantDamage = 0x30; // "IGrenadeInstantDamage"
            inline constexpr std::uintptr_t SpecialEffectsRadius = 0x38; // "float"
            inline constexpr std::uintptr_t InstantBlindSpecialEffect = 0x3C; // "bool"
            inline constexpr std::uintptr_t IsPeriodSmokeSpecialEffect = 0x3D; // "bool"
            inline constexpr std::uintptr_t PeriodDamageSpecialEffect = 0x40; // "int"
            inline constexpr std::uintptr_t PeriodDamageTypeSpecialEffectFunc = 0x48; // "Func<DamageTypeDescription>"
            inline constexpr std::uintptr_t IsMustSleepOnTrigger = 0x50; // "bool"
            inline constexpr std::uintptr_t IsPeriodDamageSpecialEffect = 0x51; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_PeriodDamageTypeSpecialEffect = 0x4048E90; // "public DamageTypeDescription get_PeriodDamageTypeSpecialEffect()"
        }
    } // namespace GrenadeDescription

    namespace GrenadeDestroyModel { // "Models.Models.GrenadeDestroy.GrenadeDestroyModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "GrenadeModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Destroy = 0x4963770; // "public void Destroy(WorldEntitiesModel worldEntitiesModel)"
        }
    } // namespace GrenadeDestroyModel

    namespace GrenadeDrawTsModel { // "Game.Battle.Entities.Grenade.Models.GrenadeDrawTsModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t DrawTs = 0x10; // "long"
            inline constexpr std::uintptr_t ShouldBeDrawn = 0x18; // "bool"
            inline constexpr std::uintptr_t PrevSimulatedTickIndex = 0x20; // "long"
            inline constexpr std::uintptr_t NextSimulatedTickIndex = 0x28; // "long"
        }
    } // namespace GrenadeDrawTsModel

    namespace GrenadeDrawTsStateModel { // "Game.Battle.Entities.Grenade.Models.GrenadeDrawTsStateModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t State = 0x10; // "GrenadeDrawTsState"
            inline constexpr std::uintptr_t TimeLeft = 0x18; // "long"
        }
    } // namespace GrenadeDrawTsStateModel

    namespace GrenadeDrawTsUpdater { // "Game.Battle.Entities.Grenade.Updaters.GrenadeDrawTsUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t drawTsModel = 0x20; // "GrenadeDrawTsModel"
            inline constexpr std::uintptr_t time = 0x28; // "TimeModel"
            inline constexpr std::uintptr_t grenadeViewDescriptions = 0x30; // "GrenadeViewDescriptions"
            inline constexpr std::uintptr_t description = 0x38; // "GrenadeDescription"
            inline constexpr std::uintptr_t characterEntityViews = 0x40; // "IReadOnlyDictionary<int, BattleCharacterEntityView>"
            inline constexpr std::uintptr_t grenadeOwner = 0x48; // "GrenadeOwnerModel"
            inline constexpr std::uintptr_t characterSlotsModel = 0x50; // "ICharacterSlotsModel"
            inline constexpr std::uintptr_t startTs = 0x58; // "long"
            inline constexpr std::uintptr_t operativeDelayedDrawStartTs = 0x60; // "long"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xB601A0; // "public GrenadeDrawTsUpdater Init(GrenadeDrawTsModel drawTsModel, TimeModel time, GrenadeModel grenade, GrenadeViewDescriptions grenadeViewDescriptions, IReadOnlyDictionary<int, BattleCharacterEntityView> characterEntityViews, ICharacterSlotsModel characterSlotsModel)"
            inline constexpr std::uintptr_t Dispose = 0x9ED4D0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xB602D0; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace GrenadeDrawTsUpdater

    namespace GrenadeEntityDataBuilder { // "Models.Replication.EntityDataBuilder.GrenadeEntityDataBuilder (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t paramsModel = 0x10; // "EntitiesParamsModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Build = 0x44B8170; // "public IData Build(int id)"
        }
    } // namespace GrenadeEntityDataBuilder

    namespace GrenadeEntityModel { // "Game.Battle.Entities.Grenade.Models.GrenadeEntityModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ServerModel = 0x18; // "GrenadeModel"
            inline constexpr std::uintptr_t ClientModel = 0x20; // "GrenadeClientModel"
        }
    } // namespace GrenadeEntityModel

    namespace GrenadeEntityModelUpdater { // "Game.Battle.Entities.Grenade.Updaters.GrenadeEntityModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t updaters = 0x20; // "List<IUpdater>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xB60660; // "public GrenadeEntityModelUpdater Init(GrenadeEntityModel entityModel, TimeModel time, BattleModel battleModel, HitBoxesModel hitBoxesModel, RaycastModel raycastModel, GrenadeViewDescriptions grenadeViewDescriptions, IReadOnlyDictionary<int, BattleCharacterEntityView> characterViews, UpdaterPool updaterPool, RegisterDisposable registerDisposable)"
            inline constexpr std::uintptr_t Dispose = 0xB60600; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0x94CF50; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace GrenadeEntityModelUpdater

    namespace GrenadeEntityStreamReader { // "Models.Replication.EntityStreamReader.GrenadeEntityStreamReader (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t paramsModel = 0x20; // "EntitiesParamsModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t TryReadParams = 0x44B8270; // "protected override bool TryReadParams(int entityId, IBinaryReadStream stream)"
        }
    } // namespace GrenadeEntityStreamReader

    namespace GrenadeExtensions { // "Models.Utils.Extensions.GrenadeExtensions (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x81C8DC0; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t queryResult = 0x0; // "List<PhysicsBodyId>"
            inline constexpr std::uintptr_t debugBattleCharactersBodies = 0x8; // "HashSet<PhysicsBodyId>"
            inline constexpr std::uintptr_t debugNonBattleCharactersBodies = 0x10; // "HashSet<PhysicsBodyId>"
            inline constexpr std::uintptr_t ignoreBodies = 0x18; // "HashSet<PhysicsBodyId>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SearchEntitiesForInstantDamageBroadPhase = 0x3959710; // "public static void SearchEntitiesForInstantDamageBroadPhase(PhysicsSceneModel physicsSceneModel, PhysicsBodiesModel physicsBodiesModel, WorldEntitiesModel worldEntitiesModel, in Vector3 searchPosition, float searchRadius, HashSet<PhysicsBodyId> battleCharactersBodiesResult, HashSet<PhysicsBodyId> nonBattleCharactersBodiesResult)"
            inline constexpr std::uintptr_t SearchBattleCharactersForInstantBlindEffectBroadPhase = 0x3959000; // "public static void SearchBattleCharactersForInstantBlindEffectBroadPhase(PhysicsSceneModel physicsSceneModel, PhysicsBodiesModel physicsBodiesModel, WorldEntitiesModel worldEntitiesModel, in Vector3 searchPosition, float searchRadius, HashSet<PhysicsBodyId> battleCharactersBodiesResult)"
            inline constexpr std::uintptr_t SearchEntitiesForPeriodDamageBroadPhase = 0x3959EB0; // "public static void SearchEntitiesForPeriodDamageBroadPhase(PhysicsSceneModel physicsSceneModel, PhysicsBodiesModel physicsBodiesModel, WorldEntitiesModel worldEntitiesModel, in Vector3 searchPosition, float searchRadius, HashSet<PhysicsBodyId> battleCharactersBodiesResult, HashSet<PhysicsBodyId> nonBattleCharactersBodiesResult)"
            inline constexpr std::uintptr_t TryAddBattleCharacterToBroadPhaseResult = 0x395AA70; // "private static bool TryAddBattleCharacterToBroadPhaseResult(PhysicsBodiesModel physicsBodiesModel, PhysicsBodyId bodyId, HashSet<PhysicsBodyId> battleCharactersBodiesResult)"
            inline constexpr std::uintptr_t TryAddBattleCharacterFromVehicleToBroadPhaseResult = 0x395A780; // "private static bool TryAddBattleCharacterFromVehicleToBroadPhaseResult(PhysicsBodiesModel physicsBodiesModel, WorldEntitiesModel worldEntitiesModel, PhysicsBodyId bodyId, HashSet<PhysicsBodyId> battleCharactersBodiesResult)"
            inline constexpr std::uintptr_t TryAddBattleCharacterFromHideObjectToBroadPhaseResult = 0x395A630; // "private static bool TryAddBattleCharacterFromHideObjectToBroadPhaseResult(PhysicsBodiesModel physicsBodiesModel, WorldEntitiesModel worldEntitiesModel, PhysicsBodyId bodyId, HashSet<PhysicsBodyId> battleCharactersBodiesResult)"
            inline constexpr std::uintptr_t IsPossibleAddBattleCharacterToBroadPhaseResult = 0x3958E50; // "private static bool IsPossibleAddBattleCharacterToBroadPhaseResult(BattleCharacterModel battleCharacter)"
            inline constexpr std::uintptr_t CalculateInstantDamageInfoForBattleCharacterNarrowPhase = 0x39579B0; // "public static ValueTuple<bool, float, Vector3> CalculateInstantDamageInfoForBattleCharacterNarrowPhase(PhysicsSceneModel physicsSceneModel, HitBoxesModel hitBoxes, RaycastModel raycastModel, WorldEntitiesModel worldEntitiesModel, in Vector3 searchPosition, float searchRadius, BattleCharacterModel battleCharacter)"
            inline constexpr std::uintptr_t CalculateInstantBlindInfoForBattleCharacterNarrowPhase = 0x3957530; // "public static ValueTuple<bool, float, Vector3> CalculateInstantBlindInfoForBattleCharacterNarrowPhase(PhysicsSceneModel physicsSceneModel, HitBoxesModel hitBoxes, RaycastModel raycastModel, WorldEntitiesModel worldEntitiesModel, in Vector3 searchPosition, float searchRadius, BattleCharacterModel battleCharacter)"
            inline constexpr std::uintptr_t CalculatePeriodDamageInfoForBattleCharacterNarrowPhase = 0x3958300; // "public static bool CalculatePeriodDamageInfoForBattleCharacterNarrowPhase(in Vector3 searchPosition, float searchRadius, BattleCharacterModel battleCharacter)"
            inline constexpr std::uintptr_t CanInstantDamageCharacter = 0x3958560; // "public static bool CanInstantDamageCharacter(PhysicsSceneModel physicsSceneModel, HitBoxesModel hitBoxes, RaycastModel raycastModel, WorldEntitiesModel worldEntitiesModel, in Vector3 searchPosition, float searchRadius, BattleCharacterModel characterModel)"
            inline constexpr std::uintptr_t CanPeriodDamageCharacter = 0x3958620; // "public static bool CanPeriodDamageCharacter(in Vector3 searchPosition, float searchRadius, BattleCharacterModel characterModel)"
            inline constexpr std::uintptr_t CanInstantBlindCharacter = 0x39584A0; // "public static bool CanInstantBlindCharacter(PhysicsSceneModel physicsSceneModel, HitBoxesModel hitBoxes, RaycastModel raycastModel, WorldEntitiesModel worldEntitiesModel, in Vector3 searchPosition, float searchRadius, BattleCharacterModel characterModel)"
            inline constexpr std::uintptr_t DebugBattleCharactersInstantDamage = 0x3958A10; // "public static void DebugBattleCharactersInstantDamage(PhysicsSceneModel physicsSceneModel, HitBoxesModel hitBoxes, RaycastModel raycastModel, PhysicsBodiesModel physicsBodiesModel, WorldEntitiesModel worldEntitiesModel, in Vector3 searchPosition, float searchRadius, Func<BattleCharacterModel, BattleCharacterModel> serverToSimulatedFunc, List<ValueTuple<bool, Vector3>> battleCharactersResult)"
            inline constexpr std::uintptr_t DebugBattleCharactersInstantBlindEffect = 0x3958690; // "public static void DebugBattleCharactersInstantBlindEffect(PhysicsSceneModel physicsSceneModel, HitBoxesModel hitBoxes, RaycastModel raycastModel, PhysicsBodiesModel physicsBodiesModel, WorldEntitiesModel worldEntitiesModel, in Vector3 searchPosition, float searchRadius, Func<BattleCharacterModel, BattleCharacterModel> serverToSimulatedFunc, List<ValueTuple<bool, Vector3>> battleCharactersResult)"
            inline constexpr std::uintptr_t CalculateNarrowPhaseRaycastParams = 0x3957E30; // "private static void CalculateNarrowPhaseRaycastParams(BattleCharacterModel battleCharacter, HitBoxData[] hitBoxesNodes, HitBoxPartData[] hitBoxesParts, HitBoxShapesData hitBoxShapes, WorldEntitiesModel worldEntitiesModel, HashSet<PhysicsBodyId> ignoreBodies, out Vector3 raycastTarget)"
            inline constexpr std::uintptr_t MakeGrenadeSleep = 0x3958EA0; // "public static void MakeGrenadeSleep(long now, GrenadeTransformModel transform, VelocityModel sourceVelocity, IPrimitiveModel<long> sourceTs, GrenadeFlyPhysicsModel flyPhysics)"
            inline constexpr std::uintptr_t CalculateGrenadeThrowPosition = 0x3956E30; // "public static Vector3 CalculateGrenadeThrowPosition(in Vector3 characterPosition, in Vector3 characterRightVector, float crouchModifier, BattleCharacterConfig battleCharacterConfig)"
            inline constexpr std::uintptr_t CalculateGrenadeThrowVelocity = 0x3957140; // "public static Vector3 CalculateGrenadeThrowVelocity(in Vector3 lookDirection, in Vector3 characterRightVector)"
            inline constexpr std::uintptr_t IsCanTriggerGrenadeWithHeavyEffects = 0x3958DA0; // "public static bool IsCanTriggerGrenadeWithHeavyEffects(GrenadeTriggerModel trigger, PhysicsQueueData<GrenadeTriggerHeavyEffectItem> heavyEffectsQueue, int expectedHeavyEffectsTotalCount)"
            inline constexpr std::uintptr_t IsCanTriggerGrenadeWithLightEffects = 0x3958E30; // "public static bool IsCanTriggerGrenadeWithLightEffects(GrenadeTriggerModel trigger)"
        }
    } // namespace GrenadeExtensions

    namespace GrenadeGasAffectsCharacterModelUpdater { // "Game.Battle.Entities.Grenade.Updaters.GrenadeGasAffectsCharacterModelUpdater (Battle.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x81C90F8; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace Fields {
            inline constexpr std::uintptr_t grenadeTrigger = 0x20; // "GrenadeTriggerModel"
            inline constexpr std::uintptr_t clientTriggerModel = 0x28; // "ClientGrenadeTriggerModel"
            inline constexpr std::uintptr_t grenadePosition = 0x30; // "SetMovementModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x38; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t description = 0x40; // "GrenadeDescription"
            inline constexpr std::uintptr_t effectDuration = 0x48; // "long"
            inline constexpr std::uintptr_t now = 0x50; // "INow"
            inline constexpr std::uintptr_t physicsBodiesModel = 0x58; // "PhysicsBodiesModel"
        }
        namespace StaticFields {
            inline constexpr std::uintptr_t battleCharactersBroadPhaseResult = 0x0; // "HashSet<PhysicsBodyId>"
            inline constexpr std::uintptr_t nonBattleCharactersBroadPhaseResult = 0x8; // "HashSet<PhysicsBodyId>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xB622F0; // "public GrenadeGasAffectsCharacterModelUpdater Init(BattleModel battleModel, GrenadeEntityModel grenadeEntity, INow now)"
            inline constexpr std::uintptr_t Dispose = 0xB62260; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xB62440; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace GrenadeGasAffectsCharacterModelUpdater

    namespace GrenadeInitializeModel { // "Models.Models.GrenadeInitialize.GrenadeInitializeModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "GrenadeModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Initialize = 0x4963830; // "public void Initialize(WorldEntitiesModel worldEntitiesModel)"
        }
    } // namespace GrenadeInitializeModel

    namespace GrenadeInstantDamage { // "Models.References.Grenade.GrenadeDamage.GrenadeInstantDamage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t MaxDamageDistance = 0x10; // "float"
            inline constexpr std::uintptr_t MaxDamage = 0x14; // "int"
            inline constexpr std::uintptr_t Intervals = 0x18; // "IReadOnlyList<GrenadeDamageInterval>"
            inline constexpr std::uintptr_t IntervalsCount = 0x20; // "int"
            inline constexpr std::uintptr_t MaxRange = 0x24; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Calculate = 0x440AAD0; // "public int Calculate(float range)"
        }
    } // namespace GrenadeInstantDamage

    namespace GrenadeInterpolationTicksUpdater { // "Game.Battle.Entities.Grenade.Updaters.GrenadeInterpolationTicksUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t drawTsModel = 0x20; // "GrenadeDrawTsModel"
            inline constexpr std::uintptr_t time = 0x28; // "TimeModel"
            inline constexpr std::uintptr_t snapshots = 0x30; // "TimelineSnapshotsData<GrenadeTimelineData>"
            inline constexpr std::uintptr_t extrapolations = 0x38; // "TimelineExtrapolationsData<GrenadeTimelineData>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0x9F4C50; // "public GrenadeInterpolationTicksUpdater Init(GrenadeDrawTsModel drawTsModel, TimeModel time, TimelineSnapshotsData<GrenadeTimelineData> snapshots, TimelineExtrapolationsData<GrenadeTimelineData> extrapolations)"
            inline constexpr std::uintptr_t Dispose = 0x9F4BF0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xB62E20; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace GrenadeInterpolationTicksUpdater

    namespace GrenadeModel { // "Models.Models.Grenade.GrenadeModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Id = 0x10; // "int"
            inline constexpr std::uintptr_t Description = 0x18; // "GrenadeDescription"
            inline constexpr std::uintptr_t Initialize = 0x20; // "GrenadeInitializeModel"
            inline constexpr std::uintptr_t Destroy = 0x28; // "GrenadeDestroyModel"
            inline constexpr std::uintptr_t Transform = 0x30; // "GrenadeTransformModel"
            inline constexpr std::uintptr_t SourceVelocity = 0x38; // "VelocityModel"
            inline constexpr std::uintptr_t SourceTs = 0x40; // "IPrimitiveModel<long>"
            inline constexpr std::uintptr_t FlyPhysics = 0x48; // "GrenadeFlyPhysicsModel"
            inline constexpr std::uintptr_t TriggerTimerEndTs = 0x50; // "IPrimitiveModel<long>"
            inline constexpr std::uintptr_t Trigger = 0x58; // "GrenadeTriggerModel"
            inline constexpr std::uintptr_t PeriodsCounter = 0x60; // "IPrimitiveModel<int>"
            inline constexpr std::uintptr_t RemoveTs = 0x68; // "IPrimitiveModel<long>"
            inline constexpr std::uintptr_t Owner = 0x70; // "GrenadeOwnerModel"
            inline constexpr std::uintptr_t TimelineData = 0x78; // "ITimelineDataModel<GrenadeTimelineData>"
            inline constexpr std::uintptr_t Snapshots = 0x80; // "TimelineSnapshotsData<GrenadeTimelineData>"
            inline constexpr std::uintptr_t Extrapolation = 0x88; // "TimelineExtrapolationsData<GrenadeTimelineData>"
        }
    } // namespace GrenadeModel

    namespace GrenadeOwnerModel { // "Models.Models.GrenadeOwner.GrenadeOwnerModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ownerPublicId = 0x10; // "PublicIdData"
            inline constexpr std::uintptr_t OwnerName = 0x18; // "string"
            inline constexpr std::uintptr_t OwnerClanTag = 0x20; // "string"
            inline constexpr std::uintptr_t OwnerRole = 0x28; // "PlayerRoleDescription"
            inline constexpr std::uintptr_t IsHaveOwner = 0x30; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_OwnerPublicId = 0x4963D30; // "public long get_OwnerPublicId()"
            inline constexpr std::uintptr_t Set = 0x4963C90; // "public void Set(long ownerPublicId, string ownerName, string ownerClanTag, PlayerRoleDescription ownerRole)"
            inline constexpr std::uintptr_t Clear = 0xCC06F0; // "public void Clear()"
        }
    } // namespace GrenadeOwnerModel

    namespace GrenadePathHitPreviewUpdater { // "Game.Battle.Entities.Grenade.Updaters.GrenadePathHitPreviewUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t pathModel = 0x10; // "GrenadePathModel"
            inline constexpr std::uintptr_t cameraModel = 0x18; // "BattleCameraModel"
            inline constexpr std::uintptr_t preview = 0x20; // "Transform"
            inline constexpr std::uintptr_t camera = 0x28; // "Camera"
            inline constexpr std::uintptr_t isActive = 0x30; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB63A20; // "public void Update()"
        }
    } // namespace GrenadePathHitPreviewUpdater

    namespace GrenadePathModel { // "Game.Battle.Entities.Grenade.Models.GrenadePathModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t SourcePoints = 0x10; // "Vector3[]"
            inline constexpr std::uintptr_t CollisionPoint = 0x18; // "Nullable<Vector3>"
            inline constexpr std::uintptr_t SourceCount = 0x28; // "int"
            inline constexpr std::uintptr_t IsActive = 0x2C; // "bool"
            inline constexpr std::uintptr_t MaxIterations = 0x30; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t UpdateTrailPoints = 0xB63F80; // "public static void UpdateTrailPoints(Vector3[] sourcePoints, int sourceCount, Vector3[] pathPoints, float intensityStep, float rangeStep, float easingWidth, int iterations)"
            inline constexpr std::uintptr_t OrthogonalProjection = 0xB63EB0; // "private static Vector3 OrthogonalProjection(Vector3 line, Vector3 point)"
            inline constexpr std::uintptr_t ProcessIntencityStep = 0xB63F60; // "private static float ProcessIntencityStep(float step)"
        }
    } // namespace GrenadePathModel

    namespace GrenadePositionModelUpdater { // "Game.Battle.Entities.Grenade.Updaters.GrenadePositionModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t setMovement = 0x20; // "SetMovementModel"
            inline constexpr std::uintptr_t drawTsModel = 0x28; // "GrenadeDrawTsModel"
            inline constexpr std::uintptr_t interpolationModel = 0x30; // "GrenadeDataInterpolationModel"
            inline constexpr std::uintptr_t synchronize = 0x38; // "GrenadeSynchronizePositionWithOwnerModel"
            inline constexpr std::uintptr_t grenadeViewDescriptions = 0x40; // "GrenadeViewDescriptions"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA5F7A0; // "public GrenadePositionModelUpdater Init(SetMovementModel setMovement, GrenadeDrawTsModel drawTsModel, GrenadeDataInterpolationModel interpolationModel, GrenadeSynchronizePositionWithOwnerModel synchronize, GrenadeViewDescriptions grenadeViewDescriptions)"
            inline constexpr std::uintptr_t Dispose = 0xA123B0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xB64EB0; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace GrenadePositionModelUpdater

    namespace GrenadeRotationModel { // "Game.Battle.Entities.Grenade.Models.GrenadeRotationModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t InitialOrientation = 0x10; // "Quaternion"
            inline constexpr std::uintptr_t AxisOfRotation = 0x20; // "Vector3"
            inline constexpr std::uintptr_t AngularSpeed = 0x2C; // "float"
            inline constexpr std::uintptr_t RotationTime = 0x30; // "float"
            inline constexpr std::uintptr_t Orientation = 0x34; // "Quaternion"
        }
    } // namespace GrenadeRotationModel

    namespace GrenadeRotationModelUpdater { // "Game.Battle.Entities.Grenade.Models.GrenadeRotationModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t characterViews = 0x20; // "IReadOnlyDictionary<int, BattleCharacterEntityView>"
            inline constexpr std::uintptr_t grenadeDataInterpolation = 0x28; // "GrenadeDataInterpolationModel"
            inline constexpr std::uintptr_t grenadeCollisionPoint = 0x30; // "GrenadeCollisionPointModel"
            inline constexpr std::uintptr_t grenadeViewDescriptions = 0x38; // "GrenadeViewDescriptions"
            inline constexpr std::uintptr_t grenadeRotation = 0x40; // "GrenadeRotationModel"
            inline constexpr std::uintptr_t grenadeDrawTs = 0x48; // "GrenadeDrawTsModel"
            inline constexpr std::uintptr_t grenadeOwner = 0x50; // "GrenadeOwnerModel"
            inline constexpr std::uintptr_t characterSlotsModel = 0x58; // "ICharacterSlotsModel"
            inline constexpr std::uintptr_t isStarted = 0x60; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xB86060; // "public GrenadeRotationModelUpdater Init(GrenadeModel server, GrenadeClientModel client, IReadOnlyDictionary<int, BattleCharacterEntityView> characterViews, GrenadeViewDescriptions grenadeViewDescriptions, ICharacterSlotsModel characterSlotsModel)"
            inline constexpr std::uintptr_t Dispose = 0xB62AB0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xB86130; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t GetNotParallelAuxiliaryVector = 0xB85CB0; // "private Vector3 GetNotParallelAuxiliaryVector(in Vector3 original)"
            inline constexpr std::uintptr_t GetRandomOrthogonalVector = 0xB85DC0; // "private Vector3 GetRandomOrthogonalVector(in Vector3 source)"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace GrenadeRotationModelUpdater

    namespace GrenadeRules { // "Game.Battle.Entities.Grenade.Models.GrenadeRules (Battle.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t PredictSmokescreenDurationSinceGrenadeWasTriggered = 0xB867A0; // "public static long PredictSmokescreenDurationSinceGrenadeWasTriggered(GrenadeDescription description, long now, long sourceTs)"
        }
    } // namespace GrenadeRules

    namespace GrenadeSettings { // "Models.References.Grenade.GrenadeSettings (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x81CA110; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t GrenadeFlyBodyTypeFilter = 0x0; // "Func<int, bool>"
            inline constexpr std::uintptr_t DynamicReflectionsMods = 0x8; // "Quaternion[]"
            inline constexpr std::uintptr_t CharacterSpeedWithGrenadeInHand = 0x10; // "CharacterSpeed"
            inline constexpr std::uintptr_t CharacterSpeedOnGrenadeThrowOrHold = 0x18; // "CharacterSpeed"
            inline constexpr std::uintptr_t damageImmuneDurations = 0x20; // "Dictionary<DamageTypeDescription, long>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t GetDamageImmuneDuration = 0x440AD90; // "public static long GetDamageImmuneDuration(DamageTypeDescription damageType)"
        }
    } // namespace GrenadeSettings

    namespace GrenadesExplosionsModel { // "Game.Battle.GrenadeExplosion.GrenadesExplosionsModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Explosions = 0x10; // "Queue<ValueTuple<Vector3, long>>"
            inline constexpr std::uintptr_t LastFlashExplosionPosition = 0x18; // "Nullable<Vector3>"
        }
    } // namespace GrenadesExplosionsModel

    namespace GrenadesExplosionsModelUpdater { // "Game.Battle.GrenadeExplosion.GrenadesExplosionsModelUpdater (Battle.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x81CAF88; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace Fields {
            inline constexpr std::uintptr_t battleEntitiesModel = 0x20; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t physicsBodiesModel = 0x28; // "PhysicsBodiesModel"
            inline constexpr std::uintptr_t grenadesExplosionsModel = 0x30; // "GrenadesExplosionsModel"
            inline constexpr std::uintptr_t grenadeTriggerModel = 0x38; // "ClientGrenadeTriggerModel"
            inline constexpr std::uintptr_t movementModel = 0x40; // "SetMovementModel"
            inline constexpr std::uintptr_t description = 0x48; // "GrenadeDescription"
            inline constexpr std::uintptr_t hitBoxesModel = 0x50; // "HitBoxesModel"
            inline constexpr std::uintptr_t raycastModel = 0x58; // "RaycastModel"
            inline constexpr std::uintptr_t now = 0x60; // "INow"
        }
        namespace StaticFields {
            inline constexpr std::uintptr_t battleCharactersBroadPhaseResult = 0x0; // "HashSet<PhysicsBodyId>"
            inline constexpr std::uintptr_t nonBattleCharactersBroadPhaseResult = 0x8; // "HashSet<PhysicsBodyId>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xA90110; // "public GrenadesExplosionsModelUpdater Init(BattleModel battleModel, GrenadeEntityModel grenadeEntityModel, HitBoxesModel hitBoxesModel, RaycastModel raycastModel, INow now)"
            inline constexpr std::uintptr_t Dispose = 0xA90070; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA902E0; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace GrenadesExplosionsModelUpdater

    namespace GrenadesFlashExplosionModelUpdater { // "Game.Battle.GrenadeExplosion.GrenadesFlashExplosionModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t grenadesExplosionsModel = 0x20; // "GrenadesExplosionsModel"
            inline constexpr std::uintptr_t grenadeTriggerModel = 0x28; // "ClientGrenadeTriggerModel"
            inline constexpr std::uintptr_t movementModel = 0x30; // "SetMovementModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0x998C80; // "public GrenadesFlashExplosionModelUpdater Init(GrenadesExplosionsModel grenadesExplosionsModel, ClientGrenadeTriggerModel grenadeTriggerModel, SetMovementModel movementModel)"
            inline constexpr std::uintptr_t Dispose = 0x9F6DA0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xA90A80; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace GrenadesFlashExplosionModelUpdater

    namespace GrenadeSynchronizePositionWithOwnerModel { // "Game.Battle.Entities.Grenade.Models.GrenadeSynchronizePositionWithOwnerModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t InitialOffset = 0x10; // "Vector3"
            inline constexpr std::uintptr_t TimeLeft = 0x1C; // "float"
        }
    } // namespace GrenadeSynchronizePositionWithOwnerModel

    namespace GrenadeSynchronizePositionWithOwnerModelUpdater { // "Game.Battle.Entities.Grenade.Updaters.GrenadeSynchronizePositionWithOwnerModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t grenadeTsModel = 0x20; // "GrenadeDrawTsModel"
            inline constexpr std::uintptr_t synchronizePosition = 0x28; // "GrenadeSynchronizePositionWithOwnerModel"
            inline constexpr std::uintptr_t characterViews = 0x30; // "IReadOnlyDictionary<int, BattleCharacterEntityView>"
            inline constexpr std::uintptr_t grenadeViewDescriptions = 0x38; // "GrenadeViewDescriptions"
            inline constexpr std::uintptr_t snapshots = 0x40; // "TimelineSnapshotsData<GrenadeTimelineData>"
            inline constexpr std::uintptr_t grenadeOwner = 0x48; // "GrenadeOwnerModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x50; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t characterSlotsModel = 0x58; // "ICharacterSlotsModel"
            inline constexpr std::uintptr_t isStarted = 0x60; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0xB65FE0; // "public GrenadeSynchronizePositionWithOwnerModelUpdater Init(GrenadeModel grenade, GrenadeClientModel client, IReadOnlyDictionary<int, BattleCharacterEntityView> characterViews, GrenadeViewDescriptions grenadeViewDescriptions, IBattleEntitiesModel battleEntitiesModel, ICharacterSlotsModel characterSlotsModel)"
            inline constexpr std::uintptr_t Dispose = 0xB62AB0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xB663C0; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t IsCollisionHappened = 0xB66180; // "private bool IsCollisionHappened(long now, long syncEndTs, out long collisionTs)"
            inline constexpr std::uintptr_t TryGetGrenadeOwnerWeaponParentPosition = 0xB66780; // "private bool TryGetGrenadeOwnerWeaponParentPosition(long publicId, out Vector3 position)"
            inline constexpr std::uintptr_t IsCharacterInVehicle = 0xB660C0; // "private bool IsCharacterInVehicle(IEntityModel entityModel)"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace GrenadeSynchronizePositionWithOwnerModelUpdater

    namespace GrenadeTimelineData { // "Models.Timeline.Data.Entity.GrenadeTimelineData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t SourcePosition = 0x0; // "Vector3"
            inline constexpr std::uintptr_t SourceVelocity = 0xC; // "Vector3"
            inline constexpr std::uintptr_t SourceTs = 0x18; // "long"
            inline constexpr std::uintptr_t IsSleeping = 0x20; // "bool"
        }
    } // namespace GrenadeTimelineData

    namespace GrenadeTimelineDataExtensions { // "Models.Utils.Timeline.Data.GrenadeTimelineDataExtensions (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x81CA5E0; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t InterpolationFunc = 0x0; // "TimelineDelegates.Interpolation<GrenadeTimelineData>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Interpolation = 0x394C760; // "private static void Interpolation(in GrenadeTimelineData from, in GrenadeTimelineData to, float t, out GrenadeTimelineData result)"
        }
    } // namespace GrenadeTimelineDataExtensions

    namespace GrenadeTimelineDataModel { // "Models.Models.TimelineDataModel.GrenadeTimelineDataModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t transform = 0x10; // "GrenadeTransformModel"
            inline constexpr std::uintptr_t sourceVelocity = 0x18; // "VelocityModel"
            inline constexpr std::uintptr_t sourceTs = 0x20; // "IPrimitiveModel<long>"
            inline constexpr std::uintptr_t flyPhysics = 0x28; // "GrenadeFlyPhysicsModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Build = 0x48B74F0; // "public GrenadeTimelineData Build()"
        }
    } // namespace GrenadeTimelineDataModel

    namespace GrenadeTrajectoryUpdater { // "Game.Battle.Entities.Player.Updaters.GrenadeTrajectoryUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t pathModel = 0x10; // "GrenadePathModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x18; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t physicsSceneModel = 0x20; // "PhysicsSceneModel"
            inline constexpr std::uintptr_t raycastModel = 0x28; // "RaycastModel"
            inline constexpr std::uintptr_t hitBoxesModel = 0x30; // "HitBoxesModel"
            inline constexpr std::uintptr_t playerRotationInputModel = 0x38; // "PlayerRotationInputModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t GetMaxTriggerTimer = 0xB06950; // "private long GetMaxTriggerTimer()"
            inline constexpr std::uintptr_t Update = 0xB06AB0; // "public void Update()"
        }
    } // namespace GrenadeTrajectoryUpdater

    namespace GrenadeTransformModel { // "Models.Models.GrenadeTransform.GrenadeTransformModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t sourcePosition = 0x10; // "IPrimitiveData<Vector3>"
            inline constexpr std::uintptr_t Position = 0x18; // "Vector3"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_X = 0x4963E40; // "public float get_X()"
            inline constexpr std::uintptr_t get_Y = 0x4963E50; // "public float get_Y()"
            inline constexpr std::uintptr_t get_Z = 0x4963E60; // "public float get_Z()"
            inline constexpr std::uintptr_t get_SourcePosition = 0x4963D70; // "public Vector3 get_SourcePosition()"
            inline constexpr std::uintptr_t set_SourcePosition = 0x48E2EB0; // "public void set_SourcePosition(Vector3 value)"
        }
    } // namespace GrenadeTransformModel

    namespace GrenadeTriggerHeavyEffectItem { // "Models.Models.GrenadeTriggerQueueModels.GrenadeTriggerHeavyEffectItem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Type = 0x0; // "GrenadeTriggerHeavyEffectItemType"
            inline constexpr std::uintptr_t GrenadeDescription = 0x8; // "GrenadeDescription"
            inline constexpr std::uintptr_t Transform = 0x10; // "GrenadeTransformModel"
            inline constexpr std::uintptr_t Owner = 0x18; // "GrenadeOwnerModel"
            inline constexpr std::uintptr_t TargetRigidBodyId = 0x20; // "PhysicsBodyId"
        }
    } // namespace GrenadeTriggerHeavyEffectItem

    namespace GrenadeTriggerLightEffectItem { // "Models.Models.GrenadeTriggerQueueModels.GrenadeTriggerLightEffectItem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Type = 0x0; // "GrenadeTriggerLightEffectItemType"
            inline constexpr std::uintptr_t GrenadeDescription = 0x8; // "GrenadeDescription"
            inline constexpr std::uintptr_t Transform = 0x10; // "GrenadeTransformModel"
            inline constexpr std::uintptr_t Owner = 0x18; // "GrenadeOwnerModel"
            inline constexpr std::uintptr_t TargetRigidBodyId = 0x20; // "PhysicsBodyId"
        }
    } // namespace GrenadeTriggerLightEffectItem

    namespace GrenadeTriggerModel { // "Models.Models.GrenadeTrigger.GrenadeTriggerModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t isTriggered = 0x10; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t triggerTs = 0x18; // "long"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsTriggered = 0x4963EC0; // "public bool get_IsTriggered()"
            inline constexpr std::uintptr_t get_TriggerTs = 0x7E7130; // "public long get_TriggerTs()"
            inline constexpr std::uintptr_t Trigger = 0x4963E70; // "public void Trigger(long now)"
        }
    } // namespace GrenadeTriggerModel

    namespace GrenadeTriggerUpdater { // "Game.Battle.Entities.Grenade.Updaters.GrenadeTriggerUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t interpolationModel = 0x20; // "GrenadeDataInterpolationModel"
            inline constexpr std::uintptr_t trigger = 0x28; // "ClientGrenadeTriggerModel"
            inline constexpr std::uintptr_t now = 0x30; // "INow"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0x998C80; // "public GrenadeTriggerUpdater Init(GrenadeDataInterpolationModel interpolationModel, ClientGrenadeTriggerModel trigger, INow now)"
            inline constexpr std::uintptr_t Dispose = 0x9F6DA0; // "protected override void Dispose()"
            inline constexpr std::uintptr_t OnUpdate = 0xB67630; // "protected override void OnUpdate()"
            inline constexpr std::uintptr_t Core_Updater_IUpdater_Update = 0x9165B0; // "private void Core.Updater.IUpdater.Update()"
        }
    } // namespace GrenadeTriggerUpdater

    namespace HeadAdaptationManualBehavior { // "Game.Battle.Entities.BattleCharacter.MeleeAttack.HeadAdaptationManualBehavior (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t root = 0x20; // "Transform"
            inline constexpr std::uintptr_t boneTarget = 0x28; // "Transform"
            inline constexpr std::uintptr_t AnimationWeight = 0x30; // "float"
            inline constexpr std::uintptr_t edgeOverrideRotation = 0x34; // "Quaternion"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetOverrideRotation = 0xBEE590; // "public void SetOverrideRotation(Quaternion edgeOverrideRotation)"
            inline constexpr std::uintptr_t ManualUpdate = 0xBEE250; // "public override void ManualUpdate()"
        }
    } // namespace HeadAdaptationManualBehavior

    namespace HealthAutoRestoreSystem { // "Models.Systems.HealthAutoRestoreSystem (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x40F8D00; // "protected override void Tick(ITick tick)"
        }
    } // namespace HealthAutoRestoreSystem

    namespace HealthModel { // "Models.Models.Health.HealthModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t health = 0x10; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t isDead = 0x18; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t maxAmount = 0x20; // "int"
            inline constexpr std::uintptr_t criticalHealth = 0x24; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsDead = 0x4964AC0; // "public bool get_IsDead()"
            inline constexpr std::uintptr_t set_IsDead = 0x4964BC0; // "public void set_IsDead(bool value)"
            inline constexpr std::uintptr_t get_IsFull = 0x4964B10; // "public bool get_IsFull()"
            inline constexpr std::uintptr_t get_IsCriticalHealth = 0x4964A70; // "public bool get_IsCriticalHealth()"
            inline constexpr std::uintptr_t get_Ratio = 0x4964B60; // "public float get_Ratio()"
            inline constexpr std::uintptr_t get_MaxAmount = 0x7E8CD0; // "public int get_MaxAmount()"
            inline constexpr std::uintptr_t get_Amount = 0x4964A20; // "public int get_Amount()"
            inline constexpr std::uintptr_t SetHealth = 0x49649C0; // "public void SetHealth(int value)"
            inline constexpr std::uintptr_t Damage = 0x4964850; // "public void Damage(int damage)"
            inline constexpr std::uintptr_t Heal = 0x4964900; // "public void Heal(int amount)"
        }
    } // namespace HealthModel

    namespace HideWeaponByStateRules { // "Game.Battle.Entities.BattleCharacter.Weapon.HideWeaponByStateRules (Battle.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t GetIsVisible = 0xBCB5A0; // "public static bool GetIsVisible(IBattleCharacterStateModel battleCharacterStateModel, EmotionModel emotionModel, AnimationStateAssistant animationStateAssistant)"
        }
    } // namespace HideWeaponByStateRules

    namespace HitBoxBoxShape { // "Models.HitBox.Data.Shapes.HitBoxBoxShape (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Position = 0x0; // "Vector3"
            inline constexpr std::uintptr_t Orientation = 0xC; // "Quaternion"
            inline constexpr std::uintptr_t Width = 0x1C; // "float"
            inline constexpr std::uintptr_t Height = 0x20; // "float"
            inline constexpr std::uintptr_t Length = 0x24; // "float"
            inline constexpr std::uintptr_t MinX = 0x28; // "float"
            inline constexpr std::uintptr_t MinY = 0x2C; // "float"
            inline constexpr std::uintptr_t MinZ = 0x30; // "float"
            inline constexpr std::uintptr_t MaxX = 0x34; // "float"
            inline constexpr std::uintptr_t MaxY = 0x38; // "float"
            inline constexpr std::uintptr_t MaxZ = 0x3C; // "float"
        }
    } // namespace HitBoxBoxShape

    namespace HitBoxCapsuleShape { // "Models.HitBox.Data.Shapes.HitBoxCapsuleShape (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Position = 0x0; // "Vector3"
            inline constexpr std::uintptr_t Up = 0xC; // "Vector3"
            inline constexpr std::uintptr_t Radius = 0x18; // "float"
            inline constexpr std::uintptr_t Length = 0x1C; // "float"
            inline constexpr std::uintptr_t MinX = 0x20; // "float"
            inline constexpr std::uintptr_t MinY = 0x24; // "float"
            inline constexpr std::uintptr_t MinZ = 0x28; // "float"
            inline constexpr std::uintptr_t MaxX = 0x2C; // "float"
            inline constexpr std::uintptr_t MaxY = 0x30; // "float"
            inline constexpr std::uintptr_t MaxZ = 0x34; // "float"
        }
    } // namespace HitBoxCapsuleShape

    namespace HitBoxCharactersData { // "Models.HitBox.Data.HitBoxCharactersData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t BonesData = 0x10; // "float[]"
            inline constexpr std::uintptr_t CharactersData = 0x18; // "float[]"
            inline constexpr std::uintptr_t CharactersBodyData = 0x20; // "PhysicsBodyId[]"
            inline constexpr std::uintptr_t CharactersHitBoxIdData = 0x28; // "int[]"
        }
    } // namespace HitBoxCharactersData

    namespace HitBoxData { // "Models.HitBox.Data.HitBoxData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t BodyId = 0x0; // "PhysicsBodyId"
            inline constexpr std::uintptr_t PartsStartPointer = 0x8; // "int"
            inline constexpr std::uintptr_t PartsCount = 0xC; // "int"
            inline constexpr std::uintptr_t MinX = 0x10; // "float"
            inline constexpr std::uintptr_t MinY = 0x14; // "float"
            inline constexpr std::uintptr_t MinZ = 0x18; // "float"
            inline constexpr std::uintptr_t MaxX = 0x1C; // "float"
            inline constexpr std::uintptr_t MaxY = 0x20; // "float"
            inline constexpr std::uintptr_t MaxZ = 0x24; // "float"
            inline constexpr std::uintptr_t PreviousHitBoxId = 0x28; // "int"
        }
    } // namespace HitBoxData

    namespace HitBoxes { // "Models.HitBox.HitBoxes (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x81E51E0; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t unitYData = 0x0; // "float[]"
            inline constexpr std::uintptr_t vectorResult = 0x8; // "float[]"
            inline constexpr std::uintptr_t sphereShapeIds = 0x10; // "int[]"
            inline constexpr std::uintptr_t capsuleShapeIds = 0x18; // "int[]"
            inline constexpr std::uintptr_t boxShapeIds = 0x20; // "int[]"
            inline constexpr std::uintptr_t hullShapeIds = 0x28; // "int[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t AddSkeletonHitBox = 0x4A4EBA0; // "public static int AddSkeletonHitBox(HitBoxesData data, PhysicsBodyId bodyId, int previousHitBoxId, int skeletonIndex, SkeletonHitBoxConfig hitBoxDescription, Span<float> hitBoxesBonesData, int boneHitBoxesBonesDataSize, int skeletonHitBoxesBonesDataSize)"
            inline constexpr std::uintptr_t AddTransformHitBox = 0x4A4F6E0; // "public static int AddTransformHitBox(HitBoxesData data, PhysicsBodyId bodyId, int previousHitBoxId, TransformHitBoxDescription hitBoxDescription, in Vector3 worldPosition, in Quaternion worldOrientation)"
            inline constexpr std::uintptr_t AddHitBoxPart = 0x4A4E900; // "public static void AddHitBoxPart(HitBoxesData data, int hitType, byte surfaceType, HitBoxShapeType shapeType, int shapeId)"
            inline constexpr std::uintptr_t AddHitBoxData = 0x4A4DFE0; // "private static int AddHitBoxData(HitBoxesData data, PhysicsBodyId bodyId, int previousHitBoxId, int hitBoxesPartsStartPointer, int spheresCount, int capsulesCount, int boxesCount, int hullsCount)"
            inline constexpr std::uintptr_t AddHitBox = 0x4A4EA20; // "public static int AddHitBox(HitBoxesData data, PhysicsBodyId bodyId, int previousHitBoxId, int partsStartPointer, int partsCount, float minX, float minY, float minZ, float maxX, float maxY, float maxZ)"
            inline constexpr std::uintptr_t UpdateShapeIdsCapacity = 0x4A50BD0; // "private static void UpdateShapeIdsCapacity(int spheresCount, int capsulesCount, int boxesCount, int hullsCount)"
            inline constexpr std::uintptr_t Clear = 0x4A50AD0; // "public static void Clear(HitBoxesData data)"
        }
    } // namespace HitBoxes

    namespace HitBoxesData { // "Models.HitBox.Data.HitBoxesData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t TickIndex = 0x10; // "long"
            inline constexpr std::uintptr_t Shapes = 0x18; // "HitBoxShapesData"
            inline constexpr std::uintptr_t HitBoxes = 0x20; // "PhysicsLinkedListData<HitBoxData>"
            inline constexpr std::uintptr_t HitBoxesPartsSize = 0x28; // "int"
            inline constexpr std::uintptr_t HitBoxesParts = 0x30; // "HitBoxPartData[]"
        }
    } // namespace HitBoxesData

    namespace HitBoxesDataCollection { // "Models.HitBox.HitBoxesDataCollection.HitBoxesDataCollection (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t capacity = 0x10; // "int"
            inline constexpr std::uintptr_t array = 0x18; // "HitBoxesData[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Get = 0x4A782D0; // "public HitBoxesData Get(long tickIndex)"
            inline constexpr std::uintptr_t GetIndex = 0x4A782C0; // "private int GetIndex(long value)"
            inline constexpr std::uintptr_t GetEnumerator = 0x4A78250; // "public IEnumerator<HitBoxesData> GetEnumerator()"
            inline constexpr std::uintptr_t System_Collections_IEnumerable_GetEnumerator = 0x4A78250; // "private IEnumerator System.Collections.IEnumerable.GetEnumerator()"
        }
    } // namespace HitBoxesDataCollection

    namespace HitBoxesInfoModel { // "Models.HitBox.HitBoxesInfo.HitBoxesInfoModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t TickIndex = 0x10; // "long"
        }
    } // namespace HitBoxesInfoModel

    namespace HitBoxesInterpolation { // "Models.HitBox.Interpolation.HitBoxesInterpolation (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t Interpolate = 0x4A79D20; // "public static void Interpolate(HitBoxesData previousHitBoxesData, HitBoxesData currentHitBoxesData, HitBoxesData interpolatedHitBoxesData, float dt)"
            inline constexpr std::uintptr_t CopyHitBox = 0x4A785A0; // "private static void CopyHitBox(HitBoxesData currentHitBoxesData, HitBoxesData interpolatedHitBoxesData, in HitBoxData currentHitBoxData)"
            inline constexpr std::uintptr_t CopyHitBoxParts = 0x4A78450; // "private static void CopyHitBoxParts(HitBoxesData currentHitBoxesData, HitBoxesData interpolatedHitBoxesData, in HitBoxData currentHitBoxData)"
            inline constexpr std::uintptr_t CopyShape = 0x4A788F0; // "private static int CopyShape(HitBoxShapesData currentShapes, int currentShapeId, HitBoxShapesData interpolatedShapes, HitBoxShapeType shapeType)"
            inline constexpr std::uintptr_t CopyHullShape = 0x4A78850; // "private static int CopyHullShape(HitBoxShapesData currentShapes, int currentShapeId, HitBoxShapesData interpolatedShapes)"
            inline constexpr std::uintptr_t InterpolateHitBox = 0x4A79130; // "private static void InterpolateHitBox(HitBoxesData previousHitBoxesData, int previousHitBoxId, HitBoxesData currentHitBoxesData, HitBoxesData interpolatedHitBoxesData, in HitBoxData currentHitBoxData, float dt)"
            inline constexpr std::uintptr_t InterpolateHitBoxParts = 0x4A78F20; // "private static void InterpolateHitBoxParts(HitBoxesData previousHitBoxesData, int previousHitBoxId, HitBoxesData currentHitBoxesData, HitBoxesData interpolatedHitBoxesData, in HitBoxData currentHitBoxData, float dt)"
            inline constexpr std::uintptr_t InterpolateShape = 0x4A79580; // "private static int InterpolateShape(HitBoxShapesData previousShapes, int previousShapeId, HitBoxShapesData currentShapes, int currentShapeId, HitBoxShapesData interpolatedShapes, float dt, HitBoxShapeType shapeType)"
            inline constexpr std::uintptr_t InterpolateSphereShape = 0x4A79C40; // "private static int InterpolateSphereShape(HitBoxShapesData interpolatedShapes, ref HitBoxSphereShape shape1, ref HitBoxSphereShape shape2, float dt)"
            inline constexpr std::uintptr_t InterpolateCapsuleShape = 0x4A78D90; // "private static int InterpolateCapsuleShape(HitBoxShapesData interpolatedShapes, ref HitBoxCapsuleShape shape1, ref HitBoxCapsuleShape shape2, float dt)"
            inline constexpr std::uintptr_t InterpolateBoxShape = 0x4A78BF0; // "private static int InterpolateBoxShape(HitBoxShapesData interpolatedShapes, ref HitBoxBoxShape shape1, ref HitBoxBoxShape shape2, float dt)"
            inline constexpr std::uintptr_t InterpolateHullShape = 0x4A79440; // "private static int InterpolateHullShape(HitBoxShapesData interpolatedShapes, ref HitBoxHullShape shape1, ref HitBoxHullShape shape2, PhysicsLinkedListData<HullShapeData> hullData, float dt)"
        }
    } // namespace HitBoxesInterpolation

    namespace HitBoxHullShape { // "Models.HitBox.Data.Shapes.HitBoxHullShape (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Position = 0x0; // "Vector3"
            inline constexpr std::uintptr_t Orientation = 0xC; // "Quaternion"
            inline constexpr std::uintptr_t HullDataId = 0x1C; // "int"
            inline constexpr std::uintptr_t MinX = 0x20; // "float"
            inline constexpr std::uintptr_t MinY = 0x24; // "float"
            inline constexpr std::uintptr_t MinZ = 0x28; // "float"
            inline constexpr std::uintptr_t MaxX = 0x2C; // "float"
            inline constexpr std::uintptr_t MaxY = 0x30; // "float"
            inline constexpr std::uintptr_t MaxZ = 0x34; // "float"
        }
    } // namespace HitBoxHullShape

    namespace HitBoxId { // "Models.HitBox.Utils.HitBoxId (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t IsEmpty = 0x4A47ED0; // "public static bool IsEmpty(int id)"
        }
    } // namespace HitBoxId

    namespace HitBoxIdModel { // "Models.Models.HitBoxId.HitBoxIdModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Id = 0x10; // "int"
        }
    } // namespace HitBoxIdModel

    namespace HitBoxLogic { // "Models.HitBox.Utils.HitBoxLogic (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x81E4838; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t bonesParentData = 0x0; // "float[]"
            inline constexpr std::uintptr_t hitBoxesBonesData = 0x8; // "float[]"
            inline constexpr std::uintptr_t unitYData = 0x10; // "float[]"
            inline constexpr std::uintptr_t animationClips = 0x18; // "List<ValueTuple<AnimationClip, float>>"
            inline constexpr std::uintptr_t animationClipFrames = 0x20; // "List<ValueTuple<AnimationClipFrame, float>>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t CalculateBattleCharacterSkeleton = 0x4A48C20; // "public static void CalculateBattleCharacterSkeleton(BattleCharacterModel character, SkeletonConfig skeletonDescription, WorldEntitiesModel worldEntitiesModel, ContentCacheModel contentCacheModel, long now, float dt)"
            inline constexpr std::uintptr_t ApplyMask = 0x4A48490; // "private static void ApplyMask(SkeletonConfig skeletonDescription, byte mask, ReadOnlySpan<float> maskBonesData, Span<float> bonesData)"
            inline constexpr std::uintptr_t CalculatePoseByAnimationClips = 0x4A4AF20; // "private static void CalculatePoseByAnimationClips(List<ValueTuple<AnimationClip, float>> animationClips, float normalizedTime, SkeletonConfig skeletonDescription, Span<float> bonesData)"
            inline constexpr std::uintptr_t UpdateHitBoxCharactersDataCapacity = 0x4A4B570; // "public static void UpdateHitBoxCharactersDataCapacity(HitBoxCharactersData hitBoxCharactersData, int charactersCount, SkeletonConfig skeletonDescription)"
            inline constexpr std::uintptr_t UpdateCapacity_T_inst_1 = 0x1686200; // "HitBoxLogic.UpdateCapacity<int>"
            // "HitBoxLogic.UpdateCapacity<PhysicsBodyId>"
            // "HitBoxLogic.UpdateCapacity<float>"
            // "HitBoxLogic.UpdateCapacity<__Il2CppFullySharedGenericType>"
            inline constexpr std::uintptr_t GetBonesDataCapacity = 0x4A4B520; // "private static int GetBonesDataCapacity(int charactersCount, SkeletonConfig skeletonDescription)"
            inline constexpr std::uintptr_t GetCharactersDataCapacity = 0x4A4B560; // "private static int GetCharactersDataCapacity(int charactersCount)"
            inline constexpr std::uintptr_t GetCharactersBodyDataCapacity = 0x4A4B550; // "private static int GetCharactersBodyDataCapacity(int charactersCount)"
            inline constexpr std::uintptr_t AddHitBoxCharacterItem = 0x4A481A0; // "public static void AddHitBoxCharacterItem(HitBoxCharactersData hitBoxCharactersData, int characterIndex, PhysicsBodyId bodyId, int previousHitBoxId, SkeletonModel skeletonModel, ITransformModel transformModel, SkeletonAnimationModel skeletonAnimationModel)"
            inline constexpr std::uintptr_t AddBonesDataItem = 0x4A47EE0; // "private static void AddBonesDataItem(Span<float> bonesData, int characterIndex, SkeletonModel skeletonModel)"
            inline constexpr std::uintptr_t AddCharactersDataItem = 0x4A48000; // "private static void AddCharactersDataItem(float[] charactersData, int characterIndex, ITransformModel transformModel, SkeletonAnimationModel skeletonAnimationModel)"
            inline constexpr std::uintptr_t AddCharactersBodyDataItem = 0x4A47FD0; // "private static void AddCharactersBodyDataItem(PhysicsBodyId[] charactersBodyData, int characterIndex, PhysicsBodyId bodyId)"
            inline constexpr std::uintptr_t AddCharactersPreviousHitBoxIdDataItem = 0x4A48170; // "private static void AddCharactersPreviousHitBoxIdDataItem(int[] charactersHitBoxIdData, int characterIndex, int previousHitBoxId)"
            inline constexpr std::uintptr_t CalculateCharacterHitBoxes = 0x4A49F80; // "public static void CalculateCharacterHitBoxes(HitBoxCharactersData hitBoxCharactersData, int charactersCount, SkeletonConfig skeletonDescription, SkeletonHitBoxConfig hitBoxDescription, HitBoxesData hitBoxesData)"
        }
    } // namespace HitBoxLogic

    namespace HitBoxPartData { // "Models.HitBox.Data.HitBoxPartData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t HitType = 0x0; // "int"
            inline constexpr std::uintptr_t SurfaceType = 0x4; // "byte"
            inline constexpr std::uintptr_t ShapeType = 0x8; // "HitBoxShapeType"
            inline constexpr std::uintptr_t ShapeId = 0xC; // "int"
        }
    } // namespace HitBoxPartData

    namespace HitBoxRaycaster { // "Models.HitBox.Raycaster.HitBoxRaycaster (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x81E49D8; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t aabbRaycastResult = 0x0; // "List<int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Raycast = 0x4A77400; // "public static void Raycast(HitBoxesData data, in Vector3 rayFrom, in Vector3 rayDirection, float rayLength, Func<int, bool> hitTypeFilter, HashSet<PhysicsBodyId> ignoreBodies, RaycastResult result)"
            inline constexpr std::uintptr_t RaycastPart = 0x4A76C90; // "private static bool RaycastPart(HitBoxShapesData hitBoxesShapes, HitBoxShapeType shapeType, int shapeId, in Vector3 rayFrom, in Vector3 rayDirection, float rayLength, out Vector3 contactPosition, out Vector3 contactNormal, out float contactDistance)"
            inline constexpr std::uintptr_t RaycastSpherePart = 0x4A77270; // "private static bool RaycastSpherePart(HitBoxSphereShape[] shapes, int shapeId, in Vector3 rayFrom, in Vector3 rayDirection, float rayLength, out Vector3 contactPosition, out Vector3 contactNormal, out float contactDistance)"
            inline constexpr std::uintptr_t RaycastCapsulePart = 0x4A768B0; // "private static bool RaycastCapsulePart(HitBoxCapsuleShape[] shapes, int shapeId, in Vector3 rayFrom, in Vector3 rayDirection, float rayLength, out Vector3 contactPosition, out Vector3 contactNormal, out float contactDistance)"
            inline constexpr std::uintptr_t RaycastBoxPart = 0x4A76650; // "private static bool RaycastBoxPart(HitBoxBoxShape[] shapes, int shapeId, in Vector3 rayFrom, in Vector3 rayDirection, float rayLength, out Vector3 contactPosition, out Vector3 contactNormal, out float contactDistance)"
            inline constexpr std::uintptr_t RaycastHullPart = 0x4A76A90; // "private static bool RaycastHullPart(HitBoxHullShape[] shapes, PhysicsLinkedListData<HullShapeData> hullData, int shapeId, in Vector3 rayFrom, in Vector3 rayDirection, float rayLength, out Vector3 contactPosition, out Vector3 contactNormal, out float contactDistance)"
        }
    } // namespace HitBoxRaycaster

    namespace HitBoxShapes { // "Models.HitBox.HitBoxShapes (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t AddSphereShape = 0x4A4BD50; // "public static int AddSphereShape(HitBoxShapesData data, in Vector3 position, float radius)"
            inline constexpr std::uintptr_t AddCapsuleShape = 0x4A4B960; // "public static int AddCapsuleShape(HitBoxShapesData data, in Vector3 position, in Vector3 up, float radius, float length)"
            inline constexpr std::uintptr_t AddBoxShape = 0x4A4B7E0; // "public static int AddBoxShape(HitBoxShapesData data, in Vector3 position, in Quaternion orientation, float width, float height, float length)"
            inline constexpr std::uintptr_t AddHullShape = 0x4A4BBA0; // "public static int AddHullShape(HitBoxShapesData data, in Vector3 position, in Quaternion orientation, int hullDataId)"
            inline constexpr std::uintptr_t AddHullData = 0x4A4BAE0; // "public static int AddHullData(HitBoxShapesData data, in HullShapeData hullData)"
            inline constexpr std::uintptr_t SetSphereShape = 0x4A4C1D0; // "private static void SetSphereShape(ref HitBoxSphereShape shape, in Vector3 position, float radius)"
            inline constexpr std::uintptr_t SetCapsuleShape = 0x4A4BFB0; // "private static void SetCapsuleShape(ref HitBoxCapsuleShape shape, in Vector3 position, in Vector3 up, float radius, float length)"
            inline constexpr std::uintptr_t SetBoxShape = 0x4A4BF00; // "private static void SetBoxShape(ref HitBoxBoxShape shape, in Vector3 position, in Quaternion orientation, float width, float height, float length)"
            inline constexpr std::uintptr_t SetHullShape = 0x4A4C0A0; // "private static void SetHullShape(ref HitBoxHullShape shape, in Vector3 position, in Quaternion orientation, int hullDataId, PhysicsLinkedListData<HullShapeData> hullData)"
            inline constexpr std::uintptr_t Clear = 0x4A4BE50; // "public static void Clear(HitBoxShapesData data)"
        }
    } // namespace HitBoxShapes

    namespace HitBoxShapesData { // "Models.HitBox.Data.HitBoxShapesData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Spheres = 0x10; // "PhysicsListData<HitBoxSphereShape>"
            inline constexpr std::uintptr_t Capsules = 0x18; // "PhysicsListData<HitBoxCapsuleShape>"
            inline constexpr std::uintptr_t Boxes = 0x20; // "PhysicsListData<HitBoxBoxShape>"
            inline constexpr std::uintptr_t Hulls = 0x28; // "PhysicsListData<HitBoxHullShape>"
            inline constexpr std::uintptr_t HullData = 0x30; // "PhysicsLinkedListData<HullShapeData>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Copy = 0x4A77AE0; // "public HitBoxShapesData Copy()"
        }
    } // namespace HitBoxShapesData

    namespace HitBoxSphereCastBroadPhase { // "Models.HitBox.SphereCast.HitBoxSphereCastBroadPhase (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t ClearResult = 0x111D3E0; // "public static void ClearResult(HitBoxSphereCastBroadPhaseResult result)"
            inline constexpr std::uintptr_t Query = 0x4A4C560; // "public static void Query(HitBoxesData data, in AABB bounds, HashSet<PhysicsBodyId> ignoreBodies, HitBoxSphereCastBroadPhaseResult result)"
            inline constexpr std::uintptr_t AddHitBoxToResult = 0x4A4C470; // "private static void AddHitBoxToResult(HitBoxSphereCastBroadPhaseResult result, int hitBoxId, PhysicsBodyId bodyId)"
        }
    } // namespace HitBoxSphereCastBroadPhase

    namespace HitBoxSphereCastBroadPhaseFilter { // "Models.HitBox.SphereCast.HitBoxSphereCastBroadPhaseFilter (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t RemoveNonMeleeTargets = 0x4A4C230; // "public static void RemoveNonMeleeTargets(PhysicsBodiesModel physicsBodiesModel, HitBoxSphereCastBroadPhaseResult result)"
        }
    } // namespace HitBoxSphereCastBroadPhaseFilter

    namespace HitBoxSphereCastBroadPhaseResult { // "Models.HitBox.SphereCast.Data.HitBoxSphereCastBroadPhaseResult (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t HitBoxCount = 0x10; // "int"
            inline constexpr std::uintptr_t HitBoxes = 0x18; // "int[]"
            inline constexpr std::uintptr_t Bodies = 0x20; // "PhysicsBodyId[]"
        }
    } // namespace HitBoxSphereCastBroadPhaseResult

    namespace HitBoxSphereCastHit { // "Models.HitBox.SphereCast.Data.HitBoxSphereCastHit (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ContactBodyId = 0x0; // "PhysicsBodyId"
            inline constexpr std::uintptr_t ContactHitBoxId = 0x8; // "int"
            inline constexpr std::uintptr_t ContactOverlap = 0xC; // "bool"
            inline constexpr std::uintptr_t ContactPosition = 0x10; // "Vector3"
            inline constexpr std::uintptr_t ContactNormal = 0x1C; // "Vector3"
            inline constexpr std::uintptr_t ContactDistance = 0x28; // "float"
            inline constexpr std::uintptr_t ContactSurfaceType = 0x2C; // "byte"
        }
    } // namespace HitBoxSphereCastHit

    namespace HitBoxSphereCastNarrowPhase { // "Models.HitBox.SphereCast.HitBoxSphereCastNarrowPhase (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t ClearResult = 0x111D3E0; // "public static void ClearResult(HitBoxSphereCastResult result)"
            inline constexpr std::uintptr_t SphereOverlapHitBox = 0x4A4DE10; // "public static bool SphereOverlapHitBox(HitBoxesData data, int hitBoxId, PhysicsBodyId bodyId, in Vector3 sphereCenter, float sphereRadius, Func<int, bool> hitTypeFilter, HitBoxSphereCastResult result)"
            inline constexpr std::uintptr_t SphereCastHitBox = 0x4A4D6C0; // "public static void SphereCastHitBox(HitBoxesData data, int hitBoxId, PhysicsBodyId bodyId, in Vector3 castFrom, in Vector3 castDirection, float castLength, float castRadius, Func<int, bool> hitTypeFilter, HitBoxSphereCastResult result)"
            inline constexpr std::uintptr_t SphereCastHitBoxPart = 0x4A4D200; // "private static bool SphereCastHitBoxPart(HitBoxShapesData shapes, HitBoxShapeType shapeType, int shapeId, in Vector3 castFrom, in Vector3 castDirection, float castLength, float castRadius, out Vector3 contactPosition, out Vector3 contactNormal, out float contactDistance)"
            inline constexpr std::uintptr_t SphereCastSpherePart = 0x4A4DC40; // "private static bool SphereCastSpherePart(HitBoxSphereShape[] shapes, int shapeId, in Vector3 castFrom, in Vector3 castDirection, float castLength, float castRadius, out Vector3 contactPosition, out Vector3 contactNormal, out float contactDistance)"
            inline constexpr std::uintptr_t SphereCastCapsulePart = 0x4A4CFE0; // "private static bool SphereCastCapsulePart(HitBoxCapsuleShape[] shapes, int shapeId, in Vector3 castFrom, in Vector3 castDirection, float castLength, float castRadius, out Vector3 contactPosition, out Vector3 contactNormal, out float contactDistance)"
            inline constexpr std::uintptr_t SphereCastBoxPart = 0x4A4CCF0; // "private static bool SphereCastBoxPart(HitBoxBoxShape[] shapes, int shapeId, in Vector3 castFrom, in Vector3 castDirection, float castLength, float castRadius, out Vector3 contactPosition, out Vector3 contactNormal, out float contactDistance)"
            inline constexpr std::uintptr_t SphereCastHullPart = 0x4A4DA00; // "private static bool SphereCastHullPart(HitBoxHullShape[] shapes, PhysicsLinkedListData<HullShapeData> hullData, int shapeId, in Vector3 castFrom, in Vector3 castDirection, float castLength, float castRadius, out Vector3 contactPosition, out Vector3 contactNormal, out float contactDistance)"
            inline constexpr std::uintptr_t AABBSphereCastTest = 0x4A4CA30; // "private static bool AABBSphereCastTest(in Vector3 castFrom, in Vector3 castDirection, float castLength, float castRadius, float minX, float minY, float minZ, float maxX, float maxY, float maxZ)"
            inline constexpr std::uintptr_t SphereCastAddContactToResult = 0x4A4CAC0; // "private static void SphereCastAddContactToResult(PhysicsBodyId bodyId, int hitBoxId, in Vector3 contactPosition, in Vector3 contactNormal, float contactDistance, byte contactSurfaceType, HitBoxSphereCastResult result)"
            inline constexpr std::uintptr_t SphereCastAddOverlapContactToResult = 0x4A4CBD0; // "private static void SphereCastAddOverlapContactToResult(PhysicsBodyId bodyId, int hitBoxId, byte contactSurfaceType, HitBoxSphereCastResult result)"
        }
    } // namespace HitBoxSphereCastNarrowPhase

    namespace HitBoxSphereCastResult { // "Models.HitBox.SphereCast.Data.HitBoxSphereCastResult (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t HitCount = 0x10; // "int"
            inline constexpr std::uintptr_t Hits = 0x18; // "HitBoxSphereCastHit[]"
        }
    } // namespace HitBoxSphereCastResult

    namespace HitBoxSphereIntersectionTests { // "Models.HitBox.Intersections.HitBoxSphereIntersectionTests (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t TestHitBox = 0x4A77FF0; // "public static bool TestHitBox(HitBoxesData data, in Vector3 sphereCenter, float sphereRadius, int hitBoxId, Func<int, bool> hitTypeFilter, out byte contactSurfaceType)"
            inline constexpr std::uintptr_t TestHitBoxPart = 0x4A77C20; // "private static bool TestHitBoxPart(HitBoxShapesData shapesData, in Vector3 sphereCenter, float sphereRadius, in AABB sphereAABB, HitBoxShapeType shapeType, int shapeId)"
        }
    } // namespace HitBoxSphereIntersectionTests

    namespace HitBoxSphereShape { // "Models.HitBox.Data.Shapes.HitBoxSphereShape (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Position = 0x0; // "Vector3"
            inline constexpr std::uintptr_t Radius = 0xC; // "float"
            inline constexpr std::uintptr_t MinX = 0x10; // "float"
            inline constexpr std::uintptr_t MinY = 0x14; // "float"
            inline constexpr std::uintptr_t MinZ = 0x18; // "float"
            inline constexpr std::uintptr_t MaxX = 0x1C; // "float"
            inline constexpr std::uintptr_t MaxY = 0x20; // "float"
            inline constexpr std::uintptr_t MaxZ = 0x24; // "float"
        }
    } // namespace HitBoxSphereShape

    namespace HitBoxSystem { // "Models.Systems.HitBoxSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t hitBoxes = 0x38; // "HitBoxesModel"
            inline constexpr std::uintptr_t hitBoxDescription = 0x40; // "SkeletonHitBoxConfig"
            inline constexpr std::uintptr_t skeletonDescription = 0x48; // "SkeletonConfig"
            inline constexpr std::uintptr_t hitBoxCharactersData = 0x50; // "HitBoxCharactersData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x40FD930; // "protected override void Tick(ITick tick)"
        }
    } // namespace HitBoxSystem

    namespace IncomingDamageNotificationsUpdater { // "Game.Battle.Entities.Player.Updaters.IncomingDamageNotificationsUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t incomingDamageNotificationsView = 0x10; // "IncomingDamageNotificationsView"
            inline constexpr std::uintptr_t cameraModel = 0x18; // "BattleCameraModel"
            inline constexpr std::uintptr_t hitsCacheModel = 0x20; // "HitsCacheModel"
            inline constexpr std::uintptr_t template_id = 0x28; // "PooledLoadedComponentContent<DamageDirectionView>"
            inline constexpr std::uintptr_t timeModel = 0x30; // "TimeModel"
            inline constexpr std::uintptr_t now = 0x38; // "INow"
            inline constexpr std::uintptr_t sectorViews = 0x40; // "Dictionary<int, IDisposableContent<DamageDirectionView>>"
            inline constexpr std::uintptr_t sectorViewEndTimes = 0x48; // "Dictionary<int, float>"
            inline constexpr std::uintptr_t sectorsToHide = 0x50; // "HashSet<int>"
            inline constexpr std::uintptr_t sectorsToRemove = 0x58; // "HashSet<int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB082F0; // "public void Update()"
            inline constexpr std::uintptr_t ClearNotifications = 0xB07710; // "private void ClearNotifications()"
            inline constexpr std::uintptr_t ShowNotifications = 0xB07CD0; // "private void ShowNotifications()"
            inline constexpr std::uintptr_t HideNotifications = 0xB078D0; // "private void HideNotifications()"
            inline constexpr std::uintptr_t RotateNotificationsRoot = 0xB07BD0; // "private void RotateNotificationsRoot()"
        }
    } // namespace IncomingDamageNotificationsUpdater

    namespace IncomingDebugShotsModel { // "ClientCore.DebugShots.IncomingDebugShotsModel.IncomingDebugShotsModel (Client.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t shots = 0x10; // "List<ShotDebugInfo>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Add = 0xE85AF0; // "public void Add(ShotDebugInfo shotDebugInfo)"
            inline constexpr std::uintptr_t Get = 0x7EC6B0; // "public IEnumerable<ShotDebugInfo> Get()"
            inline constexpr std::uintptr_t Clear = 0xE85BA0; // "public void Clear()"
        }
    } // namespace IncomingDebugShotsModel

    namespace InitArmorModel { // "Models.Models.InitArmor.InitArmorModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t hasArmorData = 0x10; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t amount = 0x18; // "IPrimitiveData<int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Init = 0x4933030; // "public void Init()"
            inline constexpr std::uintptr_t GetAmountModel = 0x4932EB0; // "private static IPrimitiveData<int> GetAmountModel(ReferenceMapData<EquipAmmoOrArmorSlotDescription, IPrimitiveData<int>> data)"
        }
    } // namespace InitArmorModel

    namespace InterpolatedHitBoxes { // "Models.HitBox.Interpolation.Collection.InterpolatedHitBoxes (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t hitBoxesModel = 0x10; // "HitBoxesModel"
            inline constexpr std::uintptr_t pool = 0x18; // "HitBoxesData[]"
            inline constexpr std::uintptr_t cache = 0x20; // "Dictionary<long, int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t TryGet = 0x4A7A160; // "public bool TryGet(long ts, out HitBoxesData hitBoxesData)"
            inline constexpr std::uintptr_t Get = 0x4A79F40; // "public HitBoxesData Get(long ts)"
            inline constexpr std::uintptr_t Resize = 0x4A7A0D0; // "public void Resize(int requiredCount)"
            inline constexpr std::uintptr_t Clear = 0x4A79E40; // "public void Clear()"
            inline constexpr std::uintptr_t InitializePool = 0x4A79FE0; // "private static void InitializePool(HitBoxesData[] pool, int from, int to, HitBoxesModel hitBoxesModel)"
        }
    } // namespace InterpolatedHitBoxes

    namespace KeyboardForceKnockoutEndUpdater { // "Game.Battle.Inputs.KeyboardForceKnockoutEndUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t forceKnockoutEndInputModel = 0x10; // "InputModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x18; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t roomConnectionBattle = 0x20; // "IRoomConnection"
            inline constexpr std::uintptr_t now = 0x28; // "INow"
            inline constexpr std::uintptr_t isRequest = 0x30; // "bool"
            inline constexpr std::uintptr_t holdEndTs = 0x38; // "long"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA7D3E0; // "public void Update()"
            inline constexpr std::uintptr_t SendMessage = 0xA7D330; // "private void SendMessage()"
        }
    } // namespace KeyboardForceKnockoutEndUpdater

    namespace KeyboardSurrenderArrestingUpdater { // "Game.Battle.Inputs.KeyboardSurrenderArrestingUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t surrenderArrestingInputModel = 0x10; // "InputModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x18; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t roomConnectionBattle = 0x20; // "IRoomConnection"
            inline constexpr std::uintptr_t playerSurrenderArrestViewDescription = 0x28; // "PlayerSurrenderArrestViewDescription"
            inline constexpr std::uintptr_t now = 0x30; // "INow"
            inline constexpr std::uintptr_t isRequest = 0x38; // "bool"
            inline constexpr std::uintptr_t holdEndTs = 0x40; // "double"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA7E820; // "public void Update()"
            inline constexpr std::uintptr_t SendMessage = 0xA7E770; // "private void SendMessage()"
        }
    } // namespace KeyboardSurrenderArrestingUpdater

    namespace KeyboardSurrenderInputUpdater { // "Game.Battle.Inputs.Updaters.Keyboard.KeyboardSurrenderInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t keyboardInput = 0x10; // "SurrenderInputModel.KeyboardInputModel"
            inline constexpr std::uintptr_t battleInputModel = 0x18; // "BattleInputModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x20; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t now = 0x28; // "INow"
            inline constexpr std::uintptr_t personalNotificationModel = 0x30; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t localizationKeys = 0x38; // "LocalizationKeys"
            inline constexpr std::uintptr_t crouchStandUpModel = 0x40; // "CrouchStandUpModel"
            inline constexpr std::uintptr_t stopCooldownEndTs = 0x48; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA95510; // "public void Update()"
            inline constexpr std::uintptr_t SetSurrenderInputToStop = 0xA953C0; // "private void SetSurrenderInputToStop()"
        }
    } // namespace KeyboardSurrenderInputUpdater

    namespace KillLogNotificationData { // "Models.ClientNotification.ClientNotificationData.KillLogNotificationData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t targetPublicId = 0x20; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t targetIsDangerous = 0x28; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t targetName = 0x30; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t targetClanTag = 0x38; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t targetRole = 0x40; // "IPrimitiveData<PlayerRoleDescription>"
            inline constexpr std::uintptr_t actorPublicId = 0x48; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t actorIsDangerous = 0x50; // "IPrimitiveData<bool>"
            inline constexpr std::uintptr_t actorName = 0x58; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t actorClanTag = 0x60; // "IPrimitiveData<string>"
            inline constexpr std::uintptr_t actorRole = 0x68; // "IPrimitiveData<PlayerRoleDescription>"
            inline constexpr std::uintptr_t reason = 0x70; // "IPrimitiveData<KillLogReasonDescription>"
            inline constexpr std::uintptr_t weapon = 0x78; // "IPrimitiveData<WeaponDescription>"
            inline constexpr std::uintptr_t grenade = 0x80; // "IPrimitiveData<GrenadeDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Value = 0x4ADE080; // "public ClientNotification.KillLog get_Value()"
            inline constexpr std::uintptr_t set_Value = 0x4ADE4F0; // "public void set_Value(ClientNotification.KillLog value)"
        }
    } // namespace KillLogNotificationData

    namespace KillLogReasonDescription { // "Models.References.KillLogReasonDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x8186778; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t enum_id = 0x0; // "Enum<KillLogReasonDescription>"
            inline constexpr std::uintptr_t Murdered = 0x8; // "KillLogReasonDescription"
            inline constexpr std::uintptr_t KnockedOut = 0x10; // "KillLogReasonDescription"
            inline constexpr std::uintptr_t Handcuffed = 0x18; // "KillLogReasonDescription"
            inline constexpr std::uintptr_t Arrested = 0x20; // "KillLogReasonDescription"
            inline constexpr std::uintptr_t KnockoutFinish = 0x28; // "KillLogReasonDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Enum = 0x40496F0; // "public static ReadOnlyEnum<KillLogReasonDescription> get_Enum()"
        }
    } // namespace KillLogReasonDescription

    namespace KillLogRules { // "Game.Battle.KillLogs.KillLogRules (Battle.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t GetKillLog = 0x9CBFC0; // "public static KillLogsModel.KillLog GetKillLog(GlobalModel globalModel, BattleModel battleModel, UserColorViewDescriptions userColorViewDescriptions, BattleScreenContent battleScreenContent, ClientNotification.KillLog notification)"
            inline constexpr std::uintptr_t GetNickname = 0x9CC2E0; // "private static string GetNickname(BattleScreenContent battleScreenContent, bool isDangerous, string name, string clanTag)"
            inline constexpr std::uintptr_t GetIcon = 0x9CBB80; // "private static ValueTuple<Sprite, KillLogIconSize> GetIcon(BattleScreenContent battleScreenContent, ClientNotification.KillLog notification)"
        }
    } // namespace KillLogRules

    namespace KillLogsModel { // "Game.Battle.KillLogs.KillLogsModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t KillLogs = 0x10; // "Queue<KillLogsModel.KillLog>"
        }
    } // namespace KillLogsModel

    namespace KillLogsModel_KillLog { // "Game.Battle.KillLogs.KillLogsModel.KillLog (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t KillerName = 0x10; // "string"
            inline constexpr std::uintptr_t KillerColor = 0x18; // "Color"
            inline constexpr std::uintptr_t VictimName = 0x28; // "string"
            inline constexpr std::uintptr_t VictimColor = 0x30; // "Color"
            inline constexpr std::uintptr_t IconSize = 0x40; // "KillLogIconSize"
            inline constexpr std::uintptr_t Icon = 0x48; // "Sprite"
            inline constexpr std::uintptr_t HasKnocked = 0x50; // "bool"
        }
    } // namespace KillLogsModel_KillLog

    namespace KillOtherCharacterModel { // "Game.Battle.Entities.Player.Models.KillOtherCharacterModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t EndTs = 0x10; // "float"
        }
    } // namespace KillOtherCharacterModel

    namespace KnockdownLeaveStateModel { // "Models.Models.KnockdownLeaveState.KnockdownLeaveStateModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsActive = 0x10; // "bool"
        }
    } // namespace KnockdownLeaveStateModel

    namespace KnockdownModel { // "Models.Models.Knockdown.KnockdownModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t endTs = 0x10; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t isKnockedForward = 0x18; // "IPrimitiveData<bool>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsActive = 0x493CD40; // "public bool get_IsActive()"
            inline constexpr std::uintptr_t IsEnterState = 0x493C940; // "public bool IsEnterState(long now)"
            inline constexpr std::uintptr_t IsIdleState = 0x493C990; // "public bool IsIdleState(long now)"
            inline constexpr std::uintptr_t IsLeaveState = 0x493C9F0; // "public bool IsLeaveState(long now)"
            inline constexpr std::uintptr_t get_StartTs = 0x493CE20; // "public long get_StartTs()"
            inline constexpr std::uintptr_t get_EnterStateEndTs = 0x493CC10; // "public long get_EnterStateEndTs()"
            inline constexpr std::uintptr_t get_IdleStateEndTs = 0x493CCB0; // "public long get_IdleStateEndTs()"
            inline constexpr std::uintptr_t get_EndTs = 0x493CBC0; // "public long get_EndTs()"
            inline constexpr std::uintptr_t get_IsKnockedForward = 0x493CDD0; // "public bool get_IsKnockedForward()"
            inline constexpr std::uintptr_t Start = 0x493CA40; // "public void Start(long now, bool isKnockedForward)"
            inline constexpr std::uintptr_t Stop = 0x493CB30; // "public void Stop()"
        }
    } // namespace KnockdownModel

    namespace KnockdownStateConfig { // "Models.References.Character.KnockdownStateConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t EnterStateDuration = 0x10; // "long"
            inline constexpr std::uintptr_t IdleStateDuration = 0x18; // "long"
            inline constexpr std::uintptr_t LeaveStateDuration = 0x20; // "long"
            inline constexpr std::uintptr_t TotalDuration = 0x28; // "long"
        }
    } // namespace KnockdownStateConfig

    namespace KnockdownSystem { // "Models.Systems.KnockdownSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t teleport = 0x38; // "TeleportWorldModel"
            inline constexpr std::uintptr_t safeZone = 0x40; // "SafeZoneWorldModel"
            inline constexpr std::uintptr_t physicsBodiesModel = 0x48; // "PhysicsBodiesModel"
            inline constexpr std::uintptr_t physicsSceneModel = 0x50; // "PhysicsSceneModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x40FF2C0; // "protected override void Tick(ITick tick)"
            inline constexpr std::uintptr_t TeleportKnockedDownBattleCharacterToSafeZone = 0x40FF000; // "private void TeleportKnockedDownBattleCharacterToSafeZone(long now, PhysicsBodyId bodyId, bool canUseVerticalWarp)"
        }
    } // namespace KnockdownSystem

    namespace KnockoutBuffUpdater { // "Game.Battle.Buffs.KnockoutBuffUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t now = 0x40; // "INow"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x48; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t isActive = 0x50; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xD4C420; // "public override void Update()"
        }
    } // namespace KnockoutBuffUpdater

    namespace KnockoutDescription { // "Models.References.Knockout.KnockoutDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x818B0C8; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t RevivalRole = 0x0; // "HashSet<ValueTuple<PlayerRoleDescription, PlayerRoleDescription>>"
        }
    } // namespace KnockoutDescription

    namespace KnockoutModel { // "Models.Models.Knockout.KnockoutModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t endTs = 0x10; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t knockoutPhase = 0x18; // "IPrimitiveData<KnockoutPhaseDescription>"
            inline constexpr std::uintptr_t knockoutHitDirectionSectorIndex = 0x20; // "IPrimitiveData<int>"
            inline constexpr std::uintptr_t KillerId = 0x28; // "int"
            inline constexpr std::uintptr_t KillerPublicId = 0x30; // "long"
            inline constexpr std::uintptr_t KillerNickname = 0x38; // "string"
            inline constexpr std::uintptr_t KillerClanTag = 0x40; // "string"
            inline constexpr std::uintptr_t KillerRole = 0x48; // "PlayerRoleDescription"
            inline constexpr std::uintptr_t Weapon = 0x50; // "WeaponDescription"
            inline constexpr std::uintptr_t Grenade = 0x58; // "GrenadeDescription"
            inline constexpr std::uintptr_t Reason = 0x60; // "KnockoutReasonDescription"
            inline constexpr std::uintptr_t TargetRole = 0x68; // "PlayerRoleDescription"
            inline constexpr std::uintptr_t IsSurrendered = 0x70; // "bool"
            inline constexpr std::uintptr_t IsHandcuffing = 0x71; // "bool"
            inline constexpr std::uintptr_t IsHandcuffed = 0x72; // "bool"
            inline constexpr std::uintptr_t Cops = 0x78; // "IEventsSet<int>"
            inline constexpr std::uintptr_t knockoutHitDirectionSectorIndexCache = 0x80; // "int"
            inline constexpr std::uintptr_t knockoutHitDirectionCharacterYawCache = 0x84; // "float"
            inline constexpr std::uintptr_t knockoutHitDirectionXCache = 0x88; // "float"
            inline constexpr std::uintptr_t knockoutHitDirectionZCache = 0x8C; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_HasKillerData = 0x493DA60; // "public bool get_HasKillerData()"
            inline constexpr std::uintptr_t get_IsKnockedOut = 0x493DBA0; // "public bool get_IsKnockedOut()"
            inline constexpr std::uintptr_t get_IsDelayAfterRevive = 0x493DA70; // "public bool get_IsDelayAfterRevive()"
            inline constexpr std::uintptr_t get_EndTs = 0x493DA10; // "public long get_EndTs()"
            inline constexpr std::uintptr_t get_KnockoutHitDirectionSectorIndex = 0x493DCD0; // "public int get_KnockoutHitDirectionSectorIndex()"
            inline constexpr std::uintptr_t CalculateKnockoutHitDirectionForCharacterRotation = 0x493CEB0; // "public ValueTuple<float, float> CalculateKnockoutHitDirectionForCharacterRotation(float characterYaw)"
            inline constexpr std::uintptr_t IsMobile = 0x493D390; // "public bool IsMobile(long now)"
            inline constexpr std::uintptr_t SetKillerData = 0x493D710; // "public void SetKillerData(int id, long publicId, string nickname, string clanTag, PlayerRoleDescription role, WeaponDescription weapon, GrenadeDescription grenade)"
            inline constexpr std::uintptr_t KnockOut = 0x493D510; // "public void KnockOut(long now)"
            inline constexpr std::uintptr_t Set = 0x493D780; // "public void Set(KnockoutReasonDescription reason, PlayerRoleDescription targetRole, CharacterKnockoutOrDeathRobberStateDescription targetRobberState, int knockoutHitDirectionSectorIndex)"
            inline constexpr std::uintptr_t Revive = 0x493D610; // "public void Revive(long now)"
            inline constexpr std::uintptr_t IncreaseKnockoutDuration = 0x493D320; // "public void IncreaseKnockoutDuration(long reviveDuration)"
            inline constexpr std::uintptr_t Clear = 0x493D080; // "public void Clear()"
        }
    } // namespace KnockoutModel

    namespace KnockoutPhaseDescription { // "Models.References.Knockout.KnockoutPhaseDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x818B3F8; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t enum_id = 0x0; // "Enum<KnockoutPhaseDescription>"
            inline constexpr std::uintptr_t KnockedOut = 0x8; // "KnockoutPhaseDescription"
            inline constexpr std::uintptr_t DelayAfterRevive = 0x10; // "KnockoutPhaseDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Enum = 0x43EC9B0; // "public static ReadOnlyEnum<KnockoutPhaseDescription> get_Enum()"
        }
    } // namespace KnockoutPhaseDescription

    namespace KnockoutReasonDescription { // "Models.References.Character.KnockoutReasonDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x818B590; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t PlayerDamage = 0x0; // "KnockoutReasonDescription"
            inline constexpr std::uintptr_t FallDamage = 0x8; // "KnockoutReasonDescription"
            inline constexpr std::uintptr_t VelocityDamage = 0x10; // "KnockoutReasonDescription"
            inline constexpr std::uintptr_t StaminaDamage = 0x18; // "KnockoutReasonDescription"
            inline constexpr std::uintptr_t DamageZone = 0x20; // "KnockoutReasonDescription"
        }
    } // namespace KnockoutReasonDescription

    namespace Linear1dBlendTreeNode { // "Models.HitBox.BlendTreeNode.Linear1dBlendTreeNode (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Nodes = 0x10; // "IBlendTreeNode[]"
            inline constexpr std::uintptr_t Weights = 0x18; // "float[]"
            inline constexpr std::uintptr_t Arg0 = 0x20; // "int"
            inline constexpr std::uintptr_t Arg0MinValue = 0x24; // "float"
            inline constexpr std::uintptr_t Arg0MaxValue = 0x28; // "float"
            inline constexpr std::uintptr_t IntervalInvLengths = 0x30; // "float[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t CollectAnimationClips = 0x4A7AE20; // "public void CollectAnimationClips(ReadOnlySpan<float> args, float nodeWeight, List<ValueTuple<AnimationClip, float>> result)"
        }
    } // namespace Linear1dBlendTreeNode

    namespace Linear1dBlendTreeNodeExtensions { // "Models.HitBox.Extensions.Linear1dBlendTreeNodeExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t CalculateIntervalInvLengths = 0x4A7AC20; // "public static float[] CalculateIntervalInvLengths(ReadOnlySpan<float> weights)"
            inline constexpr std::uintptr_t GetInterval = 0x4A7ACE0; // "public static void GetInterval(ReadOnlySpan<float> weights, ReadOnlySpan<float> intervalInvLengths, float weight, out int leftIndex, out int rightIndex, out float leftWeight, out float rightWeight)"
        }
    } // namespace Linear1dBlendTreeNodeExtensions

    namespace MailItemContext_WeaponSkin { // "Game.Global.Mail.Models.MailItemContext.WeaponSkin (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Description = 0x10; // "WeaponSkinDescription"
        }
    } // namespace MailItemContext_WeaponSkin

    namespace ManualShotInputUpdater { // "Game.Battle.Inputs.ManualShotInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleEntitiesModel = 0x10; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t timeModel = 0x18; // "TimeModel"
            inline constexpr std::uintptr_t battleInputModel = 0x20; // "BattleInputModel"
            inline constexpr std::uintptr_t playerRotationInput = 0x28; // "PlayerRotationInputModel"
            inline constexpr std::uintptr_t shotIntentionModel = 0x30; // "ShotIntentionModel"
            inline constexpr std::uintptr_t shotParamsModel = 0x38; // "ShotParamsModel"
            inline constexpr std::uintptr_t isManualShotFired = 0x40; // "bool"
            inline constexpr std::uintptr_t playerNowTs = 0x48; // "long"
            inline constexpr std::uintptr_t currentTickStartTs = 0x50; // "long"
            inline constexpr std::uintptr_t currentLookDirection = 0x58; // "Vector3"
            inline constexpr std::uintptr_t currentTickStartLookDirection = 0x64; // "Vector3"
            inline constexpr std::uintptr_t previousTickStartLookDirection = 0x70; // "Vector3"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA960D0; // "public void Update()"
            inline constexpr std::uintptr_t Stop = 0xA87460; // "public void Stop()"
            inline constexpr std::uintptr_t UpdateRuntimeData = 0xA95F50; // "private void UpdateRuntimeData()"
            inline constexpr std::uintptr_t SetShotParams = 0xA95E60; // "private void SetShotParams()"
            inline constexpr std::uintptr_t SetInput = 0xA95C20; // "private void SetInput()"
        }
    } // namespace ManualShotInputUpdater

    namespace MeleeAttackConfig { // "Models.References.Melee.MeleeAttackConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t AttackTime = 0x10; // "long"
            inline constexpr std::uintptr_t CooldownTime = 0x18; // "long"
            inline constexpr std::uintptr_t Damage = 0x20; // "int"
            inline constexpr std::uintptr_t DamageHead = 0x24; // "int"
            inline constexpr std::uintptr_t Range = 0x28; // "float"
            inline constexpr std::uintptr_t SqrRange = 0x2C; // "float"
            inline constexpr std::uintptr_t CastHeightStand = 0x30; // "float"
            inline constexpr std::uintptr_t CastHeightCrouch = 0x34; // "float"
            inline constexpr std::uintptr_t CastLength = 0x38; // "float"
            inline constexpr std::uintptr_t CastRadius = 0x3C; // "float"
            inline constexpr std::uintptr_t MaxTargetYawCos = 0x40; // "float"
        }
    } // namespace MeleeAttackConfig

    namespace MeleeAttackExtensions { // "Models.Utils.Extensions.MeleeAttackExtensions (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x81DF048; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t hitBoxSphereCastResult = 0x0; // "HitBoxSphereCastResult"
            inline constexpr std::uintptr_t sphereCastResult = 0x8; // "SphereCastResult"
            inline constexpr std::uintptr_t meleeAttackHits = 0x10; // "MeleeAttackExtensions.MeleeAttackHit[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t IsMeleeTarget = 0x3963600; // "public static bool IsMeleeTarget(PhysicsBodiesModel physicsBodiesModel, PhysicsBodyId bodyId)"
            inline constexpr std::uintptr_t CalculateTarget = 0x3962ED0; // "public static Vector3 CalculateTarget(SphereCastModel sphereCastModel, PhysicsData data, HitBoxesData hitBoxesData, in Vector3 sourceBodyPosition, in Vector3 castFrom, in Vector3 castDirection, float castLength, float castRadius, float minTargetYawCos, PhysicsBodyId ignoreBodyId)"
            inline constexpr std::uintptr_t CollectMeleeHits = 0x3963330; // "private static Span<MeleeAttackExtensions.MeleeAttackHit> CollectMeleeHits(HitBoxSphereCastResult hitBoxSphereCastResult, SphereCastResult sphereCastResult)"
            inline constexpr std::uintptr_t TryGetTargetHit = 0x3963680; // "private static bool TryGetTargetHit(PhysicsData data, in Vector3 sourceBodyPosition, in Vector3 sourceCastDirection, float minTargetYawCos, Span<MeleeAttackExtensions.MeleeAttackHit> hits, out MeleeAttackExtensions.MeleeAttackHit targetHit)"
            inline constexpr std::uintptr_t CalculateTargetYawCos = 0x3962D70; // "private static float CalculateTargetYawCos(PhysicsData data, in Vector3 sourcePosition, in Vector3 sourceDirection, PhysicsBodyId targetBodyId)"
            inline constexpr std::uintptr_t CalculateTargetPosition = 0x39629F0; // "private static Vector3 CalculateTargetPosition(PhysicsData data, HitBoxesData hitBoxesData, in MeleeAttackExtensions.MeleeAttackHit targetHit, in Vector3 castFrom, in Vector3 castDirection, float castLength)"
        }
    } // namespace MeleeAttackExtensions

    namespace MeleeAttackExtensions_MeleeAttackHit { // "Models.Utils.Extensions.MeleeAttackExtensions.MeleeAttackHit (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ContactBodyId = 0x0; // "PhysicsBodyId"
            inline constexpr std::uintptr_t ContactHitBoxId = 0x8; // "int"
            inline constexpr std::uintptr_t ContactOverlap = 0xC; // "bool"
            inline constexpr std::uintptr_t ContactPosition = 0x10; // "Vector3"
            inline constexpr std::uintptr_t ContactNormal = 0x1C; // "Vector3"
            inline constexpr std::uintptr_t ContactDistance = 0x28; // "float"
        }
    } // namespace MeleeAttackExtensions_MeleeAttackHit

    namespace MeleeAttackInputUpdater { // "Game.Battle.Inputs.MeleeAttackInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t personalNotificationModel = 0x10; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t localizationKeys = 0x18; // "LocalizationKeys"
            inline constexpr std::uintptr_t unavailableKeys = 0x20; // "UnavailableTargetActionsKeys"
            inline constexpr std::uintptr_t battleEntities = 0x28; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t battleInputModel = 0x30; // "BattleInputModel"
            inline constexpr std::uintptr_t meleeAttackInput = 0x38; // "InputModel"
            inline constexpr std::uintptr_t shotInputModel = 0x40; // "InputModel"
            inline constexpr std::uintptr_t sprintIntentionModel = 0x48; // "InputIntentionModel"
            inline constexpr std::uintptr_t sprintInputModel = 0x50; // "InputModel"
            inline constexpr std::uintptr_t shotInputLockModel = 0x58; // "ShotInputLockModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA7EFA0; // "public void Update()"
        }
    } // namespace MeleeAttackInputUpdater

    namespace MeleeAttackModel { // "Models.Models.MeleeAttack.MeleeAttackModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t hitTs = 0x10; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t surfaceHit = 0x18; // "IPrimitiveData<byte>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_HitTs = 0x4912000; // "public long get_HitTs()"
            inline constexpr std::uintptr_t set_HitTs = 0x4912120; // "public void set_HitTs(long value)"
            inline constexpr std::uintptr_t get_SurfaceHit = 0x49120D0; // "public byte get_SurfaceHit()"
            inline constexpr std::uintptr_t set_SurfaceHit = 0x4912180; // "public void set_SurfaceHit(byte value)"
            inline constexpr std::uintptr_t get_EndTs = 0x4911F70; // "public long get_EndTs()"
            inline constexpr std::uintptr_t get_IsActive = 0x4912050; // "public bool get_IsActive()"
        }
    } // namespace MeleeAttackModel

    namespace OpticsShootRecoilAnimationUpdater { // "Game.Battle.EntityModel.Player.Weapon.OpticsShootRecoilAnimationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t fireModel = 0x10; // "CharacterFireModel"
            inline constexpr std::uintptr_t recoilAnimationData = 0x18; // "RecoilAnimationData"
            inline constexpr std::uintptr_t transform = 0x20; // "Transform"
            inline constexpr std::uintptr_t rotationInputModel = 0x28; // "PlayerRotationInputModel"
            inline constexpr std::uintptr_t weight = 0x30; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC71A00; // "public void Update()"
        }
    } // namespace OpticsShootRecoilAnimationUpdater

    namespace OpticsWeaponAimingAnimationUpdater { // "Game.Battle.Entities.Player.Weapon.Updaters.OpticsWeaponAimingAnimationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t aimingModel = 0x10; // "CharacterAimingModel"
            inline constexpr std::uintptr_t fireModel = 0x18; // "CharacterFireModel"
            inline constexpr std::uintptr_t view = 0x20; // "PlayerWeaponAnimationView"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB40730; // "public void Update()"
        }
    } // namespace OpticsWeaponAimingAnimationUpdater

    namespace OpticsWeaponInertiaUpdater { // "Game.Battle.EntityModel.Player.Weapon.OpticsWeaponInertiaUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t view = 0x10; // "CharacterWeaponView"
            inline constexpr std::uintptr_t inertiaData = 0x18; // "WeaponInertiaData"
            inline constexpr std::uintptr_t rotation = 0x20; // "PlayerRotationInputModel"
            inline constexpr std::uintptr_t relativeVelocity = 0x28; // "CharacterRelativeVelocityModel"
            inline constexpr std::uintptr_t movementModel = 0x30; // "IMovementModel"
            inline constexpr std::uintptr_t oldRotation = 0x38; // "Vector2"
            inline constexpr std::uintptr_t inertia = 0x40; // "Quaternion"
            inline constexpr std::uintptr_t oldPositionY = 0x50; // "float"
            inline constexpr std::uintptr_t weaponRotation = 0x54; // "Vector3"
            inline constexpr std::uintptr_t weaponQuaternion = 0x60; // "Quaternion"
            inline constexpr std::uintptr_t weaponViewData = 0x70; // "WeaponViewData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC71C40; // "public void Update()"
        }
    } // namespace OpticsWeaponInertiaUpdater

    namespace OpticsWeaponLocalPositionUpdater { // "Game.Battle.EntityModel.Player.Weapon.OpticsWeaponLocalPositionUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t view = 0x10; // "CharacterWeaponView"
            inline constexpr std::uintptr_t transform = 0x18; // "Transform"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC72450; // "public void Update()"
        }
    } // namespace OpticsWeaponLocalPositionUpdater

    namespace OpticsWeaponWorldPositionUpdater { // "Game.Battle.EntityModel.Player.Weapon.OpticsWeaponWorldPositionUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t rotationInputModel = 0x10; // "PlayerRotationInputModel"
            inline constexpr std::uintptr_t transform = 0x18; // "Transform"
            inline constexpr std::uintptr_t weaponDescription = 0x20; // "WeaponDescription"
            inline constexpr std::uintptr_t movementModel = 0x28; // "IMovementModel"
            inline constexpr std::uintptr_t crouchModel = 0x30; // "CharacterCrouchModel"
            inline constexpr std::uintptr_t aimingFollow = 0x38; // "CinemachineAimingCameraFollow"
            inline constexpr std::uintptr_t aimModeModel = 0x40; // "IPrimitiveModel<AimModeDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC72550; // "public void Update()"
        }
    } // namespace OpticsWeaponWorldPositionUpdater

    namespace PlayerAimModeUpdater { // "Game.Battle.EntityModel.Player.Weapon.PlayerAimModeUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleEntitiesModel = 0x10; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t battleInputModel = 0x18; // "BattleInputModel"
            inline constexpr std::uintptr_t aimModeInputModel = 0x20; // "InputModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC72DA0; // "public void Update()"
        }
    } // namespace PlayerAimModeUpdater

    namespace PlayerAimNotificationUpdater { // "Game.Battle.EntityModel.Player.PlayerAimNotificationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t selectedQuickSlot = 0x10; // "SelectedQuickSlotModel"
            inline constexpr std::uintptr_t equipAmmo = 0x18; // "IEquipAmmoModel"
            inline constexpr std::uintptr_t equipSlots = 0x20; // "IEquipSlotsModel"
            inline constexpr std::uintptr_t quickSlotSelectProgress = 0x28; // "QuickSlotSelectProgressModel"
            inline constexpr std::uintptr_t groupsInventoryItemsModel = 0x30; // "GroupsInventoryItemsModel"
            inline constexpr std::uintptr_t selectedItemModel = 0x38; // "SelectedItemModel"
            inline constexpr std::uintptr_t health = 0x40; // "HealthModel"
            inline constexpr std::uintptr_t pocketsModel = 0x48; // "IPocketsModel"
            inline constexpr std::uintptr_t personalNotificationModel = 0x50; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t notificationKeys = 0x58; // "NotificationKeys"
            inline constexpr std::uintptr_t aimNotification = 0x60; // "PlayerAimNotificationUpdater.AimNotification"
            inline constexpr std::uintptr_t selectedSlot = 0x68; // "QuickSlotDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC48420; // "public void Update()"
            inline constexpr std::uintptr_t GetAimNotification = 0xC47E50; // "private PlayerAimNotificationUpdater.AimNotification GetAimNotification()"
        }
    } // namespace PlayerAimNotificationUpdater

    namespace PlayerAimPointerUpdater { // "Game.Battle.EntityModel.Player.PlayerAimPointerUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t stateModel = 0x10; // "IBattleCharacterStateModel"
            inline constexpr std::uintptr_t view = 0x18; // "AimPointerView"
            inline constexpr std::uintptr_t selectedQuickSlot = 0x20; // "SelectedQuickSlotModel"
            inline constexpr std::uintptr_t quickSlotSelectProgress = 0x28; // "QuickSlotSelectProgressModel"
            inline constexpr std::uintptr_t weaponViewDescriptions = 0x30; // "WeaponViewDescriptions"
            inline constexpr std::uintptr_t playerClientModel = 0x38; // "PlayerClientModel"
            inline constexpr std::uintptr_t equipSlots = 0x40; // "IEquipSlotsModel"
            inline constexpr std::uintptr_t aimTargetModel = 0x48; // "AimTargetModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x50; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t partyModel = 0x58; // "PartyModel"
            inline constexpr std::uintptr_t clanModel = 0x60; // "ClanModel"
            inline constexpr std::uintptr_t battleRoomModel = 0x68; // "RegionUserBattleRoomModel"
            inline constexpr std::uintptr_t prolongedActionProcessModel = 0x70; // "ProlongedActionProcessModel"
            inline constexpr std::uintptr_t sprint = 0x78; // "SprintModel"
            inline constexpr std::uintptr_t weaponReloadModel = 0x80; // "WeaponReloadModel"
            inline constexpr std::uintptr_t arrestTargetModel = 0x88; // "ArrestTargetModel"
            inline constexpr std::uintptr_t blindedStateModel = 0x90; // "BlindedStateModel"
            inline constexpr std::uintptr_t emotionModel = 0x98; // "EmotionModel"
            inline constexpr std::uintptr_t clanBattleTeamsCacheModel = 0xA0; // "ClanBattleTeamsCacheModel"
            inline constexpr std::uintptr_t characterSlotsModel = 0xA8; // "ClientCharacterSlotsModel"
            inline constexpr std::uintptr_t aimModeModel = 0xB0; // "IPrimitiveModel<AimModeDescription>"
            inline constexpr std::uintptr_t checker = 0xB8; // "ScreenOpenChecker"
            inline constexpr std::uintptr_t inBattleSettingsModel = 0xC0; // "InBattleSettingsModel"
            inline constexpr std::uintptr_t characterAimingModel = 0xC8; // "CharacterAimingModel"
            inline constexpr std::uintptr_t playerFakeSpreadModel = 0xD0; // "PlayerFakeSpreadModel"
            inline constexpr std::uintptr_t introCinematicModel = 0xD8; // "IntroCinematicModel"
            inline constexpr std::uintptr_t aimType = 0xE0; // "AimType"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC48C90; // "public void Update()"
            inline constexpr std::uintptr_t GetSelectedWeapon = 0xC489B0; // "private WeaponDescription GetSelectedWeapon()"
            inline constexpr std::uintptr_t SetDispersion = 0xC48AE0; // "private void SetDispersion(float aim, WeaponSpreadViewDescription spreadDescription)"
            inline constexpr std::uintptr_t GetAimTargetDangerousLevel = 0xC48600; // "private AimTargetModel.DangerousLevel GetAimTargetDangerousLevel()"
        }
    } // namespace PlayerAimPointerUpdater

    namespace PlayerArmorBarUpdater { // "Game.Battle.EntityModel.Player.PlayerArmorBarUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t now = 0x10; // "INow"
            inline constexpr std::uintptr_t healthBarView = 0x18; // "SegmentedHealthBarView"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x20; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t oldArmorSegments = 0x28; // "int"
            inline constexpr std::uintptr_t oldArmorAmount = 0x2C; // "int"
            inline constexpr std::uintptr_t isInited = 0x30; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC49930; // "public void Update()"
        }
    } // namespace PlayerArmorBarUpdater

    namespace PlayerCameraShotAnimationUpdater { // "Game.Battle.Entities.Player.Shoot.Updaters.PlayerCameraShotAnimationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t fireModel = 0x10; // "CharacterFireModel"
            inline constexpr std::uintptr_t aimingModel = 0x18; // "CharacterAimingModel"
            inline constexpr std::uintptr_t cameraAnimation = 0x20; // "AnimationIKView"
            inline constexpr std::uintptr_t selectedWeaponModel = 0x28; // "SelectedWeaponModel"
            inline constexpr std::uintptr_t aimModeModel = 0x30; // "IPrimitiveModel<AimModeDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB1F580; // "public void Update()"
        }
    } // namespace PlayerCameraShotAnimationUpdater

    namespace PlayerDamageToCharacterPopupUpdater { // "Game.Battle.EntityModel.Player.Shoot.PlayerDamageToCharacterPopupUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleCharacterModels = 0x10; // "ReadOnly.Dictionary<int, BattleCharacterModel>"
            inline constexpr std::uintptr_t damageModel = 0x18; // "DamageModel"
            inline constexpr std::uintptr_t time = 0x20; // "TimeModel"
            inline constexpr std::uintptr_t predictHitsModel = 0x28; // "PredictHitsModel"
            inline constexpr std::uintptr_t popupDamageModel = 0x30; // "PopupDamageModel"
            inline constexpr std::uintptr_t cameraModel = 0x38; // "BattleCameraModel"
            inline constexpr std::uintptr_t lastTickIndex = 0x40; // "long"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC73100; // "public void Update()"
            inline constexpr std::uintptr_t AddPopup = 0xC72F70; // "private void AddPopup(BattleCharacterModel model, in Vector3 position, bool isBadPrediction, int damage, bool isHead, bool isArmor)"
        }
    } // namespace PlayerDamageToCharacterPopupUpdater

    namespace PlayerFireModelUpdater { // "Game.Battle.Entities.BattleCharacter.Shoot.PlayerFireModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t timeModel = 0x10; // "TimeModel"
            inline constexpr std::uintptr_t shotIntentionModel = 0x18; // "ShotIntentionModel"
            inline constexpr std::uintptr_t serverModel = 0x20; // "BattleCharacterModel"
            inline constexpr std::uintptr_t clientModel = 0x28; // "PlayerClientModel"
            inline constexpr std::uintptr_t isClientFiring = 0x30; // "bool"
            inline constexpr std::uintptr_t isServerFiring = 0x31; // "bool"
            inline constexpr std::uintptr_t isPredictivelyStopped = 0x32; // "bool"
            inline constexpr std::uintptr_t startFiringTs = 0x38; // "long"
            inline constexpr std::uintptr_t currentShotIndexEndTs = 0x40; // "long"
            inline constexpr std::uintptr_t predictivelyStoppedShotEndTs = 0x48; // "long"
            inline constexpr std::uintptr_t shotIndex = 0x50; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xBE6D30; // "public void Update()"
            inline constexpr std::uintptr_t UpdateFiringStates = 0xBE6B60; // "private void UpdateFiringStates()"
            inline constexpr std::uintptr_t PredictFiringStop = 0xBE6850; // "private void PredictFiringStop()"
            inline constexpr std::uintptr_t SetStopPrediction = 0xBE6950; // "private void SetStopPrediction(bool isStopped, long shotEndTs)"
            inline constexpr std::uintptr_t UpdateClientFireModel = 0xBE6960; // "private void UpdateClientFireModel()"
        }
    } // namespace PlayerFireModelUpdater

    namespace PlayerForceKnockoutEndModel { // "Game.Battle.Knockout.PlayerForceKnockoutEndModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Progress = 0x10; // "float"
        }
    } // namespace PlayerForceKnockoutEndModel

    namespace PlayerHealthVignetteUpdater { // "Game.Battle.EntityModel.Player.PlayerHealthVignetteUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t health = 0x10; // "HealthModel"
            inline constexpr std::uintptr_t vignetteView = 0x18; // "VignetteBloodView"
            inline constexpr std::uintptr_t oldHp = 0x20; // "int"
            inline constexpr std::uintptr_t isDeath = 0x24; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC79840; // "public void Update()"
        }
    } // namespace PlayerHealthVignetteUpdater

    namespace PlayerInflictDamageModelUpdater { // "Game.Battle.Entities.Player.Shoot.Updaters.PlayerInflictDamageModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t damageModel = 0x10; // "DamageModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x18; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t lastIndex = 0x20; // "long"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB20FE0; // "public void Update()"
        }
    } // namespace PlayerInflictDamageModelUpdater

    namespace PlayerPredictMeleeHitUpdater { // "Game.Battle.Entities.BattleCharacter.MeleeAttack.PlayerPredictMeleeHitUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsSceneModel = 0x10; // "PhysicsSceneModel"
            inline constexpr std::uintptr_t hitBoxesModel = 0x18; // "HitBoxesModel"
            inline constexpr std::uintptr_t raycastModel = 0x20; // "RaycastModel"
            inline constexpr std::uintptr_t sphereCastModel = 0x28; // "SphereCastModel"
            inline constexpr std::uintptr_t meleeAttack = 0x30; // "MeleeAttackModel"
            inline constexpr std::uintptr_t immuneModel = 0x38; // "ClientImmunePopupModel"
            inline constexpr std::uintptr_t predictHits = 0x40; // "PredictHitsModel"
            inline constexpr std::uintptr_t movement = 0x48; // "IMovementModel"
            inline constexpr std::uintptr_t rotation = 0x50; // "CharacterRotationModel"
            inline constexpr std::uintptr_t time = 0x58; // "TimeModel"
            inline constexpr std::uintptr_t now = 0x60; // "INow"
            inline constexpr std::uintptr_t crouch = 0x68; // "CharacterCrouchModel"
            inline constexpr std::uintptr_t bodyId = 0x70; // "PhysicsBodyId"
            inline constexpr std::uintptr_t bodies = 0x78; // "PhysicsBodiesModel"
            inline constexpr std::uintptr_t lastTs = 0x80; // "long"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xBF3770; // "public void Update()"
            inline constexpr std::uintptr_t DrawDebugMeleeAttack = 0xBF3240; // "private void DrawDebugMeleeAttack(in Vector3 castFrom, in Vector3 castDirection, float castLength, float castRadius, in Vector3 target, RaycastResult raycastResult)"
        }
    } // namespace PlayerPredictMeleeHitUpdater

    namespace PlayerReceiveDamageUpdater { // "Game.Battle.EntityModel.Player.PlayerReceiveDamageUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t roleModel = 0x10; // "IPrimitiveModel<PlayerRoleDescription>"
            inline constexpr std::uintptr_t stateModel = 0x18; // "IBattleCharacterStateModel"
            inline constexpr std::uintptr_t receivedDamageModel = 0x20; // "ReceivedDamageModel"
            inline constexpr std::uintptr_t time = 0x28; // "TimeModel"
            inline constexpr std::uintptr_t soundEmitter = 0x30; // "GameObject"
            inline constexpr std::uintptr_t battleCharacterViewDescription = 0x38; // "BattleCharacterViewDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC7A140; // "public void Update()"
        }
    } // namespace PlayerReceiveDamageUpdater

    namespace PlayerShotsModel { // "Game.Battle.EntityModel.Player.PlayerShotsModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Items = 0x10; // "Queue<ValueTuple<ShotArgs, ShotResult[], WeaponDescription, int>>"
        }
    } // namespace PlayerShotsModel

    namespace PlayerShotsModelUpdater { // "Game.Battle.EntityModel.Player.PlayerShotsModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t immuneModel = 0x10; // "ClientImmunePopupModel"
            inline constexpr std::uintptr_t clientModel = 0x18; // "PlayerClientModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x20; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t locationHitsModel = 0x28; // "LocationHitsModel"
            inline constexpr std::uintptr_t timeModel = 0x30; // "TimeModel"
            inline constexpr std::uintptr_t physicsSceneModel = 0x38; // "PhysicsSceneModel"
            inline constexpr std::uintptr_t fireModel = 0x40; // "FireModel"
            inline constexpr std::uintptr_t waterZonesModel = 0x48; // "WorldWaterZonesClientModel"
            inline constexpr std::uintptr_t wasFiring = 0x50; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC7AC70; // "public void Update()"
            inline constexpr std::uintptr_t IsPointUnderWater = 0xC7AB30; // "private bool IsPointUnderWater(in Vector3 point)"
        }
    } // namespace PlayerShotsModelUpdater

    namespace PlayerShotsUpdater { // "Game.Battle.EntityModel.Player.PlayerShotsUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t clientModel = 0x10; // "PlayerClientModel"
            inline constexpr std::uintptr_t shotResultModel = 0x18; // "ShotResultModel"
            inline constexpr std::uintptr_t shotArgsModel = 0x20; // "ShotArgsModel"
            inline constexpr std::uintptr_t fireModel = 0x28; // "FireModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x30; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t timeModel = 0x38; // "TimeModel"
            inline constexpr std::uintptr_t id = 0x40; // "int"
            inline constexpr std::uintptr_t lastShotTickIndex = 0x48; // "long"
            inline constexpr std::uintptr_t lastShotTs = 0x50; // "long"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC7B950; // "public void Update()"
        }
    } // namespace PlayerShotsUpdater

    namespace PlayerSurrenderArrestModel { // "Game.Battle.Arrest.Models.PlayerSurrenderArrestModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t SurrenderProgress = 0x10; // "float"
        }
    } // namespace PlayerSurrenderArrestModel

    namespace PlayerWeaponCameraUpdater { // "Game.Battle.EntityModel.Player.Weapon.PlayerWeaponCameraUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t armedAimingCameraFollow = 0x10; // "CinemachineAimingCameraFollow"
            inline constexpr std::uintptr_t armedCamera = 0x18; // "CinemachineVirtualCamera"
            inline constexpr std::uintptr_t weapon = 0x20; // "IWeaponModel"
            inline constexpr std::uintptr_t aimStateModel = 0x28; // "AimStateModel"
            inline constexpr std::uintptr_t viewDescriptions = 0x30; // "WeaponViewDescriptions"
            inline constexpr std::uintptr_t crouchModel = 0x38; // "CharacterCrouchModel"
            inline constexpr std::uintptr_t playerCameraModel = 0x40; // "PlayerCameraModel"
            inline constexpr std::uintptr_t aiming = 0x48; // "AimingModel"
            inline constexpr std::uintptr_t playerCameraViewDescriptions = 0x50; // "PlayerCameraViewDescriptions"
            inline constexpr std::uintptr_t aimModeModel = 0x58; // "IPrimitiveModel<AimModeDescription>"
            inline constexpr std::uintptr_t isLeftShoulderView = 0x60; // "IPrimitiveModel<bool>"
            inline constexpr std::uintptr_t oldWeapon = 0x68; // "WeaponDescription"
            inline constexpr std::uintptr_t maxStep = 0x70; // "float"
            inline constexpr std::uintptr_t isAimed = 0x74; // "bool"
            inline constexpr std::uintptr_t usesOptics = 0x75; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xC7D0E0; // "public void Update()"
            inline constexpr std::uintptr_t SetupAimedCamera = 0xC7D020; // "private void SetupAimedCamera(WeaponDescription weapon)"
            inline constexpr std::uintptr_t GetUsesOptics = 0xC7CEF0; // "private bool GetUsesOptics()"
        }
    } // namespace PlayerWeaponCameraUpdater

    namespace PopupDamageModel { // "Game.Battle.Entities.Player.Models.PopupDamageModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t addedPopups = 0x10; // "Stack<int>"
            inline constexpr std::uintptr_t removedPopups = 0x18; // "List<int>"
            inline constexpr std::uintptr_t activePopups = 0x20; // "Queue<int>"
            inline constexpr std::uintptr_t freePopups = 0x28; // "Stack<int>"
            inline constexpr std::uintptr_t popups = 0x30; // "PopupData[]"
            inline constexpr std::uintptr_t Added = 0x38; // "StackEnumeratorNonAlloc<int>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t RemoveFirstActive = 0xB21450; // "public void RemoveFirstActive()"
            inline constexpr std::uintptr_t TryAdd = 0xB21540; // "public bool TryAdd(out int index)"
            inline constexpr std::uintptr_t MoveAddedToActive = 0xB213B0; // "public void MoveAddedToActive()"
            inline constexpr std::uintptr_t TryGetFirstActive = 0xB215E0; // "public bool TryGetFirstActive(out int index)"
            inline constexpr std::uintptr_t Get = 0xB21370; // "public ref PopupData Get(int index)"
            inline constexpr std::uintptr_t GetRemovedFromIndex = 0xB21310; // "public int GetRemovedFromIndex(int index)"
            inline constexpr std::uintptr_t get_RemovedCount = 0xB21840; // "public int get_RemovedCount()"
            inline constexpr std::uintptr_t Clear = 0xB212A0; // "public void Clear()"
        }
    } // namespace PopupDamageModel

    namespace PredictKnockdownSystem { // "Models.Systems.PredictKnockdownSystem (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x4104140; // "protected override void Tick(ITick tick)"
        }
    } // namespace PredictKnockdownSystem

    namespace PredictShotSystem { // "Models.Systems.PredictShotSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t sceneModel = 0x38; // "PhysicsSceneModel"
            inline constexpr std::uintptr_t hitBoxesModel = 0x40; // "HitBoxesModel"
            inline constexpr std::uintptr_t lastSimulatedTickModel = 0x48; // "LastSimulatedTickModel"
            inline constexpr std::uintptr_t raycastModel = 0x50; // "RaycastModel"
            inline constexpr std::uintptr_t interpolatedHitBoxes = 0x58; // "IInterpolatedHitBoxes"
            inline constexpr std::uintptr_t raycastResult = 0x60; // "RaycastResult"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x4104C10; // "protected override void Tick(ITick tick)"
            inline constexpr std::uintptr_t GetHitBoxesData = 0x4104AD0; // "private HitBoxesData GetHitBoxesData(long simulatedTickIndex, long shotSimulatedTimeOffset, long tickPeriod)"
        }
    } // namespace PredictShotSystem

    namespace PredictSurrenderSystem { // "Models.Systems.PredictSurrenderSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dropCargoModel = 0x38; // "IDropCargoModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x4105900; // "protected override void Tick(ITick tick)"
        }
    } // namespace PredictSurrenderSystem

    namespace PredictThrowGrenadeSystem { // "Models.Systems.PredictThrowGrenadeSystem (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x4105BB0; // "protected override void Tick(ITick tick)"
        }
    } // namespace PredictThrowGrenadeSystem

    namespace PrepareHitBoxIdSystem { // "Models.Systems.PrepareHitBoxIdSystem (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x4105EE0; // "protected override void Tick(ITick tick)"
        }
    } // namespace PrepareHitBoxIdSystem

    namespace ReceiveDamageModelUpdater { // "Game.Battle.Entities.Player.Updaters.ReceiveDamageModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t health = 0x10; // "HealthModel"
            inline constexpr std::uintptr_t receivedDamageModel = 0x18; // "ReceivedDamageModel"
            inline constexpr std::uintptr_t disconnectInfoModel = 0x20; // "DisconnectInfoModel"
            inline constexpr std::uintptr_t time = 0x28; // "TimeModel"
            inline constexpr std::uintptr_t armor = 0x30; // "ArmorModel"
            inline constexpr std::uintptr_t hitsModel = 0x38; // "HitsModel"
            inline constexpr std::uintptr_t nonLethalHitTs = 0x40; // "IPrimitiveData<long>"
            inline constexpr std::uintptr_t knockout = 0x48; // "KnockoutModel"
            inline constexpr std::uintptr_t immuneModel = 0x50; // "CharacterImmuneStateModel"
            inline constexpr std::uintptr_t oldHealth = 0x58; // "int"
            inline constexpr std::uintptr_t oldArmor = 0x5C; // "int"
            inline constexpr std::uintptr_t lastTs = 0x60; // "long"
            inline constexpr std::uintptr_t lastNonLethalHitTs = 0x68; // "long"
            inline constexpr std::uintptr_t isKnockout = 0x70; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB21BF0; // "public void Update()"
        }
    } // namespace ReceiveDamageModelUpdater

    namespace ReceivedDamageModel { // "Game.Battle.EntityModel.Player.ReceivedDamageModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Ticks = 0x10; // "Queue<ValueTuple<long, DamageType, DamageSource>>"
            inline constexpr std::uintptr_t LastUsedTick = 0x18; // "long"
        }
    } // namespace ReceivedDamageModel

    namespace RecoilAnimationData { // "Game.Battle.EntityModel.BattleCharacter.Weapon.RecoilAnimationData (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Amplitude = 0x10; // "float"
            inline constexpr std::uintptr_t Force = 0x14; // "float"
            inline constexpr std::uintptr_t Give = 0x18; // "float"
        }
    } // namespace RecoilAnimationData

    namespace RecoilDebugModel { // "Game.Battle.EntityModel.Player.Debug.RecoilDebugModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ShotKick = 0x10; // "Vector2"
            inline constexpr std::uintptr_t Accumulated = 0x18; // "Vector2"
            inline constexpr std::uintptr_t ShotIndex = 0x20; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetShot = 0xC982C0; // "public void SetShot(Vector2 shotKick, int shotIndex)"
            inline constexpr std::uintptr_t SetSeries = 0xC982B0; // "public void SetSeries(Vector2 accumulated, bool isSeriesActive)"
        }
    } // namespace RecoilDebugModel

    namespace RecoilModel { // "Game.Battle.Entities.Player.Recoil.RecoilModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t RecoilOffset = 0x10; // "Vector2"
        }
    } // namespace RecoilModel

    namespace RestoreHealthModel { // "Models.Models.RestoreHealth.RestoreHealthModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Ts = 0x10; // "long"
        }
    } // namespace RestoreHealthModel

    namespace RevivalModel { // "Models.Models.Revival.RevivalModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t revivalEndTsByReviveInitiator = 0x10; // "Dictionary<int, long>"
            inline constexpr std::uintptr_t reviveInitiators = 0x18; // "ILinkedQueue<int>"
            inline constexpr std::uintptr_t reviveEndTs = 0x20; // "IPrimitiveData<long>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_ReviveEndTs = 0x48E45B0; // "public long get_ReviveEndTs()"
            inline constexpr std::uintptr_t get_IsActive = 0x48E4530; // "public bool get_IsActive()"
            inline constexpr std::uintptr_t Start = 0x48E4340; // "public void Start(int reviveInitiator, long endTs)"
            inline constexpr std::uintptr_t Finish = 0x48E40B0; // "public void Finish(int reviveInitiator)"
            inline constexpr std::uintptr_t Interrupt = 0x48E4190; // "public void Interrupt(int reviveInitiator)"
        }
    } // namespace RevivalModel

    namespace ReviveCharacterModel { // "Models.Models.ProlongedInteractionHandler.Handlers.ReviveCharacterModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleCharacters = 0x10; // "ReadOnly.Dictionary<int, BattleCharacterModel>"
            inline constexpr std::uintptr_t worldEntitiesModel = 0x18; // "WorldEntitiesModel"
            inline constexpr std::uintptr_t interactRaycastModel = 0x20; // "InteractRaycastModel"
            inline constexpr std::uintptr_t worldInterruptModel = 0x28; // "IWorldInterruptModel"
            inline constexpr std::uintptr_t clanBattleCharacterTeamModel = 0x30; // "IClanBattleCharacterTeamModel"
            inline constexpr std::uintptr_t battleMode = 0x38; // "BattleModeDescription"
            inline constexpr std::uintptr_t predictionExtraTimeModel = 0x40; // "PredictionExtraTimeModel"
            inline constexpr std::uintptr_t isServer = 0x48; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Process = 0x4903B90; // "public override MutuallyExclusiveProcessesDescription get_Process()"
            inline constexpr std::uintptr_t get_StartCommand = 0x4903C20; // "internal override UseEntityCommandDescription get_StartCommand()"
            inline constexpr std::uintptr_t get_StopCommand = 0x4903CB0; // "internal override UseEntityCommandDescription get_StopCommand()"
            inline constexpr std::uintptr_t CheckInteractionStart = 0x49032D0; // "public override bool CheckInteractionStart(UseEntityCommandDescription command, int useEntityId, PlayerRoleDescription playerRole)"
            inline constexpr std::uintptr_t HandelRequest = 0x4903380; // "public override void HandelRequest(long now, int entityId, ProlongedInteractionInputDescription prolongedInteractionInput, BattleCharacterModel characterModel)"
            inline constexpr std::uintptr_t TryFinishPrediction = 0x4903870; // "public override bool TryFinishPrediction(long now, BattleCharacterModel characterModel)"
            inline constexpr std::uintptr_t TryGetTargetPosition = 0x4903A00; // "public override bool TryGetTargetPosition(int entityId, out Vector3 position)"
            inline constexpr std::uintptr_t CheckClanBattleTeammate = 0x4903130; // "private bool CheckClanBattleTeammate(int targetId, int id)"
        }
    } // namespace ReviveCharacterModel

    namespace ReviveCharacterProlongedAction { // "Game.Battle.Entities.Player.ProlongedActions.ReviveCharacterProlongedAction (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t model = 0x10; // "ProlongedInteractionModel"
            inline constexpr std::uintptr_t entityId = 0x18; // "int"
            inline constexpr std::uintptr_t Label = 0x20; // "LocalizedString"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsActive = 0xB22DF0; // "public bool get_IsActive()"
            inline constexpr std::uintptr_t get_EndTs = 0xB19D10; // "public long get_EndTs()"
            inline constexpr std::uintptr_t get_Duration = 0xB228D0; // "public long get_Duration()"
            inline constexpr std::uintptr_t get_UsePredictExtraTime = 0x7D5050; // "public bool get_UsePredictExtraTime()"
            inline constexpr std::uintptr_t get_IsShowAim = 0x7D5050; // "public bool get_IsShowAim()"
            inline constexpr std::uintptr_t Interrupt = 0xB22D30; // "public void Interrupt(BattleInputModel battleInputModel)"
            inline constexpr std::uintptr_t UpdateInterruptData = 0xB19E00; // "public void UpdateInterruptData()"
        }
    } // namespace ReviveCharacterProlongedAction

    namespace ReviveWithCopPresetCommand { // "Game.Shared.ReviveWithCopPresetCommand (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t CopPreset = 0x10; // "CopPresetDescription"
        }
    } // namespace ReviveWithCopPresetCommand

    namespace RevivingAnimationExtensions { // "Models.Utils.Extensions.Animations.RevivingAnimationExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t IsRevivingAnimationProcess = 0x3C9C870; // "public static bool IsRevivingAnimationProcess(ProlongedInteractionModel prolongedInteractionModel)"
        }
    } // namespace RevivingAnimationExtensions

    namespace ScrollWeaponAndItemsInputUpdater { // "Game.Battle.Inputs.Updaters.Keyboard.ScrollWeaponAndItemsInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t quickSlotsList = 0x10; // "List<ValueTuple<QuickSlotDescription, InputModel>>"
            inline constexpr std::uintptr_t actionsPrevItem = 0x18; // "InputAction"
            inline constexpr std::uintptr_t actionsNextItem = 0x20; // "InputAction"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x28; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t preferredTargetModel = 0x30; // "PreferredTargetModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA982D0; // "public void Update()"
            inline constexpr std::uintptr_t ScrollInput = 0xA98150; // "private void ScrollInput(int direction, QuickSlotsModel quickSlotsModel, QuickSlotDescription selectedSlot)"
        }
    } // namespace ScrollWeaponAndItemsInputUpdater

    namespace SelectedItemModel { // "Game.Battle.EntityModel.Player.Weapon.SelectedItemModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t SelectedItem = 0x10; // "InventoryItemDescription"
            inline constexpr std::uintptr_t Progress = 0x18; // "float"
            inline constexpr std::uintptr_t TakeTime = 0x20; // "long"
            inline constexpr std::uintptr_t TakingState = 0x28; // "SelectedItemModel.State"
        }
    } // namespace SelectedItemModel

    namespace SelectedWeaponInCharacterHandsUpdater { // "Game.Battle.Entities.BattleCharacter.Weapon.SelectedWeaponInCharacterHandsUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t entityView = 0x10; // "BattleCharacterEntityView"
            inline constexpr std::uintptr_t weaponView = 0x18; // "CharacterWeaponView"
            inline constexpr std::uintptr_t weaponViewDescription = 0x20; // "WeaponViewDescription"
            inline constexpr std::uintptr_t serverModel = 0x28; // "BattleCharacterModel"
            inline constexpr std::uintptr_t clientModel = 0x30; // "CharacterClientModel"
            inline constexpr std::uintptr_t battleScreenView = 0x38; // "BattleScreenView"
            inline constexpr std::uintptr_t canShowWeapon = 0x40; // "bool"
            inline constexpr std::uintptr_t areLimbsEnabled = 0x41; // "bool"
            inline constexpr std::uintptr_t aimingWeight = 0x44; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xBD0930; // "public void Update()"
            inline constexpr std::uintptr_t SetupCharacterWithWeapon = 0xBD0330; // "private void SetupCharacterWithWeapon()"
            inline constexpr std::uintptr_t UpdateAimingPose = 0xBD0760; // "private void UpdateAimingPose()"
            inline constexpr std::uintptr_t ApplyAimingWeight = 0xBCFE90; // "private void ApplyAimingWeight()"
            inline constexpr std::uintptr_t GetIKSet = 0xBD01C0; // "private SexIKSet GetIKSet()"
            inline constexpr std::uintptr_t DiscardCharacterWithWeapon = 0xBCFFB0; // "private void DiscardCharacterWithWeapon()"
            inline constexpr std::uintptr_t EnableArmedPoseComponents = 0xBD0110; // "private void EnableArmedPoseComponents(bool isArmedPoseEnabled)"
        }
    } // namespace SelectedWeaponInCharacterHandsUpdater

    namespace SelectedWeaponModel { // "Game.Battle.Entities.BattleCharacter.Weapon.Models.SelectedWeaponModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t WeaponViewDescription = 0x10; // "WeaponViewDescription"
            inline constexpr std::uintptr_t MuzzleFlashVFX = 0x18; // "ParticleSystem"
            inline constexpr std::uintptr_t MuzzleSparkVFX = 0x20; // "ParticleSystem"
            inline constexpr std::uintptr_t DropShell = 0x28; // "IDisposableContent<ParticleSystem>"
            inline constexpr std::uintptr_t ShotSmoke = 0x30; // "ParticleSystem"
            inline constexpr std::uintptr_t IsDisposed = 0x38; // "bool"
            inline constexpr std::uintptr_t CharacterWeaponView = 0x40; // "CharacterWeaponView"
            inline constexpr std::uintptr_t CharacterWeaponFirstPersonOpticsView = 0x48; // "CharacterWeaponView"
            inline constexpr std::uintptr_t PlayIdle = 0x50; // "bool"
            inline constexpr std::uintptr_t BattleCharacterBurstingModel = 0x58; // "BattleCharacterBurstingModel"
            inline constexpr std::uintptr_t ShotAnimations = 0x60; // "ShuffleContainer<AnimationIKClip>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Clear = 0xBD0B40; // "public void Clear()"
            inline constexpr std::uintptr_t get_HasSelectedWeapon = 0xA18FC0; // "public bool get_HasSelectedWeapon()"
        }
    } // namespace SelectedWeaponModel

    namespace SelectedWeaponVisibilityUpdater { // "Game.Battle.Entities.BattleCharacter.Weapon.SelectedWeaponVisibilityUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t weaponView = 0x10; // "CharacterWeaponView"
            inline constexpr std::uintptr_t serverModel = 0x18; // "BattleCharacterModel"
            inline constexpr std::uintptr_t animationStateAssistant = 0x20; // "AnimationStateAssistant"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xBD0C50; // "public void Update()"
        }
    } // namespace SelectedWeaponVisibilityUpdater

    namespace SetWeaponSkinMessage { // "Models.Messages.SetWeaponSkinMessage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t weaponSkin = 0x20; // "IPrimitiveData<WeaponSkinDescription>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_WeaponSkin = 0x4A0FCB0; // "public WeaponSkinDescription get_WeaponSkin()"
            inline constexpr std::uintptr_t get_Type = 0x4A0FC80; // "public override string get_Type()"
        }
    } // namespace SetWeaponSkinMessage

    namespace SexIKSet { // "Game.Battle.Equipment.Weapon.SexIKSet (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t shotAnimations = 0x0; // "AnimationIKClip[]"
            inline constexpr std::uintptr_t BurstStartShotAnimation = 0x8; // "AnimationIKClip"
            inline constexpr std::uintptr_t ArmedPose = 0x10; // "PoseIK"
            inline constexpr std::uintptr_t AimingArmedPose = 0x18; // "PoseIK"
            inline constexpr std::uintptr_t LeftElbowPose = 0x20; // "PoseIK"
            inline constexpr std::uintptr_t AimingLeftElbowPose = 0x28; // "PoseIK"
            inline constexpr std::uintptr_t LeftWristPose = 0x30; // "PoseIK"
            inline constexpr std::uintptr_t AimingLeftWristPose = 0x38; // "PoseIK"
            inline constexpr std::uintptr_t RightWristPose = 0x40; // "PoseIK"
            inline constexpr std::uintptr_t AimingRightWristPose = 0x48; // "PoseIK"
            inline constexpr std::uintptr_t ForearmTwist = 0x50; // "ForearmTwistSettings"
            inline constexpr std::uintptr_t ShotAnimations = 0x68; // "ShuffleContainer<AnimationIKClip>"
        }
    } // namespace SexIKSet

    namespace SexSkeletonAnimationState { // "Models.HitBox.SkeletonAnimationState.SexSkeletonAnimationState (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t states = 0x10; // "Dictionary<CharacterSexDescription, ISkeletonAnimationState>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Calculate = 0x4A62C60; // "public void Calculate(SkeletonAnimationModel skeletonAnimationModel, out BlendTreeDescription blendTree)"
        }
    } // namespace SexSkeletonAnimationState

    namespace ShotArgs { // "Game.Battle.EntityModel.Player.ShotArgs (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Ts = 0x0; // "long"
            inline constexpr std::uintptr_t Position = 0x8; // "Vector3"
            inline constexpr std::uintptr_t LookDirection = 0x14; // "Vector3"
        }
    } // namespace ShotArgs

    namespace ShotArgsModel { // "Models.Models.ShotArgs.ShotArgsModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t position = 0x10; // "IPrimitiveData<Vector3>"
            inline constexpr std::uintptr_t direction = 0x18; // "IPrimitiveData<Vector3>"
            inline constexpr std::uintptr_t weapon = 0x20; // "IPrimitiveData<WeaponDescription>"
            inline constexpr std::uintptr_t ShotStartOffsetFromCamera = 0x28; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Position = 0x48EA8F0; // "public Vector3 get_Position()"
            inline constexpr std::uintptr_t get_Direction = 0x48EA820; // "public Vector3 get_Direction()"
            inline constexpr std::uintptr_t get_Weapon = 0x48EA9C0; // "public WeaponDescription get_Weapon()"
            inline constexpr std::uintptr_t Set = 0x48EA780; // "public void Set(in Vector3 position, in Vector3 direction, WeaponDescription weapon, float shotStartOffsetFromCamera)"
        }
    } // namespace ShotArgsModel

    namespace ShotArgsSystem { // "Models.Systems.ShotArgsSystem (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x823DE48; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace Fields {
            inline constexpr std::uintptr_t hitBoxesModel = 0x38; // "HitBoxesModel"
            inline constexpr std::uintptr_t physicsSnapshots = 0x40; // "SnapshotsModel<PhysicsData>"
            inline constexpr std::uintptr_t raycastModel = 0x48; // "RaycastModel"
            inline constexpr std::uintptr_t interpolatedHitBoxes = 0x50; // "IInterpolatedHitBoxes"
            inline constexpr std::uintptr_t physicsSceneModel = 0x58; // "PhysicsSceneModel"
            inline constexpr std::uintptr_t raycastResult = 0x60; // "RaycastResult"
            inline constexpr std::uintptr_t sphereCastModel = 0x68; // "SphereCastModel"
        }
        namespace StaticFields {
            inline constexpr std::uintptr_t eps = 0x0; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x4361B00; // "protected override void Tick(ITick tick)"
            inline constexpr std::uintptr_t GetHitBoxesData = 0x43614F0; // "private HitBoxesData GetHitBoxesData(long simulatedTickIndex, long shotSimulatedTimeOffset, long tickPeriod)"
            inline constexpr std::uintptr_t GetPhysicsData = 0x4361630; // "private PhysicsData GetPhysicsData(long tickIndex)"
            inline constexpr std::uintptr_t GetShotDirection = 0x43616C0; // "private Vector3 GetShotDirection(PhysicsData physicsData, HitBoxesData hitBoxesData, Vector3 lookDirection, Vector3 cameraPosition, Vector3 shotPosition, PhysicsBodyId bodyId, float range, float blockableRange, float shotStartOffsetFromCamera, out bool isMissCast)"
            inline constexpr std::uintptr_t ApplySpreadToShotDirection = 0x4361190; // "private Vector3 ApplySpreadToShotDirection(RandomModel random, Vector3 lookDirection, float spread, out float spreadX, out float spreadY, out Vector3 spreadBasisX, out Vector3 spreadBasisY)"
            inline constexpr std::uintptr_t SpreadDirection = 0x4361980; // "private void SpreadDirection(Vector3 spreadBasisZ, out Vector3 spreadBasisX, out Vector3 spreadBasisY)"
            inline constexpr std::uintptr_t RandomizeSpread = 0x4361940; // "private float RandomizeSpread(float maxSpread, RandomModel random)"
        }
    } // namespace ShotArgsSystem

    namespace ShotBlockedDebugModel { // "Game.Battle.EntityModel.Player.Debug.ShotBlockedDebugModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsCalculated = 0x10; // "bool"
            inline constexpr std::uintptr_t ShotPosition = 0x14; // "Vector3"
            inline constexpr std::uintptr_t CameraHitPosition = 0x20; // "Vector3"
            inline constexpr std::uintptr_t HasCameraHit = 0x2C; // "bool"
            inline constexpr std::uintptr_t CameraHitBodyId = 0x30; // "PhysicsBodyId"
            inline constexpr std::uintptr_t HasShotHit = 0x38; // "bool"
            inline constexpr std::uintptr_t ShotHitPosition = 0x3C; // "Vector3"
            inline constexpr std::uintptr_t ShotHitBodyId = 0x48; // "PhysicsBodyId"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Reset = 0xC992F0; // "public void Reset()"
            inline constexpr std::uintptr_t SetAim = 0xC99300; // "public void SetAim(Vector3 shotPosition, Vector3 cameraHitPosition, RaycastResult cameraRaycastResult)"
            inline constexpr std::uintptr_t SetShotHit = 0xC993C0; // "public void SetShotHit(Vector3 shotHitPosition, PhysicsBodyId shotHitBodyId)"
        }
    } // namespace ShotBlockedDebugModel

    namespace ShotBlockedModel { // "Game.Battle.EntityModel.Player.Shoot.ShotBlockedModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t BlockedPosition = 0x10; // "Vector3"
            inline constexpr std::uintptr_t IsBlocked = 0x1C; // "bool"
        }
    } // namespace ShotBlockedModel

    namespace ShotBlockedUpdater { // "Game.Battle.Entities.Player.Updaters.ShotBlockedUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t physicsSceneModel = 0x10; // "PhysicsSceneModel"
            inline constexpr std::uintptr_t hitBoxesModel = 0x18; // "HitBoxesModel"
            inline constexpr std::uintptr_t physicsBodiesModel = 0x20; // "PhysicsBodiesModel"
            inline constexpr std::uintptr_t shotBlockedModel = 0x28; // "ShotBlockedModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x30; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t playerRotationInput = 0x38; // "PlayerRotationInputModel"
            inline constexpr std::uintptr_t raycastModel = 0x40; // "RaycastModel"
            inline constexpr std::uintptr_t sphereCastModel = 0x48; // "SphereCastModel"
            inline constexpr std::uintptr_t now = 0x50; // "INow"
            inline constexpr std::uintptr_t raycastResult = 0x58; // "RaycastResult"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB23330; // "public void Update()"
            inline constexpr std::uintptr_t GetHitBoxesData = 0xB231B0; // "private HitBoxesData GetHitBoxesData()"
            inline constexpr std::uintptr_t CalculateShotPosition = 0xB23030; // "private static Vector3 CalculateShotPosition(Vector3 transformPosition, Quaternion rotation, CharacterCrouchModel crouchModel, IPrimitiveModel<AimModeDescription> aimModeModel, WeaponDescription weapon)"
            inline constexpr std::uintptr_t IsBlockingContact = 0xB23280; // "private bool IsBlockingContact(PhysicsBodyId bodyId)"
        }
    } // namespace ShotBlockedUpdater

    namespace ShotDebugInfo { // "Models.Models.ShotDebugInfoModel.ShotDebugInfo (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t TickIndex = 0x10; // "long"
            inline constexpr std::uintptr_t Position = 0x18; // "Vector3"
            inline constexpr std::uintptr_t LookDirection = 0x24; // "Vector3"
            inline constexpr std::uintptr_t Parts = 0x30; // "ShotPartDebugInfo[]"
            inline constexpr std::uintptr_t HitBoxShapesData = 0x38; // "HitBoxShapesData"
        }
    } // namespace ShotDebugInfo

    namespace ShotDebugInfoModel { // "Models.Models.ShotDebugInfoModel.ShotDebugInfoModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsEnabled = 0x10; // "bool"
            inline constexpr std::uintptr_t ShotDebugInfo = 0x18; // "ShotDebugInfo"
        }
    } // namespace ShotDebugInfoModel

    namespace ShotDebugInfoPair { // "Game.Battle.EntityModel.Player.Debug.ShotDebugInfoPair (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Server = 0x10; // "ShotDebugInfo"
            inline constexpr std::uintptr_t Client = 0x18; // "ShotDebugInfo"
            inline constexpr std::uintptr_t GameObjects = 0x20; // "GameObject[]"
        }
    } // namespace ShotDebugInfoPair

    namespace ShotEventData { // "Models.Models.ShotEvents.ShotEventData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Type = 0x0; // "ShotEventType"
            inline constexpr std::uintptr_t ShotOwnerEntityId = 0x4; // "int"
            inline constexpr std::uintptr_t ColliderBodyId = 0x8; // "PhysicsBodyId"
            inline constexpr std::uintptr_t SourcePosition = 0x10; // "Vector3"
            inline constexpr std::uintptr_t HitPosition = 0x1C; // "Vector3"
        }
    } // namespace ShotEventData

    namespace ShotEventsModel { // "Models.Models.ShotEvents.ShotEventsModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t eventsSet = 0x10; // "IEventsSet<ShotEventData>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Count = 0x48BA810; // "public int get_Count()"
            inline constexpr std::uintptr_t GetEvent = 0x48BA730; // "public ref ShotEventData GetEvent(int index)"
            inline constexpr std::uintptr_t Add = 0x48BA610; // "public void Add(ShotEventType type, int shotOwnerEntityId, PhysicsBodyId colliderBodyId, in Vector3 sourcePosition, in Vector3 hitPosition)"
            inline constexpr std::uintptr_t Clear = 0x48BA6E0; // "public void Clear()"
        }
    } // namespace ShotEventsModel

    namespace ShotExtensions { // "Models.Utils.Extensions.ShotExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t ValidateShotInputTimeOffset = 0x396D9A0; // "public static bool ValidateShotInputTimeOffset(long now, long tickPeriod, bool isFirstShotInQueue, long shotPlayerTimeOffset, long shotEndTs)"
            inline constexpr std::uintptr_t ValidateCharacterState = 0x396D850; // "public static bool ValidateCharacterState(SprintModel sprintModel, QuickSlotSelectProgressModel quickSlotSelectProgressModel, CharacterCargoModel cargoModel, BreakColliderModel breakColliderModel, MeleeAttackModel meleeAttackModel, BecomeRobberModel becomeRobberModel, ItemActionProcessModel itemActionProcessModel, CharacterValidationModel characterValidationModel, KnockoutModel knockoutModel, bool isWeaponBroken)"
            inline constexpr std::uintptr_t GetShotStartTs = 0x396D7B0; // "public static long GetShotStartTs(long shotEndTs, WeaponDescription weapon)"
            inline constexpr std::uintptr_t GetShotStartTs_2 = 0x396D7D0; // "public static long GetShotStartTs(FireModel fireModel, ShotArgsModel shotArgsModel)"
        }
    } // namespace ShotExtensions

    namespace ShotInputLockModel { // "Game.Battle.Inputs.ShotInputLockModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsShotInputTriggered = 0x10; // "bool"
            inline constexpr std::uintptr_t IsLockedBySprint = 0x11; // "bool"
            inline constexpr std::uintptr_t IsLockedByReloading = 0x12; // "bool"
            inline constexpr std::uintptr_t IsLockedByAimTransition = 0x13; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsLockActive = 0xA98AE0; // "public bool get_IsLockActive()"
            inline constexpr std::uintptr_t SprintLock = 0xA98AC0; // "public void SprintLock()"
            inline constexpr std::uintptr_t SprintUnlock = 0xA98AD0; // "public void SprintUnlock()"
            inline constexpr std::uintptr_t ReloadingLock = 0xA98AA0; // "public void ReloadingLock()"
            inline constexpr std::uintptr_t ReloadingUnlock = 0xA98AB0; // "public void ReloadingUnlock()"
            inline constexpr std::uintptr_t AimTransitionLock = 0xA98A80; // "public void AimTransitionLock()"
            inline constexpr std::uintptr_t AimTransitionUnlock = 0xA98A90; // "public void AimTransitionUnlock()"
        }
    } // namespace ShotInputLockModel

    namespace ShotInputRules { // "Game.Battle.Inputs.ShotInputRules (Battle.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t GetShotLookOffset = 0xA98B60; // "public static int GetShotLookOffset(TimeModel timeModel, Vector3 previousTickStartLookDirection, Vector3 currentLookDirection, Vector3 shotLookDirection)"
            inline constexpr std::uintptr_t GetShotSimulatedTimeOffset = 0xA98DB0; // "public static int GetShotSimulatedTimeOffset(TimeModel timeModel)"
            inline constexpr std::uintptr_t GetShotPlayerTimeOffset = 0xA98D10; // "public static int GetShotPlayerTimeOffset(TimeModel timeModel, long shotPlayerTs)"
        }
    } // namespace ShotInputRules

    namespace ShotInputUpdater { // "Game.Battle.Inputs.ShotInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleEntitiesModel = 0x10; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t updaters = 0x18; // "IStoppedUpdater[]"
            inline constexpr std::uintptr_t isStopped = 0x20; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA98E40; // "public void Update()"
        }
    } // namespace ShotInputUpdater

    namespace ShotIntentionModel { // "Game.Battle.Inputs.ShotIntentionModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsSet = 0x10; // "bool"
            inline constexpr std::uintptr_t Weapon = 0x18; // "WeaponDescription"
            inline constexpr std::uintptr_t IsFirstInQueue = 0x20; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Set = 0xA993F0; // "public void Set(WeaponDescription weapon, bool isFirstInQueue)"
            inline constexpr std::uintptr_t Unset = 0xA99430; // "public void Unset()"
        }
    } // namespace ShotIntentionModel

    namespace ShotIntentionUpdater { // "Game.Battle.Inputs.ShotIntentionUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleEntities = 0x10; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t timeModel = 0x18; // "TimeModel"
            inline constexpr std::uintptr_t shotInput = 0x20; // "InputModel"
            inline constexpr std::uintptr_t shotIntentionModel = 0x28; // "ShotIntentionModel"
            inline constexpr std::uintptr_t shotInputLockModel = 0x30; // "ShotInputLockModel"
            inline constexpr std::uintptr_t sprintIntentionModel = 0x38; // "InputIntentionModel"
            inline constexpr std::uintptr_t isShotInputTriggered = 0x40; // "bool"
            inline constexpr std::uintptr_t isShooting = 0x41; // "bool"
            inline constexpr std::uintptr_t isManualShotBlocked = 0x42; // "bool"
            inline constexpr std::uintptr_t weaponDescription = 0x48; // "WeaponDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA99820; // "public void Update()"
            inline constexpr std::uintptr_t Stop = 0xA99710; // "public void Stop()"
            inline constexpr std::uintptr_t UpdateShotLockModel = 0xA99780; // "private void UpdateShotLockModel(bool isShotInputTriggered, WeaponDescription weapon)"
            inline constexpr std::uintptr_t CanShoot = 0xA99460; // "private bool CanShoot(WeaponDescription weapon, BattleCharacterModel serverModel)"
            inline constexpr std::uintptr_t StartFire = 0xA996A0; // "private void StartFire(WeaponDescription weapon)"
            inline constexpr std::uintptr_t ContinueFire = 0xA995F0; // "private void ContinueFire(WeaponDescription weapon, BattleCharacterModel serverModel)"
            inline constexpr std::uintptr_t StopFire = 0xA996D0; // "private void StopFire()"
        }
    } // namespace ShotIntentionUpdater

    namespace ShotInterpolationModel { // "Models.Models.ShotInterpolation.ShotInterpolationModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t transform = 0x10; // "Vector3"
            inline constexpr std::uintptr_t lookDirection = 0x1C; // "Vector3"
            inline constexpr std::uintptr_t oldTransform = 0x28; // "Vector3"
            inline constexpr std::uintptr_t ShotLookOffset = 0x38; // "long"
            inline constexpr std::uintptr_t ShotPositionOffset = 0x40; // "long"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Position = 0x97E9F0; // "public Vector3 get_Position()"
            inline constexpr std::uintptr_t get_LookDirection = 0x97E280; // "public Vector3 get_LookDirection()"
            inline constexpr std::uintptr_t SetPosition = 0x48BAA30; // "public void SetPosition(float x, float y, float z)"
            inline constexpr std::uintptr_t SetLookDirection = 0x48BAA20; // "public void SetLookDirection(float lookDirectionX, float lookDirectionY, float lookDirectionZ)"
            inline constexpr std::uintptr_t Interpolate = 0x48BA860; // "public void Interpolate(long period, float lookDirectionX, float lookDirectionY, float lookDirectionZ, out Vector3 lerpTransform, out Vector3 lerpLookDirection)"
            inline constexpr std::uintptr_t Lerp = 0x48BA9D0; // "private void Lerp(float x, float y, float z, float delta, Vector3 oldValue, out Vector3 result)"
        }
    } // namespace ShotInterpolationModel

    namespace ShotInterpolationSystem { // "Models.Systems.ShotInterpolationSystem (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x43624F0; // "protected override void Tick(ITick tick)"
        }
    } // namespace ShotInterpolationSystem

    namespace ShotParamsModel { // "Game.Battle.Inputs.ShotParamsModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsSet = 0x10; // "bool"
            inline constexpr std::uintptr_t PlayerTs = 0x18; // "long"
            inline constexpr std::uintptr_t LookDirection = 0x20; // "Vector3"
            inline constexpr std::uintptr_t IsFirstInQueue = 0x2C; // "bool"
            inline constexpr std::uintptr_t IsFollowingPrevious = 0x2D; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Set = 0xA99DB0; // "public void Set(long playerTs, Vector3 lookDirection, bool isFirstInQueue, bool isFollowingPreviousShot)"
            inline constexpr std::uintptr_t Unset = 0xA99DE0; // "public void Unset()"
        }
    } // namespace ShotParamsModel

    namespace ShotPartDebugInfo { // "Models.Models.ShotDebugInfoModel.ShotPartDebugInfo (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t From = 0x10; // "Vector3"
            inline constexpr std::uintptr_t To = 0x1C; // "Vector3"
            inline constexpr std::uintptr_t Hits = 0x28; // "Vector3[]"
        }
    } // namespace ShotPartDebugInfo

    namespace ShotResult { // "Models.Models.ShotResultModel.ShotResult (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t HasContact = 0x0; // "bool"
            inline constexpr std::uintptr_t ContactBodyId = 0x4; // "PhysicsBodyId"
            inline constexpr std::uintptr_t ContactRigidBodyPosition = 0xC; // "Vector3"
            inline constexpr std::uintptr_t ContactPosition = 0x18; // "Vector3"
            inline constexpr std::uintptr_t ContactNormal = 0x24; // "Vector3"
            inline constexpr std::uintptr_t ShotDirection = 0x30; // "Vector3"
            inline constexpr std::uintptr_t HitType = 0x3C; // "int"
            inline constexpr std::uintptr_t SurfaceType = 0x40; // "byte"
            inline constexpr std::uintptr_t DistanceCheck = 0x41; // "bool"
        }
    } // namespace ShotResult

    namespace ShotResultModel { // "Models.Models.ShotResultModel.ShotResultModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ShotResult = 0x10; // "ShotResult[]"
            inline constexpr std::uintptr_t HasResult = 0x18; // "bool"
            inline constexpr std::uintptr_t TargetTickIndex = 0x20; // "long"
            inline constexpr std::uintptr_t Count = 0x28; // "int"
            inline constexpr std::uintptr_t Weapon = 0x30; // "WeaponDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Set = 0x48BB290; // "public void Set(long targetTickIndex, int shotCount, WeaponDescription weapon)"
            inline constexpr std::uintptr_t SetResult = 0x48BB220; // "public void SetResult(int shotIndex, ShotResult shotResult)"
            inline constexpr std::uintptr_t Clear = 0x48BB200; // "public void Clear()"
        }
    } // namespace ShotResultModel

    namespace ShotRules { // "Models.Models.ShotArgs.ShotRules (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t CalculateCameraHitPosition = 0x48EB460; // "public static Vector3 CalculateCameraHitPosition(RaycastModel raycastModel, RaycastResult raycastResult, PhysicsData physicsData, HitBoxesData hitBoxesData, in Vector3 lookDirection, in Vector3 cameraOrigin, PhysicsBodyId ignoreBodyId, float range, float shotStartOffsetFromCamera)"
            inline constexpr std::uintptr_t TryCalculateShotHitPosition = 0x48EB7D0; // "public static bool TryCalculateShotHitPosition(RaycastModel raycastModel, RaycastResult raycastResult, PhysicsData physicsData, HitBoxesData hitBoxesData, in Vector3 lookDirection, in Vector3 shotOrigin, in Vector3 cameraHitPosition, float shotStartOffsetFromCamera, PhysicsBodyId ignoreBodyId, out Vector3 hitPosition, out PhysicsBodyId hitBodyId, out float sqrDistance)"
            inline constexpr std::uintptr_t CalculateShotStartOffsetFromCamera = 0x48EB690; // "public static float CalculateShotStartOffsetFromCamera(Vector3 cameraPosition, Vector3 shotPosition, Vector3 shotDirection)"
        }
    } // namespace ShotRules

    namespace SkeletonExtensions { // "Models.HitBox.Extensions.SkeletonExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t GetHierarchy = 0x4A7B4A0; // "public static int GetHierarchy(SkeletonConfig skeletonDescription, int boneIndex, Span<int> bonesResult)"
            inline constexpr std::uintptr_t GetHierarchyWithParents = 0x4A7B310; // "public static int GetHierarchyWithParents(SkeletonConfig skeletonDescription, int boneIndex, int boneParent, Span<int> bonesResult, Span<int> parentsResult)"
            inline constexpr std::uintptr_t GetChildren = 0x4A7B220; // "public static int GetChildren(SkeletonConfig skeletonDescription, int boneIndex, Span<int> result)"
        }
    } // namespace SkeletonExtensions

    namespace SkeletonHitBoxCapsuleDescription { // "Models.References.Character.SkeletonHitBoxCapsuleDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t HitType = 0x10; // "int"
            inline constexpr std::uintptr_t SurfaceType = 0x14; // "byte"
            inline constexpr std::uintptr_t Radius = 0x18; // "float"
            inline constexpr std::uintptr_t Length = 0x1C; // "float"
            inline constexpr std::uintptr_t BoneIndex = 0x20; // "int"
            inline constexpr std::uintptr_t BoneDirectionOffset = 0x24; // "float"
        }
    } // namespace SkeletonHitBoxCapsuleDescription

    namespace SkeletonHitBoxConfig { // "Models.References.Character.SkeletonHitBoxConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Spheres = 0x10; // "SkeletonHitBoxSphereDescription[]"
            inline constexpr std::uintptr_t Capsules = 0x18; // "SkeletonHitBoxCapsuleDescription[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_SpheresCount = 0xA0AD60; // "public int get_SpheresCount()"
            inline constexpr std::uintptr_t GetSphere = 0xBAA730; // "public SkeletonHitBoxSphereDescription GetSphere(int index)"
            inline constexpr std::uintptr_t get_CapsulesCount = 0x7BB180; // "public int get_CapsulesCount()"
            inline constexpr std::uintptr_t GetCapsule = 0x44765D0; // "public SkeletonHitBoxCapsuleDescription GetCapsule(int index)"
        }
    } // namespace SkeletonHitBoxConfig

    namespace SkeletonHitBoxSphereDescription { // "Models.References.Character.SkeletonHitBoxSphereDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t HitType = 0x10; // "int"
            inline constexpr std::uintptr_t SurfaceType = 0x14; // "byte"
            inline constexpr std::uintptr_t Radius = 0x18; // "float"
            inline constexpr std::uintptr_t BoneIndex = 0x1C; // "int"
            inline constexpr std::uintptr_t BoneDirectionOffset = 0x20; // "float"
        }
    } // namespace SkeletonHitBoxSphereDescription

    namespace SkinCenterWeaponContext { // "Game.Global.SkinCenter.Context.SkinCenterWeaponContext (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t globalModel = 0x10; // "GlobalModel"
            inline constexpr std::uintptr_t dialogModel = 0x18; // "SkinCenterDialogModel"
            inline constexpr std::uintptr_t weaponBaseDescription = 0x20; // "WeaponBaseDescription"
            inline constexpr std::uintptr_t viewDescriptions = 0x28; // "WeaponSkinViewDescriptions"
            inline constexpr std::uintptr_t weaponBasesViewDescription = 0x30; // "WeaponBaseViewDescription"
            inline constexpr std::uintptr_t model = 0x38; // "TemporaryEnumValue<WeaponSkinDescription>"
            inline constexpr std::uintptr_t CellDescription = 0x40; // "SkinCenterCellSizesViewDescription.CellDescription"
            inline constexpr std::uintptr_t IsClicked = 0x48; // "bool"
            inline constexpr std::uintptr_t IsBeganHover = 0x49; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Cell = 0x3652FE0; // "public ISkinCenterCellViewDescription get_Cell()"
            inline constexpr std::uintptr_t get_Rarity = 0x3653060; // "public RarityItem get_Rarity()"
            inline constexpr std::uintptr_t get_Selected = 0x7EC9F0; // "public bool get_Selected()"
            inline constexpr std::uintptr_t get_Confirmed = 0x7EC9F0; // "public bool get_Confirmed()"
            inline constexpr std::uintptr_t get_IsOwned = 0x7D5050; // "public bool get_IsOwned()"
            inline constexpr std::uintptr_t get_NeedDebt = 0x7EC9F0; // "public bool get_NeedDebt()"
            inline constexpr std::uintptr_t get_Index = 0x7E3AB0; // "public int get_Index()"
            inline constexpr std::uintptr_t get_Name = 0x3653040; // "public LocalizedString get_Name()"
            inline constexpr std::uintptr_t get_HasParts = 0x7EC9F0; // "public bool get_HasParts()"
            inline constexpr std::uintptr_t get_OwnedParts = 0x7E3AB0; // "public int get_OwnedParts()"
            inline constexpr std::uintptr_t get_MaxParts = 0x7E3AB0; // "public int get_MaxParts()"
            inline constexpr std::uintptr_t get_HasCoins = 0x7EC9F0; // "public bool get_HasCoins()"
            inline constexpr std::uintptr_t get_Coins = 0xACDA50; // "public Money get_Coins()"
            inline constexpr std::uintptr_t get_NeedImprisonment = 0x7EC9F0; // "public bool get_NeedImprisonment()"
            inline constexpr std::uintptr_t get_NeedAchievement = 0x7EC9F0; // "public bool get_NeedAchievement()"
            inline constexpr std::uintptr_t get_NeedPack = 0x7EC9F0; // "public bool get_NeedPack()"
            inline constexpr std::uintptr_t get_NeedBattlePass = 0x7EC9F0; // "public bool get_NeedBattlePass()"
            inline constexpr std::uintptr_t get_NewlyUnlockedCount = 0x207C080; // "public int get_NewlyUnlockedCount()"
            inline constexpr std::uintptr_t GetEmptyIconBySexData = 0x7E3AB0; // "public Sprite GetEmptyIconBySexData(CharacterSexDescription sexData)"
            inline constexpr std::uintptr_t GetIconBySexData = 0x3652DA0; // "public Sprite GetIconBySexData(CharacterSexDescription sexData)"
            inline constexpr std::uintptr_t OnSelect = 0x3652E70; // "public void OnSelect()"
            inline constexpr std::uintptr_t OnBeginHover = 0x7B3360; // "public void OnBeginHover()"
        }
    } // namespace SkinCenterWeaponContext

    namespace SkinCenterWeaponRollRotationInputUpdater { // "Game.Global.SkinCenter.Scene.SkinCenterWeaponRollRotationInputUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t rollRotationView = 0x10; // "SkinCenterRotationView"
            inline constexpr std::uintptr_t delayedRotationResetView = 0x18; // "SkinCenterDelayedRotationResetView"
            inline constexpr std::uintptr_t rotationInputModel = 0x20; // "SceneRotationInputModel"
            inline constexpr std::uintptr_t rollRotationModel = 0x28; // "CustomizeSceneRotationModel"
            inline constexpr std::uintptr_t resetDelay = 0x30; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x3653100; // "public void Update()"
        }
    } // namespace SkinCenterWeaponRollRotationInputUpdater

    namespace SkinCenterWeaponRotationResetModelUpdater { // "Game.Global.SkinCenter.UI.ModelUpdaters.SkinCenterWeaponRotationResetModelUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t dialogModel = 0x10; // "SkinCenterDialogModel"
            inline constexpr std::uintptr_t skinCenterSceneModel = 0x18; // "SkinCenterSceneModel"
            inline constexpr std::uintptr_t rotationModel = 0x20; // "CustomizeSceneRotationModel"
            inline constexpr std::uintptr_t currentSkinId = 0x28; // "string"
            inline constexpr std::uintptr_t currentBaseId = 0x30; // "string"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x363E060; // "public void Update()"
            inline constexpr std::uintptr_t IsWeaponTab = 0x363DF00; // "private bool IsWeaponTab(SkinCenterTab tab)"
        }
    } // namespace SkinCenterWeaponRotationResetModelUpdater

    namespace SpineAdaptationManualBehavior { // "Game.Battle.Entities.BattleCharacter.MeleeAttack.SpineAdaptationManualBehavior (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t root = 0x20; // "Transform"
            inline constexpr std::uintptr_t boneTarget = 0x28; // "Transform"
            inline constexpr std::uintptr_t boneEdge = 0x30; // "Transform"
            inline constexpr std::uintptr_t AnimationWeight = 0x38; // "float"
            inline constexpr std::uintptr_t edgeOverrideRotation = 0x3C; // "Quaternion"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetOverrideRotation = 0xBF8640; // "public void SetOverrideRotation(Quaternion edgeOverrideRotation)"
            inline constexpr std::uintptr_t ManualUpdate = 0xBF8210; // "public override void ManualUpdate()"
        }
    } // namespace SpineAdaptationManualBehavior

    namespace SpriteRecoilModelUpdater { // "Game.Battle.Entities.Player.Recoil.SpriteRecoilModelUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t weapon = 0x10; // "IWeaponModel"
            inline constexpr std::uintptr_t fireModel = 0x18; // "CharacterFireModel"
            inline constexpr std::uintptr_t weapons = 0x20; // "WeaponViewDescriptions"
            inline constexpr std::uintptr_t rotationInput = 0x28; // "PlayerRotationInputModel"
            inline constexpr std::uintptr_t recoilModel = 0x30; // "RecoilModel"
            inline constexpr std::uintptr_t targetRecoil = 0x38; // "Vector2"
            inline constexpr std::uintptr_t random = 0x40; // "Vector2"
            inline constexpr std::uintptr_t currentRecoil = 0x48; // "Vector2"
            inline constexpr std::uintptr_t attackStartRecoil = 0x50; // "Vector2"
            inline constexpr std::uintptr_t decayTs = 0x58; // "float"
            inline constexpr std::uintptr_t attackStartTime = 0x5C; // "float"
            inline constexpr std::uintptr_t attackDuration = 0x60; // "float"
            inline constexpr std::uintptr_t isAttacking = 0x64; // "bool"
            inline constexpr std::uintptr_t indexShot = 0x68; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xB248D0; // "public void Update()"
            inline constexpr std::uintptr_t GetNextRecoil = 0xB23E40; // "private Vector2 GetNextRecoil(Vector2 targetRecoil)"
            inline constexpr std::uintptr_t RecoilCompensation = 0xB240E0; // "private void RecoilCompensation(ref Vector2 previousRecoil)"
            inline constexpr std::uintptr_t CompensateRecoilAxis = 0xB23D60; // "private void CompensateRecoilAxis(float inputDelta, ref float targetRecoil, ref float currentRecoil, ref float attackStartRecoil, ref float previousRecoil)"
            inline constexpr std::uintptr_t RecoilOverextension = 0xB247D0; // "private void RecoilOverextension()"
            inline constexpr std::uintptr_t GetRecoil = 0xB24070; // "private SpriteRecoilViewDescription GetRecoil(WeaponDescription weapon)"
            inline constexpr std::uintptr_t RecoilInflation = 0xB24480; // "private void RecoilInflation()"
            inline constexpr std::uintptr_t RecoilDecay = 0xB24350; // "private void RecoilDecay()"
        }
    } // namespace SpriteRecoilModelUpdater

    namespace StartAimStateSystem { // "Models.Systems.StartAimStateSystem (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x4362E60; // "protected override void Tick(ITick tick)"
            inline constexpr std::uintptr_t StopAiming = 0x4362D10; // "private void StopAiming(AimingModel aiming, AimStateModel aimState, WeaponDescription weapon, long now)"
        }
    } // namespace StartAimStateSystem

    namespace StartKnockdownSystem { // "Models.Systems.StartKnockdownSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t worldInterruptModel = 0x38; // "IWorldInterruptModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x4365000; // "protected override void Tick(ITick tick)"
            inline constexpr std::uintptr_t CalculateDefaultKnockdownParams = 0x4364E00; // "private ValueTuple<float, bool> CalculateDefaultKnockdownParams(ITransformModel transformModel, in Vector3 knockdownDirection)"
            inline constexpr std::uintptr_t CalculateSwimmingKnockdownParams = 0x4364F80; // "private ValueTuple<float, bool> CalculateSwimmingKnockdownParams(ITransformModel transformModel)"
        }
    } // namespace StartKnockdownSystem

    namespace StartMeleeAttackSystem { // "Models.Systems.StartMeleeAttackSystem (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x43652B0; // "protected override void Tick(ITick tick)"
        }
    } // namespace StartMeleeAttackSystem

    namespace StopActionsOnDamageSystem { // "Models.Systems.StopActionsOnDamageSystem (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t worldInterruptModel = 0x38; // "IWorldInterruptModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x4365FA0; // "protected override void Tick(ITick tick)"
        }
    } // namespace StopActionsOnDamageSystem

    namespace StopFireSystem { // "Models.Systems.StopFireSystem (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x43664E0; // "protected override void Tick(ITick tick)"
        }
    } // namespace StopFireSystem

    namespace StopMeleeAttackSystem { // "Models.Systems.StopMeleeAttackSystem (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x4366810; // "protected override void Tick(ITick tick)"
        }
    } // namespace StopMeleeAttackSystem

    namespace SurrenderAnimationUpdater { // "Game.Battle.Surrender.Updaters.SurrenderAnimationUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t surrenderHighlightAnimationView = 0x10; // "SurrenderHighlightAnimationView"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x18; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t now = 0x20; // "INow"
            inline constexpr std::uintptr_t surrenderViewDescription = 0x28; // "PlayerSurrenderArrestViewDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xDB1820; // "public void Update()"
            inline constexpr std::uintptr_t GetIsDistanceBetweenCharactersCorrect = 0xDB1550; // "private bool GetIsDistanceBetweenCharactersCorrect(BattleCharacterModel first, BattleCharacterModel second)"
        }
    } // namespace SurrenderAnimationUpdater

    namespace SurrenderBuffUpdater { // "Game.Battle.Buffs.SurrenderBuffUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t battleEntitiesModel = 0x40; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t now = 0x48; // "INow"
            inline constexpr std::uintptr_t isActive = 0x50; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xD50280; // "public override void Update()"
        }
    } // namespace SurrenderBuffUpdater

    namespace SurrenderCommandConfig { // "Models.References.Surrender.SurrenderCommandConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t CooldownTime = 0x10; // "long"
            inline constexpr std::uintptr_t ScreamTime = 0x18; // "long"
        }
    } // namespace SurrenderCommandConfig

    namespace SurrenderCommandModel { // "Models.Models.SurrenderCommand.SurrenderCommandModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ts = 0x10; // "IPrimitiveData<long>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Set = 0x48C69D0; // "public void Set(long now)"
            inline constexpr std::uintptr_t get_Ts = 0x48C6A30; // "public long get_Ts()"
            inline constexpr std::uintptr_t IsCooldownActive = 0x48C6870; // "public bool IsCooldownActive(long now)"
            inline constexpr std::uintptr_t IsScreamActive = 0x48C6920; // "public bool IsScreamActive(long now)"
        }
    } // namespace SurrenderCommandModel

    namespace SurrenderCommandSystem { // "Models.Systems.SurrenderCommandSystem (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x4367190; // "protected override void Tick(ITick tick)"
        }
    } // namespace SurrenderCommandSystem

    namespace SurrenderConfig { // "Models.References.Surrender.SurrenderConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t EnterTime = 0x10; // "long"
            inline constexpr std::uintptr_t CooldownTime = 0x18; // "long"
        }
    } // namespace SurrenderConfig

    namespace SurrenderInputDescription { // "Models.References.Surrender.SurrenderInputDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x81769A8; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t enum_id = 0x0; // "Enum<SurrenderInputDescription>"
            inline constexpr std::uintptr_t Start = 0x8; // "SurrenderInputDescription"
            inline constexpr std::uintptr_t Stop = 0x10; // "SurrenderInputDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Enum = 0x4071120; // "public static ReadOnlyEnum<SurrenderInputDescription> get_Enum()"
        }
    } // namespace SurrenderInputDescription

    namespace SurrenderInputModel { // "Game.Battle.Surrender.InputModel.SurrenderInputModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t KeyboardInput = 0x10; // "SurrenderInputModel.KeyboardInputModel"
            inline constexpr std::uintptr_t TouchInput = 0x18; // "SurrenderInputModel.TouchInputModel"
        }
    } // namespace SurrenderInputModel

    namespace SurrenderInputModel_KeyboardInputModel { // "Game.Battle.Surrender.InputModel.SurrenderInputModel.KeyboardInputModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t StartSurrender = 0x10; // "InputModel"
            inline constexpr std::uintptr_t StopSurrender = 0x18; // "InputModel"
            inline constexpr std::uintptr_t StopSurrenderWithBackAction = 0x20; // "InputModel"
        }
    } // namespace SurrenderInputModel_KeyboardInputModel

    namespace SurrenderInputModel_TouchInputModel { // "Game.Battle.Surrender.InputModel.SurrenderInputModel.TouchInputModel (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Surrender = 0x10; // "InputModel"
        }
    } // namespace SurrenderInputModel_TouchInputModel

    namespace SurrenderKeys { // "SurrenderKeys (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t NoticeOfSurrender = 0x10; // "LocalizedString"
            inline constexpr std::uintptr_t SurrenderCooldown = 0x18; // "LocalizedString"
        }
    } // namespace SurrenderKeys

    namespace SurrenderModel { // "Models.Models.Surrender.SurrenderModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t surrenderStateModel = 0x10; // "SurrenderStateModel"
            inline constexpr std::uintptr_t cooldownTs = 0x18; // "IPrimitiveData<long>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsActive = 0x48C6E90; // "public bool get_IsActive()"
            inline constexpr std::uintptr_t get_Ts = 0x48C6EB0; // "public long get_Ts()"
            inline constexpr std::uintptr_t get_CooldownTs = 0x48C6E40; // "public long get_CooldownTs()"
            inline constexpr std::uintptr_t GetState = 0x48C6B90; // "public SurrenderState GetState(long now)"
            inline constexpr std::uintptr_t IsOnCooldown = 0x48C6C00; // "public bool IsOnCooldown(long now)"
            inline constexpr std::uintptr_t Start = 0x48C6C60; // "public void Start(long now)"
            inline constexpr std::uintptr_t Stop = 0x48C6D10; // "public void Stop(long now)"
            inline constexpr std::uintptr_t Clear = 0x48C6A80; // "public void Clear()"
        }
    } // namespace SurrenderModel

    namespace SurrenderOrderInputUpdater { // "Game.Battle.Inputs.SurrenderOrderInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t surrenderInputModel = 0x10; // "InputModel"
            inline constexpr std::uintptr_t battleInputModel = 0x18; // "BattleInputModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x20; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t now = 0x28; // "INow"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA9AFA0; // "public void Update()"
        }
    } // namespace SurrenderOrderInputUpdater

    namespace SurrenderStateModel { // "Models.Models.Surrender.SurrenderStateModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ts = 0x10; // "IPrimitiveData<long>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_IsActive = 0x48C7120; // "public bool get_IsActive()"
            inline constexpr std::uintptr_t get_Ts = 0x48C71A0; // "public long get_Ts()"
            inline constexpr std::uintptr_t GetState = 0x48C6F90; // "public SurrenderState GetState(long now)"
            inline constexpr std::uintptr_t Start = 0x48C6FF0; // "public void Start(long now)"
            inline constexpr std::uintptr_t Stop = 0x48C7090; // "public void Stop(long now)"
            inline constexpr std::uintptr_t Clear = 0x48C6F00; // "public void Clear()"
        }
    } // namespace SurrenderStateModel

    namespace SurrenderToFedsModelUpdater { // "Game.Global.Surrender.SurrenderToFedsModelUpdater (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t inputModel = 0x10; // "InputModel"
            inline constexpr std::uintptr_t globalModel = 0x18; // "GlobalModel"
            inline constexpr std::uintptr_t globalScreenContent = 0x20; // "GlobalScreenContent"
            inline constexpr std::uintptr_t inputActions = 0x28; // "InputActions"
            inline constexpr std::uintptr_t networkStatusModel = 0x30; // "NetworkStatusModel"
            inline constexpr std::uintptr_t mailboxModel = 0x38; // "MailboxModel"
            inline constexpr std::uintptr_t skinCenterModelProvider = 0x40; // "Func<SkinCenterModel>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0x374AD70; // "public void Update()"
            inline constexpr std::uintptr_t HasUnclaimedRealmMail = 0x374AC10; // "private bool HasUnclaimedRealmMail()"
        }
    } // namespace SurrenderToFedsModelUpdater

    namespace TouchForceKnockoutEndUpdater { // "Game.Battle.Inputs.TouchForceKnockoutEndUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t forceKnockoutEndInputModel = 0x10; // "InputModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x18; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t roomConnectionBattle = 0x20; // "IRoomConnection"
            inline constexpr std::uintptr_t now = 0x28; // "INow"
            inline constexpr std::uintptr_t isRequest = 0x30; // "bool"
            inline constexpr std::uintptr_t holdEndTs = 0x38; // "double"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA9B790; // "public void Update()"
            inline constexpr std::uintptr_t SendMessage = 0xA9B6E0; // "private void SendMessage()"
        }
    } // namespace TouchForceKnockoutEndUpdater

    namespace TouchSurrenderArrestingUpdater { // "Game.Battle.Inputs.TouchSurrenderArrestingUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t surrenderArrestingInputModel = 0x10; // "InputModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x18; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t roomConnectionBattle = 0x20; // "IRoomConnection"
            inline constexpr std::uintptr_t isRequest = 0x28; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA9CF10; // "public void Update()"
            inline constexpr std::uintptr_t SendMessage = 0xA9CE60; // "private void SendMessage()"
        }
    } // namespace TouchSurrenderArrestingUpdater

    namespace TouchSurrenderInputUpdater { // "Game.Battle.Inputs.Updaters.Touch.TouchSurrenderInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t touchInput = 0x10; // "SurrenderInputModel.TouchInputModel"
            inline constexpr std::uintptr_t battleInputModel = 0x18; // "BattleInputModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x20; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t now = 0x28; // "INow"
            inline constexpr std::uintptr_t personalNotificationModel = 0x30; // "PersonalNotificationModel"
            inline constexpr std::uintptr_t localizationKeys = 0x38; // "LocalizationKeys"
            inline constexpr std::uintptr_t crouchStandUpModel = 0x40; // "CrouchStandUpModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA9D060; // "public void Update()"
        }
    } // namespace TouchSurrenderInputUpdater

    namespace TransformHitBoxBoxDescription { // "Models.References.Character.TransformHitBoxBoxDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t HitType = 0x10; // "int"
            inline constexpr std::uintptr_t SurfaceType = 0x14; // "byte"
            inline constexpr std::uintptr_t Width = 0x18; // "float"
            inline constexpr std::uintptr_t Height = 0x1C; // "float"
            inline constexpr std::uintptr_t Length = 0x20; // "float"
            inline constexpr std::uintptr_t LocalPosition = 0x24; // "Vector3"
            inline constexpr std::uintptr_t LocalOrientation = 0x30; // "Quaternion"
        }
    } // namespace TransformHitBoxBoxDescription

    namespace TransformHitBoxCapsuleDescription { // "Models.References.Character.TransformHitBoxCapsuleDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t HitType = 0x10; // "int"
            inline constexpr std::uintptr_t SurfaceType = 0x14; // "byte"
            inline constexpr std::uintptr_t Radius = 0x18; // "float"
            inline constexpr std::uintptr_t Length = 0x1C; // "float"
            inline constexpr std::uintptr_t LocalPosition = 0x20; // "Vector3"
            inline constexpr std::uintptr_t LocalOrientation = 0x2C; // "Quaternion"
        }
    } // namespace TransformHitBoxCapsuleDescription

    namespace TransformHitBoxDescription { // "Models.References.Character.TransformHitBoxDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Spheres = 0x10; // "TransformHitBoxSphereDescription[]"
            inline constexpr std::uintptr_t Capsules = 0x18; // "TransformHitBoxCapsuleDescription[]"
            inline constexpr std::uintptr_t Boxes = 0x20; // "TransformHitBoxBoxDescription[]"
            inline constexpr std::uintptr_t Hulls = 0x28; // "TransformHitBoxHullDescription[]"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_SpheresCount = 0xA0AD60; // "public int get_SpheresCount()"
            inline constexpr std::uintptr_t GetSphere = 0xBAA730; // "public TransformHitBoxSphereDescription GetSphere(int index)"
            inline constexpr std::uintptr_t get_CapsulesCount = 0x7BB180; // "public int get_CapsulesCount()"
            inline constexpr std::uintptr_t GetCapsule = 0x44765D0; // "public TransformHitBoxCapsuleDescription GetCapsule(int index)"
            inline constexpr std::uintptr_t get_BoxesCount = 0x29D24C0; // "public int get_BoxesCount()"
            inline constexpr std::uintptr_t GetBox = 0xA69A40; // "public TransformHitBoxBoxDescription GetBox(int index)"
            inline constexpr std::uintptr_t get_HullsCount = 0x279EE40; // "public int get_HullsCount()"
            inline constexpr std::uintptr_t GetHull = 0xA69A10; // "public TransformHitBoxHullDescription GetHull(int index)"
        }
    } // namespace TransformHitBoxDescription

    namespace TransformHitBoxHullDescription { // "Models.References.Character.TransformHitBoxHullDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t HitType = 0x10; // "int"
            inline constexpr std::uintptr_t SurfaceType = 0x14; // "byte"
            inline constexpr std::uintptr_t HullDef = 0x18; // "PhysicsHullShapesDescription"
            inline constexpr std::uintptr_t LocalPosition = 0x20; // "Vector3"
            inline constexpr std::uintptr_t LocalOrientation = 0x2C; // "Quaternion"
        }
    } // namespace TransformHitBoxHullDescription

    namespace TransformHitBoxSphereDescription { // "Models.References.Character.TransformHitBoxSphereDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t HitType = 0x10; // "int"
            inline constexpr std::uintptr_t SurfaceType = 0x14; // "byte"
            inline constexpr std::uintptr_t Radius = 0x18; // "float"
            inline constexpr std::uintptr_t LocalPosition = 0x1C; // "Vector3"
            inline constexpr std::uintptr_t LocalOrientation = 0x28; // "Quaternion"
        }
    } // namespace TransformHitBoxSphereDescription

    namespace UseReloadWeapon { // "Game.Battle.EntityModel.BattleCharacter.Equipment.UseReloadWeapon (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t now = 0x10; // "INow"
            inline constexpr std::uintptr_t battleCharacterModel = 0x18; // "BattleCharacterModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t CheckContext = 0xCF0630; // "public bool CheckContext(IItemMoveContext from, IItemMoveContext to)"
            inline constexpr std::uintptr_t CheckRequirement = 0xCF07D0; // "public bool CheckRequirement(IItemMoveContext fromContext, IItemMoveContext toContext)"
            inline constexpr std::uintptr_t GetAmmoMoveContext = 0xCF0A80; // "public IItemMoveContext GetAmmoMoveContext(IItemMoveContext weaponMoveContext)"
        }
    } // namespace UseReloadWeapon

    namespace VelocityDamageModel { // "Models.Models.VelocityDamage.VelocityDamageModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t HasLastBodyVelocity = 0x10; // "bool"
            inline constexpr std::uintptr_t LastBodyVelocity = 0x14; // "Vector3"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SetLastBodyVelocity = 0x48ADC50; // "public void SetLastBodyVelocity(in Vector3 value)"
            inline constexpr std::uintptr_t ClearLastBodyVelocity = 0x844D10; // "public void ClearLastBodyVelocity()"
        }
    } // namespace VelocityDamageModel

    namespace WeaponAimCameraDescription { // "Models.References.Weapon.WeaponAimCameraDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Stand = 0x20; // "TripodDescription"
            inline constexpr std::uintptr_t Crouch = 0x38; // "TripodDescription"
        }
    } // namespace WeaponAimCameraDescription

    namespace WeaponAimModeDescription { // "Models.References.Weapon.WeaponAimModeDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t CameraFunc = 0x20; // "Func<WeaponAimCameraDescription>"
            inline constexpr std::uintptr_t ShotPosition = 0x28; // "WeaponShotPositionDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Camera = 0x9D6230; // "public WeaponAimCameraDescription get_Camera()"
        }
    } // namespace WeaponAimModeDescription

    namespace WeaponAimModeModel { // "Models.Models.WeaponAimModeModel.WeaponAimModeModel (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t GetMode = 0x48AFA60; // "public static WeaponAimModeDescription GetMode(IPrimitiveModel<AimModeDescription> aimModeModel, WeaponDescription weapon)"
            inline constexpr std::uintptr_t ShouldUseLeftShoulderForCamera = 0x48AFB70; // "public static bool ShouldUseLeftShoulderForCamera(IPrimitiveModel<AimModeDescription> aimModeModel, WeaponDescription weapon, AimingModel aimingModel, IPrimitiveModel<bool> leftShoulderView)"
            inline constexpr std::uintptr_t GetAimMode = 0x48AF8C0; // "public static AimModeDescription GetAimMode(IPrimitiveModel<AimModeDescription> aimModeModel, WeaponDescription weapon)"
        }
    } // namespace WeaponAimModeModel

    namespace WeaponAutoReloadSystem { // "Models.Systems.WeaponAutoReloadSystem (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x43731B0; // "protected override void Tick(ITick tick)"
        }
    } // namespace WeaponAutoReloadSystem

    namespace WeaponBaseDescription { // "Models.References.Weapon.WeaponBaseDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t WeaponsLazy = 0x20; // "Lazy<IReadOnlyList<WeaponDescription>>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Weapons = 0x405F9F0; // "public IReadOnlyList<WeaponDescription> get_Weapons()"
            inline constexpr std::uintptr_t get_DefaultWeapon = 0x405F970; // "public WeaponDescription get_DefaultWeapon()"
        }
    } // namespace WeaponBaseDescription

    namespace WeaponCharacterSpeedDescription { // "Models.References.Weapon.WeaponCharacterSpeedDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Value = 0x20; // "CharacterSpeed"
        }
    } // namespace WeaponCharacterSpeedDescription

    namespace WeaponComputedConfig { // "Models.References.Weapon.WeaponComputedConfig (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t baseByWeapon = 0x10; // "Dictionary<WeaponDescription, WeaponBaseDescription>"
            inline constexpr std::uintptr_t defaultSkins = 0x18; // "Dictionary<WeaponBaseDescription, WeaponSkinDescription>"
            inline constexpr std::uintptr_t skinsByWeaponBase = 0x20; // "Dictionary<WeaponBaseDescription, ReadOnly.HashSet<WeaponSkinDescription>>"
            inline constexpr std::uintptr_t weaponItems = 0x28; // "Dictionary<WeaponDescription, InventoryItemDescription>"
            inline constexpr std::uintptr_t emptyWeaponSkins = 0x30; // "ReadOnly.HashSet<WeaponSkinDescription>"
            inline constexpr std::uintptr_t NotAvailableOnStartSkinsCount = 0x38; // "int"
        }
        namespace Methods {
            inline constexpr std::uintptr_t GetWeaponBase = 0x405FAF0; // "public WeaponBaseDescription GetWeaponBase(WeaponDescription weapon)"
            inline constexpr std::uintptr_t GetDefaultSkin = 0x405FA40; // "public WeaponSkinDescription GetDefaultSkin(WeaponBaseDescription weaponBaseDescription)"
            inline constexpr std::uintptr_t GetWeaponItem = 0x405FB50; // "public InventoryItemDescription GetWeaponItem(WeaponDescription weapon)"
            inline constexpr std::uintptr_t GetSkinsByBase = 0x405FAA0; // "public ReadOnly.HashSet<WeaponSkinDescription> GetSkinsByBase(WeaponBaseDescription weaponBaseDescription)"
        }
    } // namespace WeaponComputedConfig

    namespace WeaponDamage { // "Models.References.Weapon.WeaponDamage (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Intervals = 0x10; // "IReadOnlyList<WeaponDamageInterval>"
            inline constexpr std::uintptr_t count = 0x18; // "int"
            inline constexpr std::uintptr_t MaxDamageDistance = 0x1C; // "float"
            inline constexpr std::uintptr_t MaxDamage = 0x20; // "int"
            inline constexpr std::uintptr_t MaxRange = 0x24; // "float"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Calculate = 0x4066AB0; // "public int Calculate(float range)"
        }
    } // namespace WeaponDamage

    namespace WeaponDamageDescription { // "Models.References.Weapon.WeaponDamageDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x821EE90; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t Jp7M1 = 0x0; // "WeaponDamage"
            inline constexpr std::uintptr_t Jp7M2 = 0x8; // "WeaponDamage"
            inline constexpr std::uintptr_t Jp7M3 = 0x10; // "WeaponDamage"
            inline constexpr std::uintptr_t Dp9M1 = 0x18; // "WeaponDamage"
            inline constexpr std::uintptr_t Dp9M2 = 0x20; // "WeaponDamage"
            inline constexpr std::uintptr_t Kl545M1 = 0x28; // "WeaponDamage"
            inline constexpr std::uintptr_t Kl545M2 = 0x30; // "WeaponDamage"
            inline constexpr std::uintptr_t Kl545M3 = 0x38; // "WeaponDamage"
            inline constexpr std::uintptr_t Cb45M1 = 0x40; // "WeaponDamage"
            inline constexpr std::uintptr_t Cb45M2 = 0x48; // "WeaponDamage"
            inline constexpr std::uintptr_t Cb45M3 = 0x50; // "WeaponDamage"
            inline constexpr std::uintptr_t Harris500M1 = 0x58; // "WeaponDamage"
            inline constexpr std::uintptr_t Harris500M2 = 0x60; // "WeaponDamage"
            inline constexpr std::uintptr_t Harris500M3 = 0x68; // "WeaponDamage"
            inline constexpr std::uintptr_t Rc556M1 = 0x70; // "WeaponDamage"
            inline constexpr std::uintptr_t Rc556M2 = 0x78; // "WeaponDamage"
            inline constexpr std::uintptr_t Rc556M3 = 0x80; // "WeaponDamage"
            inline constexpr std::uintptr_t StarhM1 = 0x88; // "WeaponDamage"
            inline constexpr std::uintptr_t StarhM2 = 0x90; // "WeaponDamage"
            inline constexpr std::uintptr_t StarhM3 = 0x98; // "WeaponDamage"
            inline constexpr std::uintptr_t SrReaperM1 = 0xA0; // "WeaponDamage"
            inline constexpr std::uintptr_t SrReaperM2 = 0xA8; // "WeaponDamage"
            inline constexpr std::uintptr_t SrReaperM3 = 0xB0; // "WeaponDamage"
            inline constexpr std::uintptr_t Pdw90M1 = 0xB8; // "WeaponDamage"
            inline constexpr std::uintptr_t Pdw90M2 = 0xC0; // "WeaponDamage"
            inline constexpr std::uintptr_t Pdw90M3 = 0xC8; // "WeaponDamage"
            inline constexpr std::uintptr_t ApScalarM1 = 0xD0; // "WeaponDamage"
            inline constexpr std::uintptr_t ApScalarM2 = 0xD8; // "WeaponDamage"
            inline constexpr std::uintptr_t ApScalarM3 = 0xE0; // "WeaponDamage"
            inline constexpr std::uintptr_t Ordr12M1 = 0xE8; // "WeaponDamage"
            inline constexpr std::uintptr_t Ordr12M2 = 0xF0; // "WeaponDamage"
            inline constexpr std::uintptr_t Ordr12M3 = 0xF8; // "WeaponDamage"
            inline constexpr std::uintptr_t Tag12KM1 = 0x100; // "WeaponDamage"
            inline constexpr std::uintptr_t Tag12KM2 = 0x108; // "WeaponDamage"
            inline constexpr std::uintptr_t Tag12KM3 = 0x110; // "WeaponDamage"
            inline constexpr std::uintptr_t Lbr44M1 = 0x118; // "WeaponDamage"
            inline constexpr std::uintptr_t Lbr44M2 = 0x120; // "WeaponDamage"
            inline constexpr std::uintptr_t Drm14M1 = 0x128; // "WeaponDamage"
            inline constexpr std::uintptr_t Drm14M2 = 0x130; // "WeaponDamage"
            inline constexpr std::uintptr_t Drm14M3 = 0x138; // "WeaponDamage"
            inline constexpr std::uintptr_t Mc10M1 = 0x140; // "WeaponDamage"
            inline constexpr std::uintptr_t Mc10M2 = 0x148; // "WeaponDamage"
            inline constexpr std::uintptr_t Mc10M3 = 0x150; // "WeaponDamage"
            inline constexpr std::uintptr_t Vulture50M1 = 0x158; // "WeaponDamage"
            inline constexpr std::uintptr_t Vulture50M2 = 0x160; // "WeaponDamage"
            inline constexpr std::uintptr_t LmgM2 = 0x168; // "WeaponDamage"
        }
    } // namespace WeaponDamageDescription

    namespace WeaponDamageInterval { // "Models.References.Weapon.WeaponDamageInterval (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Length = 0x10; // "float"
            inline constexpr std::uintptr_t Damage = 0x14; // "int"
        }
    } // namespace WeaponDamageInterval

    namespace WeaponDescription { // "Models.References.Weapon.WeaponDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t ShotCooldown = 0x20; // "long"
            inline constexpr std::uintptr_t Damage = 0x28; // "IWeaponDamage"
            inline constexpr std::uintptr_t Range = 0x30; // "float"
            inline constexpr std::uintptr_t SquaredRange = 0x34; // "float"
            inline constexpr std::uintptr_t HeadDamageModifier = 0x38; // "float"
            inline constexpr std::uintptr_t Magazine = 0x3C; // "int"
            inline constexpr std::uintptr_t ReloadPrecastTime = 0x40; // "long"
            inline constexpr std::uintptr_t ReloadCastTime = 0x48; // "long"
            inline constexpr std::uintptr_t ReloadTypeFunc = 0x50; // "Func<WeaponReloadTypeDescription>"
            inline constexpr std::uintptr_t MinReloadCastTime = 0x58; // "long"
            inline constexpr std::uintptr_t AimingInTime = 0x60; // "long"
            inline constexpr std::uintptr_t AimingOutTime = 0x68; // "long"
            inline constexpr std::uintptr_t SpreadFunc = 0x70; // "Func<WeaponSpreadDescription>"
            inline constexpr std::uintptr_t HipShotPatternFunc = 0x78; // "Func<WeaponShotPatternDescription>"
            inline constexpr std::uintptr_t AimedShotPatternFunc = 0x80; // "Func<WeaponShotPatternDescription>"
            inline constexpr std::uintptr_t TakeInTime = 0x88; // "long"
            inline constexpr std::uintptr_t CharacterSpeedFunc = 0x90; // "Func<WeaponCharacterSpeedDescription>"
            inline constexpr std::uintptr_t AmmoFunc = 0x98; // "Func<AmmoDescription>"
            inline constexpr std::uintptr_t MeleeAttackCharacterAnimatorMaskMaleFunc = 0xA0; // "Func<BattleCharacterAnimatorMaskDescription>"
            inline constexpr std::uintptr_t MeleeAttackCharacterAnimatorMaskFemaleFunc = 0xA8; // "Func<BattleCharacterAnimatorMaskDescription>"
            inline constexpr std::uintptr_t ThirdPersonAimModeFunc = 0xB0; // "Func<WeaponAimModeDescription>"
            inline constexpr std::uintptr_t FirstPersonAimModeFunc = 0xB8; // "Func<WeaponAimModeDescription>"
            inline constexpr std::uintptr_t IsAutomatic = 0xC0; // "bool"
            inline constexpr std::uintptr_t IsPistolPose = 0xC1; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_ReloadType = 0x1CE7810; // "public WeaponReloadTypeDescription get_ReloadType()"
            inline constexpr std::uintptr_t get_Spread = 0x4067240; // "public WeaponSpread get_Spread()"
            inline constexpr std::uintptr_t get_HipShotPattern = 0x4048F20; // "public WeaponShotPatternDescription get_HipShotPattern()"
            inline constexpr std::uintptr_t get_AimedShotPattern = 0x4048F50; // "public WeaponShotPatternDescription get_AimedShotPattern()"
            inline constexpr std::uintptr_t get_CharacterSpeed = 0x40670F0; // "public CharacterSpeed get_CharacterSpeed()"
            inline constexpr std::uintptr_t get_Ammo = 0x4067080; // "public AmmoDescription get_Ammo()"
            inline constexpr std::uintptr_t get_MeleeAttackCharacterAnimatorMaskMale = 0x40671C0; // "public BattleCharacterAnimatorMaskDescription get_MeleeAttackCharacterAnimatorMaskMale()"
            inline constexpr std::uintptr_t get_MeleeAttackCharacterAnimatorMaskFemale = 0x4067190; // "public BattleCharacterAnimatorMaskDescription get_MeleeAttackCharacterAnimatorMaskFemale()"
            inline constexpr std::uintptr_t get_ThirdPersonAimMode = 0x4067270; // "public WeaponAimModeDescription get_ThirdPersonAimMode()"
            inline constexpr std::uintptr_t get_FirstPersonAimMode = 0x4067130; // "public WeaponAimModeDescription get_FirstPersonAimMode()"
            inline constexpr std::uintptr_t get_ReloadRoundsCount = 0x40671F0; // "public int get_ReloadRoundsCount()"
            inline constexpr std::uintptr_t get_HasReloadPrecast = 0x4067160; // "public bool get_HasReloadPrecast()"
            inline constexpr std::uintptr_t get_CanChangeAimMode = 0x40670B0; // "public bool get_CanChangeAimMode()"
        }
    } // namespace WeaponDescription

    namespace WeaponDescriptionExtensions { // "Models.Utils.Extensions.WeaponDescriptionExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t GetBase = 0x3975DA0; // "public static WeaponBaseDescription GetBase(WeaponDescription weaponDescription)"
            inline constexpr std::uintptr_t GetBase_2 = 0x3975D70; // "public static WeaponBaseDescription GetBase(WeaponDescription weaponDescription, WeaponComputedConfig weaponConfig)"
            inline constexpr std::uintptr_t GetItem = 0x3975E30; // "public static InventoryItemDescription GetItem(WeaponDescription weaponDescription)"
            inline constexpr std::uintptr_t GetItem_2 = 0x3975E00; // "public static InventoryItemDescription GetItem(WeaponDescription weaponDescription, WeaponComputedConfig weaponConfig)"
        }
    } // namespace WeaponDescriptionExtensions

    namespace WeaponExtensions { // "Models.Utils.Extensions.WeaponExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t IsWeaponEquipSlot = 0x3976AC0; // "public static bool IsWeaponEquipSlot(EquipSlotDescription equipSlotDescription)"
            inline constexpr std::uintptr_t TryTakeWeaponInHands = 0x3976BA0; // "public static void TryTakeWeaponInHands(BattleCharacterModel model, EquipSlotDescription equipSlotDescription)"
            inline constexpr std::uintptr_t SetWeaponQuickSlotToEquip = 0x3976B60; // "public static void SetWeaponQuickSlotToEquip(EquipSlotDescription equipSlot, LastQuickSlotModel lastQuickSlotModel)"
            inline constexpr std::uintptr_t GetQuickSlotByWeaponEquipSlot = 0x3976750; // "private static QuickSlotDescription GetQuickSlotByWeaponEquipSlot(EquipSlotDescription equipSlotDescription)"
            inline constexpr std::uintptr_t InterruptReload = 0x3976960; // "public static void InterruptReload(long now, WeaponReloadModel weaponReloadModel, ReloadParamsModel reloadParamsModel)"
            inline constexpr std::uintptr_t FillWeaponAmmo = 0x3976510; // "public static void FillWeaponAmmo(ReloadParamsModel reloadParamsModel, WeaponDescription weapon)"
            inline constexpr std::uintptr_t FillFromSpecifiedSlot = 0x3976370; // "private static int FillFromSpecifiedSlot(IInventorySlotModel ammoSlot, WeaponDescription weapon, IAmmoModel weaponAmmoModel)"
            inline constexpr std::uintptr_t FillFromInventory = 0x3975E90; // "private static int FillFromInventory(WeaponDescription weapon, IAmmoModel weaponAmmoModel, IInventoryModel inventory)"
        }
    } // namespace WeaponExtensions

    namespace WeaponInertiaData { // "Game.Battle.EntityModel.BattleCharacter.Weapon.WeaponInertiaData (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t PositionWeight = 0x10; // "Vector3"
            inline constexpr std::uintptr_t RotationWeight = 0x1C; // "Vector3"
            inline constexpr std::uintptr_t LerpSpeed = 0x28; // "float"
            inline constexpr std::uintptr_t Pivot = 0x30; // "Transform"
        }
    } // namespace WeaponInertiaData

    namespace WeaponMagazineModel { // "Models.Models.WeaponMagazine.WeaponMagazineModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t weaponModel = 0x10; // "IWeaponModel"
            inline constexpr std::uintptr_t equipAmmo = 0x18; // "IEquipAmmoModel"
            inline constexpr std::uintptr_t selectedQuickSlot = 0x20; // "SelectedQuickSlotModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Amount = 0x48AFF60; // "public int get_Amount()"
            inline constexpr std::uintptr_t set_Amount = 0x48AFFB0; // "public void set_Amount(int value)"
            inline constexpr std::uintptr_t IsEmpty = 0x48AFD80; // "public bool IsEmpty()"
            inline constexpr std::uintptr_t IsFull = 0x48AFDE0; // "public bool IsFull()"
            inline constexpr std::uintptr_t get_Ammo = 0x48AFEE0; // "private IAmmoModel get_Ammo()"
        }
    } // namespace WeaponMagazineModel

    namespace WeaponModel { // "Models.Models.WeaponModel.WeaponModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t itemInHands = 0x10; // "IInventoryItemModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_HasValue = 0x48B0020; // "public bool get_HasValue()"
            inline constexpr std::uintptr_t get_Value = 0x48B00A0; // "public WeaponDescription get_Value()"
        }
    } // namespace WeaponModel

    namespace WeaponReloadInputUpdater { // "Game.Battle.Inputs.Keyboard.WeaponReloadInputUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t action = 0x10; // "InputAction"
            inline constexpr std::uintptr_t time = 0x18; // "TimeModel"
            inline constexpr std::uintptr_t battleInputModel = 0x20; // "BattleInputModel"
            inline constexpr std::uintptr_t battleEntitiesModel = 0x28; // "IBattleEntitiesModel"
            inline constexpr std::uintptr_t shotInputLockModel = 0x30; // "ShotInputLockModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA9EEE0; // "public void Update()"
        }
    } // namespace WeaponReloadInputUpdater

    namespace WeaponReloadModel { // "Models.Models.WeaponReload.WeaponReloadModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t state = 0x10; // "IPrimitiveData<WeaponReloadStateDescription>"
            inline constexpr std::uintptr_t endTs = 0x18; // "IPrimitiveData<long>"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_State = 0x48B04D0; // "public WeaponReloadStateDescription get_State()"
            inline constexpr std::uintptr_t get_EndTs = 0x48B03D0; // "public long get_EndTs()"
            inline constexpr std::uintptr_t get_IsInProcess = 0x48B0420; // "public bool get_IsInProcess()"
            inline constexpr std::uintptr_t SetState = 0x48B0280; // "public void SetState(WeaponReloadStateDescription state, long endTs)"
            inline constexpr std::uintptr_t Stop = 0x48B0310; // "public void Stop()"
            inline constexpr std::uintptr_t CheckReload = 0x48B0170; // "public bool CheckReload(bool isAimed, AimStateDescription aimState, bool isSprintActive, bool isSprintInTransition, bool isFireInProcess, bool isMeleeAttackActive)"
            inline constexpr std::uintptr_t CheckReload_2 = 0x48B01A0; // "public bool CheckReload(AimingModel aimingModel, AimStateModel aimStateModel, SprintModel sprintModel, FireModel fireModel, MeleeAttackModel meleeAttackModel)"
        }
    } // namespace WeaponReloadModel

    namespace WeaponReloadRules { // "Models.Models.WeaponReload.WeaponReloadRules (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t IsBackground = 0x48B0CE0; // "public static bool IsBackground(SelectedQuickSlotModel selectedQuickSlotModel, EquipSlotDescription weaponEquipSlot)"
            inline constexpr std::uintptr_t ValidateInput = 0x48B1B20; // "public static bool ValidateInput(IInventoryModel inventory, InventorySlotDescription ammoInventorySlot, InventorySlotDescription weaponInventorySlot, EquipSlotDescription weaponEquipSlot)"
            inline constexpr std::uintptr_t ValidateAmmoInput = 0x48B1A80; // "private static bool ValidateAmmoInput(IInventoryModel inventory, InventorySlotDescription ammoInventorySlot)"
            inline constexpr std::uintptr_t ValidateWeaponInput = 0x48B1C60; // "private static bool ValidateWeaponInput(IInventoryModel inventory, InventorySlotDescription weaponInventorySlot, EquipSlotDescription weaponEquipSlot)"
            inline constexpr std::uintptr_t CheckReloadParams = 0x48B0590; // "public static bool CheckReloadParams(long now, IInventoryModel inventoryModel, IEquipSlotsModel equipSlotsModel, IEquipAmmoModel equipAmmoModel, EquipSlotsDelaysModel equipSlotsDelays, InventorySlotDescription ammoInventorySlot, InventorySlotDescription weaponInventorySlot, EquipSlotDescription weaponEquipSlot)"
            inline constexpr std::uintptr_t GetAmmoForReload = 0x48B07A0; // "public static void GetAmmoForReload(long now, IInventoryModel inventoryModel, IEquipSlotsModel equipSlotsModel, IEquipAmmoModel equipAmmoModel, EquipSlotsDelaysModel equipSlotsDelays, InventorySlotDescription weaponInventorySlot, EquipSlotDescription weaponEquipSlot, out InventorySlotDescription slot)"
            inline constexpr std::uintptr_t HasAmmo = 0x48B0BF0; // "public static bool HasAmmo(AmmoDescription weaponAmmo, IInventoryModel ammoInventory, IInventoryModel inventoryModel, InventorySlotDescription ammoInventorySlot)"
            inline constexpr std::uintptr_t TryGetWeapon = 0x48B1600; // "private static bool TryGetWeapon(long now, IInventoryModel inventoryModel, IEquipSlotsModel equipSlotsModel, IEquipAmmoModel equipAmmoModel, EquipSlotsDelaysModel equipSlotsDelays, InventorySlotDescription inventorySlot, EquipSlotDescription equipSlot, out WeaponDescription weapon, out IAmmoModel ammoModel, out IInventoryModel ammoInventory)"
            inline constexpr std::uintptr_t TryGetSpecifiedAmmo = 0x48B13E0; // "private static bool TryGetSpecifiedAmmo(IInventoryModel inventoryModel, InventorySlotDescription inventorySlot, out AmmoDescription ammoDescription, out IInventoryStackModel stackModel)"
            inline constexpr std::uintptr_t HasAmmoInInventory = 0x48B0BD0; // "public static bool HasAmmoInInventory(IInventoryModel inventoryModel, AmmoDescription ammo)"
            inline constexpr std::uintptr_t GetAmmoInInventory = 0x48B08F0; // "private static InventorySlotDescription GetAmmoInInventory(IInventoryModel inventoryModel, AmmoDescription ammo)"
            inline constexpr std::uintptr_t IsSingleAmmoSlotInInventory = 0x48B0FE0; // "private static bool IsSingleAmmoSlotInInventory(IInventoryModel inventoryModel, IInventorySlotModel slotModel, AmmoDescription ammo)"
            inline constexpr std::uintptr_t IsInventorySlotUsedInReload = 0x48B0E00; // "public static bool IsInventorySlotUsedInReload(ReloadParamsModel reloadParamsModel, IInventoryModel inventoryModel, IInventorySlotModel slotModel)"
            inline constexpr std::uintptr_t IsEquipSlotUsedInReload = 0x48B0D30; // "public static bool IsEquipSlotUsedInReload(ReloadParamsModel reloadParamsModel, IEquipSlotModel slotModel)"
            inline constexpr std::uintptr_t IsSlotUsedInReload = 0x48B1260; // "private static bool IsSlotUsedInReload(ReloadParamsModel reloadParamsModel, IInventoryModel inventoryModel, IInventorySlotModel slotModel)"
        }
    } // namespace WeaponReloadRules

    namespace WeaponReloadStateDescription { // "Models.References.Weapon.WeaponReloadStateDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x8220038; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace StaticFields {
            inline constexpr std::uintptr_t enum_id = 0x0; // "Enum<WeaponReloadStateDescription>"
            inline constexpr std::uintptr_t Precast = 0x8; // "WeaponReloadStateDescription"
            inline constexpr std::uintptr_t Cast = 0x10; // "WeaponReloadStateDescription"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_Enum = 0x4067500; // "public static ReadOnlyEnum<WeaponReloadStateDescription> get_Enum()"
        }
    } // namespace WeaponReloadStateDescription

    namespace WeaponReloadTypeDescription { // "Models.References.Weapon.WeaponReloadTypeDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t IsReloadingBySingleBullet = 0x20; // "bool"
            inline constexpr std::uintptr_t CanFinishReloadOnInterrupt = 0x21; // "bool"
            inline constexpr std::uintptr_t IsReloadInterruptedByShot = 0x22; // "bool"
        }
    } // namespace WeaponReloadTypeDescription

    namespace WeaponRoundsSystem { // "Models.Systems.WeaponRoundsSystem (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x43738C0; // "protected override void Tick(ITick tick)"
        }
    } // namespace WeaponRoundsSystem

    namespace WeaponSensitivityUpdater { // "Game.Battle.Inputs.WeaponSensitivityUpdater (Battle.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t aimingModel = 0x10; // "CharacterAimingModel"
            inline constexpr std::uintptr_t weapon = 0x18; // "IWeaponModel"
            inline constexpr std::uintptr_t sensitivityModel = 0x20; // "SensitivityModel"
        }
        namespace Methods {
            inline constexpr std::uintptr_t Update = 0xA9F100; // "public void Update()"
        }
    } // namespace WeaponSensitivityUpdater

    namespace WeaponShotPattern { // "Models.References.Weapon.WeaponShotPattern (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t MandatoryYaw = 0x10; // "float"
            inline constexpr std::uintptr_t MandatoryPitch = 0x14; // "float"
            inline constexpr std::uintptr_t RandomYaw = 0x18; // "float"
            inline constexpr std::uintptr_t RandomPitch = 0x1C; // "float"
        }
    } // namespace WeaponShotPattern

    namespace WeaponShotPatternDescription { // "Models.References.Weapon.WeaponShotPatternDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Patterns = 0x20; // "WeaponShotPattern[]"
            inline constexpr std::uintptr_t Count = 0x28; // "int"
        }
    } // namespace WeaponShotPatternDescription

    namespace WeaponShotPositionDescription { // "Models.References.Weapon.WeaponShotPositionDescription (Models.dll)"
        inline constexpr std::uintptr_t TypeInfo = 0x8220EB8; // "RVA of the IL2CPP TypeInfo metadata slot"
        namespace Fields {
            inline constexpr std::uintptr_t Stand = 0x10; // "TripodDescription"
            inline constexpr std::uintptr_t Crouch = 0x28; // "TripodDescription"
        }
        namespace StaticFields {
            inline constexpr std::uintptr_t Jp7 = 0x0; // "WeaponShotPositionDescription"
            inline constexpr std::uintptr_t Dp9 = 0x8; // "WeaponShotPositionDescription"
            inline constexpr std::uintptr_t Kl545 = 0x10; // "WeaponShotPositionDescription"
            inline constexpr std::uintptr_t Cb45 = 0x18; // "WeaponShotPositionDescription"
            inline constexpr std::uintptr_t Harris500 = 0x20; // "WeaponShotPositionDescription"
            inline constexpr std::uintptr_t Rc556 = 0x28; // "WeaponShotPositionDescription"
            inline constexpr std::uintptr_t Starh = 0x30; // "WeaponShotPositionDescription"
            inline constexpr std::uintptr_t SrReaper = 0x38; // "WeaponShotPositionDescription"
            inline constexpr std::uintptr_t Pdw90 = 0x40; // "WeaponShotPositionDescription"
            inline constexpr std::uintptr_t ApScalar = 0x48; // "WeaponShotPositionDescription"
            inline constexpr std::uintptr_t Ordr12 = 0x50; // "WeaponShotPositionDescription"
            inline constexpr std::uintptr_t Lbr44 = 0x58; // "WeaponShotPositionDescription"
            inline constexpr std::uintptr_t Tag12 = 0x60; // "WeaponShotPositionDescription"
            inline constexpr std::uintptr_t Drm14 = 0x68; // "WeaponShotPositionDescription"
            inline constexpr std::uintptr_t Mc10 = 0x70; // "WeaponShotPositionDescription"
            inline constexpr std::uintptr_t Vulture50 = 0x78; // "WeaponShotPositionDescription"
            inline constexpr std::uintptr_t Lmg = 0x80; // "WeaponShotPositionDescription"
        }
    } // namespace WeaponShotPositionDescription

    namespace WeaponSkinDescription { // "Models.References.Weapon.WeaponSkinDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t WeaponBaseDescriptionFunc = 0x20; // "Func<WeaponBaseDescription>"
            inline constexpr std::uintptr_t IsDefault = 0x28; // "bool"
            inline constexpr std::uintptr_t IsAvailableOnStart = 0x29; // "bool"
            inline constexpr std::uintptr_t CryptoCoinsPrice = 0x2C; // "int"
            inline constexpr std::uintptr_t CompensationCryptoCoins = 0x30; // "int"
            inline constexpr std::uintptr_t ImprisonmentYearsRequired = 0x34; // "int"
            inline constexpr std::uintptr_t IsHidden = 0x38; // "bool"
        }
        namespace Methods {
            inline constexpr std::uintptr_t get_WeaponBaseDescription = 0x9D6230; // "public WeaponBaseDescription get_WeaponBaseDescription()"
            inline constexpr std::uintptr_t get_HasPrice = 0x40898F0; // "public bool get_HasPrice()"
            inline constexpr std::uintptr_t get_BuyParams = 0x4089890; // "public ValueTuple<int, int> get_BuyParams()"
        }
    } // namespace WeaponSkinDescription

    namespace WeaponSkinExtensions { // "Models.Utils.Extensions.WeaponSkinExtensions (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t CheckSelectSkin = 0x3976C80; // "public static bool CheckSelectSkin(WeaponSkinDescription skinDescription, IOwnedItemsModel<WeaponSkinDescription> ownedSkinsModel)"
        }
    } // namespace WeaponSkinExtensions

    namespace WeaponSkinsData { // "Models.Data.WeaponSkinsData (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t SelectedSkins = 0x20; // "ReferenceMapData<WeaponBaseDescription, IPrimitiveData<WeaponSkinDescription>>"
            inline constexpr std::uintptr_t OwnedSkins = 0x28; // "SetData<WeaponSkinDescription>"
        }
    } // namespace WeaponSkinsData

    namespace WeaponSkinsModel { // "Models.Models.WeaponSkins.WeaponSkinsModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t data = 0x10; // "WeaponSkinsData"
        }
        namespace Methods {
            inline constexpr std::uintptr_t SelectSkin = 0x48B1FA0; // "public void SelectSkin(WeaponSkinDescription weaponSkinDescription)"
            inline constexpr std::uintptr_t GetSelectedSkin = 0x48B1E60; // "public WeaponSkinDescription GetSelectedSkin(WeaponBaseDescription weaponBaseDescription)"
            inline constexpr std::uintptr_t Clear = 0x48B1D30; // "public void Clear()"
        }
    } // namespace WeaponSkinsModel

    namespace WeaponSpread { // "Models.References.Weapon.WeaponSpread (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t MovingStand = 0x10; // "WeaponStateSpread"
            inline constexpr std::uintptr_t MovingCrouch = 0x18; // "WeaponStateSpread"
            inline constexpr std::uintptr_t StillStand = 0x20; // "WeaponStateSpread"
            inline constexpr std::uintptr_t StillCrouch = 0x28; // "WeaponStateSpread"
            inline constexpr std::uintptr_t Aimed = 0x30; // "WeaponStateSpread"
            inline constexpr std::uintptr_t InAir = 0x38; // "WeaponStateSpread"
            inline constexpr std::uintptr_t ShotInc = 0x40; // "float"
            inline constexpr std::uintptr_t TickDec = 0x44; // "float"
        }
    } // namespace WeaponSpread

    namespace WeaponSpreadArgsModel { // "Models.Models.WeaponSpreadArgs.WeaponSpreadArgsModel (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t HasSpread = 0x10; // "bool"
            inline constexpr std::uintptr_t Spread = 0x14; // "float"
            inline constexpr std::uintptr_t StateSpread = 0x18; // "WeaponStateSpread"
            inline constexpr std::uintptr_t ShotSpreadOffsetX = 0x20; // "float"
            inline constexpr std::uintptr_t ShotSpreadOffsetY = 0x24; // "float"
            inline constexpr std::uintptr_t ShotSpreadBasisX = 0x28; // "Vector3"
            inline constexpr std::uintptr_t ShotSpreadBasisY = 0x34; // "Vector3"
            inline constexpr std::uintptr_t ShotSpreadBasisZ = 0x40; // "Vector3"
        }
        namespace Methods {
            inline constexpr std::uintptr_t ClearShotSpreadOffset = 0x48B2030; // "public void ClearShotSpreadOffset()"
        }
    } // namespace WeaponSpreadArgsModel

    namespace WeaponSpreadArgsSystem { // "Models.Systems.WeaponSpreadArgsSystem (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x4373CE0; // "protected override void Tick(ITick tick)"
            inline constexpr std::uintptr_t GetStateSpread = 0x4373AC0; // "private WeaponStateSpread GetStateSpread(WeaponSpread weaponSpread, CharacterControllerModel characterController, CrouchModel crouchModel, CharacterVelocityModel velocity, BattleCharacterConfig config, AimingModel aiming)"
            inline constexpr std::uintptr_t Clamp = 0x4373A40; // "private float Clamp(float value, float min, float max)"
        }
    } // namespace WeaponSpreadArgsSystem

    namespace WeaponSpreadDescription { // "Models.References.Weapon.WeaponSpreadDescription (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Value = 0x20; // "WeaponSpread"
        }
    } // namespace WeaponSpreadDescription

    namespace WeaponSpreadSystem { // "Models.Systems.WeaponSpreadSystem (Models.dll)"
        namespace Methods {
            inline constexpr std::uintptr_t Tick = 0x4374000; // "protected override void Tick(ITick tick)"
            inline constexpr std::uintptr_t Clamp = 0x4373F80; // "private float Clamp(float value, float min, float max)"
        }
    } // namespace WeaponSpreadSystem

    namespace WeaponStateSpread { // "Models.References.Weapon.WeaponStateSpread (Models.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t Min = 0x10; // "float"
            inline constexpr std::uintptr_t Max = 0x14; // "float"
        }
    } // namespace WeaponStateSpread

    namespace WeaponTypeTitles { // "Game.Global.SkinCenter.ViewDescriptions.WeaponTypeTitles (Global.dll)"
        namespace Fields {
            inline constexpr std::uintptr_t WeaponType = 0x10; // "SkinCenterWeaponType"
            inline constexpr std::uintptr_t Title = 0x18; // "LocalizedString"
        }
    } // namespace WeaponTypeTitles

} // namespace Offsets::Combat_Weapons
