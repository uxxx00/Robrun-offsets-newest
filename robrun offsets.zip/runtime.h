#pragma once
#include <cstdint>

namespace Offsets::Runtime {
    // Byte offsets for the x64 layout in il2cpp.h.

    namespace Il2CppObject {
        inline constexpr std::uintptr_t klass = 0x0;
        inline constexpr std::uintptr_t monitor = 0x8;
        inline constexpr std::uintptr_t header_size = 0x10;
    } // namespace Il2CppObject

    namespace Il2CppClass {
        inline constexpr std::uintptr_t name = 0x10;
        inline constexpr std::uintptr_t namespaze = 0x18;
        inline constexpr std::uintptr_t parent = 0x58;
        inline constexpr std::uintptr_t static_fields = 0xB8;
        inline constexpr std::uintptr_t fields = 0x80;
    } // namespace Il2CppClass

    namespace Il2CppArray {
        inline constexpr std::uintptr_t bounds = 0x10;
        inline constexpr std::uintptr_t max_length = 0x18;
        inline constexpr std::uintptr_t first_element = 0x20;
    } // namespace Il2CppArray

    namespace Il2CppString {
        inline constexpr std::uintptr_t length = 0x10;
        inline constexpr std::uintptr_t chars = 0x14;
    } // namespace Il2CppString

    namespace SystemString {
        inline constexpr std::uintptr_t _stringLength = 0x10;
        inline constexpr std::uintptr_t _firstChar = 0x14;
    } // namespace SystemString

    namespace List {
        inline constexpr std::uintptr_t _items = 0x10;
        inline constexpr std::uintptr_t _size = 0x18;
        inline constexpr std::uintptr_t _version = 0x1C;
    } // namespace List

    namespace Dictionary {
        inline constexpr std::uintptr_t _buckets = 0x10;
        inline constexpr std::uintptr_t _entries = 0x18;
        inline constexpr std::uintptr_t _count = 0x20;
    } // namespace Dictionary

    namespace Dictionary::Entry { // Dictionary<int, object> value-type entry
        inline constexpr std::uintptr_t hashCode = 0x0;
        inline constexpr std::uintptr_t next = 0x4;
        inline constexpr std::uintptr_t key = 0x8;
        inline constexpr std::uintptr_t value = 0x10;
        inline constexpr std::uintptr_t stride = 0x18;
    } // namespace Dictionary::Entry

    namespace ReadOnlyDictionaryNonAlloc {
        inline constexpr std::uintptr_t _dictionary = 0x10;
    } // namespace ReadOnlyDictionaryNonAlloc

    namespace ReadOnly::Dictionary {
        inline constexpr std::uintptr_t _dictionary = 0x10;
    } // namespace ReadOnly::Dictionary

} // namespace Offsets::Runtime
